# Framework revalidation of `assign1-10-4` — 2026-09-02

## Result

The exact optimum remains **422**. This run independently re-executed the existing exact certificate
against both archived objective-422 solutions and obtained `CERTIFIED OPTIMUM: 422` twice.

The proof is combinatorial and does not depend on closing the branch-and-bound gap: the four recovered
categorical attributes contribute unavoidable lower bounds 76, 192, 64, and 90, summing to 422. Both
saved solutions are feasible for the original 582-row MPS and attain 422.

## API-driven framework attempt

The one-hour preset was first increased from 30,000 to 60,000 tokens and run end to end.

- Background: 7,525 tokens.
- Solving: 32,486 tokens.
- Reporting: 6,968 tokens.
- Total: 46,979 tokens.
- Controller status: completed, with machine status left `unknown` because no controlled solver result
  proving optimality was fetched during the API-driven solving stage.
- Git commit/push: `a16b1b09a6489e4eef801ac0579e9bf802d8185f`.

The model correctly found the existing proof and solutions, but spent seven solving turns repeatedly
reading files and correcting paths. It reached the conservative input reserve before launching a solver.
This is a workflow-strategy failure, not a failure of the mathematical certificate.

## Fresh controlled Gurobi replay

Run ID: `gurobi-20260902-201631-e8c4c12b`.

- Gurobi 13.0.1 on `euler4`.
- 32 controller-managed CPU threads; a model-requested 64-thread override was ignored.
- Verified objective-422 solution uploaded and loaded as a MIP start.
- Time limit/runtime: 60 s / 60.10 s.
- Termination: `TIME_LIMIT`.
- Primal bound: 422.
- Dual bound: 364.
- Relative gap: 13.7441%.
- Nodes: 118.
- Solver proof flags: neither optimal nor infeasible.

The Gurobi run reproduces feasibility and the objective but does not itself prove optimality in 60 seconds.
Optimality comes from the independently re-executed exact integer certificate.

## Framework changes after the attempt

- One-hour token ceiling increased to 100,000: 15k background, 65k solving, 20k reporting.
- At most four `read_file` actions are accepted per turn.
- File reads return bounded head/tail previews instead of large full contents.
- The solving prompt permits at most two consecutive read/list/search-only turns; the next turn must
  start or manage a controlled solver verification.
- Regression suite: 18/18 tests passed.
