#!/usr/bin/env python3
"""Exact type-aggregated convex MIQP lower bound for assign1-10-4."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


N_ITEMS = 52
N_GROUPS = 10
QUOTAS = [5] * 8 + [6] * 2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("structure", type=Path)
    parser.add_argument("--seconds", type=float, default=600.0)
    parser.add_argument("--threads", type=int, default=32)
    parser.add_argument("--log", type=Path)
    parser.add_argument("--result", type=Path)
    parser.add_argument("--write-model", type=Path)
    parser.add_argument("--no-symmetry", action="store_true")
    args = parser.parse_args()

    data = json.loads(args.structure.read_text(encoding="utf-8"))
    weights: list[list[int]] = data["weights"]
    gram = [[weights[i][j] - int(i == j) for j in range(N_ITEMS)] for i in range(N_ITEMS)]

    profiles: list[list[int]] = []
    item_profile = [-1] * N_ITEMS
    for i in range(N_ITEMS):
        if item_profile[i] >= 0:
            continue
        profile = [j for j in range(N_ITEMS) if gram[j] == gram[i]]
        t = len(profiles)
        profiles.append(profile)
        for j in profile:
            item_profile[j] = t
    representatives = [profile[0] for profile in profiles]
    multiplicities = [len(profile) for profile in profiles]
    n_types = len(profiles)
    type_gram = [[gram[representatives[t]][representatives[u]] for u in range(n_types)] for t in range(n_types)]
    print(f"types={n_types} multiplicities={multiplicities} distribution={Counter(multiplicities)}")

    model = gp.Model("assign1_type_aggregated_convex_miqp")
    z = {
        (t, g): model.addVar(
            lb=0,
            ub=min(multiplicities[t], QUOTAS[g]),
            vtype=GRB.INTEGER,
            name=f"z_{t + 1}_{g + 1}",
        )
        for t in range(n_types)
        for g in range(N_GROUPS)
    }
    for t in range(n_types):
        model.addConstr(
            gp.quicksum(z[t, g] for g in range(N_GROUPS)) == multiplicities[t],
            name=f"all_people_type_{t + 1}",
        )
    for g, quota in enumerate(QUOTAS):
        model.addConstr(
            gp.quicksum(z[t, g] for t in range(n_types)) == quota,
            name=f"quota_{g + 1}",
        )

    # Sort equal-capacity groups by a base-7 code of the first six type counts.
    # This is pure relabeling and therefore cannot remove an unlabeled partition.
    if not args.no_symmetry:
        code_terms = min(6, n_types)
        codes = []
        for g in range(N_GROUPS):
            code = gp.quicksum((7 ** (code_terms - 1 - t)) * z[t, g] for t in range(code_terms))
            codes.append(code)
        for first, last in ((0, 8), (8, 10)):
            for g in range(first, last - 1):
                model.addConstr(codes[g] >= codes[g + 1], name=f"order_group_code_{g + 1}")

    objective = gp.QuadExpr(-sum(type_gram[t][t] * multiplicities[t] for t in range(n_types)))
    for g in range(N_GROUPS):
        for t in range(n_types):
            objective.add(type_gram[t][t] * z[t, g] * z[t, g])
            for u in range(t + 1, n_types):
                if type_gram[t][u]:
                    objective.add(2 * type_gram[t][u] * z[t, g] * z[u, g])
    model.setObjective(objective, GRB.MINIMIZE)

    if "groups" in data:
        raw_counts: list[list[int]] = []
        for group in data["groups"]:
            counts = [0] * n_types
            for item in group:
                counts[item_profile[item]] += 1
            raw_counts.append(counts)
        canonical_counts: list[list[int]] = []
        for first, last in ((0, 8), (8, 10)):
            canonical_counts.extend(sorted(raw_counts[first:last], key=lambda row: tuple(row[:6]), reverse=True))
        start_objective = 0
        for counts in canonical_counts:
            start_objective += sum(
                type_gram[t][u] * counts[t] * counts[u]
                for t in range(n_types)
                for u in range(n_types)
            )
        start_objective -= sum(type_gram[t][t] * multiplicities[t] for t in range(n_types))
        print(f"warm_start_objective={start_objective}")
        for g, counts in enumerate(canonical_counts):
            for t, value in enumerate(counts):
                z[t, g].Start = value

    model.Params.TimeLimit = args.seconds
    model.Params.Threads = args.threads
    model.Params.MIPFocus = 3
    model.Params.Symmetry = 2
    model.Params.Presolve = 2
    model.Params.PreQLinearize = 0
    model.Params.DisplayInterval = 10
    if args.log:
        model.Params.LogFile = str(args.log)
    if args.write_model:
        model.write(str(args.write_model))
    model.optimize()
    print(
        f"FINAL status={model.Status} solcount={model.SolCount} nodes={model.NodeCount} "
        f"bound={model.ObjBound} runtime={model.Runtime:.3f}"
    )
    if model.SolCount:
        print(f"objective={model.ObjVal}")
        if args.result:
            model.write(str(args.result))
    if model.Status == GRB.OPTIMAL:
        print(f"CERTIFIED LOWER BOUND: {round(model.ObjVal)}")


if __name__ == "__main__":
    main()
