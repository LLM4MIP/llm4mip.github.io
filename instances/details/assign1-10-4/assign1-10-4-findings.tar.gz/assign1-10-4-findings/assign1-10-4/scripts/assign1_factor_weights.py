#!/usr/bin/env python3
"""Recover a binary incidence factor A from W = I + A A^T."""

from __future__ import annotations

import argparse
import json
from itertools import combinations
from pathlib import Path

import numpy as np


def repair_incidence(
    start: np.ndarray, gram: np.ndarray, rng: np.random.Generator, steps: int = 200000
) -> tuple[np.ndarray, int]:
    incidence = start.copy()
    product = incidence @ incidence.T
    best = incidence.copy()
    best_error = int(np.abs(product - gram).sum())
    stagnation = 0
    for step in range(steps):
        errors = np.abs(product - gram)
        row_errors = errors.sum(axis=1)
        total_error = int(row_errors.sum())
        if total_error == 0:
            return incidence, 0
        conflicted = np.flatnonzero(row_errors)
        i = int(rng.choice(conflicted, p=row_errors[conflicted] / row_errors[conflicted].sum()))
        selected = np.flatnonzero(incidence[i])
        unselected = np.flatnonzero(1 - incidence[i])
        current_cost = int(errors[i].sum())
        moves: list[tuple[int, int, int, np.ndarray]] = []
        for removed in selected:
            for added in unselected:
                candidate_row = incidence[i].copy()
                candidate_row[removed] = 0
                candidate_row[added] = 1
                candidate_dots = incidence @ candidate_row
                candidate_dots[i] = 4
                candidate_cost = int(np.abs(candidate_dots - gram[i]).sum())
                moves.append((candidate_cost - current_cost, int(removed), int(added), candidate_dots))
        minimum_delta = min(move[0] for move in moves)
        near_best = [move for move in moves if move[0] <= minimum_delta + (1 if stagnation > 100 else 0)]
        delta, removed, added, candidate_dots = near_best[int(rng.integers(len(near_best)))]
        accept = delta <= 0 or rng.random() < np.exp(-delta / max(0.2, 2.0 * (1 - step / steps)))
        if accept:
            incidence[i, removed] = 0
            incidence[i, added] = 1
            product[i, :] = candidate_dots
            product[:, i] = candidate_dots
            stagnation = 0 if delta < 0 else stagnation + 1
        else:
            stagnation += 1
        new_error = int(np.abs(product - gram).sum())
        if new_error < best_error:
            best_error = new_error
            best = incidence.copy()
            print(f"repair_step={step} best_l1_gram_error={best_error}")
        if stagnation > 500:
            incidence = best.copy()
            rows = rng.choice(52, size=3, replace=False)
            for row in rows:
                selected = np.flatnonzero(incidence[row])
                unselected = np.flatnonzero(1 - incidence[row])
                incidence[row, int(rng.choice(selected))] = 0
                incidence[row, int(rng.choice(unselected))] = 1
            product = incidence @ incidence.T
            stagnation = 0
    return best, best_error


def exact_repair_from_near(start: np.ndarray, gram: np.ndarray) -> np.ndarray | None:
    errors = start @ start.T - gram
    bad_rows = sorted(set(int(value) for value in np.argwhere(np.triu(errors, 1) != 0).ravel()))
    good_rows = [i for i in range(len(start)) if i not in bad_rows]
    all_patterns: list[np.ndarray] = []
    for selected in combinations(range(start.shape[1]), 4):
        pattern = np.zeros(start.shape[1], dtype=int)
        pattern[list(selected)] = 1
        all_patterns.append(pattern)
    candidates: dict[int, list[np.ndarray]] = {}
    for row in bad_rows:
        candidates[row] = [
            pattern
            for pattern in all_patterns
            if np.array_equal(start[good_rows] @ pattern, gram[good_rows, row])
        ]
        print(f"exact_repair_row={row + 1} candidates={len(candidates[row])}")
        if not candidates[row]:
            return None

    order = sorted(bad_rows, key=lambda row: len(candidates[row]))
    chosen: dict[int, np.ndarray] = {}

    def search(position: int) -> bool:
        if position == len(order):
            return True
        row = order[position]
        for pattern in candidates[row]:
            if all(int(pattern @ chosen[other]) == int(gram[row, other]) for other in chosen):
                chosen[row] = pattern
                if search(position + 1):
                    return True
                del chosen[row]
        return False

    if not search(0):
        return None
    result = start.copy()
    for row, pattern in chosen.items():
        result[row] = pattern
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("structure", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--restarts", type=int, default=5000)
    parser.add_argument("--seed", type=int, default=104)
    parser.add_argument("--near", type=Path)
    args = parser.parse_args()

    data = json.loads(args.structure.read_text(encoding="utf-8"))
    weights = np.asarray(data["weights"], dtype=int)
    gram = weights - np.eye(len(weights), dtype=int)
    eigenvalues, eigenvectors = np.linalg.eigh(gram.astype(float))
    positive = eigenvalues > 1e-8
    factor = eigenvectors[:, positive] * np.sqrt(eigenvalues[positive])
    print(f"rank={factor.shape[1]} positive_eigenvalues={eigenvalues[positive].tolist()}")
    if factor.shape[1] != 13:
        raise ValueError("Expected rank 13")

    rng = np.random.default_rng(args.seed)
    best_error = int(1e9)
    best_incidence: np.ndarray | None = None
    if args.near:
        near_data = json.loads(args.near.read_text(encoding="utf-8"))
        best_incidence = np.asarray(near_data["incidence"], dtype=int)
        best_error = int(np.abs(best_incidence @ best_incidence.T - gram).sum())
        print(f"loaded_near_error={best_error}")
    for restart in range(0 if args.near else args.restarts):
        random_matrix = rng.normal(size=(13, 13))
        q, _ = np.linalg.qr(random_matrix)
        incidence = np.zeros((52, 13), dtype=int)
        for _ in range(200):
            rotated = factor @ q
            next_incidence = np.zeros_like(incidence)
            top = np.argpartition(rotated, -4, axis=1)[:, -4:]
            next_incidence[np.arange(52)[:, None], top] = 1
            u, _, vt = np.linalg.svd(factor.T @ next_incidence, full_matrices=False)
            q = u @ vt
            if np.array_equal(next_incidence, incidence):
                break
            incidence = next_incidence
        error = int(np.abs(incidence @ incidence.T - gram).sum())
        if error < best_error:
            best_error = error
            best_incidence = incidence.copy()
            print(f"restart={restart} best_l1_gram_error={best_error}")
        if error == 0:
            break
    if best_incidence is None:
        raise RuntimeError("No candidate incidence matrix")
    if best_error:
        exact = exact_repair_from_near(best_incidence, gram)
        if exact is not None:
            best_incidence = exact
            best_error = int(np.abs(best_incidence @ best_incidence.T - gram).sum())
            print(f"exact_repair_error={best_error}")
    if best_error:
        best_incidence, best_error = repair_incidence(best_incidence, gram, rng)
    print(f"final_error={best_error}")
    print(f"feature_degrees={best_incidence.sum(axis=0).tolist()}")
    if args.output:
        data["incidence"] = best_incidence.tolist()
        args.output.write_text(json.dumps(data, indent=2), encoding="utf-8")
        print(f"wrote={args.output}")
    if best_error:
        raise SystemExit("Did not recover an exact factor")


if __name__ == "__main__":
    main()
