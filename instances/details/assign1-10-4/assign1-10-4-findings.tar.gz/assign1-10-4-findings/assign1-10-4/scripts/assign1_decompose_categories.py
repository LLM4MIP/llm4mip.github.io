#!/usr/bin/env python3
"""Decompose assign1 similarities into four categorical equivalence relations."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


N_GROUPS = 10
N_CATEGORIES = 4


class UnionFind:
    def __init__(self, size: int) -> None:
        self.parent = list(range(size))

    def find(self, value: int) -> int:
        while self.parent[value] != value:
            self.parent[value] = self.parent[self.parent[value]]
            value = self.parent[value]
        return value

    def union(self, left: int, right: int) -> None:
        left, right = self.find(left), self.find(right)
        if left != right:
            self.parent[right] = left


def balanced_overlap(count: int) -> int:
    quotient, remainder = divmod(count, N_GROUPS)
    return remainder * (quotient + 1) * quotient + (N_GROUPS - remainder) * quotient * (quotient - 1)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("structure", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seconds", type=float, default=300.0)
    parser.add_argument("--log", type=Path)
    args = parser.parse_args()

    data = json.loads(args.structure.read_text(encoding="utf-8"))
    weights: list[list[int]] = data["weights"]
    n_items = len(weights)
    similarities = [[weights[i][j] - int(i == j) for j in range(n_items)] for i in range(n_items)]

    profiles: list[list[int]] = []
    item_profile = [-1] * n_items
    for i in range(n_items):
        if item_profile[i] >= 0:
            continue
        profile = [j for j in range(n_items) if similarities[j] == similarities[i]]
        profile_id = len(profiles)
        profiles.append(profile)
        for j in profile:
            item_profile[j] = profile_id
    representatives = [profile[0] for profile in profiles]
    multiplicities = [len(profile) for profile in profiles]
    n_profiles = len(profiles)
    profile_similarity = [
        [similarities[representatives[i]][representatives[j]] for j in range(n_profiles)]
        for i in range(n_profiles)
    ]

    model = gp.Model("four_equivalence_relations")
    same = {
        (category, i, j): model.addVar(vtype=GRB.BINARY, name=f"same_{category + 1}_{i + 1}_{j + 1}")
        for category in range(N_CATEGORIES)
        for i in range(n_profiles)
        for j in range(i + 1, n_profiles)
    }

    def edge(category: int, i: int, j: int):
        if i == j:
            return 1.0
        if i > j:
            i, j = j, i
        return same[category, i, j]

    for i in range(n_profiles):
        for j in range(i + 1, n_profiles):
            model.addConstr(
                gp.quicksum(edge(category, i, j) for category in range(N_CATEGORIES))
                == profile_similarity[i][j],
                name=f"similarity_{i + 1}_{j + 1}",
            )
    for category in range(N_CATEGORIES):
        for i in range(n_profiles):
            for j in range(i + 1, n_profiles):
                for k in range(j + 1, n_profiles):
                    ij, ik, jk = edge(category, i, j), edge(category, i, k), edge(category, j, k)
                    model.addConstr(ij + jk - ik <= 1)
                    model.addConstr(ij + ik - jk <= 1)
                    model.addConstr(ik + jk - ij <= 1)

    # Remove the initial S4 category-label symmetry.
    anchor = next(
        (i, j)
        for i in range(n_profiles)
        for j in range(i + 1, n_profiles)
        if 0 < profile_similarity[i][j] < N_CATEGORIES
    )
    anchor_similarity = profile_similarity[anchor[0]][anchor[1]]
    for category in range(N_CATEGORIES):
        model.addConstr(edge(category, anchor[0], anchor[1]) == int(category < anchor_similarity))

    model.setObjective(0.0, GRB.MINIMIZE)
    model.Params.TimeLimit = args.seconds
    model.Params.Threads = 32
    model.Params.MIPFocus = 1
    model.Params.Symmetry = 2
    model.Params.Presolve = 2
    if args.log:
        model.Params.LogFile = str(args.log)
    model.optimize()
    if not model.SolCount:
        raise SystemExit(f"No decomposition found; status={model.Status}")

    profile_classes: list[list[int]] = []
    category_frequencies: list[list[int]] = []
    item_categories = [[-1] * N_CATEGORIES for _ in range(n_items)]
    for category in range(N_CATEGORIES):
        union_find = UnionFind(n_profiles)
        for i in range(n_profiles):
            for j in range(i + 1, n_profiles):
                if edge(category, i, j).X > 0.5:
                    union_find.union(i, j)
        roots = sorted({union_find.find(i) for i in range(n_profiles)})
        root_index = {root: index for index, root in enumerate(roots)}
        classes = [root_index[union_find.find(i)] for i in range(n_profiles)]
        frequencies = [0] * len(roots)
        for profile_id, count in enumerate(multiplicities):
            frequencies[classes[profile_id]] += count
        for item in range(n_items):
            item_categories[item][category] = classes[item_profile[item]]
        profile_classes.append(classes)
        category_frequencies.append(frequencies)

    reconstructed = [
        [sum(item_categories[i][category] == item_categories[j][category] for category in range(N_CATEGORIES)) for j in range(n_items)]
        for i in range(n_items)
    ]
    if reconstructed != similarities:
        raise ValueError("Categorical decomposition does not reconstruct the similarity matrix")

    per_category_bounds = [sum(balanced_overlap(count) for count in frequencies) for frequencies in category_frequencies]
    lower_bound = sum(per_category_bounds)
    print(f"profile_multiplicities={multiplicities}")
    print(f"category_frequencies={category_frequencies}")
    print(f"per_category_bounds={per_category_bounds}")
    print(f"CERTIFIED COMBINATORIAL LOWER BOUND={lower_bound}")

    incumbent_counts: list[list[list[int]]] | None = None
    if "groups" in data:
        item_group = [-1] * n_items
        for group, members in enumerate(data["groups"]):
            for item in members:
                item_group[item] = group
        incumbent_counts = []
        incumbent_overlap = 0
        for category, frequencies in enumerate(category_frequencies):
            counts = [[0] * N_GROUPS for _ in frequencies]
            for item in range(n_items):
                counts[item_categories[item][category]][item_group[item]] += 1
            incumbent_counts.append(counts)
            incumbent_overlap += sum(value * (value - 1) for row in counts for value in row)
        print(f"incumbent_overlap_from_categories={incumbent_overlap}")
        print(f"incumbent_attains_lower_bound={incumbent_overlap == lower_bound}")

    result = {
        **data,
        "profiles": profiles,
        "profile_multiplicities": multiplicities,
        "item_categories": item_categories,
        "category_frequencies": category_frequencies,
        "per_category_bounds": per_category_bounds,
        "combinatorial_lower_bound": lower_bound,
        "incumbent_category_group_counts": incumbent_counts,
    }
    args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(f"wrote={args.output}")


if __name__ == "__main__":
    main()
