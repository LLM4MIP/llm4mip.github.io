#!/usr/bin/env python3
"""Exact per-row load-balancing lower bounds for assign1-10-4."""

from __future__ import annotations

import argparse
import json
import math
from collections import Counter
from functools import lru_cache
from itertools import product
from pathlib import Path


@lru_cache(maxsize=None)
def patterns(size: int, load_limit: int) -> tuple[tuple[int, ...], ...]:
    result: list[tuple[int, ...]] = []
    for counts in product(range(size + 1), repeat=6):
        if sum(counts) == size and sum(weight * counts[weight] for weight in range(6)) <= load_limit:
            result.append(counts)
    return tuple(result)


def can_partition(weight_counts: tuple[int, ...], load_limit: int) -> bool:
    states = {tuple(0 for _ in range(6))}
    for size, multiplicity in ((6, 2), (5, 8)):
        choices = patterns(size, load_limit)
        for _ in range(multiplicity):
            next_states: set[tuple[int, ...]] = set()
            for used in states:
                for choice in choices:
                    candidate = tuple(used[w] + choice[w] for w in range(6))
                    if all(candidate[w] <= weight_counts[w] for w in range(6)):
                        next_states.add(candidate)
            states = next_states
            if not states:
                return False
    return weight_counts in states


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("structure", type=Path)
    args = parser.parse_args()
    data = json.loads(args.structure.read_text(encoding="utf-8"))
    weights: list[list[int]] = data["weights"]
    bounds: list[int] = []
    for i, row in enumerate(weights):
        counts = tuple(Counter(row).get(weight, 0) for weight in range(6))
        load = math.ceil(sum(row) / 10)
        while not can_partition(counts, load):
            load += 1
        y_bound = load - 5
        bounds.append(y_bound)
        print(f"item={i + 1:02d} counts={counts} min_max_load={load} y_bound={y_bound}")
    print(f"bounds={bounds}")
    print(f"sum={sum(bounds)} distribution={Counter(bounds)}")


if __name__ == "__main__":
    main()
