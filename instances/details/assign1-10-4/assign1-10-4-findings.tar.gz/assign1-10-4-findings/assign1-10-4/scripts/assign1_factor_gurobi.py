#!/usr/bin/env python3
"""Recover an exact binary factor W - I = A A^T with Gurobi."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("structure", type=Path)
    parser.add_argument("--near", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seconds", type=float, default=300.0)
    parser.add_argument("--log", type=Path)
    args = parser.parse_args()

    data = json.loads(args.structure.read_text(encoding="utf-8"))
    weights: list[list[int]] = data["weights"]
    n, rank = len(weights), 13
    gram = [[weights[i][j] - int(i == j) for j in range(n)] for i in range(n)]

    near: list[list[int]] | None = None
    if args.near:
        near_data = json.loads(args.near.read_text(encoding="utf-8"))
        raw_near: list[list[int]] = near_data["incidence"]
        selected = [f for f in range(rank) if raw_near[0][f]]
        unselected = [f for f in range(rank) if not raw_near[0][f]]
        permutation = selected + unselected
        near = [[row[f] for f in permutation] for row in raw_near]

    model = gp.Model("binary_gram_factor")
    a = model.addVars(n, rank, vtype=GRB.BINARY, name="a")
    for i in range(n):
        model.addConstr(gp.quicksum(a[i, f] for f in range(rank)) == 4, name=f"row_sum_{i + 1}")
    for f in range(rank):
        model.addConstr(a[0, f] == int(f < 4), name=f"fix_first_row_{f + 1}")

    for i in range(n):
        for j in range(i + 1, n):
            products = []
            for f in range(rank):
                product = model.addVar(lb=0.0, ub=1.0, name=f"p_{i + 1}_{j + 1}_{f + 1}")
                model.addConstr(product <= a[i, f])
                model.addConstr(product <= a[j, f])
                model.addConstr(product >= a[i, f] + a[j, f] - 1)
                products.append(product)
            model.addConstr(gp.quicksum(products) == gram[i][j], name=f"dot_{i + 1}_{j + 1}")

    if near:
        for i in range(n):
            for f in range(rank):
                a[i, f].Start = near[i][f]
        model.setObjective(
            gp.quicksum((1 - a[i, f]) if near[i][f] else a[i, f] for i in range(n) for f in range(rank)),
            GRB.MINIMIZE,
        )
    else:
        model.setObjective(0.0, GRB.MINIMIZE)

    model.Params.TimeLimit = args.seconds
    model.Params.Threads = 32
    model.Params.MIPFocus = 1
    model.Params.Symmetry = 2
    model.Params.Presolve = 2
    if args.log:
        model.Params.LogFile = str(args.log)
    model.optimize()
    if not model.SolCount:
        raise SystemExit(f"No factor found; status={model.Status}")
    incidence = [[int(a[i, f].X > 0.5) for f in range(rank)] for i in range(n)]
    error = sum(
        abs(sum(incidence[i][f] * incidence[j][f] for f in range(rank)) - gram[i][j])
        for i in range(n)
        for j in range(n)
    )
    print(f"factor_objective={model.ObjVal} gram_error={error}")
    print(f"feature_degrees={[sum(incidence[i][f] for i in range(n)) for f in range(rank)]}")
    data["incidence"] = incidence
    args.output.write_text(json.dumps(data, indent=2), encoding="utf-8")
    print(f"wrote={args.output}")


if __name__ == "__main__":
    main()
