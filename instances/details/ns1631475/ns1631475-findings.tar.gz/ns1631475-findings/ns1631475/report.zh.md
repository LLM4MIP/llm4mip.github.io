#  ns1631475 Research records

##  The final conclusion

The globally optimal objective value of `ns1631475` is **11,100**.
Solver runs the branch tree, but instead comes from the original MPS structural verification + ring ranking and lower bound + original solution audit.

public solution gives the primal bound 11,100. The script directly checks the interface and integrality of the 22,696 variable and 24,496.
Article original constraint, recalculated objective to 11,100, maximum row violation to `7.958e-13`.

##  Structure recovered from the original matrix

The original model corresponds to the Hamilton ring of the 15 node:

-  30 Article assignment constraint ensures that each node has exactly one inbound and one outbound arc;
-  The 210 line equation corresponds to the direction of the arc to the direction of the ring;
-  105 is a commodity that covers the entire disordered point pair of 15 nodes correctly;
-  The 1,575 line flow balance and the 22,050 line link constraint force each commodity to be routed along a loop;
-  The 210 bar load equation calculates the demand load on each side;
-  The objective variable controls all the loads of the 210.

62 is a commodity with a positive demand and a depreciation of 450, 600, 750, 900, 1,050.
All are multiples of 150, and the total demand is 47,400.

## exact lower bound

A given arbitrary ring arrangement and arbitrary continuous node interval, the need to cross that interval divided by only two ends of the interval.
Side. If all side loads do not exceed 10,950, the maximum requirement for any arbitrary continuous interval is 21,900.

`prove_cyclic_cutwidth.py` fixed node 0 Remove rotational symmetry, exact enumeration the rest of the array; once current
A prefix can safely be pruned if one of its suffix interval cuts exceeds 21,900. The program visits 218,831 prefixes and prunes
1,262,956 extensions establish that no cycle has all interval cuts at most 21,900. Furthermore, all cut values are
The multiples of 150, so that each ring has at least one interval to reach 22,050. The two sides add up at least 22,050.
The unilateral load is also a multiple of the 150, so at least one side load is not less than the 11,100.

So the lower bound of the original problem is 11,100; combined with the public feasible solution, the result is `OPT = 11,100`.

## Evidence Boundary

Eventually, the script re-verifies the constraints, public solutions, and complete DFS for the original MPS. It calls `gurobipy`.
Read the matrix, but do not call for optimization. Independent cutwidth enumeration is only calculated using Python integer.
It records structural counts, feasibility, errors, poorly elevated node numbers and upper lower bound.
The numerical lower bound of 4,941 is not involved in the optimality conclusion.
