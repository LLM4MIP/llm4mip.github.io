#!/usr/bin/env python3
"""Evaluate the recovered 15-node ring and commodity flows in a .sol file."""

import argparse
import gzip
import json
from pathlib import Path


def read_solution(path: Path):
    opener = gzip.open if path.suffix == ".gz" else open
    values = {}
    with opener(path, "rt", encoding="utf-8") as handle:
        for line in handle:
            fields = line.split()
            if len(fields) == 2 and fields[0].startswith("C"):
                values[fields[0]] = float(fields[1])
    return values


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("structure", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    structure = json.loads(args.structure.read_text(encoding="utf-8"))
    values = read_solution(args.solution)
    arc_by_name = {
        name: tuple(endpoints)
        for name, endpoints in structure["base_arc_by_variable"].items()
    }
    base_names = list(arc_by_name)
    selected_arcs = [arc_by_name[name] for name in base_names if values.get(name, 0) > 0.5]
    successor = {i: j for i, j in selected_arcs}
    assert len(successor) == 15
    tour = [0]
    while successor[tour[-1]] != tour[0]:
        tour.append(successor[tour[-1]])
        assert len(tour) <= 15
    assert len(tour) == 15
    position = {node: index for index, node in enumerate(tour)}

    commodities = structure["flow_commodities"]
    shortest_total = 0
    shortest_hop_histogram = {}
    commodity_records = []
    actual_edge_load = {tuple(sorted((tour[i], tour[(i + 1) % 15]))): 0 for i in range(15)}
    for commodity in commodities:
        source, target = commodity["endpoints_zero_based"]
        demand = int(commodity["demand"])
        separation = abs(position[source] - position[target])
        shortest_hops = min(separation, 15 - separation)
        shortest_total += demand * shortest_hops
        shortest_hop_histogram[str(shortest_hops)] = shortest_hop_histogram.get(str(shortest_hops), 0) + 1

        layer = commodity["binary_layer"]
        layer_offset = layer * 210
        used_arcs = []
        for within_position, base_name in enumerate(base_names):
            layer_name = f"C{16 + layer_offset + within_position:04d}"
            if values.get(layer_name, 0) > 0.5:
                arc = arc_by_name[base_name]
                used_arcs.append(arc)
                edge = tuple(sorted(arc))
                if demand and edge in actual_edge_load:
                    actual_edge_load[edge] += demand
        commodity_records.append(
            {
                "binary_layer": layer,
                "endpoints_zero_based": [source, target],
                "demand": demand,
                "shortest_ring_hops": shortest_hops,
                "selected_flow_arcs": used_arcs,
            }
        )

    load_values = [int(round(values.get(f"C{index:04d}", 0))) for index in range(22487, 22697)]
    report = {
        "tour_zero_based": tour,
        "selected_directed_arcs": selected_arcs,
        "positive_demand_commodities": sum(c["demand"] > 0 for c in commodities),
        "total_demand": sum(c["demand"] for c in commodities),
        "shortest_path_weighted_hops_on_public_tour": shortest_total,
        "shortest_path_average_load_lower_bound_on_public_tour": shortest_total / 15,
        "shortest_hop_histogram_all_commodities": shortest_hop_histogram,
        "actual_positive_edge_loads_from_public_flows": {
            str(edge): load for edge, load in actual_edge_load.items()
        },
        "actual_max_edge_load_from_public_flows": max(actual_edge_load.values()),
        "reported_load_variable_min": min(load_values),
        "reported_load_variable_max": max(load_values),
        "reported_objective": values.get("C22486"),
        "commodities": commodity_records,
    }
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in report.items() if key != "commodities"}, indent=2))


if __name__ == "__main__":
    main()
