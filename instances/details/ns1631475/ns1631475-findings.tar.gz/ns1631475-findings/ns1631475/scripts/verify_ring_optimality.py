#!/usr/bin/env python3
"""Check the original matrix, incumbent, and cyclic-cutwidth proof for ns1631475."""

import argparse
from collections import defaultdict
import gzip
import json
from pathlib import Path

import gurobipy as gp


def read_solution(path):
    opener = gzip.open if path.suffix == ".gz" else open
    values = {}
    with opener(path, "rt", encoding="utf-8") as handle:
        for line in handle:
            fields = line.split()
            if len(fields) == 2 and fields[0].startswith("C"):
                values[fields[0]] = float(fields[1])
    return values


def row_dict(model, constraint):
    row = model.getRow(constraint)
    return {row.getVar(k).VarName: row.getCoeff(k) for k in range(row.size())}


def exact_cutwidth_infeasibility(commodities, n, threshold):
    weights = [[0] * n for _ in range(n)]
    for commodity in commodities:
        i, j = commodity["endpoints_zero_based"]
        demand = int(commodity["demand"])
        weights[i][j] = weights[j][i] = demand
    full = (1 << n) - 1
    cut = [0] * (full + 1)
    for mask in range(1, full + 1):
        bit = mask & -mask
        v = bit.bit_length() - 1
        old = mask ^ bit
        cut[mask] = cut[old] + sum(
            -weights[v][u] if old & (1 << u) else weights[v][u]
            for u in range(n)
            if u != v
        )
    assert all(cut[mask] == cut[full ^ mask] for mask in range(full + 1))
    allowed = [value <= threshold for value in cut]
    order = sorted(range(1, n), key=lambda v: (-sum(weights[v]), v))
    path = [0]
    visited = 1
    pruned = 0

    def search(mask):
        nonlocal visited, pruned
        if mask == full:
            return path.copy()
        for v in order:
            bit = 1 << v
            if mask & bit:
                continue
            suffix = bit
            good = allowed[suffix]
            if good:
                for u in reversed(path):
                    suffix |= 1 << u
                    if suffix != full and not allowed[suffix]:
                        good = False
                        break
            if not good:
                pruned += 1
                continue
            path.append(v)
            visited += 1
            witness = search(mask | bit)
            if witness is not None:
                return witness
            path.pop()
        return None

    witness = search(1)
    return {
        "threshold": threshold,
        "feasible_order_exists": witness is not None,
        "witness": witness,
        "visited_prefixes": visited,
        "pruned_extensions": pruned,
        "forbidden_subsets": sum(cut[mask] > threshold for mask in range(1, full)),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("structure", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    structure = json.loads(args.structure.read_text(encoding="utf-8"))
    model = gp.read(str(args.model))
    variables = model.getVars()
    constraints = model.getConstrs()
    by_name = {variable.VarName: variable for variable in variables}
    binaries = [
        variable
        for variable in variables
        if variable.VType != gp.GRB.CONTINUOUS and variable.LB == 0 and variable.UB == 1
    ]
    assert len(binaries) == 107 * 210
    layers = [binaries[offset : offset + 210] for offset in range(0, len(binaries), 210)]
    layer_of = {}
    position_of = {}
    for layer_index, layer in enumerate(layers):
        for position, variable in enumerate(layer):
            layer_of[variable.VarName] = layer_index
            position_of[variable.VarName] = position

    arc_by_name = {
        name: tuple(endpoints)
        for name, endpoints in structure["base_arc_by_variable"].items()
    }
    base_names = [variable.VarName for variable in layers[0]]
    assert set(base_names) == set(arc_by_name)
    arc_position = {arc_by_name[name]: position for position, name in enumerate(base_names)}
    assert len(arc_position) == 210
    reciprocal = [arc_position[(j, i)] for i, j in map(arc_by_name.get, base_names)]

    # The 30 unit assignment rows are exactly one outgoing and one incoming
    # equation for each node.
    assignment_supports = []
    for constraint in constraints[1:31]:
        terms = row_dict(model, constraint)
        assert constraint.Sense == "=" and constraint.RHS == 1
        assert len(terms) == 14 and set(terms.values()) == {1}
        assignment_supports.append(frozenset(terms))
    expected_supports = []
    for node in range(15):
        expected_supports.append(frozenset(name for name, (i, _) in arc_by_name.items() if i == node))
        expected_supports.append(frozenset(name for name, (_, j) in arc_by_name.items() if j == node))
    assert sorted(map(sorted, assignment_supports)) == sorted(map(sorted, expected_supports))

    # Each directed y copy equals x_ij + x_ji.
    for position, constraint in enumerate(constraints[241:451]):
        expected = {
            base_names[position]: -1,
            base_names[reciprocal[position]]: -1,
            layers[1][position].VarName: 1,
        }
        assert constraint.Sense == "=" and constraint.RHS == 0
        assert row_dict(model, constraint) == expected

    commodities = structure["flow_commodities"]
    assert len(commodities) == 105
    assert {
        tuple(sorted(c["endpoints_zero_based"])) for c in commodities
    } == {(i, j) for i in range(15) for j in range(i + 1, 15)}

    # Recover and check all 15 conservation equations for every commodity.
    balance_rows = defaultdict(list)
    for constraint in constraints[451:2026]:
        terms = row_dict(model, constraint)
        term_layers = {layer_of[name] for name in terms}
        assert len(term_layers) == 1
        layer_index = term_layers.pop()
        assert 2 <= layer_index <= 106
        assert len(terms) == 28 and set(map(abs, terms.values())) == {1}
        incident_nodes = set()
        for name in terms:
            i, j = arc_by_name[base_names[position_of[name]]]
            incident_nodes.update((i, j))
        # Intersection, rather than union, identifies the common balance node.
        common = set(range(15))
        for name in terms:
            common.intersection_update(arc_by_name[base_names[position_of[name]]])
        assert len(common) == 1
        node = common.pop()
        orientation = set()
        for name, coefficient in terms.items():
            i, j = arc_by_name[base_names[position_of[name]]]
            orientation.add((coefficient, i == node, j == node))
        assert orientation in (
            {(1, True, False), (-1, False, True)},
            {(-1, True, False), (1, False, True)},
        )
        balance_rows[layer_index].append((node, int(constraint.RHS)))
    for commodity in commodities:
        layer_index = commodity["binary_layer"]
        rows = balance_rows[layer_index]
        assert len(rows) == 15 and {node for node, _ in rows} == set(range(15))
        nonzero_rhs_nodes = {node for node, rhs in rows if rhs != 0}
        assert nonzero_rhs_nodes == set(commodity["endpoints_zero_based"])
        assert sorted(rhs for _, rhs in rows) == [-1] + [0] * 13 + [1]

    # There is exactly one f^k_ij <= y_ij row for every commodity and arc.
    link_pairs = set()
    for constraint in constraints[2026:24076]:
        terms = row_dict(model, constraint)
        assert constraint.Sense == ">" and constraint.RHS == 0 and len(terms) == 2
        y = next(name for name, coefficient in terms.items() if coefficient == 1)
        flow = next(name for name, coefficient in terms.items() if coefficient == -1)
        assert layer_of[y] == 1 and 2 <= layer_of[flow] <= 106
        assert position_of[y] == position_of[flow]
        link_pairs.add((layer_of[flow], position_of[flow]))
    assert link_pairs == {(layer, position) for layer in range(2, 107) for position in range(210)}

    # Every load equality counts both orientations of the same undirected edge
    # for every positive-demand commodity, with the exact demand coefficient.
    load_names = [f"C{index:04d}" for index in range(22487, 22697)]
    for position, constraint in enumerate(constraints[24076:24286]):
        expected = {load_names[position]: 1}
        for commodity in commodities:
            demand = int(commodity["demand"])
            if demand:
                layer_index = commodity["binary_layer"]
                expected[layers[layer_index][position].VarName] = -demand
                expected[layers[layer_index][reciprocal[position]].VarName] = -demand
        assert constraint.Sense == "=" and constraint.RHS == 0
        assert row_dict(model, constraint) == expected

    z_name = "C22486"
    assert by_name[z_name].VType != gp.GRB.CONTINUOUS and by_name[z_name].Obj == 1
    for position, constraint in enumerate(constraints[24286:24496]):
        assert constraint.Sense == ">" and constraint.RHS == 0
        assert row_dict(model, constraint) == {z_name: 1, load_names[position]: -1}

    # Evaluate the public incumbent directly against every original row.
    values = read_solution(args.solution)
    assert set(values) == set(by_name)
    max_bound_violation = 0.0
    max_integrality_violation = 0.0
    for variable in variables:
        value = values[variable.VarName]
        max_bound_violation = max(max_bound_violation, variable.LB - value, value - variable.UB)
        if variable.VType != gp.GRB.CONTINUOUS:
            max_integrality_violation = max(max_integrality_violation, abs(value - round(value)))
    max_row_violation = 0.0
    for constraint in constraints:
        terms = row_dict(model, constraint)
        lhs = sum(coefficient * values[name] for name, coefficient in terms.items())
        if constraint.Sense == "=":
            violation = abs(lhs - constraint.RHS)
        elif constraint.Sense == "<":
            violation = max(0.0, lhs - constraint.RHS)
        else:
            violation = max(0.0, constraint.RHS - lhs)
        max_row_violation = max(max_row_violation, violation)
    objective = sum(variable.Obj * values[variable.VarName] for variable in variables)
    assert max_bound_violation <= 1e-7
    assert max_integrality_violation <= 1e-7
    assert max_row_violation <= 1e-6
    assert objective == 11100

    # All nonzero demands are multiples of 150. Exhaustion at 21,900 proves
    # that every ring has an interval cut of at least 22,050. Its two boundary
    # loads cannot both be at most 10,950, hence the integer optimum is >=11,100.
    assert {int(c["demand"]) % 150 for c in commodities} == {0}
    cutwidth = exact_cutwidth_infeasibility(commodities, 15, 21900)
    assert not cutwidth["feasible_order_exists"]

    report = {
        "model_matrix_structure_verified": True,
        "assignment_rows_verified": 30,
        "tour_edge_equalities_verified": 210,
        "commodity_flow_balance_rows_verified": 1575,
        "flow_edge_link_rows_verified": 22050,
        "load_equalities_verified": 210,
        "objective_domination_rows_verified": 210,
        "public_solution": {
            "objective": objective,
            "max_bound_violation": max_bound_violation,
            "max_integrality_violation": max_integrality_violation,
            "max_row_violation": max_row_violation,
        },
        "cyclic_cutwidth_infeasibility": cutwidth,
        "strict_lower_bound": 11100,
        "strict_upper_bound": 11100,
        "optimal_objective": 11100,
        "proof": (
            "The assignment/y/flow rows force a Hamiltonian ring carrying all-pairs "
            "unsplittable flows. Exhaustive cyclic-cutwidth search proves every ring "
            "has an interval demand cut >=22050. That interval has two boundary ring "
            "edges. Load coefficients and binary flows make each edge load a multiple "
            "of 150, so both loads <=10950 would sum to at most21900, a contradiction. "
            "Therefore z>=11100; the checked public solution attains11100."
        ),
    }
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
