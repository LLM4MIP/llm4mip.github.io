#!/usr/bin/env python3
"""Exact DFS for a weighted cyclic-cutwidth lower bound on the recovered ring.

For a cyclic order, every contiguous interval has two boundary edges.  All
traffic crossing that interval must use one of those edges, so an edge-load
limit L implies cut(interval) <= 2L.  The DFS fixes node 0 to remove rotational
symmetry and exhausts every remaining order, pruning a prefix as soon as one
of its suffix intervals violates the requested cut threshold.
"""

import argparse
import json
import time
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("structure", type=Path)
    parser.add_argument("--threshold", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    structure = json.loads(args.structure.read_text(encoding="utf-8"))
    n = structure["nodes"]
    assert n == 15
    weights = [[0] * n for _ in range(n)]
    for commodity in structure["flow_commodities"]:
        i, j = commodity["endpoints_zero_based"]
        demand = int(commodity["demand"])
        weights[i][j] = demand
        weights[j][i] = demand

    size = 1 << n
    full = size - 1
    cut = [0] * size
    # Exact integer recurrence: adding v changes its contribution from the
    # old-set side to the new-set side.
    for mask in range(1, size):
        bit = mask & -mask
        v = bit.bit_length() - 1
        old = mask ^ bit
        delta = 0
        for u in range(n):
            if u == v:
                continue
            delta += -weights[v][u] if old & (1 << u) else weights[v][u]
        cut[mask] = cut[old] + delta
    assert all(cut[mask] == cut[full ^ mask] for mask in range(size))

    allowed = [value <= args.threshold for value in cut]
    degree = [sum(row) for row in weights]
    candidate_order = sorted(range(1, n), key=lambda v: (-degree[v], v))
    path = [0]
    nodes_visited = 1
    pruned_by_forbidden_suffix = 0
    witness = None
    started = time.perf_counter()

    def search(mask):
        nonlocal nodes_visited, pruned_by_forbidden_suffix, witness
        if mask == full:
            witness = path.copy()
            return True
        for v in candidate_order:
            bit = 1 << v
            if mask & bit:
                continue
            suffix = bit
            feasible = allowed[suffix]
            if feasible:
                for u in reversed(path):
                    suffix |= 1 << u
                    if suffix != full and not allowed[suffix]:
                        feasible = False
                        break
            if not feasible:
                pruned_by_forbidden_suffix += 1
                continue
            path.append(v)
            nodes_visited += 1
            if search(mask | bit):
                return True
            path.pop()
        return False

    feasible = search(1)
    elapsed = time.perf_counter() - started
    report = {
        "algorithm": "exact depth-first enumeration with rotation fixed at node 0",
        "nodes": n,
        "threshold": args.threshold,
        "feasible_cyclic_order_exists": feasible,
        "witness_order_zero_based": witness,
        "search_nodes_visited": nodes_visited,
        "branches_pruned_by_forbidden_suffix": pruned_by_forbidden_suffix,
        "forbidden_nontrivial_subsets": sum(
            cut[mask] > args.threshold for mask in range(1, full)
        ),
        "elapsed_seconds": elapsed,
        "demand_total": sum(sum(row) for row in weights) // 2,
        "cut_weight_scale_gcd": 150,
        "proof_note": (
            "Every cyclic order can be rotated to begin with node 0. Every "
            "non-wrapping interval becomes a suffix when its last node is "
            "appended; wrapping intervals have non-wrapping complements with "
            "the same cut. Therefore an infeasible result exhausts all cycles."
        ),
    }
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
