#!/usr/bin/env python3
"""Standard-library checker for the compact interval-order certificate."""

from __future__ import annotations

import argparse
import json
from fractions import Fraction
from pathlib import Path


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("certificate", type=Path)
    args = ap.parse_args()
    data = json.loads(args.certificate.read_text(encoding="utf-8"))
    groups = data["groups"]
    n = len(groups)
    assert [g["id"] for g in groups] == list(range(n))
    intervals = [(Fraction(g["U"]), Fraction(g["L"])) for g in groups]
    assert all(u <= l for u, l in intervals)
    members = [item for g in groups for item in g["members"]]
    assert len(members) == data["forced_items"]
    assert len(set(members)) == len(members)
    assert all(len(g["members"]) == 1 or g["U"] == g["L"] for g in groups)

    arcs = {
        (a, b)
        for a, (_ua, la) in enumerate(intervals)
        for b, (ub, _lb) in enumerate(intervals)
        if a != b and la <= ub
    }
    assert not any((b, a) in arcs for a, b in arcs)

    matching = [tuple(edge) for edge in data["matching"]]
    assert len(matching) == data["matching_size"]
    assert len({a for a, _ in matching}) == len(matching)
    assert len({b for _, b in matching}) == len(matching)
    assert all(edge in arcs for edge in matching)

    cover_left = set(data["minimum_vertex_cover"]["left"])
    cover_right = set(data["minimum_vertex_cover"]["right"])
    assert data["cover_size"] == len(cover_left) + len(cover_right)
    assert data["cover_size"] == data["matching_size"]
    uncovered = [(a, b) for a, b in arcs if a not in cover_left and b not in cover_right]
    assert not uncovered
    assert data["uncovered_compatibility_arcs"] == 0

    paths = n - len(matching)
    slot_counts = {
        int(machine): int(count)
        for machine, count in data["endpoint_slot_counts"].items()
    }
    separator_cap = sum(slot_counts.values()) - data["forced_items"]
    assert separator_cap == data["separator_cap"] == 1
    assert data["occupied_segment_cap"] == len(slot_counts) + separator_cap
    bad = paths - data["occupied_segment_cap"]
    endpoint_sum = Fraction(data["fixed_base_cost"]) + Fraction(data["difference_cost"]) * bad
    assert paths == data["minimum_good_paths"]
    assert bad == data["bad_transition_lower_bound"]
    assert endpoint_sum == Fraction(data["endpoint_sum_lower_bound"])
    half_ceiling = (endpoint_sum.numerator + 2 * endpoint_sum.denominator - 1) // (2 * endpoint_sum.denominator)
    lattice = int(data["endpoint_load_lattice"])
    lattice_bound = ((half_ceiling + lattice - 1) // lattice) * lattice
    assert lattice_bound == Fraction(data["objective_lower_bound"])
    print("certificate_valid=1")
    print(f"groups={n} compatibility_arcs={len(arcs)} matching={len(matching)}")
    print(
        f"forced_items={len(members)} paths={paths} "
        f"segments={data['occupied_segment_cap']} bad_transitions={bad}"
    )
    print(
        f"endpoint_sum_lower_bound={endpoint_sum} "
        f"lattice_max_load_lower_bound={lattice_bound}"
    )


if __name__ == "__main__":
    main()
