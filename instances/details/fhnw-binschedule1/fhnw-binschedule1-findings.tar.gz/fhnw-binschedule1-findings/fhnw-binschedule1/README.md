# `fhnw-binschedule1`

## Result

**Optimal objective: 55,158.** This improves the public MIPLIB incumbent
55,198 by 40 and closes the instance.

The 1.14-million-variable MIP was not closed by a parameter sweep. Its two
endpoint chains are projected to a 773-item interval-order problem. A maximum
matching/minimum vertex-cover certificate proves that the endpoint loads sum
to at least 110,316, hence their maximum is at least 55,158. A compact colored
matching oracle then constructs an original-model solution whose six loads are

```text
55158, 17609, 23551, 23394, 17236, 55158
```

The lifted solution has zero row, bound, and integrality violations over all
772,872 original constraints. Therefore the lower and upper bounds coincide.

## Main evidence

- [`certificates/interval-order-certificate.json`](certificates/interval-order-certificate.json):
  738 contracted interval groups, a matching of size 134, and a matching
  minimum vertex cover of size 134.
- [`solutions/optimal-55158.sol`](solutions/optimal-55158.sol): the lifted
  sparse solution for the original MPS.
- [`scripts/derive_interval_core.py`](scripts/derive_interval_core.py): exact
  structural extraction, lower-bound derivation, compact decision-model
  generation, solution lifting, and full-row validation.
- [`scripts/verify_interval_certificate.py`](scripts/verify_interval_certificate.py):
  standard-library verification of all compatibility arcs, matching edges,
  vertex-cover edges, and lower-bound arithmetic.
- [`logs/full-validation.log`](logs/full-validation.log): the decisive
  original-model validation transcript.
- [`logs/copt-target-55158.log`](logs/copt-target-55158.log): the short
  CPU-only compact-witness run. COPT is not used for the lower bound.

See the [full structural report](reports/structural-investigation.md) for the
proof and the precise boundary between combinatorial reasoning and solver use.

## Provenance

- Compressed MPS SHA-256:
  `57544e22dcef850a82e7a0faf1e1a49e76c1dc6258ad332f9acab64954a35057`
- Previous public solution SHA-256:
  `be35678885b322af0fbc81da09d9291462cbc0e6f8a56efd52fc250ddcc8605c`
- New solution SHA-256:
  `08535f23342f5db0b28ed939347a1caba3a564ec556cd5fcdc53d305d27f969f`
- Certificate SHA-256:
  `8cfbae64cdee7a7800577c8eec3c8db76e3e61c483a3dd8a0577d13b73b3abf8`
- [Official MIPLIB page](https://miplib.zib.de/instance_details_fhnw-binschedule1.html)

## Reproduction

Check the compact lower-bound certificate without a solver:

```powershell
python instances/fhnw-binschedule1/scripts/verify_interval_certificate.py `
  instances/fhnw-binschedule1/certificates/interval-order-certificate.json
```

With `gurobipy` available, regenerate the certificate and export the compact
target model without optimizing it:

```powershell
python instances/fhnw-binschedule1/scripts/derive_interval_core.py `
  instances/fhnw-binschedule1/input/fhnw-binschedule1.mps.gz `
  instances/fhnw-binschedule1/solutions/public-55198.sol.gz `
  --certificate instances/fhnw-binschedule1/certificates/interval-order-certificate.json `
  --solution-out candidate-55164.sol `
  --decision-target 55158 `
  --decision-lp decision-55158.lp `
  --decision-export-only
```

Solve the exported zero-objective feasibility model with any exact MILP
backend, save its named-variable solution, and rerun with
`--decision-solution`. The archived COPT run used 8 CPU threads and finished at
the root in 5.00 seconds. The generated 6.5 MB LP and its regenerable compact
solution are intentionally omitted from Git.

