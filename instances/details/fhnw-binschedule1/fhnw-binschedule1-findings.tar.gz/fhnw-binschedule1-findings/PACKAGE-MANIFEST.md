# Package manifest: fhnw-binschedule1

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 9
Excluded source files: 1

## Included files

- `README.md`
- `certificates/interval-order-certificate.json`
- `logs/copt-target-55158.log`
- `logs/full-validation.log`
- `reports/structural-investigation.md`
- `scripts/derive_interval_core.py`
- `scripts/verify_interval_certificate.py`
- `solutions/optimal-55158.sol`
- `solutions/public-55198.sol.gz`

## Excluded files

- `input/fhnw-binschedule1.mps.gz (40750189 bytes; raw benchmark input; sha256 57544e22dcef850a82e7a0faf1e1a49e76c1dc6258ad332f9acab64954a35057)`
