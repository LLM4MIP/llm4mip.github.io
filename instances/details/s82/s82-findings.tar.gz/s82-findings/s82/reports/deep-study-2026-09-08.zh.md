#  `s82` in-depth research report ((2026 -09 -08))

##  Concluding Summary

This round has not been given a strictly feasible solution to the current public value of `-33.7970576238223` by MIPLIB, nor is there a proof of the complete objective function being globally optimal. Therefore, `s82` still cannot be labelled `optimal`.

However, this round obtained an independently verifiable **global structure conclusion**: the higher-level `A8_j` order variable can only select the 36 at most, while the public solution has selected the 36. In other words, the public solution has reached the global maximum value on this high-level indicator of the number of orders received. This conclusion is not based on the long-term unimproved, but comes directly from the 7 proof constraint in the original MPS.

It requires strict distinction:

-  **has global proof**: `sum_j A8_j <= 36`, and public solution reaches 36.
-  **has been conditioned exact proof**: fixed The other three production line paths and public high-level selection, line 4's public alignment objective strict optimal, `MIPGap=0`.
-  **has not yet been proven**: the complete objective `-33.7970576238223` is globally optimal.
-  **has not been updated**: strict primal improvement.

##  The actual study time

-  Traceable starting point: `2026-09-08 00:11:22 +08:00` (first directory and input download records)
-  Summary of the report: `2026-09-08 01:04:00 +08:00`
- Continuous wall-clock exploration: `52 min 38 s`
-  The cumulative special calculations of solve, IIS, structural scanning and original solution audit are about 27 minutes; the rest is spent on official file downloads, document verification, model semantics recovery, script development and proof verification.

The time of the wall clock exceeds the 40 minutes requested by the user; it did not stop after the early failure, but instead switched from pre-processing the entire model to instance-specific production line decomposition and two-line proof.

##  1. official background check

The official MIPLIB page describes `s82` as 82's job, 4's wine sorting problem, submitted by Daniel Espinoza, from MIPLIB 2010 submissions. As of the time of verification, the official status is `open`, public primal is `-33.7970576238223`.

The official page explicitly shows `No bibliographic information available`. Therefore, this study does not pretend that the later published wine filling layout paper is the original paper of `s82`. The relevant paper is only used to consider the context in which solution orders are allocated to multiple production lines.

The current public solution was submitted by Peng Lin and Shaowei Cai on 2024-10-02, with PartiMIP as the description. In the official PartiMIP repository at commit `044cee49a0e98914d73ef855f3d5ad69e5dbfa00`, `Record/s82.sol.gz` has exactly the same SHA-256 as the MIPLIB download:

`d7c5e7476436b69d008400975c3e45933a51f97bdb1e051edd864216ff6cfc59`

For the full text, see [`sources.md` ](SOURCES.md)].

##  2. Gurobi read the original structure

Use the Gurobi 13.0.2 to read the official compression MPS directly:

|  Metric |  Count |
|---|---:|
|  constraint |  87,878  |
|  Variables |  1,690,631  |
| Non-zero coefficients |  7,022,608  |
| 0 1 field integer variable |  1,690,577  |
|  continuous variables |  54  |
|  Equality |  87,605  |
|  `<=` constraint |  137  |
|  `>=` constraint |  136  |

Gurobi displays the 0 domain variable 1 in the MPS as `integer (0 binary)`, but the lower bound of all these integer variables is `[0,1]`; MIPLIB official statistics also classify them as binary.

The variable name reveals a large-scale path/time deployment model:

-  `A8_0,...,A8_41`: 42 is a high-level load/activation variable;
-  `Atp_*`: 55,388 is a path node or stop transfer variable in which 51,520 is a type of `tr`; 3,868 is a type of `tp`;
-  `Atr_*`: 1,028,509 is a path arc in which 973,823 is a type of `tr`, 54,686 is a type of `tp`;
-  `A*_L*O*T*D*` and so on: 606,590 is a finite particle sequence/order state variable;
-  `variable_volumen1,...,54`: 54 is a continuous volume variable.

The path variables use production-line indices `0,1,2,4`, representing 4 lines, consistent with the official description of four processing machines.

##  3. public solution's original MPS independent audit

The variable explanation for `.sol` that is not listed is 0 and is independently recalculated using the original MPS scarcity matrix:

-  Declare objective: `-33.7970576238223`
-  Recalculating objective: `-33.797057623822184`
-  Maximum variable bound violation: `0`
- Maximum integrality violation: `0`
-  Maximum row violation: `5.820766091346741e-11`
-  row violation greater than the number of `1e-9`: `0`

Therefore, the public solution on the original MPS is a strictly credible numerical feasible solution.

The main components of the public objective are:

| Template of variable | Non-zero numbers | Objective contribution |
|---|---:|---:|
| `A8_j` | 36 | `-36.0000000000` |
| `variable_volumen*` | 38 | `+2.6529896637` |
| `Atp_*tr*` | 40 | `-0.2416398223` |
| `Atr_*tr*` | 23 | `-0.1359034002` |
| `Atr_*tp*` | 11 | `+0.0006666667` |
| `A*_L*O*D*T*` | 12 | `-0.0731707317` |

This indicates that the number of loads for `A8_j` is the dominant part of objective, but the volume and path costs still have a net contribution of about 2.2, so the maximum number of loads can't automatically launch the full objective optimum.

##  4 . global structure proof: 36 is the most accepted `A8` order

Public solution not selected:

`A8_2, A8_3, A8_8, A8_11, A8_12, A8_41`。

In the original MPS, a variable 5 is fixed directly from a single variable line to 0:

|  Variables | The original line |  constraint |
|---|---|---|
| `A8_2` | `c85` | `-A8_2 >= 0` |
| `A8_3` | `c86` | `-A8_3 >= 0` |
| `A8_8` | `c92` | `-A8_8 >= 0` |
| `A8_12` | `c100` | `-A8_12 >= 0` |
| `A8_41` | `c150` | `-A8_41 >= 0` |

Since the lower bound of the variable is 0, the 5 variable can only be 0.

The remaining `A8_11` case is strictly excluded by two rows. Let `S` be the sum of the 93 binary path variables shared by `c96` and `c258`. The original rows are:

```text
c96 : -A8_11 + S >= 0
c258: 8712 S <= 6500
```

The second line is given:

`S <= 6500/8712 = 0.7460973370 < 1`。

Since `S` is a binary variable of 93, and `S` is a nonnegative integer, there must be `S=0`. The first line is `A8_11<=0`, combined with `A8_11>=0`, known as `A8_11=0`.

The script is verified on a case by case basis:

-  The path variable 93 in both rows supports the set complete equals;
-  All path coefficients in `c96` are 1;
-  All path coefficients in `c258` are 8712;
-  93 is an integer variable for `[0,1]`.

Therefore, in a high-level variable 42 there is a 6 which in any feasible solution must be 0, so `sum A8_j <=36`. The public solution correctly selects the remaining 36 variables, so the globally optimal value of the high-level sequence strict is equal to 36.

The original MPS also selected the 37 candidate variable for the algebra all fixed to 1, proof infeasible in seconds at 2.77; the IIS was further narrowed down to two constraints `c96,c258` and lower bound `A8_11>=1`.

##  5 . instance Specific decomposition experiment

###  5.1 Full model, fixed 42 High-level selection

First, all `A8_j` values in the fixed public solution are re-optimized for the rest of the 169 variable. Gurobi aggressive presolve runs continuously for about 599 seconds, has not been pre-processed, has not entered the branch node, and has not generated any valid bound.

Conclusion: `TIME_LIMIT`, no improvement, no proof. This result indicates a direct dependence on the entire model aggressive presolve is not suitable for the instance.

###  5.2 by production line path decomposition

After that, the instance special neighborhood is used: the entire `Atp/Atr` path is released for the objective output line with the terminal variable, the path of the fixed other output lines is public solution; the `A*` finite particle sharing variable and the continuous volume variable are still re-determined by the model.

| Objective Line | Release the path/terminal variable |  Time |  Status | The Best Objective |  bound  |  gap  |
|---:|---:|---:|---|---:|---:|---:|
|  4  |  12,284  |  17.49 s  |  `OPTIMAL`  |  `-33.79705762382218`  | The objective |  `0`  |
| 0 | 141,479 | 420.21 s | `TIME_LIMIT` | `-33.79705762382218` | `-33.8130237317` | `0.04724%` |
| 1 | 463,347 | 180.15 s | `TIME_LIMIT` | `-33.79705762382218` | `-33.8087103351` | `0.03448%` |
| 2 | 466,819 | 180.17 s | `TIME_LIMIT` | `-33.79705762382218` | `-33.8076364571` | `0.03130%` |

line 4 closure under strict `MIPGap=0`, so public solution is the exact optimal solution to this condition problem. line 0, 1, 2 has not been improved, but there is still a non-zero gap, and can only be written as a bounded string without improved string, and cannot be written as a locally optimal proof.

Early line 4 trials used the Gurobi default `1e-4` relative gap, which still had a `0.0068%` gap when labeled as `OPTIMAL`. This study did not accept the result as proof, but instead re-run with `MIPGap=0` and true closure.

##  6. Why can't we still declare the full objective optimal?

All high-level receivable orders are accepted by the public solution, but the full objective also includes volume, path end time and other transfer costs.

-  the order path between the 4 line is reconfigured;
-  Change the endpoints of different lines;
-  the joint adjustment of the `variable_volumen*`;
-  or select fewer orders but significantly reduce other positive costs;

Therefore, the current evidence supporting the global maximum number of lithium-ion loads, which does not support the global optimum number of lithium-ion loads.

##  7. The next most promising route

1.  To extract the `Atp/Atr` network of each line into an explicitly circular diagram, do exactly the shortest path/resource constraint, the shortest path pricing, instead of continuing to let Gurobi handle the entire array.
2.  Using 42 as a single `A8_j`, 54 as a master variable, the 4 line path as a pricing subproblem, constructs the Dantzig-based Wolfe/branch-and-price lower bound.
3.  A known 6 `A8` is permanently 0, with the corresponding columns and covers removed from the original model; a small master branch of 37 for the remaining 36 high-level variable is studied separately.
4.  Establish a feasibility problem for public objective that is strictly superior to the `objective <= -33.7970576238223-epsilon` threshold and use rational coefficients or interval error controls in path pricing.
5.  line 0 / 1 / 2 The current condition gap is less than `0.05%` and can be prioritized to add path control to these lines, eliminate the shortest arcs and symmetry columns at the same end; line 4 has closed and should not continue to input the same configuration of arithmetic.

##  8. Documentation of the evidence

-  Model and public solution audit:[ `results/structure-and-public-audit.json` ](../artifacts/structure-and-public-audit.json)
-  Highly variable structure:[ `results/highlevel-structure-certificate.json` ](../artifacts/highlevel-structure-certificate.json)
-  `A8_11` two-line algebraic certificate:[ `results/a8-11-two-row-certificate.json` ](../artifacts/a8-11-two-row-certificate.json)
-  All 37 individual candidate orders are infeasible:[ `results/global-all37-300s.json` ](../artifacts/global-all37-300s.json)
- IIS summary: [`results/global-all37-iis.json`](../artifacts/global-all37-iis.json)
-  IIS sub-model:[ `results/global-all37-iis.ilp` ](../artifacts/global-all37-iis.ilp)
-  line 4 Zero gap condition proof:[ `results/line4-public-selection-strict-420s.json` ](../artifacts/line4-public-selection-strict-420s.json)
-  Line 0 / 1 / 2 Limit time result: [ `results/line0-public-selection-strict-420s.json` ](../artifacts/line0-public-selection-strict-420s.json) [ `results/line1-public-selection-strict-180s.json` ](../artifacts/line1-public-selection-strict-180s.json) ], [ `results/line2-public-selection-strict-180s.json` ](../artifacts/line2-public-selection-strict-180s.json)
-  It is also possible to reproduce the script: `work/inspect_s82.py` ](../scripts/inspect_s82.py), `work/highlevel_certificate.py` ](../scripts/highlevel_certificate.py), `work/a8_11_certificate.py` ](../scripts/a8_11_certificate.py), `work/line_reopt.py` ](../scripts/line_reopt.py), `work/solve_s82.py` ](../scripts/solve_s82.py), `work/all37_iis.py` ](../scripts/all37_iis.py).

##  The final state

```text
new primal improvement:  NO
full-objective optimal:   NOT PROVED
global structural proof: max sum(A8_j) = 36
exact conditional proof: line 4 optimal with other lines fixed
line 0/1/2:              TIME_LIMIT, no improvement
```

