#  s82 Background and sources

##  Source directly related to this instance

1.  **MIPLIB 2017 official instance page**
   https://miplib.zib.de/instance_details_s82.html  
   The official page describes `s82` as a wine scheduling problem with 82 jobs and 4 processing machines, submitted by Daniel Espinoza from MIPLIB 2010 submissions. At the recorded page state it remains `open`, with public primal `-33.7970576238223`. The page lists 1,690,631 variables, 87,878 constraints and classification statistics for the original model, and explicitly states that no bibliographic information is available.

2.  **MIPLIB official instance and solution file**
   instance :  https://miplib.zib.de/WebData/instances/s82.mps.gz
Current solution: https://miplib.zib.de/downloads/solutions/s82/3/s82.sol.gz
The original structure decomposition link: https://miplib.zib.de/WebData/decomps_orig/s82.dec
This study preserves the downloaded file, SHA-256, and independent feasibility audit on the original MPS. The structure decomposition link actually returned the web page error instead of the `.dec` content, so it was not considered as valid decomposition evidence; the error response was alternatively `s82-dec-download-error.html`.

3.  **PartiMIP official paper**
   Peng Lin, Shaowei Cai, Mengchuan Zou, Shengqi Chen, “Parallel MIP Solving with Dynamic Task Decomposition,” CP 2025.  
   DOI：https://doi.org/10.4230/LIPIcs.CP.2025.26  
The paper presents a parallel MIP framework for dynamic task decomposition; the MIPLIB page records the current `s82` solution submitted by Peng Lin and Shaowei Cai to 2024 -10 -02, described as PartiMIP.

4.  **PartiMIP official code and records warehouse repository**
   https://github.com/shaowei-cai-group/PartiMIP  
Local review submitted: `044cee49a0e98914d73ef855f3d5ad69e5dbfa00`. The warehouse repository `Record/s82.sol.gz` and the MIPLIB current download file SHA- 256 complete are the same: `d7c5e7476436b69d008400975c3e45933a51f97bdb1e051edd864216ff6cfc59`. This indicates that the current public solution is indeed the record solution released for the project.

5.  **MIPLIB 2010 Paper and official site**
   T. Koch et al., “MIPLIB 2010: Mixed Integer Programming Library version 5,” Mathematical Programming Computation 3, 103–163 (2011).  
   DOI：https://doi.org/10.1007/s12532-011-0025-9  
The official website: https://miplib2010.zib.de/
The MIPLIB 2010 submission background and reference repository requirements for examining exact solutions for confirming instances; the paper does not have a dedicated mathematical model for public `s82`.

##  Domain Background (Related but not considered to be s82 original model source)

6.  **Parallel machine background** with wine filling layout
   C. Cataldo et al., “A MIP formulation and a heuristic solution approach for the bottling scheduling problem in the wine industry,” Computers & Industrial Engineering 105 (2017), 136–145.  
   DOI：https://doi.org/10.1016/j.cie.2016.12.029  
The paper explains that wine filling orders need to be allocated to the production line, models can be degraded to NP-hard parallel machine layout problems, and develop greedy constructive heuristics. Due to the late publication of the MIPLIB 2010 submission, **It can only be claimed as a field context as the original paper of `s82` or the same model**.

## Evidence Boundary

-  The official MIPLIB page clearly states the `No bibliographic information available`, so no later published wine classification paper pretends to be the original source of the `s82`.
-  The specific meaning of `s82` is primarily derived from the official MPS variable name and the rare structure recovery; the recovered structure is marked in the report as a hypothesis derived from the model, rather than as a known fact in the paper.
-  Globally optimal only accepts full gap closure or verifiable certificate; local neighborhoods are marked separately with optimal and unimproved time limits.
