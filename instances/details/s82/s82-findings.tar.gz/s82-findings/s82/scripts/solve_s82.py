import argparse
import json
import math
import re
import time
from pathlib import Path

import gurobipy as gp


ROOT = Path(r"D:\sufe\code\AI+MIP\direct-api-research\batch-20260908\s82")
MPS = ROOT / "input" / "s82-official.mps.gz"
PUBLIC_SOL = ROOT / "input" / "s82.sol"
PUBLIC_OBJ = -33.7970576238223


def parse_solution(path):
    values = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        fields = line.split()
        if len(fields) >= 2 and not fields[0].startswith("=obj="):
            values[fields[0]] = float(fields[1])
    return values


parser = argparse.ArgumentParser()
parser.add_argument(
    "--mode",
    choices=["baseline", "fix-accept", "radius", "add-one", "strict-better"],
    required=True,
)
parser.add_argument("--radius", type=int, default=2)
parser.add_argument("--time-limit", type=float, default=600.0)
parser.add_argument("--threads", type=int, default=4)
parser.add_argument("--seed", type=int, default=20260908)
parser.add_argument("--tag", required=True)
args = parser.parse_args()

result_path = ROOT / "results" / f"{args.tag}.json"
log_path = ROOT / "logs" / f"{args.tag}.log"
sol_path = ROOT / "results" / f"{args.tag}.sol"

public_values = parse_solution(PUBLIC_SOL)
started = time.time()
m = gp.read(str(MPS))
m.update()
read_seconds = time.time() - started

m.Params.LogFile = str(log_path)
m.Params.TimeLimit = args.time_limit
m.Params.Threads = args.threads
m.Params.Seed = args.seed
m.Params.NumericFocus = 2
m.Params.MIPGap = 0.0
m.Params.MIPGapAbs = 0.0
m.Params.MIPFocus = 1 if args.mode != "strict-better" else 3
m.Params.Heuristics = 0.30 if args.mode != "strict-better" else 0.05
m.Params.Presolve = 1
m.Params.PrePasses = 2
m.Params.Aggregate = 0
m.Params.PreSparsify = 0
m.Params.Cuts = 2
m.Params.NodefileStart = 4

# Load the exact sparse public solution as a start. Variables omitted from a .sol
# file are interpreted as zero by Gurobi's MIP-start reader.
m.read(str(PUBLIC_SOL))

accept_vars = sorted(
    [v for v in m.getVars() if re.fullmatch(r"A8_\d+", v.VarName)],
    key=lambda v: int(v.VarName.split("_")[1]),
)
selected = [v for v in accept_vars if public_values.get(v.VarName, 0.0) > 0.5]
unselected = [v for v in accept_vars if public_values.get(v.VarName, 0.0) <= 0.5]

if args.mode == "fix-accept":
    for v in accept_vars:
        value = round(public_values.get(v.VarName, 0.0))
        v.LB = value
        v.UB = value
elif args.mode == "radius":
    distance = gp.quicksum(1 - v for v in selected) + gp.quicksum(
        v for v in unselected
    )
    m.addConstr(distance <= args.radius, name=f"local_branch_A8_r{args.radius}")
elif args.mode == "add-one":
    # Exact high-level test: all 36 currently accepted A8 jobs remain selected,
    # and exactly one or more of the six omitted A8 jobs must be added.
    for v in selected:
        v.LB = 1.0
    m.addConstr(gp.quicksum(v for v in unselected) >= 1, name="add_at_least_one_A8")
elif args.mode == "strict-better":
    original_obj = m.getObjective()
    m.addConstr(original_obj <= PUBLIC_OBJ - 1e-7, name="strict_better_public")
    m.setObjective(0.0, gp.GRB.MINIMIZE)

m.update()
opt_started = time.time()
m.optimize()
opt_seconds = time.time() - opt_started

status_name = {
    gp.GRB.LOADED: "LOADED",
    gp.GRB.OPTIMAL: "OPTIMAL",
    gp.GRB.INFEASIBLE: "INFEASIBLE",
    gp.GRB.INF_OR_UNBD: "INF_OR_UNBD",
    gp.GRB.UNBOUNDED: "UNBOUNDED",
    gp.GRB.CUTOFF: "CUTOFF",
    gp.GRB.ITERATION_LIMIT: "ITERATION_LIMIT",
    gp.GRB.NODE_LIMIT: "NODE_LIMIT",
    gp.GRB.TIME_LIMIT: "TIME_LIMIT",
    gp.GRB.SOLUTION_LIMIT: "SOLUTION_LIMIT",
    gp.GRB.INTERRUPTED: "INTERRUPTED",
    gp.GRB.NUMERIC: "NUMERIC",
    gp.GRB.SUBOPTIMAL: "SUBOPTIMAL",
}.get(m.Status, str(m.Status))

objective = None
bound = None
gap = None
accepted = None
if m.SolCount:
    objective = float(m.ObjVal)
    accepted = [v.VarName for v in accept_vars if v.X > 0.5]
    m.write(str(sol_path))
try:
    candidate = float(m.ObjBound)
    bound = candidate if math.isfinite(candidate) else None
except gp.GurobiError:
    pass
try:
    candidate = float(m.MIPGap)
    gap = candidate if math.isfinite(candidate) else None
except gp.GurobiError:
    pass

out = {
    "instance": "s82",
    "tag": args.tag,
    "mode": args.mode,
    "radius": args.radius if args.mode == "radius" else None,
    "time_limit": args.time_limit,
    "threads": args.threads,
    "seed": args.seed,
    "public_objective": PUBLIC_OBJ,
    "public_accept_count": len(selected),
    "public_selected_accept_vars": [v.VarName for v in selected],
    "public_unselected_accept_vars": [v.VarName for v in unselected],
    "read_seconds": read_seconds,
    "optimize_seconds": opt_seconds,
    "wall_seconds": time.time() - started,
    "status_code": int(m.Status),
    "status": status_name,
    "solution_count": int(m.SolCount),
    "objective": objective,
    "objective_bound": bound,
    "relative_gap": gap,
    "node_count": float(m.NodeCount),
    "simplex_iterations": float(m.IterCount),
    "barrier_iterations": int(m.BarIterCount),
    "accepted_count": len(accepted) if accepted is not None else None,
    "accepted_vars": accepted,
    "strict_improvement": objective is not None and objective < PUBLIC_OBJ - 1e-9,
    "global_optimality_proved": args.mode == "baseline" and m.Status == gp.GRB.OPTIMAL,
    "restricted_subproblem_proved": args.mode in {"fix-accept", "radius", "add-one"}
    and m.Status in {gp.GRB.OPTIMAL, gp.GRB.INFEASIBLE},
    "global_max_A8_acceptance_count_proved_36": args.mode == "add-one"
    and m.Status == gp.GRB.INFEASIBLE,
    "solution_file": str(sol_path) if m.SolCount else None,
    "log_file": str(log_path),
}
result_path.write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
print(json.dumps(out, indent=2, ensure_ascii=False))
