import collections
import json
import math
import re
from pathlib import Path

import gurobipy as gp


ROOT = Path(r"D:\sufe\code\AI+MIP\direct-api-research\batch-20260908\s82")
MPS = ROOT / "input" / "s82-official.mps.gz"
SOL = ROOT / "input" / "s82.sol"
OUT = ROOT / "results" / "highlevel-structure-certificate.json"


values = {}
for line in SOL.read_text(encoding="utf-8").splitlines():
    fields = line.split()
    if len(fields) >= 2 and not fields[0].startswith("=obj="):
        values[fields[0]] = float(fields[1])

m = gp.read(str(MPS))
m.update()
vars_ = m.getVars()
constrs = m.getConstrs()
A = m.getA().tocsc()

accept_vars = sorted(
    [v for v in vars_ if re.fullmatch(r"A8_\d+", v.VarName)],
    key=lambda v: int(v.VarName.split("_")[1]),
)
forced_zero = []
support = {}
for v in accept_vars:
    row_indices = A.indices[A.indptr[v.index] : A.indptr[v.index + 1]]
    descriptions = []
    for row_index in row_indices:
        c = constrs[row_index]
        row = m.getRow(c)
        coeff = None
        for k in range(row.size()):
            if row.getVar(k).index == v.index:
                coeff = row.getCoeff(k)
                break
        item = {
            "row": c.ConstrName,
            "sense": c.Sense,
            "rhs": c.RHS,
            "nnz": row.size(),
            "coefficient_of_accept_var": coeff,
        }
        descriptions.append(item)
        # -x >= 0 together with x >= 0 is an independently checkable x=0 proof.
        if row.size() == 1 and c.Sense == ">" and c.RHS == 0 and coeff == -1:
            forced_zero.append(
                {
                    "var": v.VarName,
                    "row": c.ConstrName,
                    "derivation": f"-{v.VarName} >= 0 and {v.VarName} >= 0",
                }
            )
    support[v.VarName] = descriptions

template = collections.defaultdict(lambda: {"nonzeros": 0, "objective": 0.0})
line_nonzeros = collections.Counter()
for v in vars_:
    x = values.get(v.VarName, 0.0)
    if abs(x) <= 1e-15:
        continue
    key = re.sub(r"\d+", "#", v.VarName)
    template[key]["nonzeros"] += 1
    template[key]["objective"] += x * v.Obj
    match = re.search(r"_li([0124])$", v.VarName)
    if match:
        line_nonzeros[match.group(1)] += 1

selected = [v.VarName for v in accept_vars if values.get(v.VarName, 0.0) > 0.5]
omitted = [v.VarName for v in accept_vars if values.get(v.VarName, 0.0) <= 0.5]
forced_names = {item["var"] for item in forced_zero}

out = {
    "instance": "s82",
    "high_level_accept_variables": len(accept_vars),
    "selected_accept_variables": selected,
    "selected_count": len(selected),
    "omitted_accept_variables": omitted,
    "singleton_forced_zero_certificates": forced_zero,
    "only_omitted_not_singleton_forced_zero": sorted(set(omitted) - forced_names),
    "consequence": (
        "Five of the six omitted A8 variables are algebraically fixed to zero. "
        "A8_11 is the only nontrivial omitted high-level acceptance candidate."
    ),
    "accept_constraint_support": support,
    "public_solution_objective_decomposition": template,
    "public_nonzero_path_variables_by_line": line_nonzeros,
}
OUT.write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
print(json.dumps(out, indent=2, ensure_ascii=False))
