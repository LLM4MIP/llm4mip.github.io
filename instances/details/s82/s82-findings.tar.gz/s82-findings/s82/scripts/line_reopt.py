import argparse
import json
import math
import re
import time
from pathlib import Path

import gurobipy as gp


ROOT = Path(r"D:\sufe\code\AI+MIP\direct-api-research\batch-20260908\s82")
MPS = ROOT / "input" / "s82-official.mps.gz"
SOL = ROOT / "input" / "s82.sol"
PUBLIC_OBJ = -33.7970576238223


def parse_sol(path):
    values = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        fields = line.split()
        if len(fields) >= 2 and not fields[0].startswith("=obj="):
            values[fields[0]] = float(fields[1])
    return values


parser = argparse.ArgumentParser()
parser.add_argument("--line", choices=["0", "1", "2", "4"], required=True)
parser.add_argument("--add-a8-11", action="store_true")
parser.add_argument("--time-limit", type=float, default=420.0)
parser.add_argument("--tag", required=True)
args = parser.parse_args()

values = parse_sol(SOL)
result_path = ROOT / "results" / f"{args.tag}.json"
sol_path = ROOT / "results" / f"{args.tag}.sol"
log_path = ROOT / "logs" / f"{args.tag}.log"

started = time.time()
m = gp.read(str(MPS))
m.update()
m.Params.LogFile = str(log_path)
m.Params.TimeLimit = args.time_limit
m.Params.Threads = 4
m.Params.Seed = 20260908 + int(args.line)
m.Params.NumericFocus = 2
m.Params.MIPGap = 0.0
m.Params.MIPGapAbs = 0.0
m.Params.MIPFocus = 1
m.Params.Heuristics = 0.4
m.Params.Cuts = 1
m.Params.Presolve = 1
m.Params.PrePasses = 2
m.Params.Aggregate = 0
m.Params.PreSparsify = 0
m.Params.NodefileStart = 4

fixed_count = 0
free_line_count = 0
for v in m.getVars():
    name = v.VarName
    line_match = re.search(r"_li([0124])$", name)
    if name.startswith(("Atp_", "Atr_")):
        if line_match and line_match.group(1) == args.line:
            free_line_count += 1
        else:
            val = round(values.get(name, 0.0))
            v.LB = val
            v.UB = val
            fixed_count += 1
    elif re.fullmatch(r"A8_\d+", name):
        val = round(values.get(name, 0.0))
        if name == "A8_11" and args.add_a8_11:
            val = 1
        v.LB = val
        v.UB = val
        fixed_count += 1
    elif name.startswith("Tp_"):
        # Free only the terminal/sink choice of the target production line.
        if name.endswith(f"_Slinea_{args.line}") or name.endswith(
            f"_Sinklinea_{args.line}"
        ):
            free_line_count += 1
        else:
            val = round(values.get(name, 0.0))
            v.LB = val
            v.UB = val
            fixed_count += 1

# For a feasible incumbent, load the published schedule.  When A8_11 is forced
# in, that schedule is intentionally infeasible and is not loaded as a start.
if not args.add_a8_11:
    m.read(str(SOL))

m.update()
opt_started = time.time()
m.optimize()
opt_seconds = time.time() - opt_started

status_name = {
    gp.GRB.OPTIMAL: "OPTIMAL",
    gp.GRB.INFEASIBLE: "INFEASIBLE",
    gp.GRB.INF_OR_UNBD: "INF_OR_UNBD",
    gp.GRB.TIME_LIMIT: "TIME_LIMIT",
    gp.GRB.SUBOPTIMAL: "SUBOPTIMAL",
    gp.GRB.NUMERIC: "NUMERIC",
    gp.GRB.INTERRUPTED: "INTERRUPTED",
}.get(m.Status, str(m.Status))

objective = float(m.ObjVal) if m.SolCount else None
bound = None
gap = None
try:
    candidate = float(m.ObjBound)
    bound = candidate if math.isfinite(candidate) else None
except gp.GurobiError:
    pass
try:
    candidate = float(m.MIPGap)
    gap = candidate if math.isfinite(candidate) else None
except gp.GurobiError:
    pass
if m.SolCount:
    m.write(str(sol_path))

out = {
    "instance": "s82",
    "method": "exact_single_line_reoptimization_with_other_paths_fixed",
    "target_line": int(args.line),
    "forced_A8_11": args.add_a8_11,
    "public_objective": PUBLIC_OBJ,
    "fixed_integer_path_or_high_level_variables": fixed_count,
    "free_target_line_path_or_terminal_variables": free_line_count,
    "time_limit": args.time_limit,
    "status": status_name,
    "status_code": int(m.Status),
    "solution_count": int(m.SolCount),
    "objective": objective,
    "objective_bound": bound,
    "relative_gap": gap,
    "node_count": float(m.NodeCount),
    "simplex_iterations": float(m.IterCount),
    "optimize_seconds": opt_seconds,
    "wall_seconds": time.time() - started,
    "strict_improvement": objective is not None and objective < PUBLIC_OBJ - 1e-9,
    "global_proof": False,
    "conditional_line_proof": m.Status in {gp.GRB.OPTIMAL, gp.GRB.INFEASIBLE}
    and (m.Status == gp.GRB.INFEASIBLE or (gap is not None and gap == 0.0)),
    "condition": (
        "All Atp/Atr paths on non-target lines fixed to public solution; "
        "all A8 decisions fixed to public solution except optional A8_11=1."
    ),
    "solution_file": str(sol_path) if m.SolCount else None,
    "log_file": str(log_path),
}
result_path.write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
print(json.dumps(out, indent=2, ensure_ascii=False))
