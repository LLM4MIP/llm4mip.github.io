# Package manifest: s82

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 32
Excluded source files: 0

## Included files

- `README.md`
- `artifacts/a8-11-two-row-certificate.json`
- `artifacts/fix-accept-600s.json`
- `artifacts/global-all37-300s.json`
- `artifacts/global-all37-iis.ilp`
- `artifacts/global-all37-iis.json`
- `artifacts/highlevel-structure-certificate.json`
- `artifacts/line0-public-selection-strict-420s.json`
- `artifacts/line1-public-selection-strict-180s.json`
- `artifacts/line2-public-selection-strict-180s.json`
- `artifacts/line4-public-selection-strict-420s.json`
- `artifacts/replay-a8-11-two-row-certificate.json`
- `artifacts/structure-and-public-audit.json`
- `artifacts/summary.json`
- `input/SHA256SUMS`
- `input/s82-public.sol.gz`
- `logs/fix-accept-600s.log`
- `logs/global-all37-300s.log`
- `logs/global-all37-iis.log`
- `logs/line0-public-selection-strict-420s.log`
- `logs/line1-public-selection-strict-180s.log`
- `logs/line2-public-selection-strict-180s.log`
- `logs/line4-public-selection-strict-420s.log`
- `reports/SOURCES.md`
- `reports/deep-study-2026-09-08.zh.md`
- `scripts/a8_11_certificate.py`
- `scripts/all37_iis.py`
- `scripts/highlevel_certificate.py`
- `scripts/inspect_s82.py`
- `scripts/line_reopt.py`
- `scripts/recover_structure.py`
- `scripts/solve_s82.py`

## Excluded files

- None
