# Input provenance

The original MPS is intentionally not stored in this repository.

- MIPLIB page: <https://miplib.zib.de/instance_details_pb-gfrd-pnc.html>
- Official MPS: <https://miplib.zib.de/WebData/instances/pb-gfrd-pnc.mps.gz>
- Expected SHA-256: `9cd2b554089095cebd17251ad14cabb5d27478afdd3efa832b7aa60a91b5df55`

Download it as `input/pb-gfrd-pnc.mps.gz` before regenerating the quotient.
