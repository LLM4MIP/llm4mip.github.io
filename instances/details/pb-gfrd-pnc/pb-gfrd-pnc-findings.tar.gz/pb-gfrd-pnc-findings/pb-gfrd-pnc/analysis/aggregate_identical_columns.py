#!/usr/bin/env python3
"""Aggregate exact identical binary columns into bounded integer variables.

If k binary columns have identical coefficients in every row and in the
objective, the model depends only on their sum.  Replacing them by one integer
variable in [0,k] is exact, and any aggregate solution can be disaggregated by
setting an arbitrary number of members to one.
"""

from __future__ import annotations

import collections
import gzip
import pathlib
import sys


def parse_mps(path: str):
    row_order: list[str] = []
    senses: dict[str, str] = {}
    rhs: dict[str, float] = {}
    columns: dict[str, dict[str, float]] = collections.defaultdict(dict)
    section = ""
    with gzip.open(path, "rt", encoding="ascii") as stream:
        for raw in stream:
            fields = raw.split()
            if not fields:
                continue
            if fields[0] == "NAME":
                section = "NAME"
                continue
            if fields[0] in {"ROWS", "COLUMNS", "RHS", "BOUNDS", "ENDATA"} and len(fields) == 1:
                section = fields[0]
                continue
            if section == "ROWS":
                sense, row = fields[:2]
                senses[row] = sense
                if sense != "N":
                    row_order.append(row)
            elif section == "COLUMNS":
                if len(fields) >= 3 and fields[1] == "'MARKER'":
                    continue
                var = fields[0]
                for pos in range(1, len(fields), 2):
                    columns[var][fields[pos]] = float(fields[pos + 1])
            elif section == "RHS":
                for pos in range(1, len(fields), 2):
                    rhs[fields[pos]] = float(fields[pos + 1])
    return row_order, senses, rhs, columns


def parse_solution(path: str) -> set[str]:
    chosen = set()
    with open(path, encoding="ascii") as stream:
        for line in stream:
            fields = line.split()
            if len(fields) == 2 and fields[0].startswith("x") and float(fields[1]) > 0.5:
                chosen.add(fields[0])
    return chosen


def write_expression(out, prefix: str, terms: list[tuple[float, str]], rhs_tail: str = ""):
    line = prefix
    for coefficient, var in terms:
        sign = "+" if coefficient >= 0 else "-"
        token = f" {sign} {abs(coefficient):.15g} {var}"
        if len(line) + len(token) > 180:
            out.write(line + "\n")
            line = "  " + token.lstrip()
        else:
            line += token
    out.write(line + rhs_tail + "\n")


def main(mps_path: str, solution_path: str, output_dir: str) -> None:
    row_order, senses, rhs, columns = parse_mps(mps_path)
    chosen = parse_solution(solution_path)

    by_signature: dict[tuple, list[str]] = collections.defaultdict(list)
    for var, entries in columns.items():
        by_signature[tuple(sorted(entries.items()))].append(var)
    groups = sorted(by_signature.values(), key=lambda members: int(members[0][1:]))

    new_entries: dict[str, dict[str, float]] = {}
    members_by_new: dict[str, list[str]] = {}
    uppers: dict[str, int] = {}
    binaries: list[str] = []
    generals: list[str] = []
    aggregate_start: dict[str, int] = {}
    aggregate_index = 0
    for members in groups:
        if len(members) == 1:
            new_var = members[0]
            binaries.append(new_var)
        else:
            aggregate_index += 1
            new_var = f"a{aggregate_index:04d}"
            generals.append(new_var)
            uppers[new_var] = len(members)
        members_by_new[new_var] = members
        new_entries[new_var] = columns[members[0]]
        aggregate_start[new_var] = sum(var in chosen for var in members)

    row_terms: dict[str, list[tuple[float, str]]] = {row: [] for row in row_order}
    objective_terms = []
    for var, entries in new_entries.items():
        if entries.get("Obj", 0.0):
            objective_terms.append((entries["Obj"], var))
        for row, coefficient in entries.items():
            if row != "Obj":
                row_terms[row].append((coefficient, var))

    target = pathlib.Path(output_dir)
    target.mkdir(parents=True, exist_ok=True)
    lp_path = target / "pb-gfrd-pnc-aggregated.lp"
    with lp_path.open("w", encoding="ascii") as out:
        out.write("Minimize\n")
        write_expression(out, " obj:", objective_terms)
        out.write("Subject To\n")
        for row in row_order:
            relation = ">=" if senses[row] == "G" else "="
            write_expression(out, f" {row}:", row_terms[row], f" {relation} {rhs.get(row, 0.0):.15g}")
        out.write("Bounds\n")
        for var in generals:
            out.write(f" 0 <= {var} <= {uppers[var]}\n")
        out.write("Binary\n")
        for var in binaries:
            out.write(f" {var}\n")
        out.write("General\n")
        for var in generals:
            out.write(f" {var}\n")
        out.write("End\n")

    with (target / "official_8844_aggregated.sol").open("w", encoding="ascii") as out:
        out.write("# Objective value = 8844\n")
        for var in sorted(aggregate_start):
            if aggregate_start[var]:
                out.write(f"{var} {aggregate_start[var]}\n")

    with (target / "aggregation_map.tsv").open("w", encoding="ascii") as out:
        out.write("aggregate_var\tupper_bound\toriginal_vars\n")
        for var in sorted(members_by_new):
            if len(members_by_new[var]) > 1:
                out.write(f"{var}\t{len(members_by_new[var])}\t{' '.join(members_by_new[var])}\n")

    original_obj = sum(columns[var].get("Obj", 0.0) for var in chosen)
    aggregate_obj = sum(new_entries[var].get("Obj", 0.0) * value for var, value in aggregate_start.items())
    if original_obj != aggregate_obj:
        raise RuntimeError("objective mismatch in transformed start")
    for row in row_order:
        original_lhs = sum(columns[var].get(row, 0.0) for var in chosen)
        aggregate_lhs = sum(new_entries[var].get(row, 0.0) * value for var, value in aggregate_start.items())
        if original_lhs != aggregate_lhs:
            raise RuntimeError(f"row mismatch after aggregation: {row}")

    print(f"original_variables={len(columns)}")
    print(f"aggregated_variables={len(new_entries)} binaries={len(binaries)} bounded_integers={len(generals)}")
    print(f"removed_symmetric_variables={len(columns) - len(new_entries)}")
    print(f"original_constraint_nonzeros={sum(len(e) - ('Obj' in e) for e in columns.values())}")
    print(f"aggregated_constraint_nonzeros={sum(len(e) - ('Obj' in e) for e in new_entries.values())}")
    print(f"incumbent_objective={aggregate_obj} row_values_preserved=yes")
    print(f"model={lp_path}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], sys.argv[3])
