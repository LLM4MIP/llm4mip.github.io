from __future__ import annotations

import argparse
import gzip
import json
import math
from pathlib import Path
import time

import gurobipy as gp
from gurobipy import GRB


def read_sparse_solution(path: Path) -> tuple[dict[str, float], float | None]:
    opener = gzip.open if path.suffix == ".gz" else open
    values: dict[str, float] = {}
    declared: float | None = None
    with opener(path, "rt", encoding="utf-8", errors="replace") as stream:
        for raw in stream:
            fields = raw.split()
            if len(fields) < 2:
                continue
            if fields[0] == "=obj=":
                declared = float(fields[1])
                continue
            if fields[0].startswith("#"):
                continue
            try:
                values[fields[0]] = float(fields[1])
            except ValueError:
                pass
    return values, declared


def apply_full_start(model: gp.Model, values: dict[str, float]) -> dict[str, int | float]:
    variables = model.getVars()
    by_name = {variable.VarName: variable for variable in variables}
    unknown = sorted(set(values) - set(by_name))
    explicit_nonzero = 0
    objective = float(model.ObjCon)
    for variable in variables:
        value = float(values.get(variable.VarName, 0.0))
        variable.Start = value
        explicit_nonzero += value != 0.0
        objective += float(variable.Obj) * value
    return {
        "variables_explicitly_started": len(variables),
        "explicit_nonzero_values": explicit_nonzero,
        "solution_entries": len(values),
        "unknown_solution_names": len(unknown),
        "start_objective_recomputed": objective,
    }


def parameter_value(model: gp.Model, name: str):
    return getattr(model.Params, name)


def json_value(value):
    """Return a standards-compliant JSON scalar for a solver value."""
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("log", type=Path)
    parser.add_argument("--time-limit", type=float, default=300.0)
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--node-limit", type=float)
    parser.add_argument("--mip-focus", type=int, default=0)
    parser.add_argument("--presolve", type=int, default=2)
    parser.add_argument("--aggregate", type=int, default=1)
    parser.add_argument("--agg-fill", type=int, default=-1)
    parser.add_argument("--pre-sparsify", type=int, default=-1)
    parser.add_argument("--pre-dep-row", type=int, default=-1)
    parser.add_argument("--symmetry", type=int, default=-1)
    parser.add_argument("--cuts", type=int, default=-1)
    parser.add_argument("--heuristics", type=float, default=0.05)
    parser.add_argument("--method", type=int, default=-1)
    parser.add_argument("--numeric-focus", type=int, default=1)
    parser.add_argument("--mip-gap", type=float, default=0.0)
    parser.add_argument("--concurrent-mip", type=int)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.log.parent.mkdir(parents=True, exist_ok=True)
    started = time.time()
    model = gp.read(str(args.mps))
    values, declared = read_sparse_solution(args.solution)
    start_report = apply_full_start(model, values)

    model.Params.LogFile = str(args.log)
    model.Params.TimeLimit = args.time_limit
    model.Params.Threads = args.threads
    model.Params.Seed = args.seed
    model.Params.MIPFocus = args.mip_focus
    model.Params.Presolve = args.presolve
    model.Params.Aggregate = args.aggregate
    model.Params.AggFill = args.agg_fill
    model.Params.PreSparsify = args.pre_sparsify
    model.Params.PreDepRow = args.pre_dep_row
    model.Params.Symmetry = args.symmetry
    model.Params.Cuts = args.cuts
    model.Params.Heuristics = args.heuristics
    model.Params.Method = args.method
    model.Params.NumericFocus = args.numeric_focus
    model.Params.MIPGap = args.mip_gap
    if args.concurrent_mip is not None:
        model.Params.ConcurrentMIP = args.concurrent_mip
    if args.node_limit is not None:
        model.Params.NodeLimit = args.node_limit

    model.optimize()
    parameters = {
        name: json_value(parameter_value(model, name))
        for name in [
            "TimeLimit",
            "Threads",
            "Seed",
            "NodeLimit",
            "MIPFocus",
            "Presolve",
            "Aggregate",
            "AggFill",
            "PreSparsify",
            "PreDepRow",
            "Symmetry",
            "Cuts",
            "Heuristics",
            "Method",
            "NumericFocus",
            "MIPGap",
            "ConcurrentMIP",
        ]
    }
    status_names = {
        GRB.OPTIMAL: "OPTIMAL",
        GRB.TIME_LIMIT: "TIME_LIMIT",
        GRB.NODE_LIMIT: "NODE_LIMIT",
        GRB.INTERRUPTED: "INTERRUPTED",
        GRB.INFEASIBLE: "INFEASIBLE",
        GRB.INF_OR_UNBD: "INF_OR_UNBD",
        GRB.UNBOUNDED: "UNBOUNDED",
    }
    report = {
        "instance": model.ModelName,
        "mps": str(args.mps),
        "solution": str(args.solution),
        "declared_solution_objective": declared,
        "full_start": start_report,
        "parameters": parameters,
        "status": int(model.Status),
        "status_name": status_names.get(model.Status, str(model.Status)),
        "solutions": int(model.SolCount),
        "objective": float(model.ObjVal) if model.SolCount else None,
        "bound": float(model.ObjBound) if model.IsMIP else None,
        "gap": float(model.MIPGap) if model.IsMIP and model.SolCount else None,
        "nodes": float(model.NodeCount) if model.IsMIP else None,
        "simplex_iterations": float(model.IterCount),
        "barrier_iterations": int(model.BarIterCount),
        "runtime_seconds": float(model.Runtime),
        "wall_seconds": time.time() - started,
        "work_units": float(model.Work),
    }
    if model.SolCount:
        report["incumbent_matches_public"] = math.isclose(
            float(model.ObjVal),
            float(start_report["start_objective_recomputed"]),
            rel_tol=0.0,
            abs_tol=1e-6,
        )
    encoded = json.dumps(report, indent=2, sort_keys=True, allow_nan=False)
    args.output.write_text(encoded + "\n", encoding="utf-8")
    print(encoded)


if __name__ == "__main__":
    main()
