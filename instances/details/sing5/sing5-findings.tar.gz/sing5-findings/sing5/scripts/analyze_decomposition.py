from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import statistics

import gurobipy as gp
from gurobipy import GRB


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def describe(values: list[int | float]) -> dict[str, int | float] | None:
    if not values:
        return None
    return {
        "min": min(values),
        "median": statistics.median(values),
        "mean": statistics.fmean(values),
        "max": max(values),
    }


def parse_dec(path: Path) -> tuple[int, dict[str, int], set[str]]:
    block_count = 0
    current_block: int | None = None
    in_master = False
    row_to_block: dict[str, int] = {}
    master_rows: set[str] = set()
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    index = 0
    while index < len(lines):
        line = lines[index].strip()
        index += 1
        if not line or line.startswith("\\"):
            continue
        upper = line.upper()
        if upper == "NBLOCKS":
            while index < len(lines) and (not lines[index].strip() or lines[index].lstrip().startswith("\\")):
                index += 1
            block_count = int(lines[index].strip())
            index += 1
            continue
        if upper.startswith("BLOCK "):
            current_block = int(line.split()[1])
            in_master = False
            continue
        if upper == "MASTERCONSS":
            current_block = None
            in_master = True
            continue
        if upper in {"PRESOLVED", "0"}:
            continue
        if in_master:
            master_rows.add(line)
        elif current_block is not None:
            if line in row_to_block:
                raise RuntimeError(f"row assigned twice: {line}")
            row_to_block[line] = current_block
    return block_count, row_to_block, master_rows


def finite(value: float) -> float | str:
    if math.isinf(value):
        return "inf" if value > 0 else "-inf"
    return float(value)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("dec", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()
    model = gp.read(str(args.mps), env)
    variables = model.getVars()
    constraints = model.getConstrs()
    block_count, row_to_block, master_names = parse_dec(args.dec)

    constraint_names = {constraint.ConstrName for constraint in constraints}
    assigned_names = set(row_to_block) | master_names
    missing_in_model = sorted(assigned_names - constraint_names)
    unassigned = sorted(constraint_names - assigned_names)
    if missing_in_model or unassigned:
        raise RuntimeError(
            f"DEC mismatch: {len(missing_in_model)} names absent from model, "
            f"{len(unassigned)} model rows unassigned"
        )

    variable_blocks: list[set[int]] = [set() for _ in variables]
    variable_master_touch = [False] * len(variables)
    block_rows: dict[int, int] = Counter()
    block_nnz: dict[int, int] = Counter()
    block_variables: dict[int, set[int]] = defaultdict(set)
    master_degrees: list[int] = []
    master_senses: Counter[str] = Counter()
    master_variables: set[int] = set()

    for constraint in constraints:
        row = model.getRow(constraint)
        indices = [row.getVar(position).index for position in range(row.size())]
        if constraint.ConstrName in master_names:
            master_degrees.append(row.size())
            master_senses[constraint.Sense] += 1
            for variable_index in indices:
                variable_master_touch[variable_index] = True
                master_variables.add(variable_index)
        else:
            block = row_to_block[constraint.ConstrName]
            block_rows[block] += 1
            block_nnz[block] += row.size()
            block_variables[block].update(indices)
            for variable_index in indices:
                variable_blocks[variable_index].add(block)

    linking = {
        index
        for index in range(len(variables))
        if len(variable_blocks[index]) > 1
        or (variable_master_touch[index] and bool(variable_blocks[index]))
    }
    master_only = {
        index
        for index in master_variables
        if not variable_blocks[index]
    }
    block_only = {
        index
        for index in range(len(variables))
        if len(variable_blocks[index]) == 1 and not variable_master_touch[index]
    }

    block_records = []
    for block in range(1, block_count + 1):
        variable_indices = block_variables[block]
        local_indices = variable_indices - linking
        link_indices = variable_indices & linking
        record = {
            "block": block,
            "rows": block_rows[block],
            "variables": len(variable_indices),
            "local_variables": len(local_indices),
            "linking_variables": len(link_indices),
            "integer_variables": sum(variables[i].VType != GRB.CONTINUOUS for i in variable_indices),
            "continuous_variables": sum(variables[i].VType == GRB.CONTINUOUS for i in variable_indices),
            "objective_variables": sum(variables[i].Obj != 0.0 for i in variable_indices),
            "nonzeros": block_nnz[block],
        }
        block_records.append(record)

    shape_groups: Counter[tuple[int, ...]] = Counter(
        (
            item["rows"],
            item["variables"],
            item["local_variables"],
            item["linking_variables"],
            item["integer_variables"],
            item["continuous_variables"],
            item["objective_variables"],
            item["nonzeros"],
        )
        for item in block_records
    )
    repeated_shapes = [
        {
            "count": count,
            "rows": shape[0],
            "variables": shape[1],
            "local_variables": shape[2],
            "linking_variables": shape[3],
            "integer_variables": shape[4],
            "continuous_variables": shape[5],
            "objective_variables": shape[6],
            "nonzeros": shape[7],
        }
        for shape, count in shape_groups.most_common()
        if count > 1
    ]

    integer_bound_patterns = Counter(
        (finite(variable.LB), finite(variable.UB))
        for variable in variables
        if variable.VType != GRB.CONTINUOUS
    )
    objective_partition = {
        "linking": sum(variables[i].Obj != 0.0 for i in linking),
        "master_only": sum(variables[i].Obj != 0.0 for i in master_only),
        "block_only": sum(variables[i].Obj != 0.0 for i in block_only),
        "other": sum(
            variables[i].Obj != 0.0
            for i in range(len(variables))
            if i not in linking and i not in master_only and i not in block_only
        ),
    }

    payload = {
        "instance": model.ModelName,
        "source": {
            "mps": str(args.mps),
            "mps_sha256": sha256(args.mps),
            "dec": str(args.dec),
            "dec_sha256": sha256(args.dec),
        },
        "model": {
            "variables": model.NumVars,
            "constraints": model.NumConstrs,
            "nonzeros": model.NumNZs,
            "objective_sense": "minimize" if model.ModelSense == GRB.MINIMIZE else "maximize",
            "variable_types": dict(Counter(variable.VType for variable in variables)),
            "constraint_senses": dict(Counter(constraint.Sense for constraint in constraints)),
            "objective_nonzeros": sum(variable.Obj != 0.0 for variable in variables),
            "integer_bound_patterns": [
                {"lb": pattern[0], "ub": pattern[1], "count": count}
                for pattern, count in integer_bound_patterns.most_common()
            ],
        },
        "decomposition": {
            "blocks": block_count,
            "block_rows": len(row_to_block),
            "master_rows": len(master_names),
            "master_row_senses": dict(master_senses),
            "master_row_degree_stats": describe(master_degrees),
            "master_variables": len(master_variables),
            "linking_variables": len(linking),
            "master_only_variables": len(master_only),
            "block_only_variables": len(block_only),
            "variables_touching_multiple_blocks": sum(len(blocks) > 1 for blocks in variable_blocks),
            "block_row_stats": describe([item["rows"] for item in block_records]),
            "block_variable_stats": describe([item["variables"] for item in block_records]),
            "block_local_variable_stats": describe([item["local_variables"] for item in block_records]),
            "block_linking_variable_stats": describe([item["linking_variables"] for item in block_records]),
            "block_nnz_stats": describe([item["nonzeros"] for item in block_records]),
            "objective_nonzeros_by_partition": objective_partition,
            "repeated_block_shapes": repeated_shapes,
            "block_records": block_records,
            "largest_blocks_by_rows": sorted(block_records, key=lambda item: (-item["rows"], item["block"]))[:20],
            "largest_blocks_by_variables": sorted(block_records, key=lambda item: (-item["variables"], item["block"]))[:20],
        },
        "notes": [
            "Rows are assigned exactly as in the official MIPLIB decomposition file.",
            "A linking variable either touches multiple blocks or touches both a block and a master row.",
            "Repeated block shapes compare counts only and do not assert coefficient-level isomorphism.",
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
