from __future__ import annotations

import argparse
from collections import defaultdict
import gzip
import json
from pathlib import Path
import time

import gurobipy as gp
from gurobipy import GRB


def read_solution(model: gp.Model, path: Path) -> tuple[list[float], dict]:
    variables = model.getVars()
    by_name = {variable.VarName: variable.index for variable in variables}
    values = [0.0] * len(variables)
    declared = None
    explicit = 0
    unknown: list[str] = []
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8", errors="replace") as stream:
        for raw in stream:
            fields = raw.split()
            if not fields or fields[0].startswith("#"):
                continue
            if fields[0].startswith("="):
                for token in reversed(fields):
                    try:
                        declared = float(token)
                        break
                    except ValueError:
                        pass
                continue
            if len(fields) < 2:
                continue
            try:
                value = float(fields[1])
            except ValueError:
                continue
            index = by_name.get(fields[0])
            if index is None:
                if len(unknown) < 20:
                    unknown.append(fields[0])
                continue
            if variables[index].VType != GRB.CONTINUOUS:
                value = float(round(value))
            values[index] = value
            explicit += 1
    objective = model.ObjCon + sum(variable.Obj * values[variable.index] for variable in variables)
    return values, {
        "declared_objective": declared,
        "recomputed_objective": objective,
        "explicit_entries": explicit,
        "variables_explicitly_started": len(variables),
        "unknown_name_examples": unknown,
    }


def read_decomposition(path: Path) -> tuple[int, dict[int, list[str]], set[str]]:
    block_count = 0
    current_block = None
    in_master = False
    blocks: dict[int, list[str]] = defaultdict(list)
    master: set[str] = set()
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    index = 0
    while index < len(lines):
        line = lines[index].strip()
        index += 1
        if not line or line.startswith("\\"):
            continue
        upper = line.upper()
        if upper == "NBLOCKS":
            while index < len(lines) and not lines[index].strip():
                index += 1
            block_count = int(lines[index].strip())
            index += 1
        elif upper.startswith("BLOCK "):
            current_block = int(line.split()[1])
            in_master = False
        elif upper == "MASTERCONSS":
            current_block = None
            in_master = True
        elif upper in {"PRESOLVED", "0"}:
            continue
        elif in_master:
            master.add(line)
        elif current_block is not None:
            blocks[current_block].append(line)
    return block_count, blocks, master


def audit(model: gp.Model, values: list[float]) -> dict:
    variables = model.getVars()
    max_bound_violation = 0.0
    max_integrality_violation = 0.0
    for variable, value in zip(variables, values):
        max_bound_violation = max(max_bound_violation, variable.LB - value, value - variable.UB, 0.0)
        if variable.VType != GRB.CONTINUOUS:
            max_integrality_violation = max(max_integrality_violation, abs(value - round(value)))
    max_row_violation = 0.0
    worst_row = None
    for constraint in model.getConstrs():
        row = model.getRow(constraint)
        activity = sum(
            row.getCoeff(position) * values[row.getVar(position).index]
            for position in range(row.size())
        )
        if constraint.Sense == GRB.LESS_EQUAL:
            violation = max(0.0, activity - constraint.RHS)
        elif constraint.Sense == GRB.GREATER_EQUAL:
            violation = max(0.0, constraint.RHS - activity)
        else:
            violation = abs(activity - constraint.RHS)
        if violation > max_row_violation:
            max_row_violation = violation
            worst_row = constraint.ConstrName
    return {
        "objective": model.ObjCon + sum(variable.Obj * values[variable.index] for variable in variables),
        "max_bound_violation": max_bound_violation,
        "max_integrality_violation": max_integrality_violation,
        "max_row_violation": max_row_violation,
        "worst_row": worst_row,
    }


def write_sparse_solution(model: gp.Model, values: list[float], path: Path) -> None:
    objective = model.ObjCon + sum(variable.Obj * values[variable.index] for variable in model.getVars())
    lines = [f"=obj= {objective:.17g}"]
    for variable, value in zip(model.getVars(), values):
        if abs(value) > 1e-12:
            lines.append(f"{variable.VarName} {value:.17g}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Coordinate LNS using the official MIPLIB .dec blocks.")
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("decomposition", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("log_dir", type=Path)
    parser.add_argument("best_solution", type=Path)
    parser.add_argument("--time-per-block", type=float, default=30.0)
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--seed", type=int, default=5000)
    parser.add_argument("--max-blocks", type=int, default=12)
    parser.add_argument("--min-block-rows", type=int, default=100)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.log_dir.mkdir(parents=True, exist_ok=True)
    args.best_solution.parent.mkdir(parents=True, exist_ok=True)
    started = time.time()

    model = gp.read(str(args.mps))
    variables = model.getVars()
    constraints = {constraint.ConstrName: constraint for constraint in model.getConstrs()}
    incumbent, solution_info = read_solution(model, args.solution)
    initial_audit = audit(model, incumbent)
    original_lbs = [variable.LB for variable in variables]
    original_ubs = [variable.UB for variable in variables]

    block_count, block_rows, master_rows = read_decomposition(args.decomposition)
    block_variables: dict[int, set[int]] = defaultdict(set)
    for block, row_names in block_rows.items():
        for row_name in row_names:
            row = model.getRow(constraints[row_name])
            block_variables[block].update(row.getVar(position).index for position in range(row.size()))
    master_variables: set[int] = set()
    for row_name in master_rows:
        row = model.getRow(constraints[row_name])
        master_variables.update(row.getVar(position).index for position in range(row.size()))
    all_block_variables = set().union(*block_variables.values())
    master_only = master_variables - all_block_variables

    # A complete feasible incumbent is kept after every coordinate step.  Fixing the
    # complement does not change the original constraints; it only defines a safe LNS.
    for variable, value in zip(variables, incumbent):
        variable.LB = value
        variable.UB = value
        variable.Start = value
    model.update()

    candidates = [
        block for block in range(1, block_count + 1)
        if len(block_rows[block]) >= args.min_block_rows
    ]
    candidates.sort(key=lambda block: (-len(block_rows[block]), block))
    candidates = candidates[: args.max_blocks]
    records: list[dict] = []
    best_objective = initial_audit["objective"]

    for sequence, block in enumerate(candidates, start=1):
        free = block_variables[block] | master_only
        for index in free:
            variables[index].LB = original_lbs[index]
            variables[index].UB = original_ubs[index]
            variables[index].Start = incumbent[index]
        model.update()
        model.reset(0)
        model.Params.OutputFlag = 1
        model.Params.LogFile = str(args.log_dir / f"sing5-block-{block:02d}.log")
        model.Params.TimeLimit = args.time_per_block
        model.Params.Threads = args.threads
        model.Params.Seed = args.seed + sequence
        model.Params.MIPFocus = 1
        model.Params.Presolve = 2
        model.Params.Aggregate = 2
        model.Params.PreSparsify = 2
        model.Params.Symmetry = 2
        model.Params.Cuts = 2
        model.Params.Heuristics = 0.2
        # Coordinate optimality must not be inferred from Gurobi's default
        # relative MIP gap (1e-4); require closure apart from solver tolerances.
        model.Params.MIPGap = 0.0
        model.Params.MIPGapAbs = 0.0
        block_started = time.time()
        model.optimize()
        objective = float(model.ObjVal) if model.SolCount else None
        improved = objective is not None and objective < best_objective - 1e-6
        if improved:
            incumbent = [float(variable.X) for variable in variables]
            best_objective = objective
            write_sparse_solution(model, incumbent, args.best_solution)
        records.append({
            "sequence": sequence,
            "block": block,
            "block_rows": len(block_rows[block]),
            "block_variables": len(block_variables[block]),
            "master_only_variables": len(master_only),
            "free_variables": len(free),
            "status": int(model.Status),
            "status_name": {
                GRB.OPTIMAL: "OPTIMAL",
                GRB.TIME_LIMIT: "TIME_LIMIT",
                GRB.NODE_LIMIT: "NODE_LIMIT",
            }.get(model.Status, str(model.Status)),
            "solutions": int(model.SolCount),
            "objective": objective,
            "bound": float(model.ObjBound),
            "gap": float(model.MIPGap) if model.SolCount else None,
            "zero_gap_certificate": bool(
                model.Status == GRB.OPTIMAL
                and model.SolCount
                and abs(float(model.ObjVal) - float(model.ObjBound)) <= 1e-6
            ),
            "nodes": float(model.NodeCount),
            "runtime_seconds": float(model.Runtime),
            "wall_seconds": time.time() - block_started,
            "improved": improved,
        })
        for index in free:
            variables[index].LB = incumbent[index]
            variables[index].UB = incumbent[index]
            variables[index].Start = incumbent[index]
        model.update()

        checkpoint = {
            "instance": model.ModelName,
            "method": "official .dec one-block coordinate LNS; complement fixed to incumbent",
            "solution": solution_info,
            "initial_audit": initial_audit,
            "decomposition": {
                "blocks": block_count,
                "master_rows": len(master_rows),
                "master_only_variables": len(master_only),
                "candidate_blocks": candidates,
            },
            "parameters": vars(args) | {
                "mps": str(args.mps),
                "solution": str(args.solution),
                "decomposition": str(args.decomposition),
                "output": str(args.output),
                "log_dir": str(args.log_dir),
                "best_solution": str(args.best_solution),
            },
            "best_objective": best_objective,
            "objective_improvement": initial_audit["objective"] - best_objective,
            "records": records,
            "wall_seconds": time.time() - started,
        }
        # Replace Path values before JSON serialization.
        checkpoint["parameters"] = {
            key: str(value) if isinstance(value, Path) else value
            for key, value in checkpoint["parameters"].items()
        }
        args.output.write_text(json.dumps(checkpoint, indent=2) + "\n", encoding="utf-8")

    checkpoint["final_audit"] = audit(model, incumbent)
    checkpoint["wall_seconds"] = time.time() - started
    args.output.write_text(json.dumps(checkpoint, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(checkpoint, indent=2))


if __name__ == "__main__":
    main()
