# `sing5` — complete open-instance study (2026-09-08)

Official MIPLIB page: <https://miplib.zib.de/instance_details_sing5.html>

## Result

`sing5` remains **globally open**. The public incumbent is strictly feasible,
but none of the full-MIP, block-neighborhood, or Lagrangian experiments in this
study found a better primal solution or closed the global gap.

| Quantity | Value | Evidence boundary |
|---|---:|---|
| Strict feasible upper bound | **18,778,435.60767737** | Direct evaluation on the original MPS; zero bound/integrality violation and maximum row violation `4.55e-13` |
| Best local reproducible lower bound | **18,462,676.77864** | Full-precision final `BestBd` in an imported, normally terminated Gurobi 13.0.2 original-MIP log |
| Reproducible relative gap | **1.681497%** | Computed from the two values above |
| Historical COPT 10-hour lower bound | **18,605,207.3** | Finite-precision value extracted from an archived PDF; no matching raw log or solution is available here |
| Gap implied by the historical PDF value | **0.922485%** | Context only; not counted as a result reproduced by this repository |

The incumbent is the MIPLIB public solution, not a new primal improvement. Its
independent audit is archived in
[`sing5-public-audit.json`](artifacts/sing5-public-audit.json). The exact
published input file was reread once more during publication; that replay is
[`published-solution-replay.json`](artifacts/published-solution-replay.json).

## Model and official decomposition

The original model has 154,463 variables (146,210 integer and 8,253
continuous), 92,183 rows, and 408,715 nonzeros. The official MIPLIB `.dec`
file partitions 91,847 rows into 68 blocks and leaves 336 master rows. There are
16,529 linking variables and 168 variables appearing only in the master layer.
The audited decomposition is recorded in
[`sing5-decomposition.json`](artifacts/sing5-decomposition.json).
An independent coefficient-by-coefficient audit also finds an exact ordered
isomorphism between blocks 7 and 8; the incumbent is fixed by that swap. See
[`block7-8-isomorphism-audit.txt`](artifacts/block7-8-isomorphism-audit.txt).

## Full-MIP lower-bound experiments

Every full-model run retained all original variables and constraints and used a
complete version of the strict incumbent as its MIP start.

| Configuration | Time / stopping condition | Best lower bound | Outcome |
|---|---:|---:|---|
| LP relaxation | root LP | 18,418,516.01313750 | 1.9167% below the incumbent |
| Aggressive root cuts | 300 s, one-node limit | 18,436,733.37867603 | no primal improvement |
| Dual-focused branch-and-bound | 600 s, 357 nodes | 18,437,529.54560198 | no primal improvement |
| `ConcurrentMIP=2` | 1,200 s, 1,833 nodes | 18,442,898.50581330 | time limit; controlled repository run |
| Imported one-thread baseline | configured `TimeLimit=30`; log reports 945.67 s | **18,462,676.77864** | normal final summary; no primal improvement; elapsed-time anomaly |

The imported log's parameter block says `TimeLimit=30`, while its final summary
says 945.67 seconds and the attachment did not retain an independent wrapper.
The bound is therefore usable because the solver printed a normal full-
precision final summary, but its runtime is not trustworthy and must not be
compared with controlled wall times. Details are in the
[import report](reports/imported-baseline-2026-09-08.md),
[result JSON](artifacts/imported-baseline-result.json), and
[sanitized log](logs/imported-baseline-2026-09-08.log).

All lower bounds above are floating-point solver evidence, not independently
checked rational certificates. The stronger COPT value quoted above remains
useful historical evidence and exceeds the imported bound by `142,530.52136`,
but its PDF-only provenance prevents an exact replay or parameter audit.

## Conditional block-neighborhood conclusions

Two LNS experiments used the official 68-block decomposition. For each tested
neighborhood, variables belonging to the selected block or blocks and all 168
master-only variables were released; every other variable was fixed to the
strict incumbent. All original constraints remained in the subproblem. Gurobi
was required to return `OPTIMAL` with both `MIPGap=0` and `MIPGapAbs=0`.

- **68/68 single-block neighborhoods closed:** every official block was tested,
  all 68 subproblems returned zero solver gap, and none improved the incumbent.
- **6/6 selected multi-block neighborhoods closed:** `(10,11,12)`, `(7,8)`,
  `(13,14)`, `(66,67,68)`, `(4,5,6)`, and `(1,2,3)` all returned zero solver
  gap without improvement. The largest released neighborhood contained 32,433
  variables.
- The `(13,14)` test also covers the two-block direction in which the 2018 and
  2019 public solutions differ: their integer patterns are identical, while 32
  continuous changes in those two blocks have nearly offsetting objective
  effects.

The complete summaries are
[`block-lns-all68-gap0.json`](artifacts/block-lns-all68-gap0.json) and
[`group-lns-structural-gap0.json`](artifacts/group-lns-structural-gap0.json);
the corresponding raw logs are under
[`logs/block-lns-all68-gap0/`](logs/block-lns-all68-gap0/) and
[`logs/group-lns-structural-gap0/`](logs/group-lns-structural-gap0/).

These are **conditional coordinate-optimality results**. They prove only that
the incumbent cannot be improved while the complement of each listed
neighborhood is fixed. They do not cover arbitrary combinations of blocks and
do not prove global optimality of `sing5`.

## Lagrangian experiment

The 336 official master constraints were dualized while block integrality was
retained. At the full-LP dual multipliers, the integer Lagrangian subproblem was
solved to zero gap at **18,418,516.01313751**, numerically equal to the original
LP relaxation. Projected subgradient trials did not raise this value. The
assembly and multiplier signs were checked by reproducing the full LP value to
about `2.35e-7`.

For this minimization problem, each correctly signed and fully solved
Lagrangian subproblem supplies a valid global lower bound. Nevertheless, the
reported value is weaker than the best full-MIP bound, is floating-point
solver evidence, and does not show that the maximum of the Lagrangian dual has
been found. See
[`lagrangian-lpdual-300s.json`](artifacts/lagrangian-lpdual-300s.json) and
[`lagrangian-subgradient-15.json`](artifacts/lagrangian-subgradient-15.json).

## Reproduction

Commands below are run from this instance directory and require Gurobi 13.x
with a valid license. They write replay output below `replay/` and do not alter
the archived evidence.

Earlier controlled full-MIP run retained by this repository:

```powershell
python scripts/run_gurobi.py `
  input/sing5.mps.gz input/sing5-public.sol.gz `
  replay/concurrent2-balanced-1200s.json replay/concurrent2-balanced-1200s.log `
  --time-limit 1200 --threads 4 --seed 530 --mip-focus 0 `
  --presolve 2 --aggregate 2 --agg-fill 200 --pre-sparsify 2 `
  --pre-dep-row 1 --numeric-focus 1 --mip-gap 0 --concurrent-mip 2
```

All 68 single-block neighborhoods:

```powershell
python scripts/run_block_lns.py `
  input/sing5.mps.gz input/sing5-public.sol.gz input/sing5.dec `
  replay/block-lns-all68-gap0.json replay/block-lns-all68-gap0 `
  replay/sing5-block-lns-best.sol `
  --time-per-block 20 --threads 2 --seed 5600 `
  --max-blocks 68 --min-block-rows 1
```

The six selected multi-block neighborhoods:

```powershell
python scripts/run_group_lns.py `
  input/sing5.mps.gz input/sing5-public.sol.gz input/sing5.dec `
  replay/group-lns-structural-gap0.json replay/group-lns-structural-gap0 `
  replay/sing5-group-lns-best.sol `
  --groups "10,11,12;7,8;13,14;66,67,68;4,5,6;1,2,3" `
  --time-per-group 60 --threads 2 --seed 5700
```

Projected-subgradient Lagrangian trial:

```powershell
python scripts/run_lagrangian_subgradient.py `
  input/sing5.mps.gz input/sing5-public.sol.gz input/sing5.dec `
  replay/lagrangian-subgradient-15.json replay/lagrangian-subgradient-15.log `
  --iterations 15 --time-per-block 30 --threads-lp 2 `
  --seed 5910 --theta 1.5 --stagnation 4
```

Input and auxiliary-file hashes are recorded in
[`input/SHA256SUMS`](input/SHA256SUMS). The cross-instance interpretation and
comparison with `sing11`, `sing17`, `sing44`, and `sing326` are in the
[`sing` family report](../../docs/sing-family-2026-09-08.zh.md).

## Scope of the conclusion

This study establishes a strict feasible upper bound, a reproducible numerical
global lower bound, and extensive conditional neighborhood optimality. The
strict UB and best reproduced LB still differ by 315,758.82903737. No portable
global proof trace closes that interval, so **`sing5` remains open**.
