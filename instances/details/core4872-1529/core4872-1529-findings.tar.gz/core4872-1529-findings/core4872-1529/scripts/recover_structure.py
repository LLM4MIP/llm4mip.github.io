"""Recover set-cover core and exceptional rows without optimizing."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path

import gurobipy as gp


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("mps", type=Path)
    ap.add_argument("out", type=Path)
    args = ap.parse_args()

    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()
    m = gp.read(str(args.mps), env)
    vars_ = m.getVars()
    binary = {v.index for v in vars_ if v.VType in ("B", "I") and v.LB == 0 and v.UB == 1}
    continuous = {v.index for v in vars_ if v.VType == "C"}

    obj_dist = Counter((v.VType, v.Obj, v.LB, str(v.UB)) for v in vars_)
    pure_cover: list[dict] = []
    exceptional: list[dict] = []
    incidence: dict[int, list[int]] = defaultdict(list)
    for rno, con in enumerate(m.getConstrs()):
        row = m.getRow(con)
        terms = [(row.getVar(k), row.getCoeff(k)) for k in range(row.size())]
        for v, a in terms:
            incidence[v.index].append(rno)
        is_cover = (
            con.Sense == ">"
            and con.RHS == 1.0
            and terms
            and all(v.index in binary and a == 1.0 for v, a in terms)
        )
        record = {
            "index": rno,
            "name": con.ConstrName,
            "sense": con.Sense,
            "rhs": con.RHS,
            "degree": len(terms),
            "terms": [
                {"name": v.VarName, "type": v.VType, "coef": a, "obj": v.Obj}
                for v, a in terms
            ],
        }
        if is_cover:
            pure_cover.append(record)
        else:
            exceptional.append(record)

    signatures: dict[tuple[int, ...], list[int]] = defaultdict(list)
    for idx in binary:
        signatures[tuple(incidence[idx])].append(idx)
    duplicate_groups = [group for group in signatures.values() if len(group) > 1]

    payload = {
        "source": str(args.mps),
        "counts": {
            "variables": len(vars_),
            "semantic_binary": len(binary),
            "continuous": len(continuous),
            "constraints": m.NumConstrs,
            "pure_unit_set_cover_rows": len(pure_cover),
            "exceptional_rows": len(exceptional),
            "duplicate_full_incidence_groups": len(duplicate_groups),
            "variables_in_duplicate_groups": sum(len(g) for g in duplicate_groups),
        },
        "objective_distribution": [
            {"count": n, "type": key[0], "obj": key[1], "lb": key[2], "ub": key[3]}
            for key, n in sorted(obj_dist.items(), key=lambda z: (-z[1], str(z[0])))
        ],
        "exceptional_rows": exceptional,
        "continuous_variables": [
            {
                "name": vars_[idx].VarName,
                "lb": vars_[idx].LB,
                "ub": str(vars_[idx].UB),
                "obj": vars_[idx].Obj,
                "rows": incidence[idx],
            }
            for idx in sorted(continuous)
        ],
        "duplicate_full_incidence_groups": [
            [vars_[idx].VarName for idx in group] for group in duplicate_groups[:200]
        ],
        "pure_cover_degree_distribution": dict(
            Counter(row["degree"] for row in pure_cover)
        ),
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
