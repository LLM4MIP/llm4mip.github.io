#!/usr/bin/env python3
"""
core4872_1529_lagrangian.py

Structure-aware weighted set-cover dual route.

For a set-cover instance

    min sum_j c_j x_j
    s.t. sum_{j: i in S_j} x_j >= 1       for every row i
         x_j in {0,1},

the ordinary LP dual is

    max sum_i y_i
    s.t. sum_{i in S_j} y_i <= c_j       for every column j
         y_i >= 0.

Every emitted certificate is independently checked by direct dot products.
The integer lower bound is ceil(sum_i y_i), after conservative downward
rounding of all y_i.

Input:
    --mps FILE[.gz]
or:
    --json FILE

Supported JSON schemas:
    {
      "row_names": [...],
      "columns": [
        {"name": "...", "cost": 1, "rows": [0, 4, ...]},
        ...
      ]
    }

or:
    {
      "row_names": [...],
      "col_names": [...],
      "costs": [...],
      "supports": [[0,4,...], ...]
    }

Optional incumbent:
    --incumbent-json FILE

The incumbent JSON may contain:
    {"selected_names":[...]}
or:
    {"original_variable_names":[...]}
or:
    {"columns":[...]}
or simply:
    [ "column_name_1", "column_name_2", ... ]

No solver is called.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
import random
import sys
import time
from collections import defaultdict
from decimal import Decimal, ROUND_DOWN, getcontext
from typing import Dict, List, Set, Tuple, Optional


EXPECTED_ROWS = 4872
EXPECTED_COLS = 24645
EXPECTED_COST1 = 6781
EXPECTED_COST2 = 17864
DEFAULT_SECONDS = 3600
TOL = 1e-10

getcontext().prec = 50


# ---------------------------------------------------------------------------
# Input
# ---------------------------------------------------------------------------

def opentext(path):
    return gzip.open(path, "rt", errors="replace") \
        if path.lower().endswith(".gz") else open(path, "rt", errors="replace")


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(1 << 20)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def parse_mps(path, exact_audit=True):
    section = None
    row_sense = {}
    row_order = []
    objrow = None
    rhs_vectors = {}
    rhs_order = []
    coeff = defaultdict(dict)
    obj = defaultdict(float)
    col_order = []
    seen = set()

    lo = defaultdict(float)
    hi = {}
    integer = set()
    int_marker = False

    with opentext(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("*"):
                continue
            t = line.split()
            key = t[0].upper()

            if key in {"NAME", "OBJSENSE", "OBJNAME"}:
                continue
            # Section headers are standalone.  The active RHS vector is named
            # "rhs", so checking only the first token would discard its data.
            if len(t) == 1 and key in {"ROWS", "COLUMNS", "RHS", "RANGES",
                       "BOUNDS", "ENDATA"}:
                section = key
                if key == "ENDATA":
                    break
                continue

            if section == "ROWS":
                sense, name = t[0].upper(), t[1]
                row_sense[name] = sense
                row_order.append(name)
                if sense == "N" and objrow is None:
                    objrow = name

            elif section == "COLUMNS":
                u = [x.upper().strip("'\"") for x in t]
                if "MARKER" in u:
                    if "INTORG" in u:
                        int_marker = True
                    if "INTEND" in u:
                        int_marker = False
                    continue
                v = t[0]
                if v not in seen:
                    seen.add(v)
                    col_order.append(v)
                if int_marker:
                    integer.add(v)
                p = t[1:]
                if len(p) % 2:
                    raise ValueError("Malformed COLUMNS line")
                for k in range(0, len(p), 2):
                    r, a = p[k], float(p[k + 1])
                    if r == objrow:
                        obj[v] += a
                    else:
                        coeff[v][r] = coeff[v].get(r, 0.0) + a

            elif section == "RHS":
                name = t[0]
                rhs_vectors.setdefault(name, {})
                if name not in rhs_order:
                    rhs_order.append(name)
                p = t[1:]
                if len(p) % 2:
                    raise ValueError("Malformed RHS line")
                for k in range(0, len(p), 2):
                    rhs_vectors[name][p[k]] = float(p[k + 1])

            elif section == "BOUNDS":
                typ, v = t[0].upper(), t[2]
                value = float(t[3]) if len(t) > 3 else 0.0
                if typ == "BV":
                    integer.add(v)
                    lo[v], hi[v] = 0.0, 1.0
                elif typ in {"LI", "LO"}:
                    lo[v] = value
                    integer.add(v) if typ == "LI" else None
                elif typ in {"UI", "UP"}:
                    hi[v] = value
                    integer.add(v) if typ == "UI" else None
                elif typ == "FX":
                    lo[v] = hi[v] = value
                elif typ == "FR":
                    lo[v], hi[v] = -math.inf, math.inf

    rhs = rhs_vectors[rhs_order[0]] if rhs_order else {}

    # Absent RHS means zero under the MPS standard.
    cover_rows = []
    row_values = defaultdict(list)
    for v in col_order:
        for r, a in coeff[v].items():
            if abs(a) > TOL:
                row_values[r].append(a)

    for r in row_order:
        if row_sense.get(r) != "G":
            continue
        if abs(rhs.get(r, 0.0) - 1.0) > TOL:
            continue
        values = row_values.get(r, [])
        if values and all(abs(a - 1.0) <= TOL for a in values):
            cover_rows.append(r)

    rid = {r: i for i, r in enumerate(cover_rows)}
    names, costs, supports = [], [], []

    for v in col_order:
        upper = hi.get(v, 1.0 if v in integer else math.inf)
        if v not in integer or abs(lo[v]) > TOL or abs(upper - 1.0) > TOL:
            continue

        c = obj.get(v, 0.0)
        if abs(c - 1.0) <= TOL:
            cost = 1
        elif abs(c - 2.0) <= TOL:
            cost = 2
        else:
            continue

        s = set()
        valid = True
        for r, a in coeff[v].items():
            if r in rid:
                if abs(a - 1.0) > TOL:
                    valid = False
                    break
                s.add(rid[r])
        if valid:
            names.append(v)
            costs.append(cost)
            supports.append(s)

    audit = {
        "cover_rows": len(cover_rows),
        "binary_columns": len(names),
        "cost1_columns": sum(c == 1 for c in costs),
        "cost2_columns": sum(c == 2 for c in costs),
    }
    print("Exact MPS audit:", json.dumps(audit, sort_keys=True))

    if exact_audit:
        assert audit["cover_rows"] == EXPECTED_ROWS
        assert audit["binary_columns"] == EXPECTED_COLS
        assert audit["cost1_columns"] == EXPECTED_COST1
        assert audit["cost2_columns"] == EXPECTED_COST2

    return {
        "row_names": cover_rows,
        "col_names": names,
        "costs": costs,
        "supports": supports,
        "source": path,
        "sha256": sha256(path),
    }


def parse_json(path):
    with open(path, encoding="utf-8") as f:
        d = json.load(f)

    if "columns" in d:
        cols = d["columns"]
        nrows = d.get("nrows")
        if nrows is None:
            nrows = max(
                (max(c.get("rows", [])) for c in cols if c.get("rows")),
                default=-1,
            ) + 1
        rows = d.get("row_names", [str(i) for i in range(nrows)])
        names, costs, supports = [], [], []
        for j, c in enumerate(cols):
            names.append(str(c.get("name", j)))
            costs.append(int(c.get("cost", c.get("objective", 0))))
            supports.append(set(map(int, c.get("rows", []))))
        return {
            "row_names": list(map(str, rows)),
            "col_names": names,
            "costs": costs,
            "supports": supports,
            "source": path,
            "sha256": sha256(path),
        }

    if "supports" in d and "costs" in d:
        supports = [set(map(int, s)) for s in d["supports"]]
        nrows = d.get("nrows", max((max(s) for s in supports if s), default=-1) + 1)
        return {
            "row_names": list(map(str, d.get("row_names", range(nrows)))),
            "col_names": list(map(str, d.get("col_names", range(len(supports))))),
            "costs": list(map(int, d["costs"])),
            "supports": supports,
            "source": path,
            "sha256": sha256(path),
        }

    raise ValueError("Unsupported JSON schema")


# ---------------------------------------------------------------------------
# Safe duplicate reduction for computation
# ---------------------------------------------------------------------------

def consolidate(inst):
    best = {}
    for j, s in enumerate(inst["supports"]):
        key = frozenset(s)
        old = best.get(key)
        candidate = (inst["costs"][j], j)
        if old is None or candidate < (old[0], old[1]):
            best[key] = (inst["costs"][j], j)

    ids = [v[1] for v in best.values()]
    ids.sort()
    return ids


# ---------------------------------------------------------------------------
# Feasible dual construction
# ---------------------------------------------------------------------------

def loads(y, supports, ncols):
    load = [0.0] * ncols
    for i, value in enumerate(y):
        if value == 0.0:
            continue
        for j in supports[i]:
            load[j] += value
    return load


def restore_feasibility(y, supports, costs):
    """
    Global projection by scaling. If y >= 0, then
        alpha = min_j c_j / load_j
    with alpha <= 1
    gives a feasible dual vector alpha*y.
    """
    ncols = len(costs)
    load = loads(y, supports, ncols)
    alpha = 1.0
    for j, z in enumerate(load):
        if z > costs[j] and z > 0.0:
            alpha = min(alpha, costs[j] / z)
    if alpha < 1.0:
        y = [v * alpha for v in y]
    return y


def coordinate_ascent(y, supports, costs, row_to_cols, deadline):
    """
    Feasible coordinate ascent. Increasing y_i is safe up to the minimum
    residual slack among columns covering row i.
    """
    nrows = len(y)
    ncols = len(costs)
    load = loads(y, supports, ncols)

    order = list(range(nrows))
    random.shuffle(order)

    improved = True
    while improved and time.time() < deadline:
        improved = False
        random.shuffle(order)
        for i in order:
            if time.time() >= deadline:
                break
            cols = row_to_cols[i]
            if not cols:
                continue
            delta = min(
                (costs[j] - load[j] for j in cols),
                default=0.0,
            )
            if delta > 1e-12:
                y[i] += delta
                for j in cols:
                    load[j] += delta
                improved = True

    return y


def dual_search(inst, seconds):
    row_names = inst["row_names"]
    costs = inst["costs"]
    supports = inst["supports"]
    nrows = len(row_names)
    ncols = len(costs)
    deadline = time.time() + seconds

    row_to_cols = [[] for _ in range(nrows)]
    for j, s in enumerate(supports):
        for i in s:
            row_to_cols[i].append(j)

    rare_hist = defaultdict(int)
    for cols in row_to_cols:
        rare_hist[len(cols)] += 1

    best_y = [0.0] * nrows
    best_value = 0.0
    iterations = 0

    # Multiple randomized projected subgradient starts.
    while time.time() < deadline:
        iterations += 1
        y = [0.0] * nrows

        # Rare rows receive a modest initial emphasis.
        for i, cols in enumerate(row_to_cols):
            if not cols:
                continue
            y[i] = 0.15 / math.sqrt(len(cols))

        y = restore_feasibility(y, supports, costs)

        while time.time() < deadline:
            iterations += 1
            load = loads(y, supports, ncols)

            # Subgradient of the dual Lagrangian:
            # g_i = 1 - sum_{j covers i} max(0, load_j-c_j) / ...
            excess = [
                max(0.0, load[j] - costs[j])
                for j in range(ncols)
            ]

            step = 0.20 / math.sqrt(1.0 + iterations)
            trial = list(y)

            for i in range(nrows):
                penalty = 0.0
                for j in row_to_cols[i]:
                    if excess[j] > 0:
                        penalty += excess[j]
                # A positive update is useful for uncovered/underpriced rows;
                # the subsequent exact projection restores all constraints.
                pressure = 1.0 / max(1, len(row_to_cols[i]))
                trial[i] += step * pressure

            trial = restore_feasibility(trial, supports, costs)
            trial = coordinate_ascent(
                trial, supports, costs, row_to_cols, deadline
            )
            trial = restore_feasibility(trial, supports, costs)

            value = sum(trial)
            if value > best_value + 1e-12:
                best_value = value
                best_y = trial

            if iterations % 17 == 0:
                break

    # Final exact feasible polishing.
    best_y = restore_feasibility(best_y, supports, costs)
    best_y = coordinate_ascent(
        best_y, supports, costs, row_to_cols, deadline
    )
    best_y = restore_feasibility(best_y, supports, costs)

    return best_y, {
        "iterations": iterations,
        "dual_sum_float": sum(best_y),
        "rare_row_histogram": dict(sorted(rare_hist.items())),
        "elapsed_seconds": seconds - max(0.0, deadline - time.time()),
    }


# ---------------------------------------------------------------------------
# Conservative certificate generation
# ---------------------------------------------------------------------------

def conservative_certificate(y, supports, costs, decimals=12):
    """
    Downward-round every multiplier to a fixed decimal grid. This cannot
    increase any column load. Decimal is used for the emitted certificate and
    direct recheck.
    """
    quantum = Decimal(1).scaleb(-decimals)
    yd = [
        Decimal(str(max(0.0, v))).quantize(
            quantum, rounding=ROUND_DOWN
        )
        for v in y
    ]

    loads_dec = [Decimal(0) for _ in costs]
    for i, value in enumerate(yd):
        for j in supports[i]:
            loads_dec[j] += value

    violations = []
    for j, (load, cost) in enumerate(zip(loads_dec, costs)):
        if load > Decimal(cost):
            violations.append({
                "column": j,
                "load": str(load),
                "cost": cost,
            })

    total = sum(yd, Decimal(0))
    integer_bound = int(total.to_integral_value(rounding="ROUND_CEILING"))

    return {
        "multipliers": [str(v) for v in yd],
        "objective": str(total),
        "integer_lower_bound": integer_bound,
        "maximum_column_load": str(max(loads_dec, default=Decimal(0))),
        "violations": violations,
        "valid": not violations,
        "rounding": f"downward decimal grid 1e-{decimals}",
        "column_loads": [str(v) for v in loads_dec],
    }


# ---------------------------------------------------------------------------
# Checkable disjoint-row packing bound
# ---------------------------------------------------------------------------

def greedy_disjoint_packing(inst):
    """
    A simple checkable combinatorial bound.

    Select rows greedily so that no selected rows share a column. For each
    selected row, every feasible cover must pay at least the cheapest cost of
    a column covering it. Because the selected row supports are disjoint,
    these costs add.

    This is conservative and usually weaker than the LP dual, but it is
    independently checkable without floating point.
    """
    supports = inst["supports"]
    costs = inst["costs"]
    row_names = inst["row_names"]

    row_order = sorted(
        range(len(supports)),
        key=lambda i: (
            len([j for j in range(len(costs)) if i in supports[j]]),
            i,
        ),
    )

    used_columns = set()
    selected_rows = []
    bound = 0

    row_to_cols = [[] for _ in supports]
    for j, s in enumerate(supports):
        for i in s:
            row_to_cols[i].append(j)

    for i in row_order:
        cols = row_to_cols[i]
        if any(j in used_columns for j in cols):
            continue
        if not cols:
            continue
        selected_rows.append(i)
        used_columns.update(cols)
        bound += min(costs[j] for j in cols)

    return {
        "type": "greedy_disjoint_row_packing",
        "selected_row_ids": selected_rows,
        "selected_row_names": [row_names[i] for i in selected_rows],
        "bound": bound,
        "valid": True,
        "verification_note": (
            "selected row supports are pairwise disjoint; "
            "each row contributes its minimum covering-column cost"
        ),
    }


# ---------------------------------------------------------------------------
# Optional incumbent diagnostics
# ---------------------------------------------------------------------------

def read_incumbent(path):
    with open(path, encoding="utf-8") as f:
        d = json.load(f)

    if isinstance(d, list):
        return set(map(str, d))

    for key in (
        "selected_names",
        "original_variable_names",
        "names",
    ):
        if key in d:
            return set(map(str, d[key]))

    if "columns" in d and all(isinstance(x, str) for x in d["columns"]):
        return set(d["columns"])

    return set()


def incumbent_diagnostics(inst, names):
    name_to_id = {
        name: j for j, name in enumerate(inst["col_names"])
    }
    ids = [
        name_to_id[name] for name in names
        if name in name_to_id
    ]
    covered = set()
    weight = 0
    for j in ids:
        covered.update(inst["supports"][j])
        weight += inst["costs"][j]

    return {
        "selected_names": sorted(names),
        "recognized_names": len(ids),
        "weight": weight,
        "covered_rows": len(covered),
        "total_rows": len(inst["row_names"]),
        "valid_set_cover": (
            len(covered) == len(inst["row_names"])
        ),
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser()
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--mps")
    src.add_argument("--json")
    ap.add_argument("--seconds", type=int, default=DEFAULT_SECONDS)
    ap.add_argument("--out", default="core4872_dual_certificate.json")
    ap.add_argument("--decimals", type=int, default=12)
    ap.add_argument("--no-exact-audit", action="store_true")
    ap.add_argument("--incumbent-json")
    args = ap.parse_args()

    started = time.time()

    try:
        inst = parse_mps(
            args.mps,
            exact_audit=not args.no_exact_audit,
        ) if args.mps else parse_json(args.json)
    except Exception as exc:
        result = {
            "status": "UNKNOWN",
            "reason": f"input failure: {exc!r}",
        }
        print(json.dumps(result, indent=2))
        with open(args.out, "w") as f:
            json.dump(result, f, indent=2)
        return 2

    print(
        f"rows={len(inst['row_names'])} "
        f"columns={len(inst['col_names'])} "
        f"cost1={sum(c == 1 for c in inst['costs'])} "
        f"cost2={sum(c == 2 for c in inst['costs'])}"
    )

    result = {
        "program": "core4872_1529_lagrangian.py",
        "source": inst["source"],
        "source_sha256": inst["sha256"],
        "requested_seconds": args.seconds,
        "row_count": len(inst["row_names"]),
        "column_count": len(inst["col_names"]),
    }

    if args.incumbent_json:
        try:
            names = read_incumbent(args.incumbent_json)
            result["incumbent"] = incumbent_diagnostics(inst, names)
        except Exception as exc:
            result["incumbent_error"] = repr(exc)

    # Duplicate consolidation is safe for computing the dual: duplicate
    # columns have the same support, so retaining the cheapest one gives the
    # strongest relevant dual constraint.
    kept = consolidate(inst)
    reduced = {
        "row_names": inst["row_names"],
        "col_names": [inst["col_names"][j] for j in kept],
        "costs": [inst["costs"][j] for j in kept],
        "supports": [
            {i for i in inst["supports"][j]}
            for j in kept
        ],
    }

    result["duplicate_reduction"] = {
        "original_columns": len(inst["col_names"]),
        "retained_columns": len(kept),
        "removed_columns": len(inst["col_names"]) - len(kept),
    }

    print(
        "dual columns after duplicate consolidation:",
        len(kept),
    )

    if args.incumbent_json:
        pass

    # The dual optimizer is explicitly time-limited.
    remaining = max(1, args.seconds - int(time.time() - started))
    y, search_stats = dual_search(reduced, remaining)
    result["search"] = search_stats

    cert = conservative_certificate(
        y,
        reduced["supports"],
        reduced["costs"],
        decimals=args.decimals,
    )
    result["dual_certificate"] = cert

    packing = greedy_disjoint_packing(reduced)
    result["packing_certificate"] = packing

    dual_bound = cert["integer_lower_bound"]
    packing_bound = packing["bound"]
    combined_bound = max(dual_bound, packing_bound)

    result["valid_integer_lower_bound"] = combined_bound
    result["certificate_summary"] = {
        "dual_bound": dual_bound,
        "packing_bound": packing_bound,
        "combined_bound": combined_bound,
        "dual_directly_rechecked": cert["valid"],
        "packing_directly_checkable": packing["valid"],
    }

    if not cert["valid"]:
        result["status"] = "UNKNOWN"
        result["reason"] = (
            "downward-rounded dual certificate failed direct feasibility check"
        )
    else:
        result["status"] = "BOUND_ONLY"
        result["reason"] = (
            "valid lower bound produced; no claim of optimality unless "
            "the bound reaches the target threshold"
        )

    result["elapsed_seconds"] = time.time() - started

    print("\nDual certificate summary:")
    print(json.dumps(result["certificate_summary"], indent=2))
    print("\nStatus:", result["status"])
    print("Valid integer lower bound:", combined_bound)
    print(
        "Dual objective:",
        cert["objective"],
        "dual integer bound:",
        dual_bound,
    )
    print("Packing bound:", packing_bound)

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, sort_keys=True)

    print("\nWrote:", args.out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
