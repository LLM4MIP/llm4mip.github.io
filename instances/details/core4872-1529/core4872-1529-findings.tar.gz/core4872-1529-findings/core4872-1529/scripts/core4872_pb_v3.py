#!/usr/bin/env python3
"""
core4872_1529_v3.py

Proof-oriented SAT decision program for MIPLIB instance core4872-1529.

Decision:
    Is there a binary set cover of objective weight <= 1529?

Primary encoding:
    - One SAT variable x_j for each residual set-cover column.
    - One positive clause per residual cover row.
    - For every cost-2 column x_j, introduce a fresh alias y_j and add:
          y_j <-> x_j
      using:
          (not y_j or x_j)
          (not x_j or y_j)
    - Add MiniCard's native unweighted cardinality constraint:
          sum(all x_j plus all y_j) <= residual_budget

    Since every literal in the cardinality list is a distinct SAT variable,
    this counts cost-1 columns once and cost-2 columns twice exactly.

Important result labels:
    SAT
        A model was found and validated against every untouched original-MPS
        row and all original variable bounds using read-only Gurobi evaluation.

    CANDIDATE_SAT
        A model passed the internal parsed set-cover check, but full untouched
        MPS validation was unavailable.

    BACKEND_UNSAT
        MiniCard returned UNSAT, but no independently replayed proof was
        retained. This is not certified global optimality.

    PROVED_UNSAT
        Used only for a directly checkable contradiction found by safe
        preprocessing, such as an uncovered row or forced weight > budget.

    UNKNOWN
        Timeout, dependency failure, parser/audit failure, or validation failure.

Dependencies:
    Required SAT backend:
        python -m pip install python-sat

    Optional but strongly recommended for untouched-MPS SAT validation:
        gurobipy

Gurobi use:
    - gp.read() only
    - no optimize()
    - no presolve()
    - no relaxation or solver call
    - all rows, bounds, integrality, and objective are evaluated directly

Default runtime:
    3600 seconds unless a decision is reached earlier.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
import threading
import time
from collections import defaultdict
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Set, Tuple


EXPECTED_COVER_ROWS = 4872
EXPECTED_BINARY_COLUMNS = 24645
EXPECTED_COST1_COLUMNS = 6781
EXPECTED_COST2_COLUMNS = 17864
DEFAULT_BUDGET = 1529
DEFAULT_SECONDS = 3600
TOL = 1e-9


# =============================================================================
# Data structures
# =============================================================================

@dataclass
class SetCoverInstance:
    row_names: List[str]
    col_names: List[str]
    costs: List[int]
    supports: List[Set[int]]
    source: str
    source_sha256: Optional[str]

    @property
    def nrows(self) -> int:
        return len(self.row_names)

    @property
    def ncols(self) -> int:
        return len(self.col_names)


@dataclass
class ReducedInstance:
    row_names: List[str]
    costs: List[int]
    supports: List[Set[int]]

    # residual local column ID -> original SetCoverInstance column ID
    original_col_ids: List[int]

    # residual local row ID -> original SetCoverInstance row ID
    original_row_ids: List[int]

    forced_original_col_ids: Set[int]
    residual_budget: int
    statistics: Dict[str, object]

    @property
    def nrows(self) -> int:
        return len(self.row_names)

    @property
    def ncols(self) -> int:
        return len(self.costs)


# =============================================================================
# General helpers
# =============================================================================

def open_text(path: str):
    if path.lower().endswith(".gz"):
        return gzip.open(path, "rt", errors="replace")
    return open(path, "rt", errors="replace")


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            block = f.read(1024 * 1024)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def write_result(path: str, result: Dict[str, object]) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, sort_keys=True)


# =============================================================================
# MPS parser
# =============================================================================

def parse_core_mps(path: str, exact_audit: bool = True) -> SetCoverInstance:
    """
    Parse the original MPS without optimization.

    Critical MPS rule:
        The default RHS of a row absent from the active RHS vector is ZERO,
        not one.

    A cover row is accepted only if:
        - sense is G;
        - explicit/default RHS equals 1;
        - every nonzero coefficient in that row is +1.

    Binary columns are recognized from BV bounds or integer-marker membership
    with effective bounds [0,1].
    """
    section: Optional[str] = None

    row_sense: Dict[str, str] = {}
    row_order: List[str] = []
    objective_row: Optional[str] = None

    # var -> row -> coefficient
    column_coefficients: Dict[str, Dict[str, float]] = defaultdict(dict)
    objective_coefficients: Dict[str, float] = defaultdict(float)
    column_order: List[str] = []
    seen_columns: Set[str] = set()

    # Multiple RHS vectors are syntactically possible. Use the first one.
    rhs_vectors: Dict[str, Dict[str, float]] = {}
    rhs_vector_order: List[str] = []

    lower_bounds: Dict[str, float] = {}
    upper_bounds: Dict[str, float] = {}
    explicit_binary: Set[str] = set()
    integer_columns: Set[str] = set()
    integer_marker_active = False

    with open_text(path) as f:
        for raw in f:
            line = raw.rstrip("\r\n")
            if not line.strip() or line.lstrip().startswith("*"):
                continue

            tokens = line.split()
            if not tokens:
                continue

            keyword = tokens[0].upper()

            if keyword == "NAME":
                section = "NAME"
                continue
            if keyword in {"OBJSENSE", "OBJNAME"}:
                section = keyword
                continue
            # Section headers are standalone tokens.  In this instance the RHS
            # vector itself is named "rhs", so a case-insensitive keyword test
            # without the length guard would skip every RHS data record.
            if len(tokens) == 1 and keyword in {
                "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"
            }:
                section = keyword
                if keyword == "ENDATA":
                    break
                continue

            if section == "ROWS":
                if len(tokens) < 2:
                    raise ValueError(f"Malformed ROWS line: {line}")
                sense = tokens[0].upper()
                name = tokens[1]
                row_sense[name] = sense
                row_order.append(name)
                if sense == "N" and objective_row is None:
                    objective_row = name

            elif section == "COLUMNS":
                marker_tokens = [x.upper().strip("'\"") for x in tokens]
                if "MARKER" in marker_tokens:
                    if "INTORG" in marker_tokens:
                        integer_marker_active = True
                    elif "INTEND" in marker_tokens:
                        integer_marker_active = False
                    continue

                if len(tokens) < 3:
                    raise ValueError(f"Malformed COLUMNS line: {line}")

                var = tokens[0]
                if var not in seen_columns:
                    seen_columns.add(var)
                    column_order.append(var)

                if integer_marker_active:
                    integer_columns.add(var)

                pairs = tokens[1:]
                if len(pairs) % 2 != 0:
                    raise ValueError(f"Odd COLUMNS row/value list: {line}")

                for k in range(0, len(pairs), 2):
                    row = pairs[k]
                    value = float(pairs[k + 1])

                    if objective_row is not None and row == objective_row:
                        objective_coefficients[var] += value
                    else:
                        old = column_coefficients[var].get(row, 0.0)
                        column_coefficients[var][row] = old + value

            elif section == "RHS":
                if len(tokens) < 3:
                    raise ValueError(f"Malformed RHS line: {line}")

                vector_name = tokens[0]
                if vector_name not in rhs_vectors:
                    rhs_vectors[vector_name] = {}
                    rhs_vector_order.append(vector_name)

                pairs = tokens[1:]
                if len(pairs) % 2 != 0:
                    raise ValueError(f"Odd RHS row/value list: {line}")

                for k in range(0, len(pairs), 2):
                    row = pairs[k]
                    value = float(pairs[k + 1])
                    rhs_vectors[vector_name][row] = value

            elif section == "BOUNDS":
                if len(tokens) < 3:
                    raise ValueError(f"Malformed BOUNDS line: {line}")

                bound_type = tokens[0].upper()
                var = tokens[2]
                value = float(tokens[3]) if len(tokens) >= 4 else 0.0

                if bound_type == "BV":
                    explicit_binary.add(var)
                    integer_columns.add(var)
                    lower_bounds[var] = 0.0
                    upper_bounds[var] = 1.0

                elif bound_type == "LI":
                    integer_columns.add(var)
                    lower_bounds[var] = value

                elif bound_type == "UI":
                    integer_columns.add(var)
                    upper_bounds[var] = value

                elif bound_type == "LO":
                    lower_bounds[var] = value

                elif bound_type == "UP":
                    upper_bounds[var] = value

                elif bound_type == "FX":
                    lower_bounds[var] = value
                    upper_bounds[var] = value

                elif bound_type == "FR":
                    lower_bounds[var] = -math.inf
                    upper_bounds[var] = math.inf

                elif bound_type == "MI":
                    lower_bounds[var] = -math.inf

                elif bound_type == "PL":
                    upper_bounds[var] = math.inf

    if objective_row is None:
        raise ValueError("No objective row found")

    # MPS default RHS is zero.
    active_rhs: Dict[str, float]
    if rhs_vector_order:
        active_rhs = rhs_vectors[rhs_vector_order[0]]
    else:
        active_rhs = {}

    # Build row-oriented coefficient information for auditing cover rows.
    row_nonzero_coefficients: Dict[str, List[float]] = defaultdict(list)
    for var in column_order:
        for row, value in column_coefficients[var].items():
            if abs(value) > TOL:
                row_nonzero_coefficients[row].append(value)

    cover_row_names: List[str] = []
    for row in row_order:
        if row_sense.get(row) != "G":
            continue

        # Correct default: absent RHS means zero.
        rhs_value = active_rhs.get(row, 0.0)
        if abs(rhs_value - 1.0) > TOL:
            continue

        values = row_nonzero_coefficients.get(row, [])
        if not values:
            continue
        if not all(abs(value - 1.0) <= TOL for value in values):
            continue

        cover_row_names.append(row)

    cover_row_id = {
        name: i for i, name in enumerate(cover_row_names)
    }

    col_names: List[str] = []
    costs: List[int] = []
    supports: List[Set[int]] = []

    for var in column_order:
        is_integer = var in integer_columns or var in explicit_binary

        # MPS integer-marker columns conventionally have lower bound 0 and,
        # absent a contrary bound in this benchmark, upper bound 1.
        default_upper = 1.0 if is_integer else math.inf
        lo = lower_bounds.get(var, 0.0)
        hi = upper_bounds.get(var, default_upper)

        is_binary = (
            is_integer
            and abs(lo) <= TOL
            and abs(hi - 1.0) <= TOL
        )
        if not is_binary:
            continue

        objective_value = objective_coefficients.get(var, 0.0)
        if abs(objective_value - 1.0) <= TOL:
            cost = 1
        elif abs(objective_value - 2.0) <= TOL:
            cost = 2
        else:
            # This exact instance's 24,645 binary set-cover columns must all
            # have cost one or two. A strict audit below catches deviations.
            continue

        support: Set[int] = set()
        for row, value in column_coefficients[var].items():
            rid = cover_row_id.get(row)
            if rid is not None:
                if abs(value - 1.0) > TOL:
                    raise AssertionError(
                        f"Nonunit coefficient in accepted cover row "
                        f"{row}, column {var}: {value}"
                    )
                support.add(rid)

        col_names.append(var)
        costs.append(cost)
        supports.append(support)

    audit = {
        "cover_rows": len(cover_row_names),
        "binary_cost12_columns": len(col_names),
        "cost1_columns": sum(c == 1 for c in costs),
        "cost2_columns": sum(c == 2 for c in costs),
    }
    print("MPS audit:", json.dumps(audit, sort_keys=True))

    if exact_audit:
        assert len(cover_row_names) == EXPECTED_COVER_ROWS, (
            f"Expected {EXPECTED_COVER_ROWS} cover rows, "
            f"found {len(cover_row_names)}"
        )
        assert len(col_names) == EXPECTED_BINARY_COLUMNS, (
            f"Expected {EXPECTED_BINARY_COLUMNS} binary cost-1/2 columns, "
            f"found {len(col_names)}"
        )
        assert sum(c == 1 for c in costs) == EXPECTED_COST1_COLUMNS, (
            f"Expected {EXPECTED_COST1_COLUMNS} cost-1 columns"
        )
        assert sum(c == 2 for c in costs) == EXPECTED_COST2_COLUMNS, (
            f"Expected {EXPECTED_COST2_COLUMNS} cost-2 columns"
        )
        assert len(set(col_names)) == len(col_names), (
            "Duplicate original column names"
        )
        assert len(set(cover_row_names)) == len(cover_row_names), (
            "Duplicate cover row names"
        )

    return SetCoverInstance(
        row_names=cover_row_names,
        col_names=col_names,
        costs=costs,
        supports=supports,
        source=path,
        source_sha256=sha256_file(path),
    )


# =============================================================================
# Safe preprocessing
# =============================================================================

def safe_reduce(
    inst: SetCoverInstance,
    budget: int,
) -> Tuple[str, Optional[ReducedInstance], Dict[str, object]]:
    """
    Safe reductions only:

    1. Remove empty columns.
    2. Merge columns with identical complete cover-row support:
       retain minimum cost, breaking ties by original column ID.
    3. Repeated singleton-row forcing.
    4. Remove columns that cover no residual row.

    General subset dominance is intentionally skipped in this version. This
    avoids an O(n^2) Python pass and leaves no ambiguity about performance or
    correctness.
    """
    started = time.time()

    stats: Dict[str, object] = {
        "initial_rows": inst.nrows,
        "initial_columns": inst.ncols,
        "dominance_pass": "skipped intentionally",
        "budget": budget,
    }

    # Records use persistent original column IDs.
    records: List[Tuple[int, int, Set[int]]] = []
    for original_id in range(inst.ncols):
        support = set(inst.supports[original_id])
        if support:
            records.append(
                (original_id, inst.costs[original_id], support)
            )

    stats["empty_columns_removed"] = inst.ncols - len(records)

    # Identical-support consolidation.
    best_by_signature: Dict[
        frozenset, Tuple[int, int, Set[int]]
    ] = {}

    for original_id, cost, support in records:
        signature = frozenset(support)
        incumbent = best_by_signature.get(signature)
        if incumbent is None:
            best_by_signature[signature] = (
                original_id, cost, support
            )
        else:
            old_original_id, old_cost, _ = incumbent
            if (cost, original_id) < (old_cost, old_original_id):
                best_by_signature[signature] = (
                    original_id, cost, support
                )

    records = list(best_by_signature.values())
    records.sort(key=lambda x: x[0])

    stats["duplicate_columns_removed"] = (
        stats["initial_columns"]
        - stats["empty_columns_removed"]
        - len(records)
    )
    stats["after_duplicate_columns"] = len(records)

    active_rows: Set[int] = set(range(inst.nrows))
    forced_original_ids: Set[int] = set()
    residual_budget = budget
    force_rounds = 0

    while True:
        # Restrict supports to residual rows and remove useless columns.
        restricted: List[Tuple[int, int, Set[int]]] = []
        for original_id, cost, support in records:
            residual_support = support & active_rows
            if residual_support and cost <= residual_budget:
                restricted.append(
                    (original_id, cost, residual_support)
                )
        records = restricted

        row_to_positions: Dict[int, List[int]] = defaultdict(list)
        for position, (_, _, support) in enumerate(records):
            for row in support:
                row_to_positions[row].append(position)

        uncovered = [
            row for row in active_rows
            if not row_to_positions.get(row)
        ]
        if uncovered:
            contradiction = {
                "type": "uncovered_row",
                "original_row_ids": uncovered[:20],
                "original_row_names": [
                    inst.row_names[r] for r in uncovered[:20]
                ],
                "count": len(uncovered),
            }
            stats.update({
                "status": "PROVED_UNSAT",
                "contradiction": contradiction,
                "preprocessing_seconds": time.time() - started,
            })
            return "PROVED_UNSAT", None, stats

        singleton_positions = {
            positions[0]
            for row, positions in row_to_positions.items()
            if row in active_rows and len(positions) == 1
        }

        if not singleton_positions:
            break

        force_rounds += 1
        newly_forced: List[Tuple[int, int, Set[int]]] = [
            records[p] for p in sorted(singleton_positions)
        ]

        newly_forced_ids = {
            original_id
            for original_id, _, _ in newly_forced
        }

        for original_id, cost, support in newly_forced:
            if original_id in forced_original_ids:
                continue
            forced_original_ids.add(original_id)
            residual_budget -= cost
            active_rows.difference_update(support)

        if residual_budget < 0:
            contradiction = {
                "type": "forced_weight_exceeds_budget",
                "forced_original_ids": sorted(forced_original_ids),
                "forced_names": [
                    inst.col_names[j]
                    for j in sorted(forced_original_ids)
                ],
                "forced_weight": sum(
                    inst.costs[j] for j in forced_original_ids
                ),
                "budget": budget,
            }
            stats.update({
                "status": "PROVED_UNSAT",
                "contradiction": contradiction,
                "preprocessing_seconds": time.time() - started,
            })
            return "PROVED_UNSAT", None, stats

        records = [
            record for record in records
            if record[0] not in newly_forced_ids
        ]

    original_row_ids = sorted(active_rows)
    row_remap = {
        original_row_id: local_row_id
        for local_row_id, original_row_id
        in enumerate(original_row_ids)
    }

    final_records: List[Tuple[int, int, Set[int]]] = []
    for original_id, cost, support in records:
        local_support = {
            row_remap[r] for r in support
            if r in row_remap
        }
        if local_support:
            final_records.append(
                (original_id, cost, local_support)
            )

    final_records.sort(key=lambda x: x[0])

    reduced = ReducedInstance(
        row_names=[
            inst.row_names[r] for r in original_row_ids
        ],
        costs=[cost for _, cost, _ in final_records],
        supports=[
            support for _, _, support in final_records
        ],
        original_col_ids=[
            original_id for original_id, _, _ in final_records
        ],
        original_row_ids=original_row_ids,
        forced_original_col_ids=forced_original_ids,
        residual_budget=residual_budget,
        statistics={},
    )

    stats.update({
        "force_rounds": force_rounds,
        "forced_columns": len(forced_original_ids),
        "forced_weight": sum(
            inst.costs[j] for j in forced_original_ids
        ),
        "residual_rows": reduced.nrows,
        "residual_columns": reduced.ncols,
        "residual_cost1_columns": sum(c == 1 for c in reduced.costs),
        "residual_cost2_columns": sum(c == 2 for c in reduced.costs),
        "residual_budget": residual_budget,
        "preprocessing_seconds": time.time() - started,
        "status": "REDUCED",
    })
    reduced.statistics = stats

    return "REDUCED", reduced, stats


# =============================================================================
# MiniCard dependency probe
# =============================================================================

def probe_minicard() -> Dict[str, object]:
    """
    Audit the precise PySAT API required here.

    The program requires:
        Solver(name='minicard')
        solver.add_clause(...)
        solver.add_atmost(lits, k)
        solver.solve_limited(expect_interrupt=True)
        solver.interrupt()

    A tiny semantic test checks native at-most behavior.
    """
    probe: Dict[str, object] = {
        "package": "python-sat",
        "backend": "minicard",
        "pypblib_required": False,
    }

    try:
        import pysat
        from pysat.solvers import Solver

        probe["pysat_version"] = getattr(
            pysat, "__version__", "unknown"
        )

        with Solver(name="minicard") as solver:
            required = [
                "add_clause",
                "add_atmost",
                "solve",
                "solve_limited",
                "interrupt",
            ]
            missing = [
                name for name in required
                if not hasattr(solver, name)
            ]
            if missing:
                probe["ok"] = False
                probe["reason"] = (
                    f"MiniCard API methods missing: {missing}"
                )
                return probe

            # Semantic test:
            # a and b are both true, but at most one of a,b.
            solver.add_clause([1])
            solver.add_clause([2])
            solver.add_atmost([1, 2], 1)
            test_result = solver.solve()

            if test_result is not False:
                probe["ok"] = False
                probe["reason"] = (
                    "MiniCard native at-most semantic probe failed"
                )
                return probe

        probe["ok"] = True
        return probe

    except Exception as exc:
        probe["ok"] = False
        probe["reason"] = repr(exc)
        return probe


# =============================================================================
# SAT encoding and wall-clock control
# =============================================================================

def solve_with_minicard(
    reduced: ReducedInstance,
    deadline: float,
) -> Tuple[str, Optional[List[int]], Dict[str, object]]:
    """
    Return:
        status,
        chosen residual local column IDs or None,
        solver statistics.
    """
    probe = probe_minicard()
    stats: Dict[str, object] = {
        "dependency_probe": probe,
        "proof_retained": False,
        "proof_replayed": False,
    }

    if not probe.get("ok"):
        stats["reason"] = "MiniCard dependency/API probe failed"
        return "UNKNOWN", None, stats

    try:
        from pysat.solvers import Solver
    except Exception as exc:
        stats["reason"] = repr(exc)
        return "UNKNOWN", None, stats

    remaining = deadline - time.time()
    if remaining <= 0:
        stats["reason"] = "deadline reached before SAT construction"
        return "UNKNOWN", None, stats

    ncols = reduced.ncols

    # Correct transpose: residual row -> residual local columns.
    row_to_columns: List[List[int]] = [
        [] for _ in range(reduced.nrows)
    ]
    for local_column, support in enumerate(reduced.supports):
        for local_row in support:
            if not 0 <= local_row < reduced.nrows:
                stats["reason"] = (
                    f"invalid residual row ID {local_row}"
                )
                return "UNKNOWN", None, stats
            row_to_columns[local_row].append(local_column)

    empty_rows = [
        r for r, columns in enumerate(row_to_columns)
        if not columns
    ]
    if empty_rows:
        stats["reason"] = (
            "residual transpose contains uncovered rows"
        )
        stats["empty_rows"] = empty_rows[:20]
        return "UNKNOWN", None, stats

    # x_j variables are 1..ncols.
    x_variables = [
        local_column + 1
        for local_column in range(ncols)
    ]

    next_variable = ncols + 1
    alias_by_column: Dict[int, int] = {}

    for local_column, cost in enumerate(reduced.costs):
        if cost == 2:
            alias_by_column[local_column] = next_variable
            next_variable += 1
        elif cost != 1:
            stats["reason"] = (
                f"unsupported residual cost {cost}"
            )
            return "UNKNOWN", None, stats

    cardinality_literals = list(x_variables)
    cardinality_literals.extend(alias_by_column.values())

    assert len(cardinality_literals) == len(set(cardinality_literals))
    assert len(cardinality_literals) == (
        sum(1 for c in reduced.costs if c == 1)
        + 2 * sum(1 for c in reduced.costs if c == 2)
    )

    stats.update({
        "residual_columns": ncols,
        "cover_clauses": reduced.nrows,
        "cost2_aliases": len(alias_by_column),
        "sat_variables": next_variable - 1,
        "cardinality_literal_count": len(cardinality_literals),
        "native_atmost_bound": reduced.residual_budget,
        "alias_equivalence_clauses": 2 * len(alias_by_column),
        "encoding": (
            "positive cover clauses plus cost-2 equivalence aliases "
            "plus MiniCard native unweighted at-most"
        ),
    })

    stop_watcher = threading.Event()
    timed_out = threading.Event()
    solver_started = time.time()

    try:
        with Solver(
            name="minicard",
            use_timer=True,
        ) as solver:
            # One positive clause per residual row.
            for columns in row_to_columns:
                solver.add_clause([
                    local_column + 1
                    for local_column in columns
                ])

            # y_j <-> x_j for every cost-2 column.
            for local_column, alias_variable in alias_by_column.items():
                x_variable = local_column + 1
                solver.add_clause([
                    -alias_variable,
                    x_variable,
                ])
                solver.add_clause([
                    -x_variable,
                    alias_variable,
                ])

            # Exact weighted budget after alias expansion.
            solver.add_atmost(
                cardinality_literals,
                reduced.residual_budget,
            )

            def deadline_watcher() -> None:
                wait_seconds = max(0.0, deadline - time.time())
                if not stop_watcher.wait(wait_seconds):
                    timed_out.set()
                    try:
                        solver.interrupt()
                    except Exception:
                        pass

            watcher = threading.Thread(
                target=deadline_watcher,
                daemon=True,
            )
            watcher.start()

            answer = solver.solve_limited(
                expect_interrupt=True
            )

            stop_watcher.set()
            watcher.join(timeout=1.0)

            stats["solver_wall_seconds"] = (
                time.time() - solver_started
            )
            try:
                stats["solver_accumulated_time"] = solver.time_accum()
            except Exception:
                pass

            if answer is True:
                model = solver.get_model() or []
                true_literals = {
                    literal for literal in model
                    if literal > 0
                }
                chosen = [
                    local_column
                    for local_column in range(ncols)
                    if local_column + 1 in true_literals
                ]

                # Independently check the SAT model against the residual
                # mathematical set-cover problem before mapping it back.
                chosen_set = set(chosen)
                residual_weight = sum(
                    reduced.costs[j] for j in chosen
                )
                uncovered_rows = [
                    r for r, columns in enumerate(row_to_columns)
                    if not any(j in chosen_set for j in columns)
                ]

                stats["model_residual_weight"] = residual_weight
                stats["model_selected_columns"] = len(chosen)
                stats["model_uncovered_rows"] = len(uncovered_rows)

                if residual_weight > reduced.residual_budget:
                    stats["reason"] = (
                        "MiniCard model exceeds residual budget"
                    )
                    return "UNKNOWN", None, stats

                if uncovered_rows:
                    stats["reason"] = (
                        "MiniCard model leaves residual rows uncovered"
                    )
                    stats["uncovered_rows"] = uncovered_rows[:20]
                    return "UNKNOWN", None, stats

                return "SAT_MODEL", chosen, stats

            if answer is False:
                # MiniCard/PySAT did not retain and independently replay a
                # formal certificate in this execution.
                stats["reason"] = (
                    "MiniCard returned UNSAT; no independently "
                    "replayed proof was retained"
                )
                return "BACKEND_UNSAT", None, stats

            if timed_out.is_set() or time.time() >= deadline:
                stats["reason"] = "wall-clock deadline interrupt"
            else:
                stats["reason"] = (
                    "MiniCard returned UNKNOWN or was interrupted"
                )
            return "UNKNOWN", None, stats

    except Exception as exc:
        stop_watcher.set()
        stats["solver_wall_seconds"] = time.time() - solver_started
        stats["reason"] = f"MiniCard exception: {exc!r}"
        return "UNKNOWN", None, stats


# =============================================================================
# Candidate reconstruction and internal validation
# =============================================================================

def validate_against_parsed_cover(
    inst: SetCoverInstance,
    selected_original_ids: Iterable[int],
    budget: int,
) -> Dict[str, object]:
    selected = sorted(set(selected_original_ids))

    invalid_ids = [
        j for j in selected
        if not 0 <= j < inst.ncols
    ]

    covered: Set[int] = set()
    weight = 0

    for original_id in selected:
        if 0 <= original_id < inst.ncols:
            weight += inst.costs[original_id]
            covered.update(inst.supports[original_id])

    uncovered = sorted(
        set(range(inst.nrows)) - covered
    )

    return {
        "valid": (
            not invalid_ids
            and not uncovered
            and weight <= budget
        ),
        "weight": weight,
        "budget": budget,
        "selected_count": len(selected),
        "selected_original_ids": selected,
        "selected_names": [
            inst.col_names[j] for j in selected
            if 0 <= j < inst.ncols
        ],
        "covered_rows": len(covered),
        "total_cover_rows": inst.nrows,
        "invalid_original_ids": invalid_ids,
        "uncovered_row_ids": uncovered,
        "uncovered_row_names": [
            inst.row_names[r] for r in uncovered
        ],
    }


# =============================================================================
# Untouched MPS validation through read-only Gurobi
# =============================================================================

def gurobi_validate_untouched_mps(
    mps_path: str,
    selected_names: Set[str],
    budget: int,
) -> Dict[str, object]:
    """
    Validate the candidate directly against every untouched original-MPS row.

    No optimization method is called.

    Assignment:
        selected binary names = 1
        every other original variable = 0

    Checks:
        - every selected name exists;
        - all original variable bounds;
        - integrality;
        - every original linear constraint;
        - objective <= budget.
    """
    try:
        import gurobipy as gp
    except Exception as exc:
        return {
            "available": False,
            "valid": None,
            "reason": f"gurobipy unavailable: {exc!r}",
        }

    try:
        model = gp.read(mps_path)

        variables = model.getVars()
        original_names = {v.VarName for v in variables}
        unknown_selected_names = sorted(
            selected_names - original_names
        )

        values: Dict[str, float] = {
            v.VarName: (
                1.0 if v.VarName in selected_names else 0.0
            )
            for v in variables
        }

        bound_violations = []
        integrality_violations = []

        for var in variables:
            value = values[var.VarName]

            if value < var.LB - 1e-7 or value > var.UB + 1e-7:
                bound_violations.append({
                    "variable": var.VarName,
                    "value": value,
                    "lb": var.LB,
                    "ub": var.UB,
                })

            if var.VType in {
                gp.GRB.BINARY,
                gp.GRB.INTEGER,
                gp.GRB.SEMIINT,
            }:
                if abs(value - round(value)) > 1e-7:
                    integrality_violations.append({
                        "variable": var.VarName,
                        "value": value,
                        "type": var.VType,
                    })

        row_violations = []

        for constraint in model.getConstrs():
            expression = model.getRow(constraint)
            lhs = 0.0

            for k in range(expression.size()):
                var = expression.getVar(k)
                coefficient = expression.getCoeff(k)
                lhs += coefficient * values[var.VarName]

            sense = constraint.Sense
            rhs = constraint.RHS

            if sense == gp.GRB.LESS_EQUAL:
                violation = max(0.0, lhs - rhs)
            elif sense == gp.GRB.GREATER_EQUAL:
                violation = max(0.0, rhs - lhs)
            elif sense == gp.GRB.EQUAL:
                violation = abs(lhs - rhs)
            else:
                violation = math.inf

            if violation > 1e-7:
                row_violations.append({
                    "row": constraint.ConstrName,
                    "sense": sense,
                    "lhs": lhs,
                    "rhs": rhs,
                    "violation": violation,
                })

        # Evaluate the original linear objective directly from coefficients.
        objective_value = float(model.ObjCon)
        for var in variables:
            objective_value += (
                var.Obj * values[var.VarName]
            )

        objective_violation = max(
            0.0, objective_value - budget
        )

        valid = (
            not unknown_selected_names
            and not bound_violations
            and not integrality_violations
            and not row_violations
            and objective_violation <= 1e-7
        )

        return {
            "available": True,
            "valid": valid,
            "method": (
                "gurobipy read-only direct evaluation; "
                "no optimize or presolve call"
            ),
            "mps_rows_checked": len(model.getConstrs()),
            "mps_variables_checked": len(variables),
            "objective_value": objective_value,
            "budget": budget,
            "objective_violation": objective_violation,
            "unknown_selected_names": unknown_selected_names,
            "bound_violation_count": len(bound_violations),
            "integrality_violation_count": len(
                integrality_violations
            ),
            "row_violation_count": len(row_violations),
            "bound_violations": bound_violations[:20],
            "integrality_violations": (
                integrality_violations[:20]
            ),
            "row_violations": row_violations[:20],
        }

    except Exception as exc:
        return {
            "available": True,
            "valid": None,
            "reason": (
                "untouched-MPS read-only validation failed: "
                f"{exc!r}"
            ),
        }


# =============================================================================
# Main
# =============================================================================

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--mps",
        required=True,
        help="original core4872-1529 MPS or MPS.GZ",
    )
    parser.add_argument(
        "--budget",
        type=int,
        default=DEFAULT_BUDGET,
    )
    parser.add_argument(
        "--seconds",
        type=int,
        default=DEFAULT_SECONDS,
    )
    parser.add_argument(
        "--out",
        default="core4872_1529_v3_result.json",
    )
    parser.add_argument(
        "--no-exact-audit",
        action="store_true",
        help=(
            "disable instance-specific count assertions; "
            "not recommended for the official file"
        ),
    )
    args = parser.parse_args()

    started = time.time()
    deadline = started + max(1, args.seconds)

    result: Dict[str, object] = {
        "program": "core4872_1529_v3.py",
        "budget": args.budget,
        "requested_seconds": args.seconds,
        "source": args.mps,
    }

    # ---------------------------------------------------------------------
    # Parse and assert the exact recovered structure.
    # ---------------------------------------------------------------------
    try:
        inst = parse_core_mps(
            args.mps,
            exact_audit=not args.no_exact_audit,
        )
    except Exception as exc:
        result.update({
            "status": "UNKNOWN",
            "reason": f"MPS parse/audit failed: {exc!r}",
            "elapsed_seconds": time.time() - started,
        })
        print(json.dumps(result, indent=2, sort_keys=True))
        write_result(args.out, result)
        return 2

    result["source_sha256"] = inst.source_sha256
    result["audit"] = {
        "cover_rows": inst.nrows,
        "binary_columns": inst.ncols,
        "cost1_columns": sum(c == 1 for c in inst.costs),
        "cost2_columns": sum(c == 2 for c in inst.costs),
        "expected_cover_rows": EXPECTED_COVER_ROWS,
        "expected_binary_columns": EXPECTED_BINARY_COLUMNS,
        "expected_cost1_columns": EXPECTED_COST1_COLUMNS,
        "expected_cost2_columns": EXPECTED_COST2_COLUMNS,
    }

    # ---------------------------------------------------------------------
    # Safe preprocessing.
    # ---------------------------------------------------------------------
    reduction_status, reduced, reduction_stats = safe_reduce(
        inst,
        args.budget,
    )
    result["reduction"] = reduction_stats

    print(
        "Reduction:",
        json.dumps(reduction_stats, indent=2, sort_keys=True),
    )

    if reduction_status == "PROVED_UNSAT":
        result.update({
            "status": "PROVED_UNSAT",
            "proof_type": (
                "safe preprocessing contradiction"
            ),
            "elapsed_seconds": time.time() - started,
        })
        print(json.dumps(result, indent=2, sort_keys=True))
        write_result(args.out, result)
        return 0

    if reduced is None:
        result.update({
            "status": "UNKNOWN",
            "reason": "preprocessing returned no residual instance",
            "elapsed_seconds": time.time() - started,
        })
        print(json.dumps(result, indent=2, sort_keys=True))
        write_result(args.out, result)
        return 1

    if reduced.nrows == 0:
        selected_original_ids = sorted(
            reduced.forced_original_col_ids
        )
        backend_status = "SAT_MODEL"
        residual_chosen: Optional[List[int]] = []
        solver_stats = {
            "reason": "all rows covered by forced columns",
            "proof_retained": False,
        }
    else:
        backend_status, residual_chosen, solver_stats = (
            solve_with_minicard(reduced, deadline)
        )

    result["solver"] = solver_stats

    # ---------------------------------------------------------------------
    # Process a SAT model.
    # ---------------------------------------------------------------------
    if backend_status == "SAT_MODEL" and residual_chosen is not None:
        residual_original_ids = {
            reduced.original_col_ids[j]
            for j in residual_chosen
        }
        selected_original_ids = sorted(
            reduced.forced_original_col_ids
            | residual_original_ids
        )

        internal_validation = validate_against_parsed_cover(
            inst,
            selected_original_ids,
            args.budget,
        )
        result["parsed_cover_validation"] = internal_validation

        if not internal_validation["valid"]:
            result.update({
                "status": "UNKNOWN",
                "reason": (
                    "SAT model failed full parsed-cover validation"
                ),
                "elapsed_seconds": time.time() - started,
            })
            print(json.dumps(result, indent=2, sort_keys=True))
            write_result(args.out, result)
            return 1

        selected_names = set(
            internal_validation["selected_names"]
        )

        untouched_validation = gurobi_validate_untouched_mps(
            args.mps,
            selected_names,
            args.budget,
        )
        result["untouched_mps_validation"] = untouched_validation

        result["candidate"] = {
            "weight": internal_validation["weight"],
            "selected_count": internal_validation["selected_count"],
            "original_column_ids": selected_original_ids,
            "original_variable_names": (
                internal_validation["selected_names"]
            ),
        }

        if untouched_validation.get("valid") is True:
            result["status"] = "SAT"
            result["reason"] = (
                "candidate validated against every untouched "
                "original-MPS row, all bounds, integrality, and objective"
            )
        elif untouched_validation.get("valid") is False:
            result["status"] = "UNKNOWN"
            result["reason"] = (
                "candidate failed untouched original-MPS validation"
            )
        else:
            result["status"] = "CANDIDATE_SAT"
            result["reason"] = (
                "candidate passed parsed-cover validation, but "
                "untouched-MPS validation was unavailable"
            )

    elif backend_status == "BACKEND_UNSAT":
        result.update({
            "status": "BACKEND_UNSAT",
            "reason": (
                "MiniCard returned UNSAT, but no independently "
                "checked proof certificate was retained"
            ),
            "proof": {
                "retained": False,
                "replayed": False,
                "certified_global_optimality": False,
            },
        })

    else:
        result.update({
            "status": "UNKNOWN",
            "reason": solver_stats.get(
                "reason", "SAT backend returned no decision"
            ),
        })

    result["elapsed_seconds"] = time.time() - started

    print(json.dumps(result, indent=2, sort_keys=True))
    write_result(args.out, result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
