# Run summary: `core4872-1529`

- **Initial audit** Official MPS and public ID 3 solution staged. Gurobi
  read-only extraction confirmed 24,656 variables, 4,875 rows, and the
  4,872-row weighted set-cover core. The incumbent at 1530 passed a full audit.
- **API segment 1** Compared PB/SAT, structural set-cover, and short MIP routes;
  emitted the first PB program. Code review rejected its incidence handling and
  preprocessing complexity before accepting any result.
- **API segment 2** Repaired the PB code. Execution exposed a lowercase RHS
  parser bug and missing `pypblib`; the resulting 4,873-row reduction was
  discarded and marked `UNKNOWN`.
- **API segment 3** Replaced generic PB encoding with an exact MiniCard alias
  construction. The corrected input audit found 4,872 rows and 24,645 binary
  columns. Safe reduction left 4,691 rows, 24,365 columns, and residual budget
  1,447 after 53 forced columns of weight 82. The 900-second search ended
  `UNKNOWN` without a witness or replayable proof.
- **API segment 4** Pivoted to a non-SAT Lagrangian-dual and rare-row-packing
  route. It emitted a valid but weak rounded dual bound 38 and a stronger
  disjoint-row packing bound 932.
- **Independent replay** A separate Gurobi row-matrix verifier, with no call to
  `optimize()`, checked the 692 selected row supports on the untouched MPS:
  zero overlaps, nonnegative objectives/lower bounds, recomputed bound 932,
  zero errors.
- **Final status** `OPEN / NOT PROVED OPTIMAL`; verified bounds `[932,1530]`.

No general-purpose MIP solver optimization was run.
