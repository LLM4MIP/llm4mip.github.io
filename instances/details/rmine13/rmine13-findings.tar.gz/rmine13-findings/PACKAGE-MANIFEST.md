# Package manifest: rmine13

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 99
Excluded source files: 1

## Included files

- `README.md`
- `SHA256SUMS`
- `analysis/gurobi-13.0.1-structure.json`
- `analysis/lagrangian-exact-replay.json`
- `analysis/lagrangian-search.json`
- `artifacts/exact-lb-cert.json.gz`
- `artifacts/exact-lb-lambda.json`
- `artifacts/exact-lb-verification.json`
- `artifacts/multi-cone/capacity-only-diagnostic.json`
- `artifacts/multi-cone/full-boundary0-summary.json`
- `artifacts/multi-cone/full-boundary1-summary.json`
- `artifacts/multi-cone/full-boundary10-summary.json`
- `artifacts/multi-cone/full-boundary11-summary.json`
- `artifacts/multi-cone/full-boundary2-summary.json`
- `artifacts/multi-cone/full-boundary3-summary.json`
- `artifacts/multi-cone/full-boundary4-summary.json`
- `artifacts/multi-cone/full-boundary5-summary.json`
- `artifacts/multi-cone/full-boundary6-summary.json`
- `artifacts/multi-cone/full-boundary7-summary.json`
- `artifacts/multi-cone/full-boundary8-summary.json`
- `artifacts/multi-cone/full-boundary9-summary.json`
- `artifacts/multi-cone/global-master-summary.json`
- `artifacts/multi-cone/retained-seed-exact-audit.json`
- `artifacts/strict-ub-exact-audit.json`
- `artifacts/structure.json`
- `artifacts/triple-cover-screen-result.json`
- `artifacts/triple-cover-screen-validation.json`
- `experiments/extraction-window-0-2/incumbent.sol`
- `experiments/extraction-window-0-2/result.json`
- `experiments/extraction-window-0-2/solver.log`
- `experiments/extraction-window-1-3/incumbent.sol`
- `experiments/extraction-window-1-3/result.json`
- `experiments/extraction-window-1-3/solver.log`
- `experiments/extraction-window-10-12/incumbent-rounded.sol`
- `experiments/extraction-window-10-12/incumbent.sol`
- `experiments/extraction-window-10-12/result.json`
- `experiments/extraction-window-10-12/solver.log`
- `experiments/extraction-window-2-4/incumbent.sol`
- `experiments/extraction-window-2-4/result.json`
- `experiments/extraction-window-2-4/solver.log`
- `experiments/extraction-window-3-5/incumbent.sol`
- `experiments/extraction-window-3-5/result.json`
- `experiments/extraction-window-3-5/solver.log`
- `experiments/extraction-window-4-6/incumbent.sol`
- `experiments/extraction-window-4-6/result.json`
- `experiments/extraction-window-4-6/solver.log`
- `experiments/extraction-window-5-7/incumbent.sol`
- `experiments/extraction-window-5-7/result.json`
- `experiments/extraction-window-5-7/solver.log`
- `experiments/extraction-window-6-8/incumbent.sol`
- `experiments/extraction-window-6-8/result.json`
- `experiments/extraction-window-6-8/solver.log`
- `experiments/extraction-window-7-9/incumbent.sol`
- `experiments/extraction-window-7-9/result.json`
- `experiments/extraction-window-7-9/solver.log`
- `experiments/extraction-window-8-10/incumbent.sol`
- `experiments/extraction-window-8-10/result.json`
- `experiments/extraction-window-8-10/solver.log`
- `experiments/extraction-window-9-11/incumbent.sol`
- `experiments/extraction-window-9-11/result.json`
- `experiments/extraction-window-9-11/solver.log`
- `experiments/extraction-window5-0-4/incumbent.sol`
- `experiments/extraction-window5-0-4/result.json`
- `experiments/extraction-window5-0-4/solver.log`
- `experiments/extraction-window5-3-7/incumbent.sol`
- `experiments/extraction-window5-3-7/result.json`
- `experiments/extraction-window5-3-7/solver.log`
- `experiments/extraction-window5-6-10/incumbent.sol`
- `experiments/extraction-window5-6-10/result.json`
- `experiments/extraction-window5-6-10/solver.log`
- `experiments/extraction-window5-8-12/incumbent.sol`
- `experiments/extraction-window5-8-12/result.json`
- `experiments/extraction-window5-8-12/solver.log`
- `experiments/full-rounded-start/incumbent.sol`
- `experiments/full-rounded-start/result.json`
- `experiments/full-rounded-start/solver.log`
- `input/SHA256SUMS`
- `input/rmine13-public.sol.gz`
- `logs/gurobi-13.0.1-structure.log`
- `logs/lagrangian-exact-replay.log`
- `logs/lagrangian-search.log`
- `logs/public-rounded-strict-exact.log`
- `logs/public-solution-exact.log`
- `logs/window10-12-raw-copt-exact.log`
- `logs/window10-12-rounded-exact.log`
- `reports/structured-search.md`
- `scripts/copt_structured_search.py`
- `scripts/exact_decimal_audit.py`
- `scripts/exact_lagrangian_certificate.py`
- `scripts/exact_mps_solution_check.py`
- `scripts/fixed_rhs_exact_wrapper.py`
- `scripts/gurobi_structure_export.py`
- `scripts/rmine_lagrangian_copt.py`
- `scripts/rmine_lagrangian_exact_replay.py`
- `scripts/run_rmine_windows.sh`
- `solutions/rmine13-public-rounded-strict.sol`
- `solutions/rmine13-strict-rounded.sol`
- `solutions/rmine13-window10-12-raw-copt.sol`
- `solutions/rmine13-window10-12-rounded.sol`

## Excluded files

- `input/rmine13.mps.gz (2938284 bytes; raw benchmark input; sha256 b99d1c9a31d724fade70872d02518e48b1ca60880b21206872303a0d147e4b95)`
