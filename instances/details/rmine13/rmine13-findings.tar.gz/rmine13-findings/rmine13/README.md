#  `rmine13`: strict repair solution, exact closure lower bound and historical experiment archives

The date of the study: 2026 -09 -08.

The official MIPLIB page: < https://miplib.zib.de/instance_details_rmine13.html >

The official MPS: [ download `rmine13.mps.gz` ](https://miplib.zib.de/WebData/instances/rmine13.mps.gz)

##  Current Conclusions

`rmine13`'s globally optimal value remains **open**.
No restricted neighborhood certificate has the best proof of the original problem.

| bound | value | evidence status |
|---|---:|---|
|  strict feasible UB  |  `-3495.3706609999999806509`  | After rounding the public tolerance solution by a variable, recycle it on the original MPS as finite decimal exactly. |
|  strongest recorded numerical LB  |  `-3496.99083`  | COPT 10 hours floating-point dual bound; no portable proof trace |
|  portable exact global LB  |  `-3504.689959073912780`  | Rational Lagrangian maximum-closure certificate, maintaining the feasible integer max-flow with the same capacity cut |

Therefore, the strict intervals for this minimization problem that can be independently checked are:

```text
-3504.689959073912780 <= OPT <= -3495.3706609999999806509.
```

The range width is `9.3192980739127993491`, which is the absolute value of `0.266618%` for strict UB.
COPT's numerical boundary is stronger, and its numerical gap with the relatively strict UB is
`1.6201690000000193491` (`0.046352%`), but it cannot replace the portable exact certificate.

Exact LB in early archives
`-3508.946737452 = -877236684363 / 250000000` is retained as a recyclable result of the experiment;
The `-3504.689959073912780` of the current certificate, which is larger and therefore stronger for minimization problems, has replaced the old value.
Both results are not compatible with the strict UB closure, nor are they.
optimality proof .

##  Context and model structure of problems

`rmine13` belongs to the MineLib open pit mining production scheduling instance.
[MineLib paper ](https://doi.org/10.1007/s10479-012-1258-3). The original model had a 23,980.
`[0,1]` integer variable, 197,155 line and 485,784 nonzero entries, representing 2,197 (`13^3`)
Mining blocks and 13 period.

| row family | count | meaning |
|---|---:|---|
|  spatial precedence `gprec`  |  175,346  | Three-dimensional lateral/spatial backward relations |
|  temporal precedence `tprec`  |  21,783  | The cumulative time chain of the same block |
|  capacity `tcap`  |  26  | Two resource capacity constraints per period |

After removing the 26 bar capacity line, the remaining 197,129 lines are RHS to 0 and the coefficient to `+1/-1`.
Precedence; fixed capacity Sub-problems after multiplication are therefore maximum closure / minimum cut.

The original MPS SHA-256 was designed for
`b99d1c9a31d724fade70872d02518e48b1ca60880b21206872303a0d147e4b95`。
Current list of structures see [`artifacts/structure.json` ](artifacts/structure.json), early structure readings]
The records continue to be kept
[`analysis/gurobi-13.0.1-structure.json`](analysis/gurobi-13.0.1-structure.json)。

##  Strict primal evidence

The public vector objective of the MIPLIB ID 2 is `-3495.3706624382535`, but it is not a strict integer point:
3 is a variable deviating from an integer with a maximum deviation of about `5.8576e-6` and two precedent rows each violating
`5e-9`. original public solution and word-for-word audit respectively
[`input/rmine13-public.sol.gz`](input/rmine13-public.sol.gz) and
[`logs/public-solution-exact.log`](logs/public-solution-exact.log)。

The variable rounding only loses the objective value of `0.0000014382534443491` and gets strict UB.
`-3495.3706609999999806509`. The current canonical solution is
[`solutions/rmine13-strict-rounded.sol`](solutions/rmine13-strict-rounded.sol)，
For the independent Decimal-60 record, see
[`artifacts/strict-ub-exact-audit.json`](artifacts/strict-ub-exact-audit.json)：

```text
exact row violations             0 / 197155
exact bound violations           0
exact integrality violations     0
```

Early strict candidate format of origin/main
[`solutions/rmine13-public-rounded-strict.sol`](solutions/rmine13-public-rounded-strict.sol)
and its audit
[`logs/public-rounded-strict-exact.log`](logs/public-rounded-strict-exact.log) is also retained,
To ensure the traceability of the original experimental inputs and hash records.

##  Currently portable exact lower bound

26 rationalized capacity
[ `artifacts/exact-lb-lambda.json` ](artifacts/exact-lb-lambda.json) . integer max-flow, 
Capacity cut and full rationality witness maintained
[`artifacts/exact-lb-cert.json.gz` ](artifacts/exact-lb-cert.json.gz), whose SHA-256 is
`cdcb5882d1ee03817746325465a7ca473576cff06f5b21aa7f84aef0ba33290b`。

Independent replay returns `verified=true`, scaled flow and cut are equal to
`1231971994479658124406100329`, and given

```text
-876172489768478194996176911 / 250000000000000000000000
  = -3504.689959073912780.
```

Reserved output
`artifacts/exact-lb-verification.json` ](artifacts/exact-lb-verification.json) verification machine
It doesn't call Gurobi/COPT, and it doesn't re-apply for max-flow; it checks model SHA, multiplier non-negative, network.
Capacity, flow capacity and constant, `flow=cut` and ultimately lower bound.

##  Current structured negative results

The following results are exclusion-only candidate groups or neighborhoods that cannot be excluded from globally optimal proof:

-  finite `K=80` pair-conflict screening does not include cut;
-  600 Second triple-cover Screening covers periods 0 - -8, checking the triples of 881,568, including
866,619 with a root LP sum greater than 2, no exact minimal triple cover is found;
-  Non-local one-to-one exchange scan 1,454,216 one pair, three-phase cycle scan 33,628 one, not obtained
While meeting precedence and strict improvement of the two resources;
-  4,800 - column, 18,434 -row multi-cone restricted master Search within seconds of 480.108
2,616,228 node, not found incumbent; this is not a complete master's infeasibility proof;
-  12 single boundary subproblems each use the boundary to generate all 193 - -277 rows at root proof.
strict improvements are infeasible, but not cross-border combinations.

Detailed description and recording of the machine
[`reports/structured-search.md`](reports/structured-search.md)、
[`artifacts/multi-cone/`](artifacts/multi-cone/)、
[`artifacts/triple-cover-screen-result.json` ](artifacts/triple-cover-screen-result.json) and
[`artifacts/triple-cover-screen-validation.json`](artifacts/triple-cover-screen-validation.json)。

##  Origin/main Early experiments archived

All of the following entries remain. They still have calibrated and replicated values, but the old lower bound has been replaced by the 10 clock above.
Numerical boundaries are replaced by new exact certificates.

###  Full-model short run

|  Run |  Time limit |  Status |  incumbent  |  numerical bound  |  nodes  |
|---|---:|---|---:|---:|---:|
| Coordinated cold start without start |  600 s  |  TIME_LIMIT  |  `-3475.085457`  |  `-3502.2642471768054`  |  544  |
| Strict candidate warm start |  600 s  |  TIME_LIMIT  |  `-3495.3706610000013`  |  `-3503.6206933022077`  |  1  |

The results of warm-start and logs are
`experiments/full-rounded-start/` ](experiments/full-rounded-start/).
Not included in the catalog; both lines are floating-point numerical, and both are weaker than the current COPT 10 hourly numerical boundary.

### Consecutive three-period and five-period windows

Three-period windows fix the extraction schedule outside the window. COPT numerically closed 9 of the 11 windows; `[1,3]` and
`[2,4]` with a 90-second limit; none of the strictly feasible incumbents improved. The respective `result.json` files,
`solver.log` and the output solution are maintained under [`experiments/` ](experiments/)
`extraction-window-*` directory

`[10,12]` used to show `-3495.3706614869925`, but the original output of 23 had a non-integer value and a small margin.
Therefore, the surface improvement of about `4.87e-7` is simply the tolerance effect:

- [`solutions/rmine13-window10-12-raw-copt.sol`](solutions/rmine13-window10-12-raw-copt.sol)
- [`logs/window10-12-raw-copt-exact.log`](logs/window10-12-raw-copt-exact.log)
- [`solutions/rmine13-window10-12-rounded.sol`](solutions/rmine13-window10-12-rounded.sol)
- [`logs/window10-12-rounded-exact.log`](logs/window10-12-rounded-exact.log)

The four five-stage windows `[0,4]`, `[3,7]`, `[6,10]`, `[8,12]` are all time-limited and incumbent.
Unchanged; the complete material is in `experiments/extraction-window5-*`.

###  Early Closure Certificate replaced

The best floating-point value for early 300 closure-oracle searches is `-3508.929020352369`.
`analysis/lagrangian-search.json` ](analysis/lagrangian-search.json). The old big integer
replay certificate
[`analysis/lagrangian-exact-replay.json`](analysis/lagrangian-exact-replay.json)
gives:

```text
integer max-flow = recomputed cut    2302599098935
integer selected weight             -2016583787452
closure violations                  0
old exact lower bound               -877236684363 / 250000000
                                    = -3508.946737452
```

The value is still valid at the strict global lower bound, but has been reinforced by the `-3504.689959073912780` strict.

###  Resolve Environment and Licensing Corrections

Earlier formal optimization mainly used COPT 8.0.4 on altman. An older report described Gurobi on euler4 as
The license is described as size-limited; this judgment is incorrect. 2026 -09 -08 has been verified on-site by euler4
**full Gurobi 13.0.1 license**, able to read and optimize the scale model.
COPT runs the fact, but can't use the solver to choose the explanation as the Gurobi license size limit.

## Reproduction

Check the old archive and current key file hash under `instances/rmine13/`:

```sh
sha256sum -c SHA256SUMS
sha256sum -c input/SHA256SUMS
```

The current strict UB verification:

```sh
python scripts/exact_decimal_audit.py \
  --mps input/rmine13.mps.gz \
  --solution solutions/rmine13-strict-rounded.sol \
  --out /tmp/rmine13-strict-ub-audit.json
```

It's a great way to play the game.

```sh
python scripts/exact_lagrangian_certificate.py verify \
  input/rmine13.mps.gz \
  artifacts/exact-lb-cert.json.gz
```

From the reserved multiplier reconstruction to the new certificate:

```sh
python scripts/exact_lagrangian_certificate.py make \
  input/rmine13.mps.gz \
  artifacts/exact-lb-lambda.json \
  /tmp/rmine13-exact-lb-cert.json.gz
```

Replay the old closure certificate:

```sh
python scripts/rmine_lagrangian_exact_replay.py \
  --mps input/rmine13.mps.gz \
  --search-result analysis/lagrangian-search.json \
  --out replay.json \
  --multiplier-places 6 \
  --weight-places 9
```

The expected result of the old replay is `exact_bound_decimal = -3508.946737452` and
`flow_cut_equality_verified = true`. Early exact checker, COPT search and window experiment input
The `scripts/` ](scripts/) and the `experiments/` ](experiments/) remain unchanged.
The results of this study have not yet been proven.
