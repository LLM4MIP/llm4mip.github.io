#!/usr/bin/env python3
"""COPT warm-start and structure-aware neighborhoods for rmine13/set3-09."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
import platform
import re
import time
from pathlib import Path

import coptpy as cp


RMINE_RE = re.compile(r"^x_B(?P<block>\d+)_t(?P<period>\d+)$")
SET3_RE = re.compile(r"^(?P<family>y|w)\((?P<period>\d+),(?P<index>\d+)\)$")


def read_solution(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix == ".gz" else open
    values: dict[str, float] = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as stream:
        for raw in stream:
            fields = raw.split()
            if len(fields) < 2 or fields[0].startswith(("#", "=")):
                continue
            try:
                values[fields[0]] = float(fields[1])
            except ValueError:
                pass
    return values


def digest(path: Path | None) -> str | None:
    if path is None:
        return None
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def attr(model, name, default=None):
    try:
        return getattr(model, name)
    except Exception:
        return default


def finite_float(value):
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def set_param(model, result: dict, parameter, value) -> None:
    label = str(parameter)
    try:
        model.setParam(parameter, value)
        result[label] = value
    except Exception as error:
        result[label] = f"unsupported: {error}"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--start", type=Path)
    parser.add_argument("--pattern", type=Path)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument(
        "--mode",
        choices=(
            "full",
            "rmine-window",
            "rmine-extraction-window",
            "rmine-local-branching",
            "set3-period-window",
            "set3-item-group",
            "set3-local-branching",
            "set3-sibling-start",
            "set3-sibling-fixed",
        ),
        required=True,
    )
    parser.add_argument("--window", help="inclusive a-b interval")
    parser.add_argument("--items", help="comma-separated item ids or inclusive a-b ranges")
    parser.add_argument("--radius", type=int, help="Hamming radius for local branching")
    parser.add_argument("--include-unmined", action="store_true")
    parser.add_argument("--seconds", type=float, default=300.0)
    parser.add_argument("--threads", type=int, default=8)
    parser.add_argument("--aggressive", action="store_true")
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    seed = read_solution(args.start) if args.start else {}
    pattern = read_solution(args.pattern) if args.pattern else {}
    if args.mode != "full" and not seed and args.mode not in {
        "set3-sibling-start", "set3-sibling-fixed"
    }:
        raise ValueError(f"{args.mode} requires --start")
    if args.mode.startswith("set3-sibling") and not pattern:
        raise ValueError(f"{args.mode} requires --pattern")
    interval = None
    if args.window:
        a, b = map(int, args.window.split("-"))
        if a > b:
            raise ValueError("invalid window")
        interval = (a, b)
    free_items: set[int] = set()
    if args.items:
        for token in args.items.split(","):
            if "-" in token:
                a, b = map(int, token.split("-"))
                free_items.update(range(a, b + 1))
            else:
                free_items.add(int(token))

    env = cp.Envr()
    model = env.createModel(f"structured-{args.mode}")
    model.read(str(args.model))
    variables = model.getVars().getAll()

    # Load a dense official target start where available.  For sibling transfer,
    # supply only the binary pattern so COPT can construct target-compatible flows.
    load_return = None
    if args.mode == "set3-sibling-start":
        start_vars = [v for v in variables if v.vtype != cp.COPT.CONTINUOUS]
        start_vals = [float(round(pattern.get(v.name, 0.0))) for v in start_vars]
    elif seed:
        start_vars = variables
        start_vals = [seed.get(v.name, 0.0) for v in variables]
    else:
        start_vars, start_vals = [], []
    if start_vars:
        model.setMipStart(start_vars, start_vals)
        try:
            load_return = repr(model.loadMipStart())
        except Exception as error:
            load_return = f"load error: {error}"

    fixed = 0
    free = 0
    unparsed = 0
    active_blocks: set[int] = set()
    extraction_period: dict[int, int] = {}
    if args.mode == "rmine-extraction-window":
        if interval is None:
            raise ValueError("rmine-extraction-window requires --window")
        period_sets: dict[int, list[int]] = {}
        for variable in variables:
            match = RMINE_RE.match(variable.name)
            if match:
                period_sets.setdefault(int(match.group("block")), []).append(
                    int(match.group("period"))
                )
        sentinel = max(p for periods in period_sets.values() for p in periods) + 1
        for block, periods in period_sets.items():
            ones = [p for p in periods if seed.get(f"x_B{block}_t{p}", 0.0) > 0.5]
            extraction_period[block] = min(ones) if ones else sentinel
            if interval[0] <= extraction_period[block] <= interval[1]:
                active_blocks.add(block)
            elif args.include_unmined and extraction_period[block] == sentinel:
                active_blocks.add(block)

    for variable in variables:
        if variable.vtype == cp.COPT.CONTINUOUS:
            continue
        value_source = pattern if args.mode == "set3-sibling-fixed" else seed
        value = float(round(value_source.get(variable.name, 0.0)))
        should_fix = False
        if args.mode == "rmine-window":
            if interval is None:
                raise ValueError("rmine-window requires --window")
            match = RMINE_RE.match(variable.name)
            if match:
                should_fix = not (interval[0] <= int(match.group("period")) <= interval[1])
            else:
                unparsed += 1
                should_fix = True
        elif args.mode == "rmine-extraction-window":
            match = RMINE_RE.match(variable.name)
            if match:
                block, period = int(match.group("block")), int(match.group("period"))
                should_fix = block not in active_blocks or not (
                    interval[0] <= period <= interval[1]
                )
            else:
                unparsed += 1
                should_fix = True
        elif args.mode == "set3-period-window":
            if interval is None:
                raise ValueError("set3-period-window requires --window")
            match = SET3_RE.match(variable.name)
            if match:
                should_fix = not (interval[0] <= int(match.group("period")) <= interval[1])
            else:
                unparsed += 1
                should_fix = True
        elif args.mode == "set3-item-group":
            if not free_items:
                raise ValueError("set3-item-group requires --items")
            match = SET3_RE.match(variable.name)
            if match and match.group("family") == "y":
                should_fix = int(match.group("index")) not in free_items
            elif match and match.group("family") == "w":
                # Joint family setups are left free so changed item setups can
                # switch their corresponding family on or off.
                should_fix = False
            else:
                unparsed += 1
                should_fix = True
        elif args.mode == "set3-sibling-fixed":
            should_fix = True
        if should_fix:
            variable.setInfo(cp.COPT.Info.LB, value)
            variable.setInfo(cp.COPT.Info.UB, value)
            fixed += 1
        else:
            free += 1

    if args.mode in {"rmine-local-branching", "set3-local-branching"}:
        if args.radius is None or args.radius < 0:
            raise ValueError("local branching requires a nonnegative --radius")
        discrete = [v for v in variables if v.vtype != cp.COPT.CONTINUOUS]
        expression = cp.quicksum(
            (1.0 - v) if seed.get(v.name, 0.0) > 0.5 else v for v in discrete
        )
        model.addConstr(expression <= args.radius, name=f"local_branching_{args.radius}")
        free = len(discrete)

    parameters: dict[str, object] = {}
    model.setLogFile(str(args.outdir / "solver.log"))
    set_param(model, parameters, cp.COPT.Param.Logging, 1)
    set_param(model, parameters, cp.COPT.Param.Threads, args.threads)
    set_param(model, parameters, cp.COPT.Param.TimeLimit, args.seconds)
    set_param(model, parameters, cp.COPT.Param.RelGap, 0.0)
    if hasattr(cp.COPT.Param, "GPUMode"):
        set_param(model, parameters, cp.COPT.Param.GPUMode, 0)
    if hasattr(cp.COPT.Param, "FeasTol"):
        set_param(model, parameters, cp.COPT.Param.FeasTol, 1e-9)
    if args.aggressive:
        for parameter, value in (
            (cp.COPT.Param.HeurLevel, 3),
            (cp.COPT.Param.PreRootHeurLevel, 3),
            (cp.COPT.Param.RoundingHeurLevel, 3),
            (cp.COPT.Param.DivingHeurLevel, 3),
            (cp.COPT.Param.FAPHeurLevel, 4),
            (cp.COPT.Param.SubMipHeurLevel, 3),
            (cp.COPT.Param.MipRepair, 3),
        ):
            set_param(model, parameters, parameter, value)

    started = time.monotonic()
    model.solve()
    wall = time.monotonic() - started
    has_solution = bool(attr(model, "hasmipsol", False))
    if has_solution:
        model.writeSol(str(args.outdir / "incumbent.sol"))

    result = {
        "schema": "rmine-set3-copt-structured-v1",
        "host": platform.node(),
        "copt_version": [
            cp.COPT.VERSION_MAJOR,
            cp.COPT.VERSION_MINOR,
            cp.COPT.VERSION_TECHNICAL,
        ],
        "mode": args.mode,
        "window": list(interval) if interval else None,
        "include_unmined": args.include_unmined,
        "model_sha256": digest(args.model),
        "start_sha256": digest(args.start),
        "pattern_sha256": digest(args.pattern),
        "start_value_count": len(seed),
        "pattern_value_count": len(pattern),
        "load_mip_start_return": load_return,
        "fixed_discrete_variables": fixed,
        "free_discrete_variables": free,
        "unparsed_discrete_variables": unparsed,
        "active_rmine_blocks": len(active_blocks),
        "free_items": sorted(free_items),
        "local_branching_radius": args.radius,
        "parameters": parameters,
        "wall_seconds": wall,
        "status": int(attr(model, "status", -1)),
        "has_solution": has_solution,
        "objective": finite_float(attr(model, "objval")) if has_solution else None,
        "best_bound": finite_float(attr(model, "bestbnd")),
        "relative_gap": finite_float(attr(model, "mipgap")) if has_solution else None,
        "node_count": finite_float(attr(model, "nodecnt", 0.0)),
        "solver_runtime": finite_float(attr(model, "solvingtime", wall)),
        "global_proof_claim": False,
    }
    (args.outdir / "result.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
