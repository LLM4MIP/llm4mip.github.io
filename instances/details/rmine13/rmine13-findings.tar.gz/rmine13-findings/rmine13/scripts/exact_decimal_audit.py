#!/usr/bin/env python3
"""Solver-independent finite-decimal audit of an MPS solution."""

import argparse
import gzip
import json
from decimal import Decimal, getcontext
from pathlib import Path


getcontext().prec = 60


def open_text(path):
    if str(path).endswith(".gz"):
        return gzip.open(path, "rt", encoding="utf-8", errors="strict")
    return open(path, "rt", encoding="utf-8", errors="strict")


def read_solution(path):
    values = {}
    declared = None
    with open_text(path) as handle:
        for raw in handle:
            pieces = raw.split()
            if not pieces or raw.startswith("#"):
                continue
            if pieces[0] == "=obj=":
                declared = Decimal(pieces[-1])
            elif len(pieces) >= 2:
                values[pieces[0]] = Decimal(pieces[1])
    return declared, values


def audit(mps_path, solution_path):
    declared, values = read_solution(solution_path)
    senses, rhs, activity = {}, {}, {}
    objective_row = None
    objective = Decimal(0)
    variable_names = set()
    integer_variables = set()
    bounds = {}
    section = None
    in_integer_section = False

    with open_text(mps_path) as handle:
        for raw in handle:
            pieces = raw.split()
            if not pieces:
                continue
            key = pieces[0]
            if key in {"NAME", "OBJSENSE", "OBJNAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = key
                continue
            if section == "ROWS":
                sense, name = pieces[:2]
                if sense == "N":
                    objective_row = name
                else:
                    senses[name] = sense
                    rhs[name] = Decimal(0)
                    activity[name] = Decimal(0)
            elif section == "COLUMNS":
                if "MARKER" in raw:
                    if "INTORG" in raw:
                        in_integer_section = True
                    elif "INTEND" in raw:
                        in_integer_section = False
                    continue
                variable = pieces[0]
                variable_names.add(variable)
                if in_integer_section:
                    integer_variables.add(variable)
                value = values.get(variable, Decimal(0))
                for pos in range(1, len(pieces), 2):
                    row = pieces[pos]
                    coefficient = Decimal(pieces[pos + 1])
                    if row == objective_row:
                        objective += coefficient * value
                    elif row in activity:
                        activity[row] += coefficient * value
            elif section == "RHS":
                for pos in range(1, len(pieces), 2):
                    row = pieces[pos]
                    if row in rhs:
                        rhs[row] = Decimal(pieces[pos + 1])
                    elif row == objective_row:
                        # In fixed-format MPS an objective-row RHS is an offset.
                        objective -= Decimal(pieces[pos + 1])
            elif section == "RANGES":
                raise ValueError("RANGES are not supported by this independent audit")
            elif section == "BOUNDS":
                bound_type = pieces[0]
                variable = pieces[2]
                value = Decimal(pieces[3]) if len(pieces) > 3 else None
                lb, ub = bounds.get(variable, (Decimal(0), Decimal("Infinity")))
                if bound_type in {"UP", "UI"}:
                    ub = value
                elif bound_type in {"LO", "LI"}:
                    lb = value
                elif bound_type == "FX":
                    lb = ub = value
                elif bound_type == "BV":
                    lb, ub = Decimal(0), Decimal(1)
                elif bound_type == "FR":
                    lb, ub = Decimal("-Infinity"), Decimal("Infinity")
                elif bound_type == "MI":
                    lb = Decimal("-Infinity")
                elif bound_type == "PL":
                    ub = Decimal("Infinity")
                if bound_type in {"BV", "LI", "UI"}:
                    integer_variables.add(variable)
                bounds[variable] = (lb, ub)

    row_violations = []
    for row, sense in senses.items():
        if sense == "L":
            violation = max(Decimal(0), activity[row] - rhs[row])
        elif sense == "G":
            violation = max(Decimal(0), rhs[row] - activity[row])
        else:
            violation = abs(activity[row] - rhs[row])
        if violation:
            row_violations.append((violation, row, activity[row], sense, rhs[row]))
    row_violations.sort(reverse=True)

    bound_violations = []
    integer_violations = []
    for variable in variable_names:
        value = values.get(variable, Decimal(0))
        lb, ub = bounds.get(variable, (Decimal(0), Decimal("Infinity")))
        violation = max(Decimal(0), lb - value, value - ub)
        if violation:
            bound_violations.append((violation, variable, value, lb, ub))
        if variable in integer_variables and value != value.to_integral_value():
            integer_violations.append((abs(value - value.to_integral_value()), variable, value))

    return {
        "arithmetic": "Python Decimal precision 60; MPS and solution tokens parsed directly",
        "mps": str(Path(mps_path).resolve()),
        "solution": str(Path(solution_path).resolve()),
        "declared_objective": str(declared) if declared is not None else None,
        "objective_exact_decimal": str(objective),
        "objective_difference": str(objective - declared) if declared is not None else None,
        "model_variable_count": len(variable_names),
        "integer_variable_count": len(integer_variables),
        "solution_listed_count": len(values),
        "row_count": len(senses),
        "unknown_solution_names": sorted(set(values) - variable_names),
        "missing_solution_names_assumed_zero": len(variable_names - set(values)),
        "max_row_violation_exact": str(max((x[0] for x in row_violations), default=Decimal(0))),
        "violating_row_count": len(row_violations),
        "max_bound_violation_exact": str(max((x[0] for x in bound_violations), default=Decimal(0))),
        "bound_violation_count": len(bound_violations),
        "max_integrality_violation_exact": str(max((x[0] for x in integer_violations), default=Decimal(0))),
        "integrality_violation_count": len(integer_violations),
        "feasible_exact_decimal": not row_violations and not bound_violations and not integer_violations,
        "worst_rows": [[str(a), b, str(c), d, str(e)] for a, b, c, d, e in row_violations[:20]],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", required=True)
    parser.add_argument("--solution", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    result = audit(args.mps, args.solution)
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
