# `rmine13` structured primal and cover search

These experiments deliberately tested structure-aware neighborhoods instead of
spending the whole budget on the original branch-and-bound model.  None found a
strict improvement over `-3495.3706609999999806509`; the result is evidence
about the tested neighborhoods, not a global optimality proof.

## Closure-aware local search

- 1,454,216 cross-period pair swaps were checked; 647,039 improved the
  objective before capacity checking, but none satisfied both resources.
- 20,641 improving closure-frontier pairs were checked; none was feasible.
- 33,628 three-period cycles were checked; 923 improved the objective before
  capacity checking, but none was feasible.
- 240 predecessor-cone insertion/successor-cone pushback trials produced 233
  strictly feasible repaired schedules, but the best was 1.388510 worse than
  the incumbent.
- Twelve short LNS runs returned the seed.

## Two-resource multi-cone restricted master

The global pilot contained 4,800 binary cone columns and 18,434 rows covering
both resource systems, block overlap, combined precedence, and strict objective
improvement.  It searched 2,616,228 nodes in 480.108 seconds and reached its
time limit without a feasible master incumbent.  This does not prove that the
whole 4,800-column master is infeasible.

As a bounded complement, the complete generated column set was partitioned by
the twelve adjacent period boundaries.  Every single-boundary master used all
193--277 applicable columns and retained the complete capacity, overlap and
precedence systems.  All 12 were proved infeasible at the root node.  Thus no
strict improvement exists in any of these twelve precisely defined restricted
neighborhoods.

A capacity-and-overlap-only relaxation found an apparently improving four-cone
combination with objective delta `-0.069232`.  It violated a spatial precedence
arc (block 1733 was advanced ahead of required predecessor 1890), so it was
correctly rejected when the full precedence rows were restored.

The machine-readable summaries are in [`../artifacts/multi-cone/`](../artifacts/multi-cone/).

## Genuine triple-cover screen

A 600-second finite screen covered periods 0--8.  It checked 881,568 triples,
of which 866,619 satisfied `x_i + x_j + x_k > 2` at the root LP point.  It found
no triple for which every proper pair fits both resources while the three-cone
union strictly exceeds a cumulative capacity.  The independent validation is
[`triple-cover-screen-validation.json`](../artifacts/triple-cover-screen-validation.json).

This finite negative result neither rules out higher-order induced covers nor
proves that no triple cover exists outside the screened candidate set.
