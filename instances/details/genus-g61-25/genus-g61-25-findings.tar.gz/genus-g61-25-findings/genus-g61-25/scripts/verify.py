#!/usr/bin/env python3
"""Reproduce the rank-15 genus-g61-25 structural and exact-computation audit."""

from __future__ import annotations

import argparse
import collections
import hashlib
import importlib.util
from pathlib import Path
import re
from xml.etree import ElementTree


NAME = "genus-g61-25"
FACE_SLOTS = tuple(range(58))
SOURCE_TO_MPS = {
    0: 0, 1: 1, 2: 58, 3: 2, 4: 47, 5: 16, 6: 13, 7: 3, 8: 14,
    9: 44, 10: 48, 11: 4, 12: 8, 13: 11, 14: 5, 15: 26, 16: 9,
    17: 24, 18: 6, 19: 52, 20: 25, 21: 27, 22: 7, 23: 38, 24: 53,
    25: 45, 26: 37, 27: 35, 28: 43, 29: 50, 30: 23, 31: 17,
    32: 46, 33: 18, 34: 30, 35: 15, 36: 19, 37: 20, 38: 29,
    39: 28, 40: 12, 41: 10, 42: 40, 43: 33, 44: 39, 46: 32,
    47: 54, 48: 41, 49: 55, 50: 21, 51: 22, 52: 57, 53: 56,
    54: 42, 55: 51, 56: 31, 57: 34, 58: 36, 59: 59, 60: 49,
}


def load_helpers(path: Path):
    spec = importlib.util.spec_from_file_location("genus_artifacts", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def adjacency(vertices: set[int], edges: set[tuple[int, int]]) -> dict[int, set[int]]:
    result = {vertex: set() for vertex in vertices}
    for u, v in edges:
        result[u].add(v)
        result[v].add(u)
    return result


def degree_histogram(graph: dict[int, set[int]]) -> dict[int, int]:
    return dict(sorted(collections.Counter(map(len, graph.values())).items()))


def triangle_count(graph: dict[int, set[int]]) -> int:
    return sum(
        1
        for u in graph
        for v in graph[u]
        for w in graph[u] & graph[v]
        if u < v < w
    )


def parse_graphml(path: Path) -> tuple[set[int], set[tuple[int, int]]]:
    root = ElementTree.parse(path).getroot()
    vertices = {
        int(element.attrib["id"].removeprefix("n"))
        for element in root.iter()
        if element.tag.endswith("node")
    }
    edges = {
        tuple(
            sorted(
                (
                    int(element.attrib["source"].removeprefix("n")),
                    int(element.attrib["target"].removeprefix("n")),
                )
            )
        )
        for element in root.iter()
        if element.tag.endswith("edge")
    }
    if any(u == v for u, v in edges):
        raise AssertionError("Source graph contains a loop")
    return vertices, edges


def suppress_45(
    vertices: set[int], edges: set[tuple[int, int]]
) -> tuple[set[int], set[tuple[int, int]]]:
    vertices, edges = set(vertices), set(edges)
    graph = adjacency(vertices, edges)
    if graph[45] != {42, 48}:
        raise AssertionError(f"Expected N(45)={{42,48}}, got {graph[45]}")
    edges.remove((42, 45))
    edges.remove((45, 48))
    if (42, 48) in edges:
        raise AssertionError("Suppressing 45 would create a parallel edge")
    edges.add((42, 48))
    vertices.remove(45)
    return vertices, edges


def joint_wl_map(
    first: dict[int, set[int]], second: dict[int, set[int]]
) -> tuple[dict[int, int], bool]:
    colors_first = {vertex: len(neighbors) for vertex, neighbors in first.items()}
    colors_second = {vertex: len(neighbors) for vertex, neighbors in second.items()}
    while True:
        signatures_first = {
            vertex: (colors_first[vertex], tuple(sorted(colors_first[n] for n in neighbors)))
            for vertex, neighbors in first.items()
        }
        signatures_second = {
            vertex: (colors_second[vertex], tuple(sorted(colors_second[n] for n in neighbors)))
            for vertex, neighbors in second.items()
        }
        palette = {
            signature: index
            for index, signature in enumerate(
                sorted(set(signatures_first.values()) | set(signatures_second.values()))
            )
        }
        new_first = {vertex: palette[signature] for vertex, signature in signatures_first.items()}
        new_second = {vertex: palette[signature] for vertex, signature in signatures_second.items()}
        if new_first == colors_first and new_second == colors_second:
            break
        colors_first, colors_second = new_first, new_second
    buckets_first: collections.defaultdict[int, list[int]] = collections.defaultdict(list)
    buckets_second: collections.defaultdict[int, list[int]] = collections.defaultdict(list)
    for vertex, color in colors_first.items():
        buckets_first[color].append(vertex)
    for vertex, color in colors_second.items():
        buckets_second[color].append(vertex)
    unique = (
        set(buckets_first) == set(buckets_second)
        and all(len(buckets_first[color]) == len(buckets_second[color]) == 1 for color in buckets_first)
    )
    mapping = {
        buckets_first[color][0]: buckets_second[color][0]
        for color in buckets_first
        if len(buckets_first[color]) == len(buckets_second.get(color, [])) == 1
    }
    return mapping, unique


def transform_face_variable(name: str, a: int, b: int) -> str:
    match = re.fullmatch(r"x(\d+)", name)
    if match:
        index = int(match.group(1))
        if index == a:
            return f"x{b}"
        if index == b:
            return f"x{a}"
        return name
    match = re.fullmatch(r"c(\d+)_(\d+)_(\d+)", name)
    if match:
        index, u, v = map(int, match.groups())
        if index == a:
            index = b
        elif index == b:
            index = a
        return f"c{index}_{u}_{v}"
    return name


def symmetry_audit(model: dict) -> dict:
    rows = [row for row, kind in model["row_type"].items() if kind != "N"]

    def signature(row: str, a: int | None = None, b: int | None = None):
        if a is None:
            terms = tuple(sorted(model["coefficients"][row].items()))
        else:
            terms = tuple(
                sorted(
                    (transform_face_variable(variable, a, b), value)
                    for variable, value in model["coefficients"][row].items()
                )
            )
        return model["row_type"][row], model["rhs"][row], terms

    face_rows: collections.defaultdict[int, set[str]] = collections.defaultdict(set)
    for row in rows:
        for variable in model["coefficients"][row]:
            match = re.fullmatch(r"c(\d+)_(\d+)_(\d+)", variable)
            if match and int(match.group(1)) in FACE_SLOTS:
                face_rows[int(match.group(1))].add(row)
            match = re.fullmatch(r"x(\d+)", variable)
            if match and int(match.group(1)) in FACE_SLOTS:
                face_rows[int(match.group(1))].add(row)

    adjacent_checks = []
    for a in range(57):
        b = a + 1
        affected = face_rows[a] | face_rows[b]
        original = collections.Counter(signature(row) for row in affected)
        transformed = collections.Counter(signature(row, a, b) for row in affected)
        row_invariant = original == transformed
        relevant_variables = {
            variable for row in affected for variable in model["coefficients"][row]
        } | {f"x{a}", f"x{b}"}
        variable_invariant = all(
            transform_face_variable(variable, a, b) in model["variables"]
            for variable in relevant_variables
        )
        domains_invariant = all(
            model["lower"][variable]
            == model["lower"][transform_face_variable(variable, a, b)]
            and model["upper"][variable]
            == model["upper"][transform_face_variable(variable, a, b)]
            and (variable in model["integer"])
            == (transform_face_variable(variable, a, b) in model["integer"])
            for variable in relevant_variables
        )
        objective_invariant = all(
            model["objective"].get(variable, 0.0)
            == model["objective"].get(transform_face_variable(variable, a, b), 0.0)
            for variable in relevant_variables
        )
        adjacent_checks.append(
            (a, b, len(affected), row_invariant, variable_invariant, domains_invariant, objective_invariant)
        )

    parity_coefficients = {f"x{index}": 1.0 for index in FACE_SLOTS}
    parity_coefficients["x14380"] = -2.0
    parity_rows = [
        row
        for row in rows
        if model["coefficients"][row] == parity_coefficients
        and model["row_type"][row] == "E"
        and model["rhs"][row] == 0.0
    ]
    x_only_rows = [
        row
        for row in rows
        if model["coefficients"][row]
        and all(re.fullmatch(r"x\d+", variable) for variable in model["coefficients"][row])
    ]
    expected_objective = {f"x{index}": -1.0 for index in FACE_SLOTS}
    expected_objective["x59"] = -1.0
    return {
        "adjacent_checks": adjacent_checks,
        "all_adjacent_swaps_are_automorphisms": all(all(item[3:]) for item in adjacent_checks),
        "parity_rows": parity_rows,
        "x_only_rows": x_only_rows,
        "objective_exact": model["objective"] == expected_objective,
        "active_face_domains_exact": all(
            model["lower"][f"x{index}"] == 0.0
            and model["upper"][f"x{index}"] == 1.0
            and f"x{index}" in model["integer"]
            for index in FACE_SLOTS
        ),
        "dummy_x59_fixed_zero": model["lower"]["x59"] == model["upper"]["x59"] == 0.0,
        "parity_integer_domain_exact": (
            model["lower"]["x14380"] == 0.0
            and model["upper"]["x14380"] == 29.0
            and "x14380" in model["integer"]
        ),
    }


def exact_log(result: dict, input_code: bytes, mode: str) -> str:
    lines = [
        f"instance={NAME}",
        "algorithm=multi_genus (serial, one process/thread)",
        f"mode={mode}",
        f"command={' '.join(result['command'])}",
        f"stdin=reports/{NAME}.mc",
        f"input_bytes={len(input_code)}",
        f"input_sha256={hashlib.sha256(input_code).hexdigest()}",
        f"timeout_seconds={result['timeout']}",
        f"elapsed_seconds={result['elapsed']:.6f}",
        f"timed_out={result['timed_out']}",
        f"returncode={result['returncode']}",
        f"stdout_bytes={len(result['stdout'])}",
        f"stdout_sha256={hashlib.sha256(result['stdout']).hexdigest()}",
        f"stdout_equals_input_multicode={result['stdout'] == input_code}",
        "stderr_begin",
        result["stderr"].rstrip(),
        "stderr_end",
    ]
    if result["check"] is not None:
        check = result["check"]
        lines.extend(
            [
                f"rotation_edge_exact={check['edge_exact']}",
                f"rotation_faces={len(check['faces'])}",
                f"rotation_face_lengths={sorted(map(len, check['faces']))}",
                f"rotation_dart_total={check['dart_total']}",
                f"rotation_genus={check['genus']}",
            ]
        )
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser()
    instance_root = Path(__file__).resolve().parents[1]
    repository_root = Path(__file__).resolve().parents[3]
    parser.add_argument("--source-graph", type=Path, required=True)
    parser.add_argument("--multi-genus", type=Path, required=True)
    parser.add_argument("--timeout", type=float, default=600.0)
    parser.add_argument("--solve", choices=("none", "full", "decision", "both"), default="both")
    args = parser.parse_args()
    if not (0.0 < args.timeout <= 600.0):
        raise ValueError("timeout must be in (0,600]")

    helper = load_helpers(repository_root / "common" / "reproduce_genus_artifacts.py")
    reports, logs = instance_root / "artifacts", instance_root / "logs"
    reports.mkdir(exist_ok=True)
    logs.mkdir(exist_ok=True)
    model_path = instance_root / "input" / f"{NAME}.mps.gz"
    solution_path = instance_root / "solutions" / "official-40.sol.gz"
    source_path = args.source_graph

    model = helper.parse_mps(model_path)
    values, claimed = helper.parse_solution(solution_path)
    validation = helper.validate_solution(model, values)
    official_rotation = helper.rotation_from_solution(model, values)
    official_check = helper.check_rotation(model, official_rotation)
    official_faces = helper.check_face_assignment(model, values, official_rotation)

    source_vertices, source_edges = parse_graphml(source_path)
    core_vertices, core_edges = suppress_45(source_vertices, source_edges)
    source_graph, core_graph = adjacency(source_vertices, source_edges), adjacency(core_vertices, core_edges)
    mps_graph = model["adjacency"]
    mapped_edges = {
        tuple(sorted((SOURCE_TO_MPS[u], SOURCE_TO_MPS[v]))) for u, v in core_edges
    }
    provenance_exact = mapped_edges == model["edges"] and core_vertices == set(SOURCE_TO_MPS)
    wl_mapping, wl_unique = joint_wl_map(core_graph, mps_graph)
    wl_mapping_exact = wl_unique and wl_mapping == SOURCE_TO_MPS
    if not provenance_exact or not wl_mapping_exact:
        raise AssertionError("North-source core mapping failed")

    symmetry = symmetry_audit(model)
    if not all(
        (
            symmetry["all_adjacent_swaps_are_automorphisms"],
            len(symmetry["parity_rows"]) == 1,
            symmetry["x_only_rows"] == symmetry["parity_rows"],
            symmetry["objective_exact"],
            symmetry["active_face_domains_exact"],
            symmetry["dummy_x59_fixed_zero"],
            symmetry["parity_integer_domain_exact"],
        )
    ):
        raise AssertionError(f"No-symmetry audit failed: {symmetry}")

    input_code = helper.multicode(model)
    (reports / f"{NAME}.mc").write_bytes(input_code)
    (reports / f"{NAME}.official-rotation.txt").write_text(
        helper.rotation_text(NAME, "official MIPLIB incumbent solution", model, official_rotation)
    )
    page_lines = [f"{len(model['adjacency'])} {len(model['edges'])}"]
    for vertex in range(len(model["adjacency"])):
        order = official_rotation[vertex]
        page_lines.append(" ".join(map(str, order + [65535] * (7 - len(order)))))
    (reports / f"{NAME}.page-official-rotation-adjacency.txt").write_text(
        "\n".join(page_lines) + "\n"
    )
    (reports / f"{NAME}.north-to-mps.tsv").write_text(
        "# North GraphML vertex -> MPS core vertex\n"
        + "\n".join(f"{source}\t{mps}" for source, mps in sorted(SOURCE_TO_MPS.items()))
        + "\n"
    )

    results: dict[str, dict] = {}
    if args.solve in ("full", "both"):
        print("starting serial full minimum-genus run", flush=True)
        result = helper.run_multi_genus(args.multi_genus, model, args.timeout, ["w"])
        results["full"] = result
        (logs / f"{NAME}.multi-genus-600s.log").write_text(
            exact_log(result, input_code, "minimum-genus embedding")
        )
        if result["check"] is not None:
            (reports / f"{NAME}.exact-rotation.txt").write_text(
                helper.rotation_text(NAME, "serial multi_genus exact run", model, result["rotation"])
            )
        print(
            f"full run finished: elapsed={result['elapsed']:.6f}, timed_out={result['timed_out']}",
            flush=True,
        )
    if args.solve in ("decision", "both"):
        print("starting serial genus-at-most-9 exclusion run", flush=True)
        result = helper.run_multi_genus(args.multi_genus, model, args.timeout, ["l9", "F"])
        results["decision"] = result
        (logs / f"{NAME}.multi-genus-decision-gt-9-600s.log").write_text(
            exact_log(result, input_code, "exclude orientable genus <=9")
        )
        print(
            f"decision run finished: elapsed={result['elapsed']:.6f}, timed_out={result['timed_out']}",
            flush=True,
        )

    full_exact = (
        "full" in results
        and not results["full"]["timed_out"]
        and results["full"]["returncode"] == 0
        and results["full"]["check"] is not None
        and results["full"]["check"]["edge_exact"]
        and results["full"]["check"]["genus"] == 10
    )
    decision_exact = (
        "decision" in results
        and not results["decision"]["timed_out"]
        and results["decision"]["returncode"] == 0
        and results["decision"]["stdout"] == input_code
        and "With genus larger than 9: 1" in results["decision"]["stderr"]
    )

    audit_lines = [
        f"instance={NAME}",
        f"model_sha256={helper.sha256(model_path)}",
        f"solution_sha256={helper.sha256(solution_path)}",
        f"north_graphml_sha256={helper.sha256(source_path)}",
        f"mps_variables={len(model['variables'])}",
        f"mps_constraints={sum(kind != 'N' for kind in model['row_type'].values())}",
        f"mps_graph_vertices={len(mps_graph)}",
        f"mps_graph_edges={len(model['edges'])}",
        f"mps_degree_histogram={degree_histogram(mps_graph)}",
        f"mps_triangle_count={triangle_count(mps_graph)}",
        f"north_vertices={len(source_vertices)}",
        f"north_edges={len(source_edges)}",
        f"north_degree_histogram={degree_histogram(source_graph)}",
        f"north_unique_degree2_vertices={[v for v, n in source_graph.items() if len(n) == 2]}",
        f"north_vertex45_neighbors={sorted(source_graph[45])}",
        "core_reduction=suppress vertex 45 and replace 42-45-48 by edge 42-48",
        f"core_vertices={len(core_vertices)}",
        f"core_edges={len(core_edges)}",
        f"north_to_mps_edge_exact={provenance_exact}",
        f"joint_wl_colors_unique={wl_unique}",
        f"joint_wl_map_matches_saved_map={wl_mapping_exact}",
        f"objective_exactly_minus_usable_faces_plus_fixed_dummy={symmetry['objective_exact']}",
        f"dummy_x59_fixed_zero={symmetry['dummy_x59_fixed_zero']}",
        f"x_only_rows={symmetry['x_only_rows']}",
        f"parity_rows={symmetry['parity_rows']}",
        "parity_equation=sum(x0..x57)-2*x14380=0",
        "precedence_rows=none",
        f"all_57_adjacent_face_label_swaps_are_full_model_automorphisms={symmetry['all_adjacent_swaps_are_automorphisms']}",
        f"adjacent_swap_checks={symmetry['adjacent_checks']}",
        f"claimed_objective={claimed}",
        f"computed_objective={validation['objective']}",
        f"max_bound_violation={validation['max_bound_violation']}",
        f"max_integrality_violation={validation['max_integrality_violation']}",
        f"max_row_violation={validation['max_row_violation']}",
        f"official_rotation_edge_exact={official_check['edge_exact']}",
        f"official_rotation_faces={len(official_check['faces'])}",
        f"official_rotation_face_lengths={sorted(map(len, official_check['faces']))}",
        f"official_rotation_darts={official_check['dart_total']}",
        f"official_rotation_genus={official_check['genus']}",
        f"official_face_assignment_exact_dart_set_match={official_faces['exact_dart_set_match']}",
        "euler_relation=genus=(2-60+118-F)/2=(60-F)/2",
        f"full_exact_computation_closed_genus10={full_exact}",
        f"decision_computation_proved_genus_gt9={decision_exact}",
        f"exact_optimum_closed_this_run={decision_exact or full_exact}",
        "certificate_caveat=genus-10 official rotation is directly checkable; any exact lower bound is executable exhaustive evidence unless a separate proof certificate is generated",
    ]
    (logs / f"{NAME}.rank15-audit.log").write_text("\n".join(audit_lines) + "\n")
    print(f"full_exact={full_exact}")
    print(f"decision_exact={decision_exact}")
    print(f"exact_optimum_closed={decision_exact or full_exact}")


if __name__ == "__main__":
    main()
