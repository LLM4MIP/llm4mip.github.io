#!/usr/bin/env python3
"""Run one bounded, serial PAGE-low-memory audit for genus-g61-25."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import os
from pathlib import Path
import re
import subprocess
import time


NAME = "genus-g61-25"


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def parse_and_check_output(text: str, model: dict, helper) -> dict | None:
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    header_index = next(
        (index for index, line in enumerate(lines) if line.startswith("Solution with ")),
        None,
    )
    if header_index is None:
        return None
    match = re.fullmatch(
        r"Solution with (\d+) cycles \(genus (\d+)\) found in (\d+) iterations:",
        lines[header_index],
    )
    if match is None:
        raise AssertionError(f"Unexpected PAGE header: {lines[header_index]}")
    face_count, claimed_genus, iterations = map(int, match.groups())
    face_lines = lines[header_index + 1 : header_index + 1 + face_count]
    if len(face_lines) != face_count:
        raise AssertionError("PAGE output has too few face rows")
    faces = [list(map(int, line.split())) for line in face_lines]
    if any(len(face) < 2 or face[0] != face[-1] for face in faces):
        raise AssertionError("PAGE emitted a nonclosed facial walk")

    expected_darts = {
        (u, v) for u, neighbors in model["adjacency"].items() for v in neighbors
    }
    output_darts = [
        (face[index], face[index + 1])
        for face in faces
        for index in range(len(face) - 1)
    ]
    if len(output_darts) != len(set(output_darts)):
        raise AssertionError("PAGE face list repeats a directed edge")
    if set(output_darts) != expected_darts:
        raise AssertionError("PAGE face list is not an exact directed-edge partition")

    next_neighbor: dict[int, dict[int, int]] = {
        vertex: {} for vertex in model["adjacency"]
    }
    for face in faces:
        cycle = face[:-1]
        for index, vertex in enumerate(cycle):
            predecessor = cycle[index - 1]
            successor = cycle[(index + 1) % len(cycle)]
            old = next_neighbor[vertex].setdefault(predecessor, successor)
            if old != successor:
                raise AssertionError("Inconsistent rotation transition")
    rotation = {}
    for vertex, neighbors in model["adjacency"].items():
        transitions = next_neighbor[vertex]
        if set(transitions) != neighbors or set(transitions.values()) != neighbors:
            raise AssertionError(f"Incomplete rotation at {vertex}")
        start = min(neighbors)
        order = [start]
        while transitions[order[-1]] != start:
            order.append(transitions[order[-1]])
            if len(order) > len(neighbors):
                raise AssertionError(f"Noncyclic rotation at {vertex}")
        if len(order) != len(neighbors):
            raise AssertionError(f"Short rotation at {vertex}")
        rotation[vertex] = order
    rotation_check = helper.check_rotation(model, rotation)
    output_face_sets = {frozenset(
        (face[index], face[index + 1]) for index in range(len(face) - 1)
    ) for face in faces}
    traced_face_sets = {frozenset(face) for face in rotation_check["faces"]}
    if output_face_sets != traced_face_sets:
        raise AssertionError("PAGE face rows differ from independently traced faces")
    if rotation_check["genus"] != claimed_genus or len(rotation_check["faces"]) != face_count:
        raise AssertionError("PAGE header disagrees with Euler/face tracing")
    return {
        "face_count": face_count,
        "claimed_genus": claimed_genus,
        "iterations": iterations,
        "dart_count": len(output_darts),
        "rotation": rotation,
        "rotation_check": rotation_check,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    instance_root = Path(__file__).resolve().parents[1]
    repository_root = Path(__file__).resolve().parents[3]
    parser.add_argument("--page", type=Path, required=True)
    parser.add_argument("--timeout", type=float, default=600.0)
    parser.add_argument("--glb", type=int)
    args = parser.parse_args()
    if not (0.0 < args.timeout <= 600.0):
        raise ValueError("timeout must be in (0,600]")
    if args.glb is not None and not (0 <= args.glb <= 10):
        raise ValueError("glb must be between 0 and the certified upper bound 10")

    helper = load(repository_root / "common" / "reproduce_genus_artifacts.py", "genus_artifacts")
    model = helper.parse_mps(instance_root / "input" / f"{NAME}.mps.gz")
    input_path = (instance_root / "artifacts" / f"{NAME}.page-official-rotation-adjacency.txt").resolve()
    suffix = "no-glb" if args.glb is None else f"glb{args.glb}"
    stdout_path = instance_root / "artifacts" / f"{NAME}.page-low-mem-{suffix}.out"
    stderr_path = instance_root / "logs" / f"{NAME}.page-low-mem-{suffix}.stderr.log"
    metadata_path = instance_root / "logs" / f"{NAME}.page-low-mem-{suffix}-600s.log"

    environment = os.environ.copy()
    environment.update(
        {
            "S": "0",
            "DEG": "7",
            "ADJ": str(input_path),
            "STDOUT": "1",
            "THREADS": "1",
            "CG_THREADS": "1",
        }
    )
    if args.glb is None:
        environment.pop("GLB", None)
    else:
        environment["GLB"] = str(args.glb)
    command = [str(args.page.resolve())]
    print(
        "starting PAGE low-memory exact search with "
        + ("GLB unset" if args.glb is None else f"GLB={args.glb}"),
        flush=True,
    )
    started = time.monotonic()
    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=environment,
        cwd=instance_root / "artifacts",
    )
    try:
        stdout, stderr = process.communicate(timeout=args.timeout)
        timed_out = False
    except subprocess.TimeoutExpired:
        process.kill()
        stdout, stderr = process.communicate()
        timed_out = True
    elapsed = time.monotonic() - started
    stdout_path.write_bytes(stdout)
    stderr_path.write_bytes(stderr)

    checked = None
    parse_error = None
    if not timed_out and process.returncode == 0:
        try:
            checked = parse_and_check_output(stdout.decode("utf-8"), model, helper)
        except Exception as error:  # preserve a failed independent check in the log
            parse_error = f"{type(error).__name__}: {error}"

    lines = [
        f"instance={NAME}",
        "algorithm=PAGE page_low_mem (serial implementation)",
        f"command={' '.join(command)}",
        "environment_S=0",
        "environment_DEG=7",
        f"environment_ADJ={input_path}",
        "environment_STDOUT=1",
        "environment_THREADS=1",
        "environment_CG_THREADS=1",
        f"environment_GLB={'UNSET' if args.glb is None else args.glb}",
        "input_order=independently-verified official genus-10 rotation",
        f"input_sha256={helper.sha256(input_path)}",
        f"page_binary_sha256={helper.sha256(args.page)}",
        f"timeout_seconds={args.timeout}",
        f"elapsed_seconds={elapsed:.6f}",
        f"timed_out={timed_out}",
        f"returncode={process.returncode}",
        f"stdout_bytes={len(stdout)}",
        f"stdout_sha256={sha(stdout)}",
        f"stderr_bytes={len(stderr)}",
        f"stderr_sha256={sha(stderr)}",
        f"independent_output_check_error={parse_error}",
        f"independent_output_check_passed={checked is not None}",
    ]
    if checked is not None:
        lines.extend(
            [
                f"output_faces={checked['face_count']}",
                f"output_genus={checked['claimed_genus']}",
                f"output_iterations={checked['iterations']}",
                f"output_darts={checked['dart_count']}",
                f"rotation_edge_exact={checked['rotation_check']['edge_exact']}",
                f"rotation_genus={checked['rotation_check']['genus']}",
            ]
        )
        (instance_root / "artifacts" / f"{NAME}.page-exact-rotation-{suffix}.txt").write_text(
            helper.rotation_text(
                NAME, "PAGE low-memory exact output", model, checked["rotation"]
            )
        )
    metadata_path.write_text("\n".join(lines) + "\n")
    print(f"PAGE finished: elapsed={elapsed:.6f}, timed_out={timed_out}", flush=True)
    print(f"independent_output_check_passed={checked is not None}", flush=True)


if __name__ == "__main__":
    main()
