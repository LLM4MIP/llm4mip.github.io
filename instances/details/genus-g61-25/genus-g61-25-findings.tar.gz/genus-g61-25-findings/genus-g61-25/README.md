# `genus-g61-25`

## Result

The official objective **-40** solution is independently checked and yields a
40-face rotation, corresponding to orientable genus **10**. The MPS graph is
exactly matched to the genus-preserving core of the North graph `g.61.25`.

The latest local exact proof improves the original-MPS lower bound to **-42**
(genus at least 9), without relying on the published genus-8 computation.
A complete tree excludes every rotation with at least 44 faces: 3,803 nodes,
1,902 exact leaves, zero pending nodes. Independent catalogue, branch-coverage,
and integer leaf checks passed. The separately audited original-MPS implication
and even face parity transfer this to the original formulation.

The remaining interval is **[-42, -40]**; the subsequent 42-face search is
incomplete. The -40 original-MPS witness is checked at tolerance `1e-6` because
of rounded thirds; no zero-tolerance rational witness claim is made here.
See the [latest report](../../docs/ten-instance-results-2026-09-06.zh.md#genus-g61-25),
[complete compressed proof](../../studies/ten-instance-2026-09-06/genus-priority/certificates/g61-44-exclusion.tar.gz),
and [replay instructions](../../studies/ten-instance-2026-09-06/README.md).

The older PAGE/search report below is retained as historical evidence, not the
current bound.

## Provenance

- Compressed MPS SHA-256: `F601E791F656D3CD6769180CFCBBCE22AEDBFB411B439D012BE90031FF5277B0`
- Official compressed solution SHA-256: `046E705A0EDDCBD66AD62A3DF04C6490D26A5C155F5685D1585F9762DB03F6C9`
- [MIPLIB instance page](https://miplib.zib.de/instance_details_genus-g61-25.html)

Use [`scripts/verify.py`](scripts/verify.py) for the graph and solution audits;
[`scripts/run_page.py`](scripts/run_page.py) records the PAGE experiment setup.
See the [full report](reports/structural-investigation.md),
[`artifacts/`](artifacts/), and [`logs/`](logs/). Time-limited runs are retained
as negative evidence only.
