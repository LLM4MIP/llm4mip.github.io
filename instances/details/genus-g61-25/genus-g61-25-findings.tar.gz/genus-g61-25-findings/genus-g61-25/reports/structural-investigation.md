# Rank 15: `genus-g61-25`

## Disposition

This investigation does **not** close the instance. The defensible result is

\[
8 \leq \gamma(G) \leq 10,
\]

where \(\gamma\) is orientable genus. The upper bound 10 is backed by a
locally and independently checked rotation system. The lower bound 8 is a
computational result reported for the exactly matched North graph in the
companion data to Chimani--Wiedera (ESA 2019); its original proof trace was
not available or replayed here. Three serial specialized searches, each capped
at 600 seconds, failed to finish an exact lower-bound proof.

For the MIP, the same statement is

\[
\min z = 2\gamma(G)-60 \in \{-44,-42,-40\}.
\]

The official incumbent `-40` is feasible and means genus 10, but it is not
proved optimal.

## Verified MPS semantics

The official MPS has 14,380 variables and 94,735 constraints. Its indexed
families consist of 13,688 variables `c_i_u_v` (58 face slots times 236
directed darts), 632 local rotation variables `p_u_v_w`, and 60 `x` variables.
The `c0_u_v` index set recovers a simple connected graph with

- 60 vertices, 118 undirected edges, and 236 directed darts;
- degree histogram `{3: 28, 4: 19, 5: 5, 6: 5, 7: 3}`;
- six triangles.

The cited SEA 2016 formulation establishes the rotation/face-partition
semantics. Locally, the variable index sets and all rows were parsed, and the
official assignment was reconstructed both as a rotation and as face-dart
sets, providing a direct check that these semantics agree with this MPS.

There are 58 usable binary face indicators `x0,...,x57`. The objective is

\[
-\sum_{i=0}^{57}x_i-x_{59},
\]

and `x59` is fixed to zero. The only row containing only `x` variables is the
exact equality

\[
\sum_{i=0}^{57}x_i-2x_{14380}=0,
\]

where `x14380` is integer in `[0,29]`. Thus the number \(F\) of selected faces
is even and the effective objective is `-F`. Euler's formula gives

\[
60-118+F=2-2g,
\qquad
g=\frac{60-F}{2},
\qquad
z=-F=2g-60.
\]

These identities explain exactly why objective `-40` means 40 faces and
orientable genus 10.

## The missing symmetry breaking

MIPLIB reports zero precedence rows, and the model indeed has no ordering
constraints on its 58 face slots. The audit applied every adjacent face-label
swap \(i\leftrightarrow i+1\) simultaneously to `x_i` and all `c_i_u_v`.
For all 57 swaps, the complete multiset of typed rows, coefficients, and
right-hand sides was unchanged, as were variable domains, integrality, and
objective coefficients. Since adjacent swaps generate \(S_{58}\), the model
has full face-label symmetry.

Consequently, adding

\[
x_0\ge x_1\ge\cdots\ge x_{57}
\]

would be WLOG: any feasible face partition can relabel its active slots first.
This is a concrete explanation for why the unsymmetrized MPS is a poor vehicle
for a short generic solve. No direct Gurobi optimization run was spent on this
instance; the available time was used on graph-specific exact algorithms.

## Exact North-graph provenance

MIPLIB identifies the source as Stephen C. North's undirected graph
`g.61.25`. The preserved GraphML source has 61 vertices and 119 edges, with
degree histogram `{2: 1, 3: 28, 4: 19, 5: 5, 6: 5, 7: 3}`. Vertex 45 is the
unique degree-2 vertex and has neighbors 42 and 48. Suppressing the path
`42-45-48` to the edge `42-48` produces a 60-vertex, 118-edge graph.

The saved 60-vertex map sends every edge of that reduced graph to an MPS edge
and vice versa. Joint Weisfeiler--Leman refinement gives 60 singleton colors
and independently recovers exactly the saved map. Hence this is an exact
isomorphism, not a degree-sequence guess. Subdividing or suppressing a
degree-2 vertex preserves orientable genus, so the North source graph and the
MPS graph have the same minimum genus.

The source file `g.61.25.graphml` is not redistributed here; download it from
the North Graph Archive source below and pass it to the verifier with
`--source-graph`. The complete label map is
`../artifacts/genus-g61-25.north-to-mps.tsv`; the recovered graph is in
`../artifacts/genus-g61-25.adjacency.txt` and `.mc`.

## Official incumbent and checkable upper certificate

The official sparse solution, with omitted variables interpreted as zero,
was evaluated against every MPS row and variable domain:

- claimed and recomputed objective: `-40`;
- bound and integrality violations: zero;
- largest row residual: `9.992007221626409e-16`;
- unknown variables: none.

The positive `p` variables reconstruct a cyclic neighbor order at every
vertex. Tracing this rotation uses every one of the 236 darts exactly once and
produces 40 faces, with lengths

```text
3,3,3,3,3,3,4,4,4,4,4,4,
5,5,5,5,5,5,5,5,5,6,6,6,6,6,6,
7,7,7,7,7,9,9,9,9,9,10,10,13.
```

The positive `c_i_u_v` variables agree exactly with those traced face-dart
sets. The graph is connected and Euler's formula therefore gives genus 10.
The full cyclic orders are in `genus-g61-25.official-rotation.txt`. This is a
small, portable, directly checkable certificate of \(\gamma(G)\leq10\).

## Literature lower bound and its boundary

The `north.csv` row named `g.61.25` in the result archive accompanying
Chimani--Wiedera's ESA 2019 work reports lower bound 8 and the then-current
upper bound 29; its runtime fields are blank. Because the exact North-to-MPS
core mapping above is proved and degree-2 suppression preserves genus, that
reported bound transfers to this MPS graph.

This audit treats `8` as an externally trusted computational result. The
archive was not preserved locally, and no proof log or independently checkable
certificate for that lower bound was supplied. Neither the ESA paper nor the
earlier SEA 2016 paper was found to claim genus 10 for this exact graph.
MIPLIB likewise still marks the instance open and lists `-40` only as the
best-known feasible value (submitted by Local-MIP in 2024). Thus the
literature supports the interval 8--10, not an exact genus-10 claim.

Sources:

- [MIPLIB instance page](https://miplib.zib.de/instance_details_genus-g61-25.html)
- [Chimani--Wiedera, *Stronger ILPs for the Graph Genus Problem* (ESA 2019)](https://doi.org/10.4230/LIPIcs.ESA.2019.30)
- [official experimental result archive](https://tcs.uos.de/_media/research/genus/results.zip)
- [Osnabrueck minimum-genus project page](https://tcs.uos.de/research/min-genus)
- [Beyer et al., *A Practical Method for the Minimum Genus of a Graph* (SEA 2016)](https://doi.org/10.1007/978-3-319-38851-9_6)
- [Graph Drawing data collections](https://www.graphdrawing.org/data.html)

## Bounded specialized exact computation

All long attempts were serial and capped at 600 seconds. They were run
sequentially, never concurrently.

| Attempt | Exact task | Outcome at the cap |
|---|---|---|
| Brinkmann `multi_genus w` | compute minimum genus and a rotation | timed out after `600.004057` s, with no output |
| PAGE `page_low_mem`, no `GLB` | search from genus 0 using the certified genus-10 rotation as upper bound | timed out after `600.004264` s while still testing genus 0; progress reached 210,000,000 states |
| PAGE `page_low_mem`, `GLB=8` | use the matched published lower bound and test genera 8 and 9 | timed out after `600.003768` s while still testing genus 8 (44 faces); progress reached 142,000,000 states |

Both PAGE runs used the explicit environment `THREADS=1` and `CG_THREADS=1`.
The targeted run's diagnostic begins `Beginning lazy genus search between 8
and 10` and never reports completion of genus 8. Its standard output is empty,
so it supplies no rotation and no lower-bound certificate. A preliminary
20-second `multi_genus l9 F` decision probe also timed out without output and
is retained only as a diagnostic, not as one of the substantive attempts.

Brinkmann's paper describes the exact minimum-orientable-genus algorithm used
by `multi_genus`: [arXiv:2005.08243](https://arxiv.org/abs/2005.08243) and
[Ars Mathematica Contemporanea 22 (2022), P4.01](https://doi.org/10.26493/1855-3974.2320.c2d).
The exact sources came from the
[`SanderGi/Genus` repository](https://github.com/SanderGi/Genus), which also
contains PAGE; source, build, input, and log hashes are pinned in the source
fingerprint.

## What is proved, and what remains

Locally checkable facts are the MPS objective identity, the source/core graph
isomorphism, and the genus-10 rotation. Accepting the external ESA 2019 data
adds the computational lower bound 8. None of the local exhaustive searches
finished, so they add no lower bound. In particular, neither 8 nor 9 was
excluded locally, and `-40` must not be called optimal.

The clean exact closure is the decision problem \(\gamma(G)\leq9\),
equivalently whether the MPS can have at least 42 faces (objective at most
`-42`). A longer completed `multi_genus l9 F` run or a completed PAGE search
of genera 8 and 9 would give executable exhaustive evidence. For a portable
certificate, encode the same rotation/face decision as SAT or PB and refute it
with a checked DRAT/LRAT/VeriPB proof. A MIP-specific alternative is to add the
proved-WLOG 58-slot ordering chain and the cutoff `sum x_i >= 42`, but a solver
timeout or heuristic failure would not constitute a proof.

## Reproduction artifacts

- `../scripts/verify.py`: structural, symmetry, provenance, and incumbent
  audit; optional bounded `multi_genus` runner.
- `../scripts/run_page.py`: bounded serial PAGE runner with independent parsing
  of any returned face/rotation witness.
- `../artifacts/genus-g61-25.adjacency.txt` and `.mc`: recovered graph.
- `../artifacts/genus-g61-25.north-to-mps.tsv`: exact source-to-MPS map.
- `../artifacts/genus-g61-25.official-rotation.txt`: directly checkable genus-10 witness.
- `../artifacts/genus-g61-25.page-official-rotation-adjacency.txt`: PAGE input carrying the
  same verified upper-bound rotation.
- `../logs/genus-g61-25.rank15-audit.log`: full structural audit.
- `../logs/genus-g61-25.literature-bound-audit.log`: exact instance match and
  externally reported bound, with the missing-local-archive caveat.
- `../logs/genus-g61-25.multi-genus-600s.log`: full exact-run timeout.
- `../logs/genus-g61-25.page-low-mem-600s.log` and
  `../logs/genus-g61-25.page-low-mem.stderr.log`: unseeded PAGE metadata and
  progress.
- `../logs/genus-g61-25.page-low-mem-glb8-600s.log` and
  `../logs/genus-g61-25.page-low-mem-glb8.stderr.log`: targeted PAGE metadata
  and complete progress stream.
- `../artifacts/genus-g61-25.source-fingerprint.txt`: input, source, build, and log hashes.
