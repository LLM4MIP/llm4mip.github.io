# `cdc7-4-3-2`

## Result

The verified solution selects a constant-dimension subspace code of size **307**, represented by MPS objective **-307**. The best global objective bound obtained is `-381`; global optimality remains open.

An exact conflict-graph enumeration proves that the 307-code solution has no improving exchange of the following sizes:

- remove at most 1 and add 2;
- remove at most 2 and add 3;
- remove at most 3 and add 4;
- remove at most 4 and add 5.

The 5→6 enumeration did not finish within its time limit, so the certificate stops at 4→5.

## Input

- SHA-256: `7CB233A7B3DF00065EBE43AFF1E991FF2884E5DEFA8CC951B0C568AB25A754F4`
- Model: 11,811 binary variables, 14,478 set-packing rows, 259,842 nonzeros.
- MIPLIB metadata: [instance page](https://miplib.zib.de/instance_details_cdc7-4-3-2.html)

## Reproduce the exchange certificate

```powershell
python .\instances\cdc7-4-3-2\scripts\cdc_exchange_proof.py `
  .\instances\cdc7-4-3-2\input\cdc7-4-3-2.mps.gz `
  .\instances\cdc7-4-3-2\solutions\cdc7-4-3-2-known307.sol `
  --max-remove 4
```

Raw solver baselines and the run with the public start are under [`logs/`](logs/).
