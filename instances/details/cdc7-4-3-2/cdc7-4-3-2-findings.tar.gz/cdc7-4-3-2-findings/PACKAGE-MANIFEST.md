# Package manifest: cdc7-4-3-2

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 8
Excluded source files: 1

## Included files

- `README.md`
- `logs/cdc7-4-3-2-copt-baseline.log`
- `logs/cdc7-4-3-2-gurobi-baseline.log`
- `logs/cdc7-4-3-2-known307-gurobi.log`
- `scripts/cdc_exchange_proof.py`
- `solutions/cdc7-4-3-2-known307.sol`
- `solutions/cdc7-4-3-2-known307.sol.gz`
- `solutions/cdc7-4-3-2-verified307.sol`

## Excluded files

- `input/cdc7-4-3-2.mps.gz (1211994 bytes; raw benchmark input; sha256 7cb233a7b3df00065ebe43aff1e991ff2884e5defa8cc951b0c568ab25a754f4)`
