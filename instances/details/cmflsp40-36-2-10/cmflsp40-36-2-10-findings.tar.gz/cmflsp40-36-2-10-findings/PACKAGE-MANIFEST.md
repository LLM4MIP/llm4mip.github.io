# Package manifest: cmflsp40-36-2-10

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 20
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/all-item-pairs-900s.json`
- `artifacts/fixed-family-600s.json`
- `artifacts/global-bound-1200s.json`
- `artifacts/period-neighborhoods-900s.json`
- `artifacts/public-rounded-fixed-repair.json`
- `artifacts/strict-incumbent-independent-audit.json`
- `artifacts/structure-public-audit.json`
- `artifacts/summary.json`
- `input/SHA256SUMS`
- `input/cmflsp40-36-2-10-public.sol.gz`
- `logs/fixed-family-600s.log`
- `logs/global-bound-1200s.log`
- `logs/public-rounded-fixed-repair.log`
- `reports/SOURCES.md`
- `reports/deep-study-2026-09-08.zh.md`
- `scripts/cmflsp_fixed_family.py`
- `scripts/cmflsp_item_neighborhoods.py`
- `scripts/cmflsp_period_neighborhoods.py`
- `solutions/strict-repaired.sol`

## Excluded files

- `input/cmflsp40-36-2-10.mps.gz (1827007 bytes; raw benchmark input; sha256 67feea0a3062236342c707977553a54fc09c56e67e8ce608b1df6fcd3fd4ccb1)`
