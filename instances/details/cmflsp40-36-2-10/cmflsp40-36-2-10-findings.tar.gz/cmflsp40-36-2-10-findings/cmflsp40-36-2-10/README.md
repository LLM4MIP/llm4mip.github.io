# cmflsp40-36-2-10 — strict incumbent and 985 exact neighborhoods

2026-09-14 independent dual-bound review: [adopted bound, proof chain, checks, and limitations](../../docs/dual-bound-audit-2026-09-14/cases/cmflsp40-36-2-10.zh.md). Reviewed lower bound: **approximately 65928415.306808524**. Numerical support is accepted with the missing original global runner noted. This review distinguishes exact, literature, and numerical evidence; historical statements below remain dated records.

Official MIPLIB page: <https://miplib.zib.de/instance_details_cmflsp40-36-2-10.html>

## Result

This study does not claim a new primal improvement or global optimum.  The
MIPLIB tolerance solution has objective about `66,452,234.49456009`, but its
near-integer values contain deviations around `7.5e-7`.  Rounding all 1,512
integer variables and reoptimizing the 26,640 continuous variables gives the
strict point:

```text
strict objective       66,452,236.45360000
maximum row violation       2.27e-13
bound/integrality violation 0
```

Because this strict value is worse than the tolerance-accepted MIPLIB value,
it is not listed as an incumbent improvement.

## Recovered structure

The multi-family capacitated lot-sizing formulation contains 40 items, 36
periods and two families:

- 1,440 binary item-period setup variables `Y`;
- 72 binary family-period setup variables `Z`;
- 26,640 continuous extended-requirement variables `X`;
- 4,266 rows and 386,432 nonzeros.

## Exact neighborhood study

Starting from the strict point, two complete fix-and-optimize scans were made:

- all 40 single-item and all 780 two-item blocks: 820/820 subproblems closed
  to optimality with no improvement; every trial left all family variables and
  all continuous recourse variables free;
- every contiguous period window of width 2 through 6: 165/165 subproblems
  closed to optimality with no improvement; every trial freed all setup
  variables in the window and all continuous recourse variables.

These are exact local results in their stated neighborhoods, not a global
proof.  A 600-second fixed-family search ended with gap `0.0194%`; a
1,200-second global run ended with bound `65,928,415.30680852` and gap
`0.7883%`.

The complete report is
[`deep-study-2026-09-08.zh.md`](reports/deep-study-2026-09-08.zh.md), and the
aggregated trials are archived in
[`all-item-pairs-900s.json`](artifacts/all-item-pairs-900s.json) and
[`period-neighborhoods-900s.json`](artifacts/period-neighborhoods-900s.json).

Input hashes are in [`input/SHA256SUMS`](input/SHA256SUMS).
