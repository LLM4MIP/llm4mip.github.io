from __future__ import annotations

import argparse
import gzip
import itertools
import json
import math
import time
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def read_values(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix == ".gz" else open
    values: dict[str, float] = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
        for raw in handle:
            if not raw.strip() or raw.lstrip().startswith("#"):
                continue
            fields = raw.split()
            if len(fields) >= 2:
                try:
                    values[fields[0]] = float(fields[1])
                except ValueError:
                    pass
    return values


def audit(model: gp.Model) -> dict[str, float | int]:
    max_bound = max_integer = max_row = 0.0
    row_count = 0
    for variable in model.getVars():
        max_bound = max(max_bound, variable.LB - variable.X, variable.X - variable.UB, 0.0)
        if variable.VType in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT):
            max_integer = max(max_integer, abs(variable.X - round(variable.X)))
    for constraint in model.getConstrs():
        row = model.getRow(constraint)
        activity = math.fsum(row.getCoeff(k) * row.getVar(k).X for k in range(row.size()))
        if constraint.Sense == GRB.LESS_EQUAL:
            violation = max(activity - constraint.RHS, 0.0)
        elif constraint.Sense == GRB.GREATER_EQUAL:
            violation = max(constraint.RHS - activity, 0.0)
        else:
            violation = abs(activity - constraint.RHS)
        max_row = max(max_row, violation)
        row_count += violation > 1e-9
    return {"max_bound_violation": max_bound, "max_integrality_violation": max_integer, "max_row_violation": max_row, "row_violations_over_1e_9": row_count}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("seed", type=Path)
    parser.add_argument("summary", type=Path)
    parser.add_argument("solution_out", type=Path)
    parser.add_argument("--per-trial", type=float, default=20.0)
    parser.add_argument("--total-time", type=float, default=1200.0)
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--pair-limit", type=int, default=40)
    args = parser.parse_args()

    started = time.monotonic()
    base = gp.read(str(args.mps))
    seed = read_values(args.seed)
    incumbent = base.ObjCon + math.fsum(v.Obj * seed.get(v.VarName, 0.0) for v in base.getVars())
    best_values = dict(seed)
    setup_cost = {i: base.getVarByName(f"Y_{i}_1").Obj for i in range(1, 41)}
    singles = [(i,) for i in range(1, 41)]
    # Enumerate every two-item block, not only adjacent or high-cost pairs.
    # setup_cost is retained in the reportable model recovery above, but pair
    # coverage is deliberately complete.
    pairs = list(itertools.combinations(range(1, 41), 2))
    neighborhoods = singles + pairs[: args.pair_limit]

    trials = []
    improvements = []
    for trial_index, free_items in enumerate(neighborhoods):
        elapsed = time.monotonic() - started
        if elapsed >= args.total_time:
            break
        model = base.copy()
        variables = model.getVars()
        free_set = set(free_items)
        for variable in variables:
            value = best_values.get(variable.VarName, 0.0)
            variable.Start = value
            if variable.VarName.startswith("Y_"):
                item = int(variable.VarName.split("_")[1])
                if item not in free_set:
                    rounded = round(value)
                    variable.LB = rounded
                    variable.UB = rounded
        model.Params.OutputFlag = 0
        model.Params.Threads = args.threads
        model.Params.TimeLimit = min(args.per_trial, max(1.0, args.total_time - elapsed))
        model.Params.MIPFocus = 1
        model.Params.FeasibilityTol = 1e-9
        model.Params.IntFeasTol = 1e-9
        model.Params.MIPGap = 1e-9
        model.optimize()
        trial = {
            "index": trial_index,
            "free_items": list(free_items),
            "status": int(model.Status),
            "status_name": {GRB.OPTIMAL: "OPTIMAL", GRB.TIME_LIMIT: "TIME_LIMIT", GRB.INFEASIBLE: "INFEASIBLE"}.get(model.Status, str(model.Status)),
            "runtime": model.Runtime,
            "nodes": model.NodeCount,
            "solutions": model.SolCount,
            "objective": model.ObjVal if model.SolCount else None,
            "bound": model.ObjBound,
        }
        trials.append(trial)
        if model.SolCount and model.ObjVal < incumbent - 1e-7:
            previous = incumbent
            incumbent = model.ObjVal
            best_values = {variable.VarName: variable.X for variable in variables}
            improvements.append({"trial": trial_index, "free_items": list(free_items), "previous": previous, "objective": incumbent})

    final = base.copy()
    for variable in final.getVars():
        variable.Start = best_values.get(variable.VarName, 0.0)
    final.Params.OutputFlag = 0
    final.Params.SolutionLimit = 1
    final.Params.FeasibilityTol = 1e-9
    final.Params.IntFeasTol = 1e-9
    final.optimize()
    if final.SolCount and final.ObjVal <= incumbent + 1e-6:
        incumbent = final.ObjVal
        best_values = {variable.VarName: variable.X for variable in final.getVars()}
        final.write(str(args.solution_out))

    report = {
        "instance": "cmflsp40-36-2-10",
        "method": "exact fix-and-optimize over complete item setup blocks; all X recourse and all family Z variables remain free",
        "initial_objective": base.ObjCon + math.fsum(v.Obj * seed.get(v.VarName, 0.0) for v in base.getVars()),
        "final_objective": incumbent,
        "elapsed": time.monotonic() - started,
        "trials": trials,
        "trial_count": len(trials),
        "optimal_trials": sum(row["status"] == GRB.OPTIMAL for row in trials),
        "time_limit_trials": sum(row["status"] == GRB.TIME_LIMIT for row in trials),
        "improvements": improvements,
        "final_audit": audit(final) if final.SolCount else None,
    }
    args.summary.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in report.items() if key != "trials"}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
