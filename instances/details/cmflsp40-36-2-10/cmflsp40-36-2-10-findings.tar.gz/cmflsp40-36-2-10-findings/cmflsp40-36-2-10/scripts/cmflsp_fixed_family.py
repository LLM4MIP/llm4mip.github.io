from __future__ import annotations

import argparse
import json
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def read_values(path: Path) -> dict[str, float]:
    values: dict[str, float] = {}
    with path.open("rt", encoding="utf-8", errors="replace") as handle:
        for raw in handle:
            if raw.lstrip().startswith("#"):
                continue
            fields = raw.split()
            if len(fields) >= 2:
                try:
                    values[fields[0]] = float(fields[1])
                except ValueError:
                    pass
    return values


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("seed", type=Path)
    parser.add_argument("summary", type=Path)
    parser.add_argument("log", type=Path)
    parser.add_argument("solution_out", type=Path)
    parser.add_argument("--time-limit", type=float, default=600.0)
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    model = gp.read(str(args.mps))
    start = read_values(args.seed)
    fixed = 0
    for variable in model.getVars():
        value = start.get(variable.VarName, 0.0)
        variable.Start = value
        if variable.VarName.startswith("Z_"):
            value = round(value)
            variable.LB = value
            variable.UB = value
            fixed += 1
    model.Params.LogFile = str(args.log)
    model.Params.TimeLimit = args.time_limit
    model.Params.Threads = args.threads
    model.Params.MIPFocus = 3
    model.Params.Cuts = 3
    model.Params.FeasibilityTol = 1e-9
    model.Params.IntFeasTol = 1e-9
    model.Params.MIPGap = 1e-9
    model.optimize()
    report = {"instance": "cmflsp40-36-2-10", "method": "fix all 72 family-period activation variables Z; optimize all 1,440 item-period setups Y and 26,640 extended-requirement X variables", "fixed_family_variables": fixed, "status": int(model.Status), "status_name": {GRB.OPTIMAL: "OPTIMAL", GRB.TIME_LIMIT: "TIME_LIMIT"}.get(model.Status, str(model.Status)), "runtime": model.Runtime, "nodes": model.NodeCount, "solutions": model.SolCount, "objective": model.ObjVal if model.SolCount else None, "bound": model.ObjBound, "gap": model.MIPGap if model.SolCount else None}
    if model.SolCount:
        model.write(str(args.solution_out))
    args.summary.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
