#  cmflsp40-36-2-10 in-depth study report ((2026 -09 -08))

## Conclusion

This round found no strictly feasible solution better than the MIPLIB tolerance solution, nor proof globally optimal.

```text
MIPLIB publishes objective value 66,452,234.49456009
strict Repaired objective value 66,452,236.45360000
1200 second global dual bound 65,928,415.30680852
0.7883 % for strict incumbent
```

Here, a distinction must be made: the MIPLIB declaration value is acceptable under the default tolerance, but there is a small deviation of about `7.5e-7` when directly reversing the original MPS; the objective variation after the integer variable strict is given is about `1.95904`. Therefore this round cannot claim primal improvement.

##  1. Gurobi Structure Reading and the Context of the Problem

-  28,152 is a variable, 4,266 is a constraint, 386,432 is a nonzero entry.
-  1,512 is a 0 / 1 integer variable, 26,640 is a continuous variable.
-  1,350 equation and 2,916 equation are smaller than constraint.
-  `Y_i_t`: 40 × 36 = 1,440 is an item-period setup variable.
-  `Z_f_t`: 2 × 36 = 72 is a family-period setup variable.
-  `X_i_s_t`: 26,640 is an extended-requirement variable for production/demand coverage.
-  The constraint names are `Balance`, `Setup1`, `Setup2`, `Capacidad`.

MIPLIB classifies it as capacitated multi-family lot-sizing. Arias and Gatica (2018) discuss similar issues in MF-TRAD, MF-ARBNET and MF-EXREQ formulation; the variable dimension and the line name in this instance are consistent with the extended-requirement style.

##  2. Published solution strict

The published solution has objective approximately `66,452,234.49456` and maximum variable-bound/row deviation approximately `7.4e-7`. Rounding and fixing all 1,512 integer variables, then optimizing all 26,640 continuous `X` variables, gives:

- objective value `66,452,236.4536` ; 
-  The maximum variable boundary default to `0`;
-  the maximum integrality of the default of the `0`;
-  the maximum row violation `2.27e-13`;
-  There is no default greater than `1e-9`.

The solution is a strict benchmark for all subsequent neighborhood and global experiments.

## 3 . item block complete enumeration neighborhood

For each trial, fix item setup `Y` outside the neighborhood, release all 36 `Y` variables for selected items and all 72 family setup `Z` variables, and release all 26,640 continuous `X` variables. This is not a simple variable flip: every trial reoptimizes all continuous recourse and the global family layer.

The full enumeration is:

-  40 is a single item block;
-  `C(40,2)=780` is a double item block;
-  820 is a neighborhood.

820 / 820 were both requested by Gurobi exact to OPTIMAL, without any improvement, with a total use time of about 359 seconds. Therefore, strict incumbent is locally optimal for all single item and double item setup blocks.

## 4 . contiguous period neighborhood

Fix `Y/Z` outside the window, release all item/family setups within 2, 3, 4, 5, or 6 consecutive periods, and release all `X` variables again. Exhaustively enumerate all such windows over the 36 periods:

- A total of 165 windows;
-  165 / 165 exact is obtained from OPTIMAL;
-  No improvements;
-  The average time of use is about 215 seconds.

So the incumbent rearranges the continuous period setup for all lengths 2 6 to be locally optimal.

##  5 . fixed family pattern large neighborhood

Fix only the 72 `Z_f_t` variables, while jointly optimizing all 1,440 item-setup `Y` variables and 26,640 `X` variables. This neighborhood is much larger than the previous two groups. After 600 seconds:

```text
incumbent  66,452,236.45360000
bound      66,439,354.39233170
gap                      0.0194%
nodes                    13,556
```

No better solution has been found, but no complete closure, so it is not possible to conclude that the optimal solution under the fixed family pattern is already proof. It still indicates that the current solution is strong in this large neighborhood, and the remaining evidence gap is less than 0.02 %.

##  6. global running distance

The original model used strict tolerance, enhanced cuts and bound-oriented search to run 1,200 seconds:

```text
incumbent  66,452,236.45360000
dual bound 65,928,415.30680852
gap                       0.7883%
nodes                      1,296
```

There is no new solution. Global bound is obviously better than complete without analysis, but still not good enough to prove MIPLIB deployment or strict correction optimal.

##  7. The resulting boundary

This round can be strictly stated:

-  constitute an incumbent without a `1e-9` default;
-  It is the exact locally optimal of the entire 820 one/two item block neighborhood;
-  It is the exact locally optimal of the entire 165 length 2 6 continuous period neighborhood;
-  After the fixed family setup, the remaining gap in the big neighborhood 600 second is `0.0194%`;
-  The global gap in the second 1,200 is `0.7883%`.

This round can't claim:

-  There are primal improvements compared to MIPLIB;
-  The problem has been proven to be globally optimal.
-  Global optimum under the proof fixed family pattern.

##  8. Key files

- strict incumbent:  `../solutions/strict-repaired.sol`
-  Independent original MPS audit: `../artifacts/strict-incumbent-independent-audit.json`
-  820 One item neighborhood: `../artifacts/all-item-pairs-900s.json`
-  165 a period neighborhood: `../artifacts/period-neighborhoods-900s.json`
-  Fixed-family Large neighborhood: `../artifacts/fixed-family-600s.json`
-  1,200 seconds global search: `../artifacts/global-bound-1200s.json`
- Experiment code: `../scripts/cmflsp_item_neighborhoods.py`, `../scripts/cmflsp_period_neighborhoods.py`, `../scripts/cmflsp_fixed_family.py`

##  9. Next suggestion

The most promising direction is not to continue with smaller LNSs, but to decomposition or logical Benders for the 72 family-period setup: take `Z` as the master, `Y/X` as the subproblem, and extract cuts from capacity shortfall and setup coupling.
