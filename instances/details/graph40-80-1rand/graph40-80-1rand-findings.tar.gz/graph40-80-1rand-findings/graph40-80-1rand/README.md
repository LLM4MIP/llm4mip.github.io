# `graph40-80-1rand`

## Result

**Original-MPS optimum: -7.** The problem packs pairwise edge-disjoint nonempty
graph cuts. The -7 feasible witness passes a zero-tolerance original-model check.
Eight cuts are impossible, certified by a complete Boolean LRAT proof.

The full chain is: audit all 1,050,112 original rows and 283,648 variables;
rebuild the 4,696-variable, 32,388-clause eight-cut CNF; verify its exact LRAT
refutation (2,050 lemmas); validate the -7 witness. The original 512 edge IDs
include 431 distinct unordered endpoint pairs; the original multiplicities are
handled by the audited encoding, not silently discarded.

- [Complete CNF, LRAT and original-MPS audit](../../studies/ten-instance-2026-09-06/hour-pass/graph-proof/)
- [Full-chain checker](../../studies/ten-instance-2026-09-06/hour-pass/verify_graph_certificate.py)
- [Portable replay instructions and dependency scope](../../studies/ten-instance-2026-09-06/README.md)
- [Verified official witness](solutions/official-best.sol.gz)
- [MIPLIB metadata](https://miplib.zib.de/instance_details_graph40-80-1rand.html)
- Input SHA-256: `4a1243b6d5b81367c9d6ae6512be8dc79974a1115e2aa40d5e5393928a67ee33`

LRAT checking alone proves the archived CNF unsatisfiable; the original-model
audit and CNF reconstruction are also required for the MPS optimality claim.
The full-chain checker uses Gurobi for **reading only**, not optimization.
