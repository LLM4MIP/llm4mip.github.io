import argparse
import gzip
import json
import os
from decimal import Decimal, InvalidOperation, ROUND_HALF_EVEN


def open_text(path):
    if path.lower().endswith('.gz'):
        return gzip.open(path, 'rt', encoding='utf-8', errors='replace')
    return open(path, 'r', encoding='utf-8', errors='replace')


def integer_columns(model_path):
    integer = set()
    section = None
    in_integer_block = False
    with open_text(model_path) as handle:
        for raw in handle:
            line = raw.rstrip('\n\r')
            if not line or line.startswith('*'):
                continue
            tokens = line.split()
            if not tokens:
                continue
            head = tokens[0].upper()
            if head in {'NAME', 'ROWS', 'COLUMNS', 'RHS', 'RANGES', 'BOUNDS', 'SOS', 'ENDATA', 'OBJSENSE', 'OBJNAME'}:
                section = head
                if head != 'COLUMNS':
                    in_integer_block = False
                continue
            if section == 'COLUMNS':
                upper = [t.strip("'\"").upper() for t in tokens]
                if 'MARKER' in upper:
                    if 'INTORG' in upper:
                        in_integer_block = True
                    elif 'INTEND' in upper:
                        in_integer_block = False
                    continue
                if in_integer_block:
                    integer.add(tokens[0].strip("'\""))
            elif section == 'BOUNDS' and len(tokens) >= 3:
                bound_type = tokens[0].upper()
                variable = tokens[2].strip("'\"")
                if bound_type in {'BV', 'LI', 'UI', 'SI'}:
                    integer.add(variable)
    return integer


def read_solution(path):
    comments = []
    values = []
    with open(path, 'r', encoding='utf-8', errors='replace') as handle:
        for raw in handle:
            stripped = raw.strip()
            if not stripped:
                continue
            if stripped.startswith('#'):
                comments.append(stripped)
                continue
            tokens = stripped.split()
            if len(tokens) < 2:
                continue
            name = tokens[0]
            try:
                value = Decimal(tokens[1])
            except InvalidOperation:
                continue
            values.append((name, value))
    return comments, values


def decimal_text(value):
    if value == 0:
        return '0'
    text = format(value, 'f')
    if '.' in text:
        text = text.rstrip('0').rstrip('.')
    return text if text not in {'', '-0'} else '0'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', required=True)
    parser.add_argument('--source', required=True)
    args = parser.parse_args()

    integer = integer_columns(args.model)
    comments, values = read_solution(args.source)
    repaired = []
    adjusted = 0
    max_adjustment = Decimal(0)
    integer_values_seen = 0
    for name, value in values:
        new_value = value
        if name in integer:
            integer_values_seen += 1
            new_value = value.to_integral_value(rounding=ROUND_HALF_EVEN)
            delta = abs(new_value - value)
            if delta != 0:
                adjusted += 1
                if delta > max_adjustment:
                    max_adjustment = delta
        repaired.append((name, new_value))

    with open('best.sol', 'w', encoding='utf-8', newline='\n') as out:
        out.write('# MPS-aware integer projection of a solver incumbent\n')
        out.write('# Continuous variables are preserved verbatim in decimal value.\n')
        for name, value in repaired:
            out.write(f'{name} {decimal_text(value)}\n')

    report = {
        'method': 'MPS-aware exact integer projection',
        'source': os.path.basename(args.source),
        'declared_integer_columns': len(integer),
        'solution_values': len(values),
        'integer_values_seen': integer_values_seen,
        'adjusted_integer_values': adjusted,
        'maximum_absolute_adjustment': str(max_adjustment),
        'claim': 'candidate_only_requires_independent_checker'
    }
    with open('repair_report.json', 'w', encoding='utf-8') as out:
        json.dump(report, out, indent=2, sort_keys=True)
    with open('method_result.json', 'w', encoding='utf-8') as out:
        json.dump(report, out, indent=2, sort_keys=True)


if __name__ == '__main__':
    main()
