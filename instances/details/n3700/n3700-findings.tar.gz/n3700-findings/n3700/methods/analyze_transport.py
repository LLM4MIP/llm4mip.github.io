#!/usr/bin/env python3
"""Solver-independent MPS analyzer for the n3700 fixed-charge transportation structure."""
import argparse, collections, gzip, json, math, os, re


def opener(path):
    return gzip.open(path, "rt", encoding="utf-8", errors="replace") if path.endswith(".gz") else open(path, "rt", encoding="utf-8", errors="replace")


def stats(vals):
    if not vals:
        return {"count": 0}
    s = sorted(vals)
    n = len(s)
    return {"count": n, "min": s[0], "max": s[-1], "mean": sum(s)/n,
            "median": s[n//2] if n % 2 else (s[n//2-1]+s[n//2])/2,
            "distinct": len(set(s))}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    args = ap.parse_args()
    section = None
    row_type = {}
    objrow = None
    rhs = collections.defaultdict(float)
    cols = collections.defaultdict(dict)
    integer_mode = False
    integer_cols = set()
    binary_cols = set()
    lower = collections.defaultdict(float)
    upper = {}
    with opener(args.model) as f:
        for raw in f:
            line = raw.rstrip("\n\r")
            if not line or line.startswith("*"):
                continue
            tok = line.split()
            if not tok:
                continue
            head = tok[0].upper()
            if head in {"NAME","ROWS","COLUMNS","RHS","RANGES","BOUNDS","ENDATA","OBJSENSE","OBJNAME"}:
                section = head
                if head == "ENDATA": break
                continue
            if section == "ROWS" and len(tok) >= 2:
                row_type[tok[1]] = tok[0].upper()
                if tok[0].upper() == "N" and objrow is None: objrow = tok[1]
            elif section == "COLUMNS":
                if len(tok) >= 3 and tok[1].strip("'\"").upper() == "MARKER":
                    marker = tok[-1].strip("'\"").upper()
                    integer_mode = marker == "INTORG" if marker in {"INTORG","INTEND"} else integer_mode
                    continue
                var = tok[0]
                if integer_mode: integer_cols.add(var)
                for k in range(1, len(tok)-1, 2):
                    try: cols[var][tok[k]] = cols[var].get(tok[k], 0.0) + float(tok[k+1])
                    except ValueError: pass
            elif section == "RHS" and len(tok) >= 3:
                for k in range(1, len(tok)-1, 2):
                    try: rhs[tok[k]] = float(tok[k+1])
                    except ValueError: pass
            elif section == "BOUNDS" and len(tok) >= 3:
                bt, var = tok[0].upper(), tok[2]
                val = float(tok[3]) if len(tok) > 3 else None
                if bt == "BV": binary_cols.add(var); integer_cols.add(var); lower[var]=0.0; upper[var]=1.0
                elif bt in {"UP","UI"}: upper[var]=val
                elif bt in {"LO","LI"}: lower[var]=val
                elif bt == "FX": lower[var]=val; upper[var]=val
                elif bt == "FR": lower[var]=-math.inf; upper[var]=math.inf
                elif bt == "MI": lower[var]=-math.inf
                elif bt == "PL": upper[var]=math.inf
    constr_rows = [r for r,t in row_type.items() if t != "N"]
    row_entries = collections.defaultdict(list)
    obj = {}
    for v, ent in cols.items():
        for r,a in ent.items():
            if r == objrow: obj[v]=a
            elif r in row_type: row_entries[r].append((v,a))
    continuous = set(cols) - integer_cols
    row_nnz_by_type = collections.defaultdict(list)
    for r in constr_rows: row_nnz_by_type[row_type[r]].append(len(row_entries[r]))
    col_nnz = {v: sum(1 for r in ent if r != objrow) for v,ent in cols.items()}
    col_profiles = {}
    for label, vs in [("binary", binary_cols), ("integer_nonbinary", integer_cols-binary_cols), ("continuous", continuous)]:
        prof = collections.Counter()
        for v in vs:
            senses = tuple(sorted(row_type[r] for r in cols[v] if r in row_type and row_type[r] != "N"))
            prof[str(senses)] += 1
        col_profiles[label] = {k:v for k,v in prof.most_common()}
    # Identify two-variable inequalities that look like flow-capacity links a*x + b*y <= 0.
    links=[]
    for r in constr_rows:
        es=row_entries[r]
        if row_type[r] == "L" and len(es)==2 and abs(rhs.get(r,0.0)) < 1e-12:
            b=[(v,a) for v,a in es if v in binary_cols]
            c=[(v,a) for v,a in es if v in continuous]
            if len(b)==1 and len(c)==1:
                links.append({"row":r,"binary":b[0][0],"binary_coef":b[0][1],"continuous":c[0][0],"continuous_coef":c[0][1]})
    capacities=[]
    normalized=[]
    for z in links:
        cb,cc=z["binary_coef"],z["continuous_coef"]
        if cc != 0:
            # cc*y + cb*x <= 0; canonical y <= U*x when cc>0, cb<0.
            U=-cb/cc
            capacities.append(U)
            normalized.append((z["continuous"],z["binary"],U))
    eq_rows=[r for r in constr_rows if row_type[r]=="E"]
    eq_rhs=[rhs.get(r,0.0) for r in eq_rows]
    eq_nnz=[len(row_entries[r]) for r in eq_rows]
    eq_abscoef=collections.Counter(abs(a) for r in eq_rows for _,a in row_entries[r])
    # Continuous variables' equality incidence; in a transportation matrix each arc occurs in two balances.
    cont_eq_degree=collections.Counter()
    for v in continuous:
        cont_eq_degree[sum(1 for r in cols[v] if row_type.get(r)=="E")]+=1
    # Row grouping signatures help infer source/destination counts and duplicated symmetry.
    eq_signatures=collections.Counter((len(row_entries[r]), tuple(sorted(collections.Counter(a for _,a in row_entries[r]).items()))) for r in eq_rows)
    name_prefix=collections.Counter()
    for v in cols:
        m=re.match(r"([^0-9]*)(?:[0-9].*)?$",v)
        name_prefix[m.group(1) if m else ""] += 1
    pair_obj=[]
    for cv,bv,U in normalized:
        pair_obj.append({"capacity":U,"flow_cost":obj.get(cv,0.0),"fixed_cost":obj.get(bv,0.0)})
    report={
      "model_name":"n3700",
      "abstraction_evidence":{
        "variables":len(cols),"binary":len(binary_cols),"continuous":len(continuous),
        "rows":len(constr_rows),"objective_row":objrow,
        "row_counts":dict(collections.Counter(row_type[r] for r in constr_rows)),
        "row_nnz_stats_by_sense":{k:stats(v) for k,v in row_nnz_by_type.items()},
        "column_nnz_stats":stats(list(col_nnz.values())),"column_row_sense_profiles":col_profiles,
        "zero_rhs_two_variable_binary_continuous_L_links":len(links),
        "link_capacity_stats":stats(capacities),"nonpositive_derived_capacities":sum(u<=0 for u in capacities),
        "equality_rhs_stats":stats(eq_rhs),"equality_nnz_stats":stats(eq_nnz),
        "equality_abs_coefficient_histogram":{str(k):v for k,v in sorted(eq_abscoef.items())},
        "continuous_equality_degree_histogram":dict(sorted(cont_eq_degree.items())),
        "equality_signature_histogram":{str(k):v for k,v in eq_signatures.items()},
        "variable_name_prefixes":dict(name_prefix),
        "binary_objective_stats":stats([obj.get(v,0.0) for v in binary_cols]),
        "continuous_objective_stats":stats([obj.get(v,0.0) for v in continuous]),
        "paired_objective_and_capacity_sample":pair_obj[:25]
      },
      "interpretation_note":"Derived only from the MPS matrix. A canonical link has flow y and binary x satisfying y <= U x. Equality incidence and row sizes test whether the remaining matrix is a bipartite transportation balance system."
    }
    with open("transport_analysis.json","w",encoding="utf-8") as f: json.dump(report,f,indent=2,sort_keys=True)
    with open("method_result.json","w",encoding="utf-8") as f: json.dump({"status":"analysis_complete","artifact":"transport_analysis.json"},f,indent=2)

if __name__ == "__main__": main()
