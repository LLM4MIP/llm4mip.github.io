# Formal solving strategy

1. Recover the fixed-charge/network abstraction directly from the MPS matrix.
2. Test a custom constructive heuristic and record pairing, incidence, balance, and feasibility diagnostics.
3. If the abstraction is confirmed, strengthen it with residual shortest-path augmentation, activation-variable local search, and possibly a Lagrangian lower-bound routine.
4. Submit the best internally feasible candidate to exact controller verification. Then use a commercial solver only as a warm-start improver or proof engine rather than as a parameter portfolio.
5. If the incidence assumptions are falsified, pivot based on the row/column signatures in the custom report, such as to capacitated facility-location assignment or lot-sizing dynamic decomposition.

Strict completion requires matching verified primal and dual bounds or a strict infeasibility status.