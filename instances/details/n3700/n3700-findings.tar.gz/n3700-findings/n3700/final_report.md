# Final Report: n3700

## Outcome

This experiment produced a **partial feasible result**. It did not prove optimality or infeasibility.

The best incumbent that passed the controller's tolerance-based Decimal verification has objective

- **Verified primal bound:** 1,247,295
- **Verification tolerance:** 1e-9
- **Source run:** `gurobi-20260903-164522-ea83e8ee`

The strongest recorded dual bound is

- **Dual bound:** 1,063,103.147061621
- **Source run:** `copt-20260903-183923-a1e7b088`

Combining these two independently recorded, usable bounds gives a verified-evidence relative gap of approximately

`(1,247,295 - 1,063,103.147061621) / 1,247,295 = 0.147673047`,

or **14.7673%**.

The reporting bundle also gives a combined relative gap of **14.5440195%**, but that value uses the numerically better Gurobi incumbent 1,244,035.98328589. The controller marked that incumbent **not verified**, so it is reported only as an unverified solver-accepted candidate and is not substituted for the verified primal bound.

There were no strict optimal runs and no strict infeasible runs. Every commercial-solver run ended at a time limit, and the custom run returned no solution. A time limit is not an optimality or infeasibility certificate.

## Complete run record

| Run | Stack | Termination | Primal | Dual | Solver gap | Verification | Runtime (s) |
|---|---|---|---:|---:|---:|---|---:|
| `copt-20260903-164526-3f442fef` | COPT | `TIMEOUT` | 1,311,206 | 1,058,140.7638907675 | 19.3002% | Passed at 1e-9 | 300.0299 |
| `gurobi-20260903-164522-ea83e8ee` | Gurobi | `TIME_LIMIT` | 1,247,295 | 1,055,832.74399599 | 15.3502% | Passed at 1e-9 | 300.0121 |
| `custom-20260903-165248-dda2b247` | Custom Python | `no_solution` | — | — | — | Not checked; no candidate | 1.1744 |
| `gurobi-20260903-165613-d591f6a3` | Gurobi | `TIME_LIMIT` | 1,244,035.98328589 | 1,062,790.15238174 | 14.5692% | **Did not pass verification** | 6,000.0364 |
| `copt-20260903-183923-a1e7b088` | COPT | `TIMEOUT` | 1,271,940 | 1,063,103.147061621 | 16.4188% | Passed at 1e-9 | 7,000.0271 |
| `gurobi-20260903-203825-f63dcad5` | Gurobi | `TIME_LIMIT` | 1,263,637 | 1,044,095.91729942 | 17.3737% | Passed at 1e-9 | 400.0115 |

All six termination statuses are therefore accounted for: five time-limit terminations and one custom `no_solution` termination. None supports a claim of optimality or infeasibility.

## Generic-solver baseline

The short baseline portfolio consisted of two materially independent commercial MIP stacks:

1. **Gurobi**, approximately 300 seconds, producing the best tolerance-verified incumbent of 1,247,295 and a dual bound of 1,055,832.74399599.
2. **COPT**, approximately 300 seconds, producing a verified incumbent of 1,311,206 and a dual bound of 1,058,140.7638907675.

The Gurobi baseline supplied the final verified primal bound. The COPT baseline had the stronger initial dual bound.

The controller-managed summaries available for archival reporting do not expose the solver version strings, machine model, operating-system details, complete parameter dictionaries, or random seeds. These values must therefore be recorded as **not available in the compressed reporting record**, rather than guessed. Time limits were controller-controlled and are reflected by the measured runtimes above. The controller also controlled solver threads and result/log paths; no unsupported thread count is inferred here.

## Problem-specific research method

The research strategy treated the MPS matrix as a candidate fixed-charge/network model. The planned solver-independent abstraction and algorithm were:

1. Recover pairing, incidence, balance, activation, and flow structure directly from row and column signatures.
2. Construct a candidate using network-oriented feasibility logic.
3. Diagnose incidence and balance assumptions before attempting exact submission.
4. If the abstraction held, improve it through residual shortest-path augmentation, activation-variable local search, and possibly a Lagrangian lower-bound routine.
5. If the incidence assumptions failed, pivot to a capacitated facility-location or lot-sizing decomposition suggested by the observed matrix signatures.

The executed custom Python run, `custom-20260903-165248-dda2b247`, terminated after 1.1744 seconds with `no_solution`. Thus it neither improved the incumbent nor produced a bound. This is an informative negative result: the initial constructive abstraction was not sufficient to emit a verifiable candidate in its executed form.

The exact custom source-file path is not present in the compressed reporting excerpts available at this stage. The canonical provenance is consequently the run ID above and its controller-managed run record. No external SAT tool is recorded as having been invoked by this custom run. Python standard-library execution was available; configured CaDiCaL and DRAT-trim capabilities were not part of the recorded result.

Custom execution was CPU-only inside the controller's bubblewrap sandbox, with read-only model/tool inputs and controller-enforced time, memory, output-size, and thread controls. Exact numerical sandbox limits and the Python version are not exposed in the retained reporting summary and are therefore recorded as unavailable rather than reconstructed.

## Follow-on controlled solver experiments

After the structure-specific experiment, longer commercial-solver runs were used as incumbent-improvement and bound-generation attempts rather than as a claim of proof:

- The 6,000-second Gurobi run found the best numerical objective, 1,244,035.98328589, and a dual bound of 1,062,790.15238174. Its solution did not pass controller verification, so it is not the archived verified incumbent.
- The 7,000-second COPT run improved the global dual evidence to 1,063,103.147061621 and returned a verified incumbent of 1,271,940.
- The final 400-second Gurobi run returned a verified incumbent of 1,263,637 but did not improve either the verified primal record or the best dual record.

No full parameter dictionaries or explicit seed values are exposed by the compressed archival summaries. Accordingly, this report does not label any run as deterministic or claim that unspecified parameters were defaults. Exact machine, solver-version, and parameter metadata, if retained elsewhere by the controller, should be read from the immutable per-run records rather than inferred here.

## Interpretation

The defensible result is:

- Feasibility exists and was tolerance-verified.
- Best verified objective: **1,247,295**.
- Best lower bound: **1,063,103.147061621**.
- Verified-evidence gap: **approximately 14.7673%**.
- A better objective of **1,244,035.98328589** was solver-accepted but failed the separate tolerance verification and is not promoted to the verified record.
- No run proved optimality.
- No run proved infeasibility.

The long COPT run yielded the most informative positive bound improvement: its dual bound exceeds the short COPT baseline dual by about 4,962.3832. The custom method's most informative result was negative: its first network constructive implementation returned no candidate.

## Recommended next experiment

The highest-priority next experiment is to inspect and repair the unverified 1,244,035.98328589 candidate using exact or high-precision row-activity diagnostics. If the violations are small and localized, a feasibility-repair model should fix the offending integer/continuous variables while minimizing objective degradation, followed by independent tolerance verification.

In parallel, the structure-specific method should be extended only after validating the inferred incidence structure. A useful sequence is:

1. Produce explicit row/column role diagnostics and test every network-incidence assumption.
2. Build a residual feasibility-repair phase with exact balance accounting.
3. Add activation-variable local search around the verified incumbent.
4. Submit only internally validated candidates for controller verification.
5. Warm-start a proof-oriented commercial-solver run from the best repaired candidate while retaining the strongest known dual bound.

This recommendation targets the observed bottleneck—candidate validity and a still-large proof gap—rather than merely repeating another generic parameter run.

## Reproducibility and archive notes

- Objective sense: minimization.
- Instance: `n3700`.
- Reporting bundle generated: 2026-09-03.
- Solver/tool stacks recorded: Gurobi, COPT, and custom Python.
- Commercial solver versions: not exposed in the compressed reporting record.
- Python version: not exposed in the compressed reporting record.
- Machine/CPU/OS metadata: not exposed in the compressed reporting record.
- Random seeds: not exposed in the compressed reporting record.
- Full parameter dictionaries: not exposed in the compressed reporting record.
- Exact sandbox limits: not exposed in the compressed reporting record; limits were controller-enforced.
- Custom source path: not exposed in the compressed reporting excerpts; use the custom run ID as canonical provenance.
- Optimality proved: **No**.
- Infeasibility proved: **No**.
- Feasible solution independently checked at tolerance: **Yes, at 1e-9**.

The controller-generated `result.json`, `experiments.json`, and `experiments.md` remain the machine-readable authorities. They were not overwritten during reporting.