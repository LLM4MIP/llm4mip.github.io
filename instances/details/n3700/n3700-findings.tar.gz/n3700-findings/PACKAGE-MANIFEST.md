# Package manifest: n3700

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 56
Excluded source files: 1

## Included files

- `README.md`
- `experiments.json`
- `experiments.md`
- `final_report.md`
- `method_selection.md`
- `methods/analyze_transport.py`
- `methods/fixed_charge_flow.py`
- `methods/repair_integral_incumbent.py`
- `reporting_bundle.json`
- `result.json`
- `runs/copt-20260903-164526-3f442fef/best.sol`
- `runs/copt-20260903-164526-3f442fef/driver.stderr`
- `runs/copt-20260903-164526-3f442fef/driver.stdout`
- `runs/copt-20260903-164526-3f442fef/result.json`
- `runs/copt-20260903-164526-3f442fef/solver.log`
- `runs/copt-20260903-183923-a1e7b088/best.sol`
- `runs/copt-20260903-183923-a1e7b088/driver.stderr`
- `runs/copt-20260903-183923-a1e7b088/driver.stdout`
- `runs/copt-20260903-183923-a1e7b088/result.json`
- `runs/copt-20260903-183923-a1e7b088/solver.log`
- `runs/custom-20260903-165248-dda2b247/algorithm.stderr`
- `runs/custom-20260903-165248-dda2b247/algorithm.stdout`
- `runs/custom-20260903-165248-dda2b247/driver.stderr`
- `runs/custom-20260903-165248-dda2b247/driver.stdout`
- `runs/custom-20260903-165248-dda2b247/method_result.json`
- `runs/custom-20260903-165248-dda2b247/result.json`
- `runs/custom-20260903-165248-dda2b247/structure_report.json`
- `runs/gurobi-20260903-164522-ea83e8ee/best.sol`
- `runs/gurobi-20260903-164522-ea83e8ee/driver.stderr`
- `runs/gurobi-20260903-164522-ea83e8ee/driver.stdout`
- `runs/gurobi-20260903-164522-ea83e8ee/result.json`
- `runs/gurobi-20260903-164522-ea83e8ee/solver.log`
- `runs/gurobi-20260903-165613-d591f6a3/best.sol`
- `runs/gurobi-20260903-165613-d591f6a3/driver.stderr`
- `runs/gurobi-20260903-165613-d591f6a3/driver.stdout`
- `runs/gurobi-20260903-165613-d591f6a3/result.json`
- `runs/gurobi-20260903-165613-d591f6a3/solver.log`
- `runs/gurobi-20260903-203825-f63dcad5/best.sol`
- `runs/gurobi-20260903-203825-f63dcad5/driver.stderr`
- `runs/gurobi-20260903-203825-f63dcad5/driver.stdout`
- `runs/gurobi-20260903-203825-f63dcad5/result.json`
- `runs/gurobi-20260903-203825-f63dcad5/solver.log`
- `solutions/public/n3700-v4.sol.gz`
- `strategy.md`
- `structure-gurobi.log`
- `structure.json`
- `verification/copt-20260903-164526-3f442fef.exact-check.json`
- `verification/copt-20260903-164526-3f442fef.exact-check.txt`
- `verification/copt-20260903-183923-a1e7b088.exact-check.json`
- `verification/copt-20260903-183923-a1e7b088.exact-check.txt`
- `verification/gurobi-20260903-164522-ea83e8ee.exact-check.json`
- `verification/gurobi-20260903-164522-ea83e8ee.exact-check.txt`
- `verification/gurobi-20260903-165613-d591f6a3.exact-check.json`
- `verification/gurobi-20260903-165613-d591f6a3.exact-check.txt`
- `verification/gurobi-20260903-203825-f63dcad5.exact-check.json`
- `verification/gurobi-20260903-203825-f63dcad5.exact-check.txt`

## Excluded files

- `input/n3700.mps.gz (153346 bytes; raw benchmark input; sha256 deabadfabfacf4cecc49aaad180a6183a9d5de0b3ec73a888263dbd921f073bc)`
