# Package manifest: rmine11

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 32
Excluded source files: 0

## Included files

- `README.md`
- `artifacts/exact-lb-cert.json.gz`
- `artifacts/exact-lb-lambda.json`
- `artifacts/exact-lb-verification.json`
- `artifacts/exact-time-structure-result.json`
- `artifacts/proof-bundle/README.md`
- `artifacts/proof-bundle/agent-clique/clique_experiment.py`
- `artifacts/proof-bundle/agent-clique/run/result.json`
- `artifacts/proof-bundle/agent-clique/run/rmine11-pairs-plus-cliques.mps.gz`
- `artifacts/proof-bundle/agent-clique/run/validation.json`
- `artifacts/proof-bundle/agent-clique/validate_clique_bundle.py`
- `artifacts/proof-bundle/agent-cover-rmine11/run/result.json`
- `artifacts/proof-bundle/agent-cover-rmine11/run/rmine11-pair-clique-plus-triple-covers.mps.gz`
- `artifacts/proof-bundle/agent-cover-rmine11/run/validation.json`
- `artifacts/proof-bundle/agent-cover-rmine11/triple_cover_experiment.py`
- `artifacts/proof-bundle/agent-cover-rmine11/validate_triple_covers.py`
- `artifacts/proof-bundle/agent-dual/exact_lagrangian_certificate.py`
- `artifacts/proof-bundle/agent-dual/prefix_cut_experiment.py`
- `artifacts/proof-bundle/agent-dual/result.json`
- `artifacts/proof-bundle/agent-dual/rmine11-pairs.mps.gz`
- `artifacts/proof-bundle/agent-dual/verify_prefix_cut_bundle.py`
- `artifacts/strict-ub-exact-audit.json`
- `artifacts/structure.json`
- `input/README.md`
- `input/SHA256SUMS`
- `reports/exact-time-structure-2026-09-08.md`
- `reports/pair-clique-study.md`
- `reports/triple-cover-study.md`
- `scripts/build_exact_time_model.py`
- `scripts/exact_decimal_audit.py`
- `scripts/exact_lagrangian_certificate.py`
- `solutions/rmine11-public.sol.gz`

## Excluded files

- None
