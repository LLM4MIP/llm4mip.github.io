# rmine11 — exact primal and dual evidence; global optimum still open

Official MIPLIB page: <https://miplib.zib.de/instance_details_rmine11.html>

Official MPS: [download `rmine11.mps.gz`](https://miplib.zib.de/WebData/instances/rmine11.mps.gz)

## Status and bounds

The global optimum of `rmine11` remains **open**.  This bundle does not claim
an optimal solution or a complete optimality proof.  It deliberately keeps
three different kinds of evidence separate:

| bound | value | evidence status |
|---|---:|---|
| strict feasible UB | `-2508.404143999999991662` | exact `Decimal` replay of the public integer vector against the original MPS |
| strongest recorded numerical LB | `-2509.7041` | COPT 10-hour floating-point dual bound; no portable proof trace is available |
| portable exact global LB | `-2521.353274311517894` | exact rational Lagrangian maximum-closure certificate after validated pair, clique and triple-cover cuts |

Because this is a minimization problem, the independently checkable statement
is

```text
-2521.353274311517894 <= OPT <= -2508.404143999999991662.
```

Its exact-certified interval width is `12.949130311517902338` (`0.516230%`
of the strict UB magnitude).  The stronger COPT number is useful for numerical
comparison, but is not promoted to an exact theorem here; paired with the
strict UB, its reported numerical gap is `1.299956000000008338` (`0.051824%`).

## Recovered structure

The original model has 12,292 binary variables, 97,389 rows and 241,240
nonzeros.  It represents 1,331 (`11^3`) mine blocks over 11 periods.  A binary
`x_Bb_tt` records whether block `b` has been extracted by the end of period
`t`.

The rows consist of 86,406 spatial-precedence implications, 10,961 temporal
chain implications and only 22 capacity rows (two resources per period).
Capacity rows charge differences `x[b,t] - x[b,t-1]`, namely the blocks
actually extracted in a period.  Removing those 22 rows leaves a
maximum-weight closure problem, which is why a Lagrangian min-cut certificate
is possible.

An imported structural follow-up rewrites the cumulative variables as exact
extraction-time binaries. It reduces the integer-equivalent model from 97,389
to 10,963 rows while retaining 12,292 binaries, but its LP relaxation is
weaker and it supplies **no bound improvement** over the evidence above. The
same analysis gives a dominance fixing for 47 positive-cost blocks. See the
[exact-time supplement](reports/exact-time-structure-2026-09-08.md), its
[machine-readable summary](artifacts/exact-time-structure-result.json), and
the [`build_exact_time_model.py`](scripts/build_exact_time_model.py) generator.

The original MPS SHA-256 is
`c78691fd9a3aba94f6a74cc62701e41f42d086125dd586bbd96f6d067aafafb1`.
The machine-readable structural inventory is
[`artifacts/structure.json`](artifacts/structure.json).

## Evidence chain

The public solution in
[`solutions/rmine11-public.sol.gz`](solutions/rmine11-public.sol.gz) lists all
12,292 variables.  A solver-free, 60-digit `Decimal` parser checked every
original row, every bound and every integrality condition; all maximum
violations are exactly zero.  The retained audit is
[`artifacts/strict-ub-exact-audit.json`](artifacts/strict-ub-exact-audit.json).

The exact lower bound starts from the closure relaxation and adds independently
validated precedence-induced capacity cuts:

- 394 exact pair conflicts;
- 70 exact conflict-clique inequalities of size 3–8; and
- 5 genuine minimal triple covers at period 4.

For each triple cover, all three proper pairs fit both cumulative resources,
while the full three-closure union is strictly overloaded.  The smallest exact
overload is `17.131931`, so these are not pair conflicts under another name.
Together, the cuts improve the original exact closure bound from
`-2522.047106832620469` to `-2521.353274311517894`.

The augmented model has SHA-256
`98bc534c9f97fc5d4166046d3ce2ba5c1b6b4c98a119b66f3cd1f954c7a2f639`.
Its cut witnesses, augmented model and validation outputs are collected in
[`artifacts/proof-bundle/`](artifacts/proof-bundle/).  The portable certificate
is [`artifacts/exact-lb-cert.json.gz`](artifacts/exact-lb-cert.json.gz), with
SHA-256
`8fabb66632a4d1267fa7c8d136f6396e5463938a72219d76f1857161b9eaae0e`.
The independent replay in
[`artifacts/exact-lb-verification.json`](artifacts/exact-lb-verification.json)
checks a feasible integer max-flow, an equal-capacity cut, and the exact bound

```text
-126067663715575894697637121 / 50000000000000000000000.
```

Finite restricted-neighborhood searches found no better incumbent.  Those are
local negative results only and do not prove that the public point is globally
optimal.

## Reproduction

The original MPS is not duplicated in this package.  Download it from the
[official MIPLIB link](https://miplib.zib.de/WebData/instances/rmine11.mps.gz)
and save it as `input/rmine11.mps.gz`; the expected SHA-256 is recorded in
[`input/SHA256SUMS`](input/SHA256SUMS).  Then recheck the strict UB without a
solver:

```sh
python scripts/exact_decimal_audit.py \
  --mps input/rmine11.mps.gz \
  --solution solutions/rmine11-public.sol.gz \
  --out /tmp/rmine11-strict-ub-audit.json
```

Replay the exact lower-bound witness without resolving max flow:

```sh
python scripts/exact_lagrangian_certificate.py verify \
  artifacts/proof-bundle/agent-cover-rmine11/run/rmine11-pair-clique-plus-triple-covers.mps.gz \
  artifacts/exact-lb-cert.json.gz
```

The verifier is
[`scripts/exact_lagrangian_certificate.py`](scripts/exact_lagrangian_certificate.py);
the solver-free primal checker is
[`scripts/exact_decimal_audit.py`](scripts/exact_decimal_audit.py).
