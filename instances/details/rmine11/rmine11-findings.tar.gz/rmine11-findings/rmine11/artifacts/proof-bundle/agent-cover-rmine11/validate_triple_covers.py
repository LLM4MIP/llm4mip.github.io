#!/usr/bin/env python3
"""Independently validate an rmine triple-cover experiment bundle."""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import re
import sys
from fractions import Fraction
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
DUAL = HERE.parent / "agent-dual"
sys.path.insert(0, str(DUAL))
from exact_lagrangian_certificate import ClosureModel, parse_mps  # noqa: E402


CAP_RE = re.compile(r"^tcap_c(.+)_t(-?\d+)$")
VAR_RE = re.compile(r"^x_B(.+)_t(-?\d+)$")


def period_of(variable: str) -> int:
    match = VAR_RE.match(variable)
    if not match:
        raise ValueError(f"unexpected variable {variable}")
    return int(match.group(2))


def catalog(model: ClosureModel):
    rows = {}
    for row in model.side_rows:
        match = CAP_RE.match(row)
        if match:
            rows[(match.group(1), int(match.group(2)))] = row
    resources = sorted({resource for resource, _period in rows})
    periods = sorted({period for _resource, period in rows})
    variables_at = {period: [] for period in periods}
    for variable in model.variables:
        variables_at[period_of(variable)].append(variable)
    weights = {}
    capacity = {}
    for resource in resources:
        running = Fraction(0)
        for period in periods:
            row = rows[(resource, period)]
            running += model.side_rhs[row]
            capacity[(resource, period)] = running
            weights[(resource, period)] = {
                variable: model.side_columns[row][variable]
                for variable in variables_at[period]
            }
    return resources, periods, variables_at, weights, capacity


def closures(model: ClosureModel, nodes: list[str]):
    node_set = set(nodes)
    outgoing = {node: [] for node in nodes}
    for tail, head in model.arcs:
        if tail in node_set and head in node_set:
            outgoing[tail].append(head)
    memo = {}
    active = set()

    def visit(node: str):
        if node in memo:
            return memo[node]
        if node in active:
            raise ValueError("cycle in precedence graph")
        active.add(node)
        result = {node}
        for head in outgoing[node]:
            result.update(visit(head))
        active.remove(node)
        memo[node] = frozenset(result)
        return memo[node]

    for node in nodes:
        visit(node)
    return memo


def total_weight(weight: dict[str, Fraction], nodes) -> Fraction:
    return sum((weight[node] for node in nodes), Fraction(0))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("original_mps")
    parser.add_argument("baseline_mps")
    parser.add_argument("result_json")
    parser.add_argument("enhanced_mps")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    result = json.loads(Path(args.result_json).read_text(encoding="utf-8"))
    original = parse_mps(args.original_mps)
    baseline = parse_mps(args.baseline_mps)
    enhanced = parse_mps(args.enhanced_mps)
    if result["original_sha256"] != original.sha256:
        raise ValueError("original hash mismatch")
    if result["baseline_sha256"] != baseline.sha256:
        raise ValueError("baseline hash mismatch")
    if result["enhanced_sha256"] != enhanced.sha256:
        raise ValueError("enhanced hash mismatch")
    if set(original.variables) != set(baseline.variables) or set(original.variables) != set(enhanced.variables):
        raise ValueError("variable set changed")
    if original.objective != baseline.objective or original.objective != enhanced.objective:
        raise ValueError("objective changed")
    if set(original.arcs) != set(baseline.arcs) or set(original.arcs) != set(enhanced.arcs):
        raise ValueError("precedence arcs changed")

    resources, periods, variables_at, weights, capacities = catalog(original)
    closure_by_period = {
        period: closures(original, variables_at[period]) for period in periods
    }

    minimum_margin = None
    for index, record in enumerate(result["cover_cuts"]):
        variables = tuple(record["variables"])
        if len(variables) != 3 or len(set(variables)) != 3:
            raise ValueError(f"cut {index} is not a distinct triple")
        period = record["period"]
        if any(period_of(variable) != period for variable in variables):
            raise ValueError(f"cut {index} mixes periods")
        closure = closure_by_period[period]
        for pair in itertools.combinations(variables, 2):
            union = closure[pair[0]] | closure[pair[1]]
            for resource in resources:
                if total_weight(weights[(resource, period)], union) > capacities[(resource, period)]:
                    raise ValueError(f"cut {index} contains an already-conflicting pair")
        union = closure[variables[0]] | closure[variables[1]] | closure[variables[2]]
        resource = record["resource"]
        total = total_weight(weights[(resource, period)], union)
        capacity = capacities[(resource, period)]
        margin = total - capacity
        if margin <= 0:
            raise ValueError(f"cut {index} is not an exact cover")
        if str(total) != record["closure_union_weight"] or str(capacity) != record["prefix_capacity"]:
            raise ValueError(f"cut {index} witness values mismatch")
        if str(margin) != record["exact_overload_margin"] or len(union) != record["closure_union_size"]:
            raise ValueError(f"cut {index} witness metadata mismatch")
        minimum_margin = margin if minimum_margin is None else min(minimum_margin, margin)

        row = f"certified_triple_cover_{index}"
        if enhanced.side_rhs.get(row) != 2:
            raise ValueError(f"enhanced row {row} has wrong RHS")
        expected = {variable: Fraction(1) for variable in variables}
        if enhanced.side_columns.get(row) != expected:
            raise ValueError(f"enhanced row {row} has wrong coefficients")

    baseline_rows = set(baseline.side_rows)
    expected_new = {f"certified_triple_cover_{i}" for i in range(len(result["cover_cuts"]))}
    actual_new = set(enhanced.side_rows) - baseline_rows
    if actual_new != expected_new:
        raise ValueError("unexpected added or missing side rows")
    for row in baseline.side_rows:
        if enhanced.side_rhs.get(row) != baseline.side_rhs[row] or enhanced.side_columns.get(row) != baseline.side_columns[row]:
            raise ValueError(f"baseline side row changed: {row}")

    summary = {
        "verified": True,
        "original_sha256": original.sha256,
        "baseline_sha256": baseline.sha256,
        "enhanced_sha256": enhanced.sha256,
        "triple_cuts_exactly_verified": len(result["cover_cuts"]),
        "all_proper_pairs_fit_all_resources": True,
        "minimum_exact_overload_margin": str(minimum_margin) if minimum_margin is not None else None,
        "enhanced_rows_exactly_verified": True,
    }
    Path(args.output).write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
