# `rmine11` exact cut-validity chain

Run these commands from `instances/rmine11/`.

Validate the 394 precedence-induced pair conflicts against the original MPS:

```sh
python artifacts/proof-bundle/agent-dual/verify_prefix_cut_bundle.py \
  input/rmine11.mps.gz \
  artifacts/proof-bundle/agent-dual/result.json \
  artifacts/proof-bundle/agent-dual/rmine11-pairs.mps.gz
```

Validate the 2,907 candidate conflict edges and 70 clique inequalities:

```sh
python artifacts/proof-bundle/agent-clique/validate_clique_bundle.py \
  input/rmine11.mps.gz \
  artifacts/proof-bundle/agent-dual/result.json \
  artifacts/proof-bundle/agent-dual/rmine11-pairs.mps.gz \
  artifacts/proof-bundle/agent-clique/run/result.json \
  artifacts/proof-bundle/agent-clique/run/rmine11-pairs-plus-cliques.mps.gz
```

Validate the five genuine minimal triple covers and the final enhanced MPS:

```sh
python artifacts/proof-bundle/agent-cover-rmine11/validate_triple_covers.py \
  input/rmine11.mps.gz \
  artifacts/proof-bundle/agent-clique/run/rmine11-pairs-plus-cliques.mps.gz \
  artifacts/proof-bundle/agent-cover-rmine11/run/result.json \
  artifacts/proof-bundle/agent-cover-rmine11/run/rmine11-pair-clique-plus-triple-covers.mps.gz \
  --output /tmp/rmine11-triple-validation.json
```

Finally replay the exact flow/cut lower-bound certificate:

```sh
python scripts/exact_lagrangian_certificate.py verify \
  artifacts/proof-bundle/agent-cover-rmine11/run/rmine11-pair-clique-plus-triple-covers.mps.gz \
  artifacts/exact-lb-cert.json.gz
```

The final certificate verifier uses only the Python standard library.  The cut
validators import the archived experiment modules and therefore require the
same `gurobipy` and `networkx` Python dependencies used by the experiments;
they do not reoptimize the original integer MIP.
