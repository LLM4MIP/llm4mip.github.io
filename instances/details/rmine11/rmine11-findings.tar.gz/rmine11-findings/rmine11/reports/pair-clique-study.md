#  rmine11 precedence-clique cut experiment

## result

Based on the precedence pair cuts model of the 394, which has exact verification, three rounds of consecutive root-LP clique separation are obtained:

|  Project |  Numerical |
|---|---:|
| 394 -pair Baseline root LP |  -2521.5301057139704  |
| Add the root LP after clicking |  -2521.355937803649  |
| Relative paired baseline increases |  0.1741679103216  |
| clique cuts | 70 |
| Maximum clique has been added | 8 single node |
| When experimental scripts are used |  25.80 s  |

The results of each round:

|  Round | New cuts |  root LP  | Relative paired baseline increases |
|---:|---:|---:|---:|
| 1 | 44 | -2521.378595318067 | 0.151510395904 |
| 2 | 20 | -2521.360255765306 | 0.169849948664 |
| 3 | 6 | -2521.355937803649 | 0.174167910322 |

After rationalizing the row dual of the final enhanced LP, the integer max-flow/min-cut certificate is given and has independent verification:

```text
strict LB = -126067796890182353808399509 / 50000000000000000000000
          = -2521.355937803647076
```

Compared to the previous 394 -pair, strict lower bound `-2521.530105713968618`, strict upgraded `0.174167910321542`; compared to the original root strict lower bound `-2522.047106832620469`, cumulative upgraded `0.691169028973393`.

Relatively exact public incumbent `-2508.404143999999991662`, the new absolute gap is `12.951793803647084338`, the MIPLIB denominator is about `0.513684%`. From the original root gap meter, pair+clique closes together about `5.06612%`.

##  Graphs and cliques

The script starts with the solution 394 -pair model continuous LP, and then on the period `2,3,4,6` already covered by the pair diagram:

1.  retains all the endpoints of the seed edge of the 394;
2.  Add a finite number of high-LP values, high-closure-pressure candidates, for each period;
3.  For each pair of candidates, return to the original MPS and re-calculate the same cycle precedence closure union with `Fraction`;
4.  Conflict edge is established only when there is a strict excess of the cumulative capacity of at least one resource.
5.  Maximal cliques in the full enumeration Candidate chart, selected by the current LP node weight against the largest, clique size at least 3;
6.  Add to `sum_{i in Q} x_i,t <= 1`, re-solution, continuous LP, all three rounds.

Candidate chart statistics:

|  period  |  seed nodes  |  candidate nodes  |  exact conflict edges  |  size>=3 maximal cliques  | The largest candidate clique | enumeration Disconnected |
|---:|---:|---:|---:|---:|---:|---|
| 2 | 54 | 164 | 1411 | 10668 | 9 | false |
| 3 | 37 | 154 | 971 | 1104 | 9 | false |
| 4 | 22 | 130 | 159 | 4 | 3 | false |
| 6 | 61 | 162 | 366 | 165 | 4 | false |

The maximal-clique enumeration of all periods is complete without touching the `200000` upper limit. The maximal graph here is relative to the finite candidate graph clearly recorded in JSON, and does not claim to be a complete conflict graph maximal relative to all 12,292 variables.

Distribution of cuts has been added: period 2 with 2 column size- 4; period 3 with 48 column size- 4 - -8; period 4 with 2 column size- 3; period 6 with 20 column size- 4.

## exact verification

`validate_clique_bundle.py` does not trust the conclusions in JSON, but reads the original MPS and completes:

-  394 / 394 item seed pair by item closure/capacity verification;
-  All four candidate graphs are reconstructed, the 2,907 / 2,907 bar edge is introduced by exact cumulative excess, standardized graph hash consistent;
-  Each pair of nodes in the 70 / 70 bar clique is the exact conflict in the reconstruction graph;
-  Enhance MPS without changing variable, objective or precedence arcs;
-  The variables, coefficients and RHS of the original pair rows of 394 and the clique rows of 70 are identical.

The minimum exact excess of all clique pairs that have been added is:

```text
6545007 / 1000000 = 6.545007
```

Thus this is not a result at the tolerance boundary. Strengthened MPS SHA-256:

```text
50fef2b056c6e072db59c2fbe6ad8602d99f2c6f8af09dd2c891969e7c37617d
```

proof divided by two layers: validator proof New rows are valid for the original model global; flow=cut witness for `exact-lb-cert.json.gz` and proof reinforces the model's logical Lagrangian lower bound. The two layers combine to make the numerical strict global lower bound for the original rmine11.

## file

-  `../artifacts/proof-bundle/agent-clique/clique_experiment.py`: Candidate chart, maximum/maximum-weight separation and LP rounds;
-  `../artifacts/proof-bundle/agent-clique/validate_clique_bundle.py`: independent cut/graph/MPS validator;
-  `../artifacts/proof-bundle/agent-clique/run/result.json`: candidate nodes, graph hashes, round-by-round results and all pair witnesses for each clique;
-  `../artifacts/proof-bundle/agent-clique/run/validation.json`: Independent verification summary;
-  `../artifacts/proof-bundle/agent-clique/run/rmine11-pairs-plus-cliques.mps.gz`: 394 pair + 70 clique is an integer model.

The pair+clique phase was then further enhanced by the triple-cover phase, so the release packet only retains the final packaging.
`../artifacts/exact-lb-lambda.json`, `../artifacts/exact-lb-cert.json.gz` and
`../artifacts/exact-lb-verification.json`; see full instructions
`../artifacts/proof-bundle/README.md`。

## scope

-  Only finite candidate graphs and three rounds of separation were made; there is no complete rmine11 conflict graph.
-  Only add a clique of at least 3 size, so the improvement is not dependent on additional size-2 pair rows.
-  Different sides of each clique can be proven by different resources; clique inequality remains valid as long as any two nodes cannot coexist.
-  Complete only solution, continuous root LP, combined chart enumeration and closure min-cut, with no long integer MIP.
