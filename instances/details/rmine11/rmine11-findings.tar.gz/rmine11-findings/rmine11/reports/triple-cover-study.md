#  `rmine11` Triangular precedence-cover experiment

## result

The experiment started from the `394 pair + 70 clique` model with already strict verification and did not run integers.
branch-and-bound, separated by a triangular cover that is not paired with a conflict explanation on a continuous root LP only:

```text
pair + clique strict LB                  -2521.355937803647076
+ 5 exact minimal triple covers         -2521.353274311517894
strict improvement                          0.002663492129182
```

The new strict global lower bound

```text
-126067663715575894697637121 / 50000000000000000000000
= -2521.353274311517894
```

Compared to the original closure certificate `-2522.047106832620469` cumulative improvement
`0.693832521102575`. Relatively strict incumbent
`-2508.404143999999991662`, the current verifiable range width is
`12.949130311517902338`。

## Inequality

After fixed period `t`, the command to `H(i)` is forced by the original precedence rows when selecting `x_i,t=1`.
The selected synchronous cycle closure. If three variables `i,j,k` are satisfied:

1.  `H(i) union H(j)`, `H(i) union H(k)`, `H(j) union H(k)` for both accumulated resources are not available.
Overcapacity;
2.  However, `H(i) union H(j) union H(k)` is strictly overcapacity on at least one cumulative resource;

So three of the original integer models cannot be equal to 1 at the same time.

```text
x_i,t + x_j,t + x_k,t <= 2
```

Because every proper pair can be shared in a cumulative knapsack, these five rules are not the same.
There has been a size-2 conflict, not a clique inequality.

Finite, definite candidate screening in period 4 to find 5 clause violates cut, root LP from
`-2521.355937803650` numerical upgraded to `-2521.353274311527`.
The minimum exact overcapacity for all three closures is `0.0098672544`.

```text
17131931 / 1000000 = 17.131931.
```

##  Independent verification

`validate_triple_covers.py` Re-read official MPS, pair+clique baseline MPS, resulting in JSON
And finally MPS, and check:

-  The official MPS SHA-256 is used for
  `c78691fd9a3aba94f6a74cc62701e41f42d086125dd586bbd96f6d067aafafb1`；
-  Each proper pair of a triad of 5 / 5 has an exact capacity not exceeding two cumulative resources;
-  5 / 5 complete triple closure with strictly correct exact over capacity;
-  Finally, the MPS does not change the variable, objective, precedence arcs or any baseline side row;
-  The variables in the new row of 5 are the coefficients `1` and RHS `2`.

The MPS SHA-256 is enhanced:

```text
98bc534c9f97fc5d4166046d3ce2ba5c1b6b4c98a119b66f3cd1f954c7a2f639
```

Finally, to increase LP's rationalization of row multipliers, construct an integer max-flow with the same capacity min-cut;
`exact_lagrangian_certificate.py verify` has checked flow capacity, conservation, cut capacity and final
The result is `verified=true`.

##  Documents and Borders

-  `../artifacts/proof-bundle/agent-cover-rmine11/triple_cover_experiment.py`: finite candidate selection with LP separation;
-  `../artifacts/proof-bundle/agent-cover-rmine11/validate_triple_covers.py`: independent original - MPS cut/model validator;
-  `../artifacts/proof-bundle/agent-cover-rmine11/run/result.json`: Full candidate statistics with five cut witness;
-  `../artifacts/proof-bundle/agent-cover-rmine11/run/validation.json`: cut/model verification summary;
-  `../artifacts/proof-bundle/agent-cover-rmine11/run/rmine11-pair-clique-plus-triple-covers.mps.gz`: the final augmented integer model;
- `../artifacts/exact-lb-lambda.json`、`../artifacts/exact-lb-cert.json.gz`、
`../artifacts/exact-lb-verification.json`: strict lower bound chain of evidence

For layered verification instructions see `../artifacts/proof-bundle/README.md`.

Candidate selection takes only a finite number of high LP values/high closure-pressure variables per period and is budgeted at 600 seconds.
Limitations, so no more cuts are found, do not represent the end of a complete triangle separation.
`rmine11` is the best.
