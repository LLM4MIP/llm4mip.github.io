# Rejected proof notice

The `OPTIMAL` status recorded in `pairb400-energy-result.json` is **not a valid
optimality certificate for the official instance**.

The augmented proof model imported 750 energetic inequalities from the older
PairA400 `method02.py` experiment.  That experiment interpreted the upper bound
of a start-time variable as a completion deadline.  The correct completion
deadline is

```text
completion_deadline_i = latest_start_i + processing_time_i.
```

Consequently, the imported inequalities may cut off feasible schedules.  The
augmented model, its bound, and its `OPTIMAL` status are rejected and must not be
cited as proof for PairA400 or PairB400.

One result remains valid in the source research archive:
`pairb400-energy-best.sol` is a genuine feasible primal solution with objective
`-36.276622209826776`. It was audited against the
unmodified official PairB400 MPS, with zero row, bound, or integrality
violations above `1e-9` (maximum row violation
`3.241851231905457e-14`).  This establishes only a primal improvement, not
global optimality. The superseded solution itself is not duplicated in this
curated publication because the better final optimum is archived instead.

Any new optimality attempt must reconstruct deadlines as `UB(start_i) + p_i`
and must be independently checked on the unmodified MPS.
