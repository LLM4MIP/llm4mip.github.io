from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB

from pairb_common_deadline_master import pair_offset, recover_pairb


def audit(model: gp.Model, values: list[float]) -> dict[str, float | int | str]:
    max_bound = max_integrality = max_row = 0.0
    bound_count = integrality_count = row_count = 0
    worst_row = ""
    for variable, value in zip(model.getVars(), values):
        violation = max(float(variable.LB) - value, value - float(variable.UB), 0.0)
        max_bound = max(max_bound, violation)
        bound_count += violation > 1e-9
        if variable.VType in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT):
            violation = abs(value - round(value))
            max_integrality = max(max_integrality, violation)
            integrality_count += violation > 1e-9
    for constraint in model.getConstrs():
        row = model.getRow(constraint)
        activity = math.fsum(float(row.getCoeff(k)) * values[row.getVar(k).index] for k in range(row.size()))
        if constraint.Sense == GRB.LESS_EQUAL:
            violation = max(activity - float(constraint.RHS), 0.0)
        elif constraint.Sense == GRB.GREATER_EQUAL:
            violation = max(float(constraint.RHS) - activity, 0.0)
        else:
            violation = abs(activity - float(constraint.RHS))
        if violation > max_row:
            max_row = violation
            worst_row = constraint.ConstrName
        row_count += violation > 1e-9
    objective = float(model.ObjCon) + math.fsum(float(variable.Obj) * values[variable.index] for variable in model.getVars())
    return {
        "objective": objective,
        "max_bound_violation": max_bound,
        "bound_violations_over_1e-9": bound_count,
        "max_integrality_violation": max_integrality,
        "integrality_violations_over_1e-9": integrality_count,
        "max_row_violation": max_row,
        "worst_row": worst_row,
        "row_violations_over_1e-9": row_count,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("master_result", type=Path)
    parser.add_argument("solution_out", type=Path)
    parser.add_argument("audit_out", type=Path)
    parser.add_argument("--jobs", type=int, required=True)
    args = parser.parse_args()

    model = gp.read(str(args.mps))
    variables = model.getVars()
    releases, durations, latest_starts, prefix = recover_pairb(model, args.jobs)
    result = json.loads(args.master_result.read_text(encoding="utf-8"))
    selected = [int(i) for i in result["master_selected_jobs"]]
    selected_set = set(selected)

    ordered = sorted(selected, key=lambda i: (releases[i], i))
    starts: dict[int, float] = {}
    clock = 0.0
    for i in ordered:
        clock = max(clock, releases[i])
        starts[i] = clock
        clock += durations[i]

    values = [0.0] * len(variables)
    for i in range(args.jobs):
        values[i] = 1.0 if i in selected_set else 0.0
        values[args.jobs + i] = starts.get(i, releases[i])
    for i in range(args.jobs):
        for j in range(i + 1, args.jobs):
            offset = pair_offset(args.jobs, i, j)
            both_index = 2 * args.jobs + 2 * offset
            order_index = both_index + 1
            both = i in selected_set and j in selected_set
            values[both_index] = 1.0 if both else 0.0
            if both:
                i_before_j = starts[i] + durations[i] <= starts[j] + 1e-12
                j_before_i = starts[j] + durations[j] <= starts[i] + 1e-12
                if not i_before_j and not j_before_i:
                    raise RuntimeError(f"overlap between selected jobs {i} and {j}")
                values[order_index] = 0.0 if i_before_j else 1.0
            else:
                values[order_index] = 0.0

    args.solution_out.parent.mkdir(parents=True, exist_ok=True)
    objective = float(model.ObjCon) + math.fsum(float(v.Obj) * values[v.index] for v in variables)
    with args.solution_out.open("w", encoding="utf-8", newline="\n") as stream:
        stream.write(f"# Objective value = {objective:.17g}\n")
        for variable, value in zip(variables, values):
            stream.write(f"{variable.VarName} {value:.17g}\n")

    audit_result = audit(model, values)
    completion_deadlines = [latest_starts[i] + durations[i] for i in selected]
    payload = {
        "instance": model.ModelName,
        "construction": "selected jobs sorted by nondecreasing release time and scheduled at max(previous completion, release); Pair-B conjunction/order binaries filled canonically",
        "selected_jobs": selected,
        "selected_count": len(selected),
        "ordered_jobs": ordered,
        "last_completion": clock,
        "selected_deadline_min": min(completion_deadlines),
        "selected_deadline_max": max(completion_deadlines),
        "max_selected_start_upper_bound_violation": max(max(starts[i] - latest_starts[i], 0.0) for i in selected),
        "solution": str(args.solution_out.resolve()),
        "audit": audit_result,
        "source_master": str(args.master_result.resolve()),
        "pairb_prefix_rows": prefix,
    }
    args.audit_out.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
