from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB

from pairb_common_deadline_master import fixed_selection_rows, recover_pairb


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("original_mps", type=Path)
    parser.add_argument("master_mps", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--jobs", type=int, required=True)
    parser.add_argument("--deadline-safety", type=float, default=1e-12)
    args = parser.parse_args()

    original = gp.read(str(args.original_mps))
    master = gp.read(str(args.master_mps))
    releases, durations, latest_starts, prefix = recover_pairb(original, args.jobs)
    fixed = fixed_selection_rows(original, args.jobs, prefix)
    fixed_jobs = {int(item["job"]) for item in fixed}
    eligible = [i for i in range(args.jobs) if i not in fixed_jobs]
    deadlines = [latest_starts[i] + durations[i] for i in range(args.jobs)]
    recovered_deadline_max = max(deadlines[i] for i in eligible)
    common_deadline = recovered_deadline_max + args.deadline_safety
    thresholds = sorted({releases[i] for i in eligible})

    variables = master.getVars()
    objective_mismatch = 0
    variable_name_mismatch = 0
    variable_type_mismatch = 0
    max_objective_difference = 0.0
    for i in range(args.jobs):
        variable_name_mismatch += variables[i].VarName != original.getVars()[i].VarName
        variable_type_mismatch += variables[i].VType != GRB.BINARY
        difference = abs(float(variables[i].Obj) - float(original.getVars()[i].Obj))
        max_objective_difference = max(max_objective_difference, difference)
        objective_mismatch += difference > 1e-14

    fixed_failures = 0
    max_fixed_difference = 0.0
    for item in fixed:
        constraint = master.getConstrByName(f"fixed_{item['row']}")
        if constraint is None:
            fixed_failures += 1
            continue
        row = master.getRow(constraint)
        if row.size() != 1 or row.getVar(0).index != int(item["job"]) or constraint.Sense != GRB.EQUAL:
            fixed_failures += 1
            continue
        difference = max(
            abs(float(row.getCoeff(0)) - float(item["coefficient"])),
            abs(float(constraint.RHS) - float(item["rhs"])),
        )
        max_fixed_difference = max(max_fixed_difference, difference)
        fixed_failures += difference > 1e-14

    suffix_failures = 0
    max_suffix_coefficient_difference = 0.0
    max_suffix_rhs_difference = 0.0
    for cut_index, threshold in enumerate(thresholds):
        constraint = master.getConstrByName(f"suffix_capacity_{cut_index}")
        if constraint is None or constraint.Sense != GRB.LESS_EQUAL:
            suffix_failures += 1
            continue
        row = master.getRow(constraint)
        actual = {row.getVar(k).index: float(row.getCoeff(k)) for k in range(row.size())}
        expected = {i: durations[i] for i in eligible if releases[i] >= threshold}
        support = set(actual) | set(expected)
        coefficient_difference = max((abs(actual.get(i, 0.0) - expected.get(i, 0.0)) for i in support), default=0.0)
        rhs_difference = abs(float(constraint.RHS) - (common_deadline - threshold))
        max_suffix_coefficient_difference = max(max_suffix_coefficient_difference, coefficient_difference)
        max_suffix_rhs_difference = max(max_suffix_rhs_difference, rhs_difference)
        suffix_failures += coefficient_difference > 1e-14 or rhs_difference > 1e-14

    expected_rows = len(fixed) + len(thresholds)
    known_rows = {f"fixed_{item['row']}" for item in fixed} | {f"suffix_capacity_{i}" for i in range(len(thresholds))}
    unknown_rows = [constraint.ConstrName for constraint in master.getConstrs() if constraint.ConstrName not in known_rows]
    report = {
        "instance": original.ModelName,
        "audit_passed": bool(
            len(variables) == args.jobs
            and len(master.getConstrs()) == expected_rows
            and not variable_name_mismatch
            and not variable_type_mismatch
            and not objective_mismatch
            and not fixed_failures
            and not suffix_failures
            and not unknown_rows
        ),
        "original_pairb_recovery": {
            "jobs": args.jobs,
            "fixed_jobs": len(fixed_jobs),
            "eligible_jobs": len(eligible),
            "eligible_completion_deadline_min": min(deadlines[i] for i in eligible),
            "eligible_completion_deadline_max": recovered_deadline_max,
            "deadline_safety_added": args.deadline_safety,
            "safe_common_deadline": common_deadline,
            "deadline_definition": "upper_bound(start_i) + processing_time_i",
        },
        "master": {
            "variables": len(variables),
            "rows": len(master.getConstrs()),
            "expected_rows": expected_rows,
            "fixed_rows": len(fixed),
            "suffix_rows": len(thresholds),
            "unknown_rows": unknown_rows,
        },
        "objective_mismatches": objective_mismatch,
        "variable_name_mismatches": variable_name_mismatch,
        "variable_type_mismatches": variable_type_mismatch,
        "max_objective_difference": max_objective_difference,
        "fixed_row_failures": fixed_failures,
        "max_fixed_row_difference": max_fixed_difference,
        "suffix_row_failures": suffix_failures,
        "max_suffix_coefficient_difference": max_suffix_coefficient_difference,
        "max_suffix_rhs_difference": max_suffix_rhs_difference,
        "validity_argument": "For any threshold t, each selected job with r_i >= t must execute all p_i units after t and no later than D_safe, where D_safe is at least the maximum eligible completion deadline. Single-machine capacity therefore implies sum p_i z_i <= D_safe-t. Thus every suffix row is a necessary condition and the master objective is a valid global lower bound for the minimization MPS.",
        "sha256": {
            "original_mps": sha256(args.original_mps),
            "master_mps": sha256(args.master_mps),
        },
    }
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
