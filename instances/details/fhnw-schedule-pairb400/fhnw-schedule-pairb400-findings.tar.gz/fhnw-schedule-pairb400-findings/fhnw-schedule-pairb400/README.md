# fhnw-schedule-pairb400 — solver-verified OPT = -36.27696674236886

2026-09-14 independent dual-bound review: [adopted bound, proof chain, checks, and limitations](../../docs/dual-bound-audit-2026-09-14/cases/fhnw-schedule-pairb400.zh.md). Reviewed lower bound: **-36.276966742368865136**. Use this exact certified decimal; superseded floating-point headline digits below are historical. This review distinguishes exact, literature, and numerical evidence; historical statements below remain dated records.

Official MIPLIB page: <https://miplib.zib.de/instance_details_fhnw-schedule-pairb400.html>

## Result

```text
MIPLIB headline                    -35.4584
public variables, recomputed       -35.45840605462827
new strict optimum                 -36.27696674236886
improvement vs recomputed public     0.81856068774059
improvement vs displayed headline    0.81856674236886
selected jobs                       60
```

This is a **solver-verified global conclusion**, not a DRAT/LRAT or
exact-rational certificate. A safe release-suffix relaxation built directly
from the official Pair-B MPS is solved to zero gap twice with different seeds
and thread counts. The matching full witness is checked against all 399,096
rows of the untouched original MPS and is cross-audited in Pair A.

## Independent safe master

The Pair-B model has 160,400 variables and 399,096 rows. Ninety-six jobs are
fixed to zero; the other 304 share a common completion deadline close to 1.
For each release threshold `t`, every original feasible selection satisfies

```text
sum_{i: r_i >= t} p_i z_i <= D_safe - t.
```

Here `D_safe = 1.000000000001`. A Decimal reconstruction finds the largest
eligible completion deadline to be `1.0000000000000002`, so the master remains
a conservative relaxation despite last-bit MPS roundoff. Seed 101 with one
thread closes in 45 nodes; Seed 149 with two threads closes in 36 nodes. Both
give primal=dual=`-36.27696674236886`. The reconstructed witness has maximum
original-row violation `3.0e-16`, zero bound/integrality violations and no row
violation above `1e-9`.

## Rejected earlier proof model

The archived final conclusion does **not** use the earlier 750 transferred
energetic cuts. Those cuts confused latest start with completion deadline and
can exclude feasible schedules. Their augmented-model bound and `OPTIMAL`
status are invalid; the 7 MiB invalid proof MPS is deliberately excluded from
this repository. See [`REJECTED-PROOF-NOTICE.md`](reports/REJECTED-PROOF-NOTICE.md).

## Evidence and reproduction

- [`summary.json`](artifacts/summary.json) is the portable compact result.
- [`common-deadline-master-safe.mps.gz`](artifacts/common-deadline-master-safe.mps.gz)
  is the frozen safe relaxation.
- [`common-deadline-master-safe-result.json`](artifacts/common-deadline-master-safe-result.json)
  and [`common-deadline-master-safe-rerun-result.json`](artifacts/common-deadline-master-safe-rerun-result.json)
  record independent zero-gap runs.
- [`common-deadline-master-safe-semantic-audit.json`](artifacts/common-deadline-master-safe-semantic-audit.json)
  and its [rerun audit](artifacts/common-deadline-master-safe-rerun-semantic-audit.json)
  verify every master row.
- [`global-optimal.sol`](solutions/global-optimal.sol) is the final witness.
- Pair-A/Pair-B full-row cross-audit is in
  [`../fhnw-schedule-paira400/artifacts/independent-cross-audit.json`](../fhnw-schedule-paira400/artifacts/independent-cross-audit.json).

The scripts require Gurobi:

```sh
python scripts/pairb_common_deadline_master.py \
  input/fhnw-schedule-pairb400.mps.gz solutions/global-optimal.sol \
  /tmp/pairb400-master --jobs 400 --threads 1 --seed 101 \
  --deadline-safety 1e-12

python scripts/audit_common_deadline_master.py \
  input/fhnw-schedule-pairb400.mps.gz \
  artifacts/common-deadline-master-safe.mps.gz \
  /tmp/pairb400-master-audit.json --jobs 400 --deadline-safety 1e-12
```

Hashes are in [`input/SHA256SUMS`](input/SHA256SUMS). The shared family report
is [`../../docs/fhnw-schedule-pair-family-2026-09-08.zh.md`](../../docs/fhnw-schedule-pair-family-2026-09-08.zh.md).
