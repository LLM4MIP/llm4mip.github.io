# Input provenance

The original MPS is intentionally not stored in this repository.

- MIPLIB page: <https://miplib.zib.de/instance_details_dws012-01.html>
- Official MPS: <https://miplib.zib.de/WebData/instances/dws012-01.mps.gz>
- Expected SHA-256: `b601b8afa4d626a5ea053849e9dc531e6d296c9b2357aee205ca141b431609e4`

Download it as `input/dws012-01.mps.gz` before running the checkers.
