#!/usr/bin/env python3
"""Evaluate and compare dws012-01 solution files against the original MPS."""

from __future__ import annotations

import collections
import gzip
import sys


def open_text(path: str):
    return gzip.open(path, "rt", encoding="iso-8859-1") if path.endswith(".gz") else open(path, encoding="iso-8859-1")


def read_mps(path: str):
    rows: dict[str, str] = {}
    rhs: dict[str, float] = collections.defaultdict(float)
    cols: dict[str, dict[str, float]] = collections.defaultdict(dict)
    obj: dict[str, float] = collections.defaultdict(float)
    section = ""
    objrow = ""
    with open_text(path) as stream:
        for raw in stream:
            f = raw.split()
            if not f or f[0] == "*":
                continue
            if f[0] in {"ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"} and len(f) == 1:
                section = f[0]
                continue
            if section == "ROWS":
                rows[f[1]] = f[0]
                if f[0] == "N":
                    objrow = f[1]
            elif section == "COLUMNS":
                if len(f) >= 3 and f[1].strip("'") == "MARKER":
                    continue
                var = f[0]
                for i in range(1, len(f), 2):
                    row, value = f[i], float(f[i + 1])
                    if row == objrow:
                        obj[var] += value
                    else:
                        cols[var][row] = cols[var].get(row, 0.0) + value
            elif section == "RHS":
                for i in range(1, len(f), 2):
                    rhs[f[i]] = float(f[i + 1])
    return rows, rhs, cols, obj


def read_solution(path: str) -> dict[str, float]:
    values = {}
    with open_text(path) as stream:
        for raw in stream:
            f = raw.split()
            if len(f) == 2 and not f[0].startswith(("#", "=obj=")):
                try:
                    values[f[0]] = float(f[1])
                except ValueError:
                    pass
    return values


def evaluate(rows, rhs, cols, obj, values):
    activity = collections.defaultdict(float)
    for var, incidences in cols.items():
        value = values.get(var, 0.0)
        for row, coef in incidences.items():
            activity[row] += coef * value
    violations = []
    for row, sense in rows.items():
        if sense == "N":
            continue
        residual = activity[row] - rhs[row]
        violation = max(0.0, residual) if sense == "L" else max(0.0, -residual) if sense == "G" else abs(residual)
        if violation:
            violations.append((violation, row, sense, activity[row], rhs[row]))
    objective = sum(coef * values.get(var, 0.0) for var, coef in obj.items())
    return objective, sorted(violations, reverse=True)


def main(mps: str, left_path: str, right_path: str) -> None:
    rows, rhs, cols, obj = read_mps(mps)
    left, right = read_solution(left_path), read_solution(right_path)
    for label, values in (("left", left), ("right", right)):
        objective, violations = evaluate(rows, rhs, cols, obj, values)
        print(f"{label}: listed={len(values)} objective={objective:.15g} max_row_violation={violations[0][0]:.15g}")
        print("  top_violations", violations[:8])
    changed = []
    for var in set(left) | set(right):
        delta = right.get(var, 0.0) - left.get(var, 0.0)
        if abs(delta) > 1e-12:
            changed.append((abs(obj[var] * delta), abs(delta), var, left.get(var, 0.0), right.get(var, 0.0), obj[var]))
    changed.sort(reverse=True)
    print(f"changed_variables={len(changed)}")
    for _, _, var, lval, rval, coef in changed[:40]:
        print(f"  {var}: {lval:.15g} -> {rval:.15g}; delta={rval-lval:.15g}; objcoef={coef:g}; objdelta={coef*(rval-lval):.15g}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], sys.argv[3])
