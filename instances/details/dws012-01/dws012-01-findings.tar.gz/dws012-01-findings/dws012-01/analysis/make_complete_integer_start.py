#!/usr/bin/env python3
"""Build a complete integer-only MIP start from a sparse solution.

All integer variables omitted from the sparse solution are assigned zero.
Continuous values are deliberately omitted so Gurobi can recompute them.
"""

from __future__ import annotations

import gzip
import math
import sys


def open_text(path: str):
    return gzip.open(path, "rt", encoding="iso-8859-1") if path.endswith(".gz") else open(path, encoding="iso-8859-1")


def integer_variables(mps_path: str) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    section = ""
    integer_mode = False
    bound_declared_integer: list[str] = []
    with open_text(mps_path) as stream:
        for raw in stream:
            fields = raw.split()
            if not fields or fields[0] == "*":
                continue
            if fields[0] in {"ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"} and len(fields) == 1:
                section = fields[0]
                continue
            if section == "COLUMNS":
                if len(fields) >= 3 and fields[1].strip("'") == "MARKER":
                    integer_mode = fields[2].strip("'") == "INTORG"
                    continue
                var = fields[0]
                if integer_mode and var not in seen:
                    seen.add(var)
                    result.append(var)
            elif section == "BOUNDS" and len(fields) >= 3 and fields[0] in {"BV", "LI", "UI"}:
                bound_declared_integer.append(fields[2])
    for var in bound_declared_integer:
        if var not in seen:
            seen.add(var)
            result.append(var)
    return result


def read_solution(path: str) -> dict[str, float]:
    values: dict[str, float] = {}
    with open_text(path) as stream:
        for raw in stream:
            fields = raw.split()
            if len(fields) != 2 or fields[0].startswith(("#", "=obj=")):
                continue
            try:
                values[fields[0]] = float(fields[1])
            except ValueError:
                pass
    return values


def main(mps_path: str, sparse_solution: str, output_path: str) -> None:
    integer_vars = integer_variables(mps_path)
    sparse = read_solution(sparse_solution)
    specified = 0
    rounded = 0
    with open(output_path, "w", encoding="ascii") as out:
        out.write("# Complete integer assignment; continuous variables intentionally omitted.\n")
        for var in integer_vars:
            value = sparse.get(var, 0.0)
            if var in sparse:
                specified += 1
            nearest = round(value)
            error = abs(value - nearest)
            if error > 1e-6:
                raise ValueError(f"official value for integer {var} is {value}, distance {error} from integer")
            if error:
                rounded += 1
            out.write(f"{var} {nearest}\n")
    continuous_listed = sorted(set(sparse) - set(integer_vars))
    print(f"integer_variables={len(integer_vars)}")
    print(f"official_integer_values={specified}")
    print(f"rounded_integer_values={rounded}")
    print(f"continuous_values_omitted={len(continuous_listed)}")
    print(f"output={output_path}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], sys.argv[3])
