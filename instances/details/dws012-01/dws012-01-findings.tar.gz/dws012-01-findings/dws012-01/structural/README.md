# `dws012-01`: structural audit and exact-reformulation blueprint

## Bottom line

The instance is **not solved**.  Its apparent size is dominated by two unary
encodings, not by 15,576 independent binary decisions.  An audit of the
original decimal MPS proves that its binary feasible configurations can be
represented with 924 binary variables instead of 15,576 (a 94.1% reduction):

| family | original binaries | exact projected formulation |
|---|---:|---:|
| pipe selected | 66 | 66 |
| pump installed | 198 | represented by joint pump state |
| pump operated | 198 | eliminated (`operate = install`) |
| pump-grid triangle | 14,256 | 528 (8 code bits x 66 pipes) |
| diameter interval | 792 | 330 (5 code bits x 66 pipes) |
| flow sign | 66 | eliminated (all are fixed to one) |
| **total** | **15,576** | **924** |

This is a **proved exact projection/lift blueprint**, relative to the decimal
coefficients in the MPS.  It is not a generated reduced MPS, and the projected
formulation has not been solved.  The result therefore establishes a safe and
potentially useful reformulation route, not a new primal or dual certificate.

## Files and reproducibility

- Original model (download separately): `../input/dws012-01.mps.gz`
- Published sparse incumbent: `../solutions/official-id2.sol.gz`
- Published original decomposition: `official_original.dec`
- Published presolved decomposition: `official_presolved.dec`
- Independent parser/checker: `verify_structure.py`
- Solver investigation and strict-incumbent evidence: [`../README.md`](../README.md)

Run the structural audit without invoking an optimizer:

```sh
python3 dws012-01/structural/verify_structure.py
```

The result is `status: PASS`.  Principal output is:

```text
model                         14,280 rows, 26,148 columns, 132,936 nonzeros
variables                     15,576 binary, 10,572 continuous
official decomposition        199 blocks; 3,192-row core; 198 x 49-row blocks
border                        1,386 rows
small-block variables         198 x (49 continuous + 72 binary)
operate/install equalities    198
fixed sign binaries           66
pump states per pipe          217; 8 code bits
diameter states per pipe      19; 5 code bits
projected binary count        924
incumbent objective           82030.53014261137
maximum incumbent residual    6.943767418832181e-07
status                        PASS
```

SHA-256 identifiers:

```text
b601b8afa4d626a5ea053849e9dc531e6d296c9b2357aee205ca141b431609e4  input/dws012-01.mps.gz
18c664efa10a243dcfb97dd518387be69d84520a7a304e81c09d9f4ca8b97c98  solutions/official-id2.sol.gz
cb931de6ff9768dca441fdb883420a4202ccb97ad36ae45b671c8a442f632c0a  structural/official_original.dec
bf851f898e737737f5be9d69d3c90541414a6d94db9a5da19ff0674fab15b18b  structural/official_presolved.dec
bd45680dcdf957c80d69b06dee6e188d15564f688a971dcc845046c3df38d644  structural/verify_structure.py
```

## What the model represents

This is a 12-floor decentralized drinking-water network design model.  Every
lower/upper-floor pair is a candidate directed pipe, hence
`12*11/2 = 66` candidate arcs.  A selected pipe may carry at most one of three
pump types.  The objective is pipe investment, pump investment, and operating
power.  The pump curves are represented by an aggregated-convex-combination
(ACC) approximation on a 7 by 7 grid with a 6 by 6 Freudenthal triangulation,
which has 72 triangles.

The interpretation and grid dimensions agree with the formulation paper,
"A Comparison of MILP and MINLP Solver Performance on the Example of a
Drinking Water Supply System Design Problem":
<https://www.eccomas2016.org/proceedings/pdf/8717.pdf>.  The public instance
record is <https://miplib.zib.de/instance_details_dws012-01.html>.

Useful variable families in the MPS are:

| MPS names | count | role |
|---|---:|---|
| `VAR1`--`VAR198` | 198 | pump power; master-only continuous columns |
| `VAR265`--`VAR462` | 198 | normalized pump speed |
| `VAR463`--`VAR660` | 198 | pump head |
| `VAR661`--`VAR726` | 66 | pipe flow |
| `VAR727`--`VAR738` | 12 | floor pressure/head |
| `VAR739`--`VAR804` | 66 | pipe-selection binaries |
| `VAR805`--`VAR1002` | 198 | pump-installation binaries |
| `VAR1003`--`VAR1200` | 198 | pump-operation/ACC activation binaries |
| `VAR1201`--`VAR1266` | 66 | pressure loss |
| `VAR1267`--`VAR1332` | 66 | pipe diameter |
| `VAR1333`--`VAR2124` | 792 | 12 diameter-interval binaries per pipe |
| `VAR2125`--`VAR2190` | 66 | auxiliary absolute flow |
| `VAR2191`--`VAR2256` | 66 | flow-sign binaries, fixed to one |
| `VAR2257`--`VAR11958` | 9,702 | 49 ACC weights per pump candidate |
| `VAR11959`--`VAR26214` | 14,256 | 72 triangle binaries per pump candidate |

There is no `VAR199`--`VAR264` family; the name gap is in the supplied MPS.
Only 462 variables have objective coefficients: 198 power, 66 pipe-selection,
and 198 pump-installation variables.

## Exact bordered decomposition

The complete row/column incidence graph is connected: it has one component
with all 14,280 rows and 26,148 variables.  Thus there is no ordinary connected
component split.  The useful structure is instead the published bordered
decomposition:

- block 1 is the hydraulic/design core (3,192 rows and 1,992 variables);
- blocks 2--199 are 198 pump-approximation blocks, one for every
  `(candidate pipe, pump type)` pair;
- every pump block has 49 continuous ACC weights, 72 triangle binaries, and
  49 local support rows;
- 1,386 master rows equal exactly `198*7` linking rows; and
- no variable belongs to the row sets of two different blocks.  The 198 power
  columns are master-only; a local pump column may occur in its local block and
  in the border.

For every pump block, the audit reconstructs the local rows as

```text
lambda[v] <= sum(z[t] : triangle t contains grid vertex v),  v=1,...,49.
```

Every triangle column touches exactly three grid vertices, and the 72 supports
are exactly the standard two triangles
`{v00,v01,v10}` and `{v01,v10,v11}` in each of the 36 grid cells.  The seven
border rows include the ACC-weight sum, speed, flow/activation pair, head,
power, and triangle-selection sum.  The small blocks contain no direct
objective coefficient.

The published presolved decomposition preserves all 198 49-row pump blocks
and all 1,386 border rows; only the core shrinks from 3,192 to 2,453 rows.  This
is strong evidence that the border is formulation-level structure rather than
an artifact of a particular unpresolved matrix ordering.

## Immediate exact eliminations

### Operation equals installation

For each of the 198 pump candidates, the MPS contains both
`operate - install >= 0` and `operate - install <= 0`.  Therefore
`operate = install` exactly.  Substitution deletes 198 binary variables and
396 rows.  Per candidate pipe, the three installation variables additionally
satisfy `sum(type installs) <= 1`, and each installation implies that its pipe
is selected.

### Flow sign and absolute-flow auxiliary

Each of the 66 sign binaries has an explicit equality `sign = 1`.  The first
two rows of its 28-row arc gadget are

```text
q - qabs <= 0,
-q + qabs + 61 sign <= 61.
```

After substituting `sign = 1`, they give `qabs = q`.  Hence all 66 sign
binaries and all 66 absolute-flow auxiliaries can be removed, with `q`
substituted into the remaining gadget rows.

### Fixed pressure and definitional diameters

Row `c13477` is the singleton equality `VAR727 = 22`, so that pressure variable
can be substituted.  Each `VAR1267`--`VAR1332` diameter column occurs only in
its defining equality and has bounds `[9,105]`; it can be eliminated by
substitution, retaining the induced lower and upper inequalities on its
selector expression.

## Exact eight-bit pump-state formulation

For one pipe, let `x_p` be installation, `y_p` operation, and `z_pt` triangle
selection for pump type `p in {1,2,3}` and triangle `t in {1,...,72}`.  The MPS
implies

```text
y_p = x_p,
sum_t z_pt = y_p,
sum_p x_p <= 1.
```

Thus the joint binary vector has exactly 217 possible states: one all-off
state, or one of `3*72 = 216` `(pump type, triangle)` states.  No other binary
pattern is feasible.

An exact logarithmic embedding is as follows.  Give the 217 states distinct
codes `h_s in {0,1}^8`.  Reuse the 216 triangle variables as continuous state
weights `theta_s`, add an off-state weight `theta_0`, and impose

```text
sum_s theta_s = 1,             theta_s >= 0,
w_j = sum_s h_sj theta_s,      w_j binary,  j=1,...,8.
```

If a code coordinate `w_j` is 0 or 1, every state with positive weight must
agree at that coordinate.  Since all codes are distinct, all positive-weight
states must be the same state.  Consequently one `theta_s` is one and the rest
are zero.  This proves integrality of the state weights; it is not merely an
LP heuristic.

Recover `x_p = y_p = sum_t theta_(p,t)`, substitute these expressions in the
pipe implications and pump-cost objective, and use `theta_(p,t)` in the
existing ACC support rows.  Projection gives every original feasible point.
Conversely, the unique active state directly lifts to the original
installation, operation, and triangle binaries, while leaving the ACC weights
unchanged.  This proves two-way feasibility and objective preservation.

The replacement uses 8 binaries per pipe rather than 3 installation, 3
operation, and 216 triangle binaries: 528 rather than 14,652 binaries over all
66 pipes.

## Exact five-bit diameter-state formulation

The 12 diameter binaries do **not** obey a hidden exactly-one constraint, so
adding `sum u_j = 1` would be an invalid reduction.  Their flow intervals are

```text
lower = [0,.5,.7,1.1,1.8,2.9,4.3,7.4,10.2,14.7,20.4,30.6]
upper = [.5,.7,1.1,1.8,2.9,4.3,7.4,10.2,14.7,20.4,30.6,60]
diam  = [10,13,16,19.6,25.6,32,39,51,60,72.1,84.9,104]
```

Exhaustive enumeration of the `2^12` patterns, checking interval intersection
and the induced diameter bound `[9,105]`, leaves exactly 19 supports:

- 12 singleton supports; and
- 7 adjacent-pair supports at shared flow breakpoints.

The seven pairs are permitted by the local MPS gadget at shared boundaries;
without a separate global infeasibility proof they cannot safely be deleted.
The eighth adjacent pair would have diameter `51+60=111`, violating the upper
bound, and later pairs are larger.

Assign distinct five-bit codes to the 19 supports and introduce a simplex of
19 nonnegative state weights with the same code equations as above.  The same
coordinate argument makes exactly one state active.  For state `s`, define
`L_s=max(lower_j)` and `U_s=min(upper_j)` over its support and impose

```text
sum_s L_s theta_s <= q <= sum_s U_s theta_s,
u_j = sum_(s containing j) theta_s.
```

All occurrences of `u_j`, including diameter and pressure-loss coefficients,
can then be replaced by the right-hand expression.  Projection recovers the
original selector pattern; lifting chooses the active state's support.  This
is an exact union-of-polyhedra representation using five binaries per pipe,
or 330 rather than 792 in total.

## Decomposition and CP implications

The genuine combinatorial core is a packing/network-design decision on 66
possible upward pipes with at most one of three pump types per pipe.  The
14,256 triangle binaries are chiefly a unary encoding of 72 local modes.  This
suggests three concrete approaches:

1. Build and test the exact logarithmic state formulation above.  It attacks
   the largest avoidable source of integrality directly.
2. Use Dantzig--Wolfe/branch-and-price on the published border.  Each pump
   block has only 72 active triangle modes (plus off), and pricing within a
   chosen triangle is a tiny continuous problem.  Full enumeration is also
   plausible at this scale.
3. In a hybrid CP/MILP model, use table/domain constraints for the 217 pump
   states and 19 diameter states, leaving flow, head, pressure-loss, and ACC
   interpolation to an LP/MILP engine.  A pure CP-SAT transcription would
   require delicate scaling of the decimal hydraulic coefficients and is less
   natural.

Literal signature checks find no duplicate full columns, duplicate
constraint-matrix columns, or duplicate rows.  Repeated local topology is not
a valid global permutation symmetry: pump curves/costs and the floor-pair
hydraulic data distinguish the blocks.  No coefficient-preserving global
symmetry or safe dominance fixing was established.

## Incumbent audit and bounded solve status

The published sparse solution declares `82030.53014261136`; direct evaluation
against the decimal MPS gives `82030.53014261137`, with objective split

```text
operating power   57437.280142611366
pipe investment    7200.000000000000
pump investment   17393.250000000000
```

It has integral listed integer values and no bound violation, but its maximum
row residual is `6.943767418832181e-07`.  It is accepted at the usual `1e-6`
feasibility tolerance, not at `1e-9`; it should not be described as an exact
feasible certificate.

A separate strict repair kept exactly the published integer design and
reoptimized only continuous recourse, producing objective
`82030.5522222395` with original-MPS residual below `1e-12`.  A bounded
600-second, two-thread proof run retained that incumbent and ended at lower
bound `44641.72316928` (45.5792% gap).  See [`../README.md`](../README.md) and
`../logs/original-proof-600s.log`.  Hence neither the direct
run nor this structural audit proves optimality.
