# `genus-sym-grafo5708-48`

## Result

**Global conclusion: the optimum is -21 (orientable genus 4).**

The MPS graph is matched to the genus-preserving core of the Rome graph
`grafo5708.48`. The official solution gives a directly checkable 21-face
rotation and objective **-21**, corresponding to orientable genus **4**.
A specialized exhaustive decision run separately rules out genus at most 3.

Together these form an **exact computational optimality proof**. The
upper-bound rotation is portable, while the lower-bound computation is
preserved through source information, hashes, and logs rather than a standalone
proof trace.

## Provenance

- Compressed MPS SHA-256: `7AA642A95AA5B792C1553F3383E0FB229A92653CF41CA6D62C9095715641C4BC`
- Official compressed solution SHA-256: `725FECF6B7CE78C6FA77BA87604F83124766E511C148B5046DCE7F77A6D994C1`
- [MIPLIB instance page](https://miplib.zib.de/instance_details_genus-sym-grafo5708-48.html)

Run [`scripts/verify.py`](scripts/verify.py) to reproduce the graph mapping,
symmetry, solution, and rotation audits. See the
[full report](reports/structural-investigation.md), [`artifacts/`](artifacts/),
and [`logs/`](logs/) for the evidence boundary and execution hashes.
