#!/usr/bin/env python3
"""Reproduce the rank-14 genus-sym-grafo5708-48 audit.

The script performs no generic MIP solve.  It validates the official MIPLIB
solution, verifies the Rome-graph reduction and label map, proves that the 26
precedence rows only select a representative of the full face-label symmetry,
and runs Gunnar Brinkmann's serial exact genus executable in both optimization
and genus-at-most-3 decision modes.
"""

from __future__ import annotations

import argparse
import collections
import hashlib
import importlib.util
from pathlib import Path
import re


NAME = "genus-sym-grafo5708-48"
FACE_SLOTS = tuple(range(27))
LEAF_ORDER = (5, 6, 15, 29)
SUPPRESSION_ORDER = (2, 9, 11, 14, 18, 20, 21, 22, 24, 36, 39, 41, 43, 47)
ORIGINAL_TO_MPS = {
    1: 0,
    3: 2,
    4: 4,
    7: 18,
    8: 13,
    10: 11,
    12: 17,
    13: 1,
    16: 3,
    17: 23,
    19: 28,
    23: 27,
    25: 16,
    26: 10,
    27: 5,
    28: 21,
    30: 26,
    31: 8,
    32: 12,
    33: 7,
    34: 15,
    35: 24,
    37: 20,
    38: 25,
    40: 6,
    42: 29,
    44: 9,
    45: 22,
    46: 14,
    48: 19,
}


def load_helpers(path: Path):
    spec = importlib.util.spec_from_file_location("genus_artifacts", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def degree_histogram(edges: set[tuple[int, int]], vertices: set[int]) -> dict[int, int]:
    adjacency = {vertex: set() for vertex in vertices}
    for u, v in edges:
        adjacency[u].add(v)
        adjacency[v].add(u)
    return dict(sorted(collections.Counter(map(len, adjacency.values())).items()))


def parse_rome(path: Path) -> tuple[set[int], set[tuple[int, int]]]:
    vertices: set[int] = set()
    edges: set[tuple[int, int]] = set()
    after_marker = False
    for raw in path.read_text(encoding="ascii").splitlines():
        line = raw.strip()
        if not line:
            continue
        if line == "#":
            after_marker = True
            continue
        words = line.split()
        if not after_marker:
            if len(words) != 2:
                raise ValueError(f"Unexpected Rome vertex line: {line}")
            vertices.add(int(words[0]))
        else:
            if len(words) != 4:
                raise ValueError(f"Unexpected Rome edge line: {line}")
            u, v = int(words[2]), int(words[3])
            if u == v:
                raise ValueError("Rome graph contains a loop")
            edge = tuple(sorted((u, v)))
            if edge in edges:
                raise ValueError("Rome graph contains a duplicate edge")
            edges.add(edge)
    return vertices, edges


def reduce_rome(
    vertices: set[int], edges: set[tuple[int, int]]
) -> tuple[set[int], set[tuple[int, int]], list[str]]:
    vertices = set(vertices)
    edges = set(edges)
    operations: list[str] = []

    def neighbors(vertex: int) -> list[int]:
        return sorted(v if u == vertex else u for u, v in edges if vertex in (u, v))

    for vertex in LEAF_ORDER:
        adjacent = neighbors(vertex)
        if len(adjacent) != 1:
            raise AssertionError(f"Expected leaf {vertex}, got neighbors {adjacent}")
        edges.remove(tuple(sorted((vertex, adjacent[0]))))
        vertices.remove(vertex)
        operations.append(f"delete leaf {vertex} adjacent to {adjacent[0]}")

    for vertex in SUPPRESSION_ORDER:
        adjacent = neighbors(vertex)
        if len(adjacent) != 2:
            raise AssertionError(f"Expected degree-2 vertex {vertex}, got {adjacent}")
        a, b = adjacent
        edges.remove(tuple(sorted((vertex, a))))
        edges.remove(tuple(sorted((vertex, b))))
        vertices.remove(vertex)
        new_edge = tuple(sorted((a, b)))
        if new_edge in edges:
            raise AssertionError(f"Suppression of {vertex} creates parallel edge {new_edge}")
        edges.add(new_edge)
        operations.append(f"suppress {vertex} between {a} and {b}")
    return vertices, edges, operations


def transform_face_variable(name: str, a: int, b: int) -> str:
    match = re.fullmatch(r"x(\d+)", name)
    if match:
        index = int(match.group(1))
        if index == a:
            return f"x{b}"
        if index == b:
            return f"x{a}"
        return name
    match = re.fullmatch(r"c(\d+)_(\d+)_(\d+)", name)
    if match:
        index, u, v = map(int, match.groups())
        if index == a:
            index = b
        elif index == b:
            index = a
        return f"c{index}_{u}_{v}"
    return name


def symmetry_audit(model: dict) -> dict:
    precedence_rows = []
    for index in range(26):
        wanted = {f"x{index}": 1.0, f"x{index + 1}": -1.0}
        matches = [
            row
            for row, coefficients in model["coefficients"].items()
            if coefficients == wanted
            and model["row_type"][row] == "G"
            and model["rhs"][row] == 0.0
        ]
        if len(matches) != 1:
            raise AssertionError(f"Precedence row {index} matches={matches}")
        precedence_rows.extend(matches)
    if len(set(precedence_rows)) != 26:
        raise AssertionError("Precedence rows are not distinct")

    base_rows = [
        row
        for row, kind in model["row_type"].items()
        if kind != "N" and row not in set(precedence_rows)
    ]

    def row_counter(a: int | None = None, b: int | None = None):
        result = collections.Counter()
        for row in base_rows:
            coefficients = model["coefficients"][row]
            if a is None:
                terms = tuple(sorted(coefficients.items()))
            else:
                terms = tuple(
                    sorted(
                        (transform_face_variable(variable, a, b), value)
                        for variable, value in coefficients.items()
                    )
                )
            result[(model["row_type"][row], model["rhs"][row], terms)] += 1
        return result

    original_rows = row_counter()
    adjacent_swap_checks = []
    for index in range(26):
        a, b = index, index + 1
        row_invariant = row_counter(a, b) == original_rows
        variable_invariant = all(
            transform_face_variable(variable, a, b) in model["variables"]
            for variable in model["variables"]
        )
        domains_invariant = all(
            model["lower"][variable]
            == model["lower"][transform_face_variable(variable, a, b)]
            and model["upper"][variable]
            == model["upper"][transform_face_variable(variable, a, b)]
            and (variable in model["integer"])
            == (transform_face_variable(variable, a, b) in model["integer"])
            for variable in model["variables"]
        )
        objective_invariant = all(
            model["objective"].get(variable, 0.0)
            == model["objective"].get(transform_face_variable(variable, a, b), 0.0)
            for variable in model["variables"]
        )
        adjacent_swap_checks.append(
            (a, b, row_invariant, variable_invariant, domains_invariant, objective_invariant)
        )
    all_adjacent_swaps_are_automorphisms = all(all(item[2:]) for item in adjacent_swap_checks)

    parity_matches = []
    parity_coefficients = {f"x{index}": 1.0 for index in FACE_SLOTS}
    parity_coefficients["x3379"] = -2.0
    for row, coefficients in model["coefficients"].items():
        if (
            coefficients == parity_coefficients
            and model["row_type"][row] == "E"
            and model["rhs"][row] == 1.0
        ):
            parity_matches.append(row)

    objective_expected = {f"x{index}": -1.0 for index in FACE_SLOTS}
    objective_expected["x28"] = -1.0
    return {
        "precedence_rows": precedence_rows,
        "base_row_count": len(base_rows),
        "adjacent_swap_checks": adjacent_swap_checks,
        "all_adjacent_swaps_are_automorphisms": all_adjacent_swaps_are_automorphisms,
        "parity_rows": parity_matches,
        "objective_exact": model["objective"] == objective_expected,
        "active_face_domains_exact": all(
            model["lower"][f"x{index}"] == 0.0
            and model["upper"][f"x{index}"] == 1.0
            and f"x{index}" in model["integer"]
            for index in FACE_SLOTS
        ),
        "dummy_x28_fixed_zero": model["lower"]["x28"] == model["upper"]["x28"] == 0.0,
        "parity_integer_domain_exact": (
            model["lower"]["x3379"] == 0.0
            and model["upper"]["x3379"] == 13.0
            and "x3379" in model["integer"]
        ),
    }


def multi_genus_log(name: str, result: dict, input_code: bytes, mode: str) -> str:
    lines = [
        f"instance={NAME}",
        "algorithm=multi_genus (serial, one process/thread)",
        f"mode={mode}",
        f"command={' '.join(result['command'])}",
        f"stdin=reports/{NAME}.mc",
        f"input_bytes={len(input_code)}",
        f"input_sha256={sha256_bytes(input_code)}",
        f"timeout_seconds={result['timeout']}",
        f"elapsed_seconds={result['elapsed']:.6f}",
        f"timed_out={result['timed_out']}",
        f"returncode={result['returncode']}",
        f"stdout_bytes={len(result['stdout'])}",
        f"stdout_sha256={sha256_bytes(result['stdout'])}",
        f"stdout_equals_input_multicode={result['stdout'] == input_code}",
        "stderr_begin",
        result["stderr"].rstrip(),
        "stderr_end",
    ]
    if result["check"] is not None:
        check = result["check"]
        lines.extend(
            [
                f"rotation_edge_exact={check['edge_exact']}",
                f"rotation_faces={len(check['faces'])}",
                f"rotation_face_lengths={sorted(map(len, check['faces']))}",
                f"rotation_dart_total={check['dart_total']}",
                f"rotation_genus={check['genus']}",
            ]
        )
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser()
    instance_root = Path(__file__).resolve().parents[1]
    repository_root = Path(__file__).resolve().parents[3]
    parser.add_argument("--source-graph", type=Path, required=True)
    parser.add_argument("--multi-genus", type=Path, required=True)
    parser.add_argument("--timeout", type=float, default=60.0)
    args = parser.parse_args()
    if not (0.0 < args.timeout <= 600.0):
        raise ValueError("timeout must be in (0,600]")

    helper = load_helpers(repository_root / "common" / "reproduce_genus_artifacts.py")
    model_path = instance_root / "input" / f"{NAME}.mps.gz"
    solution_path = instance_root / "solutions" / "official-21.sol.gz"
    rome_path = args.source_graph
    reports = instance_root / "artifacts"
    logs = instance_root / "logs"
    reports.mkdir(exist_ok=True)
    logs.mkdir(exist_ok=True)

    model = helper.parse_mps(model_path)
    values, claimed = helper.parse_solution(solution_path)
    validation = helper.validate_solution(model, values)
    official_rotation = helper.rotation_from_solution(model, values)
    official_check = helper.check_rotation(model, official_rotation)
    official_faces = helper.check_face_assignment(model, values, official_rotation)

    original_vertices, original_edges = parse_rome(rome_path)
    reduced_vertices, reduced_edges, reduction_operations = reduce_rome(
        original_vertices, original_edges
    )
    if reduced_vertices != set(ORIGINAL_TO_MPS):
        raise AssertionError("Reduced Rome vertex set does not match the recorded map")
    mapped_edges = {
        tuple(sorted((ORIGINAL_TO_MPS[u], ORIGINAL_TO_MPS[v]))) for u, v in reduced_edges
    }
    provenance_edge_exact = mapped_edges == model["edges"]
    if not provenance_edge_exact:
        raise AssertionError("Reduced Rome graph does not map exactly to the MPS graph")

    symmetry = symmetry_audit(model)
    if not all(
        (
            symmetry["all_adjacent_swaps_are_automorphisms"],
            symmetry["objective_exact"],
            symmetry["active_face_domains_exact"],
            symmetry["dummy_x28_fixed_zero"],
            symmetry["parity_integer_domain_exact"],
            len(symmetry["parity_rows"]) == 1,
        )
    ):
        raise AssertionError(f"Symmetry/objective audit failed: {symmetry}")

    input_code = helper.multicode(model)
    (reports / f"{NAME}.mc").write_bytes(input_code)
    full = helper.run_multi_genus(args.multi_genus, model, args.timeout, ["w"])
    decision = helper.run_multi_genus(args.multi_genus, model, args.timeout, ["l3", "F"])
    if (
        full["timed_out"]
        or full["returncode"] != 0
        or full["check"] is None
        or not full["check"]["edge_exact"]
        or full["check"]["genus"] != 4
    ):
        raise AssertionError("Full exact genus computation did not return a genus-4 rotation")
    if (
        decision["timed_out"]
        or decision["returncode"] != 0
        or decision["stdout"] != input_code
        or "With genus larger than 3: 1" not in decision["stderr"]
    ):
        raise AssertionError("Decision computation did not exclude genus at most 3")

    (reports / f"{NAME}.exact-rotation.txt").write_text(
        helper.rotation_text(NAME, "serial multi_genus exact run", model, full["rotation"])
    )
    (logs / f"{NAME}.multi-genus.log").write_text(
        multi_genus_log(NAME, full, input_code, "minimum-genus embedding")
    )
    (logs / f"{NAME}.multi-genus-decision-gt-3.log").write_text(
        multi_genus_log(NAME, decision, input_code, "exclude orientable genus <=3")
    )

    mapping_lines = [
        "# original Rome vertex -> MPS core vertex",
        *[f"{original}\t{mps}" for original, mps in sorted(ORIGINAL_TO_MPS.items())],
    ]
    (reports / f"{NAME}.rome-to-mps.tsv").write_text("\n".join(mapping_lines) + "\n")

    audit_lines = [
        f"instance={NAME}",
        f"model_sha256={helper.sha256(model_path)}",
        f"solution_sha256={helper.sha256(solution_path)}",
        f"rome_graph_sha256={helper.sha256(rome_path)}",
        f"mps_variables={len(model['variables'])}",
        f"mps_constraints={sum(kind != 'N' for kind in model['row_type'].values())}",
        f"mps_graph_vertices={len(model['adjacency'])}",
        f"mps_graph_edges={len(model['edges'])}",
        f"mps_degree_histogram={degree_histogram(model['edges'], set(model['adjacency']))}",
        f"rome_vertices={len(original_vertices)}",
        f"rome_edges={len(original_edges)}",
        f"rome_degree_histogram={degree_histogram(original_edges, original_vertices)}",
        f"reduction_operations={reduction_operations}",
        f"reduced_vertices={len(reduced_vertices)}",
        f"reduced_edges={len(reduced_edges)}",
        f"reduced_degree_histogram={degree_histogram(reduced_edges, reduced_vertices)}",
        f"rome_to_mps_edge_exact={provenance_edge_exact}",
        f"objective_exactly_minus_usable_faces_plus_fixed_dummy={symmetry['objective_exact']}",
        f"dummy_x28_fixed_zero={symmetry['dummy_x28_fixed_zero']}",
        f"precedence_rows={symmetry['precedence_rows']}",
        f"base_rows_after_removing_precedence={symmetry['base_row_count']}",
        f"all_26_adjacent_face_label_swaps_are_base_model_automorphisms={symmetry['all_adjacent_swaps_are_automorphisms']}",
        f"adjacent_swap_checks={symmetry['adjacent_swap_checks']}",
        f"parity_rows={symmetry['parity_rows']}",
        "parity_equation=sum(x0..x26)-2*x3379=1",
        f"claimed_objective={claimed}",
        f"computed_objective={validation['objective']}",
        f"max_bound_violation={validation['max_bound_violation']}",
        f"max_integrality_violation={validation['max_integrality_violation']}",
        f"max_row_violation={validation['max_row_violation']}",
        f"official_rotation_edge_exact={official_check['edge_exact']}",
        f"official_rotation_faces={len(official_check['faces'])}",
        f"official_rotation_darts={official_check['dart_total']}",
        f"official_rotation_genus={official_check['genus']}",
        f"official_face_assignment_exact_dart_set_match={official_faces['exact_dart_set_match']}",
        "euler_relation=genus=(2-30+57-F)/2=(29-F)/2",
        "conclusion=minimum_orientable_genus=4; exact_MPS_objective=-21",
        "certificate_caveat=genus-4 rotations are directly checkable; genus>3 is an exhaustive executable result without a standalone proof certificate",
    ]
    (logs / f"{NAME}.rank14-audit.log").write_text("\n".join(audit_lines) + "\n")

    print("rank14 verification complete")
    print(f"full_elapsed_seconds={full['elapsed']:.6f}")
    print(f"decision_elapsed_seconds={decision['elapsed']:.6f}")
    print("minimum_orientable_genus=4")
    print("exact_MPS_objective=-21")


if __name__ == "__main__":
    main()
