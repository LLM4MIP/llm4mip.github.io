# Rank 14: `genus-sym-grafo5708-48`

## Result

The instance is closed by a specialized exact computation:

\[
\gamma(G)=4,\qquad \min(\text{MPS objective})=-21.
\]

Here \(\gamma\) is orientable genus. The official MIPLIB incumbent is a valid
genus-4 embedding, and a separate serial `multi_genus l3 F` run exhaustively
excluded every embedding of genus at most 3. Both computations took less than
0.02 seconds; no generic MIP solve was used.

## Exact MPS semantics

The 3,379-variable, 20,538-row MPS contains 114 variables named
`c0_u_v`, one for each directed arc of a simple 30-vertex, 57-edge graph.
The recovered graph has degree histogram
`{3: 16, 4: 8, 5: 2, 6: 4}`. Its full adjacency list is saved in
`genus-sym-grafo5708-48.adjacency.txt`.

There are 27 usable binary face indicators `x0,...,x26`. The objective is
their negative sum; the only other objective term is `-x28`, and `x28` is
fixed to zero. Therefore an embedding with \(F\) faces has MPS objective
\(-F\). The MPS also contains the exact parity equation

\[
\sum_{i=0}^{26}x_i-2x_{3379}=1,
\]

which is consistent with Euler parity. Since \(n=30\) and \(m=57\),

\[
30-57+F=2-2g,
\qquad
g=\frac{29-F}{2}.
\]

Thus the incumbent value `-21` means exactly \(F=21\) and \(g=4\).

## Symmetry breaking is WLOG

Rows `c952,...,c977` are exactly the 26 inequalities

\[
x_0\ge x_1\ge\cdots\ge x_{26}.
\]

After removing those rows, the audit simultaneously swaps adjacent face labels
\(i,i+1\) in every `x_i` and every `c_i_u_v`. For each of the 26 adjacent
swaps, the complete multiset of remaining typed rows, right-hand sides, and
coefficients is unchanged; variable domains, integrality, and objective
coefficients are unchanged as well. Since adjacent swaps generate
\(S_{27}\), the unsymmetrized formulation has full face-label symmetry. Any
feasible embedding can therefore relabel its \(F\) active face slots to
`0,...,F-1`, satisfying the chain. These 26 rows remove equivalent labelings
without removing any graph embedding or changing the optimum.

## Original graph provenance

MIPLIB describes this as the minimum-genus model of `grafo5708.48` from the
Rome Graphs. The archived Rome file has 48 vertices, 75 edges, and degree
histogram `{1: 4, 2: 12, 3: 16, 4: 10, 5: 2, 6: 4}`. Deleting leaves
`5,6,15,29` and then suppressing degree-2 vertices
`2,9,11,14,18,20,21,22,24,36,39,41,43,47` produces a 30-vertex, 57-edge
core. The saved 30-vertex label map sends every reduced Rome edge to an MPS
edge and vice versa, exactly.

Deleting leaves and subdividing or suppressing degree-2 vertices do not change
minimum orientable genus: the local additions fit inside a disk in any
embedding. Hence the MPS core and the original 48-vertex Rome graph have the
same genus.

The source file `grafo5708.48` is not redistributed here; download it from the
Rome Graphs source below and pass it to the verifier with `--source-graph`.
The exact map is `../artifacts/genus-sym-grafo5708-48.rome-to-mps.tsv`. The [Graph Drawing data
page](https://www.graphdrawing.org/data.html) identifies these files as the
Rome Graphs test suite. The [MIPLIB instance
page](https://miplib.zib.de/instance_details_genus-sym-grafo5708-48.html)
identifies this specific instance and its symmetry-breaking constraints.

## Incumbent and upper-bound certificate

The official solution was evaluated against every MPS row and variable domain:

- claimed and recomputed objective: `-21`;
- bound and integrality violations: zero;
- largest row residual: `9.992007221626409e-16`;
- unknown variables: none.

The `p` variables reconstruct a rotation system using every undirected edge
twice, with 114 directed darts partitioned into 21 face orbits. Moreover, the
positive `c_i_u_v` variables for the 21 selected face labels agree exactly with
those traced face-dart sets. Euler's formula then gives genus 4. The full
rotation is in `genus-sym-grafo5708-48.official-rotation.txt`. This is a small,
independently checkable combinatorial upper-bound certificate.

## Exact lower-bound computation

I compiled the serial `MultiGenus/multi_genus.c` implementation associated
with Gunnar Brinkmann's exact algorithm and ran it on the recovered graph's
87-byte multicode representation.

The full run

```text
multi_genus w
```

returned `graphs with genus 4: 1` and an edge-exact rotation with 21 faces in
`0.018849` seconds. A logically separate decision run

```text
multi_genus l3 F
```

returned `With genus larger than 3: 1` in `0.009102` seconds. In `F` mode it
also emitted exactly the 87 input bytes: both streams have SHA-256
`8af03aa803d1c61b873c70002dcc7234cb0987a1602a4dc64646133a4561a694`.
The implementation is serial, so both runs used one process/thread, with a
60-second timeout.

Brinkmann's paper describes an exact practical algorithm for oriented genus:
[arXiv:2005.08243](https://arxiv.org/abs/2005.08243), published as
[Ars Mathematica Contemporanea 22 (2022), P4.01](https://doi.org/10.26493/1855-3974.2320.c2d).
The exact source used here came from the
[`SanderGi/Genus` MultiGenus directory](https://github.com/SanderGi/Genus/tree/main/MultiGenus).
The MPS formulation is the one described by Beyer, Chimani, Hedtke, and
Kotrbčík in [SEA 2016](https://doi.org/10.1007/978-3-319-38851-9_6).

## Evidence boundary

The genus-4 rotations are directly checkable: one only needs to verify the
cyclic neighbor orders, trace the 21 faces, and apply Euler's formula. The
lower bound \(\gamma(G)>3\), however, is an exhaustive executable computation,
not a standalone DRAT-style or proof-assistant certificate. Reproduction pins
the model, graph, source, binary, compiler, command, input, and output hashes,
but independent trust in the lower bound still includes trust in the published
algorithm, the C implementation, compiler, and hardware execution.

## Reproduction artifacts

- `../scripts/verify.py`: one-command graph, symmetry, incumbent, and
  exact-computation audit.
- `../artifacts/genus-sym-grafo5708-48.adjacency.txt` and `.mc`: recovered graph.
- `../artifacts/genus-sym-grafo5708-48.rome-to-mps.tsv`: exact provenance map.
- `../artifacts/genus-sym-grafo5708-48.official-rotation.txt`: official witness.
- `../artifacts/genus-sym-grafo5708-48.exact-rotation.txt`: independent exact-code witness.
- `../logs/genus-sym-grafo5708-48.rank14-audit.log`: structural checks.
- `../logs/genus-sym-grafo5708-48.multi-genus.log`: full exact run.
- `../logs/genus-sym-grafo5708-48.multi-genus-decision-gt-3.log`: lower-bound
  decision run.
- `../artifacts/genus-sym-grafo5708-48.source-fingerprint.txt`: source and build hashes.
