# Package manifest: scpj4scip

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 35
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/dominance-certificate.json`
- `artifacts/dominance-copt-result.json`
- `artifacts/dominance-copt-solution-verification.json`
- `artifacts/dominance-reduced-structure.json`
- `artifacts/exchange-search.json`
- `artifacts/proof-target105-altman-verification.json`
- `artifacts/proof-target105-local-verification.json`
- `artifacts/proof-target105.json`
- `artifacts/proof-target106-altman-verification.json`
- `artifacts/proof-target106-local-verification.json`
- `artifacts/proof-target106.json`
- `artifacts/proof-target107-incomplete.json`
- `artifacts/scpj4scip-dominance-reduced.mps`
- `artifacts/structure.json`
- `artifacts/target107-local-pause-record.json`
- `logs/dominance-copt.log`
- `logs/original-copt-baseline.log`
- `logs/target107-euler-incomplete.log`
- `logs/target107-local-partial.log`
- `report.zh.md`
- `scripts/dominance_reduce.py`
- `scripts/encode_budget_cnf.py`
- `scripts/encode_strengthened_budget_cnf.py`
- `scripts/exact_setcover_bnb.py`
- `scripts/exchange_search.py`
- `scripts/run_copt_baseline.py`
- `scripts/setcover_structure.py`
- `scripts/verify_dominance.py`
- `scripts/verify_dual.py`
- `scripts/verify_setcover_bnb.py`
- `scripts/verify_setcover_solution.py`
- `scripts/write_budget_lp.py`
- `solutions/dominance-reduced.sol`
- `solutions/official-best.sol.gz`

## Excluded files

- `input/scpj4scip.mps.gz (4696918 bytes; raw benchmark input; sha256 df89aed179b4670acd415f981377794e4f90eb9d86b2ef927de13c46708d4080)`
