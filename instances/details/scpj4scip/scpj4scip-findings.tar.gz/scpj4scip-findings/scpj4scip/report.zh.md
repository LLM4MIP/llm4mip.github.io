#  scpj4scip Research records

##  Current Conclusions

`scpj4scip` is a weighted set-cover model with 99,947 binary columns and 1,000 covering constraints. The public solution objective
For 128, independent verification covers the entire 1,000 line. The current strict range is:

**107 ≤ OPT ≤ 128。**

The lower bound 107 is the strict conclusion of independent replay; the 108 .x numerical boundary reported by the solver does not serve as the strict proof.

##  Exact Dual and Reduced Dominance

The original model LP value is approximately 104.0837957004. If the feasible dual is scaled down to the denominator `10^9`, then
The 99,947 dual constraint is checked as a single integer, with the strict dual value 104.083795408, the maximum constraint violated.
The molecule is -1. Because of the integer objective, the lower bound 105 is first obtained.

The column controller further deletes the 93,437 column, retaining only the 6,510 column. For each deleted column, the certificate is clearly listed.
A set of non-higher total-cost retained columns whose coverage combines all of the deleted columns.
All substitutions were rechecked, so the reduced model and the original problem have the same integer optimum. The model has 70,532 nonzeros,
Keep the public 128 solution with the same LP value.

## strict branch proof

A floating-point LP with custom branch-and-bound is used only to select branches and generate dual candidates; all cuts are removed.
The denominator for the integer `10^6` scaled down to a feasible dual written in JSON.

-  Target 105: 15 single node, 8 single dual leaf, 5,049 single root reduced-cost fixed and 2,093 single root
dynamic fixed; proof no objective solution exceeding 105, obtained by LB 106;
-  target 106: 129 single node, 65 dual leaf, 4,060 single root fixed and 22,437 single dynamic fixed;
The proof does not exist objective not greater than the solution 106, obtained by LB 107.

Both certificates passed independent replay locally and on `altman`. Their respective SHA-256 hashes are
`5c4832f3...b00f8` and `67dd18ac...5849`.

##  Exploration that has been completed but is not proof

- Exhaustively enumerate 8,128 exchanges of type 2→1 and 341,376 exchanges of type 3→1/3→2 around the public solution, together with
1,664,661 a replacement column pair, no improvement was found; this is just a neighborhood conclusion.
- A one-hour COPT run on the original model gives the numerical bound 108.0365598701; one hour on the reduced model gives
108.4364920252 has not produced an independent strict certificate.
-  All three SAT/CaDiCaL routes return to `UNKNOWN` after one hour; partial DRAT is not UNSAT.
proof, not used to raise the lower bound.
-  `euler4`'s target 107 exact tree 262 is still open nodes after an hour.
At the user's request, 120 processed nodes, 121 open nodes were suspended without full proof being written.

As a result, the target 107 has not yet been excluded, and the strict lower bound maintains the 107.
