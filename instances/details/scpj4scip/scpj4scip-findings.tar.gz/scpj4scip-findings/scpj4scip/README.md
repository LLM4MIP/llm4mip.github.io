# scpj4scip — strict interval [107, 128]

This directory archives structure-specific work on the MIPLIB open weighted
set-covering instance `scpj4scip`.

## Current result

The independently certified interval is **[107, 128]**.  Global optimality is
still open.

- The public solution selects 128 columns, covers all 1,000 rows, and has
  objective 128.
- A denominator-`10^9` feasible LP dual gives the exact bound
  `104.083795408`, hence the initial integer lower bound 105.
- Complete branch/dual certificates rule out objective at most 105 and at most
  106.  Independent integer-only replay on both the local machine and `altman`
  raises the strict lower bound to 107.

The target-107 searches did not finish, so no claim of lower bound 108 is made.

## Exact reduction

The original model has 99,947 binary columns and 1,000 covering rows.  An exact
dominance pass removes 93,437 columns and retains 6,510.  For every removed
column, [`dominance-certificate.json`](artifacts/dominance-certificate.json)
lists retained columns whose union covers its support at no greater cost.
[`verify_dominance.py`](scripts/verify_dominance.py) rechecks all deletions
against the original MPS.  The reduced model is therefore integer-optimum
equivalent to the original.

## Exact branch certificates

The proof generator uses floating-point LP solves only to choose branches and
candidate duals.  Every pruning step stored in the certificate is justified by
an integer-scaled feasible dual.  The independent checker calls no optimizer.

| Excluded target | Tree nodes | Dual leaves | Dynamic reduced-cost fixings | Proof SHA-256 |
|---:|---:|---:|---:|---|
| 105 | 15 | 8 | 2,093 | `5c4832f3fbcbddc7b6ce9fce8ccdf1a0c2000c54c4cca0d9df4f44771c8b00f8` |
| 106 | 129 | 65 | 22,437 | `67dd18ac11d95156803801126cdf04bed524fd71175e24079b34868d4c8b5849` |

## Reproduction

The certificate replays require only Python 3:

```sh
python scripts/verify_dominance.py \
  input/scpj4scip.mps.gz artifacts/dominance-certificate.json

python scripts/verify_setcover_bnb.py \
  artifacts/scpj4scip-dominance-reduced.mps \
  artifacts/structure.json \
  artifacts/proof-target105.json --output replay-target105.json

python scripts/verify_setcover_bnb.py \
  artifacts/scpj4scip-dominance-reduced.mps \
  artifacts/structure.json \
  artifacts/proof-target106.json --output replay-target106.json
```

## Incomplete experiments and pause state

The COPT baseline on the exact reduced model retained objective 128 and ended
with floating-point solver bound `108.43649202518031`; that is diagnostic only.
Three CaDiCaL routes ended `UNKNOWN`, and their partial DRAT files are not
proofs.  The first exact target-107 tree on `euler4` stopped after 261 processed
nodes with 262 open nodes.  A local repeat was paused by the user after 120
processed nodes with 121 open nodes.  Both are archived as partial exploration
only.  There are currently no active experiments for this instance.

See [`report.zh.md`](report.zh.md) for the full Chinese summary and precise
evidence boundary.
