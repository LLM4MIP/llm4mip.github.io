#!/usr/bin/env python3
"""Parse and independently inspect the pure set-covering instance."""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import gzip
import hashlib
import json
import math
from pathlib import Path

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csc_matrix


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def open_text(path: Path):
    if path.suffix == ".gz":
        return gzip.open(path, "rt", encoding="utf-8")
    return path.open("rt", encoding="utf-8")


def parse_mps(path: Path):
    section = None
    objective_row = None
    row_sense = {}
    rhs = defaultdict(float)
    costs = defaultdict(float)
    columns = defaultdict(dict)
    with open_text(path) as stream:
        for raw in stream:
            tokens = raw.split()
            if not tokens:
                continue
            if tokens[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = tokens[0]
                continue
            if section == "ROWS":
                sense, name = tokens[:2]
                if sense == "N":
                    objective_row = name
                else:
                    row_sense[name] = sense
            elif section == "COLUMNS":
                if any("MARKER" in token for token in tokens):
                    continue
                variable = tokens[0]
                for i in range(1, len(tokens), 2):
                    row, value = tokens[i], float(tokens[i + 1])
                    if row == objective_row:
                        costs[variable] += value
                    else:
                        columns[variable][row] = columns[variable].get(row, 0.0) + value
            elif section == "RHS":
                for i in range(1, len(tokens), 2):
                    rhs[tokens[i]] = float(tokens[i + 1])
    return row_sense, rhs, costs, columns


def parse_solution(path: Path):
    declared = None
    values = {}
    with open_text(path) as stream:
        for raw in stream:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("#"):
                continue
            if tokens[0] == "=obj=":
                declared = float(tokens[-1])
            else:
                values[tokens[0]] = float(tokens[1])
    return declared, values


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    senses, rhs, costs, columns = parse_mps(args.model)
    rows = list(senses)
    variables = list(columns)
    row_index = {name: i for i, name in enumerate(rows)}
    row_columns = [[] for _ in rows]
    data, indices, indptr = [], [], [0]
    for j, variable in enumerate(variables):
        for row, coefficient in columns[variable].items():
            i = row_index[row]
            indices.append(i)
            data.append(coefficient)
            row_columns[i].append(j)
        indptr.append(len(data))
    matrix = csc_matrix((data, indices, indptr), shape=(len(rows), len(variables)))
    objective = np.array([costs[v] for v in variables])
    rhs_vector = np.array([rhs[r] for r in rows])

    declared, solution = parse_solution(args.solution)
    x = np.array([solution.get(v, 0.0) for v in variables])
    activity = matrix @ x
    objective_value = float(objective @ x)

    lp = linprog(
        objective,
        A_ub=-matrix,
        b_ub=-rhs_vector,
        bounds=(0.0, 1.0),
        method="highs",
        options={"dual_feasibility_tolerance": 1e-9, "primal_feasibility_tolerance": 1e-9},
    )
    if not lp.success:
        raise RuntimeError(lp.message)
    dual = np.maximum(-lp.ineqlin.marginals, 0.0)
    loads = matrix.T @ dual
    ratios = np.divide(objective, loads, out=np.full_like(objective, np.inf), where=loads > 0)
    scale = min(1.0, float(np.min(ratios)))
    safe_dual = dual * scale * (1.0 - 1e-10)
    safe_loads = matrix.T @ safe_dual
    dual_denominator = 10**9
    dual_numerators = [int(math.floor(value * dual_denominator)) for value in safe_dual]
    exact_column_loads = [
        sum(dual_numerators[i] for i in matrix.indices[matrix.indptr[j]:matrix.indptr[j + 1]])
        for j in range(len(variables))
    ]
    exact_bound_numerator = sum(dual_numerators)
    exact_integer_lower_bound = (exact_bound_numerator + dual_denominator - 1) // dual_denominator
    assert all(exact_column_loads[j] <= int(round(objective[j])) * dual_denominator for j in range(len(variables)))

    selected = np.flatnonzero(x > 0.5)
    selected_cover = matrix[:, selected].sum(axis=1).A.ravel()
    removable = []
    for j in selected:
        covered_rows = matrix.indices[matrix.indptr[j]:matrix.indptr[j + 1]]
        if np.all(selected_cover[covered_rows] >= 2.0 - 1e-12):
            removable.append(variables[j])

    report = {
        "model_sha256": sha256(args.model),
        "solution_sha256": sha256(args.solution),
        "structure": {
            "rows": len(rows),
            "columns": len(variables),
            "nonzeros": int(matrix.nnz),
            "row_senses": dict(Counter(senses.values())),
            "coefficient_values": Counter(format(v, ".12g") for v in data).most_common(),
            "cost_values": Counter(format(v, ".12g") for v in objective).most_common(),
            "row_degree": {"min": min(map(len, row_columns)), "max": max(map(len, row_columns)), "mean": float(matrix.nnz / len(rows))},
            "column_degree": {"min": int(np.diff(matrix.indptr).min()), "max": int(np.diff(matrix.indptr).max()), "mean": float(matrix.nnz / len(variables))},
        },
        "public_solution": {
            "declared_objective": declared,
            "computed_objective": objective_value,
            "selected_columns": int(len(selected)),
            "minimum_row_coverage": float(activity.min()),
            "maximum_row_coverage": float(activity.max()),
            "violated_rows": int(np.sum(activity + 1e-9 < rhs_vector)),
            "fractional_assignments": int(np.sum((x > 1e-9) & (x < 1 - 1e-9))),
            "individually_removable_selected_columns": removable,
        },
        "lp_relaxation": {
            "success": bool(lp.success),
            "objective": float(lp.fun),
            "iterations": int(lp.nit),
            "safe_scaled_dual_bound": float(safe_dual.sum()),
            "safe_dual_max_violation": float(np.max(safe_loads - objective)),
            "fractional_variables": int(np.sum((lp.x > 1e-8) & (lp.x < 1 - 1e-8))),
            "exact_dual_certificate": {
                "denominator": dual_denominator,
                "row_numerators": dict(zip(rows, dual_numerators)),
                "bound_numerator": exact_bound_numerator,
                "integer_objective_lower_bound": exact_integer_lower_bound,
                "maximum_integer_slack_violation": max(
                    exact_column_loads[j] - int(round(objective[j])) * dual_denominator
                    for j in range(len(variables))
                ),
            },
        },
    }
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
