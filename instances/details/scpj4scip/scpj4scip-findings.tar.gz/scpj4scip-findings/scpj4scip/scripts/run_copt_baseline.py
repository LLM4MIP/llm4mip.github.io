#!/usr/bin/env python3
"""One reproducible COPT baseline with the verified public incumbent."""

import argparse
import json
from pathlib import Path

from coptpy import COPT, Envr


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True)
    parser.add_argument("--start-file", required=True)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--time-limit", type=float, default=3600)
    parser.add_argument("--threads", type=int, default=16)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    env = Envr()
    model = env.createModel("scpj4scip")
    model.readMps(args.model)
    model.readSol(args.start_file)
    model.setLogFile(str(args.outdir / "solver.log"))
    model.setParam(COPT.Param.Threads, args.threads)
    model.setParam(COPT.Param.TimeLimit, args.time_limit)
    model.solve()

    get = model.getAttr
    result = {
        "solver": "COPT",
        "mip_status": int(get(COPT.Attr.MipStatus)),
        "runtime": float(get(COPT.Attr.SolvingTime)),
        "nodes": float(get(COPT.Attr.NodeCnt)),
        "has_mip_solution": bool(get(COPT.Attr.HasMipSol)),
        "best_bound": float(get(COPT.Attr.BestBnd)),
    }
    if result["has_mip_solution"]:
        result["objective"] = float(get(COPT.Attr.BestObj))
        model.writeSol(str(args.outdir / "best.sol"))
    (args.outdir / "result.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
