#!/usr/bin/env python3
"""Solver-independent checker for a set-cover solution file."""

import argparse
import json
from pathlib import Path

from setcover_structure import parse_mps


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    senses, rhs, costs, columns = parse_mps(args.model)
    values = {}
    for line in args.solution.read_text(encoding="utf-8").splitlines():
        fields = line.split()
        if len(fields) == 2 and fields[0] in columns:
            values[fields[0]] = float(fields[1])
    assert set(values) == set(columns)
    assert all(abs(value - round(value)) <= 1e-9 and 0 <= value <= 1 for value in values.values())
    cover = {row: 0 for row in senses}
    for name, selected in values.items():
        if round(selected):
            for row in columns[name]:
                cover[row] += 1
    assert all(senses[row] == "G" and cover[row] >= rhs[row] for row in senses)
    objective = sum(costs[name] * round(value) for name, value in values.items())
    report = {
        "verified": True,
        "variables": len(values),
        "selected_columns": sum(round(value) for value in values.values()),
        "covered_rows": len(cover),
        "minimum_row_coverage": min(cover.values()),
        "objective": objective,
    }
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
