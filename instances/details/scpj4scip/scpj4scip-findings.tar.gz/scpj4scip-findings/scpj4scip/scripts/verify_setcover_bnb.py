#!/usr/bin/env python3
"""Independently verify an exact_setcover_bnb.py proof certificate."""

import argparse
import json
from pathlib import Path

from setcover_structure import parse_mps


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("dual_structure", type=Path)
    parser.add_argument("certificate", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    senses, rhs, cost_values, columns_by_name = parse_mps(args.model)
    assert all(sense == "G" and rhs[row] == 1 for row, sense in senses.items())
    names = list(columns_by_name)
    name_index = {name: index for index, name in enumerate(names)}
    rows = list(senses)
    row_index = {row: index for index, row in enumerate(rows)}
    costs = [int(cost_values[name]) for name in names]
    column_rows = [tuple(row_index[row] for row in columns_by_name[name]) for name in names]
    column_masks = [sum(1 << row for row in covered) for covered in column_rows]
    row_columns = [[] for _ in rows]
    for column, covered in enumerate(column_rows):
        for row in covered:
            row_columns[row].append(column)

    proof = json.loads(args.certificate.read_text(encoding="utf-8"))
    assert proof["status"] == "PROVED_INFEASIBLE"
    assert proof["open_node_count"] == 0
    assert proof["source_columns"] == len(names)
    target = int(proof["target"])
    denominator = int(proof["dual_denominator"])
    target_numerator = target * denominator

    root_data = json.loads(args.dual_structure.read_text(encoding="utf-8"))["lp_relaxation"]["exact_dual_certificate"]
    root_denominator = int(root_data["denominator"])
    root_y = {row_index[row]: int(value) for row, value in root_data["row_numerators"].items()}
    root_bound = sum(root_y.values())
    assert root_denominator == proof["root_dual_denominator"]
    assert root_bound == proof["root_dual_bound_numerator"]
    assert min(root_y.values()) >= 0
    for column in range(len(names)):
        assert sum(root_y[row] for row in column_rows[column]) <= costs[column] * root_denominator
    gap = target * root_denominator - root_bound
    expected_global_zero = {
        column
        for column in range(len(names))
        if costs[column] * root_denominator - sum(root_y[row] for row in column_rows[column]) > gap
    }
    stated_global_zero = {name_index[name] for name in proof["global_fixed_zero_by_root_reduced_cost"]}
    assert stated_global_zero == expected_global_zero

    nodes = {int(node["id"]): node for node in proof["nodes"]}
    assert len(nodes) == proof["processed_nodes"]
    assert set(nodes) == set(range(len(nodes)))
    visited = set()
    dual_checks = 0
    reduced_cost_fixings = 0
    leaf_counts = {"dual": 0, "cost": 0, "uncovered": 0}
    all_rows_mask = (1 << len(rows)) - 1

    def residual(fixed_zero, fixed_one):
        covered_mask = 0
        fixed_cost = 0
        for column in fixed_one:
            covered_mask |= column_masks[column]
            fixed_cost += costs[column]
        uncovered = {row for row in range(len(rows)) if not (covered_mask >> row) & 1}
        active = {
            column
            for column in range(len(names))
            if column not in fixed_zero
            and column not in fixed_one
            and any(row in uncovered for row in column_rows[column])
        }
        return fixed_cost, uncovered, active

    def verify_dual(stated, fixed_zero, fixed_one):
        nonlocal dual_checks
        fixed_cost, uncovered, active = residual(fixed_zero, fixed_one)
        y = [0] * len(rows)
        for row_name, value in stated.items():
            assert row_name in row_index
            value = int(value)
            assert value > 0
            y[row_index[row_name]] = value
        assert all(y[row] == 0 for row in set(range(len(rows))) - uncovered)
        for column in active:
            assert sum(y[row] for row in column_rows[column]) <= costs[column] * denominator
        dual_checks += 1
        return fixed_cost, uncovered, active, y, sum(y)

    def visit(node_id, fixed_zero, fixed_one, expected_parent, expected_branch):
        nonlocal reduced_cost_fixings
        assert node_id not in visited
        visited.add(node_id)
        node = nodes[node_id]
        assert node["parent"] == expected_parent
        assert node["branch_value"] == expected_branch

        fixed_zero = set(fixed_zero)
        fixed_one = set(fixed_one)
        assert fixed_zero.isdisjoint(fixed_one)
        for reduction in node["reductions"]:
            fixed_cost, uncovered, active, y, dual_sum = verify_dual(
                reduction["dual_row_numerators"], fixed_zero, fixed_one
            )
            assert fixed_cost == reduction["fixed_cost"]
            new_zero = [int(column) for column in reduction["fixed_zero_columns"]]
            assert len(new_zero) == len(set(new_zero))
            for column in new_zero:
                assert column in active
                reduced_cost = costs[column] * denominator - sum(y[row] for row in column_rows[column])
                assert fixed_cost * denominator + dual_sum + reduced_cost > target_numerator
            fixed_zero.update(new_zero)
            assert fixed_zero.isdisjoint(fixed_one)
            reduced_cost_fixings += len(new_zero)

        if "leaf" in node:
            leaf = node["leaf"]
            kind = leaf["kind"]
            assert kind in leaf_counts
            leaf_counts[kind] += 1
            fixed_cost, uncovered, active = residual(fixed_zero, fixed_one)
            if kind == "cost":
                assert fixed_cost == leaf["fixed_cost"] and fixed_cost > target
            elif kind == "uncovered":
                row = int(leaf["row"])
                assert fixed_cost == leaf["fixed_cost"] and row in uncovered
                assert not any(column in active for column in row_columns[row])
            else:
                checked_cost, _, _, _, dual_sum = verify_dual(
                    leaf["dual_row_numerators"], fixed_zero, fixed_one
                )
                assert checked_cost == leaf["fixed_cost"]
                bound = checked_cost * denominator + dual_sum
                assert bound == leaf["bound_numerator"] and bound > target_numerator
            assert "children" not in node
            return

        assert "branch_column" in node and "children" in node
        branch = int(node["branch_column"])
        assert node["branch_name"] == names[branch]
        _, _, active = residual(fixed_zero, fixed_one)
        assert branch in active
        children = list(map(int, node["children"]))
        assert len(children) == 2 and children[0] != children[1]
        visit(children[0], fixed_zero | {branch}, fixed_one, node_id, 0)
        visit(children[1], fixed_zero, fixed_one | {branch}, node_id, 1)

    visit(int(proof["root_id"]), stated_global_zero, set(), None, None)
    assert visited == set(nodes)
    report = {
        "verified": True,
        "target_infeasible": target,
        "strict_integer_lower_bound": target + 1,
        "global_reduced_cost_zero_fixings": len(stated_global_zero),
        "tree_nodes": len(nodes),
        "dual_certificates_checked": dual_checks,
        "dynamic_reduced_cost_fixings_checked": reduced_cost_fixings,
        "leaf_counts": leaf_counts,
    }
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
