#!/usr/bin/env python3
"""CNF for cost<=B strengthened by an exact LP-dual reduced-cost argument."""

import argparse
import hashlib
import json
from pathlib import Path

from encode_budget_cnf import counter_clauses, self_test
from setcover_structure import parse_mps


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("dual_structure", type=Path)
    parser.add_argument("--bound", type=int, required=True)
    parser.add_argument("--reduced-cost-scale", type=int, default=100_000_000)
    parser.add_argument("--cnf", type=Path, required=True)
    parser.add_argument("--metadata", type=Path, required=True)
    args = parser.parse_args()
    self_test()

    senses, rhs, costs, columns = parse_mps(args.model)
    assert all(sense == "G" and rhs[row] == 1 for row, sense in senses.items())
    dual_container = json.loads(args.dual_structure.read_text(encoding="utf-8"))
    dual = dual_container["lp_relaxation"]["exact_dual_certificate"]
    denominator = int(dual["denominator"])
    row_numerators = {row: int(value) for row, value in dual["row_numerators"].items()}
    dual_bound = int(dual["bound_numerator"])
    assert set(row_numerators) == set(senses)

    reduced_cost = {
        name: int(costs[name]) * denominator - sum(row_numerators[row] for row in rows)
        for name, rows in columns.items()
    }
    assert min(reduced_cost.values()) >= 0
    gap = args.bound * denominator - dual_bound
    kept_names = [name for name in columns if reduced_cost[name] <= gap]
    removed_names = [name for name in columns if reduced_cost[name] > gap]
    # If a selected column alone consumes more reduced cost than the complete
    # target gap, the exact dual identity proves it cannot occur in a target solution.
    assert kept_names and removed_names

    input_id = {name: index + 1 for index, name in enumerate(kept_names)}
    covering = {row: [] for row in senses}
    for name in kept_names:
        for row in columns[name]:
            covering[row].append(input_id[name])
    assert all(covering.values())

    n = len(kept_names)
    objective_weights = [int(costs[name]) for name in kept_names]
    objective_counter_id = lambda i, j: n + (i - 1) * args.bound + j
    objective_counter_clauses = (
        sum(objective_weights)
        + n * (args.bound - 1)
        + (n - 1) * 2 * args.bound
    )

    scale = args.reduced_cost_scale
    scaled_bound = gap // scale
    scaled_items = [
        (input_id[name], reduced_cost[name] // scale)
        for name in kept_names
        if reduced_cost[name] // scale > 0
    ]
    assert scaled_bound > 0 and scaled_items
    scaled_ids = [item[0] for item in scaled_items]
    scaled_weights = [item[1] for item in scaled_items]
    assert max(scaled_weights) <= scaled_bound
    objective_aux = n * args.bound
    scaled_counter_id = lambda i, j: n + objective_aux + (i - 1) * scaled_bound + j
    scaled_n = len(scaled_items)
    scaled_counter_clauses = (
        sum(scaled_weights)
        + scaled_n * (scaled_bound - 1)
        + (scaled_n - 1) * 2 * scaled_bound
    )

    variable_count = n + objective_aux + scaled_n * scaled_bound
    clause_count = (
        len(covering) + objective_counter_clauses + scaled_counter_clauses
    )
    with args.cnf.open("w", encoding="ascii", newline="\n") as output:
        output.write(f"p cnf {variable_count} {clause_count}\n")
        for row in senses:
            output.write(" ".join(map(str, covering[row])) + " 0\n")
        emitted_objective = 0
        for clause in counter_clauses(
            range(1, n + 1), objective_weights, args.bound, objective_counter_id
        ):
            output.write(" ".join(map(str, clause)) + " 0\n")
            emitted_objective += 1
        emitted_scaled = 0
        for clause in counter_clauses(
            scaled_ids, scaled_weights, scaled_bound, scaled_counter_id
        ):
            output.write(" ".join(map(str, clause)) + " 0\n")
            emitted_scaled += 1
    assert emitted_objective == objective_counter_clauses
    assert emitted_scaled == scaled_counter_clauses

    certificate = {
        "encoding": "cover clauses, objective sequential counter, and scaled exact-dual reduced-cost counter",
        "equivalence": "CNF is SAT iff the dominance-reduced model has an integer solution of cost at most the bound",
        "source_model_sha256": sha256(args.model),
        "dual_structure_sha256": sha256(args.dual_structure),
        "bound": args.bound,
        "dual_denominator": denominator,
        "dual_bound_numerator": dual_bound,
        "target_gap_numerator": gap,
        "kept_original_variables": n,
        "fixed_zero_by_reduced_cost": len(removed_names),
        "fixed_zero_names_and_reduced_cost_numerators": {
            name: reduced_cost[name] for name in removed_names
        },
        "reduced_cost_scale": scale,
        "scaled_reduced_cost_bound": scaled_bound,
        "positive_scaled_reduced_cost_variables": scaled_n,
        "cnf_variables": variable_count,
        "cnf_clauses": clause_count,
        "objective_counter_clauses": objective_counter_clauses,
        "scaled_reduced_cost_counter_clauses": scaled_counter_clauses,
        "cnf_sha256": sha256(args.cnf),
        "small_exhaustive_counter_self_test": True,
        "validity_note": (
            "For every cover x, cost(x) >= dual_bound + sum_j reduced_cost_j*x_j. "
            "Thus target solutions satisfy the exact reduced-cost gap. Deleting a column "
            "whose reduced cost exceeds that gap is exact. Also sum floor(rc_j/scale)*x_j "
            "<= floor(gap/scale), so the second counter is a valid necessary condition."
        ),
    }
    args.metadata.write_text(json.dumps(certificate, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in certificate.items() if not k.startswith("fixed_zero_names")}, indent=2))


if __name__ == "__main__":
    main()
