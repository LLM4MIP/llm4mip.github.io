#!/usr/bin/env python3
"""Independently verify every column deletion in a dominance certificate."""

import argparse
import json
from pathlib import Path

from setcover_structure import parse_mps


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("certificate", type=Path)
    args = parser.parse_args()
    senses, rhs, costs, columns = parse_mps(args.model)
    cert = json.loads(args.certificate.read_text(encoding="utf-8"))
    dominated = cert["dominated"]
    assert all(sense == "G" and rhs[row] == 1 for row, sense in senses.items())
    for target, replacements in dominated.items():
        assert target in columns
        assert all(var in columns for var in replacements)
        replacement_cost = sum(costs[var] for var in replacements)
        replacement_cover = set().union(*(set(columns[var]) for var in replacements))
        assert replacement_cost <= costs[target]
        assert set(columns[target]) <= replacement_cover
    assert len(columns) - len(dominated) == cert["retained_columns"]
    print(json.dumps({
        "verified": True,
        "original_columns": len(columns),
        "dominated_columns": len(dominated),
        "retained_columns": len(columns) - len(dominated),
    }, indent=2))


if __name__ == "__main__":
    main()
