#!/usr/bin/env python3
"""Encode a weighted set-cover budget as CNF with a generalized sequential counter."""

import argparse
import hashlib
import json
from pathlib import Path

from setcover_structure import parse_mps


def counter_clauses(input_ids, weights, bound, counter_id):
    """Yield clauses for sum(weights[i] * x[i]) <= bound.

    Counter variable s(i,j) means the first i inputs have weight at least j.
    Only forward implications are required: they force an overflow conflict,
    while a within-budget assignment extends with the exact threshold values.
    """

    def s(i, j):
        return counter_id(i, j)

    for i, (x, weight) in enumerate(zip(input_ids, weights), start=1):
        assert 1 <= weight <= bound
        for j in range(1, weight + 1):
            yield (-x, s(i, j))
        for j in range(2, bound + 1):
            yield (-s(i, j), s(i, j - 1))
        if i == 1:
            continue
        for j in range(1, bound + 1):
            yield (-s(i - 1, j), s(i, j))
            if j + weight <= bound:
                yield (-x, -s(i - 1, j), s(i, j + weight))
            else:
                yield (-x, -s(i - 1, j))


def self_test():
    # Exhaustively check the encoding on small weighted sums.  Auxiliary
    # assignments are enumerated independently rather than set canonically.
    from itertools import product

    for weights in ((1, 1), (1, 2, 1), (2, 3, 1)):
        for bound in range(max(weights), 5):
            n = len(weights)
            inputs = list(range(1, n + 1))
            counter = lambda i, j: n + (i - 1) * bound + j
            clauses = list(counter_clauses(inputs, weights, bound, counter))
            aux_count = n * bound
            for selected in product((False, True), repeat=n):
                extendible = False
                for aux in product((False, True), repeat=aux_count):
                    values = list(selected) + list(aux)
                    if all(any(values[abs(lit) - 1] == (lit > 0) for lit in clause) for clause in clauses):
                        extendible = True
                        break
                assert extendible == (sum(w for w, take in zip(weights, selected) if take) <= bound)


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("--bound", type=int, required=True)
    parser.add_argument("--cnf", type=Path, required=True)
    parser.add_argument("--metadata", type=Path, required=True)
    args = parser.parse_args()
    self_test()

    senses, rhs, costs, columns = parse_mps(args.model)
    assert all(sense == "G" and rhs[row] == 1 for row, sense in senses.items())
    names = list(columns)
    assert all(costs[name] == int(costs[name]) and 1 <= costs[name] <= args.bound for name in names)
    input_id = {name: index + 1 for index, name in enumerate(names)}
    n = len(names)
    bound = args.bound
    counter_id = lambda i, j: n + (i - 1) * bound + j

    covering = {row: [] for row in senses}
    for name, rows in columns.items():
        for row in rows:
            covering[row].append(input_id[name])
    assert all(covering.values())

    weights = [int(costs[name]) for name in names]
    coverage_clause_count = len(covering)
    counter_clause_count = (
        sum(weights)
        + n * (bound - 1)
        + (n - 1) * 2 * bound
    )
    variable_count = n + n * bound
    clause_count = coverage_clause_count + counter_clause_count
    args.cnf.parent.mkdir(parents=True, exist_ok=True)
    with args.cnf.open("w", encoding="ascii", newline="\n") as output:
        output.write(f"p cnf {variable_count} {clause_count}\n")
        for row in senses:
            output.write(" ".join(map(str, covering[row])) + " 0\n")
        emitted = 0
        for clause in counter_clauses(range(1, n + 1), weights, bound, counter_id):
            output.write(" ".join(map(str, clause)) + " 0\n")
            emitted += 1
    assert emitted == counter_clause_count

    metadata = {
        "encoding": "weighted generalized sequential counter plus covering clauses",
        "equivalence": "CNF is SAT iff the reduced set-cover model has an integer solution of cost at most the bound",
        "model": str(args.model),
        "model_sha256": sha256(args.model),
        "bound": bound,
        "original_binary_variables": n,
        "counter_variables": n * bound,
        "cnf_variables": variable_count,
        "covering_clauses": coverage_clause_count,
        "counter_clauses": counter_clause_count,
        "cnf_clauses": clause_count,
        "cnf_sha256": sha256(args.cnf),
        "small_exhaustive_encoding_self_test": True,
    }
    args.metadata.write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()
