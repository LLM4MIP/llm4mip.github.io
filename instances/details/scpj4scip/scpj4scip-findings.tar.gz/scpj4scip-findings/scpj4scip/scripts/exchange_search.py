#!/usr/bin/env python3
"""Exact improving 2->1 and time-bounded 3->2 exchanges around the public cover."""

import argparse
import itertools
import json
import time
from pathlib import Path

from setcover_structure import parse_mps, parse_solution


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seconds", type=float, default=300.0)
    args = parser.parse_args()

    senses, rhs, costs, columns = parse_mps(args.model)
    declared, values = parse_solution(args.solution)
    rows = list(senses)
    row_index = {row: i for i, row in enumerate(rows)}
    variables = list(columns)
    supports = [{row_index[row] for row in columns[var]} for var in variables]
    selected = [j for j, var in enumerate(variables) if values.get(var, 0.0) > 0.5]
    selected_set = set(selected)
    assert sum(costs[variables[j]] for j in selected) == declared == 128
    assert all(costs[variables[j]] == 1 for j in selected)

    coverage = [0] * len(rows)
    for j in selected:
        for row in supports[j]:
            coverage[row] += 1
    eligible = [j for j, var in enumerate(variables) if costs[var] == 1]
    postings = [[] for _ in rows]
    for j in eligible:
        for row in supports[j]:
            postings[row].append(j)

    def uncovered_after(removal):
        counts = {}
        for j in removal:
            for row in supports[j]:
                counts[row] = counts.get(row, 0) + 1
        return {row for row, removed_count in counts.items() if coverage[row] == removed_count}

    def one_cover(uncovered, forbidden):
        if not uncovered:
            return None
        pivot = min(uncovered, key=lambda row: len(postings[row]))
        for j in postings[pivot]:
            if j not in forbidden and uncovered <= supports[j]:
                return j
        return None

    start = time.monotonic()
    pairs_checked = 0
    triples_checked = 0
    candidate_pairs_checked = 0
    improvement = None

    for a, b in itertools.combinations(selected, 2):
        pairs_checked += 1
        uncovered = uncovered_after((a, b))
        replacement = one_cover(uncovered, selected_set - {a, b})
        if replacement is not None:
            improvement = {"removed": [a, b], "added": [replacement], "operator": "2->1"}
            break

    if improvement is None:
        for removal in itertools.combinations(selected, 3):
            if time.monotonic() - start >= args.seconds:
                break
            triples_checked += 1
            forbidden = selected_set - set(removal)
            uncovered = uncovered_after(removal)
            replacement = one_cover(uncovered, forbidden)
            if replacement is not None:
                improvement = {"removed": list(removal), "added": [replacement], "operator": "3->1"}
                break
            pivot = min(uncovered, key=lambda row: len(postings[row]))
            for first in postings[pivot]:
                if first in forbidden:
                    continue
                remaining = uncovered - supports[first]
                if not remaining:
                    improvement = {"removed": list(removal), "added": [first], "operator": "3->1"}
                    break
                second = one_cover(remaining, forbidden | {first})
                candidate_pairs_checked += 1
                if second is not None:
                    improvement = {"removed": list(removal), "added": [first, second], "operator": "3->2"}
                    break
            if improvement is not None:
                break

    result = {
        "instance": "scpj4scip",
        "public_objective": declared,
        "selected_columns": len(selected),
        "cost_one_columns": len(eligible),
        "pairs_checked": pairs_checked,
        "all_2_to_1_exchanges_exhausted": pairs_checked == len(selected) * (len(selected) - 1) // 2,
        "triples_checked": triples_checked,
        "total_triples": len(selected) * (len(selected) - 1) * (len(selected) - 2) // 6,
        "candidate_pairs_checked": candidate_pairs_checked,
        "elapsed_seconds": time.monotonic() - start,
        "improvement": None,
    }
    if improvement is not None:
        removed = improvement["removed"]
        added = improvement["added"]
        new_selected = (selected_set - set(removed)) | set(added)
        new_coverage = [0] * len(rows)
        for j in new_selected:
            for row in supports[j]:
                new_coverage[row] += 1
        new_objective = sum(costs[variables[j]] for j in new_selected)
        assert min(new_coverage) >= 1
        improvement["removed_names"] = [variables[j] for j in removed]
        improvement["added_names"] = [variables[j] for j in added]
        improvement["objective"] = new_objective
        result["improvement"] = improvement
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
