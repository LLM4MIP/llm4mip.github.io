# Package manifest: z26

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 40
Excluded source files: 1

## Included files

- `.gitattributes`
- `.gitignore`
- `README.md`
- `analysis/bounds.json`
- `analysis/certificate-replay.json`
- `analysis/clique-cover-after-dominance.json`
- `analysis/clique-cover-certificate.json`
- `analysis/clique-cover-improved.json`
- `analysis/copt-30.json`
- `analysis/dominance-reduction.json`
- `analysis/gurobi-read-euler4.log`
- `analysis/metis-export.json`
- `analysis/metis-unit-export.json`
- `analysis/structure.json`
- `analysis/z26-gurobi-structure.json`
- `artifacts/reduction.graph.gz`
- `artifacts/reduction.graph.map.json`
- `artifacts/reduction.report.json.gz`
- `artifacts/reduction.strict1199.opb.gz`
- `artifacts/structure.compact.json`
- `experiments/altman-kamis/exact-unit-90.is`
- `experiments/altman-kamis/exact-unit-90.log`
- `experiments/altman-kamis/graphchecker-unit.log`
- `experiments/altman-kamis/redumis-s1.is`
- `experiments/altman-kamis/redumis-s1.log`
- `experiments/altman-kamis/redumis-s19.is`
- `experiments/altman-kamis/redumis-s19.log`
- `experiments/altman-kamis/redumis-s7.is`
- `experiments/altman-kamis/redumis-s7.log`
- `experiments/check_graph_certificates_from_mps.py`
- `experiments/clique_cover_search.py`
- `experiments/copt_baseline.py`
- `experiments/dominance_reduce.py`
- `experiments/export_metis.py`
- `experiments/reconstruct_graph.py`
- `input/z26-public-9.sol.gz`
- `scripts/metis_to_pace.py`
- `scripts/opb_to_metis.py`
- `scripts/z26_reducer.py`
- `solutions/official-best.sol.gz`

## Excluded files

- `input/z26.mps.gz (11219654 bytes; raw benchmark input; sha256 63ca4683d1311d5e1390472d5dfb880af2a6100dd11a8a08006d90fa1e27b783)`
