# `z26` — exact MPS-to-MIS reduction and certified graph bounds

## Result (2026-09-07)

Every original variable has objective coefficient `-1`, so the MIP minimizes
the negative cardinality of an independent set.  The independently certified
graph interval is

```text
1198 <= alpha(G) <= 1646.
```

In the original minimization convention this reverses to

```text
LB = -1646 <= optimum <= -1198 = UB.
```

The right endpoint is the exactly validated official feasible solution.  The
left endpoint comes from a clique partition after an alpha-preserving
dominance reduction.  With the same minimization-gap definition used for the
other instances,

```text
(UB - LB) / max(1, |UB|) = 448 / 1198
                              = 0.3739565943238731... (37.395659%).
```

This does not prove optimality and does not improve MIPLIB's incumbent.  The
current [MIPLIB page](https://miplib.zib.de/instance_details_z26.html) labels
`z26` open and publishes objective `-1198`, but no current dual bound; therefore
the certified `-1646` is reported as this repository's reproducible lower
bound, not as a claimed improvement over an unavailable current MIPLIB bound.

The user supplied the earlier result that the exact MIS conversion had been
identified and a dedicated exact algorithm had not finished in 20 minutes.
That is prior work, not a new result claimed here.  New work in this directory
is the coefficient-level mapping audit, duplicate-edge/component analysis,
formal sequential dominance certificate with incumbent back-mapping, and a
fully checkable clique-cover upper bound on `alpha`.

## First-stage Gurobi inspection

Gurobi 13.0.1 on `euler4` read the original compressed MPS with
`/home/wyc/miniconda3/envs/milp-ps/bin/python`.  Only `gp.read()` and model
attribute/matrix inspection were used; `optimize()` was never called.  The
[JSON](analysis/z26-gurobi-structure.json) and
[log](analysis/gurobi-read-euler4.log) explicitly record
`optimize_called: false`, 850,513 rows, 17,937 integer variables, 1,715,613
stored nonzeros, unit matrix coefficients, and only `<=` rows.

The independent exact parser establishes that all variables are binary with
unit upper bound, all objective coefficients are `-1`, and every nonempty row
is a unit-coefficient set-packing constraint with RHS one.  Clique-expanding
those rows is therefore an exact unweighted maximum-independent-set model.

The reconstructed graph has:

- 17,937 vertices and 520,860 unique conflict edges;
- 945,279 row-induced pair occurrences, including 424,419 duplicates;
- 848,838 two-variable `E` rows and 1,675 `K` rows (14 empty);
- 1,661 nonempty `K` cliques that partition all vertices; and
- 37 connected components, with the largest two having 13,951 and 1,042
  vertices.

The detailed audit is [structure.json](analysis/structure.json).

## Safe dominance reduction

The reduction uses this sufficient condition in the current induced graph:
if `uv` is an edge and

```text
N(u) \ {v} subseteq N(v) \ {u},
```

then `v` can be deleted.  Indeed, an independent set containing `v` cannot
contain `u`; replacing `v` by `u` cannot introduce a conflict because every
other neighbor of `u` is also a neighbor of `v`.  This proves equality of the
maximum independent-set sizes before and after each deletion, not merely a
heuristic reduction.

[dominance-reduction.json](analysis/dominance-reduction.json) records 366
sequential deletions (353 in pass one and 13 in pass two), leaving 17,571
vertices.  The initial static same-`K` scan found 302 candidates, but that
number is not used as a certificate.  The checker replays the stronger
sequential condition against the original graph at the exact active set of
every deletion.  It also applies every replacement to the official 1,198-set;
the final mapped set still has 1,198 active vertices and is independent.

## Clique-cover bound and independent replay

[clique-cover-after-dominance.json](analysis/clique-cover-after-dominance.json)
partitions all 17,571 remaining vertices into 1,646 conflict cliques.  Every
independent set takes at most one vertex from each clique, so the reduced graph
has `alpha <= 1646`; dominance preserves alpha exactly, hence the same bound
holds globally for the original MPS.

[check_graph_certificates_from_mps.py](experiments/check_graph_certificates_from_mps.py)
does not import the graph generator or cover search.  Starting from the
original MPS, it independently reconstructs all 520,860 edges, checks the
MPS-to-MIS mapping, replays all 366 deletion conditions, back-maps the official
incumbent, and verifies every pair in every cover clique.  The saved
[certificate replay](analysis/certificate-replay.json) reports all mapping,
dominance, cover, and solver-output checks true and the exact interval
`[-1646,-1198]` in original minimization signs.

The official solution separately passes exact original-MPS evaluation at
tolerance zero:

```text
objective=-1198
rows=850513 exact_row_violations=0
bound_violations=0 integrality_violations=0
```

## Bounded solver experiments (no new incumbent)

All optimization experiments on `altman` were CPU-only; GPU 0 and all other
GPUs were unused.

- COPT 8.0.4, 32 threads, 30 seconds accepted the public `-1198` start but
  only produced computational bound `-14180` at one node.  This is much weaker
  than the exact clique certificate and is explicitly not a proof artifact;
  see [copt-30.json](analysis/copt-30.json).
- KaMIS ReduMIS ran three 75-second seeds in parallel.  The independently
  checked cardinalities were 1,186, 1,184 and 1,189, all below the official
  1,198.  Logs and one-zero vectors are in
  [altman-kamis](experiments/altman-kamis/).
- The KaMIS weighted exact branch-and-reduce code was given a METIS graph with
  every vertex weight exactly one.  `graphchecker` accepted the graph.  The
  90-second run explicitly ended with `%timeout` and returned a valid set of
  only 975 vertices.  It neither completed nor emitted a usable global bound,
  so it is a timed-out local experiment, not an optimality or bound claim.

## Reproduction

Run from the repository root:

```sh
python instances/z26/experiments/reconstruct_graph.py \
  instances/z26/input/z26.mps.gz \
  instances/z26/analysis/structure.rebuilt.json \
  --solution instances/z26/solutions/official-best.sol.gz \
  --certificate instances/z26/analysis/clique-cover-seed.rebuilt.json

python instances/z26/experiments/dominance_reduce.py \
  instances/z26/input/z26.mps.gz \
  instances/z26/solutions/official-best.sol.gz \
  instances/z26/analysis/dominance-reduction.rebuilt.json

python instances/z26/experiments/check_graph_certificates_from_mps.py \
  instances/z26/input/z26.mps.gz \
  instances/z26/solutions/official-best.sol.gz \
  instances/z26/analysis/dominance-reduction.json \
  instances/z26/analysis/clique-cover-after-dominance.json \
  instances/z26/analysis/certificate-replay.rebuilt.json \
  --kamis-output instances/z26/experiments/altman-kamis/redumis-s1.is \
  --kamis-output instances/z26/experiments/altman-kamis/redumis-s7.is \
  --kamis-output instances/z26/experiments/altman-kamis/redumis-s19.is \
  --kamis-output instances/z26/experiments/altman-kamis/exact-unit-90.is

python common/exact_mps_solution_check.py \
  instances/z26/input/z26.mps.gz \
  instances/z26/solutions/official-best.sol.gz --tolerance 0
```

The original compressed MPS SHA-256 is
`63ca4683d1311d5e1390472d5dfb880af2a6100dd11a8a08006d90fa1e27b783`.

## Background sources

- [Current MIPLIB `z26` page](https://miplib.zib.de/instance_details_z26.html):
  open status, dimensions, incumbent history, and direct description as a set
  packing problem from the U.S. Frequency Spectrum Auction in collaboration
  with Ion Media Networks.
- [Fréchette, Newman and Leyton-Brown, *Solving the Station Repacking Problem*](https://doi.org/10.1609/aaai.v30i1.10077):
  authoritative context for the FCC incentive-auction station-repacking
  problem, including constraint-graph decomposition, SAT and solver
  portfolios.  It is background context; anonymous MPS names do not justify a
  claim that this paper documents the exact `z26` file.
- [Official KaMIS repository](https://github.com/KarlsruheMIS/KaMIS): solver
  provenance and documentation for ReduMIS, graphchecker and weighted
  branch-and-reduce.
