#!/usr/bin/env python3
"""Heuristic search for a checkable clique-cover upper bound on z26 MIS."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import random
import re
import time
from collections import defaultdict
from pathlib import Path


SECTIONS = {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}


def load_graph(path: Path):
    rows: dict[str, list[int]] = defaultdict(list)
    k_rows: dict[int, list[int]] = defaultdict(list)
    section = ""
    opener = gzip.open if path.suffix == ".gz" else open
    maximum_vertex = -1
    with opener(path, "rt", encoding="latin-1") as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if not raw[0].isspace() and tokens[0] in SECTIONS:
                section = tokens[0]
                continue
            if section != "COLUMNS" or "'MARKER'" in tokens:
                continue
            variable = int(tokens[0][1:]) - 1
            maximum_vertex = max(maximum_vertex, variable)
            for row, _ in zip(tokens[1::2], tokens[2::2]):
                if row == "obj":
                    continue
                rows[row].append(variable)
                if row.startswith("K"):
                    k_rows[int(row[1:])].append(variable)
    n = maximum_vertex + 1
    edges: set[int] = set()
    for vertices_raw in rows.values():
        vertices = sorted(set(vertices_raw))
        for position, left in enumerate(vertices):
            for right in vertices[position + 1 :]:
                edges.add(left * n + right)
    adjacency = [0] * n
    for encoded in edges:
        left, right = divmod(encoded, n)
        adjacency[left] |= 1 << right
        adjacency[right] |= 1 << left
    initial = [sorted(set(k_rows[index])) for index in sorted(k_rows) if k_rows[index]]
    if sorted(vertex for clique in initial for vertex in clique) != list(range(n)):
        raise ValueError("nonempty K rows do not partition the vertices")
    return adjacency, initial, len(edges)


def common_masks(cliques: list[list[int]], adjacency: list[int]) -> list[int]:
    all_vertices = (1 << len(adjacency)) - 1
    result = []
    for clique in cliques:
        common = all_vertices
        for vertex in clique:
            common &= adjacency[vertex]
        result.append(common)
    return result


def eliminate_pass(base: list[list[int]], adjacency: list[int], rng: random.Random) -> list[list[int]]:
    cliques = [clique[:] for clique in base]
    common = common_masks(cliques, adjacency)
    source_order = list(range(len(cliques)))
    # Primarily attack small colors; random keys diversify equal-size choices.
    source_order.sort(key=lambda index: (len(cliques[index]), rng.random()))
    for source in source_order:
        vertices = cliques[source]
        if not vertices:
            continue
        candidate_lists: dict[int, list[int]] = {}
        possible = True
        for vertex in vertices:
            bit = 1 << vertex
            candidates = [
                target
                for target in range(len(cliques))
                if target != source and cliques[target] and common[target] & bit
            ]
            if not candidates:
                possible = False
                break
            candidate_lists[vertex] = candidates
        if not possible:
            continue
        assignments: list[tuple[int, int]] = []
        for vertex in sorted(vertices, key=lambda value: (len(candidate_lists[value]), rng.random())):
            candidates = candidate_lists[vertex]
            # Prefer larger targets but randomize among the strongest few.
            candidates.sort(key=lambda target: len(cliques[target]), reverse=True)
            width = min(4, len(candidates))
            target = candidates[rng.randrange(width)]
            assignments.append((vertex, target))
        # The source itself is a clique, so vertices assigned to the same target
        # are mutually adjacent.  Individual compatibility with the old target
        # is therefore sufficient for the simultaneous move.
        for vertex, target in assignments:
            cliques[target].append(vertex)
            common[target] &= adjacency[vertex]
        cliques[source] = []
        common[source] = 0
    return [sorted(clique) for clique in cliques if clique]


def valid_cover(cliques: list[list[int]], adjacency: list[int], expected_vertices: list[int] | None = None) -> bool:
    if expected_vertices is None:
        expected_vertices = list(range(len(adjacency)))
    if sorted(vertex for clique in cliques for vertex in clique) != expected_vertices:
        return False
    return all(
        adjacency[left] & (1 << right)
        for clique in cliques
        for position, left in enumerate(clique)
        for right in clique[position + 1 :]
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--seed-certificate", type=Path)
    parser.add_argument("--seconds", type=float, default=120.0)
    parser.add_argument("--seed", type=int, default=260907)
    parser.add_argument("--reduction", type=Path)
    args = parser.parse_args()

    adjacency, k_cover, edges = load_graph(args.mps)
    reduction_payload = None
    if args.reduction:
        reduction_payload = json.loads(args.reduction.read_text(encoding="utf-8"))
        expected_vertices = [vertex - 1 for vertex in reduction_payload["remaining_vertices_one_based"]]
        active = set(expected_vertices)
        k_cover = [[vertex for vertex in clique if vertex in active] for clique in k_cover]
        k_cover = [clique for clique in k_cover if clique]
    else:
        expected_vertices = list(range(len(adjacency)))
    starts = [k_cover]
    if args.seed_certificate:
        seed_payload = json.loads(args.seed_certificate.read_text(encoding="utf-8"))
        seed_cover = [[vertex - 1 for vertex in clique] for clique in seed_payload["cliques_one_based"]]
        if args.reduction:
            seed_cover = [[vertex for vertex in clique if vertex in active] for clique in seed_cover]
            seed_cover = [clique for clique in seed_cover if clique]
        starts.append(seed_cover)
    for cover in starts:
        if not valid_cover(cover, adjacency, expected_vertices):
            raise ValueError("invalid starting clique cover")
    best = min(starts, key=len)
    rng = random.Random(args.seed)
    deadline = time.time() + args.seconds
    trials = 0
    improvements = []
    while time.time() < deadline:
        start = starts[trials % len(starts)] if trials < len(starts) * 4 else best
        candidate = eliminate_pass(start, adjacency, rng)
        trials += 1
        if len(candidate) < len(best):
            best = candidate
            improvements.append({"trial": trials, "cliques": len(best)})
            print(json.dumps(improvements[-1]), flush=True)
    if not valid_cover(best, adjacency, expected_vertices):
        raise AssertionError("search produced an invalid cover")
    payload = {
        "kind": "z26_vertex_partition_into_conflict_cliques",
        "source_sha256": hashlib.sha256(args.mps.read_bytes()).hexdigest(),
        "vertex_count": len(adjacency),
        "unique_conflict_edges": edges,
        "dominance_reduction": str(args.reduction) if args.reduction else None,
        "dominance_reduction_sha256": hashlib.sha256(args.reduction.read_bytes()).hexdigest() if args.reduction else None,
        "covered_active_vertices": len(expected_vertices),
        "clique_count_upper_bound_on_independence_number": len(best),
        "trials": trials,
        "seed": args.seed,
        "improvements": improvements,
        "cliques_one_based": [[vertex + 1 for vertex in clique] for clique in best],
    }
    args.output.write_text(json.dumps(payload, separators=(",", ":")) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in payload.items() if key != "cliques_one_based"}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
