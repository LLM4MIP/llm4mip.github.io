#!/usr/bin/env python3
"""Reconstruct and audit the exact conflict graph encoded by z26.mps.gz.

Every nonempty row has unit coefficients, sense <=, and right-hand side one.
Consequently a row is exactly a clique in a conflict graph.  This script
checks those facts against the original MPS before constructing the graph.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
import random
import re
from array import array
from collections import Counter, defaultdict, deque
from pathlib import Path


SECTION_NAMES = {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}


def open_text(path: Path):
    return gzip.open(path, "rt", encoding="latin-1") if path.suffix == ".gz" else path.open(encoding="latin-1")


def variable_id(name: str) -> int:
    if not name.startswith("x") or not name[1:].isdigit():
        raise ValueError(f"unexpected variable name {name!r}")
    return int(name[1:]) - 1


def row_id(name: str) -> tuple[str, int]:
    match = re.fullmatch(r"([EK])(\d+)", name)
    if not match:
        raise ValueError(f"unexpected row name {name!r}")
    return match.group(1), int(match.group(2))


class UnionFind:
    def __init__(self, n: int):
        self.parent = list(range(n))
        self.size = [1] * n

    def find(self, x: int) -> int:
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, x: int, y: int) -> None:
        x, y = self.find(x), self.find(y)
        if x == y:
            return
        if self.size[x] < self.size[y]:
            x, y = y, x
        self.parent[y] = x
        self.size[x] += self.size[y]


def parse_solution(path: Path | None) -> set[int]:
    if path is None:
        return set()
    selected: set[int] = set()
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as handle:
        for raw in handle:
            tokens = raw.split()
            if len(tokens) >= 2 and tokens[0].startswith("x"):
                if float(tokens[1]) > 0.5:
                    selected.add(variable_id(tokens[0]))
    return selected


def greedy_clique_cover(adjacency_bits: list[int], order: list[int]) -> list[list[int]]:
    """First-fit partition into cliques, represented by common-neighbor masks."""
    cliques: list[list[int]] = []
    common: list[int] = []
    for vertex in order:
        bit = 1 << vertex
        best = -1
        best_future = -1
        # Prefer the feasible color retaining the largest common-neighbor set.
        for index, mask in enumerate(common):
            if mask & bit:
                future = (mask & adjacency_bits[vertex]).bit_count()
                if future > best_future:
                    best = index
                    best_future = future
        if best < 0:
            cliques.append([vertex])
            common.append(adjacency_bits[vertex])
        else:
            cliques[best].append(vertex)
            common[best] &= adjacency_bits[vertex]
    return cliques


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--solution", type=Path)
    parser.add_argument("--certificate", type=Path)
    parser.add_argument("--random-trials", type=int, default=12)
    args = parser.parse_args()

    sha256 = hashlib.sha256(args.mps.read_bytes()).hexdigest()
    row_senses: dict[str, str] = {}
    e_rows: dict[int, list[int]] = defaultdict(list)
    k_rows: dict[int, list[int]] = defaultdict(list)
    rhs: dict[str, str] = {}
    variable_types: set[int] = set()
    upper_one: set[int] = set()
    objective: dict[int, str] = {}
    coefficient_counts: Counter[str] = Counter()
    section = ""
    integer_mode = False

    with open_text(args.mps) as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if not raw[0].isspace() and tokens[0] in SECTION_NAMES:
                section = tokens[0]
                continue
            if section == "ROWS":
                row_senses[tokens[1]] = tokens[0]
            elif section == "COLUMNS":
                if "'MARKER'" in tokens:
                    integer_mode = "'INTORG'" in tokens
                    continue
                vertex = variable_id(tokens[0])
                if integer_mode:
                    variable_types.add(vertex)
                for row, value in zip(tokens[1::2], tokens[2::2]):
                    if row == "obj":
                        objective[vertex] = value
                        continue
                    coefficient_counts[value] += 1
                    family, index = row_id(row)
                    (e_rows if family == "E" else k_rows)[index].append(vertex)
            elif section == "RHS":
                for row, value in zip(tokens[1::2], tokens[2::2]):
                    rhs[row] = value
            elif section == "BOUNDS":
                kind, variable = tokens[0], variable_id(tokens[2])
                value = tokens[3] if len(tokens) > 3 else "0"
                if kind in {"BV", "UP", "UI"} and float(value) == 1.0:
                    upper_one.add(variable)

    n = max(objective) + 1
    rows = [("E", index, vertices) for index, vertices in e_rows.items()]
    rows += [("K", index, vertices) for index, vertices in k_rows.items()]
    all_row_names = {f"{family}{index}" for family, index, _ in rows}
    empty_rows = sorted(name for name in row_senses if name != "obj" and name not in all_row_names)
    nonunit_rhs = {
        name: rhs.get(name, "0")
        for name in row_senses
        if name != "obj" and float(rhs.get(name, "0")) != 1.0
    }
    audit_ok = (
        len(variable_types) == n
        and len(upper_one) == n
        and set(objective) == set(range(n))
        and all(float(value) == -1.0 for value in objective.values())
        and all(sense == "L" for name, sense in row_senses.items() if name != "obj")
        and set(coefficient_counts) == {"1"}
        and not nonunit_rhs
    )

    edges: set[int] = set()
    uf = UnionFind(n)
    row_size_counts: Counter[int] = Counter()
    duplicate_entries = 0
    raw_conflict_pair_occurrences = 0
    for _, _, vertices_raw in rows:
        vertices = sorted(set(vertices_raw))
        duplicate_entries += len(vertices_raw) - len(vertices)
        row_size_counts[len(vertices)] += 1
        if len(vertices) >= 2:
            raw_conflict_pair_occurrences += len(vertices) * (len(vertices) - 1) // 2
            anchor = vertices[0]
            for vertex in vertices[1:]:
                uf.union(anchor, vertex)
            for left_index, left in enumerate(vertices):
                for right in vertices[left_index + 1 :]:
                    edges.add(left * n + right)

    adjacency_bits = [0] * n
    for encoded in edges:
        left, right = divmod(encoded, n)
        adjacency_bits[left] |= 1 << right
        adjacency_bits[right] |= 1 << left
    degrees = [neighbors.bit_count() for neighbors in adjacency_bits]
    components: dict[int, list[int]] = defaultdict(list)
    for vertex in range(n):
        components[uf.find(vertex)].append(vertex)
    component_sizes = sorted((len(vertices) for vertices in components.values()), reverse=True)

    # K rows are expected to be the station/configuration cliques.  Audit
    # whether their nonempty rows form a partition instead of assuming it.
    k_memberships = [0] * n
    nonempty_k_rows: list[list[int]] = []
    for index in sorted(k_rows):
        vertices = sorted(set(k_rows[index]))
        if vertices:
            nonempty_k_rows.append(vertices)
        for vertex in vertices:
            k_memberships[vertex] += 1
    partition_ok = all(count == 1 for count in k_memberships)

    selected = parse_solution(args.solution)
    selected_conflicts = sum(
        1 for encoded in edges if divmod(encoded, n)[0] in selected and divmod(encoded, n)[1] in selected
    )

    # Same-K-row dominance is safe: if two adjacent alternatives u,v share a
    # station clique and N(u)\\{v} is contained in N(v)\\{u}, v can be replaced
    # by u in any independent set.  Report it as a reduction candidate only;
    # the graph/certificate remains unreduced.
    dominated_pairs: list[tuple[int, int]] = []
    for clique in nonempty_k_rows:
        for u in clique:
            without_v_bit = ~(1 << u)
            for v in clique:
                if u == v:
                    continue
                # u dominates v (v may be deleted) when u has no outside
                # conflict that v lacks.
                nu = adjacency_bits[u] & ~(1 << v)
                nv = adjacency_bits[v] & without_v_bit
                if nu & ~nv == 0:
                    dominated_pairs.append((u, v))

    # Produce several checkable clique covers.  Each gives alpha(G) <= count.
    degree_order = sorted(range(n), key=lambda vertex: (-degrees[vertex], vertex))
    index_order = list(range(n))
    candidate_covers = [greedy_clique_cover(adjacency_bits, degree_order), greedy_clique_cover(adjacency_bits, index_order)]
    rng = random.Random(260907)
    degree_buckets: dict[int, list[int]] = defaultdict(list)
    for vertex in range(n):
        degree_buckets[degrees[vertex]].append(vertex)
    for _ in range(args.random_trials):
        trial_order: list[int] = []
        for degree in sorted(degree_buckets, reverse=True):
            bucket = degree_buckets[degree][:]
            rng.shuffle(bucket)
            trial_order.extend(bucket)
        candidate_covers.append(greedy_clique_cover(adjacency_bits, trial_order))
    best_cover = min(candidate_covers, key=len)
    cover_valid = (
        sorted(vertex for clique in best_cover for vertex in clique) == list(range(n))
        and all(
            adjacency_bits[left] & (1 << right)
            for clique in best_cover
            for position, left in enumerate(clique)
            for right in clique[position + 1 :]
        )
    )

    certificate = {
        "kind": "z26_vertex_partition_into_conflict_cliques",
        "source_sha256": sha256,
        "vertex_count": n,
        "clique_count_upper_bound_on_independence_number": len(best_cover),
        "cliques_one_based": [[vertex + 1 for vertex in clique] for clique in best_cover],
    }
    if args.certificate:
        args.certificate.write_text(json.dumps(certificate, separators=(",", ":")) + "\n", encoding="utf-8")

    vertex_component = [uf.find(vertex) for vertex in range(n)]
    component_edge_counts: Counter[int] = Counter()
    for encoded in edges:
        left, _ = divmod(encoded, n)
        component_edge_counts[vertex_component[left]] += 1
    component_k_counts: Counter[int] = Counter()
    for clique in nonempty_k_rows:
        component_k_counts[vertex_component[clique[0]]] += 1
    component_incumbent_counts: Counter[int] = Counter(vertex_component[vertex] for vertex in selected)
    component_cover_counts: Counter[int] = Counter()
    for clique in best_cover:
        component_cover_counts[vertex_component[clique[0]]] += 1
    component_details = []
    for root, vertices in sorted(components.items(), key=lambda item: (-len(item[1]), min(item[1]))):
        component_details.append(
            {
                "minimum_vertex_one_based": min(vertices) + 1,
                "vertices": len(vertices),
                "edges": component_edge_counts[root],
                "K_groups": component_k_counts[root],
                "official_incumbent_selected": component_incumbent_counts[root],
                "clique_cover_upper_bound": component_cover_counts[root],
            }
        )

    result = {
        "source_sha256": sha256,
        "exact_mps_to_unweighted_mis_audit": {
            "passed": audit_ok,
            "all_variables_binary_with_unit_upper_bound": len(variable_types) == n and len(upper_one) == n,
            "all_objective_coefficients_minus_one": all(float(value) == -1.0 for value in objective.values()),
            "all_nonempty_rows_unit_set_packing": not nonunit_rhs and set(coefficient_counts) == {"1"},
            "nonunit_rhs": nonunit_rhs,
            "duplicate_entries_within_rows": duplicate_entries,
        },
        "dimensions": {
            "vertices": n,
            "mps_rows_excluding_objective": len(row_senses) - 1,
            "E_rows": len(e_rows),
            "K_rows": len(k_rows) + sum(name.startswith("K") for name in empty_rows),
            "empty_rows": len(empty_rows),
            "unique_conflict_edges_after_clique_expansion": len(edges),
            "raw_conflict_pair_occurrences": raw_conflict_pair_occurrences,
            "duplicate_conflict_pair_occurrences": raw_conflict_pair_occurrences - len(edges),
        },
        "row_size_distribution": {str(size): count for size, count in sorted(row_size_counts.items())},
        "graph": {
            "component_count": len(components),
            "component_sizes_descending": component_sizes,
            "degree_min": min(degrees),
            "degree_median": sorted(degrees)[n // 2],
            "degree_mean": sum(degrees) / n,
            "degree_max": max(degrees),
            "isolated_vertices": sum(degree == 0 for degree in degrees),
            "component_details": component_details,
        },
        "K_rows_partition_vertices": {
            "passed": partition_ok,
            "nonempty_K_rows": len(nonempty_k_rows),
            "uncovered_vertices": sum(count == 0 for count in k_memberships),
            "multiply_covered_vertices": sum(count > 1 for count in k_memberships),
            "trivial_clique_cover_bound_if_partition": len(nonempty_k_rows) if partition_ok else None,
        },
        "official_solution": {
            "selected_vertices": len(selected),
            "conflicting_selected_pairs": selected_conflicts,
        },
        "safe_same_station_dominance_candidates": {
            "ordered_pairs": len(dominated_pairs),
            "distinct_deletable_vertices": len({v for _, v in dominated_pairs}),
            "first_100_one_based": [[u + 1, v + 1] for u, v in dominated_pairs[:100]],
        },
        "clique_cover_certificate": {
            "valid": cover_valid,
            "trial_counts": [len(cover) for cover in candidate_covers],
            "best_global_upper_bound_on_alpha": len(best_cover),
            "certificate": str(args.certificate) if args.certificate else None,
        },
    }
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if audit_ok and cover_valid and selected_conflicts == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
