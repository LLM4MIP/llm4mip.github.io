#!/usr/bin/env python3
"""CPU-only COPT baseline for z26 with the exact public incumbent as a start."""

from __future__ import annotations

import argparse
import gzip
import json
import time

import coptpy as cp


def read_selected(path: str) -> set[str]:
    opener = gzip.open if path.endswith(".gz") else open
    selected = set()
    with opener(path, "rt", encoding="utf-8") as handle:
        for raw in handle:
            tokens = raw.split()
            if len(tokens) >= 2 and tokens[0].startswith("x"):
                try:
                    if float(tokens[1]) > 0.5:
                        selected.add(tokens[0])
                except ValueError:
                    pass
    return selected


def attr(obj, *names):
    for name in names:
        try:
            return getattr(obj, name)
        except Exception:
            pass
    return None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps")
    parser.add_argument("start")
    parser.add_argument("output_solution")
    parser.add_argument("output_json")
    parser.add_argument("--seconds", type=float, default=1200)
    parser.add_argument("--threads", type=int, default=32)
    args = parser.parse_args()

    started = time.time()
    env = cp.Envr()
    model = env.createModel("z26")
    model.read(args.mps)
    variables = model.getVars()
    selected = read_selected(args.start)
    starts = [1.0 if variable.name in selected else 0.0 for variable in variables]
    model.setMipStart(variables, starts)
    model.loadMipStart()
    model.setParam(cp.COPT.Param.TimeLimit, args.seconds)
    model.setParam(cp.COPT.Param.Threads, args.threads)
    model.setParam(cp.COPT.Param.RelGap, 0.0)
    model.setParam(cp.COPT.Param.Logging, 1)
    model.solve()
    if attr(model, "hasmipsol", "HasMipSol"):
        model.write(args.output_solution)
    result = {
        "method": "generic COPT 8 CPU baseline after structure reconstruction",
        "gpu_used": False,
        "threads": args.threads,
        "time_limit_seconds": args.seconds,
        "wall_seconds": time.time() - started,
        "public_start_selected": len(selected),
        "status": str(attr(model, "status", "Status")),
        "objective": str(attr(model, "objval", "ObjVal")),
        "best_bound": str(attr(model, "bestbnd", "BestBnd")),
        "node_count": str(attr(model, "nodecnt", "NodeCnt")),
        "has_mip_solution": bool(attr(model, "hasmipsol", "HasMipSol")),
        "claim_scope": "computational solver bound only; not an exact certificate",
    }
    with open(args.output_json, "w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2, sort_keys=True)
        handle.write("\n")
    print("RESULT_JSON=" + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
