#!/usr/bin/env python3
"""Apply safe adjacent-neighborhood domination to the exact z26 graph."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from pathlib import Path

from clique_cover_search import load_graph


def read_selected(path: Path) -> set[int]:
    opener = gzip.open if path.suffix == ".gz" else open
    selected = set()
    with opener(path, "rt", encoding="utf-8") as handle:
        for raw in handle:
            tokens = raw.split()
            if len(tokens) >= 2 and tokens[0].startswith("x"):
                try:
                    if float(tokens[1]) > 0.5:
                        selected.add(int(tokens[0][1:]) - 1)
                except ValueError:
                    pass
    return selected


def independent(selected: set[int], adjacency: list[int]) -> bool:
    mask = sum(1 << vertex for vertex in selected)
    return all(adjacency[vertex] & (mask ^ (1 << vertex)) == 0 for vertex in selected)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("official_solution", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--max-passes", type=int, default=100)
    args = parser.parse_args()

    adjacency, _, edge_count = load_graph(args.mps)
    n = len(adjacency)
    active = (1 << n) - 1
    selected = read_selected(args.official_solution)
    if not independent(selected, adjacency):
        raise ValueError("input incumbent is not independent")
    sequence = []
    pass_summaries = []
    for pass_index in range(args.max_passes):
        removed = 0
        # Lower active degree is the natural candidate dominator.  Ties are
        # oriented by vertex id, preventing mutual-domination cycles.
        active_vertices = [vertex for vertex in range(n) if active & (1 << vertex)]
        active_vertices.sort(key=lambda vertex: ((adjacency[vertex] & active).bit_count(), vertex))
        for dominator in active_vertices:
            dominator_bit = 1 << dominator
            if not active & dominator_bit:
                continue
            dominator_neighbors = adjacency[dominator] & active
            candidates_mask = dominator_neighbors
            while candidates_mask:
                bit = candidates_mask & -candidates_mask
                dominated = bit.bit_length() - 1
                candidates_mask ^= bit
                if not active & bit:
                    continue
                dominated_neighbors = adjacency[dominated] & active
                outside_dominator = dominator_neighbors & ~bit
                outside_dominated = dominated_neighbors & ~dominator_bit
                if outside_dominator & ~outside_dominated:
                    continue
                # If neighborhoods are equal, keep the lower id to make the
                # reduction order canonical.
                if outside_dominator == outside_dominated and dominator > dominated:
                    continue
                selected_replaced = dominated in selected
                if selected_replaced:
                    selected.remove(dominated)
                    selected.add(dominator)
                sequence.append(
                    {
                        "delete_one_based": dominated + 1,
                        "dominator_one_based": dominator + 1,
                        "active_degree_deleted": dominated_neighbors.bit_count(),
                        "active_degree_dominator": dominator_neighbors.bit_count(),
                        "incumbent_replaced": selected_replaced,
                    }
                )
                active ^= bit
                removed += 1
                # The active neighborhood of the dominator shrank.
                dominator_neighbors &= ~bit
        pass_summaries.append({"pass": pass_index + 1, "removed": removed, "remaining": active.bit_count()})
        print(json.dumps(pass_summaries[-1]), flush=True)
        if removed == 0:
            break
    if not independent(selected, adjacency) or any(not (active & (1 << vertex)) for vertex in selected):
        raise AssertionError("incumbent back-mapping failed")
    payload = {
        "kind": "z26_safe_adjacent_open_neighborhood_domination_reduction",
        "source_sha256": hashlib.sha256(args.mps.read_bytes()).hexdigest(),
        "vertices_before": n,
        "unique_edges_before": edge_count,
        "vertices_deleted": len(sequence),
        "vertices_remaining": active.bit_count(),
        "preserves_independence_number_exactly": True,
        "sufficient_condition": "At deletion time u-v is an edge and (N(u) minus {v}) subseteq (N(v) minus {u}); every independent set containing v can replace v by u.",
        "pass_summaries": pass_summaries,
        "reduction_sequence": sequence,
        "remaining_vertices_one_based": [vertex + 1 for vertex in range(n) if active & (1 << vertex)],
        "mapped_incumbent_one_based": sorted(vertex + 1 for vertex in selected),
        "mapped_incumbent_size": len(selected),
        "mapped_incumbent_independent": True,
    }
    args.output.write_text(json.dumps(payload, separators=(",", ":")) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in payload.items() if key not in {"reduction_sequence", "remaining_vertices_one_based", "mapped_incumbent_one_based"}}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
