#!/usr/bin/env python3
"""Convert the reduced unweighted MIS OPB emitted by z26_reducer to METIS."""

import argparse
import json
import re
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("opb", type=Path)
    parser.add_argument("graph", type=Path)
    parser.add_argument("mapping", type=Path)
    args = parser.parse_args()

    variables: list[str] = []
    edges_by_name: list[tuple[str, str]] = []
    with args.opb.open("r", encoding="utf-8") as stream:
        for raw in stream:
            line = raw.strip()
            if not line or line.startswith("*"):
                continue
            names = re.findall(r"\b1\s+([A-Za-z_][A-Za-z0-9_]*)", line)
            if ">=" in line:
                variables = names
            elif "<=" in line and len(names) == 2:
                edges_by_name.append((names[0], names[1]))

    if not variables:
        raise SystemExit("missing cardinality line")
    index = {name: i for i, name in enumerate(variables)}
    adjacency = [set() for _ in variables]
    for left, right in edges_by_name:
        i, j = index[left], index[right]
        if i == j:
            raise SystemExit(f"self-loop at {left}")
        adjacency[i].add(j)
        adjacency[j].add(i)
    edge_count = sum(map(len, adjacency)) // 2

    args.graph.parent.mkdir(parents=True, exist_ok=True)
    with args.graph.open("w", encoding="utf-8", newline="\n") as stream:
        # fmt=10 means one integer node weight precedes each adjacency list.
        stream.write(f"{len(variables)} {edge_count} 10\n")
        for neighbors in adjacency:
            suffix = " ".join(str(node + 1) for node in sorted(neighbors))
            stream.write("1" + (" " + suffix if suffix else "") + "\n")
    args.mapping.write_text(
        json.dumps({"index_base": 1, "variables": variables}, indent=2) + "\n",
        encoding="utf-8",
    )
    print({"vertices": len(variables), "edges": edge_count})


if __name__ == "__main__":
    main()
