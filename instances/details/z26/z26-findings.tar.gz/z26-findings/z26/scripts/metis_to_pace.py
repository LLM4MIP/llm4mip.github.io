"""Convert the unit-weight METIS graph emitted by opb_to_metis.py to PACE VC."""
from __future__ import annotations

import argparse
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("target", type=Path)
    args = parser.parse_args()

    with args.source.open("r", encoding="ascii") as source:
        header = source.readline().split()
        if len(header) != 3 or header[2] != "10":
            raise SystemExit(f"expected unit-weight METIS fmt=10, got {header}")
        n, declared_m = map(int, header[:2])
        edges: list[tuple[int, int]] = []
        for u in range(1, n + 1):
            fields = [int(value) for value in source.readline().split()]
            if not fields or fields[0] != 1:
                raise SystemExit(f"vertex {u}: expected leading unit weight")
            for v in fields[1:]:
                if not 1 <= v <= n or v == u:
                    raise SystemExit(f"invalid edge {u} {v}")
                if u < v:
                    edges.append((u, v))
        if source.readline():
            raise SystemExit("extra METIS adjacency rows")
    if len(edges) != declared_m:
        raise SystemExit(f"edge count {len(edges)} != declared {declared_m}")

    args.target.parent.mkdir(parents=True, exist_ok=True)
    with args.target.open("w", encoding="ascii", newline="\n") as target:
        target.write(f"p td {n} {len(edges)}\n")
        for u, v in edges:
            target.write(f"{u} {v}\n")
    print(f"wrote {n} vertices and {len(edges)} edges")


if __name__ == "__main__":
    main()
