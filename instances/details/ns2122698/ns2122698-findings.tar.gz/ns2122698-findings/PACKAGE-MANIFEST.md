# Package manifest: ns2122698

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 47
Excluded source files: 1

## Included files

- `README.md`
- `analysis/gurobi-13.0.1-structure.json`
- `analysis/gurobi-13.0.1-structure.log`
- `analysis/integer-group-graph.json`
- `analysis/lp-dual-exact-certificate.json`
- `analysis/lp-dual-slack1e-4-export.json`
- `analysis/lp-dual-slack1e-4-solver.log`
- `analysis/lp-row-duals-grid1e6.sol`
- `analysis/sibling-pattern-comparison.json`
- `analysis/structure.json`
- `experiments/compare_sibling_patterns.py`
- `experiments/export_copt_lp_dual.py`
- `experiments/gurobi_structure_read.py`
- `experiments/integer_group_graph.py`
- `experiments/launch_altman_parallel.sh`
- `experiments/ns_block_forensics.py`
- `experiments/rationalize-result.json`
- `experiments/rationalize_incumbent.py`
- `experiments/run_copt_search.py`
- `experiments/run_sibling_crossover.py`
- `experiments/verify_exact_lp_dual.py`
- `input/SHA256SUMS`
- `results/copt-global-aggressive-600.json`
- `results/copt-global-bound-600.json`
- `results/copt-global-default-1800.json`
- `results/copt-global-default-1800.log`
- `results/copt-global-default-600.json`
- `results/copt-lns-01.json`
- `results/copt-lns-02.json`
- `results/copt-lns-03.json`
- `results/copt-lns-04.json`
- `results/copt-lns-05.json`
- `results/copt-lns-06.json`
- `results/copt-lns-07.json`
- `results/copt-lns-08.json`
- `results/copt-lns-pair-01-02.json`
- `results/copt-lns-pair-01-03-3600.json`
- `results/copt-lns-pair-01-06.json`
- `results/copt-lns-pair-02-03.json`
- `results/copt-lns-pair-02-06-3600.json`
- `results/copt-lns-pair-03-06.json`
- `results/sibling-crossover.json`
- `results/sibling-pattern-lp.json`
- `solutions/official-best-rationalized.sol`
- `solutions/official-best-rationalized.validation.json`
- `solutions/official-best-rationalized.validation.log`
- `solutions/official-best.sol.gz`

## Excluded files

- `input/ns2122698.mps.gz (1827932 bytes; raw benchmark input; sha256 d5336635229fc382361fdf880746ca83e605872f12f8d9396bca842ada3836af)`
