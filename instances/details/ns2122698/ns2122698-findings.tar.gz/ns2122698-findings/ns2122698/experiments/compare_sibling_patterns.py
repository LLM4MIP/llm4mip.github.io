#!/usr/bin/env python3
"""Compare C-prefix binary assignments in two MIPLIB solution files."""

from __future__ import annotations

import argparse
import gzip
import json
import re
from collections import Counter
from pathlib import Path


CHOICE = re.compile(r"^C(\d{2})R\d+D\d{4}$")


def read(path: Path) -> dict[str, int]:
    values: dict[str, int] = {}
    stream = gzip.open(path, "rt", encoding="ascii") if path.suffix == ".gz" else path.open("r", encoding="ascii")
    with stream:
        for line in stream:
            pieces = line.split()
            if len(pieces) != 2:
                continue
            if CHOICE.fullmatch(pieces[0]):
                value = float(pieces[1])
                rounded = round(value)
                if abs(value - rounded) > 1e-7:
                    raise ValueError(f"nonintegral value {pieces[0]}={value}")
                values[pieces[0]] = int(rounded)
    return values


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("target", type=Path)
    parser.add_argument("sibling", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    target = read(args.target)
    sibling = read(args.sibling)
    names = sorted(set(target) | set(sibling))
    changes = Counter()
    selected_target = Counter()
    selected_sibling = Counter()
    changed_samples = []
    for name in names:
        group = int(CHOICE.fullmatch(name).group(1))
        left = target.get(name, 0)
        right = sibling.get(name, 0)
        selected_target[group] += left
        selected_sibling[group] += right
        if left != right:
            changes[group] += 1
            if len(changed_samples) < 100:
                changed_samples.append([name, left, right])
    report = {
        "schema": "ns2122698-sibling-binary-comparison-v1",
        "target_explicit_choices": len(target),
        "sibling_explicit_choices": len(sibling),
        "union_choice_variables": len(names),
        "hamming_distance": sum(changes.values()),
        "hamming_by_group": [[group, changes[group]] for group in range(1, 65)],
        "selected_by_group_target": [[group, selected_target[group]] for group in range(1, 65)],
        "selected_by_group_sibling": [[group, selected_sibling[group]] for group in range(1, 65)],
        "changed_samples": changed_samples,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "hamming_distance": report["hamming_distance"],
        "nonzero_hamming_by_group": [item for item in report["hamming_by_group"] if item[1]],
    }, indent=2))


if __name__ == "__main__":
    main()
