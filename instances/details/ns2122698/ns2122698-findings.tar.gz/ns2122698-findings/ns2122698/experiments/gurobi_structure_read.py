#!/usr/bin/env python3
"""Read-only Gurobi structural audit for the original ns2122698 MPS.

The script intentionally never calls ``optimize``.  It records how Gurobi 13
sees the original model, including dimensions, coefficient and degree
histograms, naming patterns, repeated algebraic signatures, and incidence
components.  All hashes and matrix signatures are deterministic.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import re
import sys
from collections import Counter
from pathlib import Path

import gurobipy as gp


def stable(value: float) -> str:
    return format(float(value), ".17g")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def shape(name: str) -> str:
    return re.sub(r"\d+", "#", name)


def counter_json(counter: Counter, limit: int | None = None) -> list[list[object]]:
    items = sorted(counter.items(), key=lambda pair: (-pair[1], repr(pair[0])))
    if limit is not None:
        items = items[:limit]
    return [[key if isinstance(key, (int, float, str)) else repr(key), int(count)] for key, count in items]


class UnionFind:
    def __init__(self, size: int) -> None:
        self.parent = list(range(size))
        self.size = [1] * size

    def find(self, item: int) -> int:
        while self.parent[item] != item:
            self.parent[item] = self.parent[self.parent[item]]
            item = self.parent[item]
        return item

    def union(self, left: int, right: int) -> None:
        left = self.find(left)
        right = self.find(right)
        if left == right:
            return
        if self.size[left] < self.size[right]:
            left, right = right, left
        self.parent[right] = left
        self.size[left] += self.size[right]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    model_path = args.model.resolve()
    print(f"reading={model_path}", flush=True)
    model = gp.read(str(model_path))
    model.Params.OutputFlag = 0
    model.update()
    print(
        f"read_complete vars={model.NumVars} rows={model.NumConstrs} "
        f"nz={model.NumNZs} genconstrs={model.NumGenConstrs}",
        flush=True,
    )

    variables = model.getVars()
    rows = model.getConstrs()
    uf = UnionFind(len(variables) + len(rows))
    row_offset = len(variables)
    matrix_hash = hashlib.sha256()

    row_degree = Counter()
    row_senses = Counter()
    row_rhs = Counter()
    row_shapes = Counter()
    row_shape_degree = Counter()
    row_algebraic_signatures = Counter()
    coefficients = Counter()
    representative_rows: dict[str, dict[str, object]] = {}

    for row_index, row in enumerate(rows):
        expression = model.getRow(row)
        degree = expression.size()
        row_degree[degree] += 1
        row_senses[row.Sense] += 1
        row_rhs[stable(row.RHS)] += 1
        row_shape = shape(row.ConstrName)
        row_shapes[row_shape] += 1
        row_shape_degree[(row_shape, degree)] += 1
        signature_coeffs = []
        terms = []
        for position in range(degree):
            variable = expression.getVar(position)
            coefficient = stable(expression.getCoeff(position))
            coefficients[coefficient] += 1
            signature_coeffs.append(coefficient)
            uf.union(variable.index, row_offset + row_index)
            matrix_hash.update(
                f"{row_index}:{variable.index}:{coefficient}\n".encode("utf-8")
            )
            if len(terms) < 24:
                terms.append([variable.VarName, coefficient])
        row_algebraic_signatures[
            (row.Sense, stable(row.RHS), degree, tuple(sorted(Counter(signature_coeffs).items())))
        ] += 1
        if row_shape not in representative_rows:
            representative_rows[row_shape] = {
                "name": row.ConstrName,
                "sense": row.Sense,
                "rhs": stable(row.RHS),
                "term_count": degree,
                "terms": terms,
            }

    column_degree = Counter()
    column_shapes = Counter()
    column_shape_types = Counter()
    column_shape_objective = Counter()
    column_algebraic_signatures = Counter()
    variable_types = Counter()
    lower_bounds = Counter()
    upper_bounds = Counter()
    objectives = Counter()
    objective_nonzeros = 0
    representative_variables: dict[str, dict[str, object]] = {}

    for variable in variables:
        column = model.getCol(variable)
        degree = column.size()
        var_shape = shape(variable.VarName)
        column_degree[degree] += 1
        column_shapes[var_shape] += 1
        column_shape_types[(var_shape, variable.VType)] += 1
        column_shape_objective[(var_shape, stable(variable.Obj))] += 1
        variable_types[variable.VType] += 1
        lower_bounds[stable(variable.LB)] += 1
        upper_bounds[stable(variable.UB)] += 1
        objectives[stable(variable.Obj)] += 1
        objective_nonzeros += variable.Obj != 0
        signature_coeffs = [stable(column.getCoeff(i)) for i in range(degree)]
        column_algebraic_signatures[
            (
                variable.VType,
                stable(variable.LB),
                stable(variable.UB),
                stable(variable.Obj),
                degree,
                tuple(sorted(Counter(signature_coeffs).items())),
            )
        ] += 1
        if var_shape not in representative_variables:
            representative_variables[var_shape] = {
                "name": variable.VarName,
                "type": variable.VType,
                "lb": stable(variable.LB),
                "ub": stable(variable.UB),
                "objective": stable(variable.Obj),
                "linear_degree": degree,
            }

    component_sizes = Counter(uf.find(i) for i in range(len(variables) + len(rows)))
    component_histogram = Counter(component_sizes.values())

    def signature_rows(counter: Counter, limit: int = 50) -> list[dict[str, object]]:
        result = []
        for signature, count in counter.most_common(limit):
            result.append({"signature": repr(signature), "count": count})
        return result

    report = {
        "schema": "gurobi-read-structure-v1",
        "provenance": {
            "script": Path(__file__).name,
            "read_only_no_optimize": True,
            "model_path": str(model_path),
            "compressed_sha256": sha256(model_path),
            "python": sys.version,
            "platform": platform.platform(),
            "gurobi_version": list(gp.gurobi.version()),
        },
        "model": {
            "name": model.ModelName,
            "sense": "min" if model.ModelSense == gp.GRB.MINIMIZE else "max",
            "objective_constant": stable(model.ObjCon),
            "variables": model.NumVars,
            "linear_constraints": model.NumConstrs,
            "linear_nonzeros": model.NumNZs,
            "general_constraints": model.NumGenConstrs,
            "sos": model.NumSOS,
            "quadratic_constraints": model.NumQConstrs,
            "quadratic_objective_nonzeros": model.NumQNZs,
        },
        "variables": {
            "types": counter_json(variable_types),
            "lower_bounds": counter_json(lower_bounds, 40),
            "upper_bounds": counter_json(upper_bounds, 40),
            "objective_coefficients": counter_json(objectives, 60),
            "objective_nonzero_count": objective_nonzeros,
            "name_shapes": counter_json(column_shapes, 60),
            "shape_types": counter_json(column_shape_types, 80),
            "shape_objectives": counter_json(column_shape_objective, 120),
            "degree_histogram": counter_json(column_degree, 100),
            "representatives": [
                {"shape": key, "count": column_shapes[key], **value}
                for key, value in sorted(representative_variables.items())
            ],
            "algebraic_signature_counts": signature_rows(column_algebraic_signatures),
        },
        "linear_constraints": {
            "senses": counter_json(row_senses),
            "rhs": counter_json(row_rhs, 60),
            "coefficient_histogram": counter_json(coefficients, 120),
            "degree_histogram": counter_json(row_degree, 120),
            "name_shapes": counter_json(row_shapes, 80),
            "shape_degrees": counter_json(row_shape_degree, 160),
            "representatives": [
                {"shape": key, "count": row_shapes[key], **value}
                for key, value in sorted(representative_rows.items())
            ],
            "algebraic_signature_counts": signature_rows(row_algebraic_signatures),
        },
        "incidence": {
            "component_count": len(component_sizes),
            "component_size_histogram": counter_json(component_histogram, 100),
            "largest_component_sizes": sorted(component_sizes.values(), reverse=True)[:100],
            "ordered_matrix_sha256": matrix_hash.hexdigest(),
        },
    }

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(
        json.dumps(
            {
                "gurobi_version": report["provenance"]["gurobi_version"],
                **report["model"],
                "variable_types": report["variables"]["types"],
                "constraint_senses": report["linear_constraints"]["senses"],
                "incidence_components": report["incidence"]["component_count"],
            },
            indent=2,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
