#!/usr/bin/env python3
"""Greedy exact-binary crossover between the two pseudoapplication-93 incumbents.

Every integer variable remains fixed.  COPT is therefore used only to solve the
continuous completion of each target/sibling group pattern.  Any emitted
candidate must still be checked against the original MPS independently.
"""

from __future__ import annotations

import argparse
import gzip
import json
import re
import time
from collections import defaultdict
from pathlib import Path

import coptpy as cp


CHOICE = re.compile(r"^C(\d{2})R\d+D\d{4}$")


def read_solution(path: Path) -> dict[str, float]:
    stream = gzip.open(path, "rt", encoding="ascii") if path.suffix == ".gz" else path.open("r", encoding="ascii")
    values: dict[str, float] = {}
    with stream:
        for line in stream:
            pieces = line.split()
            if len(pieces) == 2 and not pieces[0].startswith("#"):
                values[pieces[0]] = float(pieces[1])
    return values


def attr(model, attribute, default=None):
    try:
        return model.getAttr(attribute)
    except Exception:
        return default


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--target", type=Path, required=True)
    parser.add_argument("--sibling", type=Path, required=True)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--threads", type=int, default=8)
    parser.add_argument("--max-rounds", type=int, default=8)
    parser.add_argument("--time-limit-per-lp", type=float, default=30.0)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    target = read_solution(args.target)
    sibling = read_solution(args.sibling)
    environment = cp.Envr()
    model = environment.createModel("ns2122698-sibling-crossover")
    model.read(str(args.model))
    model.setParam(cp.COPT.Param.Threads, args.threads)
    model.setParam(cp.COPT.Param.TimeLimit, args.time_limit_per_lp)
    model.setParam(cp.COPT.Param.GPUMode, 0)
    model.setParam(cp.COPT.Param.LogToConsole, 0)

    by_group = defaultdict(list)
    for variable in model.getVars().getAll():
        match = CHOICE.fullmatch(variable.name)
        if not match:
            continue
        group = int(match.group(1))
        left = target.get(variable.name, 0.0)
        right = sibling.get(variable.name, 0.0)
        if abs(left - round(left)) > 1e-7 or abs(right - round(right)) > 1e-7:
            raise ValueError(f"nonintegral choice value for {variable.name}")
        by_group[group].append((variable, round(left), round(right)))
        variable.lb = round(left)
        variable.ub = round(left)

    def solve() -> dict[str, object]:
        started = time.time()
        model.solve()
        feasible = bool(attr(model, cp.COPT.Attr.HasMipSol, False))
        return {
            "feasible": feasible,
            "objective": attr(model, cp.COPT.Attr.BestObj) if feasible else None,
            "status": attr(model, cp.COPT.Attr.MipStatus),
            "seconds": time.time() - started,
        }

    baseline = solve()
    if not baseline["feasible"]:
        raise RuntimeError("strict target incumbent pattern did not complete")

    selected_sibling_groups: set[int] = set()
    rounds = []
    best_objective = float(baseline["objective"])
    for round_index in range(1, args.max_rounds + 1):
        trials = []
        for group in sorted(by_group):
            if group in selected_sibling_groups:
                continue
            changed = 0
            for variable, left, right in by_group[group]:
                variable.lb = right
                variable.ub = right
                changed += left != right
            trial = solve()
            trial.update({"group": group, "changed_bits": changed})
            trials.append(trial)
            for variable, left, _ in by_group[group]:
                if group not in selected_sibling_groups:
                    variable.lb = left
                    variable.ub = left

        feasible_trials = [trial for trial in trials if trial["feasible"]]
        winner = min(feasible_trials, key=lambda trial: trial["objective"]) if feasible_trials else None
        rounds.append({"round": round_index, "trials": trials, "winner": winner})
        if winner is None or float(winner["objective"]) >= best_objective - 1e-7:
            break
        group = int(winner["group"])
        selected_sibling_groups.add(group)
        for variable, _, right in by_group[group]:
            variable.lb = right
            variable.ub = right
        accepted = solve()
        if not accepted["feasible"]:
            raise RuntimeError("accepted crossover pattern became infeasible")
        best_objective = float(accepted["objective"])
        model.writeSol(str(args.outdir / f"incumbent-round-{round_index}.sol"))

    result = {
        "schema": "ns2122698-sibling-crossover-v1",
        "solver": "COPT",
        "solver_version": [cp.COPT.VERSION_MAJOR, cp.COPT.VERSION_MINOR, cp.COPT.VERSION_TECHNICAL],
        "baseline": baseline,
        "selected_sibling_groups": sorted(selected_sibling_groups),
        "best_objective": best_objective,
        "rounds": rounds,
    }
    (args.outdir / "result.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "baseline": baseline,
        "selected_sibling_groups": sorted(selected_sibling_groups),
        "best_objective": best_objective,
        "round_count": len(rounds),
        "round_winners": [entry["winner"] for entry in rounds],
    }, indent=2))


if __name__ == "__main__":
    main()
