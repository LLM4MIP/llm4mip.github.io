#!/usr/bin/env bash
# Launch isolated COPT baselines and graph-derived LNS neighborhoods on altman.
set -euo pipefail

root="${1:-/home/huangyicheng/AI4MIP_ns2122698_20260908}"
copt_pythonpath="/home/huangyicheng/copt80/lib/python/310"
copt_librarypath="/home/huangyicheng/copt80/lib:/home/huangyicheng/copt80/lib/python/deps"
model="$root/input/ns2122698.mps.gz"
start="$root/solutions/official-best-rationalized.sol"
runner="$root/experiments/run_copt_search.py"

launch() {
  local name="$1"
  local seconds="$2"
  local threads="$3"
  local mode="$4"
  local groups="${5:-}"
  local out="$root/runs/$name"
  mkdir -p "$out"
  if [[ -s "$out/result.json" ]]; then
    echo "skip $name"
    return
  fi
  if [[ -s "$out/pid" ]] && kill -0 "$(<"$out/pid")" 2>/dev/null; then
    echo "skip $name"
    return
  fi
  local args=(
    "$runner" --model "$model" --start "$start" --outdir "$out"
    --time-limit "$seconds" --threads "$threads" --mode "$mode"
  )
  if [[ -n "$groups" ]]; then
    args+=(--free-groups "$groups")
  fi
  nohup env CUDA_VISIBLE_DEVICES="" PYTHONPATH="$copt_pythonpath" \
    LD_LIBRARY_PATH="$copt_librarypath" python3 "${args[@]}" \
    >"$out/launcher.log" 2>&1 </dev/null &
  echo "$!" >"$out/pid"
  echo "launched $name pid=$!"
}

launch global-default-600 600 16 default
launch global-aggressive-600 600 16 aggressive
launch global-bound-600 600 16 bound

# These eight neighborhoods are a deterministic weighted partition of the
# exact C-prefix co-occurrence graph emitted by integer_group_graph.py.
launch lns-01 180 8 aggressive "32,37,38,39,40,41,45,46"
launch lns-02 180 8 aggressive "10,11,13,48,49,51,52,54"
launch lns-03 180 8 aggressive "14,21,22,23,24,25,26,27"
launch lns-04 180 8 aggressive "2,3,5,6,7,15,16,17"
launch lns-05 180 8 aggressive "18,19,29,30,31,33,34,35"
launch lns-06 180 8 aggressive "1,8,36,42,43,44,50,53"
launch lns-07 180 8 aggressive "4,9,12,20,28,58,60,64"
launch lns-08 180 8 aggressive "47,55,56,57,59,61,62,63"

# Second phase: combine the four neighborhoods that did not close locally.
launch lns-pair-01-02 600 12 aggressive "10,11,13,32,37,38,39,40,41,45,46,48,49,51,52,54"
launch lns-pair-02-03 600 12 aggressive "10,11,13,14,21,22,23,24,25,26,27,48,49,51,52,54"
launch lns-pair-03-06 600 12 aggressive "1,8,14,21,22,23,24,25,26,27,36,42,43,44,50,53"
launch lns-pair-01-06 600 12 aggressive "1,8,32,36,37,38,39,40,41,42,43,44,45,46,50,53"

# A longer default run is retained remotely for continued numerical-bound work.
launch global-default-1800 1800 32 default
