#!/usr/bin/env python3
"""Project the public ns2122698 incumbent onto an exact 1/5 grid.

The official solution contains 258 values printed as 0.19999999999999996,
one 0.99999999999999956, and one tiny negative value.  This deterministic
repair only changes values within the requested tolerance of a multiple of
1/5.  Feasibility must subsequently be checked against the original MPS; the
projection alone is not a certificate.
"""

from __future__ import annotations

import argparse
import gzip
import json
from decimal import Decimal, getcontext
from pathlib import Path


getcontext().prec = 80


def open_text(path: Path):
    return gzip.open(path, "rt", encoding="utf-8") if path.suffix == ".gz" else path.open(encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("report", type=Path)
    parser.add_argument("--tolerance", type=Decimal, default=Decimal("1e-6"))
    parser.add_argument("--denominator", type=int, default=5)
    args = parser.parse_args()

    values: dict[str, Decimal] = {}
    with open_text(args.source) as handle:
        for raw in handle:
            tokens = raw.split()
            if len(tokens) < 2 or tokens[0].startswith(("#", "=")):
                continue
            try:
                values[tokens[0]] = Decimal(tokens[1])
            except Exception:
                pass

    denominator = Decimal(args.denominator)
    changes = []
    repaired = {}
    for variable, value in values.items():
        numerator = (value * denominator).to_integral_value()
        projected = numerator / denominator
        if abs(projected - value) <= args.tolerance:
            if projected != value:
                changes.append({"variable": variable, "old": str(value), "new": str(projected)})
            value = projected
        repaired[variable] = value

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write("# Public ns2122698 incumbent rationalized to exact multiples of 1/5.\n")
        handle.write("# This file is a candidate until independently checked against the original MPS.\n")
        for variable, value in repaired.items():
            if value:
                handle.write(f"{variable} {value}\n")
    report = {
        "operation": "nearest multiple of 1/5 when absolute change <= tolerance",
        "tolerance": str(args.tolerance),
        "source_specified_values": len(values),
        "output_nonzero_values": sum(value != 0 for value in repaired.values()),
        "changed_value_count": len(changes),
        "changes": changes,
        "certificate_status": "candidate only; run exact original-MPS validation",
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: report[key] for key in (
        "source_specified_values", "output_nonzero_values", "changed_value_count", "certificate_status"
    )}, indent=2))


if __name__ == "__main__":
    main()
