# `gsvm2rl9`

## Result

Global optimality remains open.  The official MIPLIB incumbent reports
`7438.18102117005`, but its two largest binary residuals are about `9.79e-9`.
Because those values multiply a big-M coefficient of 100, the tolerance saves
about `1.466e-4` in the continuous loss.  Rounding all 200 `z` values and
reoptimizing the continuous variables gives the canonical strictly integral
feasible value

```text
7438.181167767967106730404629
```

Its maximum recomputed row violation is `1.47e-15`, and its bound and
integrality violations are zero.  This is the same strict value reported as the
predecessor incumbent in the PartiMIP paper.

The best **global** lower bound obtained here is `2289.659530409` from a
15-minute Gurobi run.  A structure-based exhaustive split gives a much stronger
restricted bound of `6093.430103120` when all of the last 20 samples have
`z=1`, but the complementary branch only reaches `1966.167948991`; therefore
the restricted bound is not a global certificate.

Locally, all 20,101 fixed-binary LPs within `z`-Hamming radius 2 were
enumerated.  The center is best, and the second-best pattern flips only `z_48`
and has independently checked objective `7492.2058760486588`.  Gurobi and COPT
independently proved that no pattern within Hamming radius 8 can attain the official
published target `7438.18102117005`.  This cutoff-based radius-8 statement is
not a proof against a hypothetical improvement smaller than the `1.466e-4`
strict-versus-published tolerance interval.

## Input and provenance

- Compressed MPS SHA-256: `62FFB54A381BE8A7AE49FC4BEEF622514229B499BAF559323B4D78DC081DBAE2`
- Uncompressed MPS SHA-256: `8D52F049DDBE8C4F60936303B357C24EB9189D4CE01D031AA34253EC79512E80`
- Official solution `.sol.gz` SHA-256: `0F3F5B9D60F9AC69533F8799DDCD5DAB24D5761C4BFD8A74CC9B9883B19C72DC`
- Browsing LP SHA-256: `FCC3B51005E3D538C3D752EE852265588FE2335E92F2B17742126C3E82054C42`
- MIPLIB metadata and solution source: [instance page](https://miplib.zib.de/instance_details_gsvm2rl9.html)
- Model origin: Hess and Brooks, [GSVM2-RL ramp-loss SVM formulation](https://scholarscompass.vcu.edu/ssor_pubs/6/)

## Recovered structure

The original model has 801 variables, 600 constraints, 41,400 matrix nonzeros,
and 200 bounded integer variables that presolve recognizes as binary.  The
variable families are:

| Family | Count | Bounds / role |
|---|---:|---|
| `u` | 200 continuous | kernel expansion coefficients |
| `s` | 200 continuous | absolute-value envelope for `u` |
| `xi` | 200 continuous | loss variables in `[0,2]` |
| `z` | 200 binary | ramp-loss truncation choices |
| `b` | 1 free continuous | intercept |

For sample `i`, the classification row is

```text
sum_j y_i y_j K_ij u_j + y_i b + xi_i + 100 z_i >= 1,
```

with `s_j + u_j >= 0`, `s_j - u_j >= 0`, and objective

```text
sum_j s_j + sum_i C_i xi_i + sum_i 2 C_i z_i.
```

There are 88 negative samples with `C=113.636363636364` and 112 positive
samples with `C=89.2857142857143`.  Removing both label signs from the dense
classification block recovers a symmetric positive-semidefinite Gram matrix of
numerical rank exactly 10.  Samples 181--200 are all positive and form a
high-similarity block: their mean within-block kernel value is `99.7371`, versus
`0.9167` for the first 180 samples.

The strict incumbent has 37 ones in `z` (7 negative and 30 positive), including
all samples 181--200.  Only 10 `u` entries exceed `1e-9` in magnitude.  Its
objective components are `2.599991625488` from `s`, `487.529228090520` from
`xi`, and `6948.051948051959` from `z`.

## Experiment summary

| Method | Threads | Limit | Result |
|---|---:|---:|---|
| Gurobi 13.0.1, original model, bound focus | 24 | 900 s | numerical incumbent `7438.180988155`; strict checker rejects 4 rows above `1e-9`; global LB **`2289.659530409`** |
| COPT 8.0.4, original model | 32 | 900 s | official tolerance-assisted incumbent retained; global LB `1779.016260733` |
| Gurobi, all last 20 `z=1` | 32 | 900 s | strict incumbent retained; restricted LB **`6093.430103120`** |
| Gurobi, at least one of last 20 `z=0` | 32 | 900 s | no solution; restricted LB `1966.167948991` |
| Gurobi, last 20 fixed and class counts `(7,30)` | 32 | 900 s | strict incumbent retained; restricted LB **`6948.703493560`** |
| COPT, last 20 fixed and class counts `(7,30)` | 32 | 900 s | strict incumbent retained; restricted LB `6948.216967885` |
| COPT, count pairs `(6,34)`, `(17,20)`, `(28,6)` | 8 each | 300 s | no solution; final bounds `7435.064935065`, `7435.095909177`, `7435.220997701`; all timed out |
| Gurobi, count pair `(28,6)` | 32 | 900 s | no solution; restricted LB `7435.378726564`; time limit |
| fixed-`z` LP enumeration, radius 2 | 1 | 132.29 s | **20,101/20,101 patterns exhausted**; second best `7492.205876049` at flip `z_48` |
| Gurobi strict-target local ball, radius 2 | 16 | 1.85 s | infeasible; 1,239 nodes |
| Gurobi strict-target local ball, radius 4 | 16 | 19.71 s | infeasible; 14,698 nodes |
| Gurobi strict-target local ball, radius 6 | 16 | 86.29 s | infeasible; 78,789 nodes |
| Gurobi strict-target local ball, radius 7 | 16 | 194.36 s | **infeasible**; 184,324 nodes |
| Gurobi strict-target local ball, radius 8 | 32 | 219.40 s | **infeasible**; 408,054 nodes |
| COPT strict-target local ball, radius 8 | 32 | 275.37 s | **infeasible**; 293,992 nodes |

All COPT experiments on `altman` were CPU-only; GPU0 was not used.

## Reformulations that did not help

- Replacing `+100 z_i` by an indicator that disables the row when `z_i=1` is
  **not equivalent**.  The coefficient 100 is active at the incumbent: the
  indicator relaxation produces an artificial objective near `6954.58`.
- An exact SOS2 piecewise-linear value-function model was equivalent but had a
  weaker early bound than the original formulation.
- An exact Benders master over the 200 `z` variables reached only about
  `590.188` after 420 seconds; its recourse cuts were too weak for this model.
- LP screening over every affordable pair of negative/positive `z` counts
  rules out only 2 of 720 pairs globally.  With all last 20 fixed, it rules out
  only 1 of 205 pairs.

## Reproduce

The structure and solution checker requires NumPy:

```powershell
python .\instances\gsvm2rl9\scripts\analyze_structure.py `
  .\instances\gsvm2rl9\input\gsvm2rl9.mps.gz `
  --solution .\instances\gsvm2rl9\solutions\official-z-reoptimized.sol
```

The generators themselves use only the Python standard library.  The LP
enumeration, Benders experiment, and count screening require the COPT Python
API.  See the [full Chinese study](reports/gsvm2rl9-study.md),
[`scripts/`](scripts/), [`solutions/`](solutions/), and [`logs/`](logs/).
