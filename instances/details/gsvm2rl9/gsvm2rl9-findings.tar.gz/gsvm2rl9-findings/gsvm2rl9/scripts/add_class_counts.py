#!/usr/bin/env python3
"""Add exact class-specific z counts to an LP partition."""

from __future__ import annotations

import argparse
from pathlib import Path

from analyze_structure import parse_mps


def wrapped_sum(name: str, variables: list[str], relation: str, rhs: int) -> str:
    lines = [f" {name}:"]
    for start in range(0, len(variables), 16):
        chunk = " + ".join(variables[start : start + 16])
        lines.append(("  " if start == 0 else "  + ") + chunk)
    lines[-1] += f" {relation} {rhs}"
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("base_lp", type=Path)
    parser.add_argument("negative_count", type=int)
    parser.add_argument("positive_count", type=int)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    model = parse_mps(args.mps)
    columns = model["columns"]
    assert isinstance(columns, dict)
    negative = []
    positive = []
    for i in range(200):
        bcoef = columns["b"].get(f"R{i}", 0)
        (negative if bcoef < 0 else positive).append(f"z_{i + 1}")
    source = args.base_lp.read_text(encoding="utf-8")
    additions = (
        wrapped_sum("negative_z_count", negative, "=", args.negative_count)
        + "\n"
        + wrapped_sum("positive_z_count", positive, "=", args.positive_count)
        + "\n"
    )
    args.output.write_text(source.replace("Bounds\n", additions + "Bounds\n", 1), encoding="utf-8")
    print(
        f"wrote {args.output}; negative_count={args.negative_count}; "
        f"positive_count={args.positive_count}; class_sizes=({len(negative)},{len(positive)})"
    )


if __name__ == "__main__":
    main()
