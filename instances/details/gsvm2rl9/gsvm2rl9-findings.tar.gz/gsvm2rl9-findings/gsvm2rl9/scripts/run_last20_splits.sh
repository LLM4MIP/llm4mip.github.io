#!/usr/bin/env bash
set -euo pipefail

start_index="${1:-181}"
end_index="${2:-200}"
threads="${3:-4}"
time_limit="${4:-300}"
copt_cmd="${COPT_CMD:-copt_cmd}"

for index in $(seq "$start_index" "$end_index"); do
  model="last20_splits/gsvm_force_z${index}_0.lp"
  log="copt_force_z${index}_0_${time_limit}s.log"
  stdout="copt_force_z${index}_0_${time_limit}s.stdout"
  nohup "$copt_cmd" -c \
    "read $model; set Threads $threads; set TimeLimit $time_limit; set IntTol 1e-9; set FeasTol 1e-8; set LogFile $log; opt; exit" \
    >"$stdout" 2>&1 &
done

echo "started z_${start_index} through z_${end_index}; threads=$threads; time_limit=$time_limit"
