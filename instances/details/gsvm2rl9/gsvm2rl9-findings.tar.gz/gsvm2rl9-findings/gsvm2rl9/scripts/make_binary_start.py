#!/usr/bin/env python3
"""Extract and round all 200 z values into a solver MIP-start file."""

from __future__ import annotations

import argparse
from pathlib import Path

from analyze_structure import read_solution


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("solution", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    values, _ = read_solution(args.solution)
    lines = ["# Rounded binary MIP start derived from the official incumbent"]
    ones = 0
    for i in range(1, 201):
        value = values.get(f"z_{i}", 0)
        rounded = int(value > 0.5)
        ones += rounded
        lines.append(f"z_{i} {rounded}")
    args.output.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"wrote {args.output}; z_ones={ones}")


if __name__ == "__main__":
    main()
