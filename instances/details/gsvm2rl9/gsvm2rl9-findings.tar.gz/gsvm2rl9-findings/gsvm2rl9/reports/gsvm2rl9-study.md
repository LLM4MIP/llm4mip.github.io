#  `gsvm2rl9` structured solution report

Date of experiment: 2026 -09 -01 (Asia/Shanghai)

## Conclusion

This round finds a solution for a **strict integer feasible** with objective value as
`7438.181167767967106730404629`, but there is no proof globally optimal.
`2289.659530409`。

The MIPLIB official web solution is labeled `7438.18102117005`. The decimal weighting indicates that its constraint and boundaries are within official web tolerance.
However, the integer residuals of two `z` are greater than `1e-9`, up to `9.791822576e-9`.
The big-M coefficient 100 amplifies this, reducing the `xi` objective by approximately `1.466e-4`. After strictly rounding and fixing all `z` values,
Re-weighted solution continuous LP, obtained the strict feasible value above; maximum row violation `1.47e-15`, integer violation 0.

This repository, therefore, retains the following:

-  The original solution is used to reproduce the accepted numerical MIPLIB;
-  `official-z-reoptimized.sol`, as the strict integer benchmark for this study.

##  Models recovered from MPS

The variable is divided by name into `u(200)`, `s(200)`, `xi(200)`, `z(200)`, `b(1)`.

```text
sum_j y_i y_j K_ij u_j + y_i b + xi_i + 100 z_i >= 1,
```

The absolute value behaviour `s_j + u_j >= 0` and `s_j - u_j >= 0`, objective is

```text
sum_j s_j + sum_i C_i xi_i + sum_i 2 C_i z_i.
```

Of these, 88 negative-class samples have `C=113.636363636364`, while 112 positive-class samples have
`C=89.2857142857143`, and `0 <= xi_i <= 2`.
GSVM2-RL ramp-loss SVM structure.

The Gram matrix `K` is obtained by removing the tag symbols on both sides of the classification block. It is an exact symmetry, with the smallest floating-point characteristic value.
`-5.21e-13` has a negative characteristic value of no less than `-1e-8`, and the numerical rank is 10.
200 is an unfolded coefficient, and the classification data is actually in very low-dimensional nuclear space.

Sample 181 - -200 are all positive class, with the average block of nuclear similarity to each other being `99.7371`; the first batch of 180 samples
The average block value is only `0.9167`. The strict incumbent accurately assigns the entire sample of this 20 to `z=1`.

##  Composition of strict solution

The strict incumbent `z=1` is 37, with the negative class 7, and the positive class 30:

```text
3, 5, 10, 18, 36, 56, 80, 89, 113, 122, 123, 132, 143,
161, 167, 173, 180, 181, 182, 183, 184, 185, 186, 187, 188,
189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200
```

Objective decomposition is defined as:

```text
sum(s)       =    2.599991625487707642
sum(C xi)    =  487.529228090520399088...
sum(2 C z)   = 6948.051948051959
total        = 7438.181167767967106730...
```

Only 6 `xi` values are positive, and only 10 `u` values have absolute value above `1e-9`. The support indices of `u` are
`31,38,56,92,97,100,108,121,164,197`。

##  Global and structured branches

A 15-minute bound-focused Gurobi run on the original model gives global lower bound `2289.659530409`; COPT gives
`1779.016260733`. `7438.180988155` written by Gurobi appears to be lower than the official value, but independent.
4 row violation is greater than `1e-9`, maximum `9.79e-7`, so it is not a new feasible solution.

The core-block structure of the last 20 samples partitions the global feasible region exactly into two parts:

```text
A: sum(z_181,...,z_200) = 20
B: sum(z_181,...,z_200) <= 19
```

The two parts are disjoint and their union is the original feasible region. After running Gurobi for 900 seconds on each:

|  Branch |  incumbent  |  Lower bound |  Conclusion |
|---|---:|---:|---|
| A | `7438.181167768` | `6093.430103120` | 18.0790% restricted gap |
|  B  |  None |  `1966.167948991`  | There is no better solution, but there is no exclusion. |

Branch A's boundary is strong, indicating that the high degree of similarity does capture the incumbent structure; but Branch B is too weak, and it does not have a similar structure.
So 6093.43 cannot be considered a global lower bound.

Further count the category `(negative z, positive z)=(7,30)` in branch A fixed incumbent.
Gurobi 900 is given by the lower bound `6948.703493560`, and COPT is given by `6948.216967885`; Gurobi
The restricted gap is 6.5806 %.

##  Selection of categories

Since `z`'s objective coefficients take only two values, the enumeration can all support the current primal bound number of class pairs.
`z` is released as a sequence to solution LP:

-  global total 720 pairs; LP exclusion only 2 pairs, remaining 718 pairs;
-  At the end of the fixed 20, the 1 is followed by the 205 pair; LP only exclusion 1 pair, remaining 204 pair.

The global candidate counts closest to the current strict value are `(6,34)`, `(17,20)`, `(28,6)`.
The lower bound is approximately `7435.064935`, a gap of only 3.116. Each COPT run used 8 threads for 300 seconds and found no solution,
also failed to complete infeasibility proofs; their final lower bounds were `7435.064935065`, `7435.095909177`,
`7435.220997701`. In which `(28,6)` runs the Gurobi 32 thread for 900 seconds, the general boundary is upgraded to
`7435.378726564` has not been proven infeasible.

This illustrates the real difficulty of selecting which samples will enter `z=1`, rather than determining the number of categories for `z=1`.

##  Local poverty and local branches

For the strict incumbent around the Hamming radius 2 full mode, fixed `z` backward solution continuous LP.
The number of models is

```text
1 + C(200,1) + C(200,2) = 20,101.
```

COPT single thread with 132.29 second solution complete part of 20,101 LP.
`z_48` was changed from 0 to 1, objective `7492.2058760486588`, with the maximum row violation `2.82e-14`,
`54.024708280692` is different from the center.

In order to expand the neighborhood, the original model was added to the Hamming Ball and the Hamming Ball.
`objective <= 7438.18102117005`. Gurobi proved infeasibility within radii 2, 4, 6, and 7,
Gurobi and COPT also separate the proof radius 8 infeasible:

|  Radius |  Time |  Nodes |  Status |
|---:|---:|---:|---|
| 2 | 1.85 s | 1,239 | infeasible |
| 4 | 19.71 s | 14,698 | infeasible |
| 6 | 86.29 s | 78,789 | infeasible |
| 7 | 194.36 s | 184,324 | infeasible |
| 8，Gurobi | 219.40 s | 408,054 | **infeasible** |
| 8，COPT | 275.37 s | 293,992 | **infeasible** |

This radius-8 certificate targets reaching or improving the published official objective. It does not exclude values between the strict value and the official value
The very narrow range is about `1.466e-4`; the fixed integer LP of the radius 2 directly compares the strict over-optimization value.

##  Ineffective or Weaker Directions

1.  **indicator is not equivalent.** closes the classification line to complete the `z=1` explanation, reducing the objective to approximately
`6954.58`. The original model still required a margin not less than about `-99`, so big-M= 100 is in incumbent.
It is active nearby and cannot be deleted.
2.  **SOS2 value function.** explicitly rewrites each ramp loss to the exact PWL/SOS2 model, early lower bound.
It's worse than the original MPS, stop continuing.
3. **Benders.** Decomposition with the 200 `z` variables as the master and continuous SVM as recourse is equivalent,
However, the 420 second master lower bound is only about `590.188`, much weaker than direct branch-and-cut.

##  Conclusion on the Border

-  There is a strict integer feasible solution `7438.181167767967...`.
-  `7438.18102117005` is an incumbent accepted under the MIPLIB tolerance, not a warehouse repository strict rounding
The objective value afterwards.
-  Radius 2 fixed mode is complete; radius 8 only gives local infeasible proof to the official objective interrupt.
-  Globally optimal has not yet been proven; `6093.430103120` and `6948.703493560` are bounded branch boundaries.
Global lower bound `2289.659530409` cannot be replaced.

## material

- [MIPLIB `gsvm2rl9` instance details](https://miplib.zib.de/instance_details_gsvm2rl9.html)
- [Hess--Brooks：Mixed Integer Programming Approaches for Training Linear Support Vector Machines](https://scholarscompass.vcu.edu/ssor_pubs/6/)
- [PartiMIP source repository](https://github.com/shaowei-cai-group/PartiMIP)
- [PartiMIP CP 2025 paper](https://drops.dagstuhl.de/storage/00lipics/lipics-vol340-cp2025/LIPIcs.CP.2025.26/LIPIcs.CP.2025.26.pdf)
