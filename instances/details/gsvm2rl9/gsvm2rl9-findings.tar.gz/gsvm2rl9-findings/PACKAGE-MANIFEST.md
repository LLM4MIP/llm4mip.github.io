# Package manifest: gsvm2rl9

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 50
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/class_count_last20_lp_bounds.csv`
- `artifacts/class_count_lp_bounds.csv`
- `artifacts/gsvm_original.lp`
- `artifacts/local-radius2-enumeration.txt`
- `artifacts/structure-summary.txt`
- `logs/copt_all_last20_counts_7_30_15m.log`
- `logs/copt_case_all_last20_15m.log`
- `logs/copt_counts_17_20_5m.log`
- `logs/copt_counts_28_6_5m.log`
- `logs/copt_counts_6_34_5m.log`
- `logs/copt_local_radius8_5m.log`
- `logs/copt_original_15m.log`
- `logs/gurobi_case_all_last20_15m.log`
- `logs/gurobi_case_not_all_last20_15m.log`
- `logs/gurobi_core_7_30_15m.log`
- `logs/gurobi_counts_28_6_15m.log`
- `logs/gurobi_indicator_15m.log`
- `logs/gurobi_local_radius2_5m.log`
- `logs/gurobi_local_radius4_5m.log`
- `logs/gurobi_local_radius6_5m.log`
- `logs/gurobi_local_radius7_5m.log`
- `logs/gurobi_local_radius8_15m.log`
- `logs/gurobi_local_radius8_5m.log`
- `logs/gurobi_original_bound_15m.log`
- `logs/gurobi_pwl_sos2_15m.log`
- `reports/gsvm2rl9-study.md`
- `scripts/add_class_counts.py`
- `scripts/analyze_structure.py`
- `scripts/benders_decomposition.py`
- `scripts/enumerate_local_patterns.py`
- `scripts/fix_z_value.py`
- `scripts/make_binary_start.py`
- `scripts/make_indicator_lp.py`
- `scripts/make_local_branch_lp.py`
- `scripts/make_partition_lp.py`
- `scripts/make_pwl_sos2_lp.py`
- `scripts/run_last20_splits.sh`
- `scripts/screen_class_counts.py`
- `solutions/copt_all_last20_counts_7_30_15m.sol`
- `solutions/copt_original_15m.sol`
- `solutions/gurobi_case_all_last20_15m.sol`
- `solutions/gurobi_core_7_30_15m.sol`
- `solutions/gurobi_original_bound_15m.sol`
- `solutions/local-radius2-second-best.sol`
- `solutions/official-incumbent.sol`
- `solutions/official-incumbent.sol.gz`
- `solutions/official-pwl.mst`
- `solutions/official-z-reoptimized.sol`
- `solutions/official-z.mst`

## Excluded files

- `input/gsvm2rl9.mps.gz (346677 bytes; raw benchmark input; sha256 62ffb54a381be8a7ae49fc4beef622514229b499baf559323b4d78dc081dbae2)`
