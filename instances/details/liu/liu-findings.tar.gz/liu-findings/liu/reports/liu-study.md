#  `liu` structured solution report

2026 -09 -01; additional experiment: 2026 -09 -07 (Asia/Shanghai)

## Conclusion

`liu` is a VLSI floorplanning problem in which the 33 rotatable rectangle is inserted into the smallest square.
**1082** new solution. After translating the CP-SAT layout back to the original 1,156 MPS variable, 2,178 line constraint, variable
The solution strict is better than the exact objective 1084; globally optimal is still unproven.

The most important new conclusion is not the lower bound of the general solver, but a structural certificate: **
even**. The area lower bound is 1073, so the strict global lower bound strengthens to **1074**. This result first takes the official
The improvement target 1084 reduces to 1082, which the sequence-pair model subsequently attains; the only next target requiring
The proposed improvement objective is 1080.

The MIPLIB page currently shows `1083.984782*`, but the official website also marks the exact objective as 1084, maximum.
The constraint violation is `0.007962`. Local row-by-row decimal recomputation finds 19 row violations above `1e-6`, with the same maximum
`0.007962` (`c135`) is therefore not a feasible solution that is strictly superior to 1084.

##  Models recovered from MPS

The original model contains a 1,156 variable, a 2,178 line and a 10,626 nonzero entries:

|  variable / constraint |  Count |  Meaning |
|---|---:|---|
|  continuous variables |  67  | Square length `x1` plus 33 to the coordinates |
| Rotate the binary variable |  33  | Each rectangle is one; the rotation of two square variables is virtually ineffective. |
| Location-coded binary variable |  1,056  | 528 is a pair of rectangles, two bits per pair |
| Non-overlapping lines |  2,112  | Each pair of rectangular four lines |
| Border crossing |  66  | Each rectangle has a horizontal, longitudinal boundary |

The common big-M is 8398. For any `i<j`, the two-bit explanation is:

```text
(0,0): i on the left side of j (1,0): j on the left side of i
(0,1): i is below j (1,1): j is below i
```

The total area of the rectangle 33 is `1,149,192`. The square area of the new longitudinal 1082 is `1,170,724`.
`21,532`. The maximum number of conventions of all lengths is 2.

##  Proof of even number length

After all fixed binary variables, the remaining coordinates and `x1` appear only in the differential constraint.
The matrix is therefore totally unimodular. Rectangle dimensions and `M=8398` are even, so every right-hand side is even. Scale the coordinates and `x1`
A totally unimodular system of integers on the right-hand end is obtained except for 2; for each fixed binary mode, `x1` is always an integer extreme point.
After reflecting back to the original scale, coordinates and lateral lengths are even numbers.

Therefore, globally optimal values can be selected as even numbers. The area is given `ceil(sqrt(1149192))=1073`, and the combined evenness is obtained.
lower bound 1074. 1082 is already feasible, so the next possible strict improvement must be directly to 1080.

##  The exact solution

Strictly feasible solution (official solution ID 4):

```text
objective_side              1084.0000000000007
max_x_extent                1084.00000000000068
max_y_extent                1084.00000000000068
row violations              0
bound violations            0
integrality residual        0
```

This round is a new solution:

```text
objective_side              1082
max_x_extent                1082
max_y_extent                1082
unused area                 21532
row violations              0
bound violations            0
integrality residual        0
```

Gurobi 13.0.1 and COPT 8.0.4 also read this new `.sol` back to the original MPS respectively; in feasibility and integer tolerance.
Both receive objective 1082's MIP start when both are set to `1e-9`, COPT report bounds, rows, 
Integration violations are all for 0.

The current numerical solution (official solution ID 5):

```text
objective_side              1083.984782
rows violated > 1e-6       19
maximum row violation       0.007962 at c135
bound violations            0
integrality residual        0
```

##  1082 Objective equivalent strengthening

###  1. Squeeze the big-M

Under the `x1<=1082`, each rectangle has a co-ordinate + width/height not greater than 1082, and the other rectangle has a nonnegative co-ordinate.
To close a separation constraint, only `M=1082` is required, and the original 8398 can be safely replaced.
The range of matrix coefficients for bit encoding decreases from about `8.4e3` to `1.1e3`, but the root relaxation objective remains weak.

###  2. Indicator of origin

For each pair of rectangles, four variables are rebuilt left/right/below/above and aligned to 1; each variable is native.
indicator Activate the corresponding geometric separation. The model completes the removal of the big-M. The Gurobi root node is often cut after multiple rounds.
There are only a dozen unknown integers remaining, which are significantly more powerful than the more than a hundred compact big-M models, but the global tree is still expanding rapidly.

###  3. global two dimensional no-overlap

All sizes are divided by 2 and the objective is changed to 541 × 541.
`NoOverlap2D`, two cumulative sweep, and energetic/timetabling propagation.

### 4. sequence pair

The original four pair codes corresponded well to the four relative sequences of sequence pairs, but MPS did not explicitly impose two.
Transferability of the sequence. The new model uses the full sequence rank vector of two 0 - -32 to encode all relationships, while retaining redundancy.
`NoOverlap2D` with cumulative propagation. 1084 layout has been successfully converted into a legitimate sequence pair.
and uses it as a repair hint for the 1082 search. CP-SAT found a layout with value 1082 in `460.253` seconds, reporting a total of
314,800 conflicts and 1,755,079 branches.
All the independent decimal checks have been passed.

##  The results of the experiment

|  Method |  Threads |  Time limit |  result |
|---|---:|---:|---|
| Gurobi 13.0.1, originally MPS + strict |  32  | Switch after about 250 seconds |  incumbent 1084 ;  lower bound 614 |
| COPT 8.0.4, originally MPS + strict starting point |  32  | Switch after about 250 seconds |  incumbent 1084 ;  lower bound 560 |
| Gurobi, the tight-M of the 1082 target |  32  | Switch after about 186 seconds | No feasible points found; trees not closed |
| The 1082 target of the COPT, tightened-M |  32  | Switch after about 189 seconds | No feasible points found; trees not closed |
|  Gurobi, indicator 1082 target  |  32  | 900 seconds | Not found feasible point; reached deadline |
|  COPT, indicator 1082 target  |  32  | 900 seconds | Not found feasible point; reached deadline |
| Gurobi, indicator + official website |  32  | 300 seconds | Not found feasible point; reached deadline |
| CP-SAT, common no-overlap, edge length 1084 |  16  | 120 seconds | UNKNOWN; official website solution other than strict |
| CP-SAT, sequence pair + 1084 hint, side length 1082 |  64  | 900 seconds | **460.253 seconds to find strict feasible layout 1082** |
| Gurobi, indicator 1080 + 1082 |  64  | 900 seconds | Not found feasible point; 3,395,068 node; reached deadline |
| CP-SAT, sequence pair + 1082 hint, side length 1080 |  96  | 900 seconds |  `UNKNOWN`; 677,817 conflicts, 3,849,381 branches  |

The above COPT and CP-SAT both use CPUs on `altman`; **does not use GPU0**.

The `OPTIMAL` of the fixed CP-SAT margin indicates that the satisfactory model has found a solution, not that the original minimization problem is optimal.
Gurobi/COPT's not found feasible dot sequences only describe their respective operations, and cannot cover the 1082 subsequently found by CP-SAT.
1080's Gurobi and CP-SAT also reached the deadline, with no layout found and no proof infeasible.
The strict upper bound is 1082 and the strict lower bound is 1074: **1074 ≤ optimum ≤ 1082**. The optimum remains open.

##  Why Simplicity Is Not Enough

enumeration of the 657,721 longitudinal combination of the dual feasible function of floor and threshold and taking the best advantage of the rotation
Directions: The largest conversion area ratio remains at

```text
287298 / 292681 = 0.981607962
```

reduces to the original area bound and does not exceed the container capacity. The difficulty comes from the combinatorial geometry of relative rectangle positions rather than a
A simple one-dimensional/area inequality is missing.

##  2026 -09 -07: Key geometry experiments for the 1080

The two 541 routes recovered from the strict 1082 layout are:

```text
Horizontal: 15--21--2--12--6--20--28--16
Vertical: 4--12--30--7--3
```

In addition, there are three pieces with full horizontal width 541 and five pieces with full longitudinal height 541.
From pressing 541 to pressing 540, multiple key chains must be destroyed simultaneously or several rectangular directions must be changed.

This round was preceded by a search and screening of MIP/CP solvers:

-  Complete enumeration All single inserts in two sequence-pair arrays and all single-rectangular spins are 2,143
Neighbors; 541 × 541 is still optimal, with 133 moving only as an equivalent value.
-  On the 541 platform, widely searched for different states of 50,000 and evaluated candidates for 4,329,398, the deepest to 3, which has not yet been determined.
I've found 540.
-  After fixing the reboot problem of crossing the barrier, the combined ILS of the seed 97 completed the second generation of 11,202,782 in 600 seconds.
Optimal is 541 × 541.
-  1,350 is a dual feasible function for identity, floor, threshold and Fekete-Schepers stair
1,822,500 is a perpendicular combination and retains the symbol contribution of the rotating variable; all inequalities have already been made before the selection direction
Redundancy does not create new limits beyond the area boundary.

The exact constraint sub-question was then established, which was released in stages:

|  Subproblem |  result |
|---|---|
| Only allow the critical rectangle of 12 to change its relative relationship to each other | Presolve determines `INFEASIBLE` , 0.014527 second |
| This allows the 12 rectangle to rotate and pass through the rest of the rectangle, the external skeleton fixed | `INFEASIBLE` , 156.092 seconds, 165,034 conflicts |
| Add a full-loaded slice rectangle to the 5 and release the 17. | 900.157 After seconds `UNKNOWN` , 1,204,936 conflicts |
| All directions of the fixed 1082, but global rearrangement of all coordinates | 900.040 After seconds `UNKNOWN` , 1,896,203 conflicts |
| All native two-dimensional models that are oriented and coordinated freely | 900.110 After seconds `UNKNOWN` , 1,180,797 conflicts |
| Gurobi indicator, fixed direction, global repositioning | 900 seconds, 4,658,131 node reaches the time limit and no solution is found |

The first two `INFEASIBLE` are strictly closed with the sequence-pair neighborhood described; 17 modules and two global
The two-dimensional model does not have a closure. Single-step enumeration, platform search, ILS and dual feasible function failures do not introduce 1080.
Therefore this round has not changed strictly. The conclusion is that **1074 ≤ optimum ≤ 1082**.
Machine-readable analysis and reproduction commands
[`../experiments/critical-geometry-20260907/`](../experiments/critical-geometry-20260907/)。

##  Next suggestion

1.  Use the new 1082 sequence pair as a repair hint and test the 1080, 1078 and other odd-number objectives in stages;
2.  The first row of the sequence-pair is divided as a forefront, producing mutually repugnant and complete subtasks, followed by long runs;
3.  Starting from the 1082 sequence pair, the two sequences are Kendall distance local branch, first proof a large
1080 is infeasible within the neighborhood;
4.  Add the rank/transitivity constraint to the indicator model in two rows, cutting Gurobi's strong LP/
combined with sequence-pair combined structures;
5.  To pursue a complete proof, retrievable multi-day tasks should be used instead of typing the 15 Minutes without solution.
   infeasible。

## material

- [MIPLIB `liu` instance details](https://miplib.zib.de/instance_details_liu.html)
- [Murata et al. (1996), sequence-pair floorplanning](https://doi.org/10.1109/43.552084)
- [OR-Tools NoOverlap2D / CP-SAT parameters](https://or-tools.github.io/docs/javadoc/com/google/ortools/sat/SatParameters.html)
- [PackingSolver rectangle algorithms](https://fontanf.github.io/packingsolver/internals/rectangle.html)
