# `liu` target-1080 critical-geometry study (2026-09-07)

## Scope and result

The exact target is a `540 x 540` packing after dividing every original
dimension by the common factor 2.  This study did not find such a packing and
did not prove global infeasibility.  The rigorous global interval therefore
remains

```text
1074 <= OPT <= 1082.
```

All `INFEASIBLE` statements below refer only to explicitly frozen
sequence-pair neighborhoods.  `UNKNOWN` and heuristic failures are not used as
global lower-bound evidence.

## Structure of the strict 1082 layout

The compacted 1082 witness has scaled extent `541 x 541`.  Its two longest
precedence paths are

```text
horizontal: 15--21--2--12--6--20--28--16  (total width 541)
vertical:    4--12--30--7--3               (total height 541)
```

Three horizontal and five vertical occupied slices use the full width or
height 541.  The complete path, slice, contact, border, earliest-position, and
slack data are in
[`../../artifacts/bottleneck-analysis-1082.json`](../../artifacts/bottleneck-analysis-1082.json).

## Solver-free searches and necessary-condition filters

1. The complete one-move sequence-pair neighborhood contains 2,143 moves:
   every insertion in either permutation and every single-module rotation.
   Its best extent is still `541 x 541`; 133 moves are neutral and none reaches
   `541 x 540`, `540 x 541`, or `540 x 540`.
2. A breadth search restricted to the 541 plateau evaluated 4,329,398
   generated candidates and retained 50,000 distinct states through depth 3.
   It found no extent below 541.  This is a finite search of that recorded
   neighborhood, not a global proof.
3. An orientation-aware dual-feasible-function filter tested 1,350 functions
   (identity, floor, threshold, and Fekete--Schepers stair functions) in all
   1,822,500 ordered pairs.  Every inequality was redundant even before
   choosing rotations, so this family adds no restriction beyond the area
   bound for target 1080.
4. A repaired iterated local search accepted sequence-pair moves only within a
   15-unit barrier above the incumbent.  Seed 97 completed 11,202,782
   iterations in 600 seconds without improving `541 x 541`.  This is a search
   result, not an exhaustive neighborhood certificate.

Machine-readable results are
[`../../artifacts/one-move-neighborhood-1082.json`](../../artifacts/one-move-neighborhood-1082.json),
[`plateau-search.log`](plateau-search.log), and
[`../../artifacts/orientation-dff-target1080.json`](../../artifacts/orientation-dff-target1080.json).
The final ILS incumbent is [`ils-seed97-best.json`](ils-seed97-best.json).

## Exact restricted CP-SAT neighborhoods

The initial critical set was

```text
2,3,4,6,7,12,15,16,20,21,28,30.
```

- With every rotation and relation involving an outside module fixed, changing
  only relations internal to these 12 modules is `INFEASIBLE` in presolve
  (`0.014527` seconds).
- With outside--outside relations and outside rotations fixed, but allowing
  each of the 12 modules to rotate and to move across any outside module, the
  target is `INFEASIBLE` after `156.092` seconds, 165,034 conflicts, and
  377,190 branches.
- Adding modules `9,11,18,19,29` from alternative full slices gives a
  17-module neighborhood.  It remains `UNKNOWN` after `900.157` seconds,
  1,204,936 conflicts, and 3,610,806 branches.

The raw transcripts are
[`critical12-internal-lns.log`](critical12-internal-lns.log),
[`critical12-cross-lns.log`](critical12-cross-lns.log), and
[`critical17-cross-lns.log`](critical17-cross-lns.log).

## Global-position checks

With all 1082 rotations fixed but every coordinate and pair relation free, the
native `NoOverlap2D` model remained `UNKNOWN` after `900.040` seconds,
1,896,203 conflicts, and 6,742,329 branches.  The three duplicate-dimension
pairs have identical *oriented* dimensions under this rotation vector, so the
three lexicographic symmetry breaks in this run are valid.  See
[`no-overlap-fixed-rotation.log`](no-overlap-fixed-rotation.log).

Freeing all 30 effective rotation choices and all coordinates in a second
native `NoOverlap2D` run also remained `UNKNOWN` after `900.110` seconds,
1,180,797 conflicts, and 4,411,310 branches.  It found no 1080 placement; see
[`no-overlap-all-rotations.log`](no-overlap-all-rotations.log).  A
symmetry-free fixed-rotation Gurobi indicator model independently reached its
900-second limit after 4,658,131 branch-and-bound nodes, with no feasible
placement and 1,412,221 nodes still open.  This is likewise a time-limit
result, not a proof that the fixed orientation vector is impossible; see
[`gurobi-fixed-rotation.log`](gurobi-fixed-rotation.log).

## Reproduce the non-solver analyses

```powershell
python .\instances\liu\scripts\analyze_1082_bottlenecks.py `
  .\instances\liu\input\liu.mps.gz `
  .\instances\liu\solutions\cpsat1082_sequence_hint.json `
  --out .\instances\liu\artifacts\bottleneck-analysis-1082.json

python .\instances\liu\scripts\analyze_sequence_neighborhood.py `
  .\instances\liu\input\liu.mps.gz `
  .\instances\liu\solutions\cpsat1082_sequence_hint.json `
  --out .\instances\liu\artifacts\one-move-neighborhood-1082.json

python .\instances\liu\scripts\orientation_dff_filter.py `
  .\instances\liu\input\liu.mps.gz --side 1080 `
  --hint-json .\instances\liu\solutions\cpsat1082_sequence_hint.json `
  --out .\instances\liu\artifacts\orientation-dff-target1080.json

python .\instances\liu\scripts\search_sequence_pair_ils.py `
  .\instances\liu\input\liu.mps.gz `
  .\instances\liu\solutions\cpsat1082_sequence_hint.json `
  --target 1080 --seconds 600 --seed 97 --barrier 15 `
  --out .\instances\liu\experiments\critical-geometry-20260907\ils-seed97-best.json
```

The stair-function implementation follows Fekete and Schepers,
[*New Classes of Fast Lower Bounds for Bin Packing Problems*](https://www.ibr.cs.tu-bs.de/users/fekete/hp/publications/PDF/2001-New_Classes_of_Fast_Lower_Bounds_for_Bin_Packing_Problems.pdf).
