#!/usr/bin/env python3
"""Translate an original liu solution into a partial start for the indicator model."""

from __future__ import annotations

import argparse
from pathlib import Path

from analyze_structure import parse_mps, read_solution, recover


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("output_mst", type=Path)
    args = parser.parse_args()

    structure = recover(parse_mps(args.mps))
    values = read_solution(args.solution)
    modules = structure["modules"]
    code_variables = sorted(structure["pair_binary_variables"], key=lambda name: int(name[1:]))
    codes = [
        (int(values[code_variables[k]]), int(values[code_variables[k + 1]]))
        for k in range(0, len(code_variables), 2)
    ]
    direction = {(0, 0): "left", (1, 0): "right", (0, 1): "below", (1, 1): "above"}
    lines = ["# Partial MIP start translated from the official strict 1084 solution"]
    for module in modules:
        if module["rotation"]:
            lines.append(f"{module['rotation']} {int(values[str(module['rotation'])])}")
    cursor = 0
    for i in range(len(modules)):
        for j in range(i + 1, len(modules)):
            chosen = direction[codes[cursor]]
            for candidate in ("left", "right", "below", "above"):
                lines.append(f"p_{i + 1}_{j + 1}_{candidate} {int(candidate == chosen)}")
            cursor += 1
    args.output_mst.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"wrote {args.output_mst} with {len(lines) - 1} binary values")


if __name__ == "__main__":
    main()
