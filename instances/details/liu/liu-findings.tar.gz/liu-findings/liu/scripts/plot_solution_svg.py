#!/usr/bin/env python3
"""Render an exact liu placement as a dependency-free SVG."""

from __future__ import annotations

import argparse
from decimal import Decimal
from html import escape
from pathlib import Path

from analyze_structure import parse_mps, read_solution, recover


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("output_svg", type=Path)
    args = parser.parse_args()

    structure = recover(parse_mps(args.mps))
    values = read_solution(args.solution)
    side = int(values[str(structure["side"])].to_integral_value())
    margin = 45
    palette = ("#4e79a7", "#f28e2b", "#e15759", "#76b7b2", "#59a14f", "#edc949", "#af7aa1")
    lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {side + 2 * margin} {side + 2 * margin}" role="img">',
        f'<title>{escape(args.solution.name)}: exact {side} by {side} floorpacking</title>',
        '<rect width="100%" height="100%" fill="#ffffff"/>',
        f'<rect x="{margin}" y="{margin}" width="{side}" height="{side}" fill="#f7f7f7" stroke="#111" stroke-width="4"/>',
    ]
    for index, module in enumerate(structure["modules"], start=1):
        rotation = values.get(str(module["rotation"]), Decimal(0)) if module["rotation"] else Decimal(0)
        width = int(module["width"] + module["width_delta"] * rotation)
        height = int(module["height"] + module["height_delta"] * rotation)
        x = int(values[str(module["x"])].to_integral_value())
        y = int(values[str(module["y"])].to_integral_value())
        svg_x = margin + x
        svg_y = margin + side - y - height
        color = palette[(index - 1) % len(palette)]
        lines.append(
            f'<rect x="{svg_x}" y="{svg_y}" width="{width}" height="{height}" '
            f'fill="{color}" fill-opacity="0.78" stroke="#222" stroke-width="2"/>'
        )
        lines.append(
            f'<text x="{svg_x + width / 2}" y="{svg_y + height / 2 + 7}" text-anchor="middle" '
            f'font-family="sans-serif" font-size="20" font-weight="700" fill="#111">{index}</text>'
        )
    lines.append(
        f'<text x="{margin + side / 2}" y="28" text-anchor="middle" font-family="sans-serif" '
        f'font-size="22" font-weight="700">liu: exact side {side}</text>'
    )
    lines.append("</svg>")
    args.output_svg.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"wrote {args.output_svg}")


if __name__ == "__main__":
    main()
