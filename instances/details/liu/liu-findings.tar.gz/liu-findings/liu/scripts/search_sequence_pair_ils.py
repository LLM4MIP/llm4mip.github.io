#!/usr/bin/env python3
"""Solver-free iterated local search over Liu sequence pairs and rotations."""

from __future__ import annotations

import argparse
import json
import math
import random
import time
from pathlib import Path

from analyze_structure import parse_mps, recover


def ranks_to_order(ranks):
    return sorted(range(len(ranks)), key=lambda i: ranks[i])


def order_to_ranks(order):
    ranks = [0] * len(order)
    for rank, module in enumerate(order):
        ranks[module] = rank
    return ranks


def dimensions(modules, rotations, scale):
    widths = []
    heights = []
    for module, rotated in zip(modules, rotations):
        widths.append(int(module["height"] if rotated else module["width"]) // scale)
        heights.append(int(module["width"] if rotated else module["height"]) // scale)
    return widths, heights


def evaluate(modules, positive_order, negative_order, rotations, scale):
    count = len(modules)
    negative_rank = order_to_ranks(negative_order)
    widths, heights = dimensions(modules, rotations, scale)
    earliest_x = [0] * count
    earliest_y = [0] * count
    predecessor_x = [-1] * count
    predecessor_y = [-1] * count
    for position, v in enumerate(positive_order):
        for u in positive_order[:position]:
            if negative_rank[u] < negative_rank[v]:
                candidate = earliest_x[u] + widths[u]
                if candidate > earliest_x[v]:
                    earliest_x[v] = candidate
                    predecessor_x[v] = u
            else:
                candidate = earliest_y[u] + heights[u]
                if candidate > earliest_y[v]:
                    earliest_y[v] = candidate
                    predecessor_y[v] = u
    extent_x = max(earliest_x[i] + widths[i] for i in range(count))
    extent_y = max(earliest_y[i] + heights[i] for i in range(count))

    def path(axis, extent, lengths, predecessors):
        end = min(i for i in range(count) if axis[i] + lengths[i] == extent)
        answer = []
        while end >= 0:
            answer.append(end)
            end = predecessors[end]
        return list(reversed(answer))

    return {
        "extent_x": extent_x,
        "extent_y": extent_y,
        "x": earliest_x,
        "y": earliest_y,
        "widths": widths,
        "heights": heights,
        "critical_path_x": path(earliest_x, extent_x, widths, predecessor_x),
        "critical_path_y": path(earliest_y, extent_y, heights, predecessor_y),
    }


def energy(evaluation, target):
    x = evaluation["extent_x"]
    y = evaluation["extent_y"]
    # The maximum extent remains primary, but the sum and imbalance guide the
    # walk through plateaus and permit small temporary barriers.
    return 20.0 * max(x, y) + x + y + 0.02 * abs(x - y)


def insert_move(order, source, destination):
    answer = list(order)
    module = answer.pop(source)
    answer.insert(destination, module)
    return answer


def payload(evaluation, positive_order, negative_order, rotations, scale):
    return {
        "side": max(evaluation["extent_x"], evaluation["extent_y"]),
        "scale": scale,
        "x": evaluation["x"],
        "y": evaluation["y"],
        "rotation": rotations,
        "positive_rank": order_to_ranks(positive_order),
        "negative_rank": order_to_ranks(negative_order),
        "extent_x": evaluation["extent_x"],
        "extent_y": evaluation["extent_y"],
        "critical_path_x": [i + 1 for i in evaluation["critical_path_x"]],
        "critical_path_y": [i + 1 for i in evaluation["critical_path_y"]],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("hint", type=Path)
    parser.add_argument("--target", type=int, default=1080)
    parser.add_argument("--seconds", type=float, default=600.0)
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--log-every", type=int, default=10000)
    parser.add_argument("--barrier", type=int, default=10)
    args = parser.parse_args()

    modules = recover(parse_mps(args.mps))["modules"]
    start = json.loads(args.hint.read_text(encoding="utf-8"))
    scale = math.gcd(
        *(int(value) for module in modules for value in (module["width"], module["height"]))
    )
    target = args.target // scale
    if args.target % scale:
        raise ValueError("target is not divisible by the dimension gcd")
    positive = ranks_to_order(start["positive_rank"])
    negative = ranks_to_order(start["negative_rank"])
    rotations = [int(value) for value in start["rotation"]]
    rotatable = [
        i for i, module in enumerate(modules) if module["width"] != module["height"]
    ]
    rng = random.Random(args.seed)
    started = time.monotonic()
    deadline = started + max(0.0, args.seconds)

    current_eval = evaluate(modules, positive, negative, rotations, scale)
    current_energy = energy(current_eval, target)
    best = (list(positive), list(negative), list(rotations), current_eval)
    best_key = (
        max(current_eval["extent_x"], current_eval["extent_y"]),
        current_eval["extent_x"] + current_eval["extent_y"],
    )
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(
        json.dumps(payload(current_eval, positive, negative, rotations, scale), indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"start extent={current_eval['extent_x']}x{current_eval['extent_y']} target={target}", flush=True)

    iterations = 0
    last_best = 0
    restart = 0
    while time.monotonic() < deadline and best_key[0] > target:
        iterations += 1
        progress = min(1.0, (time.monotonic() - started) / max(1e-9, args.seconds))
        temperature = 8.0 * (1.0 - progress) + 0.15
        critical = list(
            set(current_eval["critical_path_x"]) | set(current_eval["critical_path_y"])
        )
        move_type = rng.random()
        candidate_positive = list(positive)
        candidate_negative = list(negative)
        candidate_rotations = list(rotations)

        if move_type < 0.30:
            # Directly break one edge of a current longest path by reversing
            # that pair in the negative sequence.  Moving one endpoint just
            # across the other changes only the intervening relations.
            path = rng.choice(
                [
                    current_eval["critical_path_x"],
                    current_eval["critical_path_y"],
                ]
            )
            if len(path) >= 2:
                u, v = rng.choice(list(zip(path, path[1:])))
                source = candidate_negative.index(u)
                destination = candidate_negative.index(v)
                candidate_negative = insert_move(
                    candidate_negative, source, destination
                )
        elif move_type < 0.58:
            order = candidate_positive if rng.random() < 0.5 else candidate_negative
            module = rng.choice(critical if rng.random() < 0.85 else list(range(len(modules))))
            source = order.index(module)
            if rng.random() < 0.8:
                other = rng.choice(critical)
                destination = order.index(other)
            else:
                destination = rng.randrange(len(order))
            moved = insert_move(order, source, destination)
            if order is candidate_positive:
                candidate_positive = moved
            else:
                candidate_negative = moved
        elif move_type < 0.82:
            order = candidate_positive if rng.random() < 0.5 else candidate_negative
            first = order.index(rng.choice(critical))
            radius = rng.choice([1, 1, 2, 3, 5, 8])
            second = max(0, min(len(order) - 1, first + rng.choice([-radius, radius])))
            order[first], order[second] = order[second], order[first]
        elif move_type < 0.95:
            choices = [i for i in critical if i in rotatable]
            module = rng.choice(choices or rotatable)
            candidate_rotations[module] ^= 1
        else:
            order = candidate_positive if rng.random() < 0.5 else candidate_negative
            left = rng.randrange(len(order) - 1)
            right = min(len(order), left + rng.choice([2, 3, 4, 5]))
            order[left:right] = reversed(order[left:right])

        candidate_eval = evaluate(
            modules, candidate_positive, candidate_negative, candidate_rotations, scale
        )
        candidate_energy = energy(candidate_eval, target)
        delta = candidate_energy - current_energy
        candidate_max = max(candidate_eval["extent_x"], candidate_eval["extent_y"])
        within_record_barrier = candidate_max <= best_key[0] + args.barrier
        if within_record_barrier and (
            delta <= 0 or rng.random() < math.exp(-delta / temperature)
        ):
            positive = candidate_positive
            negative = candidate_negative
            rotations = candidate_rotations
            current_eval = candidate_eval
            current_energy = candidate_energy

        candidate_key = (
            max(candidate_eval["extent_x"], candidate_eval["extent_y"]),
            candidate_eval["extent_x"] + candidate_eval["extent_y"],
        )
        if candidate_key < best_key:
            best_key = candidate_key
            best = (
                list(candidate_positive),
                list(candidate_negative),
                list(candidate_rotations),
                candidate_eval,
            )
            last_best = iterations
            args.out.write_text(
                json.dumps(payload(candidate_eval, *best[:3], scale), indent=2) + "\n",
                encoding="utf-8",
            )
            print(
                f"best iter={iterations} extent={candidate_eval['extent_x']}x{candidate_eval['extent_y']} "
                f"paths={[i + 1 for i in candidate_eval['critical_path_x']]} / "
                f"{[i + 1 for i in candidate_eval['critical_path_y']]}",
                flush=True,
            )

        if iterations - last_best > 25000:
            restart += 1
            positive, negative, rotations, current_eval = (
                list(best[0]), list(best[1]), list(best[2]), best[3]
            )
            for _ in range(2 + restart % 7):
                candidate_positive = list(positive)
                candidate_negative = list(negative)
                order = (
                    candidate_positive
                    if rng.random() < 0.5
                    else candidate_negative
                )
                a = rng.randrange(len(order) - 1)
                b = a + 1
                order[a], order[b] = order[b], order[a]
                candidate_eval = evaluate(
                    modules,
                    candidate_positive,
                    candidate_negative,
                    rotations,
                    scale,
                )
                if (
                    max(candidate_eval["extent_x"], candidate_eval["extent_y"])
                    <= best_key[0] + args.barrier
                ):
                    positive = candidate_positive
                    negative = candidate_negative
                    current_eval = candidate_eval
            current_energy = energy(current_eval, target)
            last_best = iterations
        if args.log_every and iterations % args.log_every == 0:
            print(
                f"progress iter={iterations} best={best_key} current="
                f"{current_eval['extent_x']}x{current_eval['extent_y']}",
                flush=True,
            )

    elapsed = time.monotonic() - started
    print(
        f"done iterations={iterations} seconds={elapsed:.3f} best={best_key} "
        f"success={best_key[0] <= target}",
        flush=True,
    )


if __name__ == "__main__":
    main()
