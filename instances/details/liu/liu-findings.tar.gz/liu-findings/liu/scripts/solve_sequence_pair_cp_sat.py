#!/usr/bin/env python3
"""Exact CP-SAT floorpacking model using the sequence-pair representation."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from ortools.sat.python import cp_model

from analyze_structure import parse_mps, read_solution, recover


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("--side", type=int, default=1082)
    parser.add_argument("--seconds", type=float, default=900)
    parser.add_argument("--workers", type=int, default=64)
    parser.add_argument("--fixed-placement", type=Path)
    parser.add_argument("--hint-json", type=Path)
    parser.add_argument("--write-hint", type=Path)
    parser.add_argument(
        "--free-modules",
        help="comma-separated 1-based modules whose sequence relations and rotations may change",
    )
    parser.add_argument(
        "--freeze-cross-relations",
        action="store_true",
        help="with --free-modules, allow relation changes only between two free modules",
    )
    args = parser.parse_args()

    hint = json.loads(args.hint_json.read_text(encoding="utf-8")) if args.hint_json else None
    free_modules = None
    if args.free_modules:
        if hint is None:
            raise ValueError("--free-modules requires --hint-json")
        free_modules = {int(value) - 1 for value in args.free_modules.split(",")}

    structure = recover(parse_mps(args.mps))
    modules = structure["modules"]
    if free_modules is not None:
        invalid_free = sorted(
            index + 1 for index in free_modules if not 0 <= index < len(modules)
        )
        if invalid_free:
            raise ValueError(f"invalid module numbers in --free-modules: {invalid_free}")
    scale = math.gcd(
        *(int(value) for module in modules for value in (module["width"], module["height"]))
    )
    if args.side % scale:
        raise ValueError("side must be divisible by the dimension gcd")
    side = args.side // scale
    count = len(modules)

    model = cp_model.CpModel()
    xs = [model.new_int_var(0, side, f"x_{i + 1}") for i in range(count)]
    ys = [model.new_int_var(0, side, f"y_{i + 1}") for i in range(count)]
    rotations: list[cp_model.IntVar | None] = []
    x_intervals = []
    y_intervals = []
    x_demands: list[int] = []
    y_demands: list[int] = []

    for i, module in enumerate(modules):
        width = int(module["width"]) // scale
        height = int(module["height"]) // scale
        if width == height:
            rotations.append(None)
            model.add(xs[i] + width <= side)
            model.add(ys[i] + height <= side)
            x_intervals.append(model.new_fixed_size_interval_var(xs[i], width, f"ix_{i + 1}"))
            y_intervals.append(model.new_fixed_size_interval_var(ys[i], height, f"iy_{i + 1}"))
            x_demands.append(height)
            y_demands.append(width)
        else:
            rotation = model.new_bool_var(f"r_{i + 1}")
            rotations.append(rotation)
            if free_modules is not None and i not in free_modules:
                model.add(rotation == int(hint["rotation"][i]))
            model.add(xs[i] + width <= side).only_enforce_if(rotation.negated())
            model.add(ys[i] + height <= side).only_enforce_if(rotation.negated())
            model.add(xs[i] + height <= side).only_enforce_if(rotation)
            model.add(ys[i] + width <= side).only_enforce_if(rotation)
            x_intervals.extend(
                [
                    model.new_optional_fixed_size_interval_var(xs[i], width, rotation.negated(), f"ix_{i + 1}_0"),
                    model.new_optional_fixed_size_interval_var(xs[i], height, rotation, f"ix_{i + 1}_1"),
                ]
            )
            y_intervals.extend(
                [
                    model.new_optional_fixed_size_interval_var(ys[i], height, rotation.negated(), f"iy_{i + 1}_0"),
                    model.new_optional_fixed_size_interval_var(ys[i], width, rotation, f"iy_{i + 1}_1"),
                ]
            )
            x_demands.extend([height, width])
            y_demands.extend([width, height])

    positive_rank = [model.new_int_var(0, count - 1, f"positive_rank_{i + 1}") for i in range(count)]
    negative_rank = [model.new_int_var(0, count - 1, f"negative_rank_{i + 1}") for i in range(count)]
    model.add_all_different(positive_rank)
    model.add_all_different(negative_rank)

    for i in range(count):
        width_i = int(modules[i]["width"]) // scale
        height_i = int(modules[i]["height"]) // scale
        delta_width_i = int(modules[i]["width_delta"]) // scale
        delta_height_i = int(modules[i]["height_delta"]) // scale
        rotation_i = rotations[i] if rotations[i] is not None else 0
        for j in range(i + 1, count):
            width_j = int(modules[j]["width"]) // scale
            height_j = int(modules[j]["height"]) // scale
            delta_width_j = int(modules[j]["width_delta"]) // scale
            delta_height_j = int(modules[j]["height_delta"]) // scale
            rotation_j = rotations[j] if rotations[j] is not None else 0
            positive_before = model.new_bool_var(f"positive_{i + 1}_{j + 1}")
            negative_before = model.new_bool_var(f"negative_{i + 1}_{j + 1}")
            model.add(positive_rank[i] < positive_rank[j]).only_enforce_if(positive_before)
            model.add(positive_rank[i] > positive_rank[j]).only_enforce_if(positive_before.negated())
            model.add(negative_rank[i] < negative_rank[j]).only_enforce_if(negative_before)
            model.add(negative_rank[i] > negative_rank[j]).only_enforce_if(negative_before.negated())
            if free_modules is not None:
                frozen_relation = (
                    i not in free_modules or j not in free_modules
                    if args.freeze_cross_relations
                    else i not in free_modules and j not in free_modules
                )
                if frozen_relation:
                    model.add(
                        positive_before
                        == int(hint["positive_rank"][i] < hint["positive_rank"][j])
                    )
                    model.add(
                        negative_before
                        == int(hint["negative_rank"][i] < hint["negative_rank"][j])
                    )

            # Same order in both sequences gives horizontal precedence; opposite
            # orders give vertical precedence.  Every orthogonal packing has such
            # a sequence-pair representation.
            model.add(xs[i] + width_i + delta_width_i * rotation_i <= xs[j]).only_enforce_if(
                [positive_before, negative_before]
            )
            model.add(xs[j] + width_j + delta_width_j * rotation_j <= xs[i]).only_enforce_if(
                [positive_before.negated(), negative_before.negated()]
            )
            model.add(ys[i] + height_i + delta_height_i * rotation_i <= ys[j]).only_enforce_if(
                [positive_before, negative_before.negated()]
            )
            model.add(ys[j] + height_j + delta_height_j * rotation_j <= ys[i]).only_enforce_if(
                [positive_before.negated(), negative_before]
            )

    # Redundant global constraints add energetic and sweep propagation.
    model.add_no_overlap_2d(x_intervals, y_intervals)
    model.add_cumulative(x_intervals, x_demands, side)
    model.add_cumulative(y_intervals, y_demands, side)

    if args.fixed_placement:
        fixed = read_solution(args.fixed_placement)
        for i, module in enumerate(modules):
            model.add(xs[i] == int(fixed[str(module["x"])].to_integral_value()) // scale)
            model.add(ys[i] == int(fixed[str(module["y"])].to_integral_value()) // scale)
            if rotations[i] is not None:
                model.add(rotations[i] == int(fixed[str(module["rotation"])]))
    else:
        anchor = max(range(count), key=lambda i: int(modules[i]["area"]))
        anchor_width = int(modules[anchor]["width"]) // scale
        anchor_height = int(modules[anchor]["height"]) // scale
        if rotations[anchor] is not None:
            model.add(rotations[anchor] == 0)
        model.add(2 * xs[anchor] + anchor_width <= side)
        model.add(2 * ys[anchor] + anchor_height <= side)

    if args.hint_json:
        for variable, value in zip(xs, hint["x"]):
            model.add_hint(variable, min(side, max(0, int(value))))
        for variable, value in zip(ys, hint["y"]):
            model.add_hint(variable, min(side, max(0, int(value))))
        for variable, value in zip(rotations, hint["rotation"]):
            if variable is not None:
                model.add_hint(variable, int(value))
        for variable, value in zip(positive_rank, hint["positive_rank"]):
            model.add_hint(variable, int(value))
        for variable, value in zip(negative_rank, hint["negative_rank"]):
            model.add_hint(variable, int(value))

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = args.seconds
    solver.parameters.num_search_workers = args.workers
    solver.parameters.log_search_progress = True
    solver.parameters.symmetry_level = 3
    solver.parameters.use_energetic_reasoning_in_no_overlap_2d = True
    solver.parameters.use_area_energetic_reasoning_in_no_overlap_2d = True
    solver.parameters.use_timetabling_in_no_overlap_2d = True
    solver.parameters.use_try_edge_reasoning_in_no_overlap_2d = True
    if args.hint_json:
        solver.parameters.repair_hint = True
        solver.parameters.hint_conflict_limit = 100000
    if free_modules is not None:
        print(
            "free_modules="
            + ",".join(str(i + 1) for i in sorted(free_modules))
            + f" freeze_cross_relations={args.freeze_cross_relations}"
        )
    status = solver.solve(model)
    print(f"status={solver.status_name(status)}")
    print(f"wall_time={solver.wall_time:.6f} conflicts={solver.num_conflicts} branches={solver.num_branches}")
    if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        payload = {
            "side": side,
            "scale": scale,
            "x": [solver.value(variable) for variable in xs],
            "y": [solver.value(variable) for variable in ys],
            "rotation": [solver.value(variable) if variable is not None else 0 for variable in rotations],
            "positive_rank": [solver.value(variable) for variable in positive_rank],
            "negative_rank": [solver.value(variable) for variable in negative_rank],
        }
        if args.write_hint:
            args.write_hint.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        for i, module in enumerate(modules):
            rotation = int(solver.value(rotations[i])) if rotations[i] is not None else 0
            width = int(module["width"] if rotation == 0 else module["height"])
            height = int(module["height"] if rotation == 0 else module["width"])
            print(
                f"module={i + 1} x={scale * solver.value(xs[i])} y={scale * solver.value(ys[i])} "
                f"width={width} height={height} rotation={rotation}"
            )


if __name__ == "__main__":
    main()
