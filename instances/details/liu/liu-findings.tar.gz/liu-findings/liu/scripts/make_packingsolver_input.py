#!/usr/bin/env python3
"""Export the recovered rectangles to PackingSolver CSV input files."""

from __future__ import annotations

import argparse
import csv
import math
from collections import Counter
from pathlib import Path

from analyze_structure import parse_mps, recover


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("output_directory", type=Path)
    parser.add_argument("--side", type=int, default=1082)
    args = parser.parse_args()

    structure = recover(parse_mps(args.mps))
    modules = structure["modules"]
    scale = math.gcd(
        *(int(value) for module in modules for value in (module["width"], module["height"]))
    )
    if args.side % scale:
        raise ValueError("side must be divisible by the dimension gcd")
    dimensions = Counter(
        tuple(sorted((int(module["width"]) // scale, int(module["height"]) // scale)))
        for module in modules
    )
    args.output_directory.mkdir(parents=True, exist_ok=True)

    with (args.output_directory / "items.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["WIDTH", "HEIGHT", "COPIES", "PROFIT", "ORIENTED"])
        for (width, height), copies in sorted(dimensions.items()):
            writer.writerow([width, height, copies, width * height, 0])
    with (args.output_directory / "bins.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["WIDTH", "HEIGHT", "COPIES", "COPIES_MIN"])
        writer.writerow([args.side // scale, args.side // scale, 1, 1])
    with (args.output_directory / "parameters.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["NAME", "VALUE"])
        writer.writerow(["objective", "knapsack"])
    print(f"wrote PackingSolver input for side={args.side}, scale={scale}")


if __name__ == "__main__":
    main()
