#!/usr/bin/env python3
"""Solve liu as an exact integer-coordinate 2-D packing problem with CP-SAT."""

from __future__ import annotations

import argparse
import json
import math
from collections import defaultdict
from pathlib import Path

from ortools.sat.python import cp_model

from analyze_structure import parse_mps, recover


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("--side", type=int, default=1082)
    parser.add_argument("--seconds", type=float, default=1800)
    parser.add_argument("--workers", type=int, default=48)
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--combined-no-overlap", action="store_true")
    parser.add_argument("--solution", type=Path)
    parser.add_argument("--hint-json", type=Path)
    parser.add_argument("--fix-hint-rotations", action="store_true")
    parser.add_argument(
        "--free-rotations",
        help=(
            "comma-separated 1-based modules whose rotations remain free when "
            "--fix-hint-rotations is used"
        ),
    )
    args = parser.parse_args()
    free_rotations = (
        {int(value) - 1 for value in args.free_rotations.split(",")}
        if args.free_rotations
        else set()
    )
    if args.fix_hint_rotations and not args.hint_json:
        raise ValueError("--fix-hint-rotations requires --hint-json")
    if free_rotations and not args.fix_hint_rotations:
        raise ValueError("--free-rotations requires --fix-hint-rotations")

    structure = recover(parse_mps(args.mps))
    modules = structure["modules"]
    invalid_free = sorted(
        index + 1 for index in free_rotations if not 0 <= index < len(modules)
    )
    if invalid_free:
        raise ValueError(f"invalid module numbers in --free-rotations: {invalid_free}")
    scale = math.gcd(
        *(int(value) for module in modules for value in (module["width"], module["height"]))
    )
    if args.side % scale:
        raise ValueError(f"side {args.side} is not divisible by dimension gcd {scale}")
    side = args.side // scale

    model = cp_model.CpModel()
    xs: list[cp_model.IntVar] = []
    ys: list[cp_model.IntVar] = []
    rotations: list[cp_model.IntVar | None] = []
    x_intervals = []
    y_intervals = []
    x_demands: list[int] = []
    y_demands: list[int] = []

    for index, module in enumerate(modules):
        width = int(module["width"]) // scale
        height = int(module["height"]) // scale
        x = model.new_int_var(0, side, f"x_{index + 1}")
        y = model.new_int_var(0, side, f"y_{index + 1}")
        xs.append(x)
        ys.append(y)
        if width == height:
            rotations.append(None)
            model.add(x + width <= side)
            model.add(y + height <= side)
            x_intervals.append(model.new_fixed_size_interval_var(x, width, f"ix_{index + 1}"))
            y_intervals.append(model.new_fixed_size_interval_var(y, height, f"iy_{index + 1}"))
            x_demands.append(height)
            y_demands.append(width)
        else:
            rotation = model.new_bool_var(f"r_{index + 1}")
            rotations.append(rotation)
            model.add(x + width <= side).only_enforce_if(rotation.negated())
            model.add(y + height <= side).only_enforce_if(rotation.negated())
            model.add(x + height <= side).only_enforce_if(rotation)
            model.add(y + width <= side).only_enforce_if(rotation)
            x_intervals.extend(
                [
                    model.new_optional_fixed_size_interval_var(
                        x, width, rotation.negated(), f"ix_{index + 1}_0"
                    ),
                    model.new_optional_fixed_size_interval_var(
                        x, height, rotation, f"ix_{index + 1}_1"
                    ),
                ]
            )
            y_intervals.extend(
                [
                    model.new_optional_fixed_size_interval_var(
                        y, height, rotation.negated(), f"iy_{index + 1}_0"
                    ),
                    model.new_optional_fixed_size_interval_var(
                        y, width, rotation, f"iy_{index + 1}_1"
                    ),
                ]
            )
            x_demands.extend([height, width])
            y_demands.extend([width, height])

    model.add_no_overlap_2d(x_intervals, y_intervals)
    # Orthogonal sweep constraints expose the nearly full area to propagation.
    model.add_cumulative(x_intervals, x_demands, side)
    model.add_cumulative(y_intervals, y_demands, side)

    hint = None
    if args.hint_json:
        hint = json.loads(args.hint_json.read_text(encoding="utf-8"))
        for variable, value in zip(xs, hint["x"]):
            model.add_hint(variable, min(side, max(0, int(value))))
        for variable, value in zip(ys, hint["y"]):
            model.add_hint(variable, min(side, max(0, int(value))))
        for index, variable in enumerate(rotations):
            if variable is not None:
                value = int(hint["rotation"][index])
                model.add_hint(variable, value)
                if args.fix_hint_rotations and index not in free_rotations:
                    model.add(variable == value)

    # The square container admits a 90-degree rotation and two reflections.
    # Anchor the unique largest-area rectangle to remove those four symmetries.
    anchor = max(range(len(modules)), key=lambda i: int(modules[i]["area"]))
    anchor_width = int(modules[anchor]["width"]) // scale
    anchor_height = int(modules[anchor]["height"]) // scale
    if rotations[anchor] is not None:
        model.add(rotations[anchor] == 0)
    model.add(2 * xs[anchor] + anchor_width <= side)
    model.add(2 * ys[anchor] + anchor_height <= side)

    # Rectangles with the same unordered dimensions are interchangeable while
    # rotations are free. Once named rotations are fixed, differently oriented
    # copies are no longer label-interchangeable, so omit this symmetry break.
    if not args.fix_hint_rotations:
        equal_groups: dict[tuple[int, int], list[int]] = defaultdict(list)
        for index, module in enumerate(modules):
            dimensions = sorted((int(module["width"]), int(module["height"])))
            equal_groups[tuple(dimensions)].append(index)
        for group in equal_groups.values():
            for left, right in zip(group, group[1:]):
                model.add(
                    xs[left] * (side + 1) + ys[left]
                    <= xs[right] * (side + 1) + ys[right]
                )

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = args.seconds
    solver.parameters.num_search_workers = args.workers
    solver.parameters.random_seed = args.seed
    solver.parameters.log_search_progress = True
    solver.parameters.symmetry_level = 3
    solver.parameters.use_energetic_reasoning_in_no_overlap_2d = True
    solver.parameters.use_area_energetic_reasoning_in_no_overlap_2d = True
    solver.parameters.use_timetabling_in_no_overlap_2d = True
    solver.parameters.use_try_edge_reasoning_in_no_overlap_2d = True
    solver.parameters.use_combined_no_overlap = args.combined_no_overlap
    if hint is not None:
        solver.parameters.repair_hint = True
        solver.parameters.hint_conflict_limit = 100000
    if args.fix_hint_rotations:
        print(
            "fixed_hint_rotations=true free_rotations="
            + ",".join(str(index + 1) for index in sorted(free_rotations))
        )
    status = solver.solve(model)
    print(f"status={solver.status_name(status)}")
    print(f"wall_time={solver.wall_time:.6f} conflicts={solver.num_conflicts} branches={solver.num_branches}")

    if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        lines = [f"# exact no-overlap placement in a {args.side} x {args.side} square"]
        max_x = max_y = 0
        for index, module in enumerate(modules):
            rotation = int(solver.value(rotations[index])) if rotations[index] is not None else 0
            width = int(module["width"] if rotation == 0 else module["height"])
            height = int(module["height"] if rotation == 0 else module["width"])
            x = scale * solver.value(xs[index])
            y = scale * solver.value(ys[index])
            max_x = max(max_x, x + width)
            max_y = max(max_y, y + height)
            lines.append(
                f"module={index + 1} x={x} y={y} width={width} height={height} rotation={rotation}"
            )
        lines.append(f"max_x={max_x} max_y={max_y}")
        result = "\n".join(lines) + "\n"
        print(result, end="")
        if args.solution:
            args.solution.write_text(result, encoding="utf-8")


if __name__ == "__main__":
    main()
