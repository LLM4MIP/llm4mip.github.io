#!/usr/bin/env python3
"""Enumerate the complete one-move sequence-pair neighborhood of a Liu layout."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from analyze_structure import parse_mps, recover
from search_sequence_pair_ils import evaluate, insert_move, ranks_to_order


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("hint", type=Path)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    modules = recover(parse_mps(args.mps))["modules"]
    hint = json.loads(args.hint.read_text(encoding="utf-8"))
    scale = math.gcd(
        *(int(value) for m in modules for value in (m["width"], m["height"]))
    )
    positive = ranks_to_order(hint["positive_rank"])
    negative = ranks_to_order(hint["negative_rank"])
    rotations = [int(value) for value in hint["rotation"]]
    candidates = []

    def record(kind, detail, p, n, r):
        value = evaluate(modules, p, n, r, scale)
        candidates.append(
            {
                "kind": kind,
                "detail": detail,
                "extent_x": value["extent_x"],
                "extent_y": value["extent_y"],
                "maximum": max(value["extent_x"], value["extent_y"]),
                "sum": value["extent_x"] + value["extent_y"],
            }
        )

    count = len(modules)
    for label, original in (("positive_insert", positive), ("negative_insert", negative)):
        for source in range(count):
            for destination in range(count):
                if source == destination:
                    continue
                moved = insert_move(original, source, destination)
                record(
                    label,
                    {"module": original[source] + 1, "from": source, "to": destination},
                    moved if label.startswith("positive") else positive,
                    moved if label.startswith("negative") else negative,
                    rotations,
                )
    for module in range(count):
        if modules[module]["width"] == modules[module]["height"]:
            continue
        changed = list(rotations)
        changed[module] ^= 1
        record("rotation", {"module": module + 1}, positive, negative, changed)

    candidates.sort(key=lambda item: (item["maximum"], item["sum"], item["kind"]))
    histogram = {}
    for item in candidates:
        histogram[str(item["maximum"])] = histogram.get(str(item["maximum"]), 0) + 1
    report = {
        "moves": len(candidates),
        "best_maximum": candidates[0]["maximum"],
        "best_sum": candidates[0]["sum"],
        "count_at_most_545": sum(item["maximum"] <= 545 for item in candidates),
        "count_at_most_550": sum(item["maximum"] <= 550 for item in candidates),
        "histogram": histogram,
        "best_50": candidates[:50],
    }
    text = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(text, encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()
