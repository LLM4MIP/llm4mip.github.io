#!/usr/bin/env python3
"""Create a fixed-side floorpacking model with native indicator constraints."""

from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path

from analyze_structure import parse_mps, recover


def linear(terms: list[tuple[int, str]]) -> str:
    pieces: list[str] = []
    for coefficient, variable in terms:
        if coefficient == 0:
            continue
        magnitude = abs(coefficient)
        body = variable if magnitude == 1 else f"{magnitude} {variable}"
        if not pieces:
            pieces.append(body if coefficient > 0 else f"- {body}")
        else:
            pieces.append((" + " if coefficient > 0 else " - ") + body)
    return "".join(pieces) if pieces else "0"


def extent_terms(module: dict[str, object], axis: str, sign: int = 1) -> list[tuple[int, str]]:
    coordinate = str(module[axis])
    rotation = module["rotation"]
    delta = int(module["width_delta"] if axis == "x" else module["height_delta"])
    result = [(sign, coordinate)]
    if rotation and delta:
        result.append((sign * delta, str(rotation)))
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("output_lp", type=Path)
    parser.add_argument("--side", type=int, default=1082)
    parser.add_argument(
        "--fix-rotations-from",
        type=Path,
        help="sequence-pair JSON whose module rotations are fixed in the LP",
    )
    args = parser.parse_args()

    structure = recover(parse_mps(args.mps))
    modules = structure["modules"]
    rows: list[str] = []
    relation_binaries: list[str] = []

    for index, module in enumerate(modules, start=1):
        width = int(module["width"])
        height = int(module["height"])
        rows.append(
            f" bx_{index}: {linear(extent_terms(module, 'x'))} <= {args.side - width}"
        )
        rows.append(
            f" by_{index}: {linear(extent_terms(module, 'y'))} <= {args.side - height}"
        )

    if args.fix_rotations_from:
        hint = json.loads(args.fix_rotations_from.read_text(encoding="utf-8"))
        if len(hint["rotation"]) != len(modules):
            raise ValueError("rotation hint/module count mismatch")
        for index, module in enumerate(modules):
            if module["rotation"]:
                rows.append(
                    f" fix_rotation_{index + 1}: {module['rotation']} = "
                    f"{int(hint['rotation'][index])}"
                )

    directions = ("left", "right", "below", "above")
    for i, first in enumerate(modules):
        for j in range(i + 1, len(modules)):
            second = modules[j]
            names = [f"p_{i + 1}_{j + 1}_{direction}" for direction in directions]
            relation_binaries.extend(names)
            rows.append(f" choose_{i + 1}_{j + 1}: " + " + ".join(names) + " = 1")
            cases = [
                (
                    names[0],
                    extent_terms(first, "x") + [(-1, str(second["x"]))],
                    -int(first["width"]),
                ),
                (
                    names[1],
                    extent_terms(second, "x") + [(-1, str(first["x"]))],
                    -int(second["width"]),
                ),
                (
                    names[2],
                    extent_terms(first, "y") + [(-1, str(second["y"]))],
                    -int(first["height"]),
                ),
                (
                    names[3],
                    extent_terms(second, "y") + [(-1, str(first["y"]))],
                    -int(second["height"]),
                ),
            ]
            for name, terms, rhs in cases:
                rows.append(f" sep_{name}: {name} = 1 -> {linear(terms)} <= {rhs}")

    # Square-container rotations/reflections let us anchor the unique largest rectangle.
    anchor_index = max(range(len(modules)), key=lambda index: int(modules[index]["area"]))
    anchor = modules[anchor_index]
    if anchor["rotation"]:
        rows.append(f" anchor_rotation: {anchor['rotation']} = 0")
    rows.append(
        f" anchor_x: 2 {anchor['x']} <= {args.side - int(anchor['width'])}"
    )
    rows.append(
        f" anchor_y: 2 {anchor['y']} <= {args.side - int(anchor['height'])}"
    )

    # Interchangeable modules can be ordered lexicographically while their
    # rotations remain free. If named rotations are fixed, two otherwise equal
    # modules may have different oriented shapes and this symmetry is invalid.
    if not args.fix_rotations_from:
        equal_groups: dict[tuple[int, int], list[dict[str, object]]] = defaultdict(list)
        for module in modules:
            dimensions = tuple(sorted((int(module["width"]), int(module["height"]))))
            equal_groups[dimensions].append(module)
        radix = args.side + 1
        order_index = 0
        for group in equal_groups.values():
            for first, second in zip(group, group[1:]):
                order_index += 1
                rows.append(
                    f" order_equal_{order_index}: "
                    + linear(
                        [
                            (radix, str(first["x"])),
                            (1, str(first["y"])),
                            (-radix, str(second["x"])),
                            (-1, str(second["y"])),
                        ]
                    )
                    + " <= 0"
                )

    orientation_binaries = sorted(
        {str(module["rotation"]) for module in modules if module["rotation"]},
        key=lambda name: int(name[1:]),
    )
    lines = [
        "\\ Exact fixed-side floorpacking reformulation of liu",
        "Minimize",
        f" objective: 0 {modules[0]['x']}",
        "Subject To",
        *rows,
        "Binaries",
        *[f" {name}" for name in orientation_binaries + relation_binaries],
        "End",
    ]
    args.output_lp.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(
        f"wrote {args.output_lp}: side={args.side}, modules={len(modules)}, "
        f"orientation binaries={len(orientation_binaries)}, relation binaries={len(relation_binaries)}, "
        f"rotations_fixed={bool(args.fix_rotations_from)}"
    )


if __name__ == "__main__":
    main()
