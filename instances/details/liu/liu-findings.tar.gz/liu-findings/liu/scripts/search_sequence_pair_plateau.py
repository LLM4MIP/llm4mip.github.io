#!/usr/bin/env python3
"""Solver-free breadth search on the 1082 sequence-pair plateau."""

from __future__ import annotations

import argparse
from collections import deque
import json
import math
import time
from pathlib import Path

from analyze_structure import parse_mps, recover
from search_sequence_pair_ils import evaluate, insert_move, payload, ranks_to_order


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("hint", type=Path)
    parser.add_argument("--target", type=int, default=1080)
    parser.add_argument("--seconds", type=float, default=600.0)
    parser.add_argument("--max-states", type=int, default=50000)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()

    modules = recover(parse_mps(args.mps))["modules"]
    hint = json.loads(args.hint.read_text(encoding="utf-8"))
    scale = math.gcd(
        *(int(value) for m in modules for value in (m["width"], m["height"]))
    )
    target = args.target // scale
    positive = tuple(ranks_to_order(hint["positive_rank"]))
    negative = tuple(ranks_to_order(hint["negative_rank"]))
    rotations = tuple(int(value) for value in hint["rotation"])
    initial = evaluate(modules, positive, negative, rotations, scale)
    ceiling = max(initial["extent_x"], initial["extent_y"])
    queue = deque([(positive, negative, rotations, 0)])
    visited = {(positive, negative, rotations)}
    best_state = (positive, negative, rotations, initial)
    best_key = (ceiling, initial["extent_x"] + initial["extent_y"])
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(
        json.dumps(payload(initial, positive, negative, rotations, scale), indent=2) + "\n",
        encoding="utf-8",
    )
    started = time.monotonic()
    expanded = 0
    generated = 0
    deepest = 0
    while (
        queue
        and len(visited) < args.max_states
        and time.monotonic() - started < args.seconds
        and best_key[0] > target
    ):
        p, n, r, depth = queue.popleft()
        evaluation = evaluate(modules, p, n, r, scale)
        deepest = max(deepest, depth)
        critical = sorted(
            set(evaluation["critical_path_x"]) | set(evaluation["critical_path_y"])
        )
        expanded += 1

        candidates = []
        for label, order in (("p", p), ("n", n)):
            for module in critical:
                source = order.index(module)
                for destination in range(len(order)):
                    if source == destination:
                        continue
                    moved = tuple(insert_move(order, source, destination))
                    candidates.append((moved if label == "p" else p, moved if label == "n" else n, r))
        for module in critical:
            if modules[module]["width"] != modules[module]["height"]:
                changed = list(r)
                changed[module] ^= 1
                candidates.append((p, n, tuple(changed)))

        for candidate in candidates:
            if candidate in visited:
                continue
            generated += 1
            candidate_eval = evaluate(modules, *candidate, scale)
            candidate_key = (
                max(candidate_eval["extent_x"], candidate_eval["extent_y"]),
                candidate_eval["extent_x"] + candidate_eval["extent_y"],
            )
            if candidate_key < best_key:
                best_key = candidate_key
                best_state = (*candidate, candidate_eval)
                args.out.write_text(
                    json.dumps(payload(candidate_eval, *candidate, scale), indent=2) + "\n",
                    encoding="utf-8",
                )
                print(
                    f"best expanded={expanded} depth={depth + 1} key={best_key} "
                    f"visited={len(visited)}",
                    flush=True,
                )
                if best_key[0] <= target:
                    break
            if candidate_key[0] <= ceiling:
                visited.add(candidate)
                queue.append((*candidate, depth + 1))
                if len(visited) >= args.max_states:
                    break
        if expanded % 100 == 0:
            print(
                f"progress expanded={expanded} generated={generated} visited={len(visited)} "
                f"queue={len(queue)} depth={depth} best={best_key}",
                flush=True,
            )

    elapsed = time.monotonic() - started
    print(
        f"done seconds={elapsed:.3f} expanded={expanded} generated={generated} "
        f"visited={len(visited)} queue={len(queue)} deepest={deepest} "
        f"best={best_key} success={best_key[0] <= target}",
        flush=True,
    )


if __name__ == "__main__":
    main()
