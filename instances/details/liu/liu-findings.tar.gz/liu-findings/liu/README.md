# `liu`

## Result

The instance is a 33-rectangle rotatable floorpacking problem.  This study
found a new square side **1082** solution.  Translation back to all 1,156
original MPS variables passes all 2,178 rows, all bounds, and all integrality
conditions in 80-digit Decimal arithmetic.  The exact solution is
[`cpsat-sequence-pair-1082.sol`](solutions/cpsat-sequence-pair-1082.sol), and
its numbered layout is [`cpsat-sequence-pair-1082.svg`](artifacts/cpsat-sequence-pair-1082.svg).
Gurobi 13.0.1 and COPT 8.0.4 independently accepted the solution as an initial
MIP solution with objective 1082 under `1e-9` feasibility and integrality
tolerances; both reported zero solution violations.  The checker transcript is
[`exact-check-1082.txt`](artifacts/exact-check-1082.txt).

Global optimality remains open.  This study also proves that an optimal side
length can be chosen **even**.  Together with the area bound
`ceil(sqrt(1149192)) = 1073`, this gives the rigorous global lower bound
**1074**.  After finding 1082, the next exact improvement target is therefore
**1080**; there are no possible exact objectives strictly between them.

The MIPLIB page currently displays `1083.984782*`, but its own exact objective
column is 1084 and its maximum constraint violation is `0.007962`.  Independent
recomputation finds 19 violated rows above `1e-6`; this file is retained only as
a numerical reference, not as a strict improvement.

## Input and provenance

- Compressed MPS SHA-256: `50599CBD1C0EA27D88E97FB3A53F1AAE3D240A095C8C7BAAA1F1408290C8F85F`
- Strict solution SHA-256: `E78FA2EC7882AFCDEC5A738C4D6C0AC0AA72F47896EBD717D63DC80677C04FC4`
- Current numerical solution SHA-256: `A92206ECBAA4B6B8EFD7AC24EDDF7AB48D4E5AD003E65627CEE2DE58B4D09553`
- New strict 1082 solution SHA-256: `06461CC352FB5267A9B01DCD1FD281DFA56324FA890DCA4D2C0993AEE2503AF3`
- MIPLIB metadata and solutions: [`liu` instance page](https://miplib.zib.de/instance_details_liu.html)
- Sequence-pair reformulation: Murata et al., [*VLSI module placement based on rectangle-packing by the sequence-pair*](https://doi.org/10.1109/43.552084)

## Recovered structure

| Component | Count | Role |
|---|---:|---|
| continuous variables | 67 | square side plus 66 coordinates |
| rotation binaries | 33 | one per rectangle; 2 are inactive for squares |
| pair-code binaries | 1,056 | two bits for each of 528 rectangle pairs |
| pairwise rows | 2,112 | four non-overlap alternatives per pair |
| boundary rows | 66 | two container bounds per rectangle |

The single objective variable `x1` is the side length.  The remaining
continuous variables are lower-left coordinates.  Each pair code means:

```text
(0,0)  i left of j       (1,0)  j left of i
(0,1)  i below j         (1,1)  j below i
```

All rectangle dimensions are even and their greatest common divisor is 2.  The
total area is `1,149,192`, versus `1,170,724` for the new 1082 square; unused
area is `21,532`.

The 2026-09-07 follow-up attacked target 1080 through critical-path analysis,
finite sequence-pair neighborhoods, an orientation-aware lower-bound filter,
native two-dimensional propagation, and a fixed-orientation indicator model.
It found no 1080 layout, but only explicitly restricted neighborhoods were
closed as infeasible.  The global interval remains **[1074, 1082]**.  Full
artifacts and evidence boundaries are in
[`experiments/critical-geometry-20260907/`](experiments/critical-geometry-20260907/).

## Even-lattice reduction

Fix all binaries.  Every remaining row is a difference constraint in the
coordinates and `x1`; its matrix is a node-arc incidence matrix.  All right-hand
sides are even because the dimensions and the original `M=8398` are even.
After scaling the continuous variables by 2, the right-hand side is integral
and the matrix is totally unimodular.  Therefore an objective-minimizing
extreme point for every fixed binary pattern has integral scaled coordinates,
so a global optimum can be chosen with an even side length.

Consequently there is no exact objective strictly between adjacent even target
values.  This argument first reduced improvement over the official 1084 to the
1082 feasibility target; the sequence-pair model found that target.  The same
argument now reduces the next improvement to side 1080 and rounds the area
lower bound from 1073 to 1074.
The derivation and exact checker output are summarized in
[`artifacts/structure-summary.txt`](artifacts/structure-summary.txt).

## Reformulations

1. **Tight big-M.**  Under `x1 <= 1082`, every rectangle extent is at most 1082
   and every other coordinate is nonnegative, so 1082 is a valid replacement
   for 8398.  [`liu_target1082_tightM.lp`](artifacts/liu_target1082_tightM.lp)
   applies this change without altering the two-bit pair encoding.
2. **Native indicators.**  The exact fixed-side model chooses one of four
   directions for each pair and activates the corresponding separation with an
   indicator.  It removes the weak two-bit big-M relaxation; see
   [`liu_target1082_indicator.lp`](artifacts/liu_target1082_indicator.lp).
3. **Global no-overlap CP-SAT.**  Coordinates and dimensions are divided by 2,
   yielding a 541 by 541 target with 33 optional-orientation rectangles.
4. **Sequence pair.**  Two all-different rank vectors encode the four spatial
   relations.  This explicitly enforces the transitivity absent from the
   original pair codes.  The official 1084 layout was converted to a valid
   sequence pair and used as a repair hint.  CP-SAT found side 1082 after
   `460.253` seconds; the placement was translated back to the original pair
   codes and checked exactly.

## Experiment summary

| Method | Threads | Limit | Result |
|---|---:|---:|---|
| Gurobi 13.0.1, original MPS with strict start | 32 | interrupted after about 250 s | incumbent 1084; best bound 614 |
| COPT 8.0.4, original MPS with strict start | 32 | interrupted after about 250 s | incumbent 1084; best bound 560 |
| Gurobi, tight-M 1082 target | 32 | interrupted after about 186 s | no feasible point; tree not closed |
| COPT, tight-M 1082 target | 32 | interrupted after about 189 s | no feasible point; tree not closed |
| Gurobi, indicator 1082 target | 32 | 900 s | no feasible point; time limit |
| COPT, indicator 1082 target | 32 | 900 s | no feasible point; time limit |
| Gurobi, indicator target with official binary start | 32 | 300 s | no feasible point; time limit |
| CP-SAT, global no-overlap, side 1084 | 16 | 120 s | unknown; the separate official solution remains exactly verified |
| CP-SAT, sequence pair with 1084 repair hint, side 1082 | 64 | 900 s | **feasible at 460.253 s**; 314,800 conflicts and 1,755,079 branches |
| Gurobi, indicator 1080 target with 1082 binary start | 64 | 900 s | no feasible point; 3,395,068 nodes; time limit |
| CP-SAT, sequence pair with 1082 repair hint, side 1080 | 96 | 900 s | `UNKNOWN`; 677,817 conflicts and 3,849,381 branches |
| dual-feasible-function search | 1 | 657,721 function pairs | strongest ratio `0.981607962`; no contradiction beyond area |
| complete one-move sequence-pair enumeration | 1 | 2,143 moves | best remains `541 x 541`; 133 neutral moves |
| solver-free 541-plateau breadth search | 1 | 386.226 s | 50,000 states and 4,329,398 candidates; no improvement |
| repaired sequence-pair ILS, seed 97 | 1 | 600 s | 11,202,782 iterations; best remains `541 x 541` |
| orientation-aware DFF filter | 1 | 1,822,500 function pairs | every tested inequality is redundant before choosing rotations |
| CP-SAT, 12 modules free internally | 8 | presolve | **restricted subproblem infeasible** |
| CP-SAT, 12 modules free across fixed outside skeleton | 8 | 156.092 s | **restricted subproblem infeasible**; 165,034 conflicts |
| CP-SAT, 17 modules free across fixed outside skeleton | 8 | 900 s | `UNKNOWN`; 1,204,936 conflicts and 3,610,806 branches |
| CP-SAT, all coordinates free, 1082 rotations fixed | 8 | 900 s | `UNKNOWN`; 1,896,203 conflicts and 6,742,329 branches |
| CP-SAT, all coordinates and rotations free | 8 | 900 s | `UNKNOWN`; 1,180,797 conflicts and 4,411,310 branches |
| Gurobi indicator, all coordinates free, 1082 rotations fixed | 8 | 900 s | no feasible point; 4,658,131 nodes; time limit |

All COPT and CP-SAT runs on `altman` were CPU-only.  **GPU0 was not used.**
The fixed-side CP-SAT response is `OPTIMAL` because it is a satisfaction model;
the claim made here is feasibility at 1082, not optimality of the original
minimization problem.  “No feasible point” means only that a particular run
found none; it is not an infeasibility certificate.  The two 12-module
`INFEASIBLE` results close only their precisely frozen sequence-pair
neighborhoods.  Neither those local closures nor the one-move, plateau, ILS,
DFF, or time-limit results imply global infeasibility at 1080.  The final
rigorous objective interval of this study is **[1074, 1082]**.

## Reproduce

The parser, exact checker, LP generators, and dual-feasible-bound search use
only the Python standard library:

```powershell
python .\instances\liu\scripts\analyze_structure.py `
  .\instances\liu\input\liu.mps.gz `
  --solution .\instances\liu\solutions\cpsat-sequence-pair-1082.sol

python .\common\exact_mps_solution_check.py `
  .\instances\liu\input\liu.mps.gz `
  .\instances\liu\solutions\cpsat-sequence-pair-1082.sol

python .\instances\liu\scripts\make_target_lp.py `
  .\instances\liu\artifacts\liu_original.lp `
  .\instances\liu\artifacts\liu_target1082_tightM.lp --target 1082

python .\instances\liu\scripts\make_indicator_lp.py `
  .\instances\liu\input\liu.mps.gz `
  .\instances\liu\artifacts\liu_target1082_indicator.lp --side 1082

python .\instances\liu\scripts\placement_to_mps_solution.py `
  .\instances\liu\input\liu.mps.gz `
  .\instances\liu\logs\cpsat_sequence_pair_hint_target1082_15m.stdout `
  .\instances\liu\solutions\cpsat-sequence-pair-1082.sol --side 1082
```

The two CP-SAT scripts require OR-Tools.  See [`scripts/`](scripts/),
[`solutions/`](solutions/), [`artifacts/`](artifacts/), [`logs/`](logs/), and
the [full Chinese report](reports/liu-study.md).  The exact commands added for
the target-1080 follow-up are recorded in
[`experiments/critical-geometry-20260907/README.md`](experiments/critical-geometry-20260907/README.md).
