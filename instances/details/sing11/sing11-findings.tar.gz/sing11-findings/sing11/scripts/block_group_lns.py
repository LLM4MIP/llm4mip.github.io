from __future__ import annotations

import argparse
import json
import time
from collections import defaultdict
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB

from sing17_block_lns import audit_solution, parse_decomposition, parse_solution


def main() -> None:
    parser = argparse.ArgumentParser(description="Exact-gap LNS over selected groups of official DEC blocks.")
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--decomposition", type=Path, required=True)
    parser.add_argument("--groups", required=True, help="Semicolon-separated groups, each a comma-separated block list")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--log-dir", type=Path, required=True)
    parser.add_argument("--best-solution", type=Path, required=True)
    parser.add_argument("--time-per-group", type=float, default=120.0)
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--seed", type=int, default=1)
    args = parser.parse_args()

    groups = [tuple(int(value) for value in group.split(",")) for group in args.groups.split(";")]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.log_dir.mkdir(parents=True, exist_ok=True)
    args.best_solution.parent.mkdir(parents=True, exist_ok=True)

    started = time.time()
    model = gp.read(str(args.mps))
    model.Params.OutputFlag = 0
    variables = model.getVars()
    constraints_by_name = {constraint.ConstrName: constraint for constraint in model.getConstrs()}
    incumbent, solution_info = parse_solution(model, args.solution)
    initial_audit = audit_solution(model, incumbent)
    original_lb = [variable.LB for variable in variables]
    original_ub = [variable.UB for variable in variables]

    block_count, block_rows, master_names = parse_decomposition(args.decomposition)
    block_variables: dict[int, set[int]] = defaultdict(set)
    for block, row_names in block_rows.items():
        for row_name in row_names:
            row = model.getRow(constraints_by_name[row_name])
            block_variables[block].update(row.getVar(i).index for i in range(row.size()))
    invalid = sorted({block for group in groups for block in group if not 1 <= block <= block_count})
    if invalid:
        raise ValueError(f"blocks outside 1..{block_count}: {invalid}")

    master_variables: set[int] = set()
    for row_name in master_names:
        row = model.getRow(constraints_by_name[row_name])
        master_variables.update(row.getVar(i).index for i in range(row.size()))
    all_block_variables = set().union(*block_variables.values())
    master_only_variables = master_variables - all_block_variables

    for variable, value in zip(variables, incumbent):
        variable.LB = value
        variable.UB = value
        variable.Start = value
    model.update()

    best_objective = initial_audit["objective"]
    records = []
    for sequence, group in enumerate(groups, start=1):
        free_indices = set(master_only_variables)
        for block in group:
            free_indices.update(block_variables[block])
        for index in free_indices:
            variables[index].LB = original_lb[index]
            variables[index].UB = original_ub[index]
            variables[index].Start = incumbent[index]
        model.update()
        model.reset(0)
        model.Params.TimeLimit = args.time_per_group
        model.Params.Threads = args.threads
        model.Params.Seed = args.seed + sequence
        model.Params.MIPFocus = 1
        model.Params.MIPGap = 0.0
        model.Params.MIPGapAbs = 0.0
        model.Params.Cuts = 2
        model.Params.Presolve = 2
        model.Params.Symmetry = 2
        model.Params.Heuristics = 0.2
        model.Params.OutputFlag = 1
        model.Params.LogFile = str(args.log_dir / ("blocks-" + "-".join(map(str, group)) + ".log"))
        group_started = time.time()
        model.optimize()
        improved = bool(model.SolCount and model.ObjVal < best_objective - 1e-6)
        if improved:
            incumbent = [float(variable.X) for variable in variables]
            best_objective = float(model.ObjVal)
            model.write(str(args.best_solution))
        record = {
            "sequence": sequence,
            "blocks": group,
            "block_rows": sum(len(block_rows[block]) for block in group),
            "free_variables": len(free_indices),
            "status": int(model.Status),
            "status_name": {
                GRB.OPTIMAL: "OPTIMAL",
                GRB.TIME_LIMIT: "TIME_LIMIT",
                GRB.INFEASIBLE: "INFEASIBLE",
            }.get(model.Status, "OTHER"),
            "solution_count": int(model.SolCount),
            "objective": float(model.ObjVal) if model.SolCount else None,
            "best_bound": float(model.ObjBound),
            "gap": float(model.MIPGap) if model.SolCount else None,
            "nodes": float(model.NodeCount),
            "runtime": float(model.Runtime),
            "wall_runtime": time.time() - group_started,
            "improved": improved,
        }
        for index in free_indices:
            variables[index].LB = incumbent[index]
            variables[index].UB = incumbent[index]
            variables[index].Start = incumbent[index]
        model.update()
        records.append(record)

        payload = {
            "instance": model.ModelName,
            "method": "official-decomposition grouped-block LNS with zero MIP gap",
            "source_solution": solution_info,
            "initial_audit": initial_audit,
            "decomposition": {
                "blocks": block_count,
                "master_rows": len(master_names),
                "master_only_variables": len(master_only_variables),
            },
            "parameters": {
                "groups": groups,
                "time_per_group": args.time_per_group,
                "threads": args.threads,
                "seed": args.seed,
            },
            "best_objective": best_objective,
            "objective_improvement": initial_audit["objective"] - best_objective,
            "groups_completed": len(records),
            "records": records,
            "wall_runtime": time.time() - started,
        }
        args.output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")

    payload["final_audit"] = audit_solution(model, incumbent)
    payload["wall_runtime"] = time.time() - started
    args.output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
