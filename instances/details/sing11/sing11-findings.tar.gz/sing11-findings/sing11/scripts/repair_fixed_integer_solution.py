from __future__ import annotations

import argparse
import gzip
import json
import math
import time
from decimal import Decimal, getcontext
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def read_sparse_solution(path: Path) -> tuple[dict[str, float], str | None]:
    opener = gzip.open if path.suffix == ".gz" else open
    values: dict[str, float] = {}
    declared_objective: str | None = None
    with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
        for raw_line in handle:
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if parts[0].lower() in {"=obj=", "=best=", "=opt="}:
                if len(parts) >= 2:
                    declared_objective = parts[1]
                continue
            if len(parts) < 2:
                continue
            try:
                values[parts[0]] = float(parts[1])
            except ValueError:
                continue
    return values, declared_objective


def violation(lhs: Decimal, rhs: Decimal, sense: str) -> Decimal:
    if sense == "<":
        return max(lhs - rhs, Decimal(0))
    if sense == ">":
        return max(rhs - lhs, Decimal(0))
    return abs(lhs - rhs)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Fix every integer variable to a sparse incumbent (omitted=0), reoptimize continuous variables, and audit the untouched MPS."
    )
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--output-sparse-sol", type=Path, required=True)
    parser.add_argument("--output-full-sol", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--time-limit", type=float, default=300.0)
    parser.add_argument("--threads", type=int, default=2)
    args = parser.parse_args()

    for path in (
        args.output_json,
        args.output_sparse_sol,
        args.output_full_sol,
        args.log,
    ):
        path.parent.mkdir(parents=True, exist_ok=True)

    started = time.time()
    public_values, declared_objective = read_sparse_solution(args.solution)
    model = gp.read(str(args.mps))
    variables = model.getVars()
    model_names = {var.VarName for var in variables}
    unknown_solution_names = sorted(set(public_values) - model_names)

    nonintegral_public_values: list[dict[str, object]] = []
    integer_variables = 0
    continuous_variables = 0
    for var in variables:
        value = public_values.get(var.VarName, 0.0)
        var.Start = value
        if var.VType in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT):
            integer_variables += 1
            rounded = float(round(value))
            error = abs(value - rounded)
            if error > 1e-9:
                nonintegral_public_values.append(
                    {"name": var.VarName, "value": value, "distance": error}
                )
            var.LB = rounded
            var.UB = rounded
            # Convert fixed discrete variables to continuous so this is a pure LP.
            var.VType = GRB.CONTINUOUS
        else:
            continuous_variables += 1

    if nonintegral_public_values:
        raise RuntimeError(
            f"Public point has {len(nonintegral_public_values)} nonintegral values; refusing to round silently"
        )

    model.update()
    model.Params.LogFile = str(args.log)
    model.Params.TimeLimit = args.time_limit
    model.Params.Threads = args.threads
    model.Params.Presolve = 2
    model.Params.NumericFocus = 3
    model.Params.FeasibilityTol = 1e-9
    model.Params.OptimalityTol = 1e-9
    model.optimize()

    if model.Status != GRB.OPTIMAL:
        payload = {
            "instance": model.ModelName,
            "status": int(model.Status),
            "status_name": "INFEASIBLE" if model.Status == GRB.INFEASIBLE else "NOT_OPTIMAL",
            "declared_public_objective": declared_objective,
            "sparse_entries": len(public_values),
            "unknown_solution_names": unknown_solution_names,
            "integer_variables_fixed": integer_variables,
            "continuous_variables_reoptimized": continuous_variables,
            "runtime_seconds": model.Runtime,
        }
        args.output_json.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        raise SystemExit(json.dumps(payload, indent=2))

    repaired_values = [var.X for var in variables]
    repaired_by_name = {
        var.VarName: repaired_values[var.index] for var in variables
    }

    sparse_lines = [f"=obj= {model.ObjVal:.17g}"]
    full_lines = [f"=obj= {model.ObjVal:.17g}"]
    for var in variables:
        value = repaired_values[var.index]
        full_lines.append(f"{var.VarName} {value:.17g}")
        if value != 0.0:
            sparse_lines.append(f"{var.VarName} {value:.17g}")
    args.output_sparse_sol.write_text("\n".join(sparse_lines) + "\n", encoding="utf-8")
    args.output_full_sol.write_text("\n".join(full_lines) + "\n", encoding="utf-8")

    # Audit against a separately reread, untouched copy of the official MPS.
    audit_model = gp.read(str(args.mps))
    audit_vars = audit_model.getVars()
    audit_x = [repaired_by_name[var.VarName] for var in audit_vars]
    getcontext().prec = 60
    thresholds = [Decimal("1e-9"), Decimal("1e-8"), Decimal("1e-7"), Decimal("1e-6")]
    threshold_counts = {str(t): 0 for t in thresholds}
    worst_rows: list[tuple[Decimal, str, str, Decimal, Decimal, int]] = []
    max_row_violation = Decimal(0)

    for constr in audit_model.getConstrs():
        row = audit_model.getRow(constr)
        terms = []
        for pos in range(row.size()):
            coeff = Decimal(str(row.getCoeff(pos)))
            value = Decimal(str(audit_x[row.getVar(pos).index]))
            terms.append(coeff * value)
        lhs = sum(terms, Decimal(0))
        rhs = Decimal(str(constr.RHS))
        viol = violation(lhs, rhs, constr.Sense)
        if viol > max_row_violation:
            max_row_violation = viol
        for threshold in thresholds:
            if viol > threshold:
                threshold_counts[str(threshold)] += 1
        if viol > 0:
            worst_rows.append(
                (viol, constr.ConstrName, constr.Sense, lhs, rhs, row.size())
            )

    worst_rows.sort(key=lambda item: item[0], reverse=True)
    max_bound_violation = Decimal(0)
    max_integrality_violation = Decimal(0)
    integer_pattern_mismatches = 0
    for var, value in zip(audit_vars, audit_x):
        dec_value = Decimal(str(value))
        if not math.isinf(var.LB):
            max_bound_violation = max(
                max_bound_violation, Decimal(str(var.LB)) - dec_value
            )
        if not math.isinf(var.UB):
            max_bound_violation = max(
                max_bound_violation, dec_value - Decimal(str(var.UB))
            )
        if var.VType in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT):
            int_viol = abs(dec_value - Decimal(round(value)))
            max_integrality_violation = max(max_integrality_violation, int_viol)
            public_value = round(public_values.get(var.VarName, 0.0))
            if round(value) != public_value:
                integer_pattern_mismatches += 1

    max_bound_violation = max(max_bound_violation, Decimal(0))
    objective_decimal = Decimal(str(audit_model.ObjCon)) + sum(
        (
            Decimal(str(var.Obj)) * Decimal(str(audit_x[var.index]))
            for var in audit_vars
        ),
        Decimal(0),
    )
    objective_float = audit_model.ObjCon + math.fsum(
        var.Obj * audit_x[var.index] for var in audit_vars
    )

    payload = {
        "instance": audit_model.ModelName,
        "method": "all sparse-omitted variables set to zero; every integer fixed to the public pattern; continuous LP reoptimized",
        "solver": {
            "gurobi_version": list(gp.gurobi.version()),
            "status": "OPTIMAL",
            "objective": model.ObjVal,
            "runtime_seconds": model.Runtime,
            "simplex_iterations": model.IterCount,
            "barrier_iterations": model.BarIterCount,
            "parameters": {
                "time_limit": args.time_limit,
                "threads": args.threads,
                "presolve": 2,
                "numeric_focus": 3,
                "feasibility_tolerance": 1e-9,
                "optimality_tolerance": 1e-9,
            },
        },
        "public_solution": {
            "declared_objective": declared_objective,
            "sparse_entries": len(public_values),
            "unknown_solution_names": unknown_solution_names,
            "omitted_variables_explicitly_interpreted_as_zero": len(variables) - len(public_values),
            "integer_variables_fixed": integer_variables,
            "continuous_variables_reoptimized": continuous_variables,
            "integer_pattern_mismatches_after_repair": integer_pattern_mismatches,
        },
        "original_mps_decimal_string_audit": {
            "objective": str(objective_decimal),
            "objective_float_fsum": objective_float,
            "max_bound_violation": str(max_bound_violation),
            "max_integrality_violation": str(max_integrality_violation),
            "max_row_violation": str(max_row_violation),
            "row_violation_counts_above": threshold_counts,
            "strictly_feasible_at_1e-9": (
                max_bound_violation <= Decimal("1e-9")
                and max_integrality_violation <= Decimal("1e-9")
                and max_row_violation <= Decimal("1e-9")
            ),
            "worst_rows": [
                {
                    "violation": str(viol),
                    "name": name,
                    "sense": sense,
                    "lhs": str(lhs),
                    "rhs": str(rhs),
                    "nonzeros": nnz,
                }
                for viol, name, sense, lhs, rhs, nnz in worst_rows[:20]
            ],
        },
        "outputs": {
            "sparse_solution": str(args.output_sparse_sol),
            "full_solution": str(args.output_full_sol),
            "fixed_lp_log": str(args.log),
        },
        "wall_runtime_seconds": time.time() - started,
    }
    args.output_json.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
