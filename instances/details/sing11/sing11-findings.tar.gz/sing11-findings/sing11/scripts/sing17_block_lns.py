from __future__ import annotations

import argparse
import gzip
import json
import math
import time
from collections import defaultdict
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def parse_solution(model: gp.Model, path: Path) -> tuple[list[float], dict]:
    variables = model.getVars()
    name_to_index = {variable.VarName: variable.index for variable in variables}
    values = [0.0] * len(variables)
    explicit = 0
    missing: list[str] = []
    declared_objective = None
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
        for raw_line in handle:
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if parts[0] == "=" or parts[0].startswith("="):
                for token in reversed(parts):
                    try:
                        declared_objective = float(token)
                        break
                    except ValueError:
                        continue
                continue
            if len(parts) < 2:
                continue
            try:
                value = float(parts[1])
            except ValueError:
                continue
            index = name_to_index.get(parts[0])
            if index is None:
                if len(missing) < 20:
                    missing.append(parts[0])
                continue
            if variables[index].VType != GRB.CONTINUOUS:
                value = float(round(value))
            values[index] = value
            explicit += 1
    objective = sum(variable.Obj * values[variable.index] for variable in variables)
    return values, {
        "explicit_values": explicit,
        "missing_name_examples": missing,
        "declared_objective": declared_objective,
        "recomputed_objective": objective + model.ObjCon,
    }


def parse_decomposition(path: Path) -> tuple[int, dict[int, list[str]], set[str]]:
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    block_count = 0
    current_block = None
    in_master = False
    block_rows: dict[int, list[str]] = defaultdict(list)
    master_rows: set[str] = set()
    index = 0
    while index < len(lines):
        line = lines[index].strip()
        index += 1
        if not line or line.startswith("\\"):
            continue
        upper = line.upper()
        if upper == "NBLOCKS":
            while index < len(lines) and not lines[index].strip():
                index += 1
            block_count = int(lines[index].strip())
            index += 1
        elif upper.startswith("BLOCK "):
            current_block = int(line.split()[1])
            in_master = False
        elif upper == "MASTERCONSS":
            current_block = None
            in_master = True
        elif upper in {"PRESOLVED", "0"}:
            continue
        elif in_master:
            master_rows.add(line)
        elif current_block is not None:
            block_rows[current_block].append(line)
    return block_count, block_rows, master_rows


def audit_solution(model: gp.Model, values: list[float]) -> dict:
    variables = model.getVars()
    bound_violation = 0.0
    integer_violation = 0.0
    for variable, value in zip(variables, values):
        bound_violation = max(bound_violation, variable.LB - value, value - variable.UB, 0.0)
        if variable.VType != GRB.CONTINUOUS:
            integer_violation = max(integer_violation, abs(value - round(value)))
    row_violation = 0.0
    worst_row = None
    for constraint in model.getConstrs():
        row = model.getRow(constraint)
        activity = sum(
            row.getCoeff(position) * values[row.getVar(position).index]
            for position in range(row.size())
        )
        if constraint.Sense == GRB.LESS_EQUAL:
            violation = max(0.0, activity - constraint.RHS)
        elif constraint.Sense == GRB.GREATER_EQUAL:
            violation = max(0.0, constraint.RHS - activity)
        else:
            violation = abs(activity - constraint.RHS)
        if violation > row_violation:
            row_violation = violation
            worst_row = constraint.ConstrName
    objective = model.ObjCon + sum(variable.Obj * values[variable.index] for variable in variables)
    return {
        "objective": objective,
        "max_bound_violation": bound_violation,
        "max_integrality_violation": integer_violation,
        "max_row_violation": row_violation,
        "worst_row": worst_row,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--decomposition", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--log-dir", type=Path, required=True)
    parser.add_argument("--best-solution", type=Path, required=True)
    parser.add_argument("--time-per-block", type=float, default=45.0)
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--min-block-rows", type=int, default=1)
    parser.add_argument("--max-blocks", type=int)
    parser.add_argument("--order", choices=("largest", "smallest"), default="largest")
    parser.add_argument("--seed", type=int, default=1717)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.log_dir.mkdir(parents=True, exist_ok=True)
    args.best_solution.parent.mkdir(parents=True, exist_ok=True)

    started = time.time()
    model = gp.read(str(args.mps))
    model.Params.OutputFlag = 0
    variables = model.getVars()
    constraints_by_name = {constraint.ConstrName: constraint for constraint in model.getConstrs()}
    incumbent, solution_info = parse_solution(model, args.solution)
    initial_audit = audit_solution(model, incumbent)
    original_lb = [variable.LB for variable in variables]
    original_ub = [variable.UB for variable in variables]

    block_count, block_rows, master_row_names = parse_decomposition(args.decomposition)
    block_variables: dict[int, set[int]] = defaultdict(set)
    for block, names in block_rows.items():
        for name in names:
            row = model.getRow(constraints_by_name[name])
            for position in range(row.size()):
                block_variables[block].add(row.getVar(position).index)

    master_variables: set[int] = set()
    for name in master_row_names:
        row = model.getRow(constraints_by_name[name])
        for position in range(row.size()):
            master_variables.add(row.getVar(position).index)
    all_block_variables = set().union(*block_variables.values())
    master_only_variables = master_variables - all_block_variables

    for variable, value in zip(variables, incumbent):
        variable.LB = value
        variable.UB = value
        variable.Start = value
    model.update()

    candidates = [
        block
        for block in range(1, block_count + 1)
        if len(block_rows[block]) >= args.min_block_rows
    ]
    candidates.sort(
        key=(
            (lambda block: (-len(block_rows[block]), block))
            if args.order == "largest"
            else (lambda block: (len(block_rows[block]), block))
        )
    )
    if args.max_blocks is not None:
        candidates = candidates[: args.max_blocks]

    best_objective = initial_audit["objective"]
    records = []
    for sequence, block in enumerate(candidates, start=1):
        free_indices = block_variables[block] | master_only_variables
        for index in free_indices:
            variables[index].LB = original_lb[index]
            variables[index].UB = original_ub[index]
            variables[index].Start = incumbent[index]
        model.update()
        model.reset(0)
        model.Params.TimeLimit = args.time_per_block
        model.Params.Threads = args.threads
        model.Params.Seed = args.seed + sequence
        model.Params.MIPFocus = 1
        model.Params.MIPGap = 0.0
        model.Params.MIPGapAbs = 0.0
        model.Params.Cuts = 2
        model.Params.Presolve = 2
        model.Params.Symmetry = 2
        model.Params.Heuristics = 0.2
        model.Params.OutputFlag = 1
        model.Params.LogFile = str(args.log_dir / f"sing17-block-{block:02d}.log")
        block_started = time.time()
        model.optimize()
        record = {
            "sequence": sequence,
            "block": block,
            "block_rows": len(block_rows[block]),
            "block_variables": len(block_variables[block]),
            "free_variables": len(free_indices),
            "status": int(model.Status),
            "solution_count": int(model.SolCount),
            "objective": float(model.ObjVal) if model.SolCount else None,
            "best_bound": float(model.ObjBound) if model.IsMIP else None,
            "gap": float(model.MIPGap) if model.IsMIP and model.SolCount else None,
            "nodes": float(model.NodeCount),
            "runtime": float(model.Runtime),
            "wall_runtime": time.time() - block_started,
            "improved": False,
        }
        if model.SolCount and model.ObjVal < best_objective - 1e-6:
            incumbent = [float(variable.X) for variable in variables]
            best_objective = float(model.ObjVal)
            record["improved"] = True
            model.write(str(args.best_solution))
        for index in free_indices:
            variables[index].LB = incumbent[index]
            variables[index].UB = incumbent[index]
            variables[index].Start = incumbent[index]
        model.update()
        records.append(record)

        checkpoint = {
            "instance": model.ModelName,
            "method": "official-decomposition one-block coordinate LNS (zero relative and absolute MIP gap)",
            "solution": solution_info,
            "initial_audit": initial_audit,
            "decomposition": {
                "blocks": block_count,
                "master_rows": len(master_row_names),
                "master_variables": len(master_variables),
                "master_only_variables": len(master_only_variables),
            },
            "parameters": {
                "time_per_block": args.time_per_block,
                "threads": args.threads,
                "min_block_rows": args.min_block_rows,
                "max_blocks": args.max_blocks,
                "order": args.order,
                "seed": args.seed,
            },
            "best_objective": best_objective,
            "objective_improvement": initial_audit["objective"] - best_objective,
            "blocks_completed": len(records),
            "records": records,
            "wall_runtime": time.time() - started,
        }
        args.output.write_text(json.dumps(checkpoint, indent=2) + "\n", encoding="utf-8")

    final_audit = audit_solution(model, incumbent)
    checkpoint["final_audit"] = final_audit
    checkpoint["wall_runtime"] = time.time() - started
    args.output.write_text(json.dumps(checkpoint, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(checkpoint, indent=2))


if __name__ == "__main__":
    main()
