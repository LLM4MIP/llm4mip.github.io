from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def read_solution(path: Path) -> tuple[dict[str, float], float | None]:
    values: dict[str, float] = {}
    declared: float | None = None
    with path.open("rt", encoding="utf-8", errors="replace") as handle:
        for raw_line in handle:
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if parts[0].lower() in {"=obj=", "=best=", "=opt="}:
                if len(parts) >= 2:
                    declared = float(parts[1])
                continue
            if len(parts) >= 2:
                values[parts[0]] = float(parts[1])
    return values, declared


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run a MIP with a complete, explicitly zero-filled solution start."
    )
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--start", type=Path, required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--output-sol", type=Path, required=True)
    parser.add_argument("--output-full-sol", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--time-limit", type=float, default=300.0)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--mip-focus", type=int, default=2)
    parser.add_argument("--cuts", type=int, default=2)
    parser.add_argument("--numeric-focus", type=int, default=2)
    parser.add_argument("--seed", type=int, default=511)
    args = parser.parse_args()

    for path in (args.output_json, args.output_sol, args.output_full_sol, args.log):
        path.parent.mkdir(parents=True, exist_ok=True)

    started = time.time()
    values, declared_objective = read_solution(args.start)
    model = gp.read(str(args.mps))
    variables = model.getVars()
    model_names = {var.VarName for var in variables}
    unknown_names = sorted(set(values) - model_names)
    missing_names = sorted(model_names - set(values))

    # A complete start is intentional: sparse solution files define omitted values as 0.
    for var in variables:
        var.Start = values.get(var.VarName, 0.0)

    model.Params.LogFile = str(args.log)
    model.Params.TimeLimit = args.time_limit
    model.Params.Threads = args.threads
    model.Params.MIPFocus = args.mip_focus
    model.Params.Presolve = 2
    model.Params.Cuts = args.cuts
    model.Params.NumericFocus = args.numeric_focus
    model.Params.Seed = args.seed
    model.Params.MIPGap = 0
    model.Params.FeasibilityTol = 1e-9
    model.Params.IntFeasTol = 1e-9
    model.optimize()

    objective = float(model.ObjVal) if model.SolCount else None
    if model.SolCount:
        solution_values = [var.X for var in variables]
        sparse_lines = [f"=obj= {objective:.17g}"]
        full_lines = [f"=obj= {objective:.17g}"]
        for var in variables:
            value = solution_values[var.index]
            full_lines.append(f"{var.VarName} {value:.17g}")
            if value != 0.0:
                sparse_lines.append(f"{var.VarName} {value:.17g}")
        args.output_sol.write_text("\n".join(sparse_lines) + "\n", encoding="utf-8")
        args.output_full_sol.write_text("\n".join(full_lines) + "\n", encoding="utf-8")

    status_names = {
        GRB.OPTIMAL: "OPTIMAL",
        GRB.INFEASIBLE: "INFEASIBLE",
        GRB.INF_OR_UNBD: "INF_OR_UNBD",
        GRB.UNBOUNDED: "UNBOUNDED",
        GRB.TIME_LIMIT: "TIME_LIMIT",
        GRB.NODE_LIMIT: "NODE_LIMIT",
        GRB.INTERRUPTED: "INTERRUPTED",
    }
    payload = {
        "instance": model.ModelName,
        "status": int(model.Status),
        "status_name": status_names.get(model.Status, "OTHER"),
        "parameters": {
            "time_limit": args.time_limit,
            "threads": args.threads,
            "mip_focus": args.mip_focus,
            "presolve": 2,
            "cuts": args.cuts,
            "numeric_focus": args.numeric_focus,
            "seed": args.seed,
            "mip_gap": 0,
            "feasibility_tolerance": 1e-9,
            "integer_feasibility_tolerance": 1e-9,
        },
        "complete_start": {
            "source": str(args.start),
            "declared_objective": declared_objective,
            "model_variables": len(variables),
            "explicit_entries": len(values),
            "missing_model_variables_filled_with_zero": len(missing_names),
            "unknown_solution_names": unknown_names,
        },
        "solution_count": int(model.SolCount),
        "objective": objective,
        "best_bound": float(model.ObjBound),
        "relative_gap": float(model.MIPGap) if model.SolCount else None,
        "improvement_over_start": (
            None
            if objective is None or declared_objective is None
            else declared_objective - objective
        ),
        "node_count": float(model.NodeCount),
        "simplex_iterations": float(model.IterCount),
        "barrier_iterations": int(model.BarIterCount),
        "solver_runtime_seconds": float(model.Runtime),
        "wall_runtime_seconds": time.time() - started,
        "work_units": float(model.Work),
        "outputs": {
            "sparse_solution": str(args.output_sol) if model.SolCount else None,
            "full_solution": str(args.output_full_sol) if model.SolCount else None,
            "log": str(args.log),
        },
    }
    args.output_json.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
