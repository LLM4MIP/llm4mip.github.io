from __future__ import annotations

import argparse
import gzip
import json
from collections import Counter, defaultdict
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def read_solution(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix == ".gz" else open
    values: dict[str, float] = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            fields = line.strip().split()
            if not fields or fields[0].startswith("#") or fields[0].startswith("=") or len(fields) < 2:
                continue
            try:
                values[fields[0]] = float(fields[1])
            except ValueError:
                continue
    return values


def parse_dec(path: Path) -> tuple[dict[str, int], set[str]]:
    row_to_block: dict[str, int] = {}
    master_rows: set[str] = set()
    current_block = None
    in_master = False
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    index = 0
    while index < len(lines):
        line = lines[index].strip()
        index += 1
        if not line or line.startswith("\\"):
            continue
        upper = line.upper()
        if upper == "NBLOCKS":
            while index < len(lines) and not lines[index].strip():
                index += 1
            index += 1
        elif upper.startswith("BLOCK "):
            current_block = int(line.split()[1])
            in_master = False
        elif upper == "MASTERCONSS":
            current_block = None
            in_master = True
        elif upper in {"PRESOLVED", "0"}:
            continue
        elif in_master:
            master_rows.add(line)
        elif current_block is not None:
            row_to_block[line] = current_block
    return row_to_block, master_rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--dec", type=Path, required=True)
    parser.add_argument("--old", type=Path, required=True)
    parser.add_argument("--new", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    model = gp.read(str(args.mps))
    model.update()
    old = read_solution(args.old)
    new = read_solution(args.new)
    row_to_block, master_rows = parse_dec(args.dec)

    variable_blocks: dict[int, set[int]] = defaultdict(set)
    master_variables: set[int] = set()
    for constraint in model.getConstrs():
        row = model.getRow(constraint)
        if constraint.ConstrName in master_rows:
            master_variables.update(row.getVar(i).index for i in range(row.size()))
        else:
            block = row_to_block[constraint.ConstrName]
            for i in range(row.size()):
                variable_blocks[row.getVar(i).index].add(block)

    records: dict[str, dict] = defaultdict(
        lambda: {
            "changed_integer_variables": 0,
            "changed_continuous_variables": 0,
            "max_absolute_value_change": 0.0,
            "direct_objective_change": 0.0,
            "changed_variable_examples": [],
        }
    )
    total_old_objective = model.ObjCon
    total_new_objective = model.ObjCon
    changed_integer = 0
    changed_continuous = 0
    for variable in model.getVars():
        before = old.get(variable.VarName, 0.0)
        after = new.get(variable.VarName, 0.0)
        total_old_objective += variable.Obj * before
        total_new_objective += variable.Obj * after
        tolerance = 1e-8 if variable.VType == GRB.CONTINUOUS else 0.5
        if abs(after - before) <= tolerance:
            continue
        blocks = variable_blocks.get(variable.index, set())
        if len(blocks) == 1:
            key = f"block_{next(iter(blocks)):03d}"
        elif len(blocks) > 1:
            key = "multiple_blocks"
        elif variable.index in master_variables:
            key = "master_only"
        else:
            key = "unassigned_variable"
        record = records[key]
        if variable.VType == GRB.CONTINUOUS:
            record["changed_continuous_variables"] += 1
            changed_continuous += 1
        else:
            record["changed_integer_variables"] += 1
            changed_integer += 1
        record["max_absolute_value_change"] = max(record["max_absolute_value_change"], abs(after - before))
        record["direct_objective_change"] += variable.Obj * (after - before)
        if len(record["changed_variable_examples"]) < 10:
            record["changed_variable_examples"].append(
                {"name": variable.VarName, "old": before, "new": after, "obj": variable.Obj}
            )

    ordered = sorted(
        ({"partition": key, **record} for key, record in records.items()),
        key=lambda item: (
            -(item["changed_integer_variables"] + item["changed_continuous_variables"]),
            item["partition"],
        ),
    )
    report = {
        "instance": model.ModelName,
        "old_solution": str(args.old),
        "new_solution": str(args.new),
        "old_objective": total_old_objective,
        "new_objective": total_new_objective,
        "objective_change_new_minus_old": total_new_objective - total_old_objective,
        "changed_integer_variables": changed_integer,
        "changed_continuous_variables": changed_continuous,
        "changed_partitions": len(ordered),
        "partition_records": ordered,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
