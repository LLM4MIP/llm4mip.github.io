# Package manifest: genus-sym-g31-8

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 5
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/genus-sym-g31-8.adjacency.txt`
- `artifacts/genus-sym-g31-8.mc`
- `logs/genus-sym-g31-8.multi-genus.log`
- `solutions/official-23.sol.gz`

## Excluded files

- `input/genus-sym-g31-8.mps.gz (1495997 bytes; raw benchmark input; sha256 2d5b09c516c8600eda8e805decef9b092cd0875c7d42875ffb51aa490bc96555)`
