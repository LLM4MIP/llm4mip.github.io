# One-hour framework smoke test — 2026-09-02

## Outcome

The end-to-end controller path was exercised with `comp12-2idx`:

1. OpenAI-compatible Chat Completions smoke test succeeded.
2. The agent requested and received a Gurobi structure export from `euler4`.
3. The controller launched, polled, stopped/fetched, and archived remote jobs.
4. Git commit and push completed successfully.
5. After fixing issues exposed by the first run, a controlled 30-second Gurobi replay completed normally with the known objective-277 MIP start.

This smoke test did **not** improve the instance record. The best verified primal remains 277 and the previously obtained global lower bound remains 131.

## Initial controller run

- Wall-clock: about 2.5 minutes; it ended on the token budget rather than the one-hour time limit.
- Reported provider usage: 38,458 tokens (background 5,358; solving 23,982; reporting 9,118).
- The configured 30,000-token budget was exceeded because the compatible provider adds hidden input context and one large file-reading turn was more expensive than the controller could estimate in advance.
- The model launched Gurobi with a 2,300-second request, but the remote driver rejected the model-supplied `Threads` parameter because thread count is controlled by the experiment configuration.
- Initial artifacts were committed and pushed as commit `cf25a700869b37d3340c29931129a961cba5e303`.

## Framework corrections

- Model-supplied `Threads`, `TimeLimit`, and log/result paths are now safely ignored instead of terminating the remote job.
- Security-sensitive solver parameters are still rejected.
- Gurobi `.sol`/`.mst` start files are resolved only inside the instance directory, uploaded explicitly, and loaded through a dedicated runner argument.
- Instance-relative file paths are documented and redundant `instances/<instance>/` prefixes are normalized.
- API turns now reserve estimated hidden/visible input tokens before assigning an output limit; prior action results are compacted dynamically.
- Early Gurobi exceptions are always captured in `result.json` instead of being masked by unavailable post-solve attributes.
- The known unrestricted license file from prior successful logs is explicitly selected on `euler4`.
- Local regression suite after the corrections: 15/15 tests passed.

## Remote replay trail

### `gurobi-20260902-195512-de47e7a9`

Confirmed that `Threads=64` was ignored and the objective-277 start file was uploaded and read. An early optimize error was masked by post-solve attribute collection; this prompted the result-capture correction.

### `gurobi-20260902-195714-d4324971`

The corrected result capture exposed the original error: the default Gurobi environment had selected a size-limited license.

### `gurobi-20260902-195923-bc98a2f6`

Final successful replay using the configured `euler4` license:

- solver/version: Gurobi 13.0.1;
- host: `euler4`;
- time limit/runtime: 30 s / 30.07 s;
- threads: 32 (model-requested 64 ignored);
- start: verified objective-277 solution;
- termination: `TIME_LIMIT`;
- primal bound: 277;
- dual bound: 109;
- relative gap: 60.6498%;
- explored nodes: 1;
- proof flags: neither optimal nor infeasible.

The dual bound 109 is weaker than the archived best bound 131, so README result claims remain unchanged.
