#  `comp12-2idx` continues to study the records

The date of the study: 2026 -09 -01.

## Conclusion

This round did not find a feasible solution below 277, nor did it obtain globally optimal sex proof. The original feasible solution 277 is still the best primal bound, and the best global lower bound of the complete model is still 131.

The new strict conclusion is that on a 1800 course/period binary variable, within the Hamming radius 10 centered on the current 277 solution, there is no objective value greater than the feasible solution for 276. Since the number of classes taught in each course is fixed, the Hamming distance between the two classes is even, so any improved solution needs to change at least the binary position of 12, i.e. at least rearrange the 6 teaching time.

##  Enhanced models

The 11863 variable of the original model can be divided into:

| Family of variables |  Count | Current solution objective Contributions |
|---|---:|---:|
| Distribution of `y` courses/periods |  1800  |  0  |
| Class group isolated auxiliary variable |  5400  |  92  |
| Room Capacity Assistance variable |  4054  |  0  |
| Opening day support variable |  522  |  0  |
| Minimum missing variable for school days |  87  |  185  |

Only one 1800 `y` variable is a true classroom decision. The rest of the 10063 variables are punished with epigraph or class day auxiliary variables after the fixed `y`. This round sequences these variables and retains all the original constraints; this operation at least gives the original integer model a safe relaxation, so the infeasible conclusions and lower bound obtained on this relaxation model remain valid for the original model.

The original model used 7337 for constraint to describe the course conflict. This round independently constructed a conflict diagram for each time, enumeration of which 1852 has the largest clique:

| Clique size |  Count |
|---:|---:|
| 3 | 401 |
| 4 | 672 |
| 5 | 507 |
| 6 | 208 |
| 7 | 50 |
| 8 | 12 |
| 9 | 2 |

The maximum clique constraint covers and replaces the 7231 individual to conflict constraint, reducing the model row count from 16803 to 11424. The reinforced model gets the lower bound 127.635043763222 in the 120 second run `MIPFocus=3`; it is slightly stronger on the same time scale than the original one, but does not exceed the global lower bound 180 run in the previous 131 seconds.

## Local branching

Add the following constraints, where `y*` is the current 277 solution:

```text
sum(y*[j] = 1 at 1 -y[j]) + sum(y*[j] = 0 at y[j]) <= k
objective <= 276.5
```

The objective coefficients and the original integer variable are integer derivatives, `276.5` equivalent to the objective solution of 276 in the original model.

| The radius `k` |  Time limit |  result |
|---:|---:|---|
|  10  | 184.81 seconds | **model infeasible , full proof** |
|  20  | 150 seconds |  No feasible solution found; search lower bound 261.844187725026; proof incomplete. |

The proof of the radius 10 collectively searches the nodes of 9141, performing about 643 a thousand times simplex iteration.

##  Curriculum oriented to LNS

The current solution has 46 isolated-curriculum events across 40 curricula, involving 57 courses. Minimum-teaching-day shortfalls affect 33 courses, totaling 37 missing days.

Neighborhoods are expanded according to a set of curricula that generates isolated penalty points, rather than randomly selecting courses:

| Number of courses released |  result |
|---:|---|
|  36  | **Full proof neighborhood Maximum value 277** |
|  50  | **Full proof neighborhood Maximum value 277** |
|  65  | 60 seconds without improvement, neighborhood lower bound 222 |
|  78  | 60 seconds without improvement, neighborhood lower bound 165.546260256662 |
|  88  | Two attempts at 60 global seconds failed to improve. |

In addition, the fixed room capacity penalty is 0, and requires the number of isolated times to be reduced from 46 to 45, or the missing date to be reduced from 37 to 36, respectively. Both sets of 180 second-oriented searches do not find a solution for objective not exceeding 276; these operations are not completed without infeasible proof.

##  Reproducible files

-  `comp12_strengthened_solve.py`: maximum clique strengthening, conflict replacement, local branching and objective distribution constraint;
-  `comp12_curriculum_lns.py`: Construct the LNS according to a set of courses that generate isolated penalty points;
-  `comp12-lb10-long.log`: The complete infeasible proof log of the radius 10;
-  `comp12-lb20.log`: Unfinished search log of the radius 20;
-  `comp12-curriculum-lns.log`: LNS diary of the curriculum group;
-  `comp12-strength-bound.log`: A lower bound experimental log for reinforcing the complete model.

The core command for the remote reproduction radius 10 proof is:

```bash
python comp12_strengthened_solve.py comp12-2idx.mps comp12-2idx-verified277.sol \
  --seconds 600 --threads 40 --focus 3 --replace-pairwise \
  --local-branching 10 --target 276 \
  --result comp12-lb10-long.sol --log comp12-lb10-long.log
```
