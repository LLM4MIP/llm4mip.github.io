#!/usr/bin/env python3
"""Print structural statistics for comp12-2idx using Gurobi's parsed model."""

from __future__ import annotations

import argparse
import collections
import re
from pathlib import Path

import gurobipy as gp


def variable_family(name: str) -> str:
    if name.startswith("y"):
        return "y_assignment"
    if name.startswith("lambda"):
        return "lambda_capacity"
    if name.startswith("DayInUse"):
        return "day_in_use"
    if name.startswith("DaysBelowVio"):
        return "days_below"
    if name.startswith("CurriculaIsolated"):
        return "curriculum_isolated"
    return re.split(r"[_(]", name, maxsplit=1)[0]


def row_family(name: str) -> str:
    return re.split(r"[_(]", name, maxsplit=1)[0]


def read_solution(path: Path) -> dict[str, float]:
    values: dict[str, float] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        fields = line.split()
        if len(fields) == 2 and not fields[0].startswith("#") and fields[0] != "=obj=":
            values[fields[0]] = float(fields[1])
    return values


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("--solution", type=Path)
    parser.add_argument("--presolve", action="store_true")
    args = parser.parse_args()

    model = gp.read(str(args.mps))
    model.update()
    solution = read_solution(args.solution) if args.solution else {}

    by_var: dict[str, dict[str, float]] = collections.defaultdict(
        lambda: {"count": 0, "integer": 0, "objective_nz": 0, "objective_sum": 0, "solution_nz": 0, "contribution": 0}
    )
    for var in model.getVars():
        family = variable_family(var.VarName)
        stats = by_var[family]
        stats["count"] += 1
        stats["integer"] += var.VType != gp.GRB.CONTINUOUS
        stats["objective_nz"] += abs(var.Obj) > 1e-12
        stats["objective_sum"] += var.Obj
        value = solution.get(var.VarName, 0.0)
        stats["solution_nz"] += abs(value) > 1e-9
        stats["contribution"] += var.Obj * value

    print("VARIABLE_FAMILIES")
    for family, stats in sorted(by_var.items(), key=lambda item: (-item[1]["count"], item[0])):
        print(f"{family:28s} " + " ".join(f"{key}={value:g}" for key, value in stats.items()))

    by_row = collections.Counter(row_family(row.ConstrName) for row in model.getConstrs())
    print("ROW_FAMILIES")
    for family, count in by_row.most_common():
        print(f"{family:36s} count={count}")

    print(f"MODEL rows={model.NumConstrs} cols={model.NumVars} nz={model.NumNZs}")
    if args.presolve:
        model.Params.OutputFlag = 0
        presolved = model.presolve()
        print(
            f"PRESOLVED rows={presolved.NumConstrs} cols={presolved.NumVars} "
            f"nz={presolved.NumNZs} binaries={presolved.NumBinVars} integers={presolved.NumIntVars}"
        )


if __name__ == "__main__":
    main()
