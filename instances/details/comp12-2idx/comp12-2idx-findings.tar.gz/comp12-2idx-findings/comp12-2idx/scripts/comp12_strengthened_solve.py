#!/usr/bin/env python3
"""Solve comp12-2idx after exact auxiliary relaxation and clique strengthening.

Only the course/time assignment variables carry combinatorial decisions.  Every
other integer variable in this formulation is a nonnegative penalty epigraph or
an unpenalized day-use helper whose optimal value is integral once assignments
are integral.  Relaxing those helpers is therefore an exact reformulation.

The original model encodes conflicts pairwise.  This script also detects
maximal cliques independently in each timeslot and adds the corresponding
set-packing inequalities.
"""

from __future__ import annotations

import argparse
import collections
import re
from pathlib import Path

import gurobipy as gp


SLOT_RE = re.compile(r"\((D\d+),(P\d+)\)$")


def read_solution(path: Path) -> dict[str, float]:
    values: dict[str, float] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        fields = line.split()
        if len(fields) == 2 and fields[0] != "=obj=" and not fields[0].startswith("#"):
            values[fields[0]] = float(fields[1])
    return values


def maximal_cliques(vertices: set[str], adjacency: dict[str, set[str]]) -> list[frozenset[str]]:
    result: list[frozenset[str]] = []

    def visit(chosen: set[str], candidates: set[str], excluded: set[str]) -> None:
        if not candidates and not excluded:
            if len(chosen) >= 3:
                result.append(frozenset(chosen))
            return
        pivot_pool = candidates | excluded
        pivot = max(pivot_pool, key=lambda item: len(candidates & adjacency[item])) if pivot_pool else None
        extensions = candidates - (adjacency[pivot] if pivot is not None else set())
        for vertex in list(extensions):
            neighbors = adjacency[vertex]
            visit(chosen | {vertex}, candidates & neighbors, excluded & neighbors)
            candidates.remove(vertex)
            excluded.add(vertex)

    visit(set(), set(vertices), set())
    return result


def add_conflict_cliques(
    model: gp.Model, replace_pairwise: bool
) -> tuple[int, int, collections.Counter[int]]:
    edges: dict[tuple[str, str], set[tuple[str, str]]] = collections.defaultdict(set)
    vertices: dict[tuple[str, str], set[str]] = collections.defaultdict(set)
    constraints_by_edge: dict[tuple[tuple[str, str], tuple[str, str]], list[gp.Constr]] = (
        collections.defaultdict(list)
    )
    for constraint in model.getConstrs():
        if not constraint.ConstrName.startswith("CourseConflicts"):
            continue
        row = model.getRow(constraint)
        course_vars = [
            row.getVar(index)
            for index in range(row.size())
            if row.getVar(index).VarName.startswith("y") and abs(row.getCoeff(index) - 1.0) <= 1e-12
        ]
        if len(course_vars) != 2:
            continue
        matches = [SLOT_RE.search(variable.VarName) for variable in course_vars]
        if not all(matches) or matches[0].groups() != matches[1].groups():
            continue
        slot = matches[0].groups()
        names = tuple(sorted(variable.VarName for variable in course_vars))
        vertices[slot].update(names)
        edges[slot].add(names)
        constraints_by_edge[(slot, names)].append(constraint)

    total = 0
    covered: set[tuple[tuple[str, str], tuple[str, str]]] = set()
    sizes: collections.Counter[int] = collections.Counter()
    for slot in sorted(vertices):
        adjacency = {name: set() for name in vertices[slot]}
        for left, right in edges[slot]:
            adjacency[left].add(right)
            adjacency[right].add(left)
        for clique in maximal_cliques(vertices[slot], adjacency):
            model.addConstr(
                gp.quicksum(model.getVarByName(name) for name in clique) <= 1,
                name=f"StrengthClique[{slot[0]},{slot[1]},{total}]",
            )
            total += 1
            sizes[len(clique)] += 1
            for left in clique:
                for right in clique:
                    if left < right:
                        covered.add((slot, (left, right)))

    removed = 0
    if replace_pairwise:
        for key in covered:
            for constraint in constraints_by_edge[key]:
                model.remove(constraint)
                removed += 1
    return total, removed, sizes


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--seconds", type=float, default=300.0)
    parser.add_argument("--threads", type=int, default=32)
    parser.add_argument("--focus", type=int, default=3)
    parser.add_argument("--seed", type=int, default=20260901)
    parser.add_argument("--no-relax-aux", action="store_true")
    parser.add_argument("--no-cliques", action="store_true")
    parser.add_argument("--replace-pairwise", action="store_true")
    parser.add_argument(
        "--local-branching",
        type=int,
        help="Maximum Hamming distance from the supplied assignment variables",
    )
    parser.add_argument(
        "--target",
        type=float,
        help="Search only for solutions with objective at most this value",
    )
    parser.add_argument("--capacity-zero", action="store_true")
    parser.add_argument("--max-day-violations", type=float)
    parser.add_argument("--max-isolations", type=float)
    parser.add_argument("--result", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    args = parser.parse_args()

    model = gp.read(str(args.mps))
    model.update()
    initial = read_solution(args.solution)

    relaxed = 0
    if not args.no_relax_aux:
        for variable in model.getVars():
            if not variable.VarName.startswith("y") and variable.VType != gp.GRB.CONTINUOUS:
                variable.VType = gp.GRB.CONTINUOUS
                relaxed += 1

    clique_count = 0
    removed_pairwise = 0
    clique_sizes: collections.Counter[int] = collections.Counter()
    if not args.no_cliques:
        clique_count, removed_pairwise, clique_sizes = add_conflict_cliques(
            model, args.replace_pairwise
        )

    y_variables = [variable for variable in model.getVars() if variable.VarName.startswith("y")]
    if args.local_branching is not None:
        model.addConstr(
            gp.quicksum(
                (1 - variable) if initial.get(variable.VarName, 0.0) > 0.5 else variable
                for variable in y_variables
            )
            <= args.local_branching,
            name="LocalBranchingHammingBall",
        )
    if args.target is not None:
        model.addConstr(model.getObjective() <= args.target + 0.5, name="StrictImprovementTarget")
    capacity_variables = [
        variable for variable in model.getVars() if variable.VarName.startswith("lambda")
    ]
    day_violation_variables = [
        variable for variable in model.getVars() if variable.VarName.startswith("DaysBelowVio")
    ]
    isolation_variables = [
        variable for variable in model.getVars() if variable.VarName.startswith("CurriculaIsolated")
    ]
    if args.capacity_zero:
        for variable in capacity_variables:
            variable.UB = 0.0
    if args.max_day_violations is not None:
        model.addConstr(
            gp.quicksum(day_violation_variables) <= args.max_day_violations,
            name="MaximumDayViolations",
        )
    if args.max_isolations is not None:
        model.addConstr(
            gp.quicksum(isolation_variables) <= args.max_isolations,
            name="MaximumIsolations",
        )

    model.update()
    for variable in model.getVars():
        variable.Start = initial.get(variable.VarName, 0.0)

    print(
        f"exact_aux_relaxed={relaxed} added_cliques={clique_count} "
        f"removed_pairwise={removed_pairwise} "
        f"clique_sizes={dict(sorted(clique_sizes.items()))}"
    )
    print(f"local_branching={args.local_branching} target={args.target}")
    print(
        f"capacity_zero={args.capacity_zero} "
        f"max_day_violations={args.max_day_violations} "
        f"max_isolations={args.max_isolations}"
    )
    print(
        f"strengthened_model rows={model.NumConstrs} cols={model.NumVars} "
        f"binaries={model.NumBinVars} integers={model.NumIntVars}"
    )

    model.Params.LogFile = str(args.log)
    model.Params.TimeLimit = args.seconds
    model.Params.Threads = args.threads
    model.Params.MIPFocus = args.focus
    model.Params.Seed = args.seed
    model.Params.Cuts = 3
    model.Params.PreSparsify = 2
    model.Params.Symmetry = 2
    model.optimize()

    if model.SolCount:
        model.write(str(args.result))
        print(f"RESULT objective={model.ObjVal:.15g} bound={model.ObjBound:.15g} gap={model.MIPGap:.8g}")
    else:
        print(f"RESULT no_solution status={model.Status} bound={model.ObjBound:.15g}")


if __name__ == "__main__":
    main()
