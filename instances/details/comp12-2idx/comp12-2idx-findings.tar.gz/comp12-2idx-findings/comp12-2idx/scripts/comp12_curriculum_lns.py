#!/usr/bin/env python3
"""Curriculum-cluster large-neighborhood search for comp12-2idx."""

from __future__ import annotations

import argparse
import collections
import random
import re
from pathlib import Path

import gurobipy as gp

from comp12_strengthened_solve import add_conflict_cliques, read_solution


ISOLATION_RE = re.compile(r"^CurriculaIsolated([^()]+)\(")


def course_of(variable_name: str) -> str | None:
    if variable_name.startswith("y") and "(" in variable_name:
        return variable_name[1:].split("(", 1)[0]
    return None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--seconds", type=float, default=45.0)
    parser.add_argument("--threads", type=int, default=16)
    parser.add_argument("--seed", type=int, default=20260901)
    parser.add_argument("--iterations", type=int, default=6)
    parser.add_argument("--result", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    args = parser.parse_args()

    rng = random.Random(args.seed)
    model = gp.read(str(args.mps))
    model.update()
    initial = read_solution(args.solution)

    y_by_course: dict[str, list[gp.Var]] = collections.defaultdict(list)
    for variable in model.getVars():
        course = course_of(variable.VarName)
        if course is not None:
            y_by_course[course].append(variable)

    curriculum_courses: dict[str, set[str]] = collections.defaultdict(set)
    for constraint in model.getConstrs():
        if not constraint.ConstrName.startswith("CurriculumAlone"):
            continue
        curriculum = constraint.ConstrName[len("CurriculumAlone") :].split("(", 1)[0]
        row = model.getRow(constraint)
        for index in range(row.size()):
            course = course_of(row.getVar(index).VarName)
            if course is not None:
                curriculum_courses[curriculum].add(course)

    penalized_curricula: collections.Counter[str] = collections.Counter()
    penalized_day_courses: set[str] = set()
    for variable in model.getVars():
        value = initial.get(variable.VarName, 0.0)
        if value <= 0.5:
            continue
        match = ISOLATION_RE.match(variable.VarName)
        if match:
            penalized_curricula[match.group(1)] += round(value)
        if variable.VarName.startswith("DaysBelowVio"):
            penalized_day_courses.add(variable.VarName[len("DaysBelowVio") :])

    isolated_union = set().union(
        *(curriculum_courses[curriculum] for curriculum in penalized_curricula)
    )
    print(
        f"courses={len(y_by_course)} curricula={len(curriculum_courses)} "
        f"penalized_curricula={len(penalized_curricula)} isolation_events={sum(penalized_curricula.values())} "
        f"isolated_union_courses={len(isolated_union)} penalized_day_courses={len(penalized_day_courses)}"
    )

    for variable in model.getVars():
        if not variable.VarName.startswith("y") and variable.VType != gp.GRB.CONTINUOUS:
            variable.VType = gp.GRB.CONTINUOUS
    added, removed, sizes = add_conflict_cliques(model, True)
    model.update()
    print(f"added_cliques={added} removed_pairwise={removed} clique_sizes={dict(sizes)}")

    original_bounds = {
        variable.VarName: (variable.LB, variable.UB)
        for variables in y_by_course.values()
        for variable in variables
    }
    incumbent = dict(initial)
    incumbent_objective = sum(
        variable.Obj * incumbent.get(variable.VarName, 0.0) for variable in model.getVars()
    )

    model.Params.LogFile = str(args.log)
    model.Params.Threads = args.threads
    model.Params.MIPFocus = 1
    model.Params.Cuts = 3
    model.Params.PreSparsify = 2
    model.Params.NoRelHeurTime = min(8.0, args.seconds / 4)

    sizes_to_try = [35, 50, 65, 78, 88, 88]
    curriculum_base = list(penalized_curricula)
    all_courses = list(y_by_course)
    for iteration in range(args.iterations):
        for variables in y_by_course.values():
            for variable in variables:
                variable.LB, variable.UB = original_bounds[variable.VarName]

        target_size = sizes_to_try[iteration % len(sizes_to_try)]
        selected: set[str] = set()
        if iteration % 2 == 0:
            selected.update(penalized_day_courses)
        curriculum_order = sorted(
            curriculum_base,
            key=lambda item: (-penalized_curricula[item], rng.random()),
        )
        for curriculum in curriculum_order:
            selected.update(curriculum_courses[curriculum])
            if len(selected) >= target_size:
                break
        if len(selected) < target_size:
            remaining = [course for course in all_courses if course not in selected]
            rng.shuffle(remaining)
            selected.update(remaining[: target_size - len(selected)])

        fixed = 0
        for course, variables in y_by_course.items():
            if course in selected:
                continue
            for variable in variables:
                value = round(incumbent.get(variable.VarName, 0.0))
                variable.LB = value
                variable.UB = value
                fixed += 1

        model.reset(0)
        for variable in model.getVars():
            variable.Start = incumbent.get(variable.VarName, 0.0)
        model.Params.TimeLimit = args.seconds
        model.Params.BestObjStop = incumbent_objective - 0.5
        print(
            f"iteration={iteration + 1} target={target_size} selected={len(selected)} "
            f"fixed_y={fixed} incumbent={incumbent_objective:.15g}"
        )
        model.optimize()
        if model.SolCount and model.ObjVal < incumbent_objective - 1e-5:
            incumbent_objective = model.ObjVal
            incumbent = {variable.VarName: variable.X for variable in model.getVars()}
            model.write(str(args.result))
            print(f"IMPROVED objective={incumbent_objective:.15g}")
        else:
            print(
                f"NO_IMPROVEMENT status={model.Status} "
                f"bound={model.ObjBound:.15g} solutions={model.SolCount}"
            )

    print(f"FINAL objective={incumbent_objective:.15g}")


if __name__ == "__main__":
    main()
