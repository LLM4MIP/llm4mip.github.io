# Package manifest: comp12-2idx

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 41
Excluded source files: 1

## Included files

- `README.md`
- `logs/comp12-2idx-copt-baseline.log`
- `logs/comp12-2idx-course-lns.log`
- `logs/comp12-2idx-gurobi-baseline.log`
- `logs/comp12-2idx-gurobi-known277-focus3.log`
- `logs/comp12-curriculum-lns.log`
- `logs/comp12-day36.log`
- `logs/comp12-iso45.log`
- `logs/comp12-lb10-long.log`
- `logs/comp12-lb10.log`
- `logs/comp12-lb20.log`
- `logs/comp12-replace.log`
- `logs/comp12-strength-bound.log`
- `reports/comp12-continuation-study.md`
- `reports/framework-smoke-20260902.md`
- `runs/gurobi-20260902-194218-40d68f70/driver.stderr`
- `runs/gurobi-20260902-194218-40d68f70/driver.stdout`
- `runs/gurobi-20260902-194218-40d68f70/solver.log`
- `runs/gurobi-20260902-195512-de47e7a9/driver.stderr`
- `runs/gurobi-20260902-195512-de47e7a9/driver.stdout`
- `runs/gurobi-20260902-195512-de47e7a9/solver.log`
- `runs/gurobi-20260902-195714-d4324971/driver.stderr`
- `runs/gurobi-20260902-195714-d4324971/driver.stdout`
- `runs/gurobi-20260902-195714-d4324971/result.json`
- `runs/gurobi-20260902-195714-d4324971/solver.log`
- `runs/gurobi-20260902-195923-bc98a2f6/best.sol`
- `runs/gurobi-20260902-195923-bc98a2f6/driver.stderr`
- `runs/gurobi-20260902-195923-bc98a2f6/driver.stdout`
- `runs/gurobi-20260902-195923-bc98a2f6/result.json`
- `runs/gurobi-20260902-195923-bc98a2f6/solver.log`
- `scripts/comp12_course_lns.py`
- `scripts/comp12_curriculum_lns.py`
- `scripts/comp12_model_stats.py`
- `scripts/comp12_strengthened_solve.py`
- `solutions/comp12-2idx-known277.sol`
- `solutions/comp12-2idx-known277.sol.gz`
- `solutions/comp12-2idx-verified277.sol`
- `solutions/official-best.sol.gz`
- `solutions/official-best.validation.json`
- `structure-gurobi.log`
- `structure.json`

## Excluded files

- `input/comp12-2idx.mps.gz (460241 bytes; raw benchmark input; sha256 5c3b597c3d999d4298dfb52fd6589838445752a59590b10c0cc20744453643ce)`
