# Method selection

## Evidence at formal-solving entry

The model is a minimization MILP with 11,775 integer variables bounded in [0,1], 1,966 continuous variables, 2,220 rows, and 258,915 nonzeros. Equalities dominate (1,808 rows), while coefficients and objective weights span several orders of magnitude. The fixed diagnostic baselines found verified feasible solutions. Gurobi produced the substantially better incumbent 11,554,631.5072 with bound 10,187,876.428473013; COPT's incumbent was 105,509,471.6663 with a similar lower bound. Thus primal construction matters, but a nontrivial proof gap also remains.

## Candidate algorithms derived from structure

1. **Block-angular decomposition with linking-row coordination.** Detect components after deleting high-degree coupling rows. If there are repeated weakly coupled blocks, solve or search blocks independently while repairing linking constraints, then use the resulting solution as a warm start for a proof engine.
2. **Large-neighborhood search over structural blocks.** Starting from the verified incumbent, fix variables outside one or several incidence blocks and optimize or enumerate the selected neighborhood. This is appropriate if the detector finds medium-size blocks but no clean separability.
3. **Binary master with continuous recourse.** If continuous variables are concentrated in a small set of rows or blocks, treat bounded integer decisions as a master and recover continuous variables by row-local equations or a recourse solve. This would support Benders-style feasibility and optimality cuts.
4. **Penalty-aware constructive repair.** If large objective coefficients correspond to artificial slack or unmet-demand variables, prioritize eliminating those variables through equality-preserving exchanges. This could explain the large difference between the two baseline incumbents.

## Selected first experiment

Run a solver-independent MPS incidence decomposition detector. It measures row degrees, integer/continuous incidence, name families, coefficient scales, and connected components after progressively removing high-degree linking rows. This is the smallest test that can distinguish block decomposition, block neighborhood search, and a globally coupled fallback. It does not assert feasibility or optimality and does not use a generic MIP solver.

## Decision rule after the experiment

If removing a small number of rows yields many nontrivial components, implement a blockwise constructive/repair search and emit a candidate solution. If components remain giant, inspect whether continuous variables or expensive objective variables define a smaller master/recourse interface. If neither hypothesis holds, use the verified incumbent in a solver-assisted neighborhood or proof run, with the neighborhood chosen from measured incidence rather than parameter tuning.

No preferred external decomposition package is configured. The detector therefore uses a safe Python standard-library implementation.