#!/usr/bin/env python3
"""Solver-independent structural analysis of an MPS model and a gzip solution."""
import argparse
import collections
import gzip
import json
import math
import os
import re
import shutil


def open_text(path):
    if path.lower().endswith('.gz'):
        return gzip.open(path, 'rt', encoding='utf-8', errors='replace')
    return open(path, 'rt', encoding='utf-8', errors='replace')


def stem(name):
    s = re.sub(r'\d+$', '#', name)
    s = re.sub(r'[_\-]?\d+(?:[_\-]\d+)*$', '#', s)
    m = re.match(r'^([^0-9]{1,24})', name)
    return (m.group(1).rstrip('_-') or s) if m else s


def valclass(x):
    a = abs(x)
    if x == 0:
        return 'zero'
    if abs(a-round(a)) < 1e-10:
        if a == 1: return 'unit'
        if a <= 10: return 'integer_2_10'
        if a <= 1000: return 'integer_11_1000'
        if a <= 1e6: return 'integer_1001_1e6'
        return 'integer_gt_1e6'
    return 'fractional'


def top(counter, n=30):
    return [[k, v] for k, v in counter.most_common(n)]


def parse_mps(path):
    section = None
    objective_row = None
    row_sense = {}
    row_nz = collections.Counter()
    col_nz = collections.Counter()
    obj = collections.defaultdict(float)
    rhs = collections.defaultdict(float)
    lower = collections.defaultdict(float)
    upper = {}
    vartype = collections.defaultdict(lambda: 'C')
    integer_mode = False
    matrix_classes = collections.Counter()
    matrix_abs = []
    names = {'rows': collections.Counter(), 'cols': collections.Counter()}
    markers = 0
    with open_text(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('*'):
                continue
            toks = line.split()
            head = toks[0].upper()
            if head in {'NAME','OBJSENSE','OBJNAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA'}:
                section = head
                if head == 'ENDATA': break
                continue
            if section == 'ROWS' and len(toks) >= 2:
                sense, rn = toks[0].upper(), toks[1]
                if sense == 'N' and objective_row is None:
                    objective_row = rn
                elif sense in {'E','L','G'}:
                    row_sense[rn] = sense
                    names['rows'][stem(rn)] += 1
            elif section == 'COLUMNS' and len(toks) >= 3:
                if any('MARKER' in t.upper() for t in toks):
                    markers += 1
                    u = ' '.join(toks).upper()
                    if 'INTORG' in u: integer_mode = True
                    if 'INTEND' in u: integer_mode = False
                    continue
                var = toks[0]
                if integer_mode: vartype[var] = 'I'
                else: vartype[var] = vartype[var]
                names['cols'][stem(var)] += 1
                for i in range(1, len(toks)-1, 2):
                    rn = toks[i]
                    try: x = float(toks[i+1].replace('D','E').replace('d','e'))
                    except ValueError: continue
                    if rn == objective_row:
                        obj[var] += x
                    else:
                        row_nz[rn] += 1
                        col_nz[var] += 1
                        matrix_classes[valclass(x)] += 1
                        matrix_abs.append(abs(x))
            elif section == 'RHS' and len(toks) >= 3:
                for i in range(1, len(toks)-1, 2):
                    try: rhs[toks[i]] = float(toks[i+1].replace('D','E').replace('d','e'))
                    except ValueError: pass
            elif section == 'BOUNDS' and len(toks) >= 3:
                bt, var = toks[0].upper(), toks[2]
                x = None
                if len(toks) > 3:
                    try: x = float(toks[3].replace('D','E').replace('d','e'))
                    except ValueError: pass
                if bt in {'BV'}:
                    vartype[var] = 'I'; lower[var] = 0.0; upper[var] = 1.0
                elif bt in {'LI','UI'}:
                    vartype[var] = 'I'
                    if bt == 'LI' and x is not None: lower[var] = x
                    if bt == 'UI' and x is not None: upper[var] = x
                elif bt == 'LO' and x is not None: lower[var] = x
                elif bt == 'UP' and x is not None: upper[var] = x
                elif bt == 'FX' and x is not None: lower[var] = x; upper[var] = x
                elif bt == 'FR': lower[var] = -math.inf; upper[var] = math.inf
                elif bt == 'MI': lower[var] = -math.inf
                elif bt == 'PL': upper[var] = math.inf
    vars_all = set(vartype) | set(obj) | set(col_nz) | set(lower) | set(upper)
    obj_classes = collections.Counter(valclass(v) for v in obj.values())
    obj_values = collections.Counter(obj.values())
    rhs_classes = collections.Counter(valclass(v) for v in rhs.values())
    row_degree_hist = collections.Counter(row_nz.values())
    col_degree_hist = collections.Counter(col_nz.values())
    row_by_sense = collections.Counter(row_sense.values())
    binary = sum(1 for v in vars_all if vartype[v] == 'I' and lower[v] == 0 and upper.get(v) == 1)
    def quantiles(xs):
        if not xs: return {}
        ys = sorted(xs)
        return {str(q): ys[min(len(ys)-1, int(q*(len(ys)-1)))] for q in (0, .25, .5, .75, .9, .99, 1)}
    return {
        'objective_row': objective_row,
        'counts': {'variables': len(vars_all), 'rows': len(row_sense), 'integer': sum(vartype[v]=='I' for v in vars_all), 'binary_by_bounds': binary, 'markers': markers},
        'row_senses': dict(row_by_sense),
        'name_families': {'columns': top(names['cols'], 50), 'rows': top(names['rows'], 50)},
        'incidence': {
            'row_degree_quantiles': quantiles(list(row_nz.values())),
            'column_degree_quantiles': quantiles(list(col_nz.values())),
            'largest_rows': top(row_nz, 30),
            'largest_columns': top(col_nz, 30),
            'row_degree_histogram_top': top(row_degree_hist, 30),
            'column_degree_histogram_top': top(col_degree_hist, 30)
        },
        'matrix': {'coefficient_classes': dict(matrix_classes), 'absolute_value_quantiles': quantiles(matrix_abs)},
        'objective': {'nonzeros': len(obj), 'classes': dict(obj_classes), 'most_common_values': [[x,n] for x,n in obj_values.most_common(30)], 'minimum': min(obj.values()) if obj else None, 'maximum': max(obj.values()) if obj else None},
        'rhs': {'nonzeros_or_explicit': len(rhs), 'classes': dict(rhs_classes), 'most_common_values': [[x,n] for x,n in collections.Counter(rhs.values()).most_common(30)]}
    }


def parse_solution(path):
    assignments = []
    comments = []
    objective = None
    with open_text(path) as f:
        text = f.read()
    with open('best.sol', 'wt', encoding='utf-8', newline='\n') as out:
        out.write(text)
        if text and not text.endswith('\n'): out.write('\n')
    for line in text.splitlines():
        s = line.strip()
        if not s: continue
        if s.startswith('#'):
            comments.append(s[:500])
            m = re.search(r'objective\s+value\s*[:=]?\s*([-+0-9.eEdD]+)', s, re.I)
            if m:
                try: objective = float(m.group(1).replace('D','E').replace('d','e'))
                except ValueError: pass
            continue
        t = s.split()
        if len(t) >= 2:
            try: assignments.append((t[0], float(t[1].replace('D','E').replace('d','e'))))
            except ValueError: pass
    nonzero = [(n,v) for n,v in assignments if abs(v) > 1e-12]
    integral = sum(abs(v-round(v)) <= 1e-8 for _,v in assignments)
    return {
        'objective_from_comment': objective,
        'comments': comments[:20],
        'assignment_count': len(assignments),
        'nonzero_assignment_count': len(nonzero),
        'integral_value_count': integral,
        'nonzero_value_classes': dict(collections.Counter(valclass(v) for _,v in nonzero)),
        'nonzero_name_families': top(collections.Counter(stem(n) for n,_ in nonzero), 50),
        'nonzero_sample': [[n,v] for n,v in nonzero[:100]]
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--public-solution', required=True)
    a = ap.parse_args()
    result = parse_mps(a.model)
    with open('structural_analysis.json','w',encoding='utf-8') as f:
        json.dump(result,f,indent=2,sort_keys=True)
    sol = parse_solution(a.public_solution)
    with open('public_solution_summary.json','w',encoding='utf-8') as f:
        json.dump(sol,f,indent=2,sort_keys=True)
    with open('method_result.json','w',encoding='utf-8') as f:
        json.dump({'status':'completed','method':'solver-independent MPS and public-solution structural parser','objective':sol.get('objective_from_comment'),'artifacts':['structural_analysis.json','public_solution_summary.json','best.sol']},f,indent=2)

if __name__ == '__main__':
    main()
