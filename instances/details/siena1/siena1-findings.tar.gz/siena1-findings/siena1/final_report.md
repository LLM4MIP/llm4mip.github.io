# Final report: `siena1`

## Outcome

This experiment ended with a **partial result**: a feasible solution verified by the controller's tolerance-based Decimal checker, but no proof of optimality or infeasibility.

- Objective sense: minimization
- Best verified primal bound: **10,449,008.9**
- Best dual bound: **10,219,502.195349596**
- Absolute primal-dual difference: **229,506.704650404**
- Combined relative gap: **0.021964447235794975** (approximately **2.19644%**)
- Best primal and best dual run: `gurobi-20260903-173713-7765ec0a`
- Strict optimal runs: none
- Strict infeasible runs: none
- Final classification: **feasible, verified at tolerance; not proved optimal**

The feasibility statement is specifically a tolerance-based verification result at `1e-9`. It must not be interpreted as exact arithmetic feasibility or an optimality certificate. Solver acceptance and controller verification are separate notions; the ledger reports the latter for each solver incumbent.

## Complete termination-status review

| Run | Stack | Termination | Primal | Dual | Reported gap | Verification | Runtime (s) | Interpretation |
|---|---|---|---:|---:|---:|---|---:|---|
| `gurobi-20260903-172058-f35b1a44` | Gurobi | `NODE_LIMIT` | 1,791,742,081.586 | 10,163,179.2290023 | 0.994327766628104 | yes at `1e-9` | 7.2237789631 | Feasible incumbent only; node limit is not a proof. |
| `copt-20260903-172236-8ffcecce` | COPT | `TIMEOUT` | 105,509,471.6663 | 10,189,660.367834672 | 0.903424211998123 | yes at `1e-9` | 300.0339119434 | Feasible incumbent only; timeout is not a proof. |
| `gurobi-20260903-172233-2888c593` | Gurobi | `TIME_LIMIT` | 11,554,631.5072 | 10,187,876.428473 | 0.118286340665674 | yes at `1e-9` | 300.1999478340 | Improved feasible incumbent; time limit is not a proof. |
| `custom-20260903-173117-4a153f49` | Custom Python | `completed` | — | — | — | not checked | 1.3254053593 | The method completed but supplied no ledgered bound or checked incumbent. |
| `custom-20260903-173325-a1ba44d1` | Custom Python | `ERROR` | — | — | — | not checked | 0.0679681301 | Failed custom experiment; it established no mathematical claim. |
| `gurobi-20260903-173713-7765ec0a` | Gurobi | `TIME_LIMIT` | **10,449,008.9** | **10,219,502.195349596** | **0.021964447235795** | yes at `1e-9` | 7,200.3174650669 | Best verified incumbent and best dual bound, but no proof. |
| `gurobi-20260903-194001-e97cdb36` | Gurobi | `TIME_LIMIT` | 10,449,008.9 | 10,219,336.6403565 | 0.0219802913215497 | yes at `1e-9` | 6,000.2516140938 | Reproduced the incumbent but did not improve it or the global best dual bound. |

Every exact-solver run stopped because of a node limit or time limit. Therefore, none may be reported as optimal or infeasible. The custom completion and custom error are likewise not certificates.

## Generic-solver baseline

The controller launched a short baseline portfolio before the problem-specific research phase. The baseline consisted of:

1. A short Gurobi run ending at a node limit after about 7.22 seconds.
2. A COPT run ending by timeout after about 300.03 seconds.
3. A Gurobi run ending at its time limit after about 300.20 seconds.

The baseline established that feasible incumbents were readily available but that the initial primal-dual gaps were large. Among the approximately 300-second runs, Gurobi obtained the much stronger primal value of 11,554,631.5072, while COPT's best ledgered incumbent was 105,509,471.6663. Their dual bounds were of similar scale, around 10.19 million.

The controller-generated compressed reporting artifacts do not expose complete solver parameter dictionaries. The archival record therefore reports only parameters that can be established from the run outcomes: node-limited execution for the first Gurobi run and approximately 300-second limits for the short COPT and Gurobi runs. Thread counts and log/result destinations were controller-managed. No random seed is recorded in the reporting bundle, so no seed value is inferred or invented.

## Problem-specific research phase

Two structure-specific custom Python executions were attempted before the extended exact-solver experiments, as required by the experimental protocol. Their run identifiers are:

- `custom-20260903-173117-4a153f49` — completed in 1.3254 seconds, but produced no ledgered primal or dual bound and no checked solution.
- `custom-20260903-173325-a1ba44d1` — terminated with `ERROR` after 0.0680 seconds and produced no checked mathematical result.

These custom executions are negative or inconclusive algorithmic results rather than solver proofs. The compressed reporting bundle identifies their stack as `custom-python` but does not name their source paths or retain enough design detail to reconstruct their internal candidate-generation logic in this report. Consequently, this archive does not fabricate source filenames, algorithm steps, parameters, or random seeds. The canonical run directories and controller ledgers should be used to associate any preserved custom source files with these run IDs. Neither CaDiCaL nor DRAT-trim is documented as having been invoked, and no SAT/DRAT certificate contributed to the final claim.

After the custom attempts, two materially longer Gurobi experiments ran for approximately 7,200 and 6,000 seconds. The first found the final best incumbent and best dual bound. The second retained the same incumbent but ended with a slightly weaker run-local dual bound. Thus the additional 6,000-second experiment supplied useful evidence of a search plateau but no numerical improvement over the best prior run.

As with the baseline, the compressed archival summaries do not expose complete parameter dictionaries or a recorded random seed for these extended runs. The known effective limits were approximately 7,200 and 6,000 seconds. No unrecorded parameter choices are asserted here.

## Execution environment and reproducibility record

- Exact solvers used: Gurobi and COPT.
- Custom implementation runtime: Python standard-library environment, CPU-only.
- Configured but not documented as used: CaDiCaL and DRAT-trim.
- Custom sandbox: bubblewrap-isolated, no network, read-only model/tool inputs, private writable output directory, and controller-enforced CPU time, memory, output-file size, and thread limits.
- Machine identifier and CPU model: not present in the compressed reporting artifacts.
- Gurobi version: not present in the compressed reporting artifacts.
- COPT version: not present in the compressed reporting artifacts.
- Python version: not present in the compressed reporting artifacts.
- Exact numerical sandbox limits: not present in the compressed reporting artifacts.
- Random seeds: not recorded in the compressed reporting artifacts.

These omissions are stated explicitly to preserve reproducibility integrity. Versions, host specifications, source filenames, parameter values, and seeds must not be guessed. The machine-readable `reporting_bundle.json`, `experiments.json`, and `result.json`, together with per-run artifacts retained by the controller, are the authoritative sources if additional metadata is available there.

## Verification and proof boundary

The best incumbent was accepted by the controller's Decimal-based check at tolerance `1e-9`. This supports the label **tolerance-verified feasible**. It does not provide:

- an exact rational feasibility proof,
- an optimality certificate,
- an infeasibility certificate, or
- permission to reinterpret a limit termination as a proof.

The valid global statement is therefore:

> A solution of objective 10,449,008.9 was verified at tolerance `1e-9`; a dual bound of 10,219,502.195349596 was obtained; the remaining relative gap is approximately 2.19644%; optimality and infeasibility were not proved.

## Most informative negative result

The final 6,000-second Gurobi run did not improve the incumbent obtained by the preceding 7,200-second run. Its dual bound, 10,219,336.6403565, was also slightly weaker than the experiment-wide best of 10,219,502.195349596. This indicates that simply extending a similar branch-and-bound configuration had reached a plateau within the available budget.

The custom-method evidence was also negative: one execution supplied no checked candidate or bound, and the other failed almost immediately. No claim should be drawn from either beyond those observed outcomes.

## Recommended next experiment

If optimization work resumes in a new solving stage, preserve the verified solution as an explicit warm start and focus on the lower bound rather than repeating an unchanged long run. The next controlled experiment should:

1. Recover and audit the structure-specific custom source and its error artifact.
2. Make candidate output deterministic, record a random seed explicitly, and verify every generated candidate before solver use.
3. Start an exact solver from the incumbent 10,449,008.9.
4. Test a bound-focused formulation or decomposition derived from the model structure, with a predeclared comparison against the existing best dual bound.
5. Record host details, solver versions, complete parameter dictionaries, source paths, sandbox limits, and seeds in the run metadata.

Success should be judged primarily by exceeding the dual bound 10,219,502.195349596 or by closing the gap with a strict solver status—not merely by reproducing the incumbent.

## Authoritative archival files

- `reporting_bundle.json` — compressed controller reporting bundle
- `experiments.json` — machine-readable experiment ledger
- `experiments.md` — human-readable run table
- `result.json` — controller-managed final result
- `final_report.md` — this interpretation and archival narrative
- `README.md` — concise result overview

The controller-managed JSON and ledger files were not modified during reporting.
