# Formal-solving strategy

1. Preserve the verified incumbent value 11,554,631.5072 and lower bound 10,187,876.428473013 as the current benchmark.
2. Diagnose matrix decomposition directly from the MPS. Treat high-degree rows as candidate linking constraints and measure the components induced by the remaining rows at several degree thresholds.
3. Use the diagnostic result to build one structure-specific primal method: blockwise repair/large-neighborhood search if separability appears, or a binary-master/continuous-recourse method if the continuous interface is small.
4. Validate every emitted solution with the controller's exact checker. A custom method's objective or status is never considered proof.
5. Use Gurobi or COPT only after the structural method, either to optimize induced subproblems, improve a generated warm start, or close the global proof gap.
6. Stop only when a strict solver status or independently reproducible certificate proves optimality or infeasibility.