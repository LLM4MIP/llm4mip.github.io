# Package manifest: siena1

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 62
Excluded source files: 1

## Included files

- `README.md`
- `experiments.json`
- `experiments.md`
- `final_report.md`
- `method_selection.md`
- `methods/analyze_structure.py`
- `methods/decompose.py`
- `methods/duplicate_column_exchange.py`
- `methods/inspect_siena_structure.py`
- `reporting_bundle.json`
- `result.json`
- `runs/copt-20260903-172236-8ffcecce/best.sol`
- `runs/copt-20260903-172236-8ffcecce/driver.stderr`
- `runs/copt-20260903-172236-8ffcecce/driver.stdout`
- `runs/copt-20260903-172236-8ffcecce/result.json`
- `runs/copt-20260903-172236-8ffcecce/solver.log`
- `runs/custom-20260903-173117-4a153f49/algorithm.stderr`
- `runs/custom-20260903-173117-4a153f49/algorithm.stdout`
- `runs/custom-20260903-173117-4a153f49/decomposition.json`
- `runs/custom-20260903-173117-4a153f49/driver.stderr`
- `runs/custom-20260903-173117-4a153f49/driver.stdout`
- `runs/custom-20260903-173117-4a153f49/method_result.json`
- `runs/custom-20260903-173117-4a153f49/result.json`
- `runs/custom-20260903-173325-a1ba44d1/algorithm.stderr`
- `runs/custom-20260903-173325-a1ba44d1/algorithm.stdout`
- `runs/custom-20260903-173325-a1ba44d1/driver.stderr`
- `runs/custom-20260903-173325-a1ba44d1/driver.stdout`
- `runs/custom-20260903-173325-a1ba44d1/result.json`
- `runs/gurobi-20260903-172058-f35b1a44/best.sol`
- `runs/gurobi-20260903-172058-f35b1a44/driver.stderr`
- `runs/gurobi-20260903-172058-f35b1a44/driver.stdout`
- `runs/gurobi-20260903-172058-f35b1a44/result.json`
- `runs/gurobi-20260903-172058-f35b1a44/solver.log`
- `runs/gurobi-20260903-172233-2888c593/best.sol`
- `runs/gurobi-20260903-172233-2888c593/driver.stderr`
- `runs/gurobi-20260903-172233-2888c593/driver.stdout`
- `runs/gurobi-20260903-172233-2888c593/result.json`
- `runs/gurobi-20260903-172233-2888c593/solver.log`
- `runs/gurobi-20260903-173713-7765ec0a/best.sol`
- `runs/gurobi-20260903-173713-7765ec0a/driver.stderr`
- `runs/gurobi-20260903-173713-7765ec0a/driver.stdout`
- `runs/gurobi-20260903-173713-7765ec0a/result.json`
- `runs/gurobi-20260903-173713-7765ec0a/solver.log`
- `runs/gurobi-20260903-194001-e97cdb36/best.sol`
- `runs/gurobi-20260903-194001-e97cdb36/driver.stderr`
- `runs/gurobi-20260903-194001-e97cdb36/driver.stdout`
- `runs/gurobi-20260903-194001-e97cdb36/result.json`
- `runs/gurobi-20260903-194001-e97cdb36/solver.log`
- `solutions/public/siena1-official-5.sol.gz`
- `strategy.md`
- `structure-gurobi.log`
- `structure.json`
- `verification/copt-20260903-172236-8ffcecce.exact-check.json`
- `verification/copt-20260903-172236-8ffcecce.exact-check.txt`
- `verification/gurobi-20260903-172058-f35b1a44.exact-check.json`
- `verification/gurobi-20260903-172058-f35b1a44.exact-check.txt`
- `verification/gurobi-20260903-172233-2888c593.exact-check.json`
- `verification/gurobi-20260903-172233-2888c593.exact-check.txt`
- `verification/gurobi-20260903-173713-7765ec0a.exact-check.json`
- `verification/gurobi-20260903-173713-7765ec0a.exact-check.txt`
- `verification/gurobi-20260903-194001-e97cdb36.exact-check.json`
- `verification/gurobi-20260903-194001-e97cdb36.exact-check.txt`

## Excluded files

- `input/siena1.mps.gz (1217583 bytes; raw benchmark input; sha256 8ac80c909a24dc88ddcd6661bb5aed1da7114485c1bc0ea9876cdee37f437fde)`
