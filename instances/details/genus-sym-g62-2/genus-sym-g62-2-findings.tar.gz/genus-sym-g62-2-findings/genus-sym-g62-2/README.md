# `genus-sym-g62-2`

## Result

The original-MPS interval is **[-40, -38]**; global optimality is open.
The complete catalogue of 54,952 admissible short facial walks (length at most
12) and an exact rational dual prove a native face upper bound of
`5316188672 / 130000000 < 41`. Even face parity gives at most 40 faces.
The independently audited original-MPS implication transfers this to **LB = -40**.

The -38 witness is verified at MPS tolerance `1e-6`, not as an exact rational
zero-tolerance point. The subsequent 40-face branch tree has 25,345 nodes,
12,664 checked leaves and **9 pending subtrees**. It is not an optimum proof.

- [Latest report](../../docs/ten-instance-results-2026-09-06.zh.md)
- [Complete catalogue and rational dual](../../studies/ten-instance-2026-09-06/genus-priority/runs/20260905-shortfaces/g62-k12/)
- [Original-MPS reduction audit](../../studies/ten-instance-2026-09-06/hour-pass/runs/20260905-2h/reduction-audit/genus-sym-g62-2/)
- [Replay instructions](../../studies/ten-instance-2026-09-06/README.md)
- [MIPLIB metadata](https://miplib.zib.de/instance_details_genus-sym-g62-2.html)
- Input SHA-256: `fa5e5a27ac21e571f6561fc9a26b6148f0c88276e656baf1cd51633cd3168d2e`
