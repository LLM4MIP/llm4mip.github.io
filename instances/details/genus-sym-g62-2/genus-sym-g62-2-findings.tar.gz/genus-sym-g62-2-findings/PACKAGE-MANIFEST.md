# Package manifest: genus-sym-g62-2

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 3
Excluded source files: 1

## Included files

- `README.md`
- `solutions/official-best.sol.gz`
- `solutions/official-best.validation.json`

## Excluded files

- `input/genus-sym-g62-2.mps.gz (1596247 bytes; raw benchmark input; sha256 fa5e5a27ac21e571f6561fc9a26b6148f0c88276e656baf1cd51633cd3168d2e)`
