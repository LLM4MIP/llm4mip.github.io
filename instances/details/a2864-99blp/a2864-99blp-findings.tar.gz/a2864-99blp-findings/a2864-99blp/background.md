# Background

## Mathematical abstraction

The model minimizes `-sum_j x_j` over 200,787 binary variables subject to 22,100 unit-coefficient packing inequalities and 17 unit-coefficient equalities. Equivalently, it maximizes the cardinality of a selected family under capacitated hypergraph-packing constraints and a small equality subsystem. A candidate can be checked incrementally with row loads and residual capacities; the equality subsystem must be preserved or explicitly repaired.

## Problem classification

Formulation class: pure binary set packing with invariant-knapsack/equality side constraints.

Application/combinatorial family: clique/partial-spread selection in finite projective geometry, specifically a subspace-selection problem related to partial plane spreads in `PG(7,2)`. This classification has high confidence because it is stated on the official MIPLIB instance page and is consistent with the all-unit incidence matrix and cardinality objective.

## Structural evidence

The controller-generated Gurobi profile reports 200,787 binary variables, 22,117 rows, and 20,078,717 unit matrix coefficients. There are 22,100 inequalities and 17 equalities; all variable bounds are 0/1, all objective coefficients are -1, and right-hand sides range from 1 to 17. Average incidence is about 908 variables per row and 100 rows per variable. Explicit construction of the full conflict graph may be too large, whereas compressed row-to-column and column-to-row incidence arrays are practical. Unit coefficients permit exact integer feasibility updates without floating-point ambiguity.

## Known results and target bounds

The official MIPLIB page reports a feasible objective **-257**, corresponding to a cardinality-257 selection. The official solution was downloaded from `https://miplib.zib.de/downloads/solutions/a2864-99blp/1/a2864-99blp.sol.gz` to `solutions/public/a2864-99blp.sol.gz`; its compressed SHA-256 is `e55fed5c29c2c87229c180aaed36912557d3477a995395d5837f4257f818c58f`. It must be independently checked against the exact local MPS before it is treated as experiment-verified evidence.

The two 120-second diagnostic baselines each produced an independently verified feasible objective -72 and a valid dual bound -13841. Thus -72 is the current experiment incumbent, not the public target. Using the public primal `P=-257` and diagnostic dual `D=-13841`, the relative gap is `13584/13841 = 0.9814319774582761`. No optimality proof or documented public dual bound has been established.

For minimization, lower primal values and higher dual values are better. A new primal record must be below -257; a useful experiment should first import and exactly verify the public -257 solution. A valid dual improvement must exceed -13841.

## Standard methods for this class

Relevant exact methods include maximum-clique/set-packing branch-and-cut with clique and lifted packing cuts, symmetry breaking from finite-geometry automorphisms, orbit-based branching, and exact decision formulations at a fixed target cardinality. Primal methods include scarcity-weighted greedy construction, equality-signature repair, ejection-chain or k-exchange local search, adaptive row pricing, and elite-set relinking. Globally valid bounds can come from Lagrangian relaxation with independently checked multipliers, combinatorial counting/Delsarte-style inequalities, orbit aggregation, or a checked pseudo-Boolean/SAT certificate for a fixed cardinality threshold.

## Instance-specific opportunities and risks

The cardinality objective, unit coefficients, and small equality subsystem favor exact incremental local search and equality-signature grouping. Finite-geometry symmetry may permit orbit reduction, but a guessed symmetry action must be verified before use. The 20-million-entry matrix makes repeated full scans costly. The LP relaxation is numerically problematic according to the official description, so floating-point bounds require outward-safe recomputation. A method that merely improves -72 but does not reach the public -257 solution is not a public improvement.

## Sources

- MIPLIB instance page, accessed 2026-09-04: https://miplib.zib.de/instance_details_a2864-99blp.html
- Official MIPLIB solution download: https://miplib.zib.de/downloads/solutions/a2864-99blp/1/a2864-99blp.sol.gz
- Honold, Kiermaier, and Kurz, “Classification of large partial plane spreads in PG(6,2) and related combinatorial objects,” cited by the MIPLIB page.
- Controller-generated `structure.json` and the two diagnostic baseline result files in `experiments.json`.

