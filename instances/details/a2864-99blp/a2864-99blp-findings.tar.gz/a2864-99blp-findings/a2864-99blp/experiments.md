# Experiment ledger

This file is generated from `runs/*/result.json` by the controller.

| Run | Solver | Status | Primal | Dual | Gap | Verified | Runtime (s) |
|---|---|---|---:|---:|---:|---|---:|
| `copt-20260904-224439-f6080e4d` | copt | TIMEOUT | -72 | -13841 | 0.994798063723719 | yes @ 1e-9 | 120.223058223724 |
| `custom-20260904-225213-2180ebd7` | custom-python | success | -72 | — | — | yes @ 1e-9 | 37.0619440078735 |
| `custom-20260904-225229-7ab3efb8` | custom-python | success | -72 | — | — | yes @ 1e-9 | 39.3429045677185 |
| `custom-20260904-230317-b2511486` | custom-python | completed | — | — | — | not checked | 92.7847058773041 |
| `custom-20260904-231314-3ef592ad` | custom-python | success | — | — | — | not checked | 108.989012718201 |
| `custom-20260904-231859-255c62e3` | custom-python | unsupported | — | — | — | not checked | 48.560111284256 |
| `gurobi-20260904-224426-87e3f98f` | gurobi | TIME_LIMIT | -72 | -13841 | 191.236111111111 | yes @ 1e-9 | 120.526580095291 |
