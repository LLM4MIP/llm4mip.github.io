#!/usr/bin/env python3
"""Exact, standard-library audit of the MIPLIB instance a2864-99blp.

The verifier reconstructs PG(7,2) from incidence alone.  It deliberately does
not assume that the MPS point or column numbering agrees with any published
finite-geometry enumeration.

The first pass through the MPS:

* intersects the point supports of all columns incident with each alleged
  line, recovering that line's three points;
* records every column's point and line incidences compactly;
* checks the complete matrix fingerprint; and
* independently accumulates all row activities of the supplied solution.

It then coordinatizes the recovered Steiner triple system by greedily choosing
point representatives of an eight-dimensional vector-space basis.  Finally,
it checks that every one of the
200,787 columns is a distinct 4-dimensional subspace of GF(2)^8 and that its
35 line-row incidences are exactly the 35 lines contained in that subspace.

Only Python's standard library is required.  No optimizer is invoked.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
import sys
import time
from array import array
from collections import Counter
from fractions import Fraction
from itertools import combinations
from pathlib import Path
from typing import Iterable, TextIO


N_POINTS = 255
N_LINES = 10_795
N_COLUMNS = 200_787
N_ROWS = 22_117

POINT_FIRST = 0
POINT_LAST = 254
LINE_FIRST = 255
LINE_LAST = 11_049
SIXSPACE_FIRST = 11_050
SIXSPACE_LAST = 21_844
HYPERPLANE_FIRST = 21_845
HYPERPLANE_LAST = 22_099
FIX_FIRST = 22_100
FIX_LAST = 22_116

ALL_POINT_BITS = (1 << N_POINTS) - 1


def popcount(value: int) -> int:
    """Python-3.9-compatible population count."""
    return bin(value).count("1")


def open_text(path: Path) -> TextIO:
    if path.suffix == ".gz":
        return gzip.open(path, "rt", encoding="ascii", newline="")
    return path.open("rt", encoding="ascii", newline="")


def row_index(name: str) -> int:
    if not name.startswith("R"):
        raise AssertionError(f"unexpected row name {name!r}")
    value = int(name[1:])
    if not 0 <= value < N_ROWS:
        raise AssertionError(f"row index out of range: {name!r}")
    return value


def variable_index(name: str) -> int:
    if not name.startswith("x"):
        raise AssertionError(f"unexpected variable name {name!r}")
    value = int(name[1:]) - 1
    if not 0 <= value < N_COLUMNS:
        raise AssertionError(f"variable index out of range: {name!r}")
    return value


def iter_set_bits(bits: int) -> Iterable[int]:
    while bits:
        low = bits & -bits
        yield low.bit_length() - 1
        bits ^= low


def gf2_rank(vectors: Iterable[int]) -> int:
    pivots = [0] * 8
    rank = 0
    for vector in vectors:
        value = vector
        while value:
            pivot = value.bit_length() - 1
            if pivots[pivot]:
                value ^= pivots[pivot]
            else:
                pivots[pivot] = value
                rank += 1
                break
    return rank


def rref_basis(vectors: Iterable[int]) -> tuple[int, ...]:
    """Return the unique RREF basis, taking bit 7 as the leftmost column."""
    rows = [value for value in vectors if value]
    pivot_row = 0
    pivot_columns: list[int] = []
    for pivot in range(7, -1, -1):
        candidate = next(
            (row for row in range(pivot_row, len(rows)) if (rows[row] >> pivot) & 1),
            None,
        )
        if candidate is None:
            continue
        rows[pivot_row], rows[candidate] = rows[candidate], rows[pivot_row]
        for row in range(len(rows)):
            if row != pivot_row and ((rows[row] >> pivot) & 1):
                rows[row] ^= rows[pivot_row]
        pivot_columns.append(pivot)
        pivot_row += 1
    basis = tuple(rows[:pivot_row])
    if any(value == 0 for value in basis):
        raise AssertionError("zero row in computed RREF basis")
    for row, pivot in enumerate(pivot_columns):
        if ((basis[row] >> pivot) & 1) != 1:
            raise AssertionError("missing pivot in computed RREF basis")
        if any(((basis[other] >> pivot) & 1) for other in range(len(basis)) if other != row):
            raise AssertionError("nonzero off-pivot entry in computed RREF basis")
    return basis


def gaussian_binomial(n: int, k: int, q: int = 2) -> int:
    numerator = math.prod(q ** (n - i) - 1 for i in range(k))
    denominator = math.prod(q ** (k - i) - 1 for i in range(k))
    assert numerator % denominator == 0
    return numerator // denominator


def parse_solution(path: Path) -> tuple[set[int], Fraction, int]:
    selected: set[int] = set()
    seen = bytearray(N_COLUMNS)
    declared_objective: Fraction | None = None
    assignments = 0
    with open_text(path) as stream:
        for raw in stream:
            fields = raw.split()
            if not fields or fields[0].startswith("#"):
                continue
            if fields[0] == "=obj=":
                if len(fields) != 2 or declared_objective is not None:
                    raise AssertionError("malformed or repeated objective line")
                declared_objective = Fraction(fields[1])
                continue
            if len(fields) != 2:
                raise AssertionError(f"malformed solution line: {raw.rstrip()!r}")
            index = variable_index(fields[0])
            if seen[index]:
                raise AssertionError(f"duplicate solution assignment for {fields[0]}")
            seen[index] = 1
            assignments += 1
            value = Fraction(fields[1])
            if value not in (0, 1):
                raise AssertionError(f"nonbinary solution value {fields[0]}={value}")
            if value == 1:
                selected.add(index)
    if declared_objective is None:
        raise AssertionError("solution has no declared objective")
    if assignments != N_COLUMNS or any(value == 0 for value in seen):
        raise AssertionError(
            f"solution specifies {assignments} variables; expected all {N_COLUMNS}"
        )
    if declared_objective != -len(selected):
        raise AssertionError(
            f"declared objective {declared_objective} != {-len(selected)}"
        )
    return selected, declared_objective, assignments


def parse_mps(
    path: Path, selected: set[int]
) -> tuple[
    list[int],
    array,
    list[int],
    list[str],
    list[Fraction],
    array,
    array,
    dict[str, object],
]:
    """Parse and audit the MPS in one streaming pass."""
    section: str | None = None
    senses = [""] * N_ROWS
    rhs = [Fraction(0)] * N_ROWS
    row_degrees = array("I", [0]) * N_ROWS
    selected_activity = array("H", [0]) * N_ROWS
    line_candidates = [ALL_POINT_BITS] * N_LINES
    point_masks: list[int] = []
    # Each audited column has exactly 35 lines, so offsets are implicit.
    column_lines = array("H")
    bound_seen = bytearray(N_COLUMNS)
    in_integer_block = False
    integer_marker_count = 0
    objective_coefficients = Counter()
    matrix_coefficients = Counter()

    current_name: str | None = None
    current_index: int | None = None
    current_rows: list[int] = []
    current_point_bits = 0
    current_lines: list[int] = []
    current_sixspaces = 0
    current_hyperplanes = 0
    current_fixes = 0
    current_objective: Fraction | None = None
    columns_flushed = 0

    def flush_column() -> None:
        nonlocal current_name, current_index, current_rows, current_point_bits
        nonlocal current_lines, current_sixspaces, current_hyperplanes
        nonlocal current_fixes, current_objective, columns_flushed
        if current_name is None:
            return
        assert current_index is not None
        if current_index != columns_flushed:
            raise AssertionError(
                f"columns are not exactly x1,... in order at {current_name}"
            )
        if current_objective != -1:
            raise AssertionError(
                f"{current_name} objective is {current_objective}, not -1"
            )
        point_count = popcount(current_point_bits)
        if (
            point_count,
            len(current_lines),
            current_sixspaces,
            current_hyperplanes,
        ) != (15, 35, 35, 15):
            raise AssertionError(
                f"{current_name} block counts are "
                f"{point_count,len(current_lines),current_sixspaces,current_hyperplanes}"
            )
        if current_fixes not in (0, 1):
            raise AssertionError(f"{current_name} occurs in {current_fixes} fixed rows")
        point_masks.append(current_point_bits)
        column_lines.extend(current_lines)
        for line in current_lines:
            line_candidates[line] &= current_point_bits
        if current_index in selected:
            for row in current_rows:
                selected_activity[row] += 1
        columns_flushed += 1
        current_name = None
        current_index = None
        current_rows = []
        current_point_bits = 0
        current_lines = []
        current_sixspaces = 0
        current_hyperplanes = 0
        current_fixes = 0
        current_objective = None

    with open_text(path) as stream:
        for raw in stream:
            fields = raw.split()
            if not fields or fields[0].startswith("*"):
                continue
            keyword = fields[0]
            if keyword in {
                "NAME",
                "ROWS",
                "COLUMNS",
                "RHS",
                "RANGES",
                "BOUNDS",
                "ENDATA",
            }:
                if section == "COLUMNS" and keyword != "COLUMNS":
                    flush_column()
                section = keyword
                continue

            if section == "ROWS":
                sense, name = fields[:2]
                if sense == "N":
                    if name != "OBJ":
                        raise AssertionError(f"unexpected free row {name}")
                else:
                    index = row_index(name)
                    if senses[index]:
                        raise AssertionError(f"duplicate row {name}")
                    senses[index] = sense
            elif section == "COLUMNS":
                if len(fields) >= 2 and fields[1].strip("'") == "MARKER":
                    flush_column()
                    marker = fields[-1].strip("'")
                    if marker == "INTORG":
                        if in_integer_block:
                            raise AssertionError("nested INTORG marker")
                        in_integer_block = True
                        integer_marker_count += 1
                    elif marker == "INTEND":
                        if not in_integer_block:
                            raise AssertionError("INTEND without INTORG")
                        in_integer_block = False
                        integer_marker_count += 1
                    else:
                        raise AssertionError(f"unexpected marker {marker}")
                    continue
                name = fields[0]
                if name != current_name:
                    flush_column()
                    current_name = name
                    current_index = variable_index(name)
                    if not in_integer_block:
                        raise AssertionError(f"{name} is outside the integer marker block")
                for position in range(1, len(fields), 2):
                    row_name = fields[position]
                    coefficient = Fraction(fields[position + 1])
                    if row_name == "OBJ":
                        if current_objective is not None:
                            raise AssertionError(f"duplicate objective entry for {name}")
                        current_objective = coefficient
                        objective_coefficients[coefficient] += 1
                        continue
                    row = row_index(row_name)
                    if coefficient != 1:
                        raise AssertionError(
                            f"nonunit matrix coefficient {name},{row_name}={coefficient}"
                        )
                    matrix_coefficients[coefficient] += 1
                    row_degrees[row] += 1
                    current_rows.append(row)
                    if POINT_FIRST <= row <= POINT_LAST:
                        point = row - POINT_FIRST
                        bit = 1 << point
                        if current_point_bits & bit:
                            raise AssertionError(f"duplicate point row in {name}")
                        current_point_bits |= bit
                    elif LINE_FIRST <= row <= LINE_LAST:
                        current_lines.append(row - LINE_FIRST)
                    elif SIXSPACE_FIRST <= row <= SIXSPACE_LAST:
                        current_sixspaces += 1
                    elif HYPERPLANE_FIRST <= row <= HYPERPLANE_LAST:
                        current_hyperplanes += 1
                    else:
                        assert FIX_FIRST <= row <= FIX_LAST
                        current_fixes += 1
            elif section == "RHS":
                for position in range(1, len(fields), 2):
                    row = row_index(fields[position])
                    value = Fraction(fields[position + 1])
                    if rhs[row] != 0:
                        raise AssertionError(f"duplicate RHS for R{row}")
                    rhs[row] = value
            elif section == "RANGES":
                raise AssertionError("unexpected RANGES entries")
            elif section == "BOUNDS":
                bound_type, _bound_set, name = fields[:3]
                if bound_type != "BV":
                    raise AssertionError(f"unexpected bound type {bound_type} for {name}")
                index = variable_index(name)
                if bound_seen[index]:
                    raise AssertionError(f"duplicate bound for {name}")
                bound_seen[index] = 1

    if columns_flushed != N_COLUMNS:
        raise AssertionError(f"parsed {columns_flushed} columns, expected {N_COLUMNS}")
    if in_integer_block:
        raise AssertionError("unterminated integer marker block")
    if integer_marker_count != 2:
        raise AssertionError(f"saw {integer_marker_count} integer markers")
    if any(value == 0 for value in bound_seen):
        raise AssertionError("not every variable has a BV bound")
    if objective_coefficients != Counter({Fraction(-1): N_COLUMNS}):
        raise AssertionError(f"objective fingerprint failed: {objective_coefficients}")
    if matrix_coefficients != Counter({Fraction(1): 20_078_717}):
        raise AssertionError(f"matrix coefficient fingerprint failed: {matrix_coefficients}")

    if senses[:FIX_FIRST] != ["L"] * FIX_FIRST:
        raise AssertionError("the first 22,100 rows are not all <= rows")
    if senses[FIX_FIRST:] != ["E"] * (N_ROWS - FIX_FIRST):
        raise AssertionError("the final 17 rows are not all equality rows")
    if rhs[POINT_FIRST : POINT_LAST + 1] != [Fraction(17)] * N_POINTS:
        raise AssertionError("point RHS values are not all 17")
    if rhs[LINE_FIRST : LINE_LAST + 1] != [Fraction(1)] * N_LINES:
        raise AssertionError("line RHS values are not all 1")
    if rhs[SIXSPACE_FIRST : SIXSPACE_LAST + 1] != [Fraction(1)] * N_LINES:
        raise AssertionError("six-space RHS values are not all 1")
    if rhs[HYPERPLANE_FIRST : HYPERPLANE_LAST + 1] != [Fraction(17)] * N_POINTS:
        raise AssertionError("hyperplane RHS values are not all 17")
    if rhs[FIX_FIRST:] != [Fraction(1)] * (N_ROWS - FIX_FIRST):
        raise AssertionError("prescribed-variable RHS values are not all 1")

    expected_degrees = (
        [11_811] * N_POINTS
        + [651] * N_LINES
        + [651] * N_LINES
        + [11_811] * N_POINTS
        + [1] * 17
    )
    if list(row_degrees) != expected_degrees:
        mismatches = [
            (row, degree, expected_degrees[row])
            for row, degree in enumerate(row_degrees)
            if degree != expected_degrees[row]
        ]
        raise AssertionError(f"row-degree mismatch, first entries: {mismatches[:10]}")

    metadata: dict[str, object] = {
        "columns": columns_flushed,
        "rows": N_ROWS,
        "matrix_nonzeros": sum(row_degrees),
        "objective_nonzeros": sum(objective_coefficients.values()),
        "integer_marker_lines": integer_marker_count,
        "all_variables_binary": True,
        "all_matrix_coefficients_one": True,
        "all_objective_coefficients_minus_one": True,
    }
    return (
        point_masks,
        column_lines,
        line_candidates,
        senses,
        rhs,
        row_degrees,
        selected_activity,
        metadata,
    )


def reconstruct_lines(
    line_candidates: list[int],
) -> tuple[list[tuple[int, int, int]], dict[tuple[int, int], tuple[int, int]]]:
    triples: list[tuple[int, int, int]] = []
    pair_map: dict[tuple[int, int], tuple[int, int]] = {}
    for line, candidate in enumerate(line_candidates):
        points = tuple(iter_set_bits(candidate))
        if len(points) != 3:
            raise AssertionError(
                f"line row R{LINE_FIRST + line} has point-support intersection {points}"
            )
        triples.append(points)
        for first, second in combinations(points, 2):
            key = (first, second)
            third = candidate ^ (1 << first) ^ (1 << second)
            third_point = third.bit_length() - 1
            if key in pair_map:
                raise AssertionError(
                    f"point pair {key} occurs in lines {pair_map[key][0]} and {line}"
                )
            pair_map[key] = (line, third_point)
    expected_pairs = math.comb(N_POINTS, 2)
    if len(pair_map) != expected_pairs:
        raise AssertionError(f"covered {len(pair_map)} point pairs, expected {expected_pairs}")
    return triples, pair_map


def coordinatize(
    triples: list[tuple[int, int, int]],
    pair_map: dict[tuple[int, int], tuple[int, int]],
) -> tuple[list[int], list[int], list[int]]:
    coordinates = [0] * N_POINTS
    vector_to_point: dict[int, int] = {}
    basis: list[int] = []
    span_sizes: list[int] = []

    for dimension in range(8):
        new_point = next(point for point, value in enumerate(coordinates) if value == 0)
        new_vector = 1 << dimension
        basis.append(new_point)
        old_span = list(vector_to_point.items())
        coordinates[new_point] = new_vector
        vector_to_point[new_vector] = new_point
        for vector, old_point in old_span:
            key = tuple(sorted((new_point, old_point)))
            _line, third = pair_map[key]
            combined = new_vector ^ vector
            if coordinates[third] not in (0, combined):
                raise AssertionError(
                    f"inconsistent coordinate for point {third}: "
                    f"{coordinates[third]} versus {combined}"
                )
            if combined in vector_to_point and vector_to_point[combined] != third:
                raise AssertionError(f"coordinate {combined} assigned to two points")
            coordinates[third] = combined
            vector_to_point[combined] = third
        expected_size = 2 ** (dimension + 1) - 1
        if len(vector_to_point) != expected_size:
            raise AssertionError(
                f"span after basis point {new_point} has {len(vector_to_point)} points, "
                f"expected {expected_size}"
            )
        span_sizes.append(expected_size)

    if set(coordinates) != set(range(1, 256)):
        raise AssertionError("point coordinates are not a bijection onto GF(2)^8 minus zero")
    for line, points in enumerate(triples):
        if coordinates[points[0]] ^ coordinates[points[1]] ^ coordinates[points[2]]:
            raise AssertionError(f"line {line} does not satisfy a xor b xor c = 0")
    return coordinates, basis, span_sizes


def standard_rref_point_coordinates() -> list[int]:
    """Decode the MPS's explicit one-row RREF ordering of the 255 points.

    The point blocks have sizes 128,64,...,1.  Within the block whose pivot is
    coordinate ``k``, the free entries to its right are counted with coordinate
    ``k+1`` as the least-significant bit.  Thus row R0 is 0x01, R1 is 0x03,
    R128 is 0x02, and so on.
    """
    result: list[int] = []
    row = 0
    for pivot in range(8):
        block_size = 1 << (7 - pivot)
        for offset in range(block_size):
            result.append((1 << pivot) | (offset << (pivot + 1)))
            row += 1
    if row != N_POINTS or set(result) != set(range(1, 256)):
        raise AssertionError("explicit RREF point enumeration is not a bijection")
    return result


def verify_coordinate_agreement(
    incidence_coordinates: list[int],
    standard_coordinates: list[int],
    basis: list[int],
    triples: list[tuple[int, int, int]],
) -> dict[str, object]:
    """Show that the two independently obtained coordinate systems are linear."""
    basis_images = [standard_coordinates[point] for point in basis]
    if gf2_rank(basis_images) != 8:
        raise AssertionError("greedy incidence basis is not a basis in RREF coordinates")
    for point, incidence_vector in enumerate(incidence_coordinates):
        transformed = 0
        for dimension in range(8):
            if (incidence_vector >> dimension) & 1:
                transformed ^= basis_images[dimension]
        if transformed != standard_coordinates[point]:
            raise AssertionError(
                f"coordinate systems disagree at R{point}: "
                f"linear image {transformed:02x} != RREF {standard_coordinates[point]:02x}"
            )
    for line, points in enumerate(triples):
        if (
            standard_coordinates[points[0]]
            ^ standard_coordinates[points[1]]
            ^ standard_coordinates[points[2]]
        ):
            raise AssertionError(f"line {line} fails xor in explicit RREF coordinates")
    return {
        "explicit_rref_coordinate_formula": "(1 << pivot) | (offset << (pivot + 1))",
        "explicit_rref_coordinate_image": "all nonzero vectors of GF(2)^8",
        "greedy_basis_images_in_rref_hex": [f"{value:02x}" for value in basis_images],
        "coordinate_systems_related_by_verified_invertible_linear_map": True,
        "all_line_triples_xor_to_zero_in_both_coordinate_systems": True,
    }


def verify_columns(
    point_masks: list[int],
    column_lines: array,
    coordinates: list[int],
    pair_map: dict[tuple[int, int], tuple[int, int]],
) -> dict[str, object]:
    subspaces: set[int] = set()
    column_digest = hashlib.sha256()
    rref_digest = hashlib.sha256()
    rank_counts: Counter[int] = Counter()

    for column, point_bits in enumerate(point_masks):
        points = list(iter_set_bits(point_bits))
        vectors = [coordinates[point] for point in points]
        rank = gf2_rank(vectors)
        rank_counts[rank] += 1
        if rank != 4:
            raise AssertionError(f"x{column + 1} point support has GF(2) rank {rank}")
        vector_set = set(vectors)
        if len(vector_set) != 15:
            raise AssertionError(f"x{column + 1} has repeated point coordinates")
        with_zero = vector_set | {0}
        for first in with_zero:
            for second in with_zero:
                if first ^ second not in with_zero:
                    raise AssertionError(f"x{column + 1} is not xor-closed")

        subspace_bits = sum(1 << vector for vector in vector_set)
        if subspace_bits in subspaces:
            raise AssertionError(f"x{column + 1} duplicates an earlier 4-space")
        subspaces.add(subspace_bits)

        predicted_lines: set[int] = set()
        for first, second in combinations(points, 2):
            line, _third = pair_map[(first, second)]
            predicted_lines.add(line)
        if len(predicted_lines) != 35:
            raise AssertionError(
                f"x{column + 1} contains {len(predicted_lines)} recovered lines, not 35"
            )
        start = 35 * column
        actual_lines = set(column_lines[start : start + 35])
        if len(actual_lines) != 35:
            raise AssertionError(f"x{column + 1} repeats a line row")
        if actual_lines != predicted_lines:
            missing = sorted(predicted_lines - actual_lines)
            extra = sorted(actual_lines - predicted_lines)
            raise AssertionError(
                f"x{column + 1} line incidence mismatch: missing={missing}, extra={extra}"
            )

        encoded = f"x{column + 1}\t" + ",".join(f"{v:02x}" for v in sorted(vectors)) + "\n"
        column_digest.update(encoded.encode("ascii"))
        basis = rref_basis(vectors)
        if len(basis) != 4:
            raise AssertionError(f"x{column + 1} RREF basis has length {len(basis)}")
        rref_digest.update(
            (f"x{column + 1}\t" + ",".join(f"{v:02x}" for v in basis) + "\n").encode(
                "ascii"
            )
        )

    universe_size = gaussian_binomial(8, 4, 2)
    if len(subspaces) != N_COLUMNS or universe_size != N_COLUMNS:
        raise AssertionError(
            f"found {len(subspaces)} distinct spaces; GF(2)^8 has {universe_size} 4-spaces"
        )
    return {
        "columns_checked": len(point_masks),
        "rank_histogram": {str(key): value for key, value in sorted(rank_counts.items())},
        "distinct_4_spaces": len(subspaces),
        "gaussian_binomial_8_choose_4_q2": universe_size,
        "all_column_line_incidence_sets_exact": True,
        "ordered_column_point_coordinate_sha256": column_digest.hexdigest(),
        "ordered_column_rref_basis_sha256": rref_digest.hexdigest(),
    }


def verify_solution(
    selected: set[int],
    declared_objective: Fraction,
    senses: list[str],
    rhs: list[Fraction],
    activity: array,
) -> dict[str, object]:
    violations: list[tuple[int, int, str, str]] = []
    for row, (sense, bound) in enumerate(zip(senses, rhs)):
        value = int(activity[row])
        if sense == "L":
            valid = value <= bound
        elif sense == "E":
            valid = value == bound
        else:
            raise AssertionError(f"unexpected sense {sense!r} in row {row}")
        if not valid:
            violations.append((row, value, sense, str(bound)))
    if violations:
        raise AssertionError(f"solution row violations, first entries: {violations[:10]}")
    line_activity = activity[LINE_FIRST : LINE_LAST + 1]
    return {
        "assignments_checked": N_COLUMNS,
        "selected_columns": len(selected),
        "computed_objective": -len(selected),
        "declared_objective": str(declared_objective),
        "row_violations": 0,
        "maximum_line_row_activity": max(line_activity),
        "maximum_point_row_activity": max(activity[POINT_FIRST : POINT_LAST + 1]),
        "maximum_six_space_row_activity": max(
            activity[SIXSPACE_FIRST : SIXSPACE_LAST + 1]
        ),
        "maximum_hyperplane_row_activity": max(
            activity[HYPERPLANE_FIRST : HYPERPLANE_LAST + 1]
        ),
        "selected_line_activity_histogram": {
            str(key): value for key, value in sorted(Counter(line_activity).items())
        },
        "all_17_prescribed_equalities_satisfied": all(
            activity[row] == 1 for row in range(FIX_FIRST, FIX_LAST + 1)
        ),
    }


def write_coordinate_tables(
    output_directory: Path,
    standard_coordinates: list[int],
    incidence_coordinates: list[int],
    basis: list[int],
    triples: list[tuple[int, int, int]],
) -> tuple[Path, Path]:
    output_directory.mkdir(parents=True, exist_ok=True)
    point_path = output_directory / "a2864-99blp_point_coordinates.tsv"
    line_path = output_directory / "a2864-99blp_line_coordinates.tsv"
    basis_set = set(basis)
    with point_path.open("wt", encoding="ascii", newline="") as stream:
        stream.write(
            "mps_point_row\tpoint_index\trref_vector_hex\trref_vector_bits\t"
            "incidence_vector_hex\tgreedy_basis\n"
        )
        for point, vector in enumerate(standard_coordinates):
            stream.write(
                f"R{point}\t{point}\t{vector:02x}\t{vector:08b}\t"
                f"{incidence_coordinates[point]:02x}\t"
                f"{1 if point in basis_set else 0}\n"
            )
    with line_path.open("wt", encoding="ascii", newline="") as stream:
        stream.write(
            "mps_line_row\tline_index\tpoint_rows\tgf2_vectors_hex\txor_zero\n"
        )
        for line, points in enumerate(triples):
            vectors = tuple(standard_coordinates[point] for point in points)
            stream.write(
                f"R{LINE_FIRST + line}\t{line}\t"
                f"{','.join('R' + str(point) for point in points)}\t"
                f"{','.join(f'{vector:02x}' for vector in vectors)}\t"
                f"{1 if vectors[0] ^ vectors[1] ^ vectors[2] == 0 else 0}\n"
            )
    return point_path, line_path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def uncompressed_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with open_text(path) as stream:
        for block in iter(lambda: stream.read(1 << 20), ""):
            digest.update(block.encode("ascii"))
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument(
        "--output-directory",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "artifacts",
    )
    args = parser.parse_args()
    started = time.monotonic()

    selected, declared_objective, assignments = parse_solution(args.solution)
    print(
        f"solution parsed: assignments={assignments}, selected={len(selected)}, "
        f"objective={declared_objective}",
        flush=True,
    )
    (
        point_masks,
        column_lines,
        line_candidates,
        senses,
        rhs,
        row_degrees,
        selected_activity,
        model_audit,
    ) = parse_mps(args.mps, selected)
    print(
        f"MPS parsed: rows={N_ROWS}, columns={len(point_masks)}, "
        f"matrix_nonzeros={sum(row_degrees)}",
        flush=True,
    )

    triples, pair_map = reconstruct_lines(line_candidates)
    print(
        f"lines reconstructed: triples={len(triples)}, point_pairs={len(pair_map)}",
        flush=True,
    )
    incidence_coordinates, basis, span_sizes = coordinatize(triples, pair_map)
    standard_coordinates = standard_rref_point_coordinates()
    coordinate_agreement = verify_coordinate_agreement(
        incidence_coordinates, standard_coordinates, basis, triples
    )
    print(
        "vector-space basis representatives: "
        + ",".join(f"R{point}" for point in basis)
        + f"; span_sizes={span_sizes}; explicit RREF numbering agrees linearly",
        flush=True,
    )

    column_audit = verify_columns(
        point_masks, column_lines, standard_coordinates, pair_map
    )
    print(
        f"columns verified: distinct_4_spaces={column_audit['distinct_4_spaces']}, "
        "all 35-line incidence sets exact=yes",
        flush=True,
    )
    solution_audit = verify_solution(
        selected, declared_objective, senses, rhs, selected_activity
    )
    print(
        f"solution verified: objective={solution_audit['computed_objective']}, "
        "row_violations=0",
        flush=True,
    )

    point_path, line_path = write_coordinate_tables(
        args.output_directory,
        standard_coordinates,
        incidence_coordinates,
        basis,
        triples,
    )
    report = {
        "status": "exact_pass",
        "verifier": str(Path(__file__)),
        "verifier_sha256": sha256(Path(__file__)),
        "model": str(args.mps),
        "model_sha256": sha256(args.mps),
        "model_uncompressed_sha256": uncompressed_sha256(args.mps),
        "solution": str(args.solution),
        "solution_sha256": sha256(args.solution),
        "elapsed_seconds": time.monotonic() - started,
        "row_partition": {
            "points": [POINT_FIRST, POINT_LAST],
            "lines": [LINE_FIRST, LINE_LAST],
            "six_spaces": [SIXSPACE_FIRST, SIXSPACE_LAST],
            "hyperplanes": [HYPERPLANE_FIRST, HYPERPLANE_LAST],
            "prescribed_equalities": [FIX_FIRST, FIX_LAST],
        },
        "model_audit": model_audit,
        "line_reconstruction": {
            "lines": len(triples),
            "points_per_line": 3,
            "covered_unordered_point_pairs": len(pair_map),
            "expected_unordered_point_pairs": math.comb(N_POINTS, 2),
            "steiner_triple_system_exact": True,
        },
        "coordinatization": {
            "basis_point_rows": [f"R{point}" for point in basis],
            "basis_vectors_hex": [f"{1 << dimension:02x}" for dimension in range(8)],
            "span_sizes": span_sizes,
            "coordinate_image": "all nonzero vectors of GF(2)^8",
            "all_line_triples_xor_to_zero": True,
            "independent_explicit_rref_check": coordinate_agreement,
        },
        "column_audit": column_audit,
        "solution_audit": solution_audit,
        "logical_conclusion": {
            "mps_feasible_set_maps_into_A_2_8_6_4_codes": True,
            "reason": (
                "Each column is a 4-space; every contained line is represented "
                "by a <=1 row, so two selected 4-spaces intersect in dimension at "
                "most one and have subspace distance at least six."
            ),
            "published_upper_bound": 257,
            "verified_feasible_cardinality": len(selected),
            "certified_mps_optimum": -257,
        },
        "coordinate_tables": {
            "points": str(point_path),
            "points_sha256": sha256(point_path),
            "lines": str(line_path),
            "lines_sha256": sha256(line_path),
        },
    }
    json_path = args.output_directory / "a2864-99blp_exact_geometry_audit.json"
    with json_path.open("wt", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(f"audit JSON: {json_path}")
    print(f"EXACT GEOMETRY AUDIT PASS in {report['elapsed_seconds']:.3f} seconds")


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"AUDIT FAILED: {error}", file=sys.stderr)
        raise
