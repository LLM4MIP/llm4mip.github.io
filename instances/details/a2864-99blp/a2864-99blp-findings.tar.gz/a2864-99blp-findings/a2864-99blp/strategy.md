# Formal Solving Strategy

## Current target state

The sourced public target and current diagnostic bounds are:

- official MIPLIB feasible primal: -257, pending independent local verification of the downloaded official solution;
- current experiment feasible primal: -72;
- diagnostic valid dual: -13841;
- public-primal/diagnostic-dual relative gap: 0.9814319774582761.

The immediate target is to independently verify and import the official -257 solution, then search for a feasible objective below -257. In parallel, the dual program seeks a certified value above -13841. No optimality claim is possible unless verified primal and dual bounds meet within tolerance or an independently checked exact proof is produced.

## Mandatory execution discipline

The fixed 120-second Gurobi/euler4 and COPT/altman jobs are diagnostic baselines and will not be duplicated or extended. Post-baseline direct solver time will not be requested until four materially distinct custom methods have been launched, at least three have completed successfully, successful custom runtime totals at least 3600 seconds, one scaled run has executed for at least 1800 seconds, and a successful method has targeted a globally valid dual bound or checked proof.

Every custom method must write `method_result.json` with:

- `status`;
- `algorithm_family`;
- `algorithm_role` equal to `primal`, `dual_bound`, `proof`, or `hybrid`;
- a structure-specific `hypothesis`;
- positive numeric `work_units` and its unit;
- `termination_reason`;
- target bound and achieved bound or objective;
- seed;
- requested and actual runtime where available;
- acceptance criterion;
- pivot condition;
- names of any solution or certificate artifacts.

Dry runs are deterministic and small. Scaled runs perform real search, bound optimization, propagation, or certificate work; they may not sleep or busy-wait merely to consume time.

## Experiment 1: low-row exchange

**Hypothesis:** Starting from the official cardinality-257 solution rather than the weak diagnostic cardinality-72 incumbent, scarcity-aware additions with bounded ejection chains and exact unit-row slack updates may find a larger equality-compatible set.

**Dry run:** deterministic seed 1, parse and validate the representation, build row/column incidence, attempt a bounded number of additions and depth-limited repairs, and report parsed dimensions, checked incidences, candidate evaluations, accepted moves, equality violations, and final objective.

**Acceptance criterion:** write `best.sol` only after exact recomputation confirms every packing and equality row and the objective. An experimental success requires positive candidate or move work units even if no improvement is found.

**Pivot condition:** if parsing or representation fails, repair the parser first. If equality repair fails, bucket columns by their 17-row equality signature. If the neighborhood exhausts quickly, add paired insertion, larger ejection depth, neutral diversification, and incremental blocked-row indexes before scaling.

**Scale plan:** after a valid dry run, run a revised search long enough to explore a substantively enlarged neighborhood. One promising custom method will eventually receive the mandatory 1800-second scaled run.

## Experiment 2: certified Lagrangian dual search

**Hypothesis:** The retained dual -13841 is weak relative to the packing structure, and sparse projected multiplier optimization can produce a globally valid bound above it.

**Dry run:** evaluate several deterministic projected subgradient or coordinate steps from a safe multiplier vector. Count full sparse evaluations and active-column term evaluations. Emit the best multiplier vector and recomputed bound.

**Acceptance criterion:** inequality multipliers must be nonnegative. The reported original-minimization dual is accepted only after a separate outward-safe recomputation of `-U`. Floating-point exploratory values are not treated as certified improvements.

**Pivot condition:** if matrix passes are too slow, use row-major/column-major compressed arrays and active-column screening. If the bound stalls, add coordinate refinement, row aggregation, and rational/scaled-integer polishing.

## Experiment 3: adaptive randomized construction and relinking

**Hypothesis:** Multiple equality-compatible greedy basins exist, and adaptive scarcity penalties plus elite path relinking can exceed cardinality 257 even if local exchange from the official incumbent stalls.

**Dry run:** deterministic seed 17, a small number of constructions and relinking paths, exact feasibility checks, and positive counts of column score evaluations and repair moves.

**Acceptance criterion:** retain only exactly feasible solutions; improve the primal only with objective below the current verified best.

**Pivot condition:** if candidate scoring dominates, use lazy score queues. If constructions miss equality requirements, seed equality rows first and repair deficits before packing expansion. If diversity collapses, increase restricted candidate-list randomness and maintain elite-distance thresholds.

## Experiment 4: multiplicative row-price primal-dual search

**Hypothesis:** Online prices identify bottleneck rows better than static degree scores and can guide both feasible construction and a useful certificate-safe Lagrangian vector.

**Dry run:** deterministic seed 29, bounded epochs of row-price updates and reconstruction, with counts of epochs, price updates, candidate scans, and certified bound evaluations.

**Acceptance criterion:** primal output requires exact feasibility; dual output requires separate valid Lagrangian recomputation. Heuristic surrogate scores are never reported as bounds.

**Pivot condition:** if prices oscillate, damp updates and average iterates. If equality rows destabilize construction, maintain explicit equality deficits and separate free equality prices from nonnegative packing prices.

## Optional proof experiment

After cardinality and row-size statistics are measured, estimate the size of a pseudo-Boolean-to-CNF cardinality decision encoding. Only if tractable, encode a selected target, run CaDiCaL, and check any UNSAT proof with `drat-trim`. SAT output is merely a candidate assignment until translated and verified against the original model. UNSAT without a successfully checked proof is not accepted.

## Result handling and direction changes

After every completed experiment, read `experiments.json` and at most one genuinely necessary log. Compare the current verified primal and dual with the official primal -257, diagnostic dual -13841, and all prior experiment results. Preserve any verified improvement immediately.

Negative outcomes will be classified as parsing, representation, feasibility repair, neighborhood size, evaluation cost, diversification, or false structural hypothesis. Plausible methods are revised at the identified failure point; falsified hypotheses trigger a materially different method. Direct solver fallback is considered only after the custom gates and only when custom evidence supplies a focused proof or polishing hypothesis.
