import argparse, gzip, json, math, os, random, time


def open_text(path):
    return gzip.open(path, 'rt', errors='replace') if path.endswith('.gz') else open(path, 'r', errors='replace')


def parse_mps(path):
    section = None
    sense = 'MIN'
    rows = {}
    row_order = []
    objrow = None
    cols = {}
    obj = {}
    rhs = {}
    lb = {}
    ub = {}
    integer_mode = False
    integer_vars = set()
    ranges_seen = False
    with open_text(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('*'):
                continue
            tok = line.split()
            head = tok[0].upper()
            if head in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE','OBJNAME'):
                section = head
                if head == 'RANGES':
                    ranges_seen = True
                continue
            if section == 'OBJSENSE':
                if head.startswith('MAX'):
                    sense = 'MAX'
                elif head.startswith('MIN'):
                    sense = 'MIN'
                continue
            if section == 'ROWS':
                if len(tok) >= 2:
                    typ, name = tok[0].upper(), tok[1]
                    if typ == 'N' and objrow is None:
                        objrow = name
                    elif typ in ('L','G','E'):
                        rows[name] = typ
                        row_order.append(name)
                continue
            if section == 'COLUMNS':
                if any('MARKER' in z.upper() for z in tok):
                    joined = ' '.join(tok).upper()
                    if 'INTORG' in joined:
                        integer_mode = True
                    elif 'INTEND' in joined:
                        integer_mode = False
                    continue
                if len(tok) < 3:
                    continue
                var = tok[0]
                if integer_mode:
                    integer_vars.add(var)
                cols.setdefault(var, {})
                pairs = tok[1:]
                for k in range(0, len(pairs)-1, 2):
                    r = pairs[k]
                    try:
                        val = float(pairs[k+1].replace('D','E').replace('d','e'))
                    except ValueError:
                        continue
                    if r == objrow:
                        obj[var] = obj.get(var, 0.0) + val
                    elif r in rows:
                        cols[var][r] = cols[var].get(r, 0.0) + val
                continue
            if section == 'RHS':
                if len(tok) < 3:
                    continue
                pairs = tok[1:]
                for k in range(0, len(pairs)-1, 2):
                    r = pairs[k]
                    if r in rows and r not in rhs:
                        rhs[r] = float(pairs[k+1].replace('D','E').replace('d','e'))
                continue
            if section == 'BOUNDS':
                if len(tok) < 3:
                    continue
                typ = tok[0].upper()
                var = tok[2]
                val = float(tok[3].replace('D','E').replace('d','e')) if len(tok) >= 4 else 0.0
                if typ == 'BV':
                    lb[var], ub[var] = 0.0, 1.0
                    integer_vars.add(var)
                elif typ in ('LI','UI'):
                    integer_vars.add(var)
                    if typ == 'LI': lb[var] = val
                    else: ub[var] = val
                elif typ == 'LO': lb[var] = val
                elif typ == 'UP': ub[var] = val
                elif typ == 'FX': lb[var] = val; ub[var] = val
                elif typ == 'FR': lb[var] = -math.inf; ub[var] = math.inf
                elif typ == 'MI': lb[var] = -math.inf
                elif typ == 'PL': ub[var] = math.inf
                continue
    if ranges_seen:
        raise RuntimeError('RANGES records are not supported by this dry-run implementation')
    variables = sorted(set(cols) | set(obj) | set(lb) | set(ub))
    for v in variables:
        lb.setdefault(v, 0.0)
        ub.setdefault(v, math.inf)
    for r in row_order:
        rhs.setdefault(r, 0.0)
    if sense == 'MAX':
        obj = {v: -c for v,c in obj.items()}
    return variables, row_order, rows, cols, obj, rhs, lb, ub, integer_vars, sense


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--seed', type=int, default=1701)
    ap.add_argument('--runtime', type=float, default=90.0)
    ap.add_argument('--upper-bound', type=float, default=-72.0)
    ap.add_argument('--report-every', type=int, default=250)
    args = ap.parse_args()
    random.seed(args.seed)
    started = time.monotonic()
    status = 'completed'
    termination = 'runtime_budget_exhausted_after_active_subgradient_iterations'
    try:
        V, R, rtype, colmap, cdict, rhsdict, lbd, ubd, ints, original_sense = parse_mps(args.model)
        if original_sense != 'MIN':
            raise RuntimeError('This experiment was designed for the observed minimization model')
        rid = {r:i for i,r in enumerate(R)}
        n, m = len(V), len(R)
        signs = [1.0 if rtype[r] in ('L','E') else -1.0 for r in R]
        equality = [rtype[r] == 'E' for r in R]
        bnorm = [signs[i] * rhsdict[R[i]] for i in range(m)]
        # h_i(x)=sign_i*(a_i x-rhs_i) <= 0; equality multipliers are unrestricted.
        sparse = []
        c = []
        lo = []
        hi = []
        integral = []
        for v in V:
            sparse.append([(rid[r], signs[rid[r]]*a) for r,a in colmap.get(v,{}).items()])
            c.append(cdict.get(v,0.0))
            lo.append(lbd[v])
            hi.append(ubd[v])
            integral.append(v in ints)
        if any(not math.isfinite(lo[j]) or not math.isfinite(hi[j]) for j in range(n)):
            raise RuntimeError('The separable relaxation contains a variable without finite bounds')
        if any(integral[j] and (abs(lo[j]-round(lo[j])) > 1e-9 or abs(hi[j]-round(hi[j])) > 1e-9) for j in range(n)):
            raise RuntimeError('An integer variable has nonintegral explicit bounds')
        lam = [0.0]*m
        best_q = -math.inf
        best_lam = None
        best_x_ones = 0
        iterations = 0
        evaluations = 0
        stalls = 0
        phase_scale = 1.6
        trace = []
        deadline = started + max(1.0,args.runtime)
        while time.monotonic() < deadline:
            rc = c[:]
            for j in range(n):
                z = c[j]
                for i,a in sparse[j]:
                    z += lam[i]*a
                rc[j] = z
            x = [0.0]*n
            variable_part = 0.0
            unbounded = False
            for j,z in enumerate(rc):
                if z > 1e-13:
                    xv = lo[j]
                elif z < -1e-13:
                    xv = hi[j]
                else:
                    # Deterministic alternating tie choice supplies useful subgradient diversity.
                    xv = hi[j] if ((iterations + j) & 1) else lo[j]
                if integral[j]:
                    xv = float(round(xv))
                if not math.isfinite(xv):
                    unbounded = True
                    break
                x[j] = xv
                variable_part += z*xv
            if unbounded:
                raise RuntimeError('A Lagrangian subproblem was unbounded')
            q = variable_part - sum(lam[i]*bnorm[i] for i in range(m))
            evaluations += 1
            h = [-bnorm[i] for i in range(m)]
            for j,xv in enumerate(x):
                if xv != 0.0:
                    for i,a in sparse[j]:
                        h[i] += a*xv
            if q > best_q + 1e-8:
                best_q = q
                best_lam = lam[:]
                best_x_ones = sum(1 for z in x if abs(z) > 1e-12)
                stalls = 0
            else:
                stalls += 1
            norm2 = sum(z*z for z in h)
            if norm2 <= 1e-24:
                termination = 'zero_subgradient_exact_lagrangian_stationarity'
                break
            target_distance = max(1.0, args.upper_bound - q)
            step = phase_scale * target_distance / norm2
            # A finite cap protects against nearly zero subgradients without changing validity.
            step = min(step, 10000.0 / math.sqrt(norm2))
            for i in range(m):
                nv = lam[i] + step*h[i]
                lam[i] = nv if equality[i] else max(0.0,nv)
            iterations += 1
            if stalls >= 400:
                phase_scale *= 0.62
                stalls = 0
                # A small deterministic perturbation only changes the search point, never bound validity.
                for i in range(m):
                    delta = (random.random()-0.5)*1e-4*(1.0+abs(lam[i]))
                    lam[i] = lam[i]+delta if equality[i] else max(0.0,lam[i]+delta)
            if iterations % max(1,args.report_every) == 0:
                trace.append({'iteration':iterations,'best_dual_bound':best_q,'current_dual_value':q,'phase_scale':phase_scale,'subgradient_norm':math.sqrt(norm2)})
                if len(trace) > 40:
                    trace = trace[-40:]
        elapsed = time.monotonic()-started
        cert = {
            'certificate_type':'lagrangian_row_multipliers',
            'objective_sense':'minimize',
            'normalization':'L rows use a*x-rhs<=0; G rows use rhs-a*x<=0; E rows use a*x-rhs=0',
            'dual_bound':best_q,
            'public_primal_target':args.upper_bound,
            'row_names':R,
            'multipliers':best_lam,
            'equality_multiplier_unrestricted':[R[i] for i in range(m) if equality[i]],
            'nonnegative_multiplier_rows':[R[i] for i in range(m) if not equality[i]],
            'variable_count':n,
            'row_count':m,
            'integer_variable_count':len(ints),
            'active_subproblem_variables':best_x_ones,
            'iterations':iterations,
            'trace':trace
        }
        with open('lagrangian_certificate.json','w') as f:
            json.dump(cert,f,indent=2)
        result = {
            'status':status,
            'algorithm_family':'projected Polyak subgradient optimization of an exact separable Lagrangian row relaxation',
            'algorithm_role':'dual_bound',
            'hypothesis':'Dualizing the 99 coupling rows leaves an exactly solvable bounded-variable subproblem and optimized row prices can improve the global lower bound beyond -13841.',
            'work_units':max(1,iterations),
            'work_unit_name':'Lagrangian subproblem evaluations',
            'termination_reason':termination,
            'target_bound':-13841.0,
            'best_dual_bound':best_q,
            'certificate_artifact':'lagrangian_certificate.json',
            'seed':args.seed,
            'runtime_seconds':elapsed,
            'acceptance_criterion':'Accept as promising for scaling if the explicit valid Lagrangian value exceeds -13841 by at least 1e-6 or shows sustained improvement in the final trace.',
            'pivot_condition':'If the bound remains at or below -13841 or multipliers stall, replace whole-row subgradient ascent with a tighter decomposition, bundle stabilization, or an independently checkable pseudo-Boolean relaxation.',
            'model_statistics':{'variables':n,'rows':m,'integer_variables':len(ints)},
            'objective_sense':'minimize'
        }
    except Exception as e:
        elapsed = time.monotonic()-started
        result = {
            'status':'error',
            'algorithm_family':'projected Polyak subgradient optimization of a separable Lagrangian row relaxation',
            'algorithm_role':'dual_bound',
            'hypothesis':'Dualizing coupling rows yields an exactly solvable bounded-variable relaxation.',
            'work_units':1,
            'termination_reason':'parsing_or_representation_failure: '+str(e),
            'target_bound':-13841.0,
            'seed':args.seed,
            'runtime_seconds':elapsed,
            'acceptance_criterion':'A successful parse and at least one finite certified dual evaluation are required.',
            'pivot_condition':'Repair MPS representation before assessing the structural hypothesis.'
        }
    with open('method_result.json','w') as f:
        json.dump(result,f,indent=2)

if __name__ == '__main__':
    main()
