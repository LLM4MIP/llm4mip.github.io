#!/usr/bin/env python3
import argparse, gzip, json, math, os, random, time


def open_model(path):
    return gzip.open(path, 'rt', errors='replace') if path.endswith('.gz') else open(path, 'r', errors='replace')


def parse_mps(path):
    rows = {}
    row_order = []
    objrow = None
    cols = {}
    obj = {}
    rhs = {}
    lb = {}
    ub = {}
    integer = set()
    section = None
    objsense = 'MIN'
    int_mode = False
    with open_model(path) as f:
        for raw in f:
            line = raw.rstrip('\n\r')
            if not line or line.lstrip().startswith('*'):
                continue
            t = line.split()
            if not t:
                continue
            head = t[0].upper()
            if head in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE','OBJNAME'):
                section = head
                if head == 'ENDATA':
                    break
                continue
            if section == 'OBJSENSE':
                if head.startswith('MAX'):
                    objsense = 'MAX'
                elif head.startswith('MIN'):
                    objsense = 'MIN'
                continue
            if section == 'ROWS':
                if len(t) >= 2:
                    typ, name = t[0].upper(), t[1]
                    if typ == 'N' and objrow is None:
                        objrow = name
                    elif typ in ('L','G','E'):
                        rows[name] = typ
                        row_order.append(name)
                continue
            if section == 'COLUMNS':
                if any("MARKER" in z.upper() for z in t):
                    if any("INTORG" in z.upper() for z in t): int_mode = True
                    if any("INTEND" in z.upper() for z in t): int_mode = False
                    continue
                var = t[0]
                if int_mode: integer.add(var)
                cols.setdefault(var, {})
                pairs = t[1:]
                for k in range(0, len(pairs)-1, 2):
                    rn = pairs[k]
                    try: val = float(pairs[k+1].replace('D','E').replace('d','e'))
                    except ValueError: continue
                    if rn == objrow:
                        obj[var] = obj.get(var, 0.0) + val
                    elif rn in rows:
                        cols[var][rn] = cols[var].get(rn, 0.0) + val
                continue
            if section == 'RHS':
                pairs = t[1:]
                for k in range(0, len(pairs)-1, 2):
                    rn = pairs[k]
                    try: val = float(pairs[k+1].replace('D','E').replace('d','e'))
                    except ValueError: continue
                    if rn in rows: rhs[rn] = val
                continue
            if section == 'BOUNDS' and len(t) >= 3:
                bt, var = t[0].upper(), t[2]
                val = 0.0
                if len(t) >= 4:
                    try: val = float(t[3].replace('D','E').replace('d','e'))
                    except ValueError: val = 0.0
                if bt == 'BV':
                    lb[var], ub[var] = 0.0, 1.0; integer.add(var)
                elif bt == 'LO': lb[var] = val
                elif bt == 'UP': ub[var] = val
                elif bt == 'FX': lb[var] = val; ub[var] = val
                elif bt == 'FR': lb[var] = -math.inf; ub[var] = math.inf
                elif bt == 'MI': lb[var] = -math.inf
                elif bt == 'PL': ub[var] = math.inf
                elif bt == 'LI': lb[var] = val; integer.add(var)
                elif bt == 'UI': ub[var] = val; integer.add(var)
    names = list(cols.keys())
    rid = {r:i for i,r in enumerate(row_order)}
    senses = [rows[r] for r in row_order]
    b = [rhs.get(r,0.0) for r in row_order]
    c = [obj.get(v,0.0) for v in names]
    if objsense == 'MAX': c = [-z for z in c]
    incidence = []
    for v in names:
        incidence.append([(rid[r],a) for r,a in cols[v].items() if abs(a)>1e-15])
    binary = []
    for v in names:
        lo, hi = lb.get(v,0.0), ub.get(v,1.0 if v in integer else math.inf)
        binary.append(v in integer and lo >= -1e-9 and hi <= 1.0+1e-9)
    return names, senses, b, c, incidence, binary, objsense


def read_solution(path, index, n):
    x = [0]*n
    if not path or not os.path.exists(path): return x
    with open(path, 'r', errors='replace') as f:
        for line in f:
            if not line.strip() or line.lstrip().startswith('#'): continue
            t=line.split()
            if len(t)>=2 and t[0] in index:
                try: x[index[t[0]]] = 1 if float(t[1]) > 0.5 else 0
                except ValueError: pass
    return x


def violation(a, senses, b):
    z=0.0
    for q,s,r in zip(a,senses,b):
        if s=='L': z += max(0.0,q-r)
        elif s=='G': z += max(0.0,r-q)
        else: z += abs(q-r)
    return z


def feasible(a,senses,b,tol=1e-8):
    return violation(a,senses,b) <= tol


def write_solution(path,names,x,obj,objsense):
    shown = obj if objsense=='MIN' else -obj
    with open(path,'w') as f:
        f.write('# Objective value = %.17g\n' % shown)
        for v,z in zip(names,x):
            if z: f.write('%s 1\n' % v)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--model',required=True)
    ap.add_argument('--seed',type=int,default=1)
    ap.add_argument('--runtime',type=float,default=120.0)
    ap.add_argument('--start',default='/resources/best.sol')
    args=ap.parse_args()
    start_time=time.time(); rng=random.Random(args.seed)
    names,senses,b,c,inc,binary,objsense=parse_mps(args.model)
    n=len(names); m=len(senses); index={v:i for i,v in enumerate(names)}
    x=read_solution(args.start,index,n)
    # Restrict nonbinary columns to zero; this instance is expected to be a BLP.
    for i in range(n):
        if not binary[i]: x[i]=0
    act=[0.0]*m
    for i,z in enumerate(x):
        if z:
            for r,a in inc[i]: act[r]+=a
    current=sum(c[i]*x[i] for i in range(n))
    seed_feasible=feasible(act,senses,b)
    best=x[:]; best_obj=current if seed_feasible else math.inf
    best_act=act[:]
    all_le=all(s=='L' for s in senses)
    nonnegative=all(a>=-1e-12 for col in inc for _,a in col)
    packing=all_le and nonnegative and all(binary)
    moves=0; accepted=0; feasible_states=1 if seed_feasible else 0; improvements=0
    deadline=start_time+max(1.0,args.runtime)

    def can_flip(i,new,activity):
        d=new-x[i]
        for r,a in inc[i]:
            q=activity[r]+d*a
            if senses[r]=='L' and q>b[r]+1e-9:return False
            if senses[r]=='G' and q<b[r]-1e-9:return False
            if senses[r]=='E' and abs(q-b[r])>1e-9:return False
        return True

    def apply(i,new):
        nonlocal current,moves
        old=x[i]
        if old==new:return
        d=new-old
        for r,a in inc[i]:act[r]+=d*a
        current+=d*c[i]; x[i]=new; moves+=1

    if packing and seed_feasible:
        # Exhaust all immediately profitable feasible insertions first.
        order=[i for i in range(n) if not x[i] and c[i]<-1e-12]
        order.sort(key=lambda i:(c[i]/max(1,len(inc[i])),c[i],i))
        for i in order:
            if can_flip(i,1,act): apply(i,1); accepted+=1
        if current<best_obj-1e-9:
            best_obj=current;best=x[:];best_act=act[:];improvements+=1
        # Large-neighborhood exchanges: remove 1..8 selected columns, then refill
        # using objective gain divided by residual-resource pressure.
        while time.time()<deadline:
            selected=[i for i in range(n) if x[i]]
            if not selected: break
            k=1+rng.randrange(min(8,len(selected)))
            removed=rng.sample(selected,k)
            snapshot=x[:]; snapact=act[:]; snapobj=current
            for i in removed: apply(i,0)
            cand=[i for i in range(n) if not x[i] and c[i]<-1e-12]
            rng.shuffle(cand)
            def score(i):
                pressure=0.0
                for r,a in inc[i]:
                    slack=max(1e-9,b[r]-act[r])
                    pressure+=a/slack
                return c[i]/max(0.05,pressure)
            cand.sort(key=score)
            for i in cand:
                moves+=1
                ok=True
                for r,a in inc[i]:
                    if act[r]+a>b[r]+1e-9:ok=False;break
                if ok: apply(i,1)
            if current<snapobj-1e-9:
                accepted+=1;feasible_states+=1
                if current<best_obj-1e-9:
                    best_obj=current;best=x[:];best_act=act[:];improvements+=1
            else:
                x[:]=snapshot;act[:]=snapact;current=snapobj
    else:
        # Adaptive exact-penalty walk for non-monotone low-row BLPs. The verified
        # incumbent is retained while infeasible states are used only as search guides.
        scale=max(1.0,max((abs(z) for z in c),default=1.0)); penalty=10.0*scale
        curv=violation(act,senses,b)
        temp=scale
        while time.time()<deadline:
            i=rng.randrange(n)
            if not binary[i]: continue
            new=1-x[i]; d=new-x[i]
            nv=0.0
            touched={r for r,_ in inc[i]}
            for r in range(m):
                q=act[r]+(d*dict(inc[i]).get(r,0.0) if r in touched else 0.0)
                if senses[r]=='L':nv+=max(0.0,q-b[r])
                elif senses[r]=='G':nv+=max(0.0,b[r]-q)
                else:nv+=abs(q-b[r])
            delta=d*c[i]+penalty*(nv-curv)
            moves+=1
            if delta<=0 or rng.random()<math.exp(-min(60.0,delta/max(1e-9,temp))):
                apply(i,new);curv=nv;accepted+=1
                if curv<=1e-8:
                    feasible_states+=1
                    if current<best_obj-1e-9:
                        best_obj=current;best=x[:];best_act=act[:];improvements+=1
            temp=max(0.01*scale,temp*0.999995)
            if moves%20000==0:
                penalty*=1.25
                if best_obj<math.inf and curv>1e-8 and rng.random()<0.5:
                    x[:]=best;act[:]=best_act;current=best_obj;curv=0.0

    elapsed=time.time()-start_time
    if best_obj<math.inf: write_solution('best.sol',names,best,best_obj,objsense)
    shown=None if best_obj==math.inf else (best_obj if objsense=='MIN' else -best_obj)
    result={
      'status':'success',
      'algorithm_family':'incumbent-seeded low-row greedy augmentation and destroy-repair exchange' if packing else 'adaptive exact-penalty low-row binary local search',
      'algorithm_role':'primal',
      'hypothesis':'With only a small number of rows, resource-slack-guided multi-column exchanges can improve the verified incumbent more effectively than generic branching.',
      'work_units':max(1,moves),
      'work_unit_name':'evaluated_or_applied_variable_moves',
      'termination_reason':'deterministic_runtime_budget_exhausted' if elapsed>=args.runtime*0.95 else 'neighborhood_exhausted',
      'target_bound':-73.0,
      'objective':shown,
      'solution_artifact':'best.sol' if shown is not None else None,
      'certificate_artifact':None,
      'seed':args.seed,
      'runtime_seconds':elapsed,
      'acceptance_criterion':'Strict objective improvement after a feasible destroy-repair exchange; penalty-Metropolis acceptance in the fallback walk.',
      'pivot_condition':'Use packing exchanges only when every row is upper-bounded, every structural coefficient is nonnegative, all variables are binary, and the supplied incumbent is feasible; otherwise pivot to adaptive exact-penalty search.',
      'packing_structure_detected':packing,
      'variables':n,'rows':m,'seed_feasible':seed_feasible,
      'accepted_moves_or_neighborhoods':accepted,'feasible_states':feasible_states,'improvements':improvements
    }
    with open('method_result.json','w') as f:json.dump(result,f,indent=2,sort_keys=True)
    with open('search_trace.json','w') as f:json.dump({'result':result,'best_internal_min_objective':None if best_obj==math.inf else best_obj},f,indent=2)

if __name__=='__main__': main()
