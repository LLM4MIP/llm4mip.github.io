import argparse, gzip, json, math, os, random, time, traceback
from collections import defaultdict


def open_model(path):
    with open(path, 'rb') as f:
        magic = f.read(2)
    return gzip.open(path, 'rt', errors='replace') if magic == b'\x1f\x8b' else open(path, 'rt', errors='replace')


def parse_mps(path):
    section = None
    objrow = None
    objsense = 'MIN'
    rowsense = {}
    row_order = []
    cols = defaultdict(lambda: defaultdict(float))
    rhs = defaultdict(float)
    ranges = defaultdict(float)
    lo, up = {}, {}
    integer_mode = False
    integer_vars = set()
    variables = []
    seen_vars = set()
    rhs_name = None
    range_name = None
    with open_model(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('*'):
                continue
            tok = line.split()
            head = tok[0].upper()
            if head in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE','OBJNAME'):
                section = head
                if head == 'ENDATA':
                    break
                continue
            if section == 'OBJSENSE':
                if head.startswith('MAX'):
                    objsense = 'MAX'
                elif head.startswith('MIN'):
                    objsense = 'MIN'
                continue
            if section == 'ROWS':
                if len(tok) >= 2:
                    s, r = tok[0].upper(), tok[1]
                    if s == 'N' and objrow is None:
                        objrow = r
                    elif s in ('L','G','E'):
                        rowsense[r] = s
                        row_order.append(r)
                continue
            if section == 'COLUMNS':
                if len(tok) >= 2 and tok[1].strip("'").upper() == 'MARKER':
                    marker = tok[-1].strip("'").upper()
                    integer_mode = marker == 'INTORG'
                    continue
                v = tok[0]
                if v not in seen_vars:
                    seen_vars.add(v); variables.append(v)
                if integer_mode:
                    integer_vars.add(v)
                pairs = tok[1:]
                for k in range(0, len(pairs)-1, 2):
                    try:
                        cols[v][pairs[k]] += float(pairs[k+1].replace('D','E').replace('d','e'))
                    except ValueError:
                        pass
                continue
            if section == 'RHS':
                if len(tok) < 3:
                    continue
                if rhs_name is None:
                    rhs_name = tok[0]
                if tok[0] != rhs_name:
                    continue
                for k in range(1, len(tok)-1, 2):
                    try: rhs[tok[k]] += float(tok[k+1].replace('D','E').replace('d','e'))
                    except ValueError: pass
                continue
            if section == 'RANGES':
                if len(tok) < 3:
                    continue
                if range_name is None:
                    range_name = tok[0]
                if tok[0] != range_name:
                    continue
                for k in range(1, len(tok)-1, 2):
                    try: ranges[tok[k]] += float(tok[k+1].replace('D','E').replace('d','e'))
                    except ValueError: pass
                continue
            if section == 'BOUNDS':
                if len(tok) < 3:
                    continue
                bt, v = tok[0].upper(), tok[2]
                val = 0.0
                if len(tok) >= 4:
                    try: val = float(tok[3].replace('D','E').replace('d','e'))
                    except ValueError: val = 0.0
                if v not in seen_vars:
                    seen_vars.add(v); variables.append(v)
                if bt == 'BV':
                    lo[v], up[v] = 0.0, 1.0; integer_vars.add(v)
                elif bt in ('LI','LO'):
                    lo[v] = val
                    if bt == 'LI': integer_vars.add(v)
                elif bt in ('UI','UP'):
                    up[v] = val
                    if bt == 'UI': integer_vars.add(v)
                elif bt == 'FX':
                    lo[v] = val; up[v] = val
                elif bt == 'FR':
                    lo[v], up[v] = -math.inf, math.inf
                elif bt == 'MI':
                    lo[v] = -math.inf
                elif bt == 'PL':
                    up[v] = math.inf
                continue
    if objsense != 'MIN':
        raise ValueError('This implementation requires a minimization model.')
    for v in variables:
        lo.setdefault(v, 0.0)
        up.setdefault(v, math.inf)
    c = {v: cols[v].get(objrow, 0.0) for v in variables}
    objconst = rhs.get(objrow, 0.0) if objrow is not None else 0.0
    # Each dualized item is (original row, sign, reference RHS, projected_nonnegative).
    # sign=+1 means a*x-b<=0; sign=-1 means b-a*x<=0.
    cons = []
    for r in row_order:
        s, b = rowsense[r], rhs.get(r, 0.0)
        if r not in ranges:
            if s == 'L': cons.append((r, 1.0, b, True))
            elif s == 'G': cons.append((r, -1.0, b, True))
            else: cons.append((r, 1.0, b, False))
        else:
            q = ranges[r]
            if s == 'L': lower, upper = b-abs(q), b
            elif s == 'G': lower, upper = b, b+abs(q)
            elif q >= 0: lower, upper = b, b+q
            else: lower, upper = b+q, b
            cons.append((r, 1.0, upper, True))
            cons.append((r, -1.0, lower, True))
    row_index = {r:i for i,r in enumerate(row_order)}
    col_entries = []
    for v in variables:
        ent = []
        for r,a in cols[v].items():
            if r in row_index and a != 0.0:
                ent.append((row_index[r], a))
        col_entries.append(ent)
    return variables, row_order, col_entries, c, lo, up, cons, objconst, len(integer_vars)


def run(args):
    variables, rows, entries, cdict, lo_d, up_d, cons, objconst, nint = parse_mps(args.model)
    n, m, k = len(variables), len(rows), len(cons)
    if not n or not k:
        raise ValueError('No variables or dualizable constraints were parsed.')
    c = [cdict[v] for v in variables]
    lower = [lo_d[v] for v in variables]
    upper = [up_d[v] for v in variables]
    for j in range(n):
        if not math.isfinite(lower[j]) or not math.isfinite(upper[j]):
            raise ValueError('Finite variable bounds are required for the box Lagrangian relaxation; offending variable: '+variables[j])
        if lower[j] > upper[j]:
            raise ValueError('Inconsistent bounds for variable: '+variables[j])
    rowpos = {r:i for i,r in enumerate(rows)}
    con_row = [rowpos[t[0]] for t in cons]
    con_sign = [t[1] for t in cons]
    con_rhs = [t[2] for t in cons]
    projected = [t[3] for t in cons]
    by_row = [[] for _ in rows]
    for h in range(k):
        by_row[con_row[h]].append(h)
    y = [0.0]*k
    best_y = y[:]
    best_q = -math.inf
    best_iter = 0
    alpha = args.alpha
    stagnant = 0
    iterations = 0
    variable_evaluations = 0
    nonzero_evaluations = 0
    rng = random.Random(args.seed)
    start = time.monotonic()
    deadline = start + args.runtime
    last_report = start
    trace = []

    while time.monotonic() < deadline:
        row_weight = [0.0]*m
        constant = objconst
        for h in range(k):
            yh = y[h]
            row_weight[con_row[h]] += yh*con_sign[h]
            constant -= yh*con_sign[h]*con_rhs[h]
        activity = [0.0]*m
        q = constant
        for j in range(n):
            rc = c[j]
            for i,a in entries[j]:
                rc += a*row_weight[i]
            x = lower[j] if rc >= 0.0 else upper[j]
            q += rc*x
            if x != 0.0:
                for i,a in entries[j]:
                    activity[i] += a*x
            nonzero_evaluations += len(entries[j])
        variable_evaluations += n
        iterations += 1
        if math.isfinite(q) and q > best_q:
            best_q, best_y, best_iter = q, y[:], iterations
            stagnant = 0
        else:
            stagnant += 1
        grad = [con_sign[h]*(activity[con_row[h]]-con_rhs[h]) for h in range(k)]
        norm2 = sum(g*g for g in grad)
        if norm2 <= 1e-30:
            trace.append({'iteration':iterations,'dual':q,'best_dual':best_q,'alpha':alpha,'event':'zero_subgradient'})
            break
        gap_to_target = max(args.target-q, 1e-8)
        step = alpha*gap_to_target/norm2
        for h in range(k):
            z = y[h] + step*grad[h]
            y[h] = max(0.0,z) if projected[h] else z
        if stagnant >= args.pivot:
            alpha = max(0.015, alpha*0.72)
            # Deterministic diversification around the best dual vector, followed by projection.
            scale = max(1e-9, sum(abs(z) for z in best_y)/max(1,k))
            for h in range(k):
                z = best_y[h] + (rng.random()-0.5)*0.02*scale
                y[h] = max(0.0,z) if projected[h] else z
            stagnant = 0
            trace.append({'iteration':iterations,'dual':q,'best_dual':best_q,'alpha':alpha,'event':'stagnation_pivot'})
        now = time.monotonic()
        if now-last_report >= 30.0:
            trace.append({'iteration':iterations,'dual':q,'best_dual':best_q,'alpha':alpha,'elapsed':now-start})
            if len(trace) > 300: trace = trace[-300:]
            last_report = now

    # Re-evaluate the best multiplier vector and retain all terms needed for independent checking.
    row_weight = [0.0]*m
    constant = objconst
    for h in range(k):
        row_weight[con_row[h]] += best_y[h]*con_sign[h]
        constant -= best_y[h]*con_sign[h]*con_rhs[h]
    min_terms = []
    checked_q = constant
    for j in range(n):
        rc = c[j]
        for i,a in entries[j]: rc += a*row_weight[i]
        x = lower[j] if rc >= 0 else upper[j]
        term = rc*x
        checked_q += term
        min_terms.append(term)
    # A conservative reporting margin protects against ordinary summation roundoff.
    margin = 1e-9*(1.0+abs(constant)+sum(abs(z) for z in min_terms))
    safe_q = checked_q-margin
    certificate = {
        'certificate_type':'Lagrangian box-relaxation lower bound',
        'objective_sense':'minimize',
        'derivation':'All original rows are dualized with sign-correct multipliers. Equality multipliers are free and inequality multipliers are nonnegative. The Lagrangian is minimized independently over each finite variable interval.',
        'variables':n,'original_rows':m,'dualized_constraints':k,'integer_variables':nint,
        'objective_constant':objconst,'multipliers':best_y,
        'constraints':[{'row':cons[h][0],'sign':con_sign[h],'rhs':con_rhs[h],'nonnegative':projected[h]} for h in range(k)],
        'raw_recomputed_bound':checked_q,'roundoff_margin':margin,'reported_safe_lower_bound':safe_q,
        'best_iteration':best_iter
    }
    with open('dual_certificate.json','w') as f: json.dump(certificate,f,separators=(',',':'))
    elapsed = time.monotonic()-start
    result = {
        'status':'success','algorithm_family':'full-row Lagrangian relaxation with exact box minimization and stabilized projected subgradient ascent',
        'algorithm_role':'dual_bound',
        'hypothesis':'The weak root bounds arise from global row coupling; dualizing all rows should convert that coupling into a tractable separable relaxation and improve the valid minimization lower bound.',
        'work_units':iterations,
        'work_unit_name':'complete Lagrangian evaluations',
        'termination_reason':'zero subgradient' if trace and trace[-1].get('event')=='zero_subgradient' else 'configured meaningful-runtime deadline reached',
        'target_bound':args.target,'dual_bound':safe_q,'raw_dual_bound':checked_q,
        'certificate_artifact':'dual_certificate.json','seed':args.seed,'runtime_seconds':elapsed,
        'acceptance_criterion':'Accept a multiplier vector only when its exactly separable box-relaxation value exceeds the incumbent dual value.',
        'pivot_condition':'After the configured number of nonimproving evaluations, reduce the Polyak factor and deterministically diversify around the best multiplier vector.',
        'iterations':iterations,'variable_evaluations':variable_evaluations,'nonzero_evaluations':nonzero_evaluations,
        'best_iteration':best_iter,'trace_tail':trace[-80:]
    }
    with open('method_result.json','w') as f: json.dump(result,f,indent=2)


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--model',required=True)
    p.add_argument('--runtime',type=float,default=1820.0)
    p.add_argument('--seed',type=int,default=286499)
    p.add_argument('--target',type=float,default=-72.0)
    p.add_argument('--alpha',type=float,default=1.65)
    p.add_argument('--pivot',type=int,default=250)
    a=p.parse_args()
    try:
        run(a)
    except Exception as e:
        with open('method_result.json','w') as f:
            json.dump({'status':'failed','algorithm_family':'full-row Lagrangian relaxation with exact box minimization','algorithm_role':'dual_bound','hypothesis':'Dualizing all structural rows yields a useful separable global lower bound.','work_units':1,'termination_reason':'exception: '+str(e),'target_bound':a.target,'seed':a.seed,'runtime_seconds':0.0,'acceptance_criterion':'Strict improvement in the valid lower bound.','pivot_condition':'Not reached due to exception.','traceback':traceback.format_exc()},f,indent=2)
        raise
if __name__=='__main__': main()
