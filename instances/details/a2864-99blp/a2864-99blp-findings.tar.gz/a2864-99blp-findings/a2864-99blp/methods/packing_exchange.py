import argparse, gzip, json, os, time
from array import array


def op(path):
    return gzip.open(path, 'rt', encoding='utf-8', errors='replace') if path.endswith('.gz') else open(path, 'r', encoding='utf-8', errors='replace')


def parse_model(path):
    row_names=[]; senses=[]; row_id={}; rhs=[]
    vars_=[]; inc=[]; obj=[]
    section=''; objrow=None; curvar=None; curcodes=None; curobj=0.0
    with op(path) as f:
        for raw in f:
            s=raw.strip()
            if not s or s.startswith('*'): continue
            z=s.split(); key=z[0].upper()
            if key in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA'):
                section=key
                if key=='ENDATA': break
                continue
            if section=='ROWS':
                typ=z[0].upper(); name=z[1]
                if typ=='N' and objrow is None: objrow=name
                elif typ in ('L','G','E'):
                    row_id[name]=len(row_names); row_names.append(name); senses.append(typ); rhs.append(0.0)
            elif section=='COLUMNS':
                if 'MARKER' in s.upper(): continue
                v=z[0]
                if v!=curvar:
                    if curvar is not None:
                        vars_.append(curvar); inc.append(curcodes); obj.append(curobj)
                    curvar=v; curcodes=array('i'); curobj=0.0
                k=1
                while k+1<len(z):
                    rn=z[k]
                    try: val=float(z[k+1])
                    except ValueError: k+=2; continue
                    if rn==objrow: curobj+=val
                    elif rn in row_id:
                        if abs(val-round(val))>1e-9 or abs(val)>2147483646:
                            raise ValueError('Nonintegral or oversized matrix coefficient')
                        q=int(round(val)); rid=row_id[rn]
                        # Unit coefficients are encoded by signed one-based row indices.
                        if q==1: curcodes.append(rid+1)
                        elif q==-1: curcodes.append(-(rid+1))
                        else: raise ValueError('Expected unit matrix coefficient, found '+str(q))
                    k+=2
            elif section=='RHS':
                k=1
                while k+1<len(z):
                    rn=z[k]
                    if rn in row_id: rhs[row_id[rn]]=float(z[k+1])
                    k+=2
    if curvar is not None:
        vars_.append(curvar); inc.append(curcodes); obj.append(curobj)
    return row_names,senses,rhs,vars_,inc,obj


def read_incumbent(path, name_to_id):
    chosen=set()
    with open(path,'r',encoding='utf-8',errors='replace') as f:
        for line in f:
            s=line.strip()
            if not s or s.startswith('#'): continue
            z=s.split()
            if len(z)<2 or z[0] not in name_to_id: continue
            try: val=float(z[1])
            except ValueError: continue
            if val>0.5: chosen.add(name_to_id[z[0]])
    return chosen


def decoded(c):
    return (c-1,1) if c>0 else (-c-1,-1)


def feasible_value(sense, value, bound):
    if sense=='L': return value<=bound+1e-9
    if sense=='G': return value>=bound-1e-9
    return abs(value-bound)<=1e-9


def write_solution(path, vars_, selected, objective):
    with open(path,'w',encoding='utf-8') as f:
        f.write('# Objective value = %.17g\n'%objective)
        for j in sorted(selected): f.write(vars_[j]+' 1\n')


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--model',required=True)
    ap.add_argument('--incumbent',default='/resources/best.sol')
    ap.add_argument('--seed',type=int,default=0)
    ap.add_argument('--max-candidates',type=int,default=60000)
    ap.add_argument('--max-pair-tests',type=int,default=250000)
    a=ap.parse_args(); t0=time.time(); work=0
    result={'status':'error','algorithm_family':'incumbent_preserving_set_packing_exchange','algorithm_role':'primal','hypothesis':'The sparse verified incumbent leaves either an equality-neutral feasible augmentation or a packing-compatible equality-preserving 2-for-1 exchange.','target_bound':-73.0,'seed':a.seed,'acceptance_criterion':'Accept only an exactly row-feasible binary solution with objective strictly below the incumbent objective.','pivot_condition':'Stop at the first direct augmentation or feasible 2-for-1 exchange; otherwise report neighborhood exhaustion at configured limits.','work_units':1,'termination_reason':'initialization_failure'}
    try:
        rows,senses,rhs,vars_,inc,obj=parse_model(a.model)
        n=len(vars_); m=len(rows); name_to_id={v:i for i,v in enumerate(vars_)}
        selected=read_incumbent(a.incumbent,name_to_id)
        if not selected: raise ValueError('No selected variables were read from the verified incumbent')
        act=[0]*m; selected_by_row=[[] for _ in range(m)]
        for j in selected:
            for c in inc[j]:
                r,q=decoded(c); act[r]+=q; selected_by_row[r].append(j)
        bad=[r for r in range(m) if not feasible_value(senses[r],act[r],rhs[r])]
        if bad: raise ValueError('Supplied incumbent is infeasible in parsed representation')
        old_obj=sum(obj[j] for j in selected)
        eqrows=[r for r,s in enumerate(senses) if s=='E']; eqpos={r:k for k,r in enumerate(eqrows)}
        def sig(j):
            d={}
            for c in inc[j]:
                r,q=decoded(c)
                if r in eqpos: d[eqpos[r]]=d.get(eqpos[r],0)+q
            return tuple(sorted((k,v) for k,v in d.items() if v))
        def after_delta(rem,adds):
            delta={}
            if rem is not None:
                for c in inc[rem]:
                    r,q=decoded(c); delta[r]=delta.get(r,0)-q
            for j in adds:
                for c in inc[j]:
                    r,q=decoded(c); delta[r]=delta.get(r,0)+q
            for r,d in delta.items():
                if not feasible_value(senses[r],act[r]+d,rhs[r]): return False
            return True
        candidates=[]
        for j in range(n):
            if j not in selected: candidates.append(j)
            if len(candidates)>=a.max_candidates: break
        found=None; scanned=0
        buckets={j:[] for j in selected}
        for v in candidates:
            scanned+=1; work+=1
            if after_delta(None,[v]) and old_obj+obj[v] < old_obj-1e-9:
                found=(None,v,None); break
            blockers=set(); impossible=False
            for c in inc[v]:
                r,q=decoded(c)
                if feasible_value(senses[r],act[r]+q,rhs[r]): continue
                if senses[r]=='E': continue
                owners=selected_by_row[r]
                if not owners: impossible=True; break
                blockers.update(owners)
                if len(blockers)>1: break
            if not impossible and len(blockers)==1:
                rem=next(iter(blockers))
                if after_delta(rem,[v]): buckets[rem].append(v)
        pairtests=0
        if found is None:
            for rem,vals in buckets.items():
                target={}
                for k,vv in sig(rem): target[k]=vv
                bysig={}
                for v in vals:
                    sv=dict(sig(v)); comp=tuple(sorted((k,target.get(k,0)-sv.get(k,0)) for k in set(target)|set(sv) if target.get(k,0)-sv.get(k,0)))
                    if comp in bysig:
                        for w in bysig[comp][-16:]:
                            pairtests+=1; work+=1
                            if old_obj-obj[rem]+obj[v]+obj[w] < old_obj-1e-9 and after_delta(rem,[v,w]):
                                found=(rem,v,w); break
                            if pairtests>=a.max_pair_tests: break
                    if found or pairtests>=a.max_pair_tests: break
                    bysig.setdefault(sig(v),[]).append(v)
                if found or pairtests>=a.max_pair_tests: break
        newsel=set(selected); term='configured_neighborhood_exhausted'
        if found:
            rem,v,w=found
            if rem is not None: newsel.remove(rem)
            newsel.add(v)
            if w is not None: newsel.add(w)
            term='accepted_direct_augmentation' if rem is None else 'accepted_equality_compatible_2_for_1_exchange'
        new_obj=sum(obj[j] for j in newsel)
        if not after_delta(None,[]) or new_obj>old_obj+1e-9: raise ValueError('Internal acceptance check failed')
        # Full independent reconstruction check of the emitted candidate.
        chk=[0]*m
        for j in newsel:
            for c in inc[j]:
                r,q=decoded(c); chk[r]+=q
        if any(not feasible_value(senses[r],chk[r],rhs[r]) for r in range(m)): raise ValueError('Final candidate failed full row check')
        write_solution('best.sol',vars_,newsel,new_obj)
        report={'rows':m,'variables':n,'equalities':len(eqrows),'incumbent_selected':len(selected),'candidate_selected':len(newsel),'incumbent_objective':old_obj,'candidate_objective':new_obj,'candidates_scanned':scanned,'pair_tests':pairtests,'one_removal_bucket_sizes':{str(k):len(v) for k,v in buckets.items() if v},'improved':new_obj<old_obj-1e-9}
        with open('dry_report.json','w') as f: json.dump(report,f,indent=2,sort_keys=True)
        result.update({'status':'success','work_units':max(1,work),'termination_reason':term,'runtime_seconds':time.time()-t0,'objective':new_obj,'solution_artifact':'best.sol','report_artifact':'dry_report.json','incumbent_objective':old_obj,'candidates_scanned':scanned,'pair_tests':pairtests})
    except Exception as e:
        result.update({'status':'error','work_units':max(1,work),'termination_reason':'exception','runtime_seconds':time.time()-t0,'error':str(e)})
    with open('method_result.json','w') as f: json.dump(result,f,indent=2,sort_keys=True)

if __name__=='__main__': main()
