import argparse
import gzip
import json
import math
import os
import random
import time


def open_model(path):
    if path.lower().endswith('.gz'):
        return gzip.open(path, 'rt', encoding='utf-8', errors='replace')
    return open(path, 'rt', encoding='utf-8', errors='replace')


def parse_mps(path):
    section = None
    obj_sense = 'MIN'
    obj_row = None
    row_sense = {}
    row_order = []
    coeff = {}
    obj = {}
    rhs = {}
    ranges = {}
    lb = {}
    ub = {}
    integer = set()
    variables = []
    seen_vars = set()
    int_mode = False

    with open_model(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('*'):
                continue
            tok = line.replace("'", '').split()
            if not tok:
                continue
            key = tok[0].upper()
            if key in ('NAME', 'ROWS', 'COLUMNS', 'RHS', 'RANGES', 'BOUNDS', 'ENDATA', 'OBJSENSE', 'OBJNAME'):
                section = key
                if key == 'OBJSENSE' and len(tok) > 1:
                    obj_sense = tok[1].upper()
                if key == 'ENDATA':
                    break
                continue
            if section == 'OBJSENSE':
                obj_sense = tok[0].upper()
                continue
            if section == 'OBJNAME':
                obj_row = tok[0]
                continue
            if section == 'ROWS':
                if len(tok) >= 2:
                    s, name = tok[0].upper(), tok[1]
                    if s == 'N' and obj_row is None:
                        obj_row = name
                    elif s in ('L', 'G', 'E'):
                        row_sense[name] = s
                        row_order.append(name)
                        coeff[name] = {}
                continue
            if section == 'COLUMNS':
                if any(x.upper() == 'MARKER' for x in tok):
                    joined = ' '.join(x.upper() for x in tok)
                    if 'INTORG' in joined:
                        int_mode = True
                    elif 'INTEND' in joined:
                        int_mode = False
                    continue
                var = tok[0]
                if var not in seen_vars:
                    seen_vars.add(var)
                    variables.append(var)
                if int_mode:
                    integer.add(var)
                pairs = tok[1:]
                for k in range(0, len(pairs) - 1, 2):
                    rn = pairs[k]
                    try:
                        val = float(pairs[k + 1])
                    except ValueError:
                        continue
                    if rn == obj_row:
                        obj[var] = obj.get(var, 0.0) + val
                    elif rn in coeff:
                        coeff[rn][var] = coeff[rn].get(var, 0.0) + val
                continue
            if section in ('RHS', 'RANGES'):
                pairs = tok[1:]
                target = rhs if section == 'RHS' else ranges
                for k in range(0, len(pairs) - 1, 2):
                    rn = pairs[k]
                    try:
                        val = float(pairs[k + 1])
                    except ValueError:
                        continue
                    target[rn] = val
                continue
            if section == 'BOUNDS' and len(tok) >= 3:
                bt = tok[0].upper()
                var = tok[2]
                if var not in seen_vars:
                    seen_vars.add(var)
                    variables.append(var)
                val = 0.0
                if len(tok) >= 4:
                    try:
                        val = float(tok[3])
                    except ValueError:
                        val = 0.0
                if bt == 'BV':
                    integer.add(var); lb[var] = 0.0; ub[var] = 1.0
                elif bt == 'LI':
                    integer.add(var); lb[var] = val
                elif bt == 'UI':
                    integer.add(var); ub[var] = val
                elif bt == 'LO':
                    lb[var] = val
                elif bt == 'UP':
                    ub[var] = val
                elif bt == 'FX':
                    lb[var] = val; ub[var] = val
                elif bt == 'FR':
                    lb[var] = -math.inf; ub[var] = math.inf
                elif bt == 'MI':
                    lb[var] = -math.inf
                elif bt == 'PL':
                    ub[var] = math.inf

    if obj_row is None:
        raise RuntimeError('No objective row was found in the MPS file')
    for v in variables:
        lb.setdefault(v, 0.0)
        ub.setdefault(v, math.inf)
    obj_constant = -rhs.get(obj_row, 0.0)

    normalized = []
    for rn in row_order:
        s = row_sense[rn]
        b = rhs.get(rn, 0.0)
        a = coeff[rn]
        rg = ranges.get(rn)
        if rg is None:
            if s == 'L':
                normalized.append((rn + ':upper', dict(a), b, False))
            elif s == 'G':
                normalized.append((rn + ':lower', {v: -q for v, q in a.items()}, -b, False))
            else:
                normalized.append((rn + ':equal', dict(a), b, True))
        else:
            width = abs(rg)
            if s == 'L':
                lo, hi = b - width, b
            elif s == 'G':
                lo, hi = b, b + width
            else:
                if rg >= 0:
                    lo, hi = b, b + width
                else:
                    lo, hi = b - width, b
            normalized.append((rn + ':range_upper', dict(a), hi, False))
            normalized.append((rn + ':range_lower', {v: -q for v, q in a.items()}, -lo, False))

    if obj_sense.startswith('MAX'):
        obj = {v: -q for v, q in obj.items()}
        obj_constant = -obj_constant
    return variables, obj, obj_constant, lb, ub, integer, normalized, obj_sense


def atomic_json(path, data):
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, sort_keys=True, allow_nan=False)
    os.replace(tmp, path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--seed', type=int, default=17)
    ap.add_argument('--runtime', type=float, default=105.0)
    ap.add_argument('--target', type=float, default=-73.0)
    ap.add_argument('--incumbent', type=float, default=-72.0)
    args = ap.parse_args()
    random.seed(args.seed)
    start = time.monotonic()
    variables, obj, obj_const, lb, ub, integer, rows, original_sense = parse_mps(args.model)
    vid = {v: j for j, v in enumerate(variables)}
    n = len(variables)
    m = len(rows)
    row_terms = []
    row_rhs = []
    equality = []
    for _, a, b, eq in rows:
        row_terms.append([(vid[v], q) for v, q in a.items()])
        row_rhs.append(b)
        equality.append(eq)
    costs = [obj.get(v, 0.0) for v in variables]
    lower = [lb[v] for v in variables]
    upper = [ub[v] for v in variables]
    lam = [0.0] * m
    best = -math.inf
    best_lam = None
    best_iter = 0
    finite_evaluations = 0
    unbounded_evaluations = 0
    iterations = 0
    variable_decisions = 0
    row_term_visits = 0
    phase = 0
    theta_schedule = [1.8, 1.0, 0.55, 0.25, 0.1, 0.04]
    theta = theta_schedule[0]
    stale = 0
    last_write = 0.0
    x = [0.0] * n

    def report(final, reason):
        elapsed = time.monotonic() - start
        cert = {
            'certificate_type': 'row_lagrangian_box-relaxation',
            'model_objective_sense': original_sense,
            'transformed_to_minimization': original_sense.startswith('MAX'),
            'best_transformed_lower_bound': None if not math.isfinite(best) else best,
            'best_original_bound': None if not math.isfinite(best) else (-best if original_sense.startswith('MAX') else best),
            'iteration': best_iter,
            'row_names': [r[0] for r in rows],
            'multipliers': best_lam if best_lam is not None else [],
            'multiplier_sign_rule': 'Nonnegative for normalized <= rows and unrestricted for equality rows.',
            'box_minimization_rule': 'Each variable independently selects a finite bound minimizing its Lagrangian reduced cost.',
            'objective_constant': obj_const
        }
        atomic_json('lagrangian_certificate.json', cert)
        result = {
            'status': 'success' if finite_evaluations > 0 else 'failed',
            'algorithm_family': 'all-row Lagrangian relaxation with projected Polyak subgradient ascent',
            'algorithm_role': 'dual_bound',
            'hypothesis': 'Dualizing all 99-style coupling rows separates the binary linear program by variables and can raise the very weak solver root bound toward the apparent -73 proof threshold.',
            'work_units': max(1, iterations),
            'work_unit_name': 'complete Lagrangian evaluations',
            'termination_reason': reason,
            'target_bound': args.target,
            'best_dual_bound': None if not math.isfinite(best) else (-best if original_sense.startswith('MAX') else best),
            'transformed_minimization_bound': None if not math.isfinite(best) else best,
            'incumbent_reference': args.incumbent,
            'seed': args.seed,
            'runtime_seconds': elapsed,
            'acceptance_criterion': 'Retain a multiplier vector only when exact box minimization gives a finite Lagrangian value strictly larger than the previous best by more than 1e-10.',
            'pivot_condition': 'After 2000 nonimproving finite evaluations, reduce the Polyak factor; after exhausting the schedule, deterministically perturb active multipliers and restart the schedule.',
            'iterations': iterations,
            'finite_evaluations': finite_evaluations,
            'unbounded_evaluations': unbounded_evaluations,
            'variable_decisions': variable_decisions,
            'row_term_visits': row_term_visits,
            'rows_after_range_expansion': m,
            'variables': n,
            'certificate_artifact': 'lagrangian_certificate.json',
            'final': final
        }
        atomic_json('method_result.json', result)

    report(False, 'initialization checkpoint')
    deadline = start + args.runtime
    while time.monotonic() < deadline:
        iterations += 1
        rc = costs[:]
        constant = obj_const
        for i in range(m):
            li = lam[i]
            constant -= li * row_rhs[i]
            if li != 0.0:
                for j, a in row_terms[i]:
                    rc[j] += li * a
            row_term_visits += len(row_terms[i])
        value = constant
        finite = True
        for j in range(n):
            c = rc[j]
            if c >= 0.0:
                pick = lower[j]
            else:
                pick = upper[j]
            if not math.isfinite(pick):
                finite = False
                break
            if variables[j] in integer:
                if c >= 0.0:
                    pick = math.ceil(pick - 1e-12)
                else:
                    pick = math.floor(pick + 1e-12)
            x[j] = pick
            value += c * pick
            variable_decisions += 1
        if not finite:
            unbounded_evaluations += 1
            # A conservative feasibility-restoring multiplier push for unbounded reduced costs.
            for i in range(m):
                if not equality[i]:
                    lam[i] = max(0.0, lam[i] + 1e-4 * (1.0 + (i % 17)))
            continue
        finite_evaluations += 1
        if value > best + 1e-10:
            best = value
            best_lam = list(lam)
            best_iter = iterations
            stale = 0
        else:
            stale += 1
        g = [-row_rhs[i] for i in range(m)]
        for i in range(m):
            s = g[i]
            for j, a in row_terms[i]:
                s += a * x[j]
            g[i] = s
            row_term_visits += len(row_terms[i])
        norm2 = sum(q * q for q in g)
        if norm2 <= 1e-24:
            report(True, 'zero subgradient reached')
            return
        upper_reference = args.incumbent
        gap = max(1e-6, upper_reference - value)
        step = theta * gap / norm2
        step = min(step, 1e4 / math.sqrt(1.0 + iterations))
        for i in range(m):
            nv = lam[i] + step * g[i]
            lam[i] = nv if equality[i] else max(0.0, nv)
        if stale >= 2000:
            stale = 0
            phase += 1
            if phase < len(theta_schedule):
                theta = theta_schedule[phase]
            else:
                phase = 0
                theta = theta_schedule[0]
                base = best_lam if best_lam is not None else lam
                lam = []
                for i, z in enumerate(base):
                    scale = 1.0 + 0.015 * math.sin((iterations + 31 * i + args.seed) * 0.017)
                    nz = z * scale
                    lam.append(nz if equality[i] else max(0.0, nz))
        now = time.monotonic()
        if now - last_write >= 10.0:
            report(False, 'periodic checkpoint while search continues')
            last_write = now
    report(True, 'configured algorithmic runtime exhausted')


if __name__ == '__main__':
    main()
