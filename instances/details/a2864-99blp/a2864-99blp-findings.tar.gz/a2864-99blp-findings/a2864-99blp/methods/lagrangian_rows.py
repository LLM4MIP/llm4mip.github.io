import argparse, gzip, json, math, os, random, time, csv
from fractions import Fraction


def q(s):
    return Fraction(s.replace('D','E').replace('d','e'))


def open_model(path):
    return gzip.open(path, 'rt', errors='replace') if path.endswith('.gz') else open(path, 'r', errors='replace')


def parse_mps(path):
    section = None
    obj_sense = 'MIN'
    objrow = None
    row_type = {}
    row_order = []
    coeff_by_col = {}
    obj = {}
    rhs = {}
    lo = {}
    up = {}
    integer = set()
    all_cols = []
    seen_cols = set()
    in_integer = False
    ranges_seen = False
    with open_model(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('*'):
                continue
            tok = line.split()
            head = tok[0].upper()
            if head in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE','OBJNAME'):
                section = head
                if head == 'RANGES':
                    ranges_seen = True
                if head == 'ENDATA':
                    break
                continue
            if section == 'OBJSENSE':
                obj_sense = tok[0].upper()
                continue
            if section == 'ROWS':
                typ, name = tok[0].upper(), tok[1]
                if typ == 'N' and objrow is None:
                    objrow = name
                elif typ in ('L','G','E'):
                    row_type[name] = typ
                    row_order.append(name)
                continue
            if section == 'COLUMNS':
                if any('MARKER' in z.upper() for z in tok):
                    joined = ' '.join(tok).upper()
                    if 'INTORG' in joined:
                        in_integer = True
                    elif 'INTEND' in joined:
                        in_integer = False
                    continue
                col = tok[0]
                if col not in seen_cols:
                    seen_cols.add(col); all_cols.append(col)
                if in_integer:
                    integer.add(col)
                pairs = tok[1:]
                for k in range(0, len(pairs)-1, 2):
                    r, val = pairs[k], q(pairs[k+1])
                    if r == objrow:
                        obj[col] = obj.get(col, Fraction(0)) + val
                    elif r in row_type:
                        coeff_by_col.setdefault(col, []).append((r, val))
                continue
            if section == 'RHS':
                pairs = tok[1:]
                for k in range(0, len(pairs)-1, 2):
                    rhs[pairs[k]] = rhs.get(pairs[k], Fraction(0)) + q(pairs[k+1])
                continue
            if section == 'BOUNDS':
                typ = tok[0].upper(); col = tok[2]
                if col not in seen_cols:
                    seen_cols.add(col); all_cols.append(col)
                val = q(tok[3]) if len(tok) > 3 else Fraction(0)
                if typ == 'BV':
                    lo[col] = Fraction(0); up[col] = Fraction(1); integer.add(col)
                elif typ == 'FX':
                    lo[col] = val; up[col] = val
                elif typ in ('LO','LI'):
                    lo[col] = val
                    if typ == 'LI': integer.add(col)
                elif typ in ('UP','UI'):
                    up[col] = val
                    if typ == 'UI': integer.add(col)
                elif typ == 'FR':
                    lo[col] = None; up[col] = None
                elif typ == 'MI':
                    lo[col] = None
                elif typ == 'PL':
                    up[col] = None
                continue
    if ranges_seen:
        raise ValueError('RANGES records are unsupported because silently ignoring them would invalidate the dual certificate')
    if objrow is None:
        raise ValueError('No objective row found')
    if obj_sense.startswith('MAX'):
        raise ValueError('This implementation certifies minimization lower bounds only')
    cols = all_cols
    ci = {c:i for i,c in enumerate(cols)}
    ri = {r:i for i,r in enumerate(row_order)}
    n, m = len(cols), len(row_order)
    cfrac = [obj.get(c, Fraction(0)) for c in cols]
    rhsfrac = [rhs.get(r, Fraction(0)) for r in row_order]
    lofrac, upfrac = [], []
    for c in cols:
        # MPS default is nonnegative with no finite upper bound.
        l = lo[c] if c in lo else Fraction(0)
        u = up[c] if c in up else None
        lofrac.append(l); upfrac.append(u)
    col_entries = [[] for _ in range(n)]
    row_entries = [[] for _ in range(m)]
    for c, entries in coeff_by_col.items():
        j = ci[c]
        for r, a in entries:
            i = ri[r]
            col_entries[j].append((i, a))
            row_entries[i].append((j, a))
    obj_const = -rhs.get(objrow, Fraction(0))
    return {'cols':cols,'rows':row_order,'rtype':[row_type[r] for r in row_order],
            'c':cfrac,'rhs':rhsfrac,'lo':lofrac,'up':upfrac,'col_entries':col_entries,
            'row_entries':row_entries,'obj_const':obj_const,'integer':integer}


def exact_bound(M, lam_float, digits=10):
    # Decimal-looking rational multipliers make the certificate independently reproducible.
    lam = [Fraction(format(v, '.10g')) for v in lam_float]
    total = M['obj_const']
    for i, typ in enumerate(M['rtype']):
        if typ == 'L': total -= lam[i] * M['rhs'][i]
        elif typ == 'G': total += lam[i] * M['rhs'][i]
        else: total -= lam[i] * M['rhs'][i]
    reduced = list(M['c'])
    for j, ent in enumerate(M['col_entries']):
        z = reduced[j]
        for i, a in ent:
            typ = M['rtype'][i]
            z += (lam[i] * a if typ in ('L','E') else -lam[i] * a)
        reduced[j] = z
    chosen = []
    for j, rc in enumerate(reduced):
        l, u = M['lo'][j], M['up'][j]
        if rc > 0:
            if l is None: return None, lam, 'negative_infinity_from_missing_lower_bound'
            total += rc*l; chosen.append(l)
        elif rc < 0:
            if u is None: return None, lam, 'negative_infinity_from_missing_upper_bound'
            total += rc*u; chosen.append(u)
        else:
            chosen.append(l if l is not None else (u if u is not None else Fraction(0)))
    return total, lam, None


def run(args):
    started = time.monotonic()
    rng = random.Random(args.seed)
    M = parse_mps(args.model)
    n, m = len(M['cols']), len(M['rows'])
    c = [float(v) for v in M['c']]
    b = [float(v) for v in M['rhs']]
    low = [None if v is None else float(v) for v in M['lo']]
    high = [None if v is None else float(v) for v in M['up']]
    cent = [[(i,float(a)) for i,a in e] for e in M['col_entries']]
    rent = [[(j,float(a)) for j,a in e] for e in M['row_entries']]
    typ = M['rtype']
    lam = [0.0]*m
    best_lam = list(lam)
    best_float = -math.inf
    iterations = 0
    restarts = 0
    stagnant = 0
    alpha = 1.6
    target = args.incumbent
    deadline = started + args.runtime
    trace = []
    while time.monotonic() < deadline:
        iterations += 1
        reduced = c[:]
        constant = float(M['obj_const'])
        for i in range(m):
            li = lam[i]
            if typ[i] == 'L': constant -= li*b[i]
            elif typ[i] == 'G': constant += li*b[i]
            else: constant -= li*b[i]
        for j,e in enumerate(cent):
            z = reduced[j]
            for i,a in e:
                z += lam[i]*a if typ[i] in ('L','E') else -lam[i]*a
            reduced[j] = z
        x = [0.0]*n
        phi = constant
        invalid = None
        for j,rc in enumerate(reduced):
            if rc > 1e-14:
                if low[j] is None: invalid = 'missing_lower_bound'; break
                x[j] = low[j]
            elif rc < -1e-14:
                if high[j] is None: invalid = 'missing_upper_bound'; break
                x[j] = high[j]
            else:
                choices = [v for v in (low[j],high[j]) if v is not None]
                x[j] = choices[rng.randrange(len(choices))] if choices else 0.0
            phi += rc*x[j]
        if invalid:
            raise ValueError('Lagrangian subproblem is unbounded: '+invalid)
        if phi > best_float + 1e-8:
            best_float = phi; best_lam = list(lam); stagnant = 0
        else:
            stagnant += 1
        activity = [0.0]*m
        for i,e in enumerate(rent):
            activity[i] = sum(a*x[j] for j,a in e)
        grad = [0.0]*m
        norm2 = 0.0
        for i in range(m):
            if typ[i] == 'L': g = activity[i]-b[i]
            elif typ[i] == 'G': g = b[i]-activity[i]
            else: g = activity[i]-b[i]
            grad[i] = g; norm2 += g*g
        if norm2 <= 1e-24:
            trace.append((iterations,time.monotonic()-started,best_float,phi,alpha,restarts))
            break
        gap = max(1.0, target-phi)
        step = alpha*gap/norm2
        for i in range(m):
            nv = lam[i] + step*grad[i]
            lam[i] = nv if typ[i] == 'E' else max(0.0,nv)
        if stagnant >= 5000:
            alpha = max(0.02, alpha*0.55)
            # Restart around the best multiplier with a diminishing, seeded perturbation.
            scale = 0.03/(1.0+restarts)
            lam = [v + rng.uniform(-scale,scale)*max(1.0,abs(v)) for v in best_lam]
            for i in range(m):
                if typ[i] != 'E': lam[i] = max(0.0,lam[i])
            stagnant = 0; restarts += 1
        if iterations == 1 or iterations % 250 == 0:
            trace.append((iterations,time.monotonic()-started,best_float,phi,alpha,restarts))
    bound, qlam, err = exact_bound(M,best_lam)
    if err: raise ValueError(err)
    cert = {'certificate_type':'row_lagrangian_separable_bound','objective_sense':'minimize',
            'bound_fraction':str(bound),'bound_decimal':float(bound),
            'row_names':M['rows'],'row_types':M['rtype'],
            'multipliers_fraction':[str(v) for v in qlam],
            'validity':'For L rows multipliers are nonnegative on Ax-b<=0; for G rows they are nonnegative on b-Ax<=0; E multipliers are free. The reported value is the exact rational minimum of the resulting separable linear function over every variable bound.',
            'variables':n,'rows':m,'objective_constant_fraction':str(M['obj_const'])}
    with open('lagrangian_certificate.json','w') as f: json.dump(cert,f,indent=2)
    with open('lagrangian_trace.csv','w',newline='') as f:
        w=csv.writer(f); w.writerow(['iteration','elapsed_seconds','best_float_bound','current_float_bound','polyak_alpha','restarts']); w.writerows(trace)
    elapsed=time.monotonic()-started
    result={'status':'success','algorithm_family':'full-row Lagrangian relaxation with projected Polyak subgradient optimization',
            'algorithm_role':'dual_bound','hypothesis':'Dualizing the small row system exposes a separable bounded-variable subproblem and can improve the very weak root lower bound while retaining an exactly checkable global certificate.',
            'work_units':iterations,'work_unit_name':'subgradient iterations','termination_reason':'zero_subgradient' if trace and iterations==trace[-1][0] and elapsed < args.runtime-1 else 'configured_runtime_reached',
            'target_bound':args.target_bound,'certified_dual_bound':float(bound),'certified_dual_bound_fraction':str(bound),
            'improves_target':float(bound)>args.target_bound+1e-9,'seed':args.seed,'runtime_seconds':elapsed,
            'acceptance_criterion':'Accept only an exact rational certificate whose lower bound exceeds the target lower bound.',
            'pivot_condition':'If 5000 iterations give no floating-bound improvement, reduce the Polyak factor and restart near the best multipliers; replace the relaxation if the dry run remains near the trivial bound.',
            'iterations':iterations,'restarts':restarts,'variables':n,'rows':m,'certificate_artifact':'lagrangian_certificate.json','trace_artifact':'lagrangian_trace.csv'}
    with open('method_result.json','w') as f: json.dump(result,f,indent=2)


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--model',required=True)
    p.add_argument('--seed',type=int,default=286499)
    p.add_argument('--runtime',type=float,default=105.0)
    p.add_argument('--incumbent',type=float,default=-72.0)
    p.add_argument('--target-bound',type=float,default=-13841.0)
    args=p.parse_args()
    try:
        run(args)
    except Exception as e:
        out={'status':'failed','algorithm_family':'full-row Lagrangian relaxation with projected Polyak subgradient optimization','algorithm_role':'dual_bound','hypothesis':'Dualizing all rows should produce a useful certified separable lower bound.','work_units':1,'termination_reason':'parsing_representation_or_unbounded_subproblem_failure','target_bound':args.target_bound,'seed':args.seed,'runtime_seconds':0.0,'acceptance_criterion':'An exact rational certified bound must exceed the target.','pivot_condition':'Repair parsing or bound representation if reported; otherwise replace this relaxation.','error':repr(e)}
        with open('method_result.json','w') as f: json.dump(out,f,indent=2)
        raise

if __name__=='__main__': main()
