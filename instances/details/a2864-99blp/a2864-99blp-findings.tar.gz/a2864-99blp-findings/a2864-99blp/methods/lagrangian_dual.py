import argparse, gzip, json, math, os, random, time
from fractions import Fraction


def frac(s):
    return Fraction(s.replace('D','E').replace('d','e'))


def toks(line):
    return line.strip().split()


def parse_mps(path):
    op = gzip.open if path.endswith('.gz') else open
    rows = {}
    row_order = []
    objrow = None
    cols = {}
    c = {}
    rhs = {}
    ranges = {}
    lb = {}
    ub = {}
    integer = set()
    section = None
    objsense = 'MIN'
    marker_int = False
    pending_objsense = False
    with op(path, 'rt', errors='replace') as f:
        for raw in f:
            if not raw.strip() or raw.lstrip().startswith('*'):
                continue
            p = toks(raw)
            if not p:
                continue
            head = p[0].upper()
            if pending_objsense and head not in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE','OBJNAME'):
                objsense = 'MAX' if head.startswith('MAX') else 'MIN'
                pending_objsense = False
                continue
            if head == 'OBJSENSE':
                if len(p) > 1:
                    objsense = 'MAX' if p[1].upper().startswith('MAX') else 'MIN'
                else:
                    pending_objsense = True
                section = 'OBJSENSE'
                continue
            if head in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJNAME'):
                section = head
                if head == 'ENDATA':
                    break
                continue
            if section == 'ROWS':
                typ, name = p[0].upper(), p[1]
                if typ == 'N' and objrow is None:
                    objrow = name
                else:
                    rows[name] = typ
                    row_order.append(name)
            elif section == 'COLUMNS':
                joined = ' '.join(p).upper().replace("'",'')
                if 'MARKER' in joined:
                    if 'INTORG' in joined:
                        marker_int = True
                    elif 'INTEND' in joined:
                        marker_int = False
                    continue
                v = p[0]
                cols.setdefault(v, {})
                if marker_int:
                    integer.add(v)
                q = p[1:]
                for i in range(0, len(q)-1, 2):
                    r, a = q[i], frac(q[i+1])
                    if r == objrow:
                        c[v] = c.get(v, Fraction(0)) + a
                    elif r in rows:
                        cols[v][r] = cols[v].get(r, Fraction(0)) + a
            elif section == 'RHS':
                q = p[1:]
                for i in range(0, len(q)-1, 2):
                    rhs[q[i]] = frac(q[i+1])
            elif section == 'RANGES':
                q = p[1:]
                for i in range(0, len(q)-1, 2):
                    ranges[q[i]] = frac(q[i+1])
            elif section == 'BOUNDS':
                typ = p[0].upper()
                v = p[2]
                val = frac(p[3]) if len(p) > 3 else Fraction(0)
                if typ == 'LO': lb[v] = val
                elif typ == 'UP': ub[v] = val
                elif typ == 'FX': lb[v] = val; ub[v] = val
                elif typ == 'FR': lb[v] = None; ub[v] = None
                elif typ == 'MI': lb[v] = None
                elif typ == 'PL': ub[v] = None
                elif typ == 'BV': lb[v] = Fraction(0); ub[v] = Fraction(1); integer.add(v)
                elif typ == 'LI': lb[v] = val; integer.add(v)
                elif typ == 'UI': ub[v] = val; integer.add(v)
                elif typ == 'SC': ub[v] = val
    names = list(cols.keys())
    for v in names:
        if v not in lb: lb[v] = Fraction(0)
        if v not in ub: ub[v] = None
        c.setdefault(v, Fraction(0))
    # Objective is transformed to minimization. MPS RHS on the objective row is an offset of -RHS.
    sign = Fraction(-1) if objsense == 'MAX' else Fraction(1)
    for v in names:
        c[v] *= sign
    obj_const = -rhs.get(objrow, Fraction(0)) * sign
    # Derive lower and upper activity limits, including MPS ranges.
    rlo, rup = {}, {}
    for r in row_order:
        b = rhs.get(r, Fraction(0)); typ = rows[r]
        if typ == 'L': rup[r] = b
        elif typ == 'G': rlo[r] = b
        elif typ == 'E': rlo[r] = b; rup[r] = b
        if r in ranges:
            z = ranges[r]; a = abs(z)
            if typ == 'L': rlo[r] = b-a
            elif typ == 'G': rup[r] = b+a
            elif typ == 'E':
                if z >= 0: rup[r] = b+a
                else: rlo[r] = b-a
    ridx = {r:i for i,r in enumerate(row_order)}
    base_rows = [[] for _ in row_order]
    for j,v in enumerate(names):
        for r,a in cols[v].items():
            if a: base_rows[ridx[r]].append((j,a))
    # Every item is g_k(x)<=0. Two sides represent equality without unrestricted multipliers.
    ineq = []
    meta = []
    for i,r in enumerate(row_order):
        if r in rup:
            ineq.append((base_rows[i], -rup[r])); meta.append({'row':r,'side':'upper','rhs':str(rup[r])})
        if r in rlo:
            ineq.append(([(j,-a) for j,a in base_rows[i]], rlo[r])); meta.append({'row':r,'side':'lower','rhs':str(rlo[r])})
    return names, c, lb, ub, obj_const, ineq, meta, objsense, len(integer)


def exact_bound(names,c,lb,ub,obj_const,ineq,lam):
    red = [c[v] for v in names]
    constant = obj_const
    for k,L in enumerate(lam):
        if not L: continue
        entries, con = ineq[k]
        constant += L*con
        for j,a in entries: red[j] += L*a
    value = constant
    for j,v in enumerate(names):
        a = red[j]
        if a > 0:
            if lb[v] is None: return None
            value += a*lb[v]
        elif a < 0:
            if ub[v] is None: return None
            value += a*ub[v]
    return value


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--model',required=True)
    ap.add_argument('--seed',type=int,default=17)
    ap.add_argument('--run-seconds',type=float,default=145.0)
    ap.add_argument('--denominator',type=int,default=1000000)
    ap.add_argument('--target',type=float,default=-72.0)
    a=ap.parse_args()
    started=time.time(); random.seed(a.seed)
    try:
        names,cq,lbq,ubq,obj_const_q,ineq_q,meta,sense,nint=parse_mps(a.model)
        n=len(names); m=len(ineq_q)
        cf=[float(cq[v]) for v in names]
        lbf=[None if lbq[v] is None else float(lbq[v]) for v in names]
        ubf=[None if ubq[v] is None else float(ubq[v]) for v in names]
        icon=[float(z[1]) for z in ineq_q]
        ient=[[(j,float(v)) for j,v in z[0]] for z in ineq_q]
        col=[[] for _ in range(n)]
        for k,ent in enumerate(ient):
            for j,v in ent: col[j].append((k,v))
        lam=[0.0]*m; best_lam=list(lam); best=-math.inf
        target = a.target if sense == 'MIN' else -a.target
        alpha=1.7; noimp=0; it=0; states=0
        deadline=started+max(2.0,a.run_seconds)
        while time.time()<deadline:
            red=cf[:]
            constant=float(obj_const_q)
            for k,L in enumerate(lam):
                if L:
                    constant += L*icon[k]
                    for j,v in ient[k]: red[j]+=L*v
            x=[0.0]*n; q=constant
            finite=True
            for j,r in enumerate(red):
                if r>0:
                    if lbf[j] is None: finite=False; break
                    x[j]=lbf[j]; q+=r*x[j]
                elif r<0:
                    if ubf[j] is None: finite=False; break
                    x[j]=ubf[j]; q+=r*x[j]
                else:
                    x[j]=lbf[j] if lbf[j] is not None else 0.0
            if not finite:
                raise RuntimeError('The separable relaxation is unbounded for the current multiplier; finite variable bounds are required for this implementation.')
            g=icon[:]
            for j,xj in enumerate(x):
                if xj:
                    for k,v in col[j]: g[k]+=v*xj
            norm=sum(z*z for z in g)
            if q>best+1e-10:
                best=q; best_lam=list(lam); noimp=0
            else: noimp+=1
            if norm<=1e-24:
                break
            gap=max(1.0, target-q)
            step=alpha*gap/norm
            # Projected ascent is valid for all g_k(x)<=0 multipliers.
            for k in range(m): lam[k]=max(0.0,lam[k]+step*g[k])
            if noimp>=400:
                alpha=max(0.03,alpha*0.72)
                # Stabilize around the best dual vector, with deterministic tiny diversification.
                for k in range(m):
                    lam[k]=max(0.0,0.8*best_lam[k]+0.2*lam[k]+(random.random()-0.5)*1e-8)
                noimp=0
            it+=1; states+=n+m
        D=a.denominator
        # Rounding nonnegative multipliers downward is not assumed to improve the bound; recompute exactly.
        cert_lam=[Fraction(max(0,int(math.floor(z*D))),D) for z in best_lam]
        cert=exact_bound(names,cq,lbq,ubq,obj_const_q,ineq_q,cert_lam)
        if cert is None: raise RuntimeError('Quantized certificate produced an unbounded separable subproblem.')
        # Also test nearest rational multipliers and retain whichever exact certificate is stronger.
        near=[Fraction(max(0,int(round(z*D))),D) for z in best_lam]
        cert2=exact_bound(names,cq,lbq,ubq,obj_const_q,ineq_q,near)
        if cert2 is not None and cert2>cert: cert,cert_lam=cert2,near
        original_bound = cert if sense=='MIN' else -cert
        cert_json={
          'certificate_type':'separable_lagrangian_row_multiplier_bound',
          'objective_sense':sense,
          'transformed_minimization_bound_numerator':cert.numerator,
          'transformed_minimization_bound_denominator':cert.denominator,
          'original_objective_bound':str(original_bound),
          'validity_rule':'For each listed inequality g_k(x)<=0, lambda_k>=0. Therefore c(x)+sum(lambda_k*g_k(x))<=c(x) for every feasible x. The reported transformed minimization bound is the exact minimum of this Lagrangian over the original independent variable bounds.',
          'multipliers':[{'inequality':meta[k], 'numerator':L.numerator,'denominator':L.denominator} for k,L in enumerate(cert_lam) if L],
          'variables':n,'row_sides':m
        }
        with open('lagrangian_certificate.json','w') as f: json.dump(cert_json,f,indent=2)
        elapsed=time.time()-started
        result={
          'status':'success','algorithm_family':'projected_subgradient_lagrangian_relaxation',
          'algorithm_role':'dual_bound',
          'hypothesis':'The model has relatively few coupling rows and many bounded binary variables, so row dualization yields a cheap separable relaxation and useful globally valid rational objective bounds.',
          'work_units':states,'iterations':it,'runtime_seconds':elapsed,'seed':a.seed,
          'acceptance_criterion':'Accept a multiplier vector only when exact rational recomputation increases the certified separable Lagrangian bound.',
          'pivot_condition':'After 400 nonimproving iterations, reduce the Polyak factor and stabilize the current vector around the best multiplier vector.',
          'termination_reason':'stationary_subgradient' if time.time()<deadline else 'configured_runtime_reached',
          'target_bound':'Close or reduce the gap to the verified incumbent -72 using a globally valid dual certificate.',
          'objective_sense':sense,'certified_bound':str(original_bound),
          'transformed_minimization_bound':str(cert),'variables':n,'integer_variables':nint,'row_sides':m,
          'certificate_artifact':'lagrangian_certificate.json'
        }
        with open('method_result.json','w') as f: json.dump(result,f,indent=2)
    except Exception as e:
        elapsed=time.time()-started
        result={'status':'failed','algorithm_family':'projected_subgradient_lagrangian_relaxation','algorithm_role':'dual_bound','hypothesis':'Few coupling rows permit a useful separable Lagrangian bound.','work_units':1,'runtime_seconds':elapsed,'seed':a.seed,'acceptance_criterion':'Exact rational bound improvement.','pivot_condition':'Adaptive projected-subgradient stabilization.','termination_reason':'implementation_or_representation_failure: '+repr(e),'target_bound':'A globally valid dual bound approaching -72.'}
        with open('method_result.json','w') as f: json.dump(result,f,indent=2)
        raise

if __name__=='__main__': main()
