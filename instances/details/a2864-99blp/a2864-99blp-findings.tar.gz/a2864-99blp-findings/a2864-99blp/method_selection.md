# Method Selection

## Classification-driven comparison

The instance is a dense unit-coefficient binary cardinality packing problem with only 17 equality rows. Methods were selected from that structure rather than from a generic solver portfolio.

### Candidate A: equality-aware low-row exchange search

**Role:** primal.

Parse the MPS into compressed incidence arrays, build or import a feasible set, maintain integral row loads, and explore additions followed by small ejection chains. Candidate additions are prioritized by low scarcity-weighted row consumption and by compatibility with the equality signature. Acceptance requires exact feasibility and a strict cardinality increase; neutral moves may be admitted only as bounded diversification when they alter the equality-compatible frontier.

**Why it fits:** all coefficients are one, capacities are small, and incremental row-load updates are exact. It avoids constructing the enormous conflict graph.

**Risk:** equality repair may dominate, or a 1-for-k neighborhood may be too small. The pivot is to enlarge to paired additions, bounded-depth ejection chains, and equality-signature buckets.

### Candidate B: randomized greedy construction with adaptive penalties and path relinking

**Role:** primal.

Construct multiple equality-compatible solutions using randomized restricted candidate lists. Score a column by objective gain divided by adaptive row scarcity, penalizing rows that repeatedly block additions. Relink elite solutions by adding columns from one elite set while repairing with removals from the other.

**Why it is distinct:** this searches globally through repeated construction and elite recombination rather than locally around one incumbent.

**Risk:** dense scoring can be expensive and equality feasibility may be rare. The pivot is lazy score recomputation, equality-signature seeding, and repair-first construction.

### Candidate C: certified Lagrangian multiplier optimization

**Role:** dual bound.

Optimize the valid packing/equality Lagrangian bound

`U = lambda*b + mu*d + sum_j max(0,1-A_j*lambda-E_j*mu)`

with nonnegative inequality multipliers and free equality multipliers. Use projected subgradient or coordinate/bundle-like updates, then scale and round multipliers outward. Emit a compact multiplier certificate and independently recompute the bound.

**Why it fits:** the objective and matrix are unit coefficient, so every bound evaluation is a sparse matrix pass and the resulting certificate has a simple mathematical interpretation.

**Risk:** nonsmooth optimization may stall at a weak bound. The pivot is row aggregation, active-column screening, coordinate refinement, and rational polishing of the best multiplier vector.

### Candidate D: row-price primal-dual hybrid with surrogate-capacity filtering

**Role:** hybrid.

Alternate between multiplicative row-price updates and feasible packing construction. Expensive or saturated rows receive higher prices; candidate columns are selected by low total price while equality deficits are tracked explicitly. The prices also produce a valid Lagrangian bound after a separate certificate-safe projection and evaluation.

**Why it is distinct:** it couples online primal construction to multiplicative resource prices rather than using fixed greedy scores or pure dual optimization.

**Risk:** heuristic prices need not themselves certify a useful bound. Only the separately checked Lagrangian evaluation is accepted as dual evidence.

### Candidate E: cardinality decision proof by pseudo-Boolean/SAT encoding

**Role:** proof.

Test whether a cardinality above a chosen threshold is feasible by encoding unit-coefficient row capacities, equalities, and the global cardinality target into CNF, then use CaDiCaL and validate an UNSAT proof with `drat-trim` when feasible in size.

**Why it is complementary:** a checked UNSAT certificate could prove an upper cardinality limit independently of a MIP solver.

**Risk:** naive sequential counters on dense rows may be prohibitively large. This method is deferred until parsing statistics reveal a manageable threshold encoding or structural decomposition. No proof will be claimed without successful independent checking.

## Selected execution order

1. Independently verify and import the official cardinality-257 solution, then dry-run and scale Candidate A to test whether it is locally improvable.
2. Dry-run Candidate C early to satisfy the need for a globally valid dual-bound method and to measure sparse bound-evaluation throughput.
3. Dry-run and scale Candidate B as a materially distinct global primal method.
4. Dry-run and scale Candidate D as a distinct primal-dual resource-pricing method.
5. Consider Candidate E only after encoding-size estimates; use it for proof only if the estimated CNF and certificate are tractable.

At least four materially distinct custom methods will be launched. At least three must finish successfully with positive numeric work units, and successful runs must accumulate at least 3600 seconds of actual algorithmic runtime, including at least one genuine 1800-second scaled run. A short run that exhausts its neighborhood will be enlarged or replaced rather than idled.

## Tool decision

Python and C++17 are sufficient for parsing, sparse incidence structures, local search, and multiplier optimization. Configured trusted tools are CaDiCaL and `drat-trim`; they are relevant only to Candidate E and are not treated as default choices. No generic MIP solver will be hidden in custom code. Gurobi/COPT direct runs remain unavailable until all custom gates are met.

## Bound-aware decision rule

The official minimization primal target is -257, the current experiment incumbent is -72, and the diagnostic dual is -13841. Candidate A and B target a primal value below -257 after importing the official solution. Candidate C targets a valid dual value above -13841. Candidate D targets either side but counts dual progress only after certificate-safe reevaluation. Candidate E targets a proof at a selected cardinality threshold. Every result will be compared with the sourced public target and the best verified value in `experiments.json`.
