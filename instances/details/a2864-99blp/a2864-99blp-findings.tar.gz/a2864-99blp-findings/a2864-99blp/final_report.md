# Final report: a2864-99blp

## Outcome

**Partial result only — feasible, not proved optimal.**

The best final incumbent has objective **-72** for this minimization problem. The controller independently rechecked that incumbent with exact-decimal model evaluation at tolerance `1e-9`; it is therefore **tolerance-verified feasible**, not merely solver-accepted. The best solver-reported global lower bound is **-13841**. It was not accompanied by an independently checked certificate and must not be described as a certified dual bound.

No run returned strict `OPTIMAL` or `INFEASIBLE` status. Both direct solver runs ended at their time limits. Consequently, this experiment proves neither optimality nor infeasibility.

The controller's common bound-pair gap is

`(-72 - (-13841)) / abs(-72) = 191.23611111111111`,

or **19,123.6111%** when displayed as a percentage. COPT separately reported `0.9947980637` (99.4798%) using its own denominator convention. These values should not be conflated.

## Comparison with prior targets and internal baselines

The sourced public primal target recorded during background research was **-72**. The final verified incumbent equals that target and therefore **does not improve the public primal bound**. The experiment did not establish a stronger sourced public dual bound. In particular, `-13841` is only a solver-reported search bound and is not an independent certificate; no public dual record is inferred from it.

The short Gurobi and COPT baselines both already found primal **-72** and dual **-13841**. Later custom methods did not improve either number. Thus there was **no experiment-internal numerical improvement and no gap reduction** after the baselines. The useful result is negative and methodological: structure-specific constructive methods could reproduce the incumbent, while the attempted proof/bound approaches did not close or strengthen the global bound within the controlled budget.

## Problem classification and structure

The instance is a pure binary, unit-coefficient set-packing model with a small equality subsystem. It minimizes `-sum_j x_j`, equivalently maximizing selected-set cardinality. The model contains:

- 200,787 binary variables;
- 22,117 rows;
- 22,100 packing inequalities;
- 17 equalities;
- 20,078,717 unit matrix coefficients; and
- objective coefficient `-1` on every variable.

Background research classifies it as a finite-projective-geometry subspace-selection problem related to partial plane spreads in `PG(7,2)`. The decisive computational features are the large sparse incidence hypergraph, uniform cardinality objective, incremental row-load feasibility checks, and the need to preserve or repair the 17 equalities. Symmetry and severe degeneracy make generic branching difficult but make row-load-based greedy and exchange neighborhoods natural.

## Methods considered

The experiment considered materially different algorithm families rather than treating parameter tuning as the primary research method:

1. a short generic MIP baseline with Gurobi;
2. a short generic MIP baseline with COPT;
3. structure-specific constructive packing with incremental row loads;
4. revised/local-exchange incumbent search around a feasible packing;
5. a larger or scaled neighborhood search after initial neighborhoods were exhausted;
6. proof-oriented or dual-oriented combinatorial analysis; and
7. a threshold/certificate-oriented route using pseudo-Boolean or SAT concepts where the available encoding was supportable.

Other standard approaches considered in the design stage included LP/cover strengthening, counting or Delsarte-style inequalities, symmetry/orbit aggregation, conflict-graph methods, and checked SAT/PB certificates for a fixed cardinality threshold. These were distinguished from direct MIP solving.

## Direct solver baselines

| Solver | Termination | Runtime (s) | Primal | Dual | Verification |
|---|---:|---:|---:|---:|---|
| COPT | `TIMEOUT` | 120.223058 | -72 | -13841 | incumbent verified at `1e-9` |
| Gurobi | `TIME_LIMIT` | 120.526580 | -72 | -13841 | incumbent verified at `1e-9` |

The direct-solver runtime was **240.749638 seconds**. These runs are short diagnostic baselines, not problem-specific algorithms. Their time-limit statuses are not evidence of optimality or infeasibility. The reported dual values are ordinary solver search bounds, not independently certified certificates.

No nondefault random seed is documented in the compressed archival evidence; absent an explicit ledger entry, solver defaults must be assumed rather than inventing a seed. The controller controlled thread count, time limit, and result/log locations. Gurobi and COPT versions and detailed host CPU/RAM metadata were not present in the compressed summaries available for this draft and are therefore not fabricated.

## Custom algorithms

Five custom Python runs were recorded:

| Run | Ledger status | Runtime (s) | Numerical result |
|---|---|---:|---|
| `custom-20260904-225213-2180ebd7` | success | 37.061944 | -72, verified at `1e-9` |
| `custom-20260904-225229-7ab3efb8` | success | 39.342905 | -72, verified at `1e-9` |
| `custom-20260904-230317-b2511486` | completed | 92.784706 | no candidate bound recorded |
| `custom-20260904-231314-3ef592ad` | success | 108.989013 | proof/bound-oriented result, no improved bound |
| `custom-20260904-231859-255c62e3` | unsupported | 48.560111 | unsupported route; no bound |

The first two successful constructive runs independently reproduced the objective -72 incumbent and passed tolerance verification. The later runs explored enlarged/revised neighborhoods and proof- or encoding-oriented routes. One completed without a numerical candidate, one successful proof-oriented computation produced no improved global bound, and one explicitly terminated as unsupported. A custom algorithm's own claim would not have constituted a proof in any event; no independently checked certificate emerged.

Exact algorithm-family labels, source filenames, measured work-unit fields, and individual hypotheses are retained in the per-run `method_result.json` records and controller ledgers. They should be copied into this report only from those records, not guessed. All custom programs were Python and were run CPU-only in the controller's bubblewrap sandbox. Model/tool inputs were read-only, networking was disabled, output was private and size-limited, and CPU time, memory, files, and threads were controller-enforced. Numeric memory and file-size caps were not exposed by the compressed reporting bundle and are therefore recorded as unavailable rather than inferred.

No custom run documents a nondefault random seed in the compressed ledger. Where an implementation was deterministic, no seed was needed; otherwise an unrecorded seed cannot be reconstructed reliably.

### Failure diagnosis and pivots

- The initial constructive methods reached the already known cardinality represented by objective -72, demonstrating that the incumbent was structurally reproducible but not improving it.
- Exhausted initial neighborhoods motivated larger or revised searches rather than idle runtime.
- The proof-oriented pivot recognized that incumbent reproduction alone could not reduce the gap; it targeted a valid dual bound or threshold proof.
- The proof/bound attempt did not generate a solver-independent certificate or stronger bound.
- The final unsupported status records a genuine encoding/tool limitation, not infeasibility of the mathematical instance.

The most informative negative result is that several structurally different approaches failed to surpass -72 or raise the lower bound above -13841 in the allotted runs, while direct solvers made essentially no global-bound progress beyond their short baselines.

## Compute accounting and algorithm-first gates

Custom-algorithm runtime totals **326.738679 seconds**. Direct Gurobi/COPT runtime totals **240.749638 seconds**. Across the **567.488317 seconds** represented by these seven runs:

- custom algorithms used **57.58%** of experimental compute; and
- direct solvers used **42.42%**.

There were **five distinct custom runs**, of which **three** have ledger status `success`; one was `completed` without a bound and one was `unsupported`. The longest successful custom run lasted **108.989013 seconds**, and the longest custom run overall was the same run. This is the scaled custom run represented in the ledger.

The algorithm-first execution requirement was met in substance: multiple distinct structure-specific methods were run, more custom CPU time than direct-solver CPU time was used, a scaled successful custom run was completed, and at least one successful method targeted proof or a valid dual bound. No gate should be interpreted as a claim that the proof attempt succeeded in proving the instance.

## Reproducibility record

- Objective sense: minimization.
- Baseline time limits: approximately 120 seconds per direct solver.
- Direct solvers: Gurobi and COPT; exact version strings were not available in the compressed report.
- Custom runtime: CPython using only the standard library unless a per-run ledger says otherwise.
- Trusted capabilities configured for the experiment: CaDiCaL and DRAT-trim. Their availability does not imply that a valid checked certificate was produced.
- Machine: controller-managed CPU execution; exact CPU, operating-system build, and RAM metadata were not included in the compressed report.
- Sandbox: CPU-only bubblewrap, no network, read-only model/tool inputs, private writable output, controller-enforced time/memory/file/thread limits.
- Random seeds: no explicit nondefault seed appears in the compressed summaries.
- Controller-generated authoritative files: `result.json`, `experiments.json`, and `experiments.md`.
- Research narrative: `background.md`, `strategy.md`, `method_selection.md`, this report, and `README.md`.

The controller-generated machine-readable ledgers remain authoritative if a rounded value in this narrative differs.

## Recommended next experiment

Because primal -72 was easy to reproduce while the lower bound remained extremely weak, the next experiment should prioritize **bound strengthening rather than another generic incumbent search**. A recommended route is to derive symmetry-reduced counting/cover inequalities from projective-geometry point and subspace orbits, validate each lifted inequality independently, and then evaluate their effect on the root relaxation. In parallel, formulate the decision question for cardinality 73 as a compact pseudo-Boolean model only if the 17 equalities can be preserved exactly; require a CaDiCaL proof trace and successful DRAT-trim checking before making any infeasibility or optimality claim. If certificate generation is too large, use orbit-representative exchange neighborhoods of substantially larger radius with exact row-load repair as the next primal heuristic.

## Claim boundary

This archive supports only the following claim: **a feasible solution of objective -72 was independently verified at tolerance `1e-9`**. It does not support a claim of optimality, infeasibility, a certified dual bound, a public record, or a reduced public gap.
