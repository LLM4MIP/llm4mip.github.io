# a2864-99blp experiment archive

2026-09-14 independent dual-bound review: [adopted bound, proof chain, checks, and limitations](../../docs/dual-bound-audit-2026-09-14/cases/a2864-99blp.zh.md). Reviewed lower bound: **-257**. This review distinguishes exact, literature, and numerical evidence; historical statements below remain dated records.

## Exact geometry crosswalk and theorem-transfer result (2026-09-05)

**Global conclusion: the optimum is -257.**

The official objective **-257** solution is exactly feasible. A new
dependency-free streaming verifier reconstructs every MPS row and column as
the incidence structure of four-dimensional subspaces of `GF(2)^8`, checking
all 20,078,717 matrix entries.

Accepting the published computational theorem `A_2(8,6;4)=257`, this exact
crosswalk proves the MPS optimum is -257. The theorem's classification and
LP/MILP computation were not replayed locally, so this is a
**literature-dependent theorem transfer**, not a self-contained local
lower-bound certificate.

- Compressed MPS SHA-256: `FC6534E01C67DCAB16D9FD83EAA93C8431AD9783F9039280D2F1A9FB07EE4E4A`
- Official compressed solution SHA-256: `E55FED5C29C2C87229C180AAED36912557D3477A995395D5837F4257F818C58F`
- Exact verifier: [`scripts/verify_geometry.py`](scripts/verify_geometry.py)
- Detailed report: [`reports/geometry-theorem-transfer.md`](reports/geometry-theorem-transfer.md)
- Machine-readable audit: [`artifacts/exact-geometry-audit.json`](artifacts/exact-geometry-audit.json)

The controlled framework run documented below predates this crosswalk and is
retained unchanged as experiment history.

> **Post-run audit correction (2026-09-04):** the official public solution with
> objective **-257** was downloaded and independently checked against all
> 22,117 original rows, bounds, and integrality conditions with zero violations.
> Therefore the run-produced value -72 is not the best known or best verified
> primal bound. The controller report below is retained as an immutable account
> of what that run itself found; its statement that the public target was -72 is
> incorrect. No optimality proof was obtained.

## Archived framework result at a glance

This controlled experiment ended with a **partial feasible result**:

- objective sense: minimization;
- best verified primal bound: **-72**;
- best solver-reported dual bound: **-13841**;
- controller common relative gap: **191.2361111111** (19,123.6111%);
- feasibility check: exact-decimal model evaluation at tolerance `1e-9`;
- optimality proved: **no**;
- infeasibility proved: **no**.

The sourced public primal target was -72, so the experiment matched but did not improve it. It did not improve a sourced public dual bound, did not improve either short internal baseline bound, and did not reduce the internal gap. The -13841 value is a solver search bound, not an independently certified dual result.

## Instance

`a2864-99blp` is a 200,787-variable pure binary set-packing model with 22,117 rows, including 22,100 inequalities and 17 equalities. All objective coefficients are -1 and all matrix coefficients are unit coefficients. It represents a finite-projective-geometry subspace-selection problem related to partial plane spreads in `PG(7,2)`.

## Experiment design

Short generic Gurobi and COPT runs established an internal baseline of primal -72 and dual -13841. Five custom Python runs then tested structure-specific constructive packing, revised or enlarged neighborhoods, and proof/dual-oriented ideas. Two custom methods reproduced and verified the -72 incumbent; no custom method improved either bound. A proof-oriented run did not yield an independently checkable certificate, and an unsupported route was recorded honestly rather than interpreted as a mathematical result.

Direct solver time was **240.749638 s** (42.42% of recorded experimental compute). Custom algorithm time was **326.738679 s** (57.58%). There were five distinct custom runs, three with ledger status `success`; the longest successful/scaled custom run lasted **108.989013 s**. The algorithm-first gates were met: multiple distinct methods, a scaled successful run, majority custom compute, and a successful run targeting proof or a valid dual bound. Meeting those execution gates does not mean the proof goal was achieved.

Both direct solvers terminated by time limit. A time limit is neither optimality nor infeasibility. Solver acceptance and the controller's tolerance verification are reported separately.

## Reproducibility

The controller managed time limits, threads, logs, and solution verification. Custom code ran CPU-only in a network-disabled bubblewrap sandbox with read-only model/tool inputs and controller-enforced time, memory, file-size, and thread limits. No explicit nondefault random seed, exact host specification, or solver version string appears in the compressed archival summaries; these details are not invented. Configured trusted capabilities included CaDiCaL and DRAT-trim, but no checked certificate resulted.

See:

- `final_report.md` for the narrative report, comparisons, compute accounting, failure analysis, and recommendation;
- `background.md` for primary-source and structural research;
- `strategy.md` and `method_selection.md` for algorithm design and pivots;
- `experiments.md` for the controller-generated run table;
- `experiments.json` for the machine-readable experiment ledger; and
- `result.json` for the authoritative final result.

Controller-managed JSON and ledger files must not be edited manually.

## Recommended continuation

The next study should emphasize globally valid bound strengthening: symmetry-reduced projective-geometry counting/cover inequalities, independently validated before use. A complementary cardinality-73 pseudo-Boolean encoding is worthwhile only if it preserves all equalities exactly and produces a proof trace that is independently accepted by DRAT-trim. For primal work, use larger orbit-aware exchange neighborhoods with exact row-load/equality repair rather than repeating another short generic MIP run.
