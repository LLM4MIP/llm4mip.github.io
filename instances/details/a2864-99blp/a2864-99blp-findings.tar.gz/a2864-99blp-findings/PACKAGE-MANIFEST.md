# Package manifest: a2864-99blp

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 84
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/exact-geometry-audit.json`
- `artifacts/line-coordinates.tsv`
- `artifacts/point-coordinates.tsv`
- `background.md`
- `experiments.json`
- `experiments.md`
- `final_report.md`
- `logs/exact-geometry-audit.log`
- `method_selection.md`
- `methods/lagrangian_box_scaled.py`
- `methods/lagrangian_dual.py`
- `methods/lagrangian_rows.py`
- `methods/lagrangian_separable.py`
- `methods/lowrow_exchange.py`
- `methods/packing_exchange.py`
- `methods/packing_sat_proof.py`
- `methods/row_lagrangian.py`
- `methods/slack_exchange.py`
- `reporting_bundle.json`
- `reports/geometry-theorem-transfer.md`
- `result.json`
- `runs/copt-20260904-224439-f6080e4d/best.sol`
- `runs/copt-20260904-224439-f6080e4d/driver.stderr`
- `runs/copt-20260904-224439-f6080e4d/driver.stdout`
- `runs/copt-20260904-224439-f6080e4d/result.json`
- `runs/copt-20260904-224439-f6080e4d/solver.log`
- `runs/custom-20260904-225213-2180ebd7/algorithm.stderr`
- `runs/custom-20260904-225213-2180ebd7/algorithm.stdout`
- `runs/custom-20260904-225213-2180ebd7/best.sol`
- `runs/custom-20260904-225213-2180ebd7/driver.stderr`
- `runs/custom-20260904-225213-2180ebd7/driver.stdout`
- `runs/custom-20260904-225213-2180ebd7/method_result.json`
- `runs/custom-20260904-225213-2180ebd7/result.json`
- `runs/custom-20260904-225229-7ab3efb8/algorithm.stderr`
- `runs/custom-20260904-225229-7ab3efb8/algorithm.stdout`
- `runs/custom-20260904-225229-7ab3efb8/best.sol`
- `runs/custom-20260904-225229-7ab3efb8/driver.stderr`
- `runs/custom-20260904-225229-7ab3efb8/driver.stdout`
- `runs/custom-20260904-225229-7ab3efb8/dry_report.json`
- `runs/custom-20260904-225229-7ab3efb8/method_result.json`
- `runs/custom-20260904-225229-7ab3efb8/result.json`
- `runs/custom-20260904-230317-b2511486/algorithm.stderr`
- `runs/custom-20260904-230317-b2511486/algorithm.stdout`
- `runs/custom-20260904-230317-b2511486/driver.stderr`
- `runs/custom-20260904-230317-b2511486/driver.stdout`
- `runs/custom-20260904-230317-b2511486/lagrangian_certificate.json`
- `runs/custom-20260904-230317-b2511486/method_result.json`
- `runs/custom-20260904-230317-b2511486/result.json`
- `runs/custom-20260904-231314-3ef592ad/algorithm.stderr`
- `runs/custom-20260904-231314-3ef592ad/algorithm.stdout`
- `runs/custom-20260904-231314-3ef592ad/driver.stderr`
- `runs/custom-20260904-231314-3ef592ad/driver.stdout`
- `runs/custom-20260904-231314-3ef592ad/lagrangian_certificate.json`
- `runs/custom-20260904-231314-3ef592ad/method_result.json`
- `runs/custom-20260904-231314-3ef592ad/result.json`
- `runs/custom-20260904-231859-255c62e3/algorithm.stderr`
- `runs/custom-20260904-231859-255c62e3/algorithm.stdout`
- `runs/custom-20260904-231859-255c62e3/driver.stderr`
- `runs/custom-20260904-231859-255c62e3/driver.stdout`
- `runs/custom-20260904-231859-255c62e3/encoding_stats.txt`
- `runs/custom-20260904-231859-255c62e3/method_result.json`
- `runs/custom-20260904-231859-255c62e3/result.json`
- `runs/gurobi-20260904-224426-87e3f98f/best.sol`
- `runs/gurobi-20260904-224426-87e3f98f/driver.stderr`
- `runs/gurobi-20260904-224426-87e3f98f/driver.stdout`
- `runs/gurobi-20260904-224426-87e3f98f/result.json`
- `runs/gurobi-20260904-224426-87e3f98f/solver.log`
- `scripts/verify_geometry.py`
- `solutions/official-257.sol.gz`
- `solutions/public/a2864-99blp.sol`
- `solutions/public/a2864-99blp.sol.gz`
- `strategy.md`
- `structure-gurobi.log`
- `structure.json`
- `verification/copt-20260904-224439-f6080e4d.exact-check.json`
- `verification/copt-20260904-224439-f6080e4d.exact-check.txt`
- `verification/custom-20260904-225213-2180ebd7.exact-check.json`
- `verification/custom-20260904-225213-2180ebd7.exact-check.txt`
- `verification/custom-20260904-225229-7ab3efb8.exact-check.json`
- `verification/custom-20260904-225229-7ab3efb8.exact-check.txt`
- `verification/gurobi-20260904-224426-87e3f98f.exact-check.json`
- `verification/gurobi-20260904-224426-87e3f98f.exact-check.txt`
- `verification/public-solution.exact-check.txt`

## Excluded files

- `input/a2864-99blp.mps.gz (71164144 bytes; raw benchmark input; sha256 fc6534e01c67dcab16d9fd83eaa93c8431ad9783f9039280d2f1a9fb07ee4e4a)`
