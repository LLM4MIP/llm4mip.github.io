#  Neos-5266653-tugela: vehicle blocks re-optimized with strict new primal bound

##  Current Conclusions

As of 2026 -09 -08, [MIPLIB instance page ](https://miplib.zib.de/instance_details_neos-5266653-tugela.html)
This instance is still labeled `open` and the page headline is tolerance solution with a star rating.
`65505.2005752763*`。

This directory receives a new solution to the original MPS **zero tolerance strict feasible**:

```text
65257.573990387 = 65257573990387 / 1000000000
```

It lowered the `247.6265848893` than the page headline.
[`solutions/tugela-65257.573990387-strict.sol`](solutions/tugela-65257.573990387-strict.sol)。
Exact differential constraint Repair report and second set Fraction Weight parse respectively
[`analysis/triple-3-11-12-exact-repair.json`](analysis/triple-3-11-12-exact-repair.json)
and
[`analysis/triple-3-11-12-independent-validation.json`](analysis/triple-3-11-12-independent-validation.json)：
The boundary of the 23,310 variable, 22,662 integer variable and 23,458 clause constraint are zero default, with the maximum exact row violation being zero.
Re-verification of the repository repository by the public checker
[`solutions/tugela-65257.573990387-strict.validation.log`](solutions/tugela-65257.573990387-strict.validation.log)。

This is only a strictly feasible upper bound, not an optimality proof. The final full-model COPT run, within a 600-second limit,
No further improvement, floating-point `best_bound=33589.17979976425`; the numerical bound is untransferable
The exact proof verification cannot be used to mark the instance as `optimal`.

##  Background and structure

MIPLIB's description of only the seam to be VRP file, and noting the page solution from Gurobi 9.0; official did not give
bibliography. Therefore, it does not assume an unknown business context, but is based on the coefficient-level structure of the original MPS.

The original model was first **read only** on `euler4` using Gurobi 13.0.1, without calling
`presolve()` or `optimize()`.
[`analysis/gurobi-13.0.1-structure.json`](analysis/gurobi-13.0.1-structure.json)
It is also known as `logs/gurobi-13.0.1-structure.log` ](logs/gurobi-13.0.1-structure.log).

|  Property |  Numerical |
|---|---:|
|  Variables |  23,310  |
|  constraint |  23,458  |
|  nonzero entries |  171,534  |
| The binary/ integer variable |  22,662  |
|  continuous variables |  648  |
| Objective non-zero |  22,644  |
|  objective sense | Minimized |

DEC and column-by-column coefficient analysis recovered an identical vehicle block 18; each block actually has a variable 1,295, containing
1,259 is a binary variable and 36 is a continuous dynamic variable.
The following sequence constraint pattern, consistent with the VRP explanation. The strict seed contains only the vehicle blocks 3, 10, 11, 12.
Non-empty, its cost contribution and activation
[`analysis/vehicle-block-profile.json`](analysis/vehicle-block-profile.json)。

The original input is [`input/neos-5266653-tugela.mps.gz` ](input/neos-5266653-tugela.mps.gz) ,
SHA-256 is the
`f363a7804415c5bc60952b4a2c8ee73e47d41d21ab9122e6e4595cb521ef9ec7`；
The official revision of DEC and MIPLIB 3 is also preserved in [`input/` ](input/)].

## official solution zero tolerance audit

The official revision of 3 is the literal objective of
`65505.200575276310617654960302300`, but it is not a zero tolerance feasible point:

|  Project |  result |
|---|---:|
|  exact row violation |  227  |
| Integrity breaches |  23  |
| Failure of the variable |  1  |
| The largest default |  `8.5960924212e-7`  |

See full audit
[`analysis/official-3-strict-validation.json`](analysis/official-3-strict-validation.json)
It is also known as `logs/official-3-common-checker.log` ](logs/official-3-common-checker.log).
This explanation is the star number of the headline; the new solution and the headline are still compared according to numerical objective, but the new solution is the same.
It's been through strict verification.

##  Solve the process

###  1 . official mode rounding with dynamic variable exact Repair

First, the full binary variable rounding of the official solution is fixed, and COPT renews the continuous part; then the 648 is fixed.
The continuous force variable is written as a differential logical system to construct a feasible force on a Bellman-Ford rational basis.
strict seeds
[`solutions/tugela-65505.241756227-strict.sol`](solutions/tugela-65505.241756227-strict.sol)，
objective `65505.241756227`. Its repair and independent replay
[`analysis/rounded-official-strict-repair.json`](analysis/rounded-official-strict-repair.json)
and
[`analysis/rounded-official-independent-validation.json`](analysis/rounded-official-independent-validation.json)。

From the seed to 1,200 second, 12 thread full model COPT warm start, no improvement; floating-point bound as
`33980.59039023698`, see
[`experiments/warm-from-65505/result.json`](experiments/warm-from-65505/result.json)。

###  2. Two vehicles and three vehicle blocks LNS

Six vehicles with four non-empty blocks each release the corresponding binary variable, while maintaining all continuous momentum variables free;
Status 1 only represents the corresponding **restricted COPT subproblem** numerical closure.

| Release the blocks | The final deadline | The state of COPT |  incumbent  |  bound  |  Conclusion |
|---|---:|---:|---:|---:|---|
|  3,10  |  120s  |  1  |  `65505.241756227`  | and incumbent | No improvement, restricted sub-problem closure |
|  3,11  |  120s  |  1  |  `65505.241756227`  | and incumbent | No improvement, restricted sub-problem closure |
|  3,12  |  300s retry  |  1  |  `65505.241756227`  | and incumbent | No improvement, restricted sub-problem closure |
|  10,12  |  120s  |  1  |  `65505.241756227`  | and incumbent | No improvement, restricted sub-problem closure |
|  10,11  |  300s retry  |  8  |  `65505.241756227`  |  `63986.42577094592`  | timeout , no improvement |
|  11,12  |  300s retry  |  8  |  `65505.241756227`  |  `54811.28698719349`  | timeout , no improvement |

All results and logs are in [`experiments/block-lns/` ](experiments/block-lns/)]
and [`logs/block-lns/`](logs/block-lns/).

3, 11, 12. 600 seconds, 8 thread run to find the floating-point candidate.
`65257.573990387`, but with status 8 timeout, local floating-point bound as
`59149.21891422553`. All binary models of the candidate are differentiated by exact reconstruction and the second set of Fraction.
After full line replay, the current strict solution is formed. The three runs themselves have no closure, so the neighborhood cannot be called optimal.

###  3. The new strict dot model is confirmed

From `65257.573990387` strict point to 600 second, 8 thread full model COPT; explore the nodes of 2,189,
There is no new incumbent, status 8, floating-point bound `33589.17979976425`.
[`experiments/warm-from-65257/result.json`](experiments/warm-from-65257/result.json)
It is also known as `logs/warm-from-65257/` ](logs/warm-from-65257/).

## Evidence Boundary

-  `65257.573990387` is the strict feasible primal bound on the original decimal MPS.
-  The full COPT model `best_bound` is a floating-point numerical, not a strict lower bound certificate provided in this directory.
-  The bound of the pair/triple belongs only to the restricted neighborhood after the fixed rest of the vehicle block; it cannot be pushed to the global lower bound.
-  Status 8 indicates a deadline, not optimal, infeasible or neighborhood closure.
-  The four pairs of status 1 are also solver-backed limited computational closures, with no portable proof files.
-  There is currently no global optimality proof, and the instance should remain `open`.

## Reproduction

From the warehouse repository root directory, perform a zero tolerance check:

```bash
python common/exact_mps_solution_check.py \
  instances/neos-5266653-tugela/input/neos-5266653-tugela.mps.gz \
  instances/neos-5266653-tugela/solutions/tugela-65257.573990387-strict.sol \
  --tolerance 0

python common/exact_mps_solution_check.py \
  instances/neos-5266653-tugela/input/neos-5266653-tugela.mps.gz \
  instances/neos-5266653-tugela/input/neos-5266653-tugela-official-3.sol.gz \
  --tolerance 0
```

Three vehicles are required for limited searches: COPT 8:

```bash
python instances/neos-5266653-tugela/experiments/copt_interleaved_block_lns.py \
  --model instances/neos-5266653-tugela/input/neos-5266653-tugela.mps.gz \
  --solution instances/neos-5266653-tugela/solutions/tugela-65505.241756227-strict.sol \
  --blocks 3,11,12 --output-dir /tmp/tugela-triple-3-11-12 \
  --time-limit 600 --threads 8
```

Check the hash file:

```bash
(cd instances/neos-5266653-tugela && sha256sum -c SHA256SUMS)
```

`SHA256SUMS` covers all archival files except for the list itself.
