# Package manifest: neos-5266653-tugela

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 64
Excluded source files: 1

## Included files

- `README.md`
- `SHA256SUMS`
- `analysis/gurobi-13.0.1-structure.json`
- `analysis/official-3-rounded-pattern.json`
- `analysis/official-3-strict-validation.json`
- `analysis/rounded-official-independent-validation.json`
- `analysis/rounded-official-strict-repair.json`
- `analysis/triple-3-11-12-exact-repair.json`
- `analysis/triple-3-11-12-independent-validation.json`
- `analysis/vehicle-block-profile.json`
- `experiments/block-lns/pair-10-11-retry300/result.json`
- `experiments/block-lns/pair-10-11/result.json`
- `experiments/block-lns/pair-10-12/result.json`
- `experiments/block-lns/pair-11-12-retry300/result.json`
- `experiments/block-lns/pair-11-12/result.json`
- `experiments/block-lns/pair-3-10/result.json`
- `experiments/block-lns/pair-3-11/result.json`
- `experiments/block-lns/pair-3-12-retry300/result.json`
- `experiments/block-lns/pair-3-12/result.json`
- `experiments/block-lns/triple-3-11-12/result.json`
- `experiments/copt_fix_integer_reopt.py`
- `experiments/copt_interleaved_block_lns.py`
- `experiments/copt_warmstart.py`
- `experiments/exact_difference_repair.py`
- `experiments/fixed-official/result.json`
- `experiments/generic_fraction_validator.py`
- `experiments/helper_route_logic.py`
- `experiments/tugela_block_profile.py`
- `experiments/warm-from-65257/result.json`
- `experiments/warm-from-65505/result.json`
- `input/neos-5266653-tugela-official-3.sol.gz`
- `input/neos-5266653-tugela.dec`
- `logs/block-lns/pair-10-11-retry300/console.log`
- `logs/block-lns/pair-10-11-retry300/solver.log`
- `logs/block-lns/pair-10-11/console.log`
- `logs/block-lns/pair-10-11/solver.log`
- `logs/block-lns/pair-10-12/console.log`
- `logs/block-lns/pair-10-12/solver.log`
- `logs/block-lns/pair-11-12-retry300/console.log`
- `logs/block-lns/pair-11-12-retry300/solver.log`
- `logs/block-lns/pair-11-12/console.log`
- `logs/block-lns/pair-11-12/solver.log`
- `logs/block-lns/pair-3-10/console.log`
- `logs/block-lns/pair-3-10/solver.log`
- `logs/block-lns/pair-3-11/console.log`
- `logs/block-lns/pair-3-11/solver.log`
- `logs/block-lns/pair-3-12-retry300/console.log`
- `logs/block-lns/pair-3-12-retry300/solver.log`
- `logs/block-lns/pair-3-12/console.log`
- `logs/block-lns/pair-3-12/solver.log`
- `logs/block-lns/triple-3-11-12/console.log`
- `logs/block-lns/triple-3-11-12/solver.log`
- `logs/fixed-official/solver.log`
- `logs/gurobi-13.0.1-structure.log`
- `logs/official-3-common-checker.log`
- `logs/official-3-strict-validation.log`
- `logs/triple-3-11-12-independent-validation.log`
- `logs/warm-from-65257/console.log`
- `logs/warm-from-65257/solver.log`
- `logs/warm-from-65505/console.log`
- `logs/warm-from-65505/solver.log`
- `solutions/tugela-65257.573990387-strict.sol`
- `solutions/tugela-65257.573990387-strict.validation.log`
- `solutions/tugela-65505.241756227-strict.sol`

## Excluded files

- `input/neos-5266653-tugela.mps.gz (971704 bytes; raw benchmark input; sha256 f363a7804415c5bc60952b4a2c8ee73e47d41d21ab9122e6e4595cb521ef9ec7)`
