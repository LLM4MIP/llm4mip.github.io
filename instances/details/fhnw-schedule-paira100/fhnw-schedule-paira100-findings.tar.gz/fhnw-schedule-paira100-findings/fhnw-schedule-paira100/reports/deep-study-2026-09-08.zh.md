#  fhnw-schedule- paira100 Structure enhancement and optimality audit (2026 -09 -08)

## Conclusion

In the strict integer sense, this instance has been amplified by the original Pair A model proof to globally optimal:

```text
strict Optimal objective value -15.1131165125934
primal bound     -15.1131165125934
dual bound       -15.1131165125934
relative gap       0
```

This is **solver-verified global optimum**: retain the full variable, constraint and objective of the original MPS, and only add a linear audit for the global effective conflict inequality and intercalation energy inequality.

The MIPLIB page shows the name objective `-15.1131226682367` is slightly lower, but the corresponding public solution is not a strict integer solution. Public solution has a binary variable 3 deviated from the nearest integer, where the two objective coefficients with the choice of the variable `C4`, `C10` are approximately `5.406e-6`, which coincides with the name objective difference of about `6.15564e-6`.

##  Original model structure

-  5,150 variable: 5,050 is a binary variable, 100 is a continuous variable.
-  10,000 article constraint, 29,873 nonzero entries.
-  The previous 100 binary variable is the project selection variable, the 100 continuous variable is the start time, and the remainder of the 4,950 binary variable corresponds to the previous sequence of all orderless operation pairs.
-  The 27 single variable equation forces the 27 items not to be selected; the rest of the 73 items each have an activity time window constraint.
-  Each operation has two or three non-overlapping constraints with a total of `2*C(100,2)=9,900` rows; all row by row recovery is successful, with the maximum error on the right end being 0.

The semantics of the time window are particularly important: the activity constraint gives the latest **start** time `u_i`, the completion date for unequal use of energy must be

```text
d_i = u_i + p_i,
```

`u_i` cannot be directly used when the deadline is reached. This round all cuts and audits use the modified `d_i`.

##  Effective inequalities

###  Conflicts of certainty

If according to release time, processing time and completion deadline, `i` is not possible before `j` and `j` before `i`, then join.

```text
z_i + z_j <= 1.
```

This instance combines the 196 clause with the independent script-by-step recalculation, and is invalid.

###  Distance energy constraint

For the `[a,b]` interval, the project `i` must be arranged in any way that the minimum amount of processing within the interval is:

```text
e_i(a,b) = max(0, p_i - max(0,a-r_i) - max(0,d_i-b)).
```

Therefore, any non-overlapping sequence is satisfied.

```text
sum_i e_i(a,b) z_i <= b-a.
```

From the release/deadline endpoint of the activity project, the 4,973 candidate zone is obtained; the LP divides the two rounds into 1,500 and 792 sections, respectively, and 2,292 sections. To avoid floating-point mistreatment, each right end is loosened to `1e-11`.

The final proof model has the 12,488 bar constraint, i.e. the original 10,000 bar plus the 196 bar conflict constraint and the 2,292 bar energy constraint.

##  solve and verification

First solve using the 2 thread, strict feasibility and integer tolerance `1e-9`:

```text
status       OPTIMAL
runtime      0.835 s
nodes        1
objective    -15.113116512593402
bound        -15.113116512593404
gap          0
```

After saving proof MPS, run back independently with 1 threads, different seeds, different cuts parameters and `NumericFocus=3`:

```text
status       OPTIMAL
runtime      3.141 s
nodes        8
objective    -15.113116512593402
bound        -15.113116512593402
gap          0
```

The final solution is to select a 23 project.

-  Maximum variable bound violation: 0;
-  The maximum integrity violation: 0;
-  The maximum original constraint violated: `6.66e-15`;
-  The original constraint of `1e-9` was violated: 0.

The independent semantic audit also confirmed:

-  The 10,000 constraint of the original MPS is not missing or modified in the proof model;
-  9,900 article pairwise aligned with recovery processing time complete;
-  196 Article conflict inequalities are valid for all;
-  2,292 energy inequalities can all be matched using `d_i=u_i+p_i`'s legitimate range constraint generated;
-  There are no unknown additional constraints.

##  Key documents

- official original instance : [ `../input/fhnw-schedule-paira100.mps.gz` ](../input/fhnw-schedule-paira100.mps.gz)
- official public solution : [ `../input/fhnw-schedule-paira100-public.sol.gz` ](../input/fhnw-schedule-paira100-public.sol.gz)
- optimal solution : [ `../solutions/global-optimal.sol` ](../solutions/global-optimal.sol)
- proof MPS：[`../artifacts/energy-proof-proof.mps.gz`](../artifacts/energy-proof-proof.mps.gz)
-  The first closing result: [ `../artifacts/energy-proof.json` ](../artifacts/energy-proof.json)
-  Independent semantic audit and weighted results:[ `../artifacts/proof-semantic-audit.json` ](../artifacts/proof-semantic-audit.json)
-  Production and audit procedures:[ `../scripts/` ](../scripts/)

## Evidence Boundary

**provides reproducible globally optimal proof of the strict integer model through structural restoration and global efficient energy cuts.**

It should not be expressed as a closed objective over the MIPLIB page numerical slope, because the numerical page comes from the near integer solution within tolerance; the correct statement is: public solution strictly after this round optimal solution has the same set of selections and the same strict objective, this round adds strict feasibility and globally optimal proof.
