# Alternative common-deadline sandwich proof

Date: 2026-09-08

## Conclusion

This imported experiment independently supports the already established
solver-verified optimum

```text
-15.11311651259340199200.
```

It does not change the instance classification or objective. Its contribution
is an alternative, much smaller formulation and a complete witness whose
literal-decimal replay has exactly zero violation.

## Exact structural sandwich

The original Pair-A model has 100 selection binaries, 100 start-time
variables, 4,950 pair-order binaries and 10,000 rows. Twenty-seven jobs are
explicitly fixed out, leaving 73 eligible jobs. For a selected set, earliest
release-date order turns common-deadline feasibility into nested suffix
packing inequalities.

Repeated processing-time coefficients in the literal MPS differ by at most
`7.18e-15`, and the implied deadlines differ slightly around one. The reduction
therefore avoids silently rounding them:

- the inner model uses each job's largest repeated processing time and
  deadline `0.999999999999995`;
- the outer model uses each job's smallest repeated processing time and
  deadline `1.000000000000005`.

The coefficient audit establishes

```text
F_inner subset F_original subset F_outer.
```

Both compact models have 73 binary variables and 100 nested rows. Their strict
one-thread Gurobi 13.0.2 runs each explored six nodes and returned the same
23-job set at zero gap:

| model | runtime | objective | bound | status |
|---|---:|---:|---:|---|
| inner | 0.02 s | -15.1131165125934 | -15.1131165125934 | optimal, zero gap |
| outer | 0.01 s | -15.1131165125934 | -15.1131165125934 | optimal, zero gap |

The selected objective recomputed from original decimal coefficients is
`-15.11311651259340199200`. Since the inner feasible set is contained in the
original set and every original selection projects into the outer set, equal
inner and outer optima pin the original integer optimum.

## Full-space witness audit

The 23 selected jobs are lifted to all 5,150 original variables, including a
complete schedule and every pair-order variable. The solver-independent
50-digit `Decimal` audit of
[`global-optimal-exact-decimal.sol`](../solutions/global-optimal-exact-decimal.sol)
against the original MPS reports:

```text
listed values                 5150
computed objective            -15.11311651259340199200
violated original rows        0 / 10000
violated bounds               0
nonintegral variables         0
maximum row violation         0
maximum bound violation       0
maximum integrality violation 0
```

The exact-decimal witness SHA-256 is
`a21fbb7bf97351de0835652b16d775da332492d2366f15da8dfd4c798ffc32e4`.

## Evidence boundary and reproduction

The set inclusions and full-space primal audit use literal decimal arithmetic.
Global optimality of each compact endpoint is supplied by a commercial
solver's zero-gap run; no portable branch-and-bound or SAT proof trace is
included. The alternative evidence therefore remains a solver-verified proof,
not an independently replayable formal optimality certificate.

The curated files are:

- [`exact-bracketing-mapping.json`](../artifacts/common-deadline/exact-bracketing-mapping.json),
  the structural coefficient map;
- [`inner-strict.sol`](../artifacts/common-deadline/inner-strict.sol) and
  [`outer-strict.sol`](../artifacts/common-deadline/outer-strict.sol), the two
  compact optima;
- [`inner-strict.log`](../logs/common-deadline/inner-strict.log) and
  [`outer-strict.log`](../logs/common-deadline/outer-strict.log), the sanitized
  zero-gap logs;
- [`experiments/common-deadline/`](../experiments/common-deadline/), the model
  reduction, lift and independent audit programs.

The original MPS is available from the
[official MIPLIB download](https://miplib.zib.de/WebData/instances/fhnw-schedule-paira100.mps.gz).
Its expected SHA-256 and the witness hashes are recorded in
[`input/SHA256SUMS`](../input/SHA256SUMS).
