# Sources

- MIPLIB instance page: https://miplib.zib.de/instance_details_fhnw-schedule-paira100.html (accessed 2026-09-08). It labels the instance open, describes continuous-time project scheduling and selection, states that Pair A/Pair B/Slot are three formulations of the same problem, and reports the nominal incumbent `-15.1131226682367` with integer violation `8.1e-6`.
- Official MPS: https://miplib.zib.de/WebData/instances/fhnw-schedule-paira100.mps.gz
- Official incumbent ID 3: https://miplib.zib.de/downloads/solutions/fhnw-schedule-paira100/3/fhnw-schedule-paira100.sol.gz

The optimization conclusions in `REPORT.md` are based on the preserved official files and local Gurobi/semantic audits, not on the webpage summary alone.
