#!/usr/bin/env python3
"""Evaluate a sparse solution against the literal decimal MPS data."""

from __future__ import annotations

from decimal import Decimal, getcontext
import sys

from reduce_common_deadline import ZERO, open_text, read_mps


getcontext().prec = 50


def read_solution(path: str):
    values = {}
    claimed = None
    with open_text(path) as stream:
        for raw in stream:
            fields = raw.split()
            if len(fields) != 2:
                continue
            if fields[0] == "=obj=":
                claimed = Decimal(fields[1])
            elif not fields[0].startswith("#"):
                try:
                    values[fields[0]] = Decimal(fields[1])
                except Exception:
                    pass
    return values, claimed


def main(mps_path: str, solution_path: str) -> None:
    senses, rhs, cols, _, obj, bounds, integer = read_mps(mps_path)
    values, claimed = read_solution(solution_path)
    activity = {row: ZERO for row, sense in senses.items() if sense != "N"}
    for var, incidences in cols.items():
        value = values.get(var, ZERO)
        for row, coefficient in incidences.items():
            activity[row] += coefficient * value
    row_violations = []
    for row, sense in senses.items():
        if sense == "N":
            continue
        residual = activity[row] - rhs[row]
        violation = max(ZERO, residual) if sense == "L" else max(ZERO, -residual) if sense == "G" else abs(residual)
        if violation:
            row_violations.append((violation, row, residual))
    bound_violations = []
    for var in cols:
        value = values.get(var, ZERO)
        lower, upper = bounds[var]
        if lower is not None and value < lower:
            bound_violations.append((lower-value, var, value))
        if upper is not None and value > upper:
            bound_violations.append((value-upper, var, value))
    integrality = []
    for var in integer:
        value = values.get(var, ZERO)
        distance = abs(value - value.to_integral_value())
        if distance:
            integrality.append((distance, var, value))
    objective = sum(coefficient * values.get(var, ZERO) for var, coefficient in obj.items())
    row_violations.sort(reverse=True)
    bound_violations.sort(reverse=True)
    integrality.sort(reverse=True)
    print(f"solution={solution_path}")
    print(f"listed_values={len(values)}")
    print(f"claimed_objective={claimed}")
    print(f"computed_objective={objective}")
    print(f"max_row_violation={row_violations[0] if row_violations else (ZERO, None, ZERO)}")
    print(f"max_bound_violation={bound_violations[0] if bound_violations else (ZERO, None, ZERO)}")
    print(f"max_integrality_violation={integrality[0] if integrality else (ZERO, None, ZERO)}")
    print(f"violated_rows={len(row_violations)} violated_bounds={len(bound_violations)} nonintegral_vars={len(integrality)}")
    print("top_rows", row_violations[:10])
    print("top_integrality", integrality[:10])


if __name__ == "__main__":
    main(*sys.argv[1:])
