#!/usr/bin/env python3
"""Verify and project paira100 to its exact common-deadline packing model.

The source model schedules every job on one machine.  Binary x[j] receives a
reward when job j completes by the common deadline 1.  Pair binaries encode a
total non-overlap disjunction.  A chosen subset is schedulable by the common
deadline iff it satisfies the nested release-date suffix inequalities written
by this script.
"""

from __future__ import annotations

import collections
from decimal import Decimal, getcontext
import gzip
import json
import sys


getcontext().prec = 50
ZERO = Decimal(0)
ONE = Decimal(1)
M = Decimal(100)


def open_text(path: str):
    return gzip.open(path, "rt", encoding="iso-8859-1") if path.endswith(".gz") else open(path, encoding="iso-8859-1")


def read_mps(path: str):
    senses: dict[str, str] = {}
    rhs: dict[str, Decimal] = collections.defaultdict(lambda: ZERO)
    cols: dict[str, dict[str, Decimal]] = collections.defaultdict(dict)
    obj: dict[str, Decimal] = collections.defaultdict(lambda: ZERO)
    bounds: dict[str, list[Decimal | None]] = collections.defaultdict(lambda: [ZERO, None])
    integer: set[str] = set()
    section = ""
    objrow = ""
    integer_mode = False
    with open_text(path) as stream:
        for raw in stream:
            fields = raw.split()
            if not fields or fields[0] == "*":
                continue
            if fields[0] in {"ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"} and len(fields) == 1:
                section = fields[0]
                continue
            if section == "ROWS":
                senses[fields[1]] = fields[0]
                if fields[0] == "N":
                    objrow = fields[1]
            elif section == "COLUMNS":
                if len(fields) >= 3 and fields[1].strip("'") == "MARKER":
                    integer_mode = fields[2].strip("'") == "INTORG"
                    continue
                var = fields[0]
                if integer_mode:
                    integer.add(var)
                for pos in range(1, len(fields), 2):
                    row, value = fields[pos], Decimal(fields[pos + 1])
                    if row == objrow:
                        obj[var] += value
                    else:
                        cols[var][row] = cols[var].get(row, ZERO) + value
            elif section == "RHS":
                for pos in range(1, len(fields), 2):
                    rhs[fields[pos]] = Decimal(fields[pos + 1])
            elif section == "BOUNDS":
                kind, _, var = fields[:3]
                value = Decimal(fields[3]) if len(fields) > 3 else ZERO
                if kind in {"LO", "LI"}:
                    bounds[var][0] = value
                elif kind in {"UP", "UI"}:
                    bounds[var][1] = value
                elif kind == "FX":
                    bounds[var] = [value, value]
                elif kind == "BV":
                    bounds[var] = [ZERO, ONE]
                    integer.add(var)
                elif kind == "FR":
                    bounds[var] = [None, None]
                elif kind == "MI":
                    bounds[var][0] = None
                elif kind == "PL":
                    bounds[var][1] = None
                if kind in {"LI", "UI"}:
                    integer.add(var)
    row_cols: dict[str, dict[str, Decimal]] = collections.defaultdict(dict)
    for var, incidences in cols.items():
        for row, value in incidences.items():
            row_cols[row][var] = value
    return senses, rhs, cols, row_cols, obj, bounds, integer


def read_solution(path: str) -> dict[str, Decimal]:
    result = {}
    with open_text(path) as stream:
        for raw in stream:
            fields = raw.split()
            if len(fields) == 2 and not fields[0].startswith(("#", "=obj=")):
                try:
                    result[fields[0]] = Decimal(fields[1])
                except Exception:
                    pass
    return result


def dstr(value: Decimal) -> str:
    return format(value, "f")


def main(
    source_mps: str,
    incumbent_path: str,
    inner_mps: str,
    outer_mps: str,
    mapping_path: str,
    start_path: str,
) -> None:
    senses, rhs, cols, row_cols, obj, bounds, integer = read_mps(source_mps)
    variables = {f"C{i}" for i in range(5150)}
    assert set(cols) == variables
    assert len(senses) == 10001 and senses["OBJ"] == "N"

    n = 100
    xvars = [f"C{i}" for i in range(n)]
    svars = [f"C{100+i}" for i in range(n)]
    pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]
    yvars = [f"C{200+k}" for k in range(len(pairs))]
    assert len(pairs) == 4950

    for var in xvars + yvars:
        assert var in integer and bounds[var] == [ZERO, ONE]
    for var in svars:
        assert var not in integer and bounds[var][1] == M
    assert set(obj) == set(xvars)
    assert all(obj[var] < 0 for var in xvars)

    processing_candidates: list[list[Decimal]] = [[] for _ in range(n)]
    pair_rows = set()
    for k, (i, j) in enumerate(pairs):
        even, odd = f"R{2*k}", f"R{2*k+1}"
        y = yvars[k]
        pair_rows.update((even, odd))
        assert senses[even] == senses[odd] == "L"
        assert row_cols[even] == {svars[i]: ONE, svars[j]: -ONE, y: -M}
        assert row_cols[odd] == {svars[i]: -ONE, svars[j]: ONE, y: M}
        pi, pj = -rhs[even], M - rhs[odd]
        for index, value in ((i, pi), (j, pj)):
            processing_candidates[index].append(value)
    assert len(pair_rows) == 9900
    assert all(len(values) == n - 1 for values in processing_candidates)
    pmin = [min(values) for values in processing_candidates]
    pmax = [max(values) for values in processing_candidates]
    max_processing_spread = max(pmax[i] - pmin[i] for i in range(n))
    assert max_processing_spread < Decimal("1e-12")
    assert all(ZERO < pmin[i] <= pmax[i] < ONE for i in range(n))

    release = [bounds[var][0] if bounds[var][0] is not None else ZERO for var in svars]
    latest_start: list[Decimal | None] = [None] * n
    schedulable = []
    fixed_zero = []
    final_rows = set()
    for i in range(n):
        row = f"R{9900+i}"
        final_rows.add(row)
        if senses[row] == "L":
            assert row_cols[row] == {xvars[i]: M, svars[i]: ONE}
            latest_start[i] = rhs[row] - M
            assert release[i] <= latest_start[i]
            schedulable.append(i)
        else:
            assert senses[row] == "E"
            assert row_cols[row] == {xvars[i]: ONE}
            assert rhs[row] == ZERO
            fixed_zero.append(i)
    assert len(schedulable) == 73 and len(fixed_zero) == 27
    assert set(senses) - {"OBJ"} == pair_rows | final_rows
    total_processing = sum(pmax, ZERO)
    assert total_processing < Decimal(99)

    # The printed MPS coefficients differ by a few ulps.  An inner/outer
    # sandwich keeps the certificate literal for those decimal coefficients.
    # The inner model uses the largest pairwise processing requirement for
    # every job and the smallest compatible common deadline.  The outer model
    # uses the smallest requirement and largest compatible deadline.
    inner_deadline = min(latest_start[i] + pmax[i] for i in schedulable)  # type: ignore[operator]
    outer_deadline = max(latest_start[i] + pmin[i] for i in schedulable)  # type: ignore[operator]
    assert inner_deadline <= outer_deadline

    incumbent = read_solution(incumbent_path)
    incumbent_x = []
    max_rounding = ZERO
    for var in xvars:
        value = incumbent.get(var, ZERO)
        rounded = Decimal(round(value))
        max_rounding = max(max_rounding, abs(value - rounded))
        assert abs(value - rounded) <= Decimal("1e-5")
        incumbent_x.append(int(rounded))
    assert all(incumbent_x[i] == 0 for i in fixed_zero)

    # Every release threshold gives a suffix-capacity inequality.  Keep all
    # 100 thresholds; dominated rows are harmless and make the map transparent.
    def write_compact(path: str, processing: list[Decimal], deadline: Decimal, label: str) -> None:
        with open(path, "w", encoding="ascii") as out:
            out.write(f"NAME          fhnw-paira100-{label}\n")
            out.write("ROWS\n")
            out.write(" N  OBJ\n")
            for i in range(n):
                out.write(f" L  K{i:03d}\n")
            out.write("COLUMNS\n")
            out.write("    MARK0000  'MARKER'                 'INTORG'\n")
            for j in schedulable:
                var = xvars[j]
                out.write(f"    {var:<8}  OBJ       {dstr(obj[var])}\n")
                for i in range(n):
                    if release[j] >= release[i]:
                        out.write(f"    {var:<8}  K{i:03d}      {dstr(processing[j])}\n")
            out.write("    MARK0001  'MARKER'                 'INTEND'\n")
            out.write("RHS\n")
            for i in range(n):
                out.write(f"    RHS1      K{i:03d}      {dstr(deadline-release[i])}\n")
            out.write("BOUNDS\n")
            for j in schedulable:
                out.write(f" BV BND1      {xvars[j]}\n")
            out.write("ENDATA\n")

    write_compact(inner_mps, pmax, inner_deadline, "inner")
    write_compact(outer_mps, pmin, outer_deadline, "outer")

    incumbent_objective = sum(obj[xvars[i]] * incumbent_x[i] for i in range(n))
    max_compact_violation = ZERO
    for i in range(n):
        load = sum((pmax[j] * incumbent_x[j] for j in schedulable if release[j] >= release[i]), ZERO)
        max_compact_violation = max(max_compact_violation, load - (inner_deadline - release[i]))
    assert max_compact_violation <= ZERO
    with open(start_path, "w", encoding="ascii") as out:
        out.write("# Exact rounded projection of official incumbent\n")
        for i in schedulable:
            out.write(f"C{i} {incumbent_x[i]}\n")

    mapping = {
        "source": source_mps,
        "n_jobs": n,
        "common_deadline": "1",
        "big_m": "100",
        "total_processing": dstr(total_processing),
        "max_processing_spread": dstr(max_processing_spread),
        "inner_deadline": dstr(inner_deadline),
        "outer_deadline": dstr(outer_deadline),
        "schedulable_jobs": schedulable,
        "fixed_zero_jobs": fixed_zero,
        "max_official_binary_rounding": dstr(max_rounding),
        "rounded_official_objective": dstr(incumbent_objective),
        "jobs": [
            {
                "job": i,
                "x": xvars[i],
                "start": svars[i],
                "release": dstr(release[i]),
                "processing_min": dstr(pmin[i]),
                "processing_max": dstr(pmax[i]),
                "latest_accepted_start": None if latest_start[i] is None else dstr(latest_start[i]),
                "weight": dstr(-obj[xvars[i]]),
            }
            for i in range(n)
        ],
        "pair_variables": [
            {"i": i, "j": j, "y": yvars[k], "even_row": f"R{2*k}", "odd_row": f"R{2*k+1}"}
            for k, (i, j) in enumerate(pairs)
        ],
    }
    with open(mapping_path, "w", encoding="utf-8") as out:
        json.dump(mapping, out, indent=2)
        out.write("\n")

    print("structural_certificate=PASS")
    print(f"jobs={n} schedulable={len(schedulable)} fixed_zero={len(fixed_zero)} pairs={len(pairs)}")
    print(f"total_processing={dstr(total_processing)} < 99")
    print(f"max_processing_spread={dstr(max_processing_spread)}")
    print(f"inner_deadline={dstr(inner_deadline)} outer_deadline={dstr(outer_deadline)}")
    print(f"max_official_binary_rounding={dstr(max_rounding)}")
    print(f"rounded_official_objective={dstr(incumbent_objective)}")
    print(f"inner_model={inner_mps}")
    print(f"outer_model={outer_mps}")
    print(f"mapping={mapping_path}")
    print(f"start={start_path}")


if __name__ == "__main__":
    main(*sys.argv[1:])
