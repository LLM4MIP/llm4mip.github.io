#!/usr/bin/env python3
"""Canonically lift an inner common-deadline solution to the original MPS."""

from __future__ import annotations

from decimal import Decimal, getcontext
import json
import sys

from reduce_common_deadline import ZERO, open_text, read_mps


getcontext().prec = 50


def read_solution(path: str) -> dict[str, Decimal]:
    values = {}
    with open_text(path) as stream:
        for raw in stream:
            fields = raw.split()
            if len(fields) == 2 and not fields[0].startswith(("#", "=obj=")):
                try:
                    values[fields[0]] = Decimal(fields[1])
                except Exception:
                    pass
    return values


def main(source_mps: str, mapping_path: str, compact_solution: str, output_path: str) -> None:
    with open(mapping_path, encoding="utf-8") as stream:
        mapping = json.load(stream)
    compact = read_solution(compact_solution)
    n = mapping["n_jobs"]
    jobs = mapping["jobs"]
    selected = []
    x = [0] * n
    for record in jobs:
        i = record["job"]
        value = compact.get(record["x"], ZERO)
        assert abs(value - Decimal(round(value))) <= Decimal("1e-8")
        x[i] = round(value)
        if x[i]:
            selected.append(i)
    fixed_zero = set(mapping["fixed_zero_jobs"])
    assert not (fixed_zero & set(selected))

    release = [Decimal(record["release"]) for record in jobs]
    pmax = [Decimal(record["processing_max"]) for record in jobs]
    inner_deadline = Decimal(mapping["inner_deadline"])

    # Earliest-start schedule in nondecreasing release order.  The inner nested
    # inequalities guarantee completion by inner_deadline.
    selected.sort(key=lambda i: (release[i], i))
    rejected = sorted(set(range(n)) - set(selected))
    order = selected + rejected
    starts = [ZERO] * n
    current = ZERO
    for i in selected:
        current = max(current, release[i])
        starts[i] = current
        current += pmax[i]
    selected_completion = current
    assert selected_completion <= inner_deadline

    # All unselected jobs may follow the common deadline.  pmax dominates every
    # pair-specific separation, and total processing is far below M=100.
    current = max(current, Decimal(1), max(release))
    for i in rejected:
        starts[i] = current
        current += pmax[i]
    assert max(starts) < Decimal(100)

    position = {job: pos for pos, job in enumerate(order)}
    values: dict[str, Decimal] = {}
    for i in range(n):
        values[f"C{i}"] = Decimal(x[i])
        values[f"C{100+i}"] = starts[i]
    for k, pair in enumerate(mapping["pair_variables"]):
        i, j = pair["i"], pair["j"]
        values[f"C{200+k}"] = ZERO if position[i] < position[j] else Decimal(1)

    senses, rhs, cols, _, obj, bounds, integer = read_mps(source_mps)
    activity = {row: ZERO for row, sense in senses.items() if sense != "N"}
    for var, incidences in cols.items():
        for row, coefficient in incidences.items():
            activity[row] += coefficient * values[var]
    violations = []
    for row, sense in senses.items():
        if sense == "N":
            continue
        residual = activity[row] - rhs[row]
        violation = max(ZERO, residual) if sense == "L" else max(ZERO, -residual) if sense == "G" else abs(residual)
        if violation:
            violations.append((violation, row, residual))
    bound_violations = []
    for var, value in values.items():
        lower, upper = bounds[var]
        if lower is not None and value < lower:
            bound_violations.append((lower - value, var))
        if upper is not None and value > upper:
            bound_violations.append((value - upper, var))
    integral_violations = [(var, values[var]) for var in integer if values[var] != values[var].to_integral_value()]
    assert not violations, sorted(violations, reverse=True)[:5]
    assert not bound_violations, sorted(bound_violations, reverse=True)[:5]
    assert not integral_violations, integral_violations[:5]

    objective = sum(coefficient * values[var] for var, coefficient in obj.items())
    with open(output_path, "w", encoding="ascii") as out:
        out.write(f"# Canonical exact-decimal lift; objective {objective}\n")
        for i in range(5150):
            out.write(f"C{i} {values[f'C{i}']}\n")

    print("lift_certificate=PASS")
    print(f"selected_jobs={len(selected)}")
    print(f"selected_completion={selected_completion}")
    print(f"last_start={max(starts)}")
    print(f"objective={objective}")
    print("max_row_violation=0 (exact Decimal evaluation)")
    print("max_bound_violation=0")
    print("integrality_violations=0")
    print(f"output={output_path}")


if __name__ == "__main__":
    main(*sys.argv[1:])
