from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def read_values(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix == ".gz" else open
    values: dict[str, float] = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
        for raw in handle:
            fields = raw.split()
            if len(fields) < 2 or fields[0].startswith("#") or fields[0] == "=obj=":
                continue
            try:
                values[fields[0]] = float(fields[1])
            except ValueError:
                pass
    return values


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def pair_offset(n: int, i: int, j: int) -> int:
    return i * (2 * n - i - 1) // 2 + j - i - 1


def recover_data(model: gp.Model, n: int) -> dict:
    variables = model.getVars()
    constraints = model.getConstrs()
    pairs = n * (n - 1) // 2
    if len(variables) != 2 * n + pairs:
        raise RuntimeError(f"unexpected Pair-A variable count: {len(variables)}")
    releases = [variables[n + i].LB for i in range(n)]
    horizon = max(variables[n + i].UB for i in range(n))

    durations: list[float | None] = [None] * n
    for i in range(n):
        j = i + 1 if i + 1 < n else i - 1
        left, right = min(i, j), max(i, j)
        order = variables[2 * n + pair_offset(n, left, right)]
        column = model.getCol(order)
        for k in range(column.size()):
            row = column.getConstr(k)
            coefficient = column.getCoeff(k)
            if i < n - 1 and coefficient < -0.5 * horizon:
                durations[i] = -row.RHS
            elif i == n - 1 and coefficient > 0.5 * horizon:
                durations[i] = horizon - row.RHS
    if any(value is None for value in durations):
        raise RuntimeError("failed to recover all durations")
    p = [float(value) for value in durations]

    latest: list[float | None] = [None] * n
    forced_zero: list[int] = []
    window_rows: dict[int, str] = {}
    for row in constraints:
        expr = model.getRow(row)
        if expr.size() == 1:
            variable = expr.getVar(0)
            coefficient = expr.getCoeff(0)
            if variable.index < n and row.Sense == GRB.EQUAL and abs(row.RHS) <= 1e-12 and abs(coefficient) > 1e-12:
                forced_zero.append(variable.index)
        elif expr.size() == 2 and row.Sense == GRB.LESS_EQUAL:
            terms = {expr.getVar(k).index: expr.getCoeff(k) for k in range(2)}
            selected = [idx for idx in terms if idx < n]
            starts = [idx for idx in terms if n <= idx < 2 * n]
            if len(selected) == 1 and len(starts) == 1 and starts[0] == n + selected[0]:
                i = selected[0]
                if abs(terms[i] - horizon) <= 1e-9 and abs(terms[n + i] - 1.0) <= 1e-9:
                    latest[i] = row.RHS - horizon
                    window_rows[i] = row.ConstrName
    forced_set = set(forced_zero)
    eligible = [i for i in range(n) if i not in forced_set]
    if any(latest[i] is None for i in eligible):
        raise RuntimeError("missing active deadline rows")
    deadlines = [None if latest[i] is None else latest[i] + p[i] for i in range(n)]

    # Check every one of the 2*C(n,2) disjunctive rows against the recovered semantics.
    rows_by_support: dict[frozenset[int], list[gp.Constr]] = {}
    for row in constraints:
        expr = model.getRow(row)
        support = frozenset(expr.getVar(k).index for k in range(expr.size()))
        rows_by_support.setdefault(support, []).append(row)
    pair_rows = 0
    pair_failures = 0
    max_rhs_error = 0.0
    for i in range(n):
        for j in range(i + 1, n):
            y = 2 * n + pair_offset(n, i, j)
            matching = rows_by_support.get(frozenset({n + i, n + j, y}), [])
            if len(matching) != 2:
                pair_failures += 1
                continue
            pair_rows += 2
            expected = sorted([-p[i], horizon - p[j]])
            actual = sorted(row.RHS for row in matching)
            error = max(abs(a - b) for a, b in zip(actual, expected))
            max_rhs_error = max(max_rhs_error, error)
            if error > 1e-9:
                pair_failures += 1

    return {
        "n": n,
        "horizon": horizon,
        "releases": releases,
        "durations": p,
        "latest_starts": latest,
        "deadlines": deadlines,
        "forced_zero": sorted(forced_zero),
        "eligible": eligible,
        "window_rows": window_rows,
        "pair_rows_checked": pair_rows,
        "pair_semantic_failures": pair_failures,
        "pair_max_rhs_error": max_rhs_error,
    }


def audit_values(model: gp.Model, values: list[float]) -> dict:
    max_bound = max_integrality = max_row = 0.0
    bound_count = integrality_count = row_count = 0
    objective = model.ObjCon
    for variable, value in zip(model.getVars(), values):
        objective += variable.Obj * value
        violation = max(variable.LB - value, value - variable.UB, 0.0)
        max_bound = max(max_bound, violation)
        bound_count += violation > 1e-9
        if variable.VType in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT):
            violation = abs(value - round(value))
            max_integrality = max(max_integrality, violation)
            integrality_count += violation > 1e-9
    worst: list[tuple[float, str]] = []
    for row in model.getConstrs():
        expr = model.getRow(row)
        activity = math.fsum(expr.getCoeff(k) * values[expr.getVar(k).index] for k in range(expr.size()))
        if row.Sense == GRB.LESS_EQUAL:
            violation = max(activity - row.RHS, 0.0)
        elif row.Sense == GRB.GREATER_EQUAL:
            violation = max(row.RHS - activity, 0.0)
        else:
            violation = abs(activity - row.RHS)
        max_row = max(max_row, violation)
        row_count += violation > 1e-9
        if violation > 0:
            worst.append((violation, row.ConstrName))
    return {
        "objective": objective,
        "max_bound_violation": max_bound,
        "max_integrality_violation": max_integrality,
        "max_row_violation": max_row,
        "bound_violations_over_1e_9": bound_count,
        "integrality_violations_over_1e_9": integrality_count,
        "row_violations_over_1e_9": row_count,
        "worst_rows": sorted(worst, reverse=True)[:10],
        "strictly_feasible_1e_9": max(max_bound, max_integrality, max_row) <= 1e-9,
    }


def audit_solution(model: gp.Model) -> dict:
    return audit_values(model, [variable.X for variable in model.getVars()])


def feasible_before(i: int, j: int, data: dict) -> bool:
    releases = data["releases"]
    durations = data["durations"]
    deadlines = data["deadlines"]
    completion_i = releases[i] + durations[i]
    completion_j = max(releases[j], completion_i) + durations[j]
    return completion_i <= deadlines[i] + 1e-12 and completion_j <= deadlines[j] + 1e-12


def energy_coefficients(a: float, b: float, data: dict) -> list[float]:
    result = [0.0] * data["n"]
    for i in data["eligible"]:
        release = data["releases"][i]
        duration = data["durations"][i]
        deadline = data["deadlines"][i]
        outside_left = max(0.0, a - release)
        outside_right = max(0.0, deadline - b)
        result[i] = max(0.0, duration - outside_left - outside_right)
    return result


def repair_public(original: gp.Model, public: dict[str, float], output: Path) -> dict:
    repaired = original.copy()
    variables = repaired.getVars()
    for variable in variables:
        if variable.VarName in public:
            raw = public[variable.VarName]
            variable.Start = round(raw) if variable.VType != GRB.CONTINUOUS else raw
            if variable.VType != GRB.CONTINUOUS:
                value = round(raw)
                variable.LB = value
                variable.UB = value
    repaired.Params.OutputFlag = 0
    repaired.Params.FeasibilityTol = 1e-9
    repaired.Params.IntFeasTol = 1e-9
    repaired.optimize()
    report = {"status": int(repaired.Status), "status_name": {GRB.OPTIMAL: "OPTIMAL", GRB.INFEASIBLE: "INFEASIBLE"}.get(repaired.Status, str(repaired.Status))}
    if repaired.SolCount:
        report["audit"] = audit_solution(repaired)
        repaired.write(str(output))
    return report


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("public_solution", type=Path)
    parser.add_argument("summary", type=Path)
    parser.add_argument("log", type=Path)
    parser.add_argument("solution_out", type=Path)
    parser.add_argument("--time-limit", type=float, default=1200.0)
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--max-energy-cuts", type=int, default=6000)
    parser.add_argument("--lp-rounds", type=int, default=6)
    args = parser.parse_args()

    original = gp.read(str(args.mps))
    structure = recover_data(original, 100)
    public = read_values(args.public_solution)
    public_values = [public.get(variable.VarName, 0.0) for variable in original.getVars()]
    public_audit = audit_values(original, public_values)
    repaired_path = args.solution_out.with_name("public-strict-repair.sol")
    public_repair = repair_public(original, public, repaired_path)

    model = gp.read(str(args.mps))
    variables = model.getVars()
    for variable in variables:
        if variable.VarName in public:
            variable.Start = round(public[variable.VarName]) if variable.VType != GRB.CONTINUOUS else public[variable.VarName]

    conflicts: list[tuple[int, int]] = []
    eligible = structure["eligible"]
    for position, i in enumerate(eligible):
        for j in eligible[position + 1 :]:
            if not feasible_before(i, j, structure) and not feasible_before(j, i, structure):
                model.addConstr(variables[i] + variables[j] <= 1.0, name=f"pair_conflict_{i}_{j}")
                conflicts.append((i, j))
    model.update()

    endpoints = sorted({structure["releases"][i] for i in eligible} | {structure["deadlines"][i] for i in eligible})
    interval_data = []
    for left, a in enumerate(endpoints):
        for b in endpoints[left + 1 :]:
            coefficients = energy_coefficients(a, b, structure)
            if sum(value > 1e-12 for value in coefficients) >= 2:
                interval_data.append((a, b, coefficients))

    relaxation = model.relax()
    relaxation.Params.OutputFlag = 0
    relaxation.Params.Method = 1
    relaxation.Params.Threads = args.threads
    added: set[tuple[float, float]] = set()
    records = []
    remaining = args.max_energy_cuts
    for round_index in range(args.lp_rounds):
        relaxation.optimize()
        z = [relaxation.getVars()[i].X for i in range(100)]
        violated = []
        for a, b, coefficients in interval_data:
            if (a, b) in added:
                continue
            violation = math.fsum(coefficients[i] * z[i] for i in eligible) - (b - a)
            if violation > 1e-8:
                norm = math.sqrt(math.fsum(coefficients[i] ** 2 for i in eligible))
                violated.append((violation / max(norm, 1e-12), violation, a, b, coefficients))
        violated.sort(reverse=True, key=lambda item: item[0])
        take = min(1500, remaining, len(violated))
        for _, violation, a, b, coefficients in violated[:take]:
            expression_mip = gp.LinExpr()
            expression_lp = gp.LinExpr()
            for i in eligible:
                coefficient = coefficients[i]
                if coefficient > 1e-12:
                    expression_mip.add(variables[i], coefficient)
                    expression_lp.add(relaxation.getVars()[i], coefficient)
            rhs = b - a + 1e-11
            model.addConstr(expression_mip <= rhs, name=f"energy_{len(added)}")
            relaxation.addConstr(expression_lp <= rhs)
            added.add((a, b))
            records.append({"round": round_index, "a": a, "b": b, "initial_violation": violation})
        remaining -= take
        if take == 0 or remaining == 0:
            break
    model.update()

    args.log.parent.mkdir(parents=True, exist_ok=True)
    model.Params.LogFile = str(args.log)
    model.Params.TimeLimit = args.time_limit
    model.Params.Threads = args.threads
    model.Params.MIPFocus = 3
    model.Params.Cuts = 3
    model.Params.Heuristics = 0.1
    model.Params.FeasibilityTol = 1e-9
    model.Params.IntFeasTol = 1e-9
    model.Params.MIPGap = 1e-9
    proof_model = args.summary.with_name(args.summary.stem + "-proof.mps.gz")
    model.write(str(proof_model))
    model.optimize()

    report = {
        "instance": "fhnw-schedule-paira100",
        "method": "Pair-A plus exact window-conflict and mandatory-overlap energetic inequalities",
        "input_sha256": sha256(args.mps),
        "public_solution_sha256": sha256(args.public_solution),
        "structure": {
            "variables": original.NumVars,
            "constraints": original.NumConstrs,
            "nonzeros": original.NumNZs,
            "binaries": sum(variable.VType == GRB.BINARY for variable in original.getVars()),
            "continuous": sum(variable.VType == GRB.CONTINUOUS for variable in original.getVars()),
            "eligible_jobs": len(eligible),
            "forced_zero_jobs": len(structure["forced_zero"]),
            "horizon": structure["horizon"],
            "release_min": min(structure["releases"][i] for i in eligible),
            "deadline_max": max(structure["deadlines"][i] for i in eligible),
            "duration_min": min(structure["durations"]),
            "duration_max": max(structure["durations"]),
            "duration_sum": sum(structure["durations"]),
            "pair_rows_checked": structure["pair_rows_checked"],
            "pair_semantic_failures": structure["pair_semantic_failures"],
            "pair_max_rhs_error": structure["pair_max_rhs_error"],
        },
        "public_audit": public_audit,
        "public_strict_repair": public_repair,
        "pair_conflict_cuts": len(conflicts),
        "candidate_intervals": len(interval_data),
        "energetic_cuts": len(added),
        "energy_cut_rounds": [sum(record["round"] == r for record in records) for r in range(args.lp_rounds)],
        "proof_model": str(proof_model.resolve()),
        "proof_model_sha256": sha256(proof_model),
        "status": int(model.Status),
        "status_name": {GRB.OPTIMAL: "OPTIMAL", GRB.TIME_LIMIT: "TIME_LIMIT", GRB.INFEASIBLE: "INFEASIBLE"}.get(model.Status, str(model.Status)),
        "runtime": model.Runtime,
        "nodes": model.NodeCount,
        "solutions": model.SolCount,
        "objective": model.ObjVal if model.SolCount else None,
        "bound": model.ObjBound,
        "gap": model.MIPGap if model.SolCount else None,
    }
    if model.SolCount:
        report["enhanced_model_audit"] = audit_solution(model)
        model.write(str(args.solution_out))
        verify = gp.read(str(args.mps))
        by_name = {variable.VarName: variable.X for variable in model.getVars()}
        report["original_mps_audit"] = audit_values(verify, [by_name[variable.VarName] for variable in verify.getVars()])
    args.summary.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
