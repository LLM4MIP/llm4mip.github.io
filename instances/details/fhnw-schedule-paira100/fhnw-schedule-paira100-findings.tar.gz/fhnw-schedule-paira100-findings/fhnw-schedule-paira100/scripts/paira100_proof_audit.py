from __future__ import annotations

import argparse
import json
import math
import re
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB

from paira100_energy_solver import audit_values, energy_coefficients, feasible_before, read_values, recover_data, sha256


def row_signature(model: gp.Model, row: gp.Constr) -> tuple:
    expr = model.getRow(row)
    terms = tuple(sorted((expr.getVar(k).VarName, round(expr.getCoeff(k), 13)) for k in range(expr.size())))
    return row.Sense, round(row.RHS, 13), terms


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("original", type=Path)
    parser.add_argument("proof", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("public_solution", type=Path)
    parser.add_argument("report", type=Path)
    parser.add_argument("rerun_solution", type=Path)
    parser.add_argument("log", type=Path)
    args = parser.parse_args()

    original = gp.read(str(args.original))
    proof = gp.read(str(args.proof))
    data = recover_data(original, 100)
    original_rows = {row.ConstrName: row_signature(original, row) for row in original.getConstrs()}
    proof_rows = {row.ConstrName: row_signature(proof, row) for row in proof.getConstrs()}
    missing_original = sorted(set(original_rows) - set(proof_rows))
    altered_original = sorted(name for name, signature in original_rows.items() if proof_rows.get(name) != signature)

    conflicts_checked = conflicts_invalid = 0
    energy_checked = energy_invalid = 0
    unknown_added: list[str] = []
    eligible = data["eligible"]
    endpoints = sorted({data["releases"][i] for i in eligible} | {data["deadlines"][i] for i in eligible})
    valid_energy_signatures: set[tuple] = set()
    for left, a in enumerate(endpoints):
        for b in endpoints[left + 1 :]:
            coefficients = energy_coefficients(a, b, data)
            if sum(value > 1e-12 for value in coefficients) < 2:
                continue
            terms = tuple(sorted((original.getVars()[i].VarName, round(coefficients[i], 13)) for i in eligible if coefficients[i] > 1e-12))
            valid_energy_signatures.add((GRB.LESS_EQUAL, round(b - a + 1e-11, 13), terms))

    for row in proof.getConstrs():
        name = row.ConstrName
        if name in original_rows:
            continue
        match = re.fullmatch(r"pair_conflict_(\d+)_(\d+)", name)
        if match:
            conflicts_checked += 1
            i, j = map(int, match.groups())
            signature = row_signature(proof, row)
            expected = (GRB.LESS_EQUAL, 1.0, tuple(sorted(((f"C{i}", 1.0), (f"C{j}", 1.0)))))
            invalid = (
                i not in eligible
                or j not in eligible
                or feasible_before(i, j, data)
                or feasible_before(j, i, data)
                or signature != expected
            )
            conflicts_invalid += int(invalid)
        elif name.startswith("energy_"):
            energy_checked += 1
            energy_invalid += int(row_signature(proof, row) not in valid_energy_signatures)
        else:
            unknown_added.append(name)

    solution_values = read_values(args.solution)
    original_solution_audit = audit_values(original, [solution_values.get(variable.VarName, 0.0) for variable in original.getVars()])
    proof_solution_audit = audit_values(proof, [solution_values.get(variable.VarName, 0.0) for variable in proof.getVars()])
    selected = [i for i in range(100) if solution_values.get(f"C{i}", 0.0) > 0.5]

    public_values = read_values(args.public_solution)
    public_integer_offenders = []
    for variable in original.getVars():
        if variable.VType != GRB.CONTINUOUS:
            value = public_values.get(variable.VarName, 0.0)
            deviation = abs(value - round(value))
            if deviation > 1e-9:
                public_integer_offenders.append({"name": variable.VarName, "index": variable.index, "value": value, "deviation": deviation, "objective_coefficient": variable.Obj})

    proof.Params.LogFile = str(args.log)
    proof.Params.Threads = 1
    proof.Params.Seed = 73
    proof.Params.MIPFocus = 0
    proof.Params.Cuts = 2
    proof.Params.NumericFocus = 3
    proof.Params.FeasibilityTol = 1e-9
    proof.Params.IntFeasTol = 1e-9
    proof.Params.MIPGap = 1e-9
    for variable in proof.getVars():
        if variable.VarName in solution_values:
            variable.Start = solution_values[variable.VarName]
    proof.optimize()
    rerun = {
        "status": int(proof.Status),
        "status_name": {GRB.OPTIMAL: "OPTIMAL", GRB.TIME_LIMIT: "TIME_LIMIT"}.get(proof.Status, str(proof.Status)),
        "runtime": proof.Runtime,
        "nodes": proof.NodeCount,
        "solutions": proof.SolCount,
        "objective": proof.ObjVal if proof.SolCount else None,
        "bound": proof.ObjBound,
        "gap": proof.MIPGap if proof.SolCount else None,
    }
    if proof.SolCount:
        rerun["audit"] = audit_values(proof, [variable.X for variable in proof.getVars()])
        proof.write(str(args.rerun_solution))

    report = {
        "instance": "fhnw-schedule-paira100",
        "original_sha256": sha256(args.original),
        "proof_sha256": sha256(args.proof),
        "solution_sha256": sha256(args.solution),
        "original_rows": len(original_rows),
        "proof_rows": len(proof_rows),
        "missing_original_rows": missing_original,
        "altered_original_rows": altered_original,
        "conflict_rows_checked": conflicts_checked,
        "invalid_conflict_rows": conflicts_invalid,
        "energy_rows_checked": energy_checked,
        "invalid_energy_rows": energy_invalid,
        "unknown_added_rows": unknown_added,
        "deadline_semantics": "active latest-start bound is RHS-horizon; completion deadline equals latest_start + duration",
        "pair_semantic_failures": data["pair_semantic_failures"],
        "original_solution_audit": original_solution_audit,
        "proof_solution_audit": proof_solution_audit,
        "selected_jobs": selected,
        "selected_job_count": len(selected),
        "public_integer_offenders": public_integer_offenders,
        "independent_rerun": rerun,
        "semantic_audit_passed": not missing_original and not altered_original and conflicts_invalid == 0 and energy_invalid == 0 and not unknown_added and data["pair_semantic_failures"] == 0,
        "proof_scope": "Solver-verified global optimum of the original integer model after adding only audited globally valid inequalities; not a DRAT/LRAT formal certificate.",
    }
    args.report.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
