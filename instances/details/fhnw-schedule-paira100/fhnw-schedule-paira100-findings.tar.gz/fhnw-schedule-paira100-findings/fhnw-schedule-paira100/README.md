# fhnw-schedule-paira100 — solver-verified OPT = -15.113116512593402

2026-09-14 independent dual-bound review: [adopted bound, proof chain, checks, and limitations](../../docs/dual-bound-audit-2026-09-14/cases/fhnw-schedule-paira100.zh.md). Reviewed lower bound: **-15.113116512593401992**. Use this exact certified decimal; superseded floating-point headline digits below are historical. This review distinguishes exact, literature, and numerical evidence; historical statements below remain dated records.

Official MIPLIB page: <https://miplib.zib.de/instance_details_fhnw-schedule-paira100.html>

## Result

The original Pair-A formulation is globally closed under strict integer
semantics:

```text
primal = -15.113116512593402
dual   = -15.113116512593402
gap    = 0
selected jobs = 23
```

This is a **solver-verified global conclusion**, not a portable formal MIP
certificate. The full original model is retained, only independently audited
valid inequalities are added, and the resulting proof model is solved to zero
gap twice with different parameters. The final solution is then evaluated in
the untouched official MPS.

The MIPLIB headline `-15.1131226682367` is numerically lower, but its public
solution contains three nonintegral binary values. Two selected-job variables
near `5.406e-6` explain the apparent `6.15564e-6` advantage. Strict rounding and
continuous repair give exactly the optimum above. This instance is therefore
counted as a strictification and optimality closure, **not** as a numerical
primal improvement over the headline.

## Structure and proof

Gurobi reads 5,150 variables, 10,000 rows and 29,873 nonzeros. The first 100
binaries select jobs, 100 continuous variables are start times, and the other
4,950 binaries encode pairwise order. Twenty-seven jobs are fixed to zero and
73 are eligible.

The proof model adds:

- 196 pair conflicts `z_i + z_j <= 1` where neither relative order fits;
- 2,292 interval-energy inequalities
  `sum_i e_i(a,b) z_i <= b-a`, with completion deadline defined as
  `latest_start_i + processing_time_i`.

The first two-thread run closes in 0.835 seconds and one node. A one-thread,
Seed-73 reread of the frozen proof MPS closes in 3.141 seconds and eight nodes.
The semantic audit verifies all 9,900 original pair rows, all 196 conflicts and
all 2,292 energy rows. The final solution has zero bound/integrality violation,
maximum original-row violation `6.66e-15`, and no row violation above `1e-9`.

## Alternative common-deadline sandwich

An independently supplied structural derivation gives a second route to the
same global conclusion. It projects the model to 73 eligible selection
binaries and nested common-deadline packing rows. To respect the literal last
digits in the MPS, it constructs an inner model from the largest repeated
processing-time coefficients and an outer model from the smallest ones:

```text
F_inner subset F_original subset F_outer.
```

The inner and outer deadlines are respectively `0.999999999999995` and
`1.000000000000005`. Gurobi 13.0.2 solved both 73-binary models to zero gap in
six nodes; both have the same 23-job optimum
`-15.11311651259340199200`. The complete lifted witness
[`global-optimal-exact-decimal.sol`](solutions/global-optimal-exact-decimal.sol)
was then replayed against all 10,000 literal-decimal original rows: the row,
bound, and integrality violations are all exactly zero. This alternative is
still a solver-verified sandwich proof, not a portable DRAT/LRAT certificate.

See the [common-deadline report](reports/common-deadline-sandwich-2026-09-08.md)
and its [machine-readable result](artifacts/common-deadline/result.json).

## Evidence and reproduction

- [`summary.json`](artifacts/summary.json) gives the compact result.
- [`energy-proof-proof.mps.gz`](artifacts/energy-proof-proof.mps.gz) is the
  frozen augmented model.
- [`proof-semantic-audit.json`](artifacts/proof-semantic-audit.json) records the
  row-by-row semantic and original-MPS checks.
- [`global-optimal.sol`](solutions/global-optimal.sol) is the final witness.
- [`global-optimal-exact-decimal.sol`](solutions/global-optimal-exact-decimal.sol)
  is the full exact-decimal witness from the alternative sandwich proof.
- [`common-deadline/`](artifacts/common-deadline/) contains the compact
  solutions, coefficient map and machine-readable alternative result.
- [`deep-study-2026-09-08.zh.md`](reports/deep-study-2026-09-08.zh.md) is the
  detailed Chinese report.

The strengthening and independent audit require Gurobi:

```sh
python scripts/paira100_energy_solver.py \
  input/fhnw-schedule-paira100.mps.gz \
  input/fhnw-schedule-paira100-public.sol.gz \
  /tmp/paira100.json /tmp/paira100.log /tmp/paira100.sol

python scripts/paira100_proof_audit.py \
  input/fhnw-schedule-paira100.mps.gz \
  artifacts/energy-proof-proof.mps.gz \
  solutions/global-optimal.sol \
  input/fhnw-schedule-paira100-public.sol.gz \
  /tmp/paira100-audit.json /tmp/paira100-rerun.sol /tmp/paira100-rerun.log
```

Hashes of the official input, proof model and both full witnesses are in
[`input/SHA256SUMS`](input/SHA256SUMS).
