# Package manifest: fhnw-schedule-paira100

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 28
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/common-deadline/exact-bracketing-mapping.json`
- `artifacts/common-deadline/inner-strict.sol`
- `artifacts/common-deadline/official-id2.sol.gz`
- `artifacts/common-deadline/outer-strict.sol`
- `artifacts/common-deadline/result.json`
- `artifacts/energy-proof-proof.mps.gz`
- `artifacts/energy-proof.json`
- `artifacts/proof-semantic-audit.json`
- `artifacts/summary.json`
- `experiments/common-deadline/audit_solution.py`
- `experiments/common-deadline/lift_common_deadline.py`
- `experiments/common-deadline/reduce_common_deadline.py`
- `experiments/common-deadline/verify_structure.py`
- `experiments/energy-proof.log`
- `experiments/proof-independent.log`
- `input/SHA256SUMS`
- `input/fhnw-schedule-paira100-public.sol.gz`
- `logs/common-deadline/inner-strict.log`
- `logs/common-deadline/outer-strict.log`
- `reports/SOURCES.md`
- `reports/common-deadline-sandwich-2026-09-08.md`
- `reports/deep-study-2026-09-08.zh.md`
- `scripts/paira100_energy_solver.py`
- `scripts/paira100_proof_audit.py`
- `solutions/global-optimal-exact-decimal.sol`
- `solutions/global-optimal.sol`
- `solutions/public-strict-repair.sol`

## Excluded files

- `input/fhnw-schedule-paira100.mps.gz (184076 bytes; raw benchmark input; sha256 e392e336e824ab1481a7cb87f3e0b44b78b77483fd7ca619898b27512440ea38)`
