#!/usr/bin/env bash
set -euo pipefail
cd /home/huangyicheng/miplib-rmine13-set3-09-20260908-agent-rmine_set3

for tag in item-group-1_6 item-group-13_18 item-group-19_30 sibling10-fixed sibling16-fixed sibling20-fixed sibling20-start; do
  source_dir="analysis/set3-${tag}"
  out_dir="analysis/set3-exactified-${tag}"
  mkdir -p "$out_dir"
  python3 analysis/set3_exactify.py \
    --mps instances/set3-09.mps.gz \
    --source "$source_dir/incumbent.sol" \
    --out "$out_dir/incumbent.sol" \
    --report "$out_dir/reconstruction.json" \
    --alphas 0.99999999999999 \
    > "logs/set3-exactified-${tag}.log" 2>&1
  python3 analysis/fixed_rhs_exact_wrapper.py \
    analysis/exact_mps_solution_check.py \
    instances/set3-09.mps.gz "$out_dir/incumbent.sol" --tolerance 0 \
    > "$out_dir/exact-audit.log" 2>&1
  sha256sum "$out_dir/incumbent.sol" > "$out_dir/sha256.txt"
done
