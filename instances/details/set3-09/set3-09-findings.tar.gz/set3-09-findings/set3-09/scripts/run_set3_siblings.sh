#!/usr/bin/env bash
set -u
base=/home/huangyicheng/miplib-rmine13-set3-09-20260908-agent-rmine_set3
export PYTHONPATH=/home/huangyicheng/copt80/lib/python/310
export LD_LIBRARY_PATH=/home/huangyicheng/copt80/lib:/home/huangyicheng/copt80/lib/python/deps
cd "$base" || exit 2
for sibling in 10 16 20; do
  python3 analysis/copt_structured_search.py \
    --model instances/set3-09.mps.gz \
    --pattern "instances/set3-$sibling-public.sol.gz" \
    --outdir "analysis/set3-sibling$sibling-fixed" \
    --mode set3-sibling-fixed --seconds 30 --threads 2 || exit $?
  python3 analysis/copt_structured_search.py \
    --model instances/set3-09.mps.gz \
    --pattern "instances/set3-$sibling-public.sol.gz" \
    --outdir "analysis/set3-sibling$sibling-start" \
    --mode set3-sibling-start --seconds 180 --threads 6 --aggressive || exit $?
done
