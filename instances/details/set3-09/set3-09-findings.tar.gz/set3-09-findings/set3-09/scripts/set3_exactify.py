#!/usr/bin/env python3
"""Construct an exact finite-decimal set3 solution from a floating LP point.

The binary setup pattern is rounded, production quantities are uniformly
contracted, and every inventory/backlog balance plus the three cost identities
is then recomputed with Decimal arithmetic directly from the original MPS.
"""

from __future__ import annotations

import argparse
import gzip
import json
import re
from collections import defaultdict
from decimal import Decimal, getcontext
from pathlib import Path


getcontext().prec = 100
VAR_RE = re.compile(r"^(?P<family>[xsyb])\((?P<t>\d+),(?P<i>\d+)\)$")
BAL_RE = re.compile(r"^bal(?P<kind>[1-4])(?:\((?P<a>\d+)(?:,(?P<b>\d+))?\))$")


def number(text: str) -> Decimal:
    return Decimal(text.replace("D", "E").replace("d", "e"))


def open_text(path: Path):
    return gzip.open(path, "rt", encoding="latin-1") if path.suffix == ".gz" else path.open(encoding="latin-1")


def read_solution(path: Path) -> dict[str, Decimal]:
    opener = gzip.open if path.suffix == ".gz" else open
    values: dict[str, Decimal] = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as stream:
        for raw in stream:
            fields = raw.split()
            if len(fields) < 2 or fields[0].startswith(("#", "=")):
                continue
            try:
                values[fields[0]] = number(fields[1])
            except Exception:
                pass
    return values


def parse_mps(path: Path):
    section = ""
    row_kind: dict[str, str] = {}
    rhs: dict[str, Decimal] = defaultdict(Decimal)
    terms: dict[str, list[tuple[str, Decimal]]] = defaultdict(list)
    objective_row = None
    variables: set[str] = set()
    integers: set[str] = set()
    lower: dict[str, Decimal] = {}
    upper: dict[str, Decimal | None] = {}
    integer_mode = False
    with open_text(path) as stream:
        for raw in stream:
            fields = raw.split()
            if not fields or raw.startswith("*"):
                continue
            if not raw[0].isspace() and fields[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = fields[0]
                continue
            if section == "ROWS":
                row_kind[fields[1]] = fields[0]
                if fields[0] == "N":
                    objective_row = fields[1]
            elif section == "COLUMNS":
                if "'MARKER'" in fields:
                    integer_mode = "'INTORG'" in fields
                    continue
                variable = fields[0]
                variables.add(variable)
                if integer_mode:
                    integers.add(variable)
                for row, coefficient in zip(fields[1::2], fields[2::2]):
                    terms[row].append((variable, number(coefficient)))
            elif section == "RHS":
                for row, value in zip(fields[1::2], fields[2::2]):
                    rhs[row] += number(value)
            elif section == "BOUNDS":
                kind, variable = fields[0], fields[2]
                value = number(fields[3]) if len(fields) > 3 else Decimal(0)
                if kind == "BV":
                    lower[variable], upper[variable] = Decimal(0), Decimal(1)
                    integers.add(variable)
                elif kind in {"LO", "LI"}:
                    lower[variable] = value
                    if kind == "LI": integers.add(variable)
                elif kind in {"UP", "UI"}:
                    upper[variable] = value
                    if kind == "UI": integers.add(variable)
                elif kind == "FX":
                    lower[variable] = upper[variable] = value
                elif kind == "FR":
                    lower[variable], upper[variable] = Decimal("-Infinity"), None
                elif kind == "MI":
                    lower[variable] = Decimal("-Infinity")
                elif kind == "PL":
                    upper[variable] = None
                else:
                    raise ValueError(f"unsupported bound {kind}")
    for variable in variables:
        lower.setdefault(variable, Decimal(0))
        upper.setdefault(variable, None)
    return row_kind, rhs, terms, objective_row, variables, integers, lower, upper


def balance_coordinate(name: str) -> tuple[int, int] | None:
    match = BAL_RE.match(name)
    if not match:
        return None
    kind = int(match.group("kind"))
    a, b = int(match.group("a")), match.group("b")
    if kind in (1, 3):
        return 1, a
    return a, int(b)


def construct(alpha: Decimal, source, row_kind, rhs, terms, objective_row, variables, integers):
    values = {name: Decimal(0) for name in variables}
    for name in integers:
        values[name] = source.get(name, Decimal(0)).to_integral_value()
    max_item = max(
        int(match.group("i"))
        for name in variables
        if (match := VAR_RE.match(name)) and match.group("family") == "x"
    )
    for name in variables:
        match = VAR_RE.match(name)
        if match and match.group("family") == "x":
            # Later-numbered items are upstream components in this instance's
            # triangular bill-of-materials graph.  Contract finished-product
            # production slightly more than its inputs, creating exact material
            # slack even when a rounded source point has a zero-setup period.
            exponent = max_item - int(match.group("i")) + 1
            # Use a linear finite-decimal gradient instead of alpha**exponent.
            # This preserves exact finite decimals of modest length, so the
            # subsequently replayed cost identities audit to literal zero.
            factor = Decimal(1) - (Decimal(1) - alpha) * exponent
            setup = f"y({match.group('t')},{match.group('i')})"
            # Solver outputs may retain 1e-12 production on a setup fixed to
            # zero.  Enforce the exact linking implication before recurrence.
            values[name] = (
                Decimal(0)
                if values.get(setup, Decimal(0)) == 0
                else max(Decimal(0), source.get(name, Decimal(0))) * factor
            )

    balance_rows = [name for name in row_kind if balance_coordinate(name)]
    balance_rows.sort(key=lambda name: balance_coordinate(name))
    negative_component_inventory = []
    production_repairs = []
    for row in balance_rows:
        t, item = balance_coordinate(row)
        inventory = f"s({t},{item})"
        backlog = f"b({t},{item})"
        pivot_terms = {name: coefficient for name, coefficient in terms[row] if name in {inventory, backlog}}
        other = sum(coefficient * values[name] for name, coefficient in terms[row] if name not in {inventory, backlog})
        if item <= 6:
            # other - inventory + backlog = rhs
            net = other - rhs[row]
            if net >= 0:
                values[inventory], values[backlog] = net, Decimal(0)
            else:
                values[inventory], values[backlog] = Decimal(0), -net
        else:
            coefficient = pivot_terms.get(inventory)
            if coefficient != -1:
                raise RuntimeError(f"unexpected inventory pivot in {row}: {coefficient}")
            values[inventory] = other - rhs[row]
            if values[inventory] < 0:
                negative_component_inventory.append((values[inventory], inventory, row))
                production = f"x({t},{item})"
                production_coefficient = dict(terms[row]).get(production)
                if production_coefficient != 1:
                    raise RuntimeError(
                        f"unexpected production pivot in {row}: "
                        f"{production} coefficient {production_coefficient}"
                    )
                # MULTILSB's bill-of-materials graph is numbered top-down:
                # production consumed in this component balance belongs only to
                # lower-numbered items, which have already been fixed.  A tiny
                # increase in the present component production therefore repairs
                # this balance and propagates only to later (higher-numbered)
                # component rows.  Keep a 1e-18 exact safety inventory.
                other_x_items = []
                for variable, variable_coefficient in terms[row]:
                    match = VAR_RE.match(variable)
                    if match and match.group("family") == "x" and variable != production:
                        other_x_items.append(int(match.group("i")))
                if any(other_item >= item for other_item in other_x_items):
                    raise RuntimeError(
                        f"non-triangular bill-of-materials row {row}: "
                        f"other production items {other_x_items}"
                    )
                setup = f"y({t},{item})"
                if values.get(setup, Decimal(0)) != 1:
                    raise RuntimeError(
                        f"cannot repair {row}: setup {setup} is not active "
                        f"(value {values.get(setup, Decimal(0))})"
                    )
                delta = -values[inventory] + Decimal("1e-18")
                values[production] += delta
                values[inventory] = Decimal("1e-18")
                production_repairs.append((delta, production, inventory, row))

    # Recompute cost auxiliaries from their defining equalities.
    for row, target in (("_R3747", "costinv"), ("_R3746", "costb")):
        target_coefficient = dict(terms[row]).get(target)
        other = sum(coefficient * values[name] for name, coefficient in terms[row] if name != target)
        values[target] = (rhs[row] - other) / target_coefficient
    values["cost"] = values["costinv"] + values["costb"]
    return values, negative_component_inventory, production_repairs


def audit(values, row_kind, rhs, terms, objective_row, variables, integers, lower, upper):
    row_violations = []
    for row, kind in row_kind.items():
        if kind == "N":
            continue
        lhs = sum(coefficient * values[name] for name, coefficient in terms[row])
        if kind == "E": violation = abs(lhs - rhs[row])
        elif kind == "L": violation = max(Decimal(0), lhs - rhs[row])
        elif kind == "G": violation = max(Decimal(0), rhs[row] - lhs)
        else: raise ValueError(kind)
        if violation:
            row_violations.append((violation, row, lhs, rhs[row]))
    bound_violations = []
    for name in variables:
        value = values[name]
        violation = max(Decimal(0), lower[name] - value)
        if upper[name] is not None:
            violation = max(violation, value - upper[name])
        if violation:
            bound_violations.append((violation, name, value))
    integer_violations = [(abs(values[n] - values[n].to_integral_value()), n) for n in integers if values[n] != values[n].to_integral_value()]
    row_violations.sort(reverse=True)
    bound_violations.sort(reverse=True)
    objective = sum(coefficient * values[name] for name, coefficient in terms[objective_row])
    return objective, row_violations, bound_violations, integer_violations


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--alphas", default="1,0.99999999999999,0.999999999999,0.9999999999,0.99999999")
    args = parser.parse_args()
    parsed = parse_mps(args.mps)
    row_kind, rhs, terms, objective_row, variables, integers, lower, upper = parsed
    source = read_solution(args.source)
    trials = []
    accepted = None
    for token in args.alphas.split(","):
        alpha = Decimal(token)
        values, negative, repairs = construct(alpha, source, row_kind, rhs, terms, objective_row, variables, integers)
        objective, rows, bounds, integrality = audit(values, row_kind, rhs, terms, objective_row, variables, integers, lower, upper)
        record = {
            "alpha": str(alpha),
            "objective": str(objective),
            "negative_component_inventory_count": len(negative),
            "minimum_component_inventory": str(min((x[0] for x in negative), default=Decimal(0))),
            "production_repair_count": len(repairs),
            "maximum_production_repair": str(max((x[0] for x in repairs), default=Decimal(0))),
            "total_production_repair": str(sum((x[0] for x in repairs), Decimal(0))),
            "row_violation_count": len(rows),
            "max_row_violation": str(rows[0][0] if rows else 0),
            "worst_row": [str(x) for x in rows[0]] if rows else None,
            "bound_violation_count": len(bounds),
            "max_bound_violation": str(bounds[0][0] if bounds else 0),
            "worst_bound": [str(x) for x in bounds[0]] if bounds else None,
            "integrality_violation_count": len(integrality),
        }
        trials.append(record)
        if not rows and not bounds and not integrality and accepted is None:
            accepted = (values, record)
    report = {
        "method": "bom-gradient-production-contraction_then_exact_balance_and_cost_replay",
        "source": str(args.source),
        "mps": str(args.mps),
        "trials": trials,
        "accepted": accepted[1] if accepted else None,
    }
    args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    if accepted:
        values = accepted[0]
        with args.out.open("w", encoding="utf-8") as stream:
            stream.write(f"=obj= {accepted[1]['objective']}\n")
            stream.write("# Exact finite-decimal balance reconstruction from fixed official binary pattern\n")
            for name in sorted(variables):
                if values[name]:
                    stream.write(f"{name} {values[name]}\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
