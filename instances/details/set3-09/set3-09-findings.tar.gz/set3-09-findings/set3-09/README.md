#  set3-09: multi-layered batch planning structure, strict solution reconstruction and neighborhood experiments

The date of the study: 2026 -09 -08.

The official MIPLIB page: < https://miplib.zib.de/instance_details_set3-09.html >

## Conclusion

This round does not improve the known tolerance feasible objective of MIPLIB, nor does it prove optimal.

-  The objective of MIPLIB ID3 is `176497.15242401615`; it is feasible under the normal MIP tolerance, but direct decimal regression has
163 is a non-zero residual with a maximum of `1.42985145e-11`.
-  After the fixed official 1,424 bit setup pattern and exact reconstruction continuous variables, the decimal-zero objective is obtained.
  `176497.15242568319286826271237029052439100`。
-  item group `1--6` gives a Hamming distance degradation setup mode for 2; after strict reconstruction objective
`176497.15242568249996140149385244688396511988701605000` is the best decimal-zero candidate this round.
but remains approximately `1.66635e-6` worse than MIPLIB ID3.
-  Full model, period window, BOM grouping, Hamming local branching and sibling mode migration have not found a new solution for MIPLIB.

If the output of the solver is only about `1e-6`, the objective must be combined with the 1,424 -bit integer signature and the original MPS Decimal audit judgment.
This directory does not treat floating-point optimization as strict improvement, nor does it treat local neighborhood closures as globally optimal proof.

##  Background and structure

This instance belongs to the Akartunali-Miller family of multi-layer big-bucket lot-sizing tests, which includes backlogging,
List of dependencies and joint family setups. Related contexts can be found here:

-  [MIPLIB set3-09 page ](https://miplib.zib.de/instance_details_set3-09.html)]
- [Akartunali--Miller lower-bound paper](https://optimization-online.org/2007/05/1668/)
-  [PDF document ](https://optimization-online.org/wp-content/uploads/2007/05/1668.pdf)]
-  [Early heuristic paper PDF ](https://optimization-online.org/wp-content/uploads/2006/10/1482.pdf)]

Gurobi 13.0.1 audited the original MPS on euler4 for read only and did not call an optimizer.
[`analysis/gurobi-13.0.1-structure.json`](analysis/gurobi-13.0.1-structure.json)。

|  Project |  Numerical |
| --- | ---: |
| Total number of variables |  4,019  |
| binary setup | 1,424 |
| continuous | 2,595 |
| Linear constraint |  3,747  |
|  nonzero entries |  13,747  |
| items | 78 |
| periods | 16 |

The name of the variable is full decomposition:

- production `x`：1,248 = 78 × 16；
- inventory `s`：1,248；
- item setup `y`：1,248；
- joint-family setup `w`：176 = 11 × 16；
- finished-product backlog `b`：96 = 6 × 16；
- `cost`、`costinv`、`costb`：3。

The constraint includes the 1,248 bar BOM/inventory balance, 1,248 bar production--setup link, 576 bar `y <= w`,
96 article capacity line(6 resource group × 16 period) and 3 article cost identity.
`1--6`、`7--12`、`13--18`、`19--30`、`31--54`、`55--78`。

##  official solution and strict reconstruction

The official ID3 solution is maintained at [`input/set3-09-public.sol.gz` ](input/set3-09-public.sol.gz)].
[`logs/public-solution-exact.log` ](logs/public-solution-exact.log) is given by:

```text
objective                         176497.15242401615
exact nonzero row residuals       163 / 3747
maximum residual                  1.42985145e-11
bound violations                  0
integrality violations            0
```

The RHS vector name of the original MPS is the valid `*RHS*`. Only when `*` is in the first column is the MPS notation; if all the first tokens are removed
If you skip the line beginning with `*`, you will mistake RHS for 0.
`scripts/fixed_rhs_exact_wrapper.py` ](scripts/fixed_rhs_exact_wrapper.py) Modified this parse detail.

The strict reconstruction steps are:

1.  fixed and rounding official 1,424 setup binaries;
2.  A finite minor scale contraction of the upper production in the order BOM of the triangle;
3.  16 period balance exact rolling inventory/backlog;
4.  Exact re-calculation of the three cost auxiliaries;
5.  The original MPS was audited for tolerance 0.

The official model is strict solution for
[`solutions/set3-09-strict-official-pattern.sol`](solutions/set3-09-strict-official-pattern.sol)：

```text
objective                         176497.15242568319286826271237029052439100
exact row violations             0 / 3747
exact bound violations           0
exact integrality violations     0
SHA256                            df1a05b7b14f297c8346aa92df23f3fdc9d2639f3761a975160867d96824ac27
```

Reconstruction reports and independent audits are
[`analysis/strict-reconstruction.json`](analysis/strict-reconstruction.json) and
[`logs/strict-official-pattern-exact.log`](logs/strict-official-pattern-exact.log)。

##  Solve the experiment

Formal solving used COPT 8.0.4 on altman. The current Gurobi 13.0.1 license on euler4 is size-limited,
Models can be read and analyzed, but can't optimize the scale of the instance.

### Full model

|  Run |  Time limit |  Status |  incumbent  |  numerical bound  |  nodes  |
| --- | ---: | --- | ---: | ---: | ---: |
| Coordinated cold start without start |  600 s  |  TIME_LIMIT  |  `415953.5421`  |  `100003.1907`  |  23,453  |
|  official ID3 start |  600 s  |  TIME_LIMIT  |  `176497.15242401595`  |  `96465.19511549911`  |  3,262  |
| Decimal-zero start | 600 s | TIME_LIMIT | `176497.15242401432` | `95928.04286978129` | 3,582 |

The latter two are archived at [`experiments/full-official-start` ](experiments/full-official-start) and
`experiments/full-strict-start` ](experiments/full-strict-start). The first is a synchronized experiment summary, the original run directory is not archived in this instance.
The setup signature of these floating-point incumbents has not changed and cannot be claimed as a new solution based on the numerical endpoints.

###  Four consecutive windows

Windows `[1,4]`, `[3,6]`, `[5,8]`, `[7,10]`, `[9,12]`, `[11,14]`, `[13,16]`
All of them are operated by COPT numerical closure, running time approximately 6.2 - -29.9 seconds. All seven outputs maintain official setup, signed, strict objective, and unimproved.
The full result is `experiments/period-window-*`.

### BOM/item groups

| Freely changing items |  Status |  solver objective | Distance from the official Hamming signature |
| --- | --- | ---: | ---: |
|  `1--6`  |  numerical locally optimal |  `176497.15242401572`  |  2  |
|  `7--12`  |  numerical locally optimal |  `176497.15242401612`  |  0  |
|  `13--18`  |  numerical locally optimal |  `176497.15242401604`  |  4  |
|  `19--30`  |  numerical locally optimal |  `176497.15242401604`  |  8  |
| `31--54` | 120 s TIME_LIMIT | `176497.1524240095` | 0 |
|  `55--78`  |  numerical locally optimal |  `176497.15242401604`  |  0  |

`31--54` seems to be the lowest floating-point objective, but the continuous variables tolerance of the same integer pattern is re-optimized.
`experiments/item-group-*`。

### Hamming local branching

|  Radius |  Status |  Time | Setup mode |  Conclusion |
| ---: | --- | ---: | --- | --- |
|  5  |  COPT numerical locally optimal |  130.7 s  | Signed official | No improvement |
|  15  |  TIME_LIMIT  |  240 s  | Signed official | No improvement |
|  40  |  TIME_LIMIT  |  240 s  | Signed official | No improvement |
|  100  |  TIME_LIMIT  |  240 s  | Signed official | No improvement |

The result of the radius 5 is only local closure in the current floating-point model, not portable proof, nor global proof of the original MIP.
The result is `experiments/lb-r*`.

###  Sibling mode migration

If the setup mode for `set3-10`, `set3-16`, `set3-20` is fixed or migrated to `set3-09` as a start, the resulting objective is significantly worse:

| Source of patterns | Fixed mode objective | 180 s start Search for the best objective |
| --- | ---: | ---: |
| set3-10 | `178276.65493374655` | `178276.65493374612` |
| set3-16 | `196095.5079224431` | `196095.50792244283` |
| set3-20 | `194987.9730363245` | `189649.07909143745` |

Input the sibling solution at [`input` ](input), run the proof at `experiments/sibling*`.

##  Integrated signatures with different patterns

The official model 1,424 -bit signature SHA256 is for:

```text
3f836016368c554d0af1d0cc988756ab91c72fa9058c6e39e397ea0812445216
```

It covers official/strict full start, seven period windows, four local-branching outputs, and item groups.
`7--12`, `31--54`, `55--78`. The objective difference between these outputs of about `1e-6` is therefore not an integer solution improvement.
The following is a complete list of `analysis/pattern-comparison.json` ](analysis/pattern-comparison.json).

Each truly different mode exactify separately, and on the original MPS the tolerance 0 is passed by:

| Source pattern | Hamming distance |  Decimal-zero objective |  solution SHA256  |
| --- | ---: | ---: | --- |
| item `1--6` | 2 | `176497.15242568249996140149385244688396511988701605000` | `f2b6dc7b8ae238d7bdf29bc9f856fc935ec7e277bb892f0e813d43006caea0c9` |
| item `13--18` | 4 | `176497.15242568344943845549562497735873075` | `9eb1110be9d6a487556d5e806b8aa3ff3c0eb633641ab1f1e7ec63e98c57fa5d` |
| item `19--30` | 8 | `176497.15242568344943845549562497735873075` | `4844655316ac23105aa88bf1bc674a5bf1ba4b60f8646f006520da6ae79fe74a` |
| sibling10 fixed | 44 | `178276.6549354508895314841973938144357950` | `f3a955711cc628678642f61020bcec94151436040022b52cbe01fdd612f01a89` |
| sibling16 fixed | 127 | `196095.50792401337005126464600578471897125` | `2e573533bad261f8167d4ef4add3b1fc4de8b35fd59452548d875badc113c0f3` |
| sibling20 fixed | 283 | `194987.9730379513897137943030283800542600` | `76d7408e7e360b72d44ae0059401f4d292c51dc54047b2139716da513aee47b9` |
| sibling20 start | 333 | `189649.0790931343978391824269366201746865846409577400` | `1bbccc92ca6441af4627629e070abe41161e62055eb84bb46287ebf3f3af45b4` |

The corresponding solution is located at [`solutions` ](solutions), reconstruction report is located at `analysis/exactified-patterns`, row by row audit is located at
`logs/exactified-patterns`. `sibling20 start` original output remains approximately `2.2e-12` production when `y=0`;
strict reconstruction first set the production to 0 and then push back all the balance.

## Reproduction

Check the inputs and key hashes:

```sh
sha256sum -c SHA256SUMS
```

The method of verification is strict solution:

```sh
python scripts/fixed_rhs_exact_wrapper.py \
  scripts/exact_mps_solution_check.py \
  input/set3-09.mps.gz \
  solutions/set3-09-strict-official-pattern.sol \
  --tolerance 0
```

The best decimal-zero candidate from the item group `1--6` solver point reconstruction this round:

```sh
python scripts/set3_exactify.py \
  --mps input/set3-09.mps.gz \
  --source experiments/item-group-1_6/incumbent.sol \
  --out reproduced-item-group-1_6.sol \
  --report reproduced-item-group-1_6.json \
  --alphas 0.99999999999999

python scripts/fixed_rhs_exact_wrapper.py \
  scripts/exact_mps_solution_check.py \
  input/set3-09.mps.gz \
  reproduced-item-group-1_6.sol \
  --tolerance 0
```

The expected objective is `176497.15242568249996140149385244688396511988701605000`, and all lines, boundaries and integrality are violated by 0.
