# Package manifest: set3-09

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 124
Excluded source files: 1

## Included files

- `README.md`
- `SHA256SUMS`
- `analysis/exactified-patterns/item-group-13_18/reconstruction.json`
- `analysis/exactified-patterns/item-group-19_30/reconstruction.json`
- `analysis/exactified-patterns/item-group-1_6/reconstruction.json`
- `analysis/exactified-patterns/sibling10-fixed/reconstruction.json`
- `analysis/exactified-patterns/sibling16-fixed/reconstruction.json`
- `analysis/exactified-patterns/sibling20-fixed/reconstruction.json`
- `analysis/exactified-patterns/sibling20-start/reconstruction.json`
- `analysis/gurobi-13.0.1-structure.json`
- `analysis/pattern-comparison.json`
- `analysis/strict-reconstruction.json`
- `experiments/full-official-start/incumbent.sol`
- `experiments/full-official-start/result.json`
- `experiments/full-official-start/solver.log`
- `experiments/full-strict-start/incumbent.sol`
- `experiments/full-strict-start/result.json`
- `experiments/full-strict-start/solver.log`
- `experiments/item-group-13_18/incumbent.sol`
- `experiments/item-group-13_18/result.json`
- `experiments/item-group-13_18/solver.log`
- `experiments/item-group-19_30/incumbent.sol`
- `experiments/item-group-19_30/result.json`
- `experiments/item-group-19_30/solver.log`
- `experiments/item-group-1_6/incumbent.sol`
- `experiments/item-group-1_6/result.json`
- `experiments/item-group-1_6/solver.log`
- `experiments/item-group-31_54/incumbent.sol`
- `experiments/item-group-31_54/result.json`
- `experiments/item-group-31_54/solver.log`
- `experiments/item-group-55_78/incumbent.sol`
- `experiments/item-group-55_78/result.json`
- `experiments/item-group-55_78/solver.log`
- `experiments/item-group-7_12/incumbent.sol`
- `experiments/item-group-7_12/result.json`
- `experiments/item-group-7_12/solver.log`
- `experiments/lb-r100/incumbent.sol`
- `experiments/lb-r100/result.json`
- `experiments/lb-r100/solver.log`
- `experiments/lb-r15/incumbent.sol`
- `experiments/lb-r15/result.json`
- `experiments/lb-r15/solver.log`
- `experiments/lb-r40/incumbent.sol`
- `experiments/lb-r40/result.json`
- `experiments/lb-r40/solver.log`
- `experiments/lb-r5/incumbent.sol`
- `experiments/lb-r5/result.json`
- `experiments/lb-r5/solver.log`
- `experiments/official-pattern-fixed/incumbent.sol`
- `experiments/official-pattern-fixed/result.json`
- `experiments/official-pattern-fixed/solver.log`
- `experiments/period-window-1-4/incumbent.sol`
- `experiments/period-window-1-4/result.json`
- `experiments/period-window-1-4/solver.log`
- `experiments/period-window-11-14/incumbent.sol`
- `experiments/period-window-11-14/result.json`
- `experiments/period-window-11-14/solver.log`
- `experiments/period-window-13-16/incumbent.sol`
- `experiments/period-window-13-16/result.json`
- `experiments/period-window-13-16/solver.log`
- `experiments/period-window-3-6/incumbent.sol`
- `experiments/period-window-3-6/result.json`
- `experiments/period-window-3-6/solver.log`
- `experiments/period-window-5-8/incumbent.sol`
- `experiments/period-window-5-8/result.json`
- `experiments/period-window-5-8/solver.log`
- `experiments/period-window-7-10/incumbent.sol`
- `experiments/period-window-7-10/result.json`
- `experiments/period-window-7-10/solver.log`
- `experiments/period-window-9-12/incumbent.sol`
- `experiments/period-window-9-12/result.json`
- `experiments/period-window-9-12/solver.log`
- `experiments/sibling10-fixed/incumbent.sol`
- `experiments/sibling10-fixed/result.json`
- `experiments/sibling10-fixed/solver.log`
- `experiments/sibling10-start/incumbent.sol`
- `experiments/sibling10-start/result.json`
- `experiments/sibling10-start/solver.log`
- `experiments/sibling16-fixed/incumbent.sol`
- `experiments/sibling16-fixed/result.json`
- `experiments/sibling16-fixed/solver.log`
- `experiments/sibling16-start/incumbent.sol`
- `experiments/sibling16-start/result.json`
- `experiments/sibling16-start/solver.log`
- `experiments/sibling20-fixed/incumbent.sol`
- `experiments/sibling20-fixed/result.json`
- `experiments/sibling20-fixed/solver.log`
- `experiments/sibling20-start/incumbent.sol`
- `experiments/sibling20-start/result.json`
- `experiments/sibling20-start/solver.log`
- `input/set3-09-public.sol.gz`
- `input/set3-10-public.sol.gz`
- `input/set3-16-public.sol.gz`
- `input/set3-20-public.sol.gz`
- `logs/exactified-patterns/item-group-13_18.exact.log`
- `logs/exactified-patterns/item-group-19_30.exact.log`
- `logs/exactified-patterns/item-group-1_6.exact.log`
- `logs/exactified-patterns/sibling10-fixed.exact.log`
- `logs/exactified-patterns/sibling16-fixed.exact.log`
- `logs/exactified-patterns/sibling20-fixed.exact.log`
- `logs/exactified-patterns/sibling20-start.exact.log`
- `logs/gurobi-13.0.1-structure.log`
- `logs/official-pattern-fixed-copt-exact.log`
- `logs/pattern-comparison.log`
- `logs/public-solution-exact.log`
- `logs/strict-official-pattern-exact.log`
- `logs/strict-reconstruction.log`
- `scripts/compare_set3_patterns.py`
- `scripts/copt_structured_search.py`
- `scripts/exact_mps_solution_check.py`
- `scripts/fixed_rhs_exact_wrapper.py`
- `scripts/gurobi_structure_export.py`
- `scripts/run_set3_exactify_patterns.sh`
- `scripts/run_set3_siblings.sh`
- `scripts/run_set3_windows.sh`
- `scripts/set3_exactify.py`
- `solutions/set3-09-strict-item-group-13_18.sol`
- `solutions/set3-09-strict-item-group-19_30.sol`
- `solutions/set3-09-strict-item-group-1_6.sol`
- `solutions/set3-09-strict-official-pattern.sol`
- `solutions/set3-09-strict-sibling10-fixed.sol`
- `solutions/set3-09-strict-sibling16-fixed.sol`
- `solutions/set3-09-strict-sibling20-fixed.sol`
- `solutions/set3-09-strict-sibling20-start.sol`

## Excluded files

- `input/set3-09.mps.gz (75702 bytes; raw benchmark input; sha256 e33898791dd888af8a025d438ec1fb7a7bb6c5f3aaf847ea5d234a2fed0bb631)`
