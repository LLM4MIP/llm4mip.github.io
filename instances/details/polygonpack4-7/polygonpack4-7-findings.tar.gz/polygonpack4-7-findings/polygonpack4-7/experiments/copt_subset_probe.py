#!/usr/bin/env python3
"""Solve one exact object-subset layer of polygonpack4-7 with COPT (CPU).

The seven-bit mask fixes presence/absence only.  Orientations, no-fit-region
choices and placements remain decision variables.  A feasible result is replayed
later against the original MPS; a time-limit result is never an infeasibility
certificate.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import coptpy as cp
from coptpy import COPT


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("mask", help="seven characters in object order, e.g. 1111000")
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--seconds", type=float, default=60.0)
    parser.add_argument("--threads", type=int, default=32)
    parser.add_argument("--feasibility-only", action="store_true")
    args = parser.parse_args()
    if len(args.mask) != 7 or any(bit not in "01" for bit in args.mask):
        raise ValueError("mask must contain exactly seven 0/1 characters")
    args.outdir.mkdir(parents=True, exist_ok=True)

    model = cp.Envr().createModel(f"polygonpack4-7-subset-{args.mask}")
    model.read(str(args.mps))
    variables = model.getVars().getAll()
    orientation_groups = [variables[14 + 4 * i : 18 + 4 * i] for i in range(7)]
    for i, (bit, group) in enumerate(zip(args.mask, orientation_groups)):
        if bit == "1":
            model.addConstr(cp.quicksum(group) == 1, name=f"force_object_{i}_selected")
        else:
            for variable in group:
                variable.setInfo(COPT.Info.LB, 0.0)
                variable.setInfo(COPT.Info.UB, 0.0)

    if args.feasibility_only:
        model.setObjective(0.0)
    model.setParam(COPT.Param.Logging, 1)
    model.setLogFile(str(args.outdir / "copt.log"))
    model.setParam(COPT.Param.Threads, args.threads)
    model.setParam(COPT.Param.TimeLimit, args.seconds)
    model.setParam(COPT.Param.RelGap, 0.0)
    try:
        model.setParam(COPT.Param.FeasTol, 1e-9)
    except Exception:
        pass
    model.solve()
    result = {
        "mask": args.mask,
        "selected_objects": [i for i, bit in enumerate(args.mask) if bit == "1"],
        "time_limit_seconds": args.seconds,
        "threads": args.threads,
        "cpu_only": True,
        "feasibility_only": args.feasibility_only,
        "status": int(model.status),
        "has_solution": int(model.hasmipsol),
        "proof_scope": "fixed presence mask; orientations/slices/placements free",
    }
    for key, attr in (
        ("objective", "objval"),
        ("best_bound", "bestbnd"),
        ("relative_gap", "mipgap"),
        ("node_count", "nodecnt"),
        ("runtime", "solvingtime"),
    ):
        try:
            result[key] = float(getattr(model, attr))
        except Exception:
            pass
    if model.hasmipsol:
        model.writeSol(str(args.outdir / "incumbent.sol"))
    (args.outdir / "summary.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print("RESULT_JSON=" + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
