#!/usr/bin/env python3
"""Optimize and robustify the 14-D placement LP for a fixed discrete layout.

The input MPS is read by Gurobi, but a fresh model containing only the original
continuous variables is constructed after substituting rounded integer values.
This keeps the solve within a restricted Gurobi license and, more importantly,
separates a combinatorial layout from its numerical placement.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def read_values(path: Path) -> dict[str, float]:
    values: dict[str, float] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        fields = raw.split()
        if len(fields) < 2 or fields[0].startswith(("#", "=")):
            continue
        try:
            values[fields[0]] = float(fields[1])
        except ValueError:
            pass
    return values


def reduced_model(
    original: gp.Model,
    fixed: dict[str, int],
    with_margin: bool,
    coordinate_cutoff: float | None = None,
) -> tuple[gp.Model, dict[str, gp.Var], gp.Var | None, list[dict]]:
    model = gp.Model("polygonpack4-7-fixed-placement")
    model.Params.OutputFlag = 1
    continuous = [v for v in original.getVars() if v.VType == GRB.CONTINUOUS]
    y = {
        v.VarName: model.addVar(
            lb=v.LB if v.LB > -GRB.INFINITY else -GRB.INFINITY,
            ub=v.UB if v.UB < GRB.INFINITY else GRB.INFINITY,
            name=v.VarName,
        )
        for v in continuous
    }
    margin = model.addVar(lb=0.0, name="uniform_margin") if with_margin else None
    integer_only_checks: list[dict] = []
    for con in original.getConstrs():
        row = original.getRow(con)
        expr = gp.LinExpr()
        fixed_activity = 0.0
        continuous_nnz = 0
        for k in range(row.size()):
            var = row.getVar(k)
            coeff = row.getCoeff(k)
            if var.VarName in y:
                expr.add(y[var.VarName], coeff)
                continuous_nnz += 1
            else:
                fixed_activity += coeff * fixed[var.VarName]
        adjusted_rhs = con.RHS - fixed_activity
        if continuous_nnz == 0:
            if con.Sense == GRB.LESS_EQUAL:
                violation = max(0.0, -adjusted_rhs)
            elif con.Sense == GRB.GREATER_EQUAL:
                violation = max(0.0, adjusted_rhs)
            else:
                violation = abs(adjusted_rhs)
            if violation > 1e-9:
                integer_only_checks.append(
                    {"row": con.ConstrName, "adjusted_rhs": adjusted_rhs, "violation": violation}
                )
            continue
        if con.Sense == GRB.LESS_EQUAL:
            if margin is not None:
                expr.add(margin, 1.0)
            model.addConstr(expr <= adjusted_rhs, name=con.ConstrName)
        elif con.Sense == GRB.GREATER_EQUAL:
            if margin is not None:
                expr.add(margin, -1.0)
            model.addConstr(expr >= adjusted_rhs, name=con.ConstrName)
        else:
            # There are no equality rows in this instance, but keep the script
            # honest if the source file changes.
            model.addConstr(expr == adjusted_rhs, name=con.ConstrName)

    coordinate_objective = gp.quicksum(v.Obj * y[v.VarName] for v in continuous)
    if coordinate_cutoff is not None:
        model.addConstr(coordinate_objective <= coordinate_cutoff, name="coordinate_objective_cutoff")
    if margin is None:
        model.setObjective(coordinate_objective, GRB.MINIMIZE)
    else:
        model.setObjective(margin, GRB.MAXIMIZE)
    model.update()
    return model, y, margin, integer_only_checks


def write_solution(
    path: Path,
    original: gp.Model,
    fixed: dict[str, int],
    coordinates: dict[str, float],
    claimed_objective: float,
) -> None:
    lines = [f"# fixed-layout robust placement; floating solve objective {claimed_objective:.17g}"]
    lines.append(f"=obj= {claimed_objective:.17g}")
    for var in original.getVars():
        value = coordinates[var.VarName] if var.VarName in coordinates else fixed[var.VarName]
        if value != 0:
            lines.append(f"{var.VarName} {value:.17g}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("pattern_solution", type=Path)
    parser.add_argument("output_solution", type=Path)
    parser.add_argument("output_json", type=Path)
    parser.add_argument("--objective-slack", type=float, default=1e-3)
    args = parser.parse_args()

    original = gp.read(str(args.mps))
    supplied = read_values(args.pattern_solution)
    fixed: dict[str, int] = {}
    for var in original.getVars():
        if var.VType != GRB.CONTINUOUS:
            fixed[var.VarName] = int(round(supplied.get(var.VarName, 0.0)))
    binary_constant = sum(v.Obj * fixed[v.VarName] for v in original.getVars() if v.VarName in fixed)

    phase1, y1, _, bad_integer_rows = reduced_model(original, fixed, False)
    phase1.Params.Method = 1
    phase1.optimize()
    if phase1.Status != GRB.OPTIMAL:
        raise RuntimeError(f"fixed placement phase 1 status {phase1.Status}")
    coordinate_optimum = phase1.ObjVal

    cutoff = coordinate_optimum + args.objective_slack
    phase2, y2, margin, bad_integer_rows2 = reduced_model(original, fixed, True, cutoff)
    phase2.Params.Method = 1
    phase2.optimize()
    if phase2.Status != GRB.OPTIMAL:
        raise RuntimeError(f"fixed placement phase 2 status {phase2.Status}")
    assert margin is not None
    coordinates = {name: var.X for name, var in y2.items()}
    full_objective = binary_constant + sum(
        v.Obj * coordinates[v.VarName]
        for v in original.getVars()
        if v.VarName in coordinates
    )
    write_solution(args.output_solution, original, fixed, coordinates, full_objective)

    selected_orientations = [
        v.VarName
        for v in original.getVars()[14:42]
        if fixed.get(v.VarName, 0) == 1
    ]
    result = {
        "source_pattern": str(args.pattern_solution),
        "continuous_variables": len(y1),
        "fixed_integer_variables": len(fixed),
        "integer_only_violations_phase1": bad_integer_rows,
        "integer_only_violations_phase2": bad_integer_rows2,
        "selected_orientation_variables": selected_orientations,
        "binary_objective_constant": binary_constant,
        "coordinate_objective_minimum": coordinate_optimum,
        "coordinate_objective_cutoff": cutoff,
        "robust_coordinate_objective": full_objective - binary_constant,
        "full_objective": full_objective,
        "uniform_margin": margin.X,
        "coordinates": coordinates,
        "gurobi_version": list(gp.gurobi.version()),
        "note": "Uniform margin applies to every substituted row containing a continuous variable; final authority is exact Decimal replay on original MPS.",
    }
    args.output_json.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
