#!/usr/bin/env python3
"""Account for every objective-screen survivor through a direct COPT run."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def solver_log_for(summary_path: Path, summary: dict, instance_root: Path) -> Path:
    sibling = summary_path.with_name("copt.log")
    if sibling.exists():
        return sibling
    seconds = int(summary["time_limit_seconds"])
    fallback = instance_root / "logs" / f"subset-{summary['mask']}-{seconds}s.log"
    if fallback.exists():
        return fallback
    raise FileNotFoundError(f"no solver log found for {summary_path}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("screen", type=Path)
    parser.add_argument("symmetry_audit", type=Path)
    parser.add_argument("candidate_audit", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("experiments", nargs="+", help="MASK=SUMMARY_JSON")
    parser.add_argument("--orientation-summary", type=Path)
    args = parser.parse_args()

    screen = json.loads(args.screen.read_text(encoding="utf-8"))
    symmetry = json.loads(args.symmetry_audit.read_text(encoding="utf-8"))
    candidate_audit = json.loads(args.candidate_audit.read_text(encoding="utf-8"))
    summaries = {}
    summary_paths = {}
    for item in args.experiments:
        mask, separator, raw_path = item.partition("=")
        if not separator:
            raise ValueError(f"experiment must be MASK=PATH: {item}")
        path = Path(raw_path)
        summary = json.loads(path.read_text(encoding="utf-8"))
        if summary["mask"] != mask:
            raise ValueError(f"mask mismatch for {path}")
        if mask in summaries:
            raise ValueError(f"duplicate experiment for mask {mask}")
        summaries[mask] = summary
        summary_paths[mask] = path

    screen_masks = set(screen["strict_improvement_candidate_masks"])
    if screen_masks != set(summaries):
        raise ValueError(
            f"direct experiments must exactly cover screen survivors: "
            f"missing={sorted(screen_masks - set(summaries))}, "
            f"extra={sorted(set(summaries) - screen_masks)}"
        )
    lower_bound_by_mask = {
        record["mask"]: record["objective_lower_bound"]
        for record in screen["all_128_masks"]
    }
    exact_audit_by_label = {
        record["label"]: record for record in candidate_audit["candidates"]
    }
    strict_incumbent = exact_audit_by_label["strict-zero-tolerance-repair"]
    copt_current_audit = exact_audit_by_label["copt-mask-1111000-300s"]
    instance_root = args.output.parent.parent

    direct_results = []
    for mask in sorted(screen_masks):
        summary = summaries[mask]
        summary_path = summary_paths[mask]
        solver_log = solver_log_for(summary_path, summary, instance_root)
        status = summary["status"]
        has_solution = bool(summary["has_solution"])
        if status == 8 and has_solution:
            disposition = "TIME_LIMIT_WITH_FLOATING_INCUMBENT_NO_STRICT_IMPROVEMENT"
        elif status == 8:
            disposition = "TIME_LIMIT_NO_FEASIBLE_SOLUTION_FOUND"
        else:
            disposition = f"COPT_STATUS_{status}"
        record = {
            "mask": mask,
            "objective_only_lower_bound": lower_bound_by_mask[mask],
            "experiment_summary": summary_path.as_posix(),
            "experiment_summary_sha256": sha256(summary_path),
            "solver_log": solver_log.as_posix(),
            "solver_log_sha256": sha256(solver_log),
            "time_limit_seconds": summary["time_limit_seconds"],
            "runtime_seconds": summary.get("runtime"),
            "threads": summary["threads"],
            "cpu_only": summary["cpu_only"],
            "feasibility_only": summary.get("feasibility_only", False),
            "node_count": summary.get("node_count"),
            "copt_status": status,
            "has_floating_solution": has_solution,
            "floating_objective": summary.get("objective") if has_solution else None,
            "floating_best_bound": (
                None if summary.get("feasibility_only", False) else summary.get("best_bound")
            ),
            "disposition": disposition,
            "independent_infeasibility_or_optimality_certificate": False,
        }
        if mask == "1111000":
            record["floating_incumbent_exact_decimal_replay"] = {
                key: copt_current_audit[key]
                for key in (
                    "solution", "solution_sha256", "literal_objective", "strict_mps_feasible",
                    "row_violation_count", "minimum_positive_row_violation",
                    "maximum_row_violation", "gap_to_miplib_headline_positive_is_worse",
                )
            }
        direct_results.append(record)

    orientation_detail = None
    if args.orientation_summary:
        detail = json.loads(args.orientation_summary.read_text(encoding="utf-8"))
        orientation_detail = {
            "path": args.orientation_summary.as_posix(),
            "sha256": sha256(args.orientation_summary),
            **{
                key: detail[key]
                for key in (
                    "mask", "expected_orientation_leaf_count", "observed_orientation_leaf_count",
                    "all_orientation_leaves_visited_exactly_once", "feasible_leaf_count",
                    "solver_infeasible_leaf_count", "timeout_or_other_unresolved_leaf_count",
                )
            },
        }

    output = {
        "objective_screen_survivor_count": len(screen_masks),
        "all_survivors_have_direct_runs": len(direct_results) == len(screen_masks),
        "direct_run_count": len(direct_results),
        "strict_improvement_found": False,
        "masks_closed_by_independent_proof": 0,
        "all_surviving_masks_remain_proof_open": True,
        "strict_incumbent_objective": strict_incumbent["literal_objective"],
        "strict_incumbent_gap_to_miplib_headline_positive_is_worse": strict_incumbent[
            "gap_to_miplib_headline_positive_is_worse"
        ],
        "direct_mask_results": direct_results,
        "status_counts": {
            "time_limit": sum(record["copt_status"] == 8 for record in direct_results),
            "time_limit_no_feasible_solution_found": sum(
                record["disposition"] == "TIME_LIMIT_NO_FEASIBLE_SOLUTION_FOUND"
                for record in direct_results
            ),
            "time_limit_with_floating_incumbent": sum(
                record["has_floating_solution"] for record in direct_results
            ),
        },
        "copy_symmetry_audit": {
            "path": args.symmetry_audit.as_posix(),
            "sha256": sha256(args.symmetry_audit),
            "same_order_copy_checks_passed": symmetry["same_order_copy_checks_passed"],
            "simple_extended_mps_permutation_certified": symmetry[
                "exact_copy_permutation_symmetry_certified"
            ],
            "within_family_endpoint_reversal_failed_count": symmetry[
                "within_family_endpoint_reversal_failed_count"
            ],
            "family_count_group_count": symmetry["family_count_group_count"],
            "family_count_groups_not_used_to_extrapolate_results": True,
        },
        "orientation_detail_1111001": orientation_detail,
        "conclusion": (
            "Every one of the 19 objective-screen survivors has its own direct COPT run; no "
            "result is extrapolated through copy symmetry. All 19 runs ended at status 8 (time "
            "limit). The 1111000 run returned the known floating incumbent but did not improve "
            "the strict repaired point; the other 18 runs found no feasible point. No timeout is "
            "an infeasibility or optimality proof, so all 19 masks remain proof-open."
        ),
        "evidence_boundary": (
            "Exact statements are the objective-only screen and Decimal MPS replay. The copy "
            "audit disproves only a simple slice-variable permutation automorphism; it neither "
            "proves nor disproves projected geometric symmetry. COPT outcomes are floating-solver "
            "evidence only."
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(output, indent=2, sort_keys=True) + "\n")
    print(json.dumps({key: output[key] for key in (
        "objective_screen_survivor_count", "all_survivors_have_direct_runs",
        "direct_run_count", "strict_improvement_found",
        "masks_closed_by_independent_proof", "all_surviving_masks_remain_proof_open",
    )}, indent=2))


if __name__ == "__main__":
    main()
