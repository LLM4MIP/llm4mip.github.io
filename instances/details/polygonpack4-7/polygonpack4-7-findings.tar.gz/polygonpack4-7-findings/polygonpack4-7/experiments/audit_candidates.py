#!/usr/bin/env python3
"""Build a compact exact-Decimal audit of every retained candidate solution.

This is intentionally separate from solver feasibility tolerances.  A candidate
is called ``strict_mps_feasible`` only when every original row, bound, and
integrality condition is satisfied by the literal decimal strings in the MPS
and solution file.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from decimal import Decimal, getcontext
from pathlib import Path

from recover_geometry import exact_slack, read_mps, read_solution


getcontext().prec = 80
ZERO = Decimal(0)
MIPLIB_HEADLINE = Decimal("-51837758.96241999")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def audit(model: dict, solution: Path) -> dict:
    values = read_solution(solution)
    objective = sum(
        model["objective"].get(variable, ZERO) * values.get(variable, ZERO)
        for variable in model["variables"]
    )
    row_violations = []
    for row, kind in model["row_types"].items():
        if kind == "N":
            continue
        lhs = sum(
            coefficient * values.get(variable, ZERO)
            for variable, coefficient in model["rows"][row]
        )
        rhs = model["rhs"].get(row, ZERO)
        _slack, violation = exact_slack(kind, lhs, rhs)
        if violation:
            row_violations.append((violation, row, lhs, rhs, kind))
    row_violations.sort(reverse=True)

    bound_violations = []
    integrality_violations = []
    for variable in model["variables"]:
        value = values.get(variable, ZERO)
        lower = model["lower"][variable]
        upper = model["upper"][variable]
        violation = max(ZERO, lower - value)
        if upper is not None:
            violation = max(violation, value - upper)
        if violation:
            bound_violations.append((violation, variable, value, lower, upper))
        if variable in model["integer_variables"]:
            violation = abs(value - value.to_integral_value())
            if violation:
                integrality_violations.append((violation, variable, value))
    bound_violations.sort(reverse=True)
    integrality_violations.sort(reverse=True)

    strict = not row_violations and not bound_violations and not integrality_violations
    reasons = []
    if row_violations:
        reasons.append("exact row residual")
    if bound_violations:
        reasons.append("exact bound residual")
    if integrality_violations:
        reasons.append("fractional integer column")
    if strict and objective >= MIPLIB_HEADLINE:
        reasons.append("strictly feasible but does not beat MIPLIB headline")
    if strict and objective < MIPLIB_HEADLINE:
        reasons.append("strict incumbent improvement")

    def row_record(item: tuple) -> dict:
        violation, row, lhs, rhs, kind = item
        return {
            "row": row,
            "sense": kind,
            "lhs": str(lhs),
            "rhs": str(rhs),
            "violation": str(violation),
        }

    return {
        "solution": solution.as_posix(),
        "solution_sha256": sha256(solution),
        "literal_objective": str(objective),
        "gap_to_miplib_headline_positive_is_worse": str(objective - MIPLIB_HEADLINE),
        "strict_mps_feasible": strict,
        "disposition": reasons,
        "row_violation_count": len(row_violations),
        "minimum_positive_row_violation": (
            str(min(item[0] for item in row_violations)) if row_violations else "0"
        ),
        "maximum_row_violation": str(row_violations[0][0]) if row_violations else "0",
        "worst_rows": [row_record(item) for item in row_violations[:10]],
        "bound_violation_count": len(bound_violations),
        "minimum_positive_bound_violation": (
            str(min(item[0] for item in bound_violations)) if bound_violations else "0"
        ),
        "maximum_bound_violation": str(bound_violations[0][0]) if bound_violations else "0",
        "integrality_violation_count": len(integrality_violations),
        "minimum_positive_integrality_violation": (
            str(min(item[0] for item in integrality_violations))
            if integrality_violations else "0"
        ),
        "maximum_integrality_violation": (
            str(integrality_violations[0][0]) if integrality_violations else "0"
        ),
        "fractional_integer_columns": [
            {"column": variable, "value": str(value), "violation": str(violation)}
            for violation, variable, value in integrality_violations[:20]
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("candidates", nargs="+", help="LABEL=PATH")
    args = parser.parse_args()

    model = read_mps(args.mps)
    results = []
    for candidate in args.candidates:
        label, separator, raw_path = candidate.partition("=")
        if not separator:
            raise ValueError(f"candidate must be LABEL=PATH: {candidate}")
        record = audit(model, Path(raw_path))
        record["label"] = label
        results.append(record)

    output = {
        "input": args.mps.as_posix(),
        "input_sha256": sha256(args.mps),
        "miplib_headline_objective": str(MIPLIB_HEADLINE),
        "comparison_rule": (
            "minimization: a negative gap is a strict objective improvement, but only when "
            "strict_mps_feasible is true"
        ),
        "candidates": results,
        "evidence_boundary": (
            "All arithmetic uses the literal finite decimals in the submitted MPS and solution files. "
            "This proves or refutes exact feasibility for that decimal MPS, not for unavailable "
            "pre-MPS polygon vertices."
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(output, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
