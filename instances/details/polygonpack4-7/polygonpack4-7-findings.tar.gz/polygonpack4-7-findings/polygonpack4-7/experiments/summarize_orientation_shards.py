#!/usr/bin/env python3
"""Merge and sanity-check sharded orientation-enumeration summaries."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("summaries", nargs="+", type=Path)
    args = parser.parse_args()
    shards = [json.loads(path.read_text(encoding="utf-8")) for path in args.summaries]
    masks = {shard["mask"] for shard in shards}
    if len(masks) != 1:
        raise ValueError(f"mixed masks: {masks}")
    mask = next(iter(masks))
    selected_count = mask.count("1")
    expected_total = 4 ** selected_count
    records = [record for shard in shards for record in shard["records"]]
    leaf_ids = [record["leaf"] for record in records]
    if len(set(leaf_ids)) != len(leaf_ids):
        raise ValueError("duplicate leaf ids across shards")
    complete = sorted(leaf_ids) == list(range(expected_total))
    status_note = shards[0]["status_code_note"]
    infeasible_status = status_note["infeasible"]
    optimal_status = status_note["optimal"]
    output = {
        "mask": mask,
        "selected_count": selected_count,
        "expected_orientation_leaf_count": expected_total,
        "observed_orientation_leaf_count": len(records),
        "all_orientation_leaves_visited_exactly_once": complete,
        "feasible_leaf_count": sum(record["has_solution"] for record in records),
        "solver_infeasible_leaf_count": sum(
            record["status"] == infeasible_status for record in records
        ),
        "solver_optimal_leaf_count": sum(
            record["status"] == optimal_status for record in records
        ),
        "timeout_or_other_unresolved_leaf_count": sum(
            record["status"] not in (infeasible_status, optimal_status) for record in records
        ),
        "unresolved_leaf_ids": [
            record["leaf"]
            for record in records
            if record["status"] not in (infeasible_status, optimal_status)
        ],
        "shards": [
            {
                "path": path.as_posix(),
                "sha256": sha256(path),
                "shard_index": shard["shard_index"],
                "shard_count": shard["shard_count"],
                "leaf_count": shard["leaf_count"],
                "solver_infeasible_leaf_count": shard["infeasible_leaf_count"],
                "unresolved_leaf_count": shard["unresolved_leaf_count"],
                "feasible_leaf_count": shard["feasible_leaf_count"],
                "per_leaf_seconds": shard["per_leaf_seconds"],
                "threads_per_leaf": shard["threads_per_leaf"],
            }
            for path, shard in zip(args.summaries, shards)
        ],
        "conclusion": (
            "No feasible orientation was found in the visited leaves. Solver-infeasible statuses "
            "are COPT floating-solver evidence; unresolved leaves are explicit timeouts. This is "
            "not an independently checkable infeasibility proof."
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(output, indent=2, sort_keys=True) + "\n")
    print(json.dumps({key: output[key] for key in (
        "mask", "expected_orientation_leaf_count", "observed_orientation_leaf_count",
        "all_orientation_leaves_visited_exactly_once", "feasible_leaf_count",
        "solver_infeasible_leaf_count", "timeout_or_other_unresolved_leaf_count",
    )}, indent=2))


if __name__ == "__main__":
    main()
