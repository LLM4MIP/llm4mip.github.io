#!/usr/bin/env python3
"""Certify exact copy symmetries directly from the decimal MPS.

The proof compares object data and every full big-M/active no-fit slice as a
multiset of normalized rational halfspaces.  It also checks endpoint reversal
inside each copy family.  Slice numbers and row order are ignored; no
floating-point comparison is used.
"""

from __future__ import annotations

import argparse
import collections
import hashlib
import itertools
import json
import math
from fractions import Fraction
from pathlib import Path

from recover_geometry import CHOICE_RE, NONOVERLAP_RE, read_mps


FAMILIES = ((0, 1), (2, 3), (4, 5, 6))
FAMILY_BY_OBJECT = {obj: family for family, group in enumerate(FAMILIES) for obj in group}


def primitive(values: tuple[Fraction, ...]) -> tuple[int, ...]:
    denominator = math.lcm(*(value.denominator for value in values))
    integers = [value.numerator * (denominator // value.denominator) for value in values]
    divisor = math.gcd(*[abs(value) for value in integers if value])
    return tuple(value // divisor for value in integers)


def reverse_pair_signature(signature: tuple) -> tuple:
    """Relabel a canonical (u, v) slice signature after endpoints are swapped."""
    reversed_slices = []
    for slice_rows in signature:
        reversed_rows = []
        for full, active in slice_rows:
            reversed_rows.append((
                (-full[0], -full[1], full[2], full[3]),
                (-active[0], -active[1], active[2]),
            ))
        reversed_slices.append(tuple(sorted(reversed_rows)))
    return tuple(sorted(reversed_slices))


def object_signature(model: dict, obj: int) -> tuple:
    x, y = f"C{2 * obj:07d}", f"C{2 * obj + 1:07d}"
    orientation = [f"C{14 + 4 * obj + rotation:07d}" for rotation in range(4)]
    containment = []
    for axis in "xy":
        for suffix in ("", "_low"):
            row = f"{axis}{obj}_contenimento{suffix}"
            terms = dict(model["rows"][row])
            coordinate = x if axis == "x" else y
            containment.append((
                model["row_types"][row],
                model["rhs"].get(row, 0),
                terms[coordinate],
                tuple(terms[var] for var in orientation),
            ))
    cardinality = []
    for suffix in ("", "_low"):
        row = f"n{obj}_only_one_rotation{suffix}"
        terms = dict(model["rows"][row])
        cardinality.append((
            model["row_types"][row],
            model["rhs"].get(row, 0),
            tuple(terms[var] for var in orientation),
        ))
    return (
        model["objective"].get(x, 0),
        model["objective"].get(y, 0),
        tuple(model["objective"].get(var, 0) for var in orientation),
        (model["lower"][x], model["upper"][x]),
        (model["lower"][y], model["upper"][y]),
        tuple((model["lower"][var], model["upper"][var]) for var in orientation),
        tuple(containment),
        tuple(cardinality),
    )


def nofit_signatures(model: dict) -> tuple[dict, list[str], dict]:
    # actual-pair -> canonical family/rotation key -> slice -> halfspaces
    raw: dict[tuple, dict[int, list[tuple[int, ...]]]] = collections.defaultdict(
        lambda: collections.defaultdict(list)
    )
    errors = []
    delta_by_key = {}
    for row, terms_list in model["rows"].items():
        match = NONOVERLAP_RE.match(row)
        if not match:
            continue
        if model["row_types"][row] != "L":
            errors.append(f"non-L no-fit row: {row}")
            continue
        i, ri, j, rj, slice_index = (
            int(match.group(key)) for key in ("i", "ri", "j", "rj", "s")
        )
        family_i, family_j = FAMILY_BY_OBJECT[i], FAMILY_BY_OBJECT[j]
        # Canonical endpoint order: family, then object index.
        if (family_i, i) < (family_j, j):
            u, ru, v, rv, sign = i, ri, j, rj, 1
        else:
            u, ru, v, rv, sign = j, rj, i, ri, -1
        terms = dict(terms_list)
        xu, yu = f"C{2 * u:07d}", f"C{2 * u + 1:07d}"
        xv, yv = f"C{2 * v:07d}", f"C{2 * v + 1:07d}"
        if terms.get(xu, 0) + terms.get(xv, 0) != 0:
            errors.append(f"x coefficients do not cancel: {row}")
        if terms.get(yu, 0) + terms.get(yv, 0) != 0:
            errors.append(f"y coefficients do not cancel: {row}")
        integer_terms = [
            (variable, coefficient)
            for variable, coefficient in terms_list
            if variable in model["integer_variables"]
        ]
        if len(integer_terms) != 1:
            errors.append(f"expected one slice variable: {row}")
            continue
        _delta, delta_coefficient = integer_terms[0]
        raw_key = (i, ri, j, rj, slice_index)
        if raw_key in delta_by_key and delta_by_key[raw_key] != _delta:
            errors.append(f"inconsistent slice variable for {raw_key}")
        delta_by_key[raw_key] = _delta
        # The row is a*(p_i-p_j) + M*delta <= rhs.  At delta=1,
        # canonical a*(p_u-p_v) <= rhs-M.
        a = Fraction(terms.get(xu, 0))
        b = Fraction(terms.get(yu, 0))
        c = Fraction(model["rhs"].get(row, 0) - delta_coefficient)
        # `sign` is retained as an internal consistency check: when u is j,
        # the coefficients read from u have already changed sign.
        del sign
        # Preserve both the full big-M row (exact MPS automorphism) and its
        # delta=1 restriction (active no-fit geometry).
        normalized = (
            primitive((a, b, Fraction(delta_coefficient), Fraction(model["rhs"].get(row, 0)))),
            primitive((a, b, c)),
        )
        key = ((u, v), (FAMILY_BY_OBJECT[u], FAMILY_BY_OBJECT[v]), (ru, rv))
        raw[key][slice_index].append(normalized)

    signatures = {}
    for key, slices in raw.items():
        signatures[key] = tuple(sorted(tuple(sorted(rows)) for rows in slices.values()))
    orientation_variables = {
        f"C{14 + 4 * obj + rotation:07d}"
        for obj in range(7)
        for rotation in range(4)
    }
    choice_count = 0
    for row, terms_list in model["rows"].items():
        match = CHOICE_RE.match(row)
        if not match:
            continue
        choice_count += 1
        i, ri, j, rj = (int(match.group(key)) for key in ("i", "ri", "j", "rj"))
        expected_orientations = {
            f"C{14 + 4 * i + ri:07d}",
            f"C{14 + 4 * j + rj:07d}",
        }
        expected_deltas = {
            delta
            for (ii, rii, jj, rjj, _slice), delta in delta_by_key.items()
            if (ii, rii, jj, rjj) == (i, ri, j, rj)
        }
        terms = dict(terms_list)
        actual_orientations = set(terms) & orientation_variables
        actual_deltas = set(terms) - orientation_variables
        if model["row_types"][row] != "L" or model["rhs"].get(row, 0) != 1:
            errors.append(f"unexpected slice-choice sense/rhs: {row}")
        if actual_orientations != expected_orientations:
            errors.append(f"unexpected orientation terms in choice row: {row}")
        if actual_deltas != expected_deltas:
            errors.append(f"unexpected slice terms in choice row: {row}")
        if any(terms[var] != 1 for var in actual_orientations):
            errors.append(f"non-unit orientation coefficient in choice row: {row}")
        if any(terms[var] != -1 for var in actual_deltas):
            errors.append(f"non-minus-one slice coefficient in choice row: {row}")
    expected_choice_count = math.comb(7, 2) * 4 * 4
    if choice_count != expected_choice_count:
        errors.append(f"expected {expected_choice_count} slice-choice rows, got {choice_count}")
    slice_bound_errors = [
        variable
        for variable in model["integer_variables"] - orientation_variables
        if model["lower"][variable] != 0 or model["upper"][variable] != 1
    ]
    if slice_bound_errors:
        errors.append(f"non-binary slice bounds: {slice_bound_errors[:10]}")
    choice_check = {
        "observed_choice_rows": choice_count,
        "expected_choice_rows": expected_choice_count,
        "all_choice_rows_have_exact_expected_form": not any(
            "choice row" in error or "slice-choice" in error for error in errors
        ),
        "all_slice_variables_have_exact_0_1_bounds": not slice_bound_errors,
    }
    return signatures, errors, choice_check


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--screen", type=Path)
    args = parser.parse_args()
    model = read_mps(args.mps)

    object_checks = []
    object_ok = True
    for group in FAMILIES:
        signatures = [object_signature(model, obj) for obj in group]
        equal = all(signature == signatures[0] for signature in signatures[1:])
        object_ok &= equal
        object_checks.append({"objects": list(group), "exactly_equal": equal})

    signatures, errors, choice_check = nofit_signatures(model)
    grouped: dict[tuple, list[tuple]] = collections.defaultdict(list)
    for (pair, families, rotations), signature in signatures.items():
        grouped[(families, rotations)].append((pair, signature))
    pair_checks = []
    pair_ok = True
    family_pair_sizes = {
        (first, second): (
            math.comb(len(FAMILIES[first]), 2)
            if first == second
            else len(FAMILIES[first]) * len(FAMILIES[second])
        )
        for first in range(len(FAMILIES))
        for second in range(first, len(FAMILIES))
    }
    expected_keys = {
        (families, rotations)
        for families in family_pair_sizes
        for rotations in itertools.product(range(4), repeat=2)
    }
    missing_keys = expected_keys - set(grouped)
    unexpected_keys = set(grouped) - expected_keys
    if missing_keys:
        errors.append(f"missing family/rotation groups: {sorted(missing_keys)}")
    if unexpected_keys:
        errors.append(f"unexpected family/rotation groups: {sorted(unexpected_keys)}")
    for families, rotations in sorted(expected_keys & set(grouped)):
        records = grouped[(families, rotations)]
        copy_count_ok = len(records) == family_pair_sizes[families]
        equal = all(signature == records[0][1] for _pair, signature in records[1:])
        pair_ok &= equal and copy_count_ok
        pair_checks.append({
            "families": list(families),
            "rotations_in_canonical_endpoint_order": list(rotations),
            "object_pairs": [list(pair) for pair, _signature in records],
            "copy_count": len(records),
            "expected_copy_count": family_pair_sizes[families],
            "copy_count_ok": copy_count_ok,
            "slice_count": len(records[0][1]),
            "canonical_signature_sha256": hashlib.sha256(
                json.dumps(records[0][1], separators=(",", ":")).encode("ascii")
            ).hexdigest(),
            "exactly_equal": equal,
        })

    # A permutation within one family can reverse the canonical endpoint order
    # of a pair.  Under that relabeling, rotations exchange places and the x/y
    # coefficients change sign; big-M, rhs, and the active rhs do not.
    endpoint_reversal_checks = []
    endpoint_reversal_ok = True
    for family in range(len(FAMILIES)):
        for first_rotation, second_rotation in itertools.product(range(4), repeat=2):
            source_key = ((family, family), (first_rotation, second_rotation))
            target_key = ((family, family), (second_rotation, first_rotation))
            source_records = grouped[source_key]
            target_records = grouped[target_key]
            source_signature = source_records[0][1]
            target_signature = target_records[0][1]
            equal = reverse_pair_signature(source_signature) == target_signature
            endpoint_reversal_ok &= equal
            endpoint_reversal_checks.append({
                "family": family,
                "source_rotations": [first_rotation, second_rotation],
                "target_rotations": [second_rotation, first_rotation],
                "exactly_equal_after_endpoint_reversal": equal,
            })

    masks = ["".join(bits) for bits in itertools.product("01", repeat=7)]
    if args.screen:
        screen = json.loads(args.screen.read_text(encoding="utf-8"))
        masks = screen["strict_improvement_candidate_masks"]
    orbit_groups: dict[tuple[int, int, int], list[str]] = collections.defaultdict(list)
    for mask in masks:
        orbit = tuple(sum(mask[obj] == "1" for obj in family) for family in FAMILIES)
        orbit_groups[orbit].append(mask)

    certified = object_ok and pair_ok and endpoint_reversal_ok and not errors
    if certified:
        conclusion = (
            "Objects within each listed family have identical bounds, objective, containment, "
            "and orientation-cardinality data. For every family pair and ordered rotation pair, "
            "every copy has the same multiset of full big-M rows and active-slice polyhedra after "
            "exact rational normalization of all halfspaces. All within-family endpoint reversals "
            "also match exactly after exchanging the rotations and negating the coordinate "
            "normal. Every slice-choice row and binary bound has the expected exact form. Slice "
            "labels may differ. Therefore permutations within a family preserve the exact "
            "decimal-MPS feasible set and objective."
        )
    else:
        conclusion = (
            "The same-order copy checks pass, but a simple permutation of the extended-MPS slice "
            "variables is not certified: within-family endpoint reversal requires exchanging the "
            "rotations and negating the coordinate normal, and at least one exact slice multiset "
            "comparison fails. The family-count groups below therefore do not prove equivalence "
            "of their masks. A projected union-of-polyhedra proof would be needed to establish "
            "geometric copy symmetry despite different slice decompositions."
        )
    output = {
        "input": args.mps.as_posix(),
        "input_sha256": hashlib.sha256(args.mps.read_bytes()).hexdigest(),
        "families": [list(group) for group in FAMILIES],
        "object_data_checks": object_checks,
        "pair_orientation_checks": pair_checks,
        "within_family_endpoint_reversal_checks": endpoint_reversal_checks,
        "slice_choice_checks": choice_check,
        "structural_errors": errors,
        "exact_copy_permutation_symmetry_certified": certified,
        "same_order_copy_checks_passed": object_ok and pair_ok and not errors,
        "within_family_endpoint_reversal_failed_count": sum(
            not check["exactly_equal_after_endpoint_reversal"]
            for check in endpoint_reversal_checks
        ),
        "candidate_mask_count": len(masks),
        "family_count_group_count": len(orbit_groups),
        "family_count_grouping_is_not_a_mask_equivalence_proof": not certified,
        "presence_mask_family_count_groups": [
            {
                "family_presence_counts_A_B_C": list(orbit),
                "representative": members[0],
                "members": members,
            }
            for orbit, members in sorted(orbit_groups.items())
        ],
        "conclusion": conclusion,
        "evidence_boundary": (
            "This audit tests a slice-variable permutation automorphism of the submitted decimal "
            "MPS. A failed test is not evidence against equality of the projected geometric "
            "unions, and no statement is made about unavailable pre-MPS polygon vertices."
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(output, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "certified": certified,
        "candidate_mask_count": len(masks),
        "family_count_group_count": len(orbit_groups),
        "groups": output["presence_mask_family_count_groups"],
        "structural_error_count": len(errors),
        "failed_pair_checks": sum(not check["exactly_equal"] for check in pair_checks),
        "failed_endpoint_reversal_checks": sum(
            not check["exactly_equal_after_endpoint_reversal"]
            for check in endpoint_reversal_checks
        ),
    }, indent=2))


if __name__ == "__main__":
    main()
