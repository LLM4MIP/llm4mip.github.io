#!/usr/bin/env python3
"""Extract a compact, independently replayable NFP geometry certificate."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("structure_audit", type=Path)
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    audit = json.loads(args.structure_audit.read_text(encoding="utf-8"))
    solution = audit["solution_audit"]
    selected = {
        int(object_index): rotations[0]
        for object_index, rotations in audit["selected_orientations"].items()
        if len(rotations) == 1
    }
    geometry_by_object = {entry["object"]: entry for entry in audit["object_bounding_geometry"]}
    objects = []
    for object_index, rotation in sorted(selected.items()):
        entry = geometry_by_object[object_index]
        rotation_entry = entry["rotations"][rotation]
        objects.append({
            "object": object_index,
            "rotation_quarter_turns": rotation,
            "coordinate_variables": entry["coordinate_variables"],
            "bbox_extent": {
                "x": rotation_entry["x_bbox_extent"],
                "y": rotation_entry["y_bbox_extent"],
            },
            "orientation_variable": rotation_entry["orientation_variable"],
        })
    pair_certificates = solution["selected_pair_slice_certificate"]
    expected_pairs = len(objects) * (len(objects) - 1) // 2
    all_pair_claims_pass = (
        len(pair_certificates) == expected_pairs
        and all(pair["active_slice_count"] >= 1 for pair in pair_certificates)
        and all(
            active["violation_count"] == 0
            for pair in pair_certificates
            for active in pair["active_slices"]
        )
    )
    result = {
        "input_mps": str(args.mps),
        "input_mps_sha256": sha256(args.mps),
        "solution": str(args.solution),
        "solution_sha256": sha256(args.solution),
        "container_from_containment_rhs": {"width": "350", "height": "250"},
        "selected_object_count": len(objects),
        "selected_objects": objects,
        "expected_selected_pairs": expected_pairs,
        "selected_pair_slice_certificates": pair_certificates,
        "all_selected_pairs_have_exactly_checked_active_nfp_slice": all_pair_claims_pass,
        "original_mps_exact_row_violation_count": solution["exact_row_violation_count"],
        "original_mps_exact_bound_violations": solution["bound_violations"],
        "original_mps_exact_integrality_violations": solution["integrality_violations"],
        "objective_decimal_replay": solution["objective"],
        "conclusion": (
            "The candidate is exactly feasible for the submitted decimal MPS; "
            "for every selected object pair an active no-fit slice is identified "
            "and every defining halfspace has nonnegative exact Decimal slack."
        ),
        "evidence_boundary": (
            "This is a geometry certificate for the no-fit disjunction encoded in "
            "the original MPS. MIPLIB supplies no source polygon-vertex file for this "
            "instance, so it is not an independent reconstruction of pre-MPS vertices."
        ),
    }
    if not all_pair_claims_pass or solution["exact_row_violation_count"] != 0:
        raise AssertionError("certificate premises failed")
    with args.output.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "selected_object_count": len(objects),
        "expected_selected_pairs": expected_pairs,
        "pair_certificate_pass": all_pair_claims_pass,
        "objective": result["objective_decimal_replay"],
    }, indent=2))


if __name__ == "__main__":
    main()
