#!/usr/bin/env python3
"""CPU-only COPT full-model probe seeded by a strictly checked solution."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import coptpy as cp
from coptpy import COPT


def read_solution(path: Path) -> dict[str, float]:
    result: dict[str, float] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        fields = raw.split()
        if len(fields) >= 2 and not fields[0].startswith(("#", "=")):
            try:
                result[fields[0]] = float(fields[1])
            except ValueError:
                pass
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("start", type=Path)
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--seconds", type=float, default=600.0)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    values = read_solution(args.start)
    model = cp.Envr().createModel("polygonpack4-7-full")
    model.read(str(args.mps))
    variables = model.getVars().getAll()
    model.setMipStart(variables, [values.get(variable.name, 0.0) for variable in variables])
    model.loadMipStart()
    model.setParam(COPT.Param.Logging, 1)
    model.setLogFile(str(args.outdir / "copt.log"))
    model.setParam(COPT.Param.Threads, 32)
    model.setParam(COPT.Param.TimeLimit, args.seconds)
    model.setParam(COPT.Param.RelGap, 0.0)
    try:
        model.setParam(COPT.Param.FeasTol, 1e-9)
    except Exception:
        pass
    model.solve()

    result = {
        "copt_version": [COPT.VERSION_MAJOR, COPT.VERSION_MINOR, COPT.VERSION_TECHNICAL],
        "cpu_only": True,
        "threads": 32,
        "time_limit_seconds": args.seconds,
        "strict_start": str(args.start),
        "status": int(model.status),
        "has_solution": int(model.hasmipsol),
    }
    for key, attr in (
        ("objective", "objval"),
        ("best_bound", "bestbnd"),
        ("relative_gap", "mipgap"),
        ("node_count", "nodecnt"),
        ("runtime", "solvingtime"),
    ):
        try:
            result[key] = float(getattr(model, attr))
        except Exception:
            pass
    if model.hasmipsol:
        model.writeSol(str(args.outdir / "incumbent.sol"))
    (args.outdir / "summary.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
