#!/usr/bin/env python3
"""Read polygonpack4-7 with Gurobi and emit a structure-only JSON audit.

This deliberately does not optimize the model.  It is intended to establish the
raw MPS dimensions, variable/row types and coefficient scales using the solver
environment requested for the experiment.
"""

from __future__ import annotations

import argparse
import collections
import gzip
import hashlib
import json
import math
import os
import platform
import socket
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def finite_or_none(value: float) -> float | None:
    return value if math.isfinite(value) and abs(value) < GRB.INFINITY else None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    digest = hashlib.sha256(args.mps.read_bytes()).hexdigest()
    model = gp.read(str(args.mps))
    variables = model.getVars()
    constraints = model.getConstrs()

    vtypes = collections.Counter(v.VType for v in variables)
    senses = collections.Counter(c.Sense for c in constraints)
    obj_nonzero = [(v.VarName, v.Obj) for v in variables if v.Obj != 0.0]
    finite_lbs = [v.LB for v in variables if finite_or_none(v.LB) is not None]
    finite_ubs = [v.UB for v in variables if finite_or_none(v.UB) is not None]
    rhs = [c.RHS for c in constraints]
    nnz_per_row = [model.getRow(c).size() for c in constraints]

    # Keep representative raw rows/columns so later semantic recovery remains
    # explicitly tied to the Gurobi parse of the original MPS.
    representative_rows = []
    for c in constraints[:20]:
        row = model.getRow(c)
        representative_rows.append(
            {
                "name": c.ConstrName,
                "sense": c.Sense,
                "rhs": c.RHS,
                "terms": [
                    [row.getVar(i).VarName, row.getCoeff(i)]
                    for i in range(min(row.size(), 30))
                ],
                "nnz": row.size(),
            }
        )

    data = {
        "purpose": "structure-only Gurobi read; no optimization",
        "host": socket.gethostname(),
        "user": os.environ.get("USER"),
        "platform": platform.platform(),
        "python": platform.python_version(),
        "gurobi_version": list(gp.gurobi.version()),
        "input": str(args.mps.resolve()),
        "input_sha256": digest,
        "model_name": model.ModelName,
        "objective_sense": "min" if model.ModelSense == GRB.MINIMIZE else "max",
        "num_variables": model.NumVars,
        "num_constraints": model.NumConstrs,
        "num_nonzeros": model.NumNZs,
        "num_sos": model.NumSOS,
        "num_quadratic_constraints": model.NumQConstrs,
        "variable_types": dict(sorted(vtypes.items())),
        "constraint_senses": dict(sorted(senses.items())),
        "objective_nonzero_count": len(obj_nonzero),
        "objective_nonzeros": obj_nonzero,
        "objective_coefficient_min": min((x[1] for x in obj_nonzero), default=0.0),
        "objective_coefficient_max": max((x[1] for x in obj_nonzero), default=0.0),
        "finite_lb_min": min(finite_lbs, default=None),
        "finite_lb_max": max(finite_lbs, default=None),
        "finite_ub_min": min(finite_ubs, default=None),
        "finite_ub_max": max(finite_ubs, default=None),
        "rhs_min": min(rhs, default=None),
        "rhs_max": max(rhs, default=None),
        "row_nnz_min": min(nnz_per_row, default=None),
        "row_nnz_max": max(nnz_per_row, default=None),
        "row_nnz_histogram": dict(sorted(collections.Counter(nnz_per_row).items())),
        "first_variables": [
            {
                "name": v.VarName,
                "type": v.VType,
                "lb": finite_or_none(v.LB),
                "ub": finite_or_none(v.UB),
                "obj": v.Obj,
            }
            for v in variables[:30]
        ],
        "representative_rows": representative_rows,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")
    print(json.dumps({k: data[k] for k in (
        "host", "user", "gurobi_version", "input_sha256", "objective_sense",
        "num_variables", "num_constraints", "num_nonzeros", "variable_types",
        "constraint_senses", "objective_nonzero_count")}, indent=2))


if __name__ == "__main__":
    main()
