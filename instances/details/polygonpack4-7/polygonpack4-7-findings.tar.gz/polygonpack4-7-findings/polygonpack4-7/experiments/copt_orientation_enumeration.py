#!/usr/bin/env python3
"""Enumerate orientations; let COPT choose NFP slices and coordinates per leaf.

Each leaf is much smaller than the original MIP because all 28
selection/orientation variables are fixed.  Solver statuses are recorded as
experimental evidence, not independently checkable infeasibility proofs.
"""

from __future__ import annotations

import argparse
import itertools
import json
import math
from pathlib import Path

import coptpy as cp
from coptpy import COPT


def safe_float(model, attribute: str):
    try:
        value = float(getattr(model, attribute))
        return value if math.isfinite(value) else None
    except Exception:
        return None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("mask")
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--per-leaf-seconds", type=float, default=2.0)
    parser.add_argument("--threads", type=int, default=8)
    parser.add_argument("--feasibility-only", action="store_true")
    parser.add_argument("--stop-on-feasible", action="store_true")
    parser.add_argument("--shard-index", type=int, default=0)
    parser.add_argument("--shard-count", type=int, default=1)
    args = parser.parse_args()
    if len(args.mask) != 7 or any(bit not in "01" for bit in args.mask):
        raise ValueError("mask must be seven 0/1 characters")
    args.outdir.mkdir(parents=True, exist_ok=True)
    if not 0 <= args.shard_index < args.shard_count:
        raise ValueError("require 0 <= shard-index < shard-count")

    selected_objects = [i for i, bit in enumerate(args.mask) if bit == "1"]
    records = []
    best_objective = math.inf
    best_orientations = None
    best_solution_path = args.outdir / "best-floating.sol"
    for leaf_index, choices in enumerate(itertools.product(range(4), repeat=len(selected_objects))):
        if leaf_index % args.shard_count != args.shard_index:
            continue
        orientation = dict(zip(selected_objects, choices))
        model = cp.Envr().createModel(f"polygonpack-leaf-{leaf_index}")
        model.read(str(args.mps))
        variables = model.getVars().getAll()
        for object_index in range(7):
            chosen = orientation.get(object_index)
            for rotation in range(4):
                variable = variables[14 + 4 * object_index + rotation]
                value = 1.0 if chosen == rotation else 0.0
                variable.setInfo(COPT.Info.LB, value)
                variable.setInfo(COPT.Info.UB, value)
        if args.feasibility_only:
            model.setObjective(0.0)
        model.setParam(COPT.Param.Logging, 0)
        model.setParam(COPT.Param.Threads, args.threads)
        model.setParam(COPT.Param.TimeLimit, args.per_leaf_seconds)
        model.setParam(COPT.Param.RelGap, 0.0)
        try:
            model.setParam(COPT.Param.FeasTol, 1e-9)
        except Exception:
            pass
        model.solve()
        objective = safe_float(model, "objval") if model.hasmipsol else None
        record = {
            "leaf": leaf_index,
            "orientation_by_selected_object": {str(k): v for k, v in orientation.items()},
            "status": int(model.status),
            "has_solution": int(model.hasmipsol),
            "objective": objective,
            "best_bound": safe_float(model, "bestbnd"),
            "runtime": safe_float(model, "solvingtime"),
            "node_count": safe_float(model, "nodecnt"),
        }
        records.append(record)
        if objective is not None and objective < best_objective:
            best_objective = objective
            best_orientations = record["orientation_by_selected_object"]
            model.writeSol(str(best_solution_path))
        if args.stop_on_feasible and model.hasmipsol:
            break
        if len(records) % 32 == 0:
            print(
                f"progress={len(records)}/{math.ceil(4 ** len(selected_objects) / args.shard_count)} "
                f"feasible={sum(r['has_solution'] for r in records)} "
                f"unresolved={sum(r['status'] not in (COPT.OPTIMAL, COPT.INFEASIBLE) for r in records)} "
                f"best={best_objective if best_objective < math.inf else None}",
                flush=True,
            )

    result = {
        "mask": args.mask,
        "selected_objects": selected_objects,
        "leaf_count": len(records),
        "per_leaf_seconds": args.per_leaf_seconds,
        "threads_per_leaf": args.threads,
        "feasibility_only": args.feasibility_only,
        "stop_on_feasible": args.stop_on_feasible,
        "shard_index": args.shard_index,
        "shard_count": args.shard_count,
        "status_code_note": {"optimal": int(COPT.OPTIMAL), "infeasible": int(COPT.INFEASIBLE)},
        "optimal_leaf_count": sum(record["status"] == COPT.OPTIMAL for record in records),
        "infeasible_leaf_count": sum(record["status"] == COPT.INFEASIBLE for record in records),
        "unresolved_leaf_count": sum(
            record["status"] not in (COPT.OPTIMAL, COPT.INFEASIBLE) for record in records
        ),
        "feasible_leaf_count": sum(record["has_solution"] for record in records),
        "best_floating_objective": best_objective if best_objective < math.inf else None,
        "best_orientations": best_orientations,
        "records": records,
        "evidence_boundary": (
            "Statuses are COPT floating-solver evidence. Best solutions require original-MPS Decimal replay; "
            "infeasible leaves are not proof certificates independent of COPT."
        ),
    }
    (args.outdir / "summary.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print("RESULT_JSON=" + json.dumps({k: result[k] for k in (
        "mask", "leaf_count", "optimal_leaf_count", "infeasible_leaf_count",
        "unresolved_leaf_count", "feasible_leaf_count", "best_floating_objective",
        "best_orientations")}, sort_keys=True))


if __name__ == "__main__":
    main()
