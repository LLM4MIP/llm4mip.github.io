# polygonpack4-7: exact-decimal geometry and tolerance audit

## Current conclusion

This study does **not** claim a new MIPLIB incumbent or global optimality.
The current headline improvement is a solver-tolerance artifact: the newest
public solution uses three orientation variables at `1e-6`.  Their large
negative objective coefficients create most of the nominal gain, but they are
not integers.

We do provide a genuinely zero-tolerance MPS-feasible repair with objective

```text
-51837707.95034043267785954996
```

Every one of the 34,529 original rows, all bounds, and all integrality
conditions has zero violation under 80-digit `Decimal` replay.  This is a
strict-feasibility repair of the historical incumbent, not an improvement over
the tolerance-based MIPLIB headline.

Numerically, the MIPLIB page headline is `-51,837,758.96241999`, whereas the
strict repair is `-51,837,707.95034043267785954996`.  Because this is a
minimization model, the strict point is **worse by
`51.01207955732214045004`**.  It therefore must not be reported as an
incumbent improvement.

## Problem background

The [official MIPLIB instance page](https://miplib.zib.de/instance_details_polygonpack4-7.html)
describes a maximum-area subset packing problem: choose from seven nonconvex
polygons, place the chosen objects without overlap inside a rectangle, and
allow rotations by 0, 90, 180, or 270 degrees.  Polygons have no fully enclosed
holes but may have bays.  The submitted instance is still open and tagged
`numerics`, `set_packing`, `invariant_knapsack`, and `mixed_binary`.

The MPS itself retains descriptive Italian row names.  They show that the
formulation uses containment constraints and a no-fit-region disjunction for
each pair of objects and orientations.  This is consistent with the general
no-fit-polygon modeling literature.  For methodological context, the later
[NFP model based on vertical slices](https://arxiv.org/abs/2206.00032) explains
how binary choices can select a convex feasible subregion and linear
halfspaces can enforce the associated relative placement.  That paper is not
claimed as the source of this MIPLIB instance; MIPLIB lists no bibliography for
`polygonpack4-7`.

A [2018 University of Pisa master's thesis](https://etd.adm.unipi.it/t/etd-01172018-224127/)
supervised by the instance submitter surveys the same irregular-polygon
packing setting, including finite rotations and exact, heuristic, and
matheuristic approaches.  It is useful contemporaneous background, but the
archive page does not identify `polygonpack4-7` as one of its generated
instances.  NVIDIA's later
[cuOpt announcement](https://developer.nvidia.com/blog/learn-how-nvidia-cuopt-accelerates-mixed-integer-optimization-using-primal-heuristics/)
explicitly names `polygonpack4-7` among four open MIPLIB instances targeted by
its primal heuristics; the exact audit below uses the public MIPLIB solution
file rather than the announcement's rounded objective.

No original polygon-vertex data was found on the instance page or under the
corresponding entries of MIPLIB's supplementary-model archive.  Consequently,
the geometry certificate below is exact for the submitted decimal MPS and its
no-fit disjunctions, but is not a reconstruction of unknown pre-MPS vertices.

## Required Gurobi structure read

The original compressed MPS was first read on `euler4` with
`/home/wyc/miniconda3/envs/milp-ps/bin/python` and Gurobi 13.0.1.  The license
is the bundled restricted non-production license, expiring 2027-11-29.  No GPU
was used and no optimization was attempted in this step.

Gurobi reported:

| property | value |
|---|---:|
| rows | 34,529 |
| columns | 10,788 |
| nonzeros | 178,591 |
| continuous columns | 14 |
| 0-1 integer columns | 10,774 |
| nonzero objective columns | 42 |

The source MPS SHA-256 is
`dcbed0f1ef6230b21175b335eac5a552a59fc3f93cbba14e7933302958ca9cb5`.
See [`analysis/gurobi-13.0.1-structure.json`](analysis/gurobi-13.0.1-structure.json)
and [`logs/gurobi-13.0.1-structure.log`](logs/gurobi-13.0.1-structure.log).
The restricted license can read this model but refuses to optimize even the
14-variable fixed-pattern model while all 34,529 rows remain present; that
failure is retained in [`logs/official-4-fixed-lp.log`](logs/official-4-fixed-lp.log).

## Exact structure recovered

[`experiments/recover_geometry.py`](experiments/recover_geometry.py) parses the
literal MPS decimals and recovers all row and variable roles:

| role | count |
|---|---:|
| coordinate variables (`x_i,y_i`) | 14 |
| presence/orientation variables | 28 = 7 x 4 |
| no-fit slice/disjunction variables | 10,746 |
| containment rows | 28 |
| orientation-cardinality rows | 14 |
| pair/orientation slice-choice rows | 336 |
| no-fit halfspace rows | 34,151 |

The 336 choice rows are exactly
`C(7,2) x 4 x 4`: one for every unordered object pair and orientation pair.
Each has the form

```text
z[i,ri] + z[j,rj] - sum_s delta[i,ri,j,rj,s] <= 1,
```

so two selected orientations must activate at least one feasible no-fit slice.
Each active `delta` then activates three to seven halfspace inequalities for
the relative `(x,y)` placement.  Across a pair/orientation combination there
are 20--48 candidate slices and 71--170 halfspace rows.

The seven objects occur in three repeated geometric families with multiplicity
2, 2, and 3.  Their axis-aligned bounding-box extents, depending on quarter
turn, are approximately:

| object family | copies | horizontal orientation | quarter-turn orientation |
|---|---:|---:|---:|
| A | 2 | 154 x 141.4 | 141.4 x 154 |
| B | 2 | 246 x 84.8 | 84.7 x 246 |
| C | 3 | 163.2 x 129 | 129 x 163.1 |

The container dimensions recovered from the containment right-hand sides are
350 x 250.  Full literal coefficients, objective values, mappings, and row
histograms are in
[`analysis/structure-and-zero-tolerance-repair.json`](analysis/structure-and-zero-tolerance-repair.json).

## Why the published improvements are numerical

The exact checker intentionally uses the finite decimal strings stored in the
MPS and solution files; missing solution columns are zero.

| public revision | literal objective replay | exact row violations | exact integer violations | strict interpretation |
|---|---:|---:|---:|---|
| MIPLIB `/4/`, cuOpt | -51,837,750.18738644608 | 12, max `1e-6` | 3, max `1e-6` | not strict |
| `/4/` after integer rounding | -51,837,707.11617517954 | 0 | 0 | strict, but no improvement |
| MIPLIB `/3/`, PartiMIP | -51,837,712.9799563899... | 5 | 2 | not strict |
| MIPLIB `/2/`, historical | -51,837,707.9503404327... | 2, max `1.035955e-14` | 0 | tolerance-feasible, not Decimal-zero |
| this study's repair | -51,837,707.95034043267785954996 | 0 | 0 | strict MPS-feasible |

The compact machine-readable audit, including the smallest and largest exact
residual for every retained public or experimental candidate, is in
[`analysis/candidate-exact-audit.json`](analysis/candidate-exact-audit.json).

For revision `/4/`, the three fractional orientation columns each equal
`1e-6` and have objective coefficients of order `-10^7`.  Integer rounding
therefore removes roughly 43 objective units.  The nominal header objective
also differs from the literal objective replay by about 8.775, matching the
objective-violation warning on the MIPLIB solution table.

The strict repair changes only two continuous coordinates from revision `/2/`:

```text
C0000000 += 1e-11
C0000004 += 2e-11
```

The objective worsens by only `6.9386e-11`, while both tiny negative no-fit
slacks become nonnegative.  The candidate and captured replay are
[`solutions/official-2-zero-tolerance-repair.sol`](solutions/official-2-zero-tolerance-repair.sol)
and [`solutions/zero-tolerance-repair.validation.log`](solutions/zero-tolerance-repair.validation.log).

## No-fit geometry certificate

The repaired solution selects objects 0--3 with rotations `(3,3,3,0)` and
leaves objects 4--6 absent.  For all six selected pairs, the certificate names
the active no-fit slice and checks every defining halfspace with exact Decimal
arithmetic.  Each pair has exactly one active slice; all six slice systems have
zero violations.  The smallest positive halfspace slack is `7.06408e-14`.

See
[`analysis/zero-tolerance-nfp-geometry-certificate.json`](analysis/zero-tolerance-nfp-geometry-certificate.json).
This certificate is deliberately phrased as MPS no-fit geometry, not as an
independent polygon-intersection test without source vertices.

## Solver experiments and finite next search

Fixing the rounded cuOpt discrete layout and reoptimizing all 14 coordinates
with COPT 8.0.4 on `altman` returns `-51837707.950340435` in 0.03 seconds.  Its
floating point has one `1.76e-17` Decimal violation, while the explicit repair
above is zero-violation.  Thus the fixed-layout experiment independently
confirms that the apparent cuOpt gain is not retained by its integral layout.

A 600-second full COPT run, seeded with the zero-tolerance repair, explored
142,906 nodes.  It found no better incumbent and ended with floating best bound
`-75324617.46384819` (31.18% gap).  This is a baseline log, not a certified
global bound.

An exact objective-only screen over all `2^7 = 128` presence masks uses the
nonnegative coordinate costs and zero-cost slice variables.  It proves that
109 masks cannot strictly improve the repaired incumbent before any geometry
is considered.  Only 19 masks remain, including the current `1111000` mask and
18 masks selecting five or more objects.  See
[`analysis/objective-layer-screen.json`](analysis/objective-layer-screen.json).

The repeated families suggest eight natural family-count groups, but they are
**not used as certified symmetry orbits**.  The exact audit verifies identical
bounds, objectives, containment, and rotation-cardinality data for copies
`{0,1}`, `{2,3}`, and `{4,5,6}`.  It also verifies all 96 same-endpoint-order
family/rotation comparisons, the full big-M and active no-fit rows, all 336
choice rows, and binary slice bounds.  However, a permutation inside one
family can reverse a pair's endpoint order.  After exactly exchanging the two
rotations and negating the coordinate normal, 47 of 48 endpoint-reversal slice
multisets differ.  Therefore a simple permutation of the extended MPS slice
variables is not certified.

Different slice decompositions could still describe the same projected union
of geometric regions.  Establishing that would require a separate exact
union-of-polyhedra proof, which is not available here.  The audit therefore
neither proves nor disproves projected geometric copy symmetry, and no mask
result is extrapolated through it.  See
[`analysis/copy-symmetry-audit.json`](analysis/copy-symmetry-audit.json),
generated by
[`experiments/certify_copy_symmetry.py`](experiments/certify_copy_symmetry.py).

Instead, every one of the 19 surviving masks received its own CPU-only COPT
run.  All runs ended at status 8 (time limit).  Eighteen found no feasible
point.  The `1111000` run returned the known floating incumbent, whose exact
replay has three positive row residuals between `1.5044e-15` and
`2.425412e-13`; the separately repaired strict point remains the valid
reference.  No run found a strict improvement or closed a mask by independent
proof.

One attempted noninteractive launch resolved the system COPT 7.2.8 module
against the COPT 8 license files and failed before model creation with an
invalid-signature error.  It is not counted as a solver run; the captured
diagnostic is in
[`logs/copt72-invalid-license-launch.log`](logs/copt72-invalid-license-launch.log).
All reported runs explicitly load COPT 8.0.4.

| mask | seconds | nodes | outcome |
|---|---:|---:|---|
| `0111111` | 120 | 30,491 | no feasible point found; timeout |
| `1011111` | 30 | 4,348 | no feasible point found; timeout |
| `1100111` | 120 | 50,652 | no feasible point found; timeout |
| `1101011` | 120 | 48,858 | no feasible point found; timeout |
| `1101101` | 30 | 7,867 | no feasible point found; timeout |
| `1101110` | 30 | 7,003 | no feasible point found; timeout |
| `1101111` | 120 | 33,629 | no feasible point found; timeout |
| `1110011` | 30 | 7,291 | no feasible point found; timeout |
| `1110101` | 30 | 7,131 | no feasible point found; timeout |
| `1110110` | 30 | 7,835 | no feasible point found; timeout |
| `1110111` | 30 | 4,671 | no feasible point found; timeout |
| `1111000` | 300 | 208,309 | known floating incumbent; no strict improvement; timeout |
| `1111001` | 180 | 11,941 | no feasible point found; timeout |
| `1111010` | 30 | 6,653 | no feasible point found; timeout |
| `1111011` | 120 | 34,525 | no feasible point found; timeout |
| `1111100` | 30 | 6,557 | no feasible point found; timeout |
| `1111101` | 30 | 4,222 | no feasible point found; timeout |
| `1111110` | 30 | 3,678 | no feasible point found; timeout |
| `1111111` | 120 | 22,525 | no feasible point found; timeout |

Thus all 19 surviving masks have a direct recorded result, but all 19 remain
open in the proof sense.  The exact coverage check, individual summary/log
hashes, and status boundary are in
[`analysis/presence-mask-search-summary.json`](analysis/presence-mask-search-summary.json).

The natural next solver is a small logic-based Benders scheme:

1. enumerate only the 19 remaining presence masks and four orientations per
   selected object;
2. choose one no-fit slice for every active object pair in a SAT/PB master;
3. check the resulting placement in only 14 continuous variables;
4. learn an infeasible orientation/slice core from an LP Farkas ray;
5. replay every feasible leaf with exact MPS decimals, and retain rationalized
   Farkas certificates for closed leaves.

[`experiments/copt_orientation_enumeration.py`](experiments/copt_orientation_enumeration.py)
implements the first useful finite experiment: orientations are enumerated and
COPT solves only slice/placement leaves.  Its infeasibility statuses remain
solver evidence until accompanied by independent Farkas certificates.

For the current `1111000` presence mask, a one-second-per-leaf sweep examined
all 256 orientations.  COPT marked 125 leaves infeasible, left 130 unresolved,
and found a floating solution in 48 leaves (the counts overlap because one
leaf can have a solution at a time limit).  Only one leaf reached optimality.
The best written point was `-51,837,699.08382522`, already worse than the
strict repair, and Decimal replay found two row residuals with maximum
`2.8e-14`; this is search evidence, not a new incumbent or a proof.

A separate 180-second COPT run fixed the first five-object mask `1111001` while
leaving rotations, slices, and coordinates free.  It explored 11,941 nodes,
found no feasible solution, and stopped with bound `-59,667,768.95422855`.
Time-limit termination is not an infeasibility proof.

For that same mask, a four-way orientation sweep visited all `4^5 = 1,024`
leaves exactly once.  At one second per leaf COPT reported 776 leaves
infeasible, left 248 leaves unresolved, and found no feasible leaf.  These
statuses remain solver evidence; the 248 leaves are explicit timeouts and the
776 others lack rational Farkas certificates.  See
[`analysis/orientation-feasibility-1111001-summary.json`](analysis/orientation-feasibility-1111001-summary.json).

## Reproduce the exact checks

From the repository root:

```bash
python common/exact_mps_solution_check.py \
  instances/polygonpack4-7/input/polygonpack4-7.mps.gz \
  instances/polygonpack4-7/solutions/official-2-zero-tolerance-repair.sol \
  --tolerance 0

python instances/polygonpack4-7/experiments/recover_geometry.py \
  instances/polygonpack4-7/input/polygonpack4-7.mps.gz \
  instances/polygonpack4-7/analysis/structure-and-zero-tolerance-repair.json \
  --solution instances/polygonpack4-7/solutions/official-2-zero-tolerance-repair.sol \
  --active-limit 1e-9

python instances/polygonpack4-7/experiments/make_geometry_certificate.py \
  instances/polygonpack4-7/analysis/structure-and-zero-tolerance-repair.json \
  instances/polygonpack4-7/input/polygonpack4-7.mps.gz \
  instances/polygonpack4-7/solutions/official-2-zero-tolerance-repair.sol \
  instances/polygonpack4-7/analysis/zero-tolerance-nfp-geometry-certificate.json

python instances/polygonpack4-7/experiments/screen_object_subsets.py \
  instances/polygonpack4-7/input/polygonpack4-7.mps.gz \
  -51837707.95034043267785954996 \
  instances/polygonpack4-7/analysis/objective-layer-screen.json

python instances/polygonpack4-7/experiments/certify_copy_symmetry.py \
  instances/polygonpack4-7/input/polygonpack4-7.mps.gz \
  instances/polygonpack4-7/analysis/copy-symmetry-audit.json \
  --screen instances/polygonpack4-7/analysis/objective-layer-screen.json
```

All optimization runs here were CPU-only.  GPU0 was not used.
