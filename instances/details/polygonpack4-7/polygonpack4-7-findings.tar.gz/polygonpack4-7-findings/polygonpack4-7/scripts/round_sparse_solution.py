#!/usr/bin/env python3
"""Round integer entries in a sparse MIPLIB solution; never optimize."""

import argparse
import gzip
from pathlib import Path

import gurobipy as gp


def read_sparse(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix == ".gz" else open
    values: dict[str, float] = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as stream:
        for raw in stream:
            fields = raw.split()
            if len(fields) < 2 or fields[0].startswith("#"):
                continue
            if fields[0] == "=obj=":
                continue
            values[fields[0]] = float(fields[1])
    return values


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", required=True, type=Path)
    parser.add_argument("--sol", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()

    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()
    model = gp.read(str(args.mps), env=env)
    supplied = read_sparse(args.sol)

    repaired: dict[str, float] = {}
    rounded = []
    for variable in model.getVars():
        value = supplied.get(variable.VarName, 0.0)
        if variable.VType != gp.GRB.CONTINUOUS:
            new_value = float(round(value))
            if new_value != value:
                rounded.append((variable.VarName, value, new_value))
            value = new_value
        if value != 0.0:
            repaired[variable.VarName] = value

    args.out.parent.mkdir(parents=True, exist_ok=True)
    objective = model.ObjCon + sum(
        variable.Obj * repaired.get(variable.VarName, 0.0)
        for variable in model.getVars()
    )
    with args.out.open("w", encoding="utf-8", newline="\n") as stream:
        stream.write(f"=obj= {objective:.17g}\n")
        for name in sorted(repaired):
            stream.write(f"{name} {repaired[name]:.17g}\n")

    print({
        "output": str(args.out),
        "objective": objective,
        "nonzeros": len(repaired),
        "rounded_entries": rounded,
    })
    model.dispose()
    env.dispose()


if __name__ == "__main__":
    main()
