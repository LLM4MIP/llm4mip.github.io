#!/usr/bin/env python3
"""
Exact structural recovery and incumbent audit for MIPLIB polygonpack4-7.

Important properties:

* Reads the compressed MPS text directly.
* Converts every decimal token to Fraction, preserving the actual saved MPS
  coefficient exactly.
* Does not call optimize, presolve, or any solver API.
* Recovers:
    - the seven (x_i,y_i) translation pairs,
    - four orientation/selection binaries per polygon,
    - all pair/orientation slice disjunctions,
    - all halfspaces attached to each slice.
* Audits solution files using their decimal strings as exact rationals.
* Checks whether the auxiliary slice variables can be eliminated exactly into
  OR-of-AND linear no-fit-region clauses.
* Emits:
    - report.json
    - latent_geometry.json.gz
    - exact_reduced.smt2, if the elimination proof succeeds
    - one orientation-fixed SMT file per incumbent
    - optionally a strict objective cutoff query.

The reduced SMT describes the SAVED MPS/LP DECIMALS. It is not a proof that
the rounded halfspaces exactly represent the polygons from which the instance
was generated.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
import re
import sys
from collections import defaultdict
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple


# ---------------------------------------------------------------------------
# Exact decimal and serialization utilities
# ---------------------------------------------------------------------------

def q(s) -> Fraction:
    """Parse an MPS decimal/scientific token exactly."""
    s = str(s).strip()
    if not s:
        raise ValueError("empty numeric token")
    if s[0] == "+":
        s = s[1:]
    low = s.lower()
    if low in {"inf", "+inf", "infinity", "+infinity"}:
        raise ValueError("infinity is not a rational token")
    if low in {"-inf", "-infinity"}:
        raise ValueError("-infinity is not a rational token")
    return Fraction(s)


def qstr(x: Fraction) -> str:
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"


def qdecimal(x: Fraction, digits: int = 14) -> str:
    return f"{float(x):.{digits}g}"


def smtq(x: Fraction) -> str:
    if x.denominator == 1:
        if x.numerator >= 0:
            return str(x.numerator)
        return f"(- {abs(x.numerator)})"
    if x.numerator >= 0:
        return f"(/ {x.numerator} {x.denominator})"
    return f"(- (/ {abs(x.numerator)} {x.denominator}))"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_gzip_or_plain(path: Path) -> Tuple[bytes, bytes]:
    raw = path.read_bytes()
    if path.suffix == ".gz" or raw[:2] == b"\x1f\x8b":
        return raw, gzip.decompress(raw)
    return raw, raw


def dump_json(path: Path, data, compress: bool = False) -> None:
    text = json.dumps(data, indent=2, sort_keys=True) + "\n"
    if compress:
        with gzip.open(path, "wt", encoding="utf-8") as f:
            f.write(text)
    else:
        path.write_text(text, encoding="utf-8")


# ---------------------------------------------------------------------------
# Minimal exact MPS parser
# ---------------------------------------------------------------------------

@dataclass
class Var:
    name: str
    integer: bool = False
    lb: Optional[Fraction] = Fraction(0)
    ub: Optional[Fraction] = None
    obj: Fraction = Fraction(0)


@dataclass
class Row:
    name: str
    sense: str                     # L, G, E
    rhs: Fraction
    terms: Dict[str, Fraction]


@dataclass
class ExactMPS:
    name: str
    sense: str                     # MIN or MAX
    obj_row: str
    obj_constant: Fraction
    vars: Dict[str, Var]
    var_order: List[str]
    rows: Dict[str, Row]
    row_order: List[str]


def meaningful_tokens(line: str) -> List[str]:
    """
    MIPLIB's files are normally readable as free MPS. Whitespace tokenization
    also works for conventional fixed MPS records because names contain no
    embedded spaces.
    """
    return line.strip().split()


def parse_mps(path: Path) -> Tuple[ExactMPS, dict]:
    raw, payload = read_gzip_or_plain(path)
    lines = payload.decode("ascii", errors="strict").splitlines()

    section = None
    model_name = ""
    sense = "MIN"
    row_sense: Dict[str, str] = {}
    row_order_all: List[str] = []
    obj_row = None

    cols: Dict[str, Dict[str, Fraction]] = defaultdict(lambda: defaultdict(Fraction))
    var_order: List[str] = []
    seen_vars = set()
    integer_vars = set()
    marker_integer = False

    rhs_values: Dict[str, Fraction] = defaultdict(Fraction)
    ranges: Dict[str, Fraction] = {}
    bounds_records: List[Tuple[str, str, Optional[Fraction]]] = []

    headers = {
        "NAME", "OBJSENSE", "OBJNAME", "ROWS", "COLUMNS",
        "RHS", "RANGES", "BOUNDS", "ENDATA"
    }

    for lineno, original in enumerate(lines, 1):
        line = original.rstrip("\r\n")
        stripped = line.strip()
        if not stripped or stripped.startswith("*"):
            continue

        toks = meaningful_tokens(line)
        head = toks[0].upper()

        if head in headers:
            section = head
            if head == "NAME" and len(toks) >= 2:
                model_name = toks[1]
            elif head == "OBJSENSE" and len(toks) >= 2:
                sense = toks[1].upper()
            elif head == "ENDATA":
                break
            continue

        if section == "OBJSENSE":
            sense = toks[0].upper()
            continue

        if section == "OBJNAME":
            obj_row = toks[0]
            continue

        if section == "ROWS":
            if len(toks) < 2:
                raise ValueError(f"MPS line {lineno}: malformed ROWS record")
            typ, name = toks[0].upper(), toks[1]
            row_sense[name] = typ
            row_order_all.append(name)
            if typ == "N" and obj_row is None:
                obj_row = name
            continue

        if section == "COLUMNS":
            # Typical marker:
            # MARK0000  'MARKER'  'INTORG'
            upper = [t.strip("'\"").upper() for t in toks]
            if "MARKER" in upper:
                if "INTORG" in upper:
                    marker_integer = True
                elif "INTEND" in upper:
                    marker_integer = False
                continue

            var = toks[0]
            if var not in seen_vars:
                seen_vars.add(var)
                var_order.append(var)
            if marker_integer:
                integer_vars.add(var)

            rest = toks[1:]
            if len(rest) % 2:
                raise ValueError(
                    f"MPS line {lineno}: odd COLUMNS row/value token count: {toks}"
                )
            for i in range(0, len(rest), 2):
                rname, value = rest[i], q(rest[i + 1])
                cols[var][rname] += value
            continue

        if section == "RHS":
            rest = toks[1:]  # ignore RHS set name
            if len(rest) % 2:
                raise ValueError(f"MPS line {lineno}: malformed RHS record")
            for i in range(0, len(rest), 2):
                rhs_values[rest[i]] += q(rest[i + 1])
            continue

        if section == "RANGES":
            rest = toks[1:]
            if len(rest) % 2:
                raise ValueError(f"MPS line {lineno}: malformed RANGES record")
            for i in range(0, len(rest), 2):
                ranges[rest[i]] = q(rest[i + 1])
            continue

        if section == "BOUNDS":
            if len(toks) < 3:
                raise ValueError(f"MPS line {lineno}: malformed BOUNDS record")
            btyp = toks[0].upper()
            var = toks[2]
            value = q(toks[3]) if len(toks) >= 4 else None
            bounds_records.append((btyp, var, value))
            if var not in seen_vars:
                seen_vars.add(var)
                var_order.append(var)
            if btyp in {"BV", "LI", "UI", "SI"}:
                integer_vars.add(var)
            continue

        raise ValueError(
            f"MPS line {lineno}: data encountered in unsupported section {section}: {line}"
        )

    if ranges:
        raise ValueError(
            "This script deliberately rejects RANGES because exact row expansion "
            f"has not been requested; found {len(ranges)} ranged rows."
        )
    if obj_row is None:
        raise ValueError("No objective row found")

    variables: Dict[str, Var] = {}
    for name in var_order:
        variables[name] = Var(name=name, integer=(name in integer_vars))

    for btyp, name, value in bounds_records:
        v = variables[name]
        if btyp == "LO":
            v.lb = value
        elif btyp == "UP":
            v.ub = value
        elif btyp == "FX":
            v.lb = v.ub = value
        elif btyp == "FR":
            v.lb = v.ub = None
        elif btyp == "MI":
            v.lb = None
        elif btyp == "PL":
            v.ub = None
        elif btyp == "BV":
            v.integer = True
            v.lb, v.ub = Fraction(0), Fraction(1)
        elif btyp == "LI":
            v.integer = True
            v.lb = value
        elif btyp == "UI":
            v.integer = True
            v.ub = value
        else:
            raise ValueError(f"Unsupported exact BOUNDS type {btyp!r}")

    row_terms: Dict[str, Dict[str, Fraction]] = defaultdict(dict)
    for vname in var_order:
        for rname, coef in cols[vname].items():
            if coef == 0:
                continue
            if rname == obj_row:
                variables[vname].obj += coef
            else:
                row_terms[rname][vname] = coef

    rows: Dict[str, Row] = {}
    constraint_order = []
    for rname in row_order_all:
        typ = row_sense[rname]
        if typ == "N":
            continue
        if typ not in {"L", "G", "E"}:
            raise ValueError(f"Unsupported ROWS type {typ}")
        rows[rname] = Row(
            name=rname,
            sense=typ,
            rhs=rhs_values.get(rname, Fraction(0)),
            terms=row_terms.get(rname, {}),
        )
        constraint_order.append(rname)

    # MPS objective RHS convention contributes the negative of RHS[obj_row].
    obj_constant = -rhs_values.get(obj_row, Fraction(0))

    model = ExactMPS(
        name=model_name,
        sense=sense,
        obj_row=obj_row,
        obj_constant=obj_constant,
        vars=variables,
        var_order=var_order,
        rows=rows,
        row_order=constraint_order,
    )
    provenance = {
        "path": str(path),
        "compressed_sha256": sha256_bytes(raw),
        "uncompressed_sha256": sha256_bytes(payload),
        "uncompressed_bytes": len(payload),
    }
    return model, provenance


# ---------------------------------------------------------------------------
# Solution parser and exact audit
# ---------------------------------------------------------------------------

XML_VAR_RE = re.compile(
    r'<variable\s+[^>]*name="([^"]+)"[^>]*value="([^"]+)"', re.I
)
XML_OBJ_RE = re.compile(r'objectiveValue="([^"]+)"', re.I)


def parse_solution(path: Path) -> dict:
    raw, payload = read_gzip_or_plain(path)
    text = payload.decode("utf-8", errors="replace")
    values: Dict[str, Fraction] = {}
    objective_claim = None
    duplicate_values = []

    xm = XML_OBJ_RE.search(text)
    if xm:
        objective_claim = q(xm.group(1))

    for name, value in XML_VAR_RE.findall(text):
        value_q = q(value)
        if name in values and values[name] != value_q:
            duplicate_values.append((name, qstr(values[name]), qstr(value_q)))
        values[name] = value_q

    if not values:
        for line in text.splitlines():
            s = line.strip()
            if not s or s.startswith("#") or s.startswith("*"):
                continue

            om = re.search(
                r"objective(?:\s+value)?\s*[:=]\s*"
                r"([-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?)",
                s, re.I
            )
            if om:
                objective_claim = q(om.group(1))
                continue

            toks = s.split()
            if len(toks) >= 2:
                try:
                    value_q = q(toks[1])
                except Exception:
                    continue
                name = toks[0]
                if name in values and values[name] != value_q:
                    duplicate_values.append((name, qstr(values[name]), qstr(value_q)))
                values[name] = value_q

    return {
        "path": str(path),
        "compressed_sha256": sha256_bytes(raw),
        "uncompressed_sha256": sha256_bytes(payload),
        "objective_claim": objective_claim,
        "values": values,
        "duplicates": duplicate_values,
    }


def lhs_value(row: Row, values: Dict[str, Fraction]) -> Fraction:
    return sum((a * values.get(v, Fraction(0)) for v, a in row.terms.items()),
               Fraction(0))


def row_violation(row: Row, lhs: Fraction) -> Fraction:
    if row.sense == "L":
        return max(Fraction(0), lhs - row.rhs)
    if row.sense == "G":
        return max(Fraction(0), row.rhs - lhs)
    return abs(lhs - row.rhs)


def audit_solution(model: ExactMPS, sol: dict, topn: int = 40) -> dict:
    supplied = sol["values"]
    unknown = sorted(set(supplied) - set(model.vars))
    values = {v: supplied.get(v, Fraction(0)) for v in model.var_order}

    objective = model.obj_constant + sum(
        (model.vars[v].obj * values[v] for v in model.var_order), Fraction(0)
    )
    objective_binary = sum(
        (model.vars[v].obj * values[v]
         for v in model.var_order if model.vars[v].integer), Fraction(0)
    )
    objective_continuous = model.obj_constant + sum(
        (model.vars[v].obj * values[v]
         for v in model.var_order if not model.vars[v].integer), Fraction(0)
    )

    bound_bad = []
    integer_bad = []
    binary_bad = []
    for name, var in model.vars.items():
        x = values[name]
        if var.lb is not None and x < var.lb:
            bound_bad.append((name, "lower", qstr(x), qstr(var.lb), qstr(var.lb - x)))
        if var.ub is not None and x > var.ub:
            bound_bad.append((name, "upper", qstr(x), qstr(var.ub), qstr(x - var.ub)))
        if var.integer and x.denominator != 1:
            integer_bad.append((name, qstr(x)))
        if var.integer and var.lb == 0 and var.ub == 1 and x not in {0, 1}:
            binary_bad.append((name, qstr(x)))

    violations = []
    for rname in model.row_order:
        row = model.rows[rname]
        lhs = lhs_value(row, values)
        vio = row_violation(row, lhs)
        if vio:
            violations.append({
                "row": rname,
                "sense": row.sense,
                "lhs": qstr(lhs),
                "rhs": qstr(row.rhs),
                "violation": qstr(vio),
                "violation_decimal": qdecimal(vio),
            })
    violations.sort(key=lambda z: Fraction(z["violation"]), reverse=True)

    claimed = sol["objective_claim"]
    return {
        "path": sol["path"],
        "hashes": {
            "compressed_sha256": sol["compressed_sha256"],
            "uncompressed_sha256": sol["uncompressed_sha256"],
        },
        "listed_variable_count": len(supplied),
        "unknown_variables": unknown,
        "duplicate_assignments": sol["duplicates"],
        "objective_claim": None if claimed is None else qstr(claimed),
        "objective_from_saved_mps": qstr(objective),
        "objective_from_saved_mps_decimal": qdecimal(objective, 17),
        "objective_difference_claim_minus_computed":
            None if claimed is None else qstr(claimed - objective),
        "objective_decomposition": {
            "integer_variables": qstr(objective_binary),
            "continuous_variables_plus_constant": qstr(objective_continuous),
            "sum": qstr(objective),
        },
        "nearest_integer_to_computed_objective": round(float(objective)),
        "bound_violation_count": len(bound_bad),
        "integrality_violation_count": len(integer_bad),
        "binary_violation_count": len(binary_bad),
        "violated_row_count": len(violations),
        "maximum_exact_row_violation":
            "0" if not violations else violations[0]["violation"],
        "maximum_row_violation_decimal":
            0.0 if not violations else violations[0]["violation_decimal"],
        "bound_violations": bound_bad[:topn],
        "integrality_violations": integer_bad[:topn],
        "binary_violations": binary_bad[:topn],
        "largest_row_violations": violations[:topn],
        "_values": values,
    }


# ---------------------------------------------------------------------------
# Latent polygon/disjunction recovery
# ---------------------------------------------------------------------------

ORI_RE = re.compile(r"^n(\d+)_only_one_rotation(?:_low)?$")
CONT_RE = re.compile(r"^([xy])(\d+)_contenimento(?:_low)?$")
CHOICE_RE = re.compile(
    r"^i(\d+),r1([0-3]),j(\d+),r2([0-3])"
    r"vincoli_di_scelta_della_slice$"
)
NONOVERLAP_RE = re.compile(
    r"^i(\d+),r1([0-3]),j(\d+),r2([0-3]),s(\d+),k(\d+)"
    r"vincoli_di_non_sovrapposizione$"
)


def is_binary(v: Var) -> bool:
    return v.integer and v.lb == 0 and v.ub == 1


def linear_json(terms: Dict[str, Fraction]) -> List[dict]:
    return [{"var": v, "coef": qstr(a)} for v, a in sorted(terms.items())]


def recover_structure(model: ExactMPS) -> dict:
    errors = []
    warnings = []

    continuous = [v for v in model.var_order if not model.vars[v].integer]
    binary = [v for v in model.var_order if is_binary(model.vars[v])]

    orientation_rows: Dict[int, List[Row]] = defaultdict(list)
    containment_rows: Dict[int, List[Tuple[str, Row]]] = defaultdict(list)
    choice_rows = {}
    nonoverlap_rows = defaultdict(list)
    unclassified = []

    for rname in model.row_order:
        row = model.rows[rname]
        m = ORI_RE.match(rname)
        if m:
            orientation_rows[int(m.group(1))].append(row)
            continue
        m = CONT_RE.match(rname)
        if m:
            containment_rows[int(m.group(2))].append((m.group(1), row))
            continue
        m = CHOICE_RE.match(rname)
        if m:
            key = tuple(map(int, m.groups()))
            if key in choice_rows:
                errors.append(f"duplicate choice row key {key}")
            choice_rows[key] = row
            continue
        m = NONOVERLAP_RE.match(rname)
        if m:
            i, ri, j, rj, s, k = map(int, m.groups())
            nonoverlap_rows[(i, ri, j, rj, s)].append((k, row))
            continue
        unclassified.append(rname)

    # Recover orientation variables from the common four binary variables in
    # each polygon's only-one-rotation rows. Rotation numbering is recovered
    # from choice-row names and positive coefficients.
    polygon_orientation_sets: Dict[int, set] = {}
    for i, rows in sorted(orientation_rows.items()):
        sets = []
        for row in rows:
            b = {v for v, a in row.terms.items()
                 if a != 0 and is_binary(model.vars[v])}
            sets.append(b)
        if not sets:
            errors.append(f"polygon {i}: no orientation row terms")
            continue
        common = set.intersection(*sets)
        polygon_orientation_sets[i] = common
        if len(common) != 4:
            errors.append(
                f"polygon {i}: expected four orientation binaries, got {sorted(common)}"
            )

    orientation: Dict[int, Dict[int, str]] = defaultdict(dict)
    choice_slices: Dict[Tuple[int, int, int, int], List[str]] = {}

    for key, row in sorted(choice_rows.items()):
        i, ri, j, rj = key
        positive = {v for v, a in row.terms.items() if a == 1}
        negative = {v for v, a in row.terms.items() if a == -1}
        other = {v: a for v, a in row.terms.items() if a not in {1, -1}}

        if row.sense != "L" or row.rhs != 1 or other:
            errors.append(
                f"{row.name}: expected +orientation +orientation -slices <= 1"
            )
            continue

        pi = positive & polygon_orientation_sets.get(i, set())
        pj = positive & polygon_orientation_sets.get(j, set())
        if len(pi) != 1 or len(pj) != 1 or len(positive) != 2:
            errors.append(
                f"{row.name}: cannot identify its two orientation variables; "
                f"positive={sorted(positive)}"
            )
            continue

        vi, vj = next(iter(pi)), next(iter(pj))
        if ri in orientation[i] and orientation[i][ri] != vi:
            errors.append(f"orientation conflict for polygon {i}, rotation {ri}")
        if rj in orientation[j] and orientation[j][rj] != vj:
            errors.append(f"orientation conflict for polygon {j}, rotation {rj}")
        orientation[i][ri] = vi
        orientation[j][rj] = vj
        choice_slices[key] = sorted(negative)

    for i in range(7):
        if set(orientation.get(i, {})) != {0, 1, 2, 3}:
            errors.append(
                f"polygon {i}: incomplete rotation map {orientation.get(i, {})}"
            )

    # Translation variables are recovered from named containment rows.
    translations: Dict[int, Dict[str, str]] = defaultdict(dict)
    for i, xr in sorted(containment_rows.items()):
        for axis, row in xr:
            cvars = [v for v, a in row.terms.items()
                     if a and not model.vars[v].integer]
            if len(cvars) != 1:
                errors.append(
                    f"{row.name}: expected one continuous translation variable, "
                    f"found {cvars}"
                )
                continue
            v = cvars[0]
            old = translations[i].get(axis)
            if old is not None and old != v:
                errors.append(
                    f"polygon {i}: inconsistent {axis} variable {old} versus {v}"
                )
            translations[i][axis] = v

    for i in range(7):
        if set(translations.get(i, {})) != {"x", "y"}:
            errors.append(f"polygon {i}: incomplete translation pair")

    recovered_translation_vars = {
        translations[i][a] for i in translations for a in translations[i]
    }
    if recovered_translation_vars != set(continuous):
        errors.append(
            "continuous variables are not exactly the recovered 14 translations: "
            f"continuous={continuous}, recovered={sorted(recovered_translation_vars)}"
        )

    orientation_vars = {
        orientation[i][r] for i in orientation for r in orientation[i]
    }

    # Recover slice -> choice and slice -> halfspaces incidence.
    slice_choice: Dict[str, Tuple[int, int, int, int]] = {}
    for key, slices in choice_slices.items():
        for z in slices:
            if z in slice_choice and slice_choice[z] != key:
                errors.append(f"slice {z} occurs in multiple choice groups")
            slice_choice[z] = key

    halfspaces_by_slice = defaultdict(list)
    row_to_slice = {}
    latent_groups = []

    for key, slices in sorted(choice_slices.items()):
        i, ri, j, rj = key
        slice_entries = []
        for s_index, z in enumerate(slices):
            # The row's textual s-number need not equal the position after
            # lexical sorting, so locate the actual non-overlap group by z.
            candidates = []
            for nkey, krows in nonoverlap_rows.items():
                if nkey[:4] != key:
                    continue
                for k, row in krows:
                    if z in row.terms:
                        candidates.append((nkey, k, row))

            if not candidates:
                errors.append(f"slice {z}: no non-overlap rows")
                continue

            names_s = {c[0][4] for c in candidates}
            if len(names_s) != 1:
                errors.append(
                    f"slice {z}: associated with multiple textual slice indices "
                    f"{sorted(names_s)}"
                )

            hs = []
            for nkey, k, row in sorted(candidates, key=lambda t: t[1]):
                integer_terms = {
                    v: a for v, a in row.terms.items() if model.vars[v].integer
                }
                continuous_terms = {
                    v: a for v, a in row.terms.items() if not model.vars[v].integer
                }
                if set(integer_terms) != {z}:
                    errors.append(
                        f"{row.name}: expected sole integer term {z}, got "
                        f"{sorted(integer_terms)}"
                    )
                    continue
                M = integer_terms[z]
                if row.sense != "L" or M <= 0:
                    errors.append(
                        f"{row.name}: expected A*x + positive_M*z <= rhs"
                    )
                # z=1 activates A*x <= rhs-M.
                active_rhs = row.rhs - M
                hs.append({
                    "k": k,
                    "source_row": row.name,
                    "terms": continuous_terms,
                    "active_rhs": active_rhs,
                    "inactive_rhs": row.rhs,
                    "M": M,
                })
                row_to_slice[row.name] = z
                halfspaces_by_slice[z].append(row.name)

            slice_entries.append({
                "slice_var": z,
                "textual_slice_index":
                    None if not names_s else next(iter(names_s)),
                "halfspaces": hs,
            })

        latent_groups.append({
            "i": i, "ri": ri, "j": j, "rj": rj,
            "orientation_i": orientation.get(i, {}).get(ri),
            "orientation_j": orientation.get(j, {}).get(rj),
            "slices": slice_entries,
        })

    all_slice_vars = set(slice_choice)
    expected_integer_vars = orientation_vars | all_slice_vars
    actual_integer_vars = {v for v in model.var_order if model.vars[v].integer}
    if expected_integer_vars != actual_integer_vars:
        errors.append(
            "integer columns are not exactly orientations plus recovered slices; "
            f"unrecovered={sorted(actual_integer_vars - expected_integer_vars)[:20]}, "
            f"unexpected={sorted(expected_integer_vars - actual_integer_vars)[:20]}"
        )

    # Check exact incidence of each slice column.
    column_rows = defaultdict(set)
    for rname, row in model.rows.items():
        for v, a in row.terms.items():
            if a:
                column_rows[v].add(rname)

    for z in sorted(all_slice_vars):
        expected = {choice_rows[slice_choice[z]].name} | set(halfspaces_by_slice[z])
        actual = column_rows[z]
        if expected != actual:
            errors.append(
                f"slice {z}: unexpected incidence; "
                f"extra={sorted(actual - expected)}, missing={sorted(expected - actual)}"
            )

    expected_classified = (
        sum(len(x) for x in orientation_rows.values())
        + sum(len(x) for x in containment_rows.values())
        + len(choice_rows)
        + sum(len(x) for x in nonoverlap_rows.values())
    )
    if unclassified:
        errors.append(f"unclassified rows: {unclassified[:20]}")

    # Validate each only-one family as equivalent to sum_r o_ir <= 1,
    # optionally accompanied by the redundant lower bound sum_r o_ir >= 0.
    top_level_ok = True
    orientation_row_descriptions = {}
    for i in range(7):
        oset = polygon_orientation_sets.get(i, set())
        desc = []
        has_upper = False
        for row in orientation_rows.get(i, []):
            terms = {v: a for v, a in row.terms.items() if a}
            desc.append({
                "name": row.name,
                "sense": row.sense,
                "rhs": qstr(row.rhs),
                "terms": linear_json(terms),
            })
            if (row.sense == "L" and row.rhs == 1
                    and set(terms) == oset
                    and all(a == 1 for a in terms.values())):
                has_upper = True
        if not has_upper:
            top_level_ok = False
            errors.append(f"polygon {i}: no exact sum of four rotations <= 1 row")
        orientation_row_descriptions[i] = desc

    pair_keys = {(g["i"], g["ri"], g["j"], g["rj"]) for g in latent_groups}
    expected_pair_keys = {
        (i, ri, j, rj)
        for i in range(7) for j in range(i)
        for ri in range(4) for rj in range(4)
    }
    if pair_keys != expected_pair_keys:
        errors.append(
            f"expected 21*16=336 pair/orientation groups, found {len(pair_keys)}"
        )

    structure = {
        "errors": errors,
        "warnings": warnings,
        "counts": {
            "continuous_variables": len(continuous),
            "binary_variables": len(actual_integer_vars),
            "orientation_variables": len(orientation_vars),
            "slice_variables": len(all_slice_vars),
            "orientation_rows": sum(len(x) for x in orientation_rows.values()),
            "containment_rows": sum(len(x) for x in containment_rows.values()),
            "choice_rows": len(choice_rows),
            "nonoverlap_rows": sum(len(x) for x in nonoverlap_rows.values()),
            "classified_rows": expected_classified,
            "unclassified_rows": len(unclassified),
            "pair_orientation_groups": len(latent_groups),
        },
        "translations": {
            str(i): translations.get(i, {}) for i in range(7)
        },
        "orientations": {
            str(i): {str(r): orientation.get(i, {}).get(r) for r in range(4)}
            for i in range(7)
        },
        "orientation_rows": orientation_row_descriptions,
        "outer_choice_claim": {
            "proved_at_most_one_orientation_per_polygon": top_level_ok,
            "states_per_polygon": 5 if top_level_ok else None,
            "maximum_outer_assignments": 5 ** 7 if top_level_ok else None,
            "qualification":
                "This counts only absent-or-one-of-four-orientations. Each active "
                "polygon pair still has a finite disjunction of slice regions, "
                "and the objective also depends on the 14 translations."
        },
        "groups": latent_groups,
        "_orientation": orientation,
        "_translations": translations,
        "_orientation_vars": orientation_vars,
        "_slice_vars": all_slice_vars,
        "_containment_rows": containment_rows,
    }
    return structure


# ---------------------------------------------------------------------------
# Exact box extraction and proof that z=0 big-M rows are redundant
# ---------------------------------------------------------------------------

def interval_intersect(
    old: Tuple[Optional[Fraction], Optional[Fraction]],
    new: Tuple[Optional[Fraction], Optional[Fraction]]
) -> Tuple[Optional[Fraction], Optional[Fraction]]:
    lo1, hi1 = old
    lo2, hi2 = new
    lo = lo2 if lo1 is None else lo1 if lo2 is None else max(lo1, lo2)
    hi = hi2 if hi1 is None else hi1 if hi2 is None else min(hi1, hi2)
    return lo, hi


def state_bounds(
    model: ExactMPS,
    structure: dict,
    polygon: int,
    state: Optional[int],       # None=absent; otherwise rotation 0..3
) -> Dict[str, Tuple[Optional[Fraction], Optional[Fraction]]]:
    orientation = structure["_orientation"]
    translations = structure["_translations"]
    result = {}

    oval = {
        orientation[polygon][r]: Fraction(int(state == r))
        for r in range(4)
    }

    for axis in ("x", "y"):
        vname = translations[polygon][axis]
        var = model.vars[vname]
        bounds = (var.lb, var.ub)

        for row_axis, row in structure["_containment_rows"][polygon]:
            if row_axis != axis:
                continue
            a = row.terms.get(vname, Fraction(0))
            if a == 0:
                raise ValueError(f"{row.name}: zero translation coefficient")
            constant = sum(
                (coef * oval.get(v, Fraction(0))
                 for v, coef in row.terms.items() if v != vname),
                Fraction(0),
            )
            rhs = row.rhs - constant

            # a*x <=/>=/= rhs
            candidates = []
            if row.sense in {"L", "E"}:
                if a > 0:
                    candidates.append((None, rhs / a))
                else:
                    candidates.append((rhs / a, None))
            if row.sense in {"G", "E"}:
                if a > 0:
                    candidates.append((rhs / a, None))
                else:
                    candidates.append((None, rhs / a))
            for b in candidates:
                bounds = interval_intersect(bounds, b)

        lo, hi = bounds
        if lo is not None and hi is not None and lo > hi:
            raise ValueError(
                f"polygon {polygon}, state {state}, axis {axis}: empty containment "
                f"interval [{qstr(lo)}, {qstr(hi)}]"
            )
        result[vname] = bounds
    return result


def prove_inactive_redundancy(model: ExactMPS, structure: dict) -> dict:
    """
    A slice with z=0 leaves A*x <= rhs. To replace the original binary model
    by a guarded OR-of-AND formula, every such inactive inequality must be
    redundant. We prove that by exact interval maximization over the union of
    all five containment boxes for each polygon.

    Since each no-overlap row is linear in translations, maximizing over the
    coordinate-wise hull is conservative. If the test succeeds, it is a valid
    exact proof of redundancy; failure does not prove non-redundancy.
    """
    state_boxes = {}
    hull = {}

    for i in range(7):
        state_boxes[i] = {}
        for state in [None, 0, 1, 2, 3]:
            state_boxes[i][state] = state_bounds(model, structure, i, state)

        for v in structure["_translations"][i].values():
            lows = [state_boxes[i][s][v][0] for s in [None, 0, 1, 2, 3]]
            highs = [state_boxes[i][s][v][1] for s in [None, 0, 1, 2, 3]]
            if any(x is None for x in lows) or any(x is None for x in highs):
                hull[v] = (None, None)
            else:
                hull[v] = (min(lows), max(highs))

    failures = []
    checked = 0
    worst_margin = None

    for group in structure["groups"]:
        for sl in group["slices"]:
            for hs in sl["halfspaces"]:
                checked += 1
                maximum = Fraction(0)
                finite = True
                for v, a in hs["terms"].items():
                    lo, hi = hull.get(v, (None, None))
                    endpoint = hi if a >= 0 else lo
                    if endpoint is None:
                        finite = False
                        break
                    maximum += a * endpoint
                if not finite:
                    failures.append({
                        "row": hs["source_row"],
                        "reason": "unbounded interval hull",
                    })
                    continue
                margin = hs["inactive_rhs"] - maximum
                if worst_margin is None or margin < worst_margin:
                    worst_margin = margin
                if margin < 0:
                    failures.append({
                        "row": hs["source_row"],
                        "slice": sl["slice_var"],
                        "max_Ax": qstr(maximum),
                        "inactive_rhs": qstr(hs["inactive_rhs"]),
                        "excess": qstr(-margin),
                    })

    boxes_json = {}
    for i in range(7):
        boxes_json[str(i)] = {}
        for state in [None, 0, 1, 2, 3]:
            label = "absent" if state is None else str(state)
            boxes_json[str(i)][label] = {
                v: [
                    None if lo is None else qstr(lo),
                    None if hi is None else qstr(hi),
                ]
                for v, (lo, hi) in state_boxes[i][state].items()
            }

    return {
        "proved": not failures,
        "checked_nonoverlap_rows": checked,
        "failure_count": len(failures),
        "failures": failures[:100],
        "minimum_redundancy_margin":
            None if worst_margin is None else qstr(worst_margin),
        "state_containment_boxes": boxes_json,
        "_state_boxes": state_boxes,
    }


# ---------------------------------------------------------------------------
# Reduced exact SMT
# ---------------------------------------------------------------------------

import itertools


def smt_symbol(name: str) -> str:
    """Quote an SMT-LIB identifier only when necessary."""
    if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.$-]*", name):
        return name
    return "|" + name.replace("\\", "\\\\").replace("|", "\\|") + "|"


def smt_sum(parts: Sequence[str]) -> str:
    parts = list(parts)
    if not parts:
        return "0"
    if len(parts) == 1:
        return parts[0]
    return "(+ " + " ".join(parts) + ")"


def smt_linear_expression(
    terms: Dict[str, Fraction],
    boolean_variables: set,
    constant: Fraction = Fraction(0),
) -> str:
    parts = []
    if constant:
        parts.append(smtq(constant))

    for name, coef in sorted(terms.items()):
        if coef == 0:
            continue
        symbol = smt_symbol(name)
        atom = f"(ite {symbol} 1 0)" if name in boolean_variables else symbol
        if coef == 1:
            parts.append(atom)
        elif coef == -1:
            parts.append(f"(- {atom})")
        else:
            parts.append(f"(* {smtq(coef)} {atom})")
    return smt_sum(parts)


def smt_assert_row(
    row: Row,
    boolean_variables: set,
    terms_override: Optional[Dict[str, Fraction]] = None,
    rhs_override: Optional[Fraction] = None,
) -> str:
    terms = row.terms if terms_override is None else terms_override
    rhs = row.rhs if rhs_override is None else rhs_override
    lhs = smt_linear_expression(terms, boolean_variables)

    if row.sense == "L":
        relation = "<="
    elif row.sense == "G":
        relation = ">="
    elif row.sense == "E":
        relation = "="
    else:
        raise ValueError(f"unknown row sense {row.sense!r}")
    return f"(assert ({relation} {lhs} {smtq(rhs)}))"


def active_halfspace_formula(hs: dict) -> str:
    lhs = smt_linear_expression(hs["terms"], set())
    return f"(<= {lhs} {smtq(hs['active_rhs'])})"


def conjunction(parts: Sequence[str]) -> str:
    parts = list(parts)
    if not parts:
        return "true"
    if len(parts) == 1:
        return parts[0]
    return "(and " + " ".join(parts) + ")"


def disjunction(parts: Sequence[str]) -> str:
    parts = list(parts)
    if not parts:
        return "false"
    if len(parts) == 1:
        return parts[0]
    return "(or " + " ".join(parts) + ")"


def infer_exact_outer_state(structure: dict, values: Dict[str, Fraction]) -> dict:
    states = {}
    invalid = []

    for i in range(7):
        orientation = structure["_orientation"][i]
        missing = [r for r in range(4) if r not in orientation]
        if missing:
            states[i] = None
            invalid.append({
                "polygon": i,
                "reason": "incomplete orientation recovery",
                "missing_rotations": missing,
                "recovered_orientation_variables": {
                    str(r): orientation[r] for r in sorted(orientation)
                },
            })
            continue

        vals = {r: values.get(orientation[r], Fraction(0)) for r in range(4)}
        ones = [r for r, value in vals.items() if value == 1]
        zeros_ok = all(value in {0, 1} for value in vals.values())

        if zeros_ok and not ones:
            states[i] = None
        elif zeros_ok and len(ones) == 1:
            states[i] = ones[0]
        else:
            states[i] = None
            invalid.append({
                "polygon": i,
                "orientation_values": {
                    str(r): qstr(vals[r]) for r in range(4)
                },
            })

    return {
        "states": states,
        "invalid": invalid,
        "exact": not invalid,
    }


def emit_reduced_smt(
    path: Path,
    model: ExactMPS,
    structure: dict,
    *,
    fixed_states: Optional[Dict[int, Optional[int]]] = None,
    invalid_fixed_state: bool = False,
    strict_objective_upper: Optional[Fraction] = None,
    include_values: bool = True,
) -> None:
    """
    Emit an exact existential QF_LRA encoding after eliminating all slice
    binaries. This is valid only after prove_inactive_redundancy() succeeds.

    For an active pair/orientation, each original slice variable selects one
    conjunction of active halfspaces. Existential elimination therefore gives
    an OR of those conjunctions. Boundary equality is accepted because every
    original active inequality is non-strict <=.
    """
    orientation_vars = set(structure["_orientation_vars"])
    translation_vars = sorted(
        v for i in range(7) for v in structure["_translations"][i].values()
    )

    lines = [
        "; Exact reduced encoding of the saved polygonpack4-7 MPS decimals.",
        "; All decimal MPS tokens were converted to exact rationals.",
        "; This establishes properties of the saved linear model, not of",
        "; unrounded source polygons that may have generated its coefficients.",
        "; Contact/boundary equality is feasible: active halfspaces use <=.",
        "(set-logic QF_LRA)",
        "(set-option :produce-models true)",
    ]

    for name in translation_vars:
        lines.append(f"(declare-fun {smt_symbol(name)} () Real)")
    for name in sorted(orientation_vars):
        lines.append(f"(declare-fun {smt_symbol(name)} () Bool)")

    lines.append("")
    lines.append("; Explicit MPS variable bounds on translations.")
    for name in translation_vars:
        var = model.vars[name]
        symbol = smt_symbol(name)
        if var.lb is not None:
            lines.append(f"(assert (>= {symbol} {smtq(var.lb)}))")
        if var.ub is not None:
            lines.append(f"(assert (<= {symbol} {smtq(var.ub)}))")

    lines.append("")
    lines.append("; At most one of four rotations for each polygon.")
    for i in range(7):
        bools = [
            smt_symbol(structure["_orientation"][i][r])
            for r in range(4)
        ]
        cardinality = smt_sum([f"(ite {b} 1 0)" for b in bools])
        lines.append(f"(assert (<= {cardinality} 1))")

    lines.append("")
    lines.append("; Original saved-MPS containment rows.")
    for i in range(7):
        for _, row in structure["_containment_rows"][i]:
            lines.append(smt_assert_row(row, orientation_vars))

    if fixed_states is not None:
        lines.append("")
        lines.append("; Exact absent/orientation assignment fixed from an incumbent.")
        if invalid_fixed_state:
            lines.append(
                "; The incumbent did not give an exact binary outer assignment."
            )
            lines.append("(assert false)")
        else:
            for i in range(7):
                state = fixed_states[i]
                for r in range(4):
                    symbol = smt_symbol(structure["_orientation"][i][r])
                    lines.append(
                        f"(assert {symbol})" if state == r
                        else f"(assert (not {symbol}))"
                    )

    lines.append("")
    lines.append("; Pairwise no-fit-region disjunctions.")
    for group in structure["groups"]:
        oi = smt_symbol(group["orientation_i"])
        oj = smt_symbol(group["orientation_j"])

        slice_formulas = []
        for sl in group["slices"]:
            halfspaces = [
                active_halfspace_formula(hs) for hs in sl["halfspaces"]
            ]
            slice_formulas.append(conjunction(halfspaces))

        pair_formula = disjunction(slice_formulas)
        lines.append(
            f"; polygons {group['i']},{group['j']} rotations "
            f"{group['ri']},{group['rj']}; {len(slice_formulas)} slices"
        )
        lines.append(f"(assert (=> (and {oi} {oj}) {pair_formula}))")

    objective_terms = {
        name: model.vars[name].obj
        for name in translation_vars + sorted(orientation_vars)
        if model.vars[name].obj
    }
    objective_expression = smt_linear_expression(
        objective_terms,
        orientation_vars,
        model.obj_constant,
    )
    lines.extend([
        "",
        "; Objective of the saved MPS, retained as an exact rational expression.",
        f"(define-fun objective () Real {objective_expression})",
    ])

    if strict_objective_upper is not None:
        lines.extend([
            "",
            "; Strict minimization cutoff: existence of a solution better than B.",
            f"; B = {qstr(strict_objective_upper)}",
            f"(assert (< objective {smtq(strict_objective_upper)}))",
        ])

    lines.append("")
    lines.append("(check-sat)")
    if include_values:
        query_symbols = [smt_symbol(v) for v in translation_vars]
        query_symbols += [smt_symbol(v) for v in sorted(orientation_vars)]
        query_symbols.append("objective")
        lines.append("(get-value (" + " ".join(query_symbols) + "))")
    lines.append("(exit)")

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


# ---------------------------------------------------------------------------
# Reduced geometric audit of incumbents
# ---------------------------------------------------------------------------

def audit_reduced_geometry(
    model: ExactMPS,
    structure: dict,
    values: Dict[str, Fraction],
    near_boundary: Fraction = Fraction(1, 10_000_000),
) -> dict:
    state_info = infer_exact_outer_state(structure, values)
    states = state_info["states"]

    selected = {}
    for i in range(7):
        orientation = structure["_orientation"].get(i, {})
        translation = structure["_translations"].get(i, {})
        xvar = translation.get("x")
        yvar = translation.get("y")
        selected[str(i)] = {
            "state": "invalid" if any(
                item["polygon"] == i for item in state_info["invalid"]
            ) else ("absent" if states[i] is None else states[i]),
            "x_variable": xvar,
            "x": None if xvar is None else qstr(values.get(xvar, Fraction(0))),
            "y_variable": yvar,
            "y": None if yvar is None else qstr(values.get(yvar, Fraction(0))),
            "orientations": {
                str(r): (
                    {
                        "variable": orientation[r],
                        "value": qstr(values.get(orientation[r], Fraction(0))),
                    }
                    if r in orientation
                    else {
                        "variable": None,
                        "value": None,
                        "recovery": "missing",
                    }
                )
                for r in range(4)
            },
        }

    active_group_count = 0
    failed_groups = []
    satisfying_groups = []
    exact_boundary_halfspaces = []
    near_boundary_halfspaces = []
    minimum_satisfied_slack = None

    if state_info["exact"]:
        group_lookup = {
            (g["i"], g["ri"], g["j"], g["rj"]): g
            for g in structure["groups"]
        }

        for i in range(7):
            if states[i] is None:
                continue
            for j in range(i):
                if states[j] is None:
                    continue

                active_group_count += 1
                key = (i, states[i], j, states[j])
                group = group_lookup.get(key)
                if group is None:
                    failed_groups.append({
                        "key": list(key),
                        "reason": "missing recovered disjunction group",
                    })
                    continue

                satisfied_slices = []
                best_slice_max_violation = None

                for sl in group["slices"]:
                    all_satisfied = True
                    slice_max_violation = Fraction(0)
                    halfspace_results = []

                    for hs in sl["halfspaces"]:
                        lhs = sum(
                            (a * values[v] for v, a in hs["terms"].items()),
                            Fraction(0),
                        )
                        slack = hs["active_rhs"] - lhs
                        violation = max(Fraction(0), -slack)
                        slice_max_violation = max(slice_max_violation, violation)
                        if slack < 0:
                            all_satisfied = False
                        else:
                            if minimum_satisfied_slack is None or slack < minimum_satisfied_slack:
                                minimum_satisfied_slack = slack

                        result = {
                            "row": hs["source_row"],
                            "lhs": qstr(lhs),
                            "rhs": qstr(hs["active_rhs"]),
                            "slack": qstr(slack),
                            "slack_decimal": qdecimal(slack),
                        }
                        halfspace_results.append(result)

                        if slack == 0:
                            exact_boundary_halfspaces.append({
                                "pair_orientation": list(key),
                                "slice": sl["slice_var"],
                                **result,
                            })
                        elif 0 < slack <= near_boundary:
                            near_boundary_halfspaces.append({
                                "pair_orientation": list(key),
                                "slice": sl["slice_var"],
                                **result,
                            })

                    if best_slice_max_violation is None:
                        best_slice_max_violation = slice_max_violation
                    else:
                        best_slice_max_violation = min(
                            best_slice_max_violation, slice_max_violation
                        )

                    if all_satisfied:
                        satisfied_slices.append({
                            "slice_variable": sl["slice_var"],
                            "textual_slice_index": sl["textual_slice_index"],
                            "halfspaces": halfspace_results,
                        })

                if satisfied_slices:
                    satisfying_groups.append({
                        "key": list(key),
                        "satisfying_slice_count": len(satisfied_slices),
                        "satisfying_slices": satisfied_slices,
                    })
                else:
                    failed_groups.append({
                        "key": list(key),
                        "reason": "no exact active slice conjunction is satisfied",
                        "minimum_slice_max_violation":
                            None if best_slice_max_violation is None
                            else qstr(best_slice_max_violation),
                    })

    return {
        "exact_outer_state": state_info["exact"],
        "invalid_outer_state_entries": state_info["invalid"],
        "polygons": selected,
        "active_pair_count": active_group_count,
        "satisfied_active_pair_count": len(satisfying_groups),
        "failed_active_pair_count": len(failed_groups),
        "failed_active_pairs": failed_groups,
        "active_pair_slice_witnesses": satisfying_groups,
        "minimum_nonnegative_active_halfspace_slack":
            None if minimum_satisfied_slack is None
            else qstr(minimum_satisfied_slack),
        "exact_boundary_halfspace_count": len(exact_boundary_halfspaces),
        "exact_boundary_halfspaces": exact_boundary_halfspaces,
        "near_boundary_threshold": qstr(near_boundary),
        "near_boundary_halfspace_count": len(near_boundary_halfspaces),
        "near_boundary_halfspaces": near_boundary_halfspaces,
        "boundary_semantics":
            "The saved MPS uses non-strict linear inequalities. Exact zero "
            "slack is therefore feasible in the saved model. This does not by "
            "itself establish the intended source geometry's convention after "
            "coefficient rounding.",
    }


# ---------------------------------------------------------------------------
# Complete outer-state and objective-layer enumeration
# ---------------------------------------------------------------------------

def continuous_box_objective_bound(
    model: ExactMPS,
    box: Dict[str, Tuple[Optional[Fraction], Optional[Fraction]]],
) -> Optional[Fraction]:
    value = Fraction(0)
    for name, (lo, hi) in box.items():
        coef = model.vars[name].obj
        if coef == 0:
            continue
        endpoint = lo if coef > 0 else hi
        if endpoint is None:
            return None
        value += coef * endpoint
    return value


def enumerate_outer_states(
    model: ExactMPS,
    structure: dict,
    redundancy: dict,
) -> dict:
    """
    Enumerate all 5^7 absent-or-oriented assignments.

    The containment-only lower bound minimizes the continuous objective over
    each polygon's recovered containment box independently. It ignores
    pairwise no-overlap clauses and is therefore a valid lower bound for a
    minimization problem whenever all required endpoints are finite.
    """
    state_boxes = redundancy["_state_boxes"]
    orientation = structure["_orientation"]
    state_values = [None, 0, 1, 2, 3]

    records = []
    layer_counts = defaultdict(int)
    bound_layer_counts = defaultdict(int)

    for states_tuple in itertools.product(state_values, repeat=7):
        orientation_objective = Fraction(0)
        continuous_bound = Fraction(0)
        finite = True
        selected_count = 0

        for i, state in enumerate(states_tuple):
            if state is not None:
                selected_count += 1
                orientation_objective += model.vars[orientation[i][state]].obj

            box_bound = continuous_box_objective_bound(
                model, state_boxes[i][state]
            )
            if box_bound is None:
                finite = False
            elif finite:
                continuous_bound += box_bound

        orientation_layer = model.obj_constant + orientation_objective
        total_bound = (
            None if not finite
            else model.obj_constant + orientation_objective + continuous_bound
        )

        layer_counts[qstr(orientation_layer)] += 1
        if total_bound is not None:
            bound_layer_counts[qstr(total_bound)] += 1

        records.append({
            "states": [
                "A" if state is None else state for state in states_tuple
            ],
            "selected_polygon_count": selected_count,
            "orientation_objective_plus_constant": qstr(orientation_layer),
            "containment_only_continuous_objective_bound":
                None if not finite else qstr(continuous_bound),
            "containment_only_total_objective_bound":
                None if total_bound is None else qstr(total_bound),
        })

    records.sort(
        key=lambda rec: (
            rec["containment_only_total_objective_bound"] is None,
            Fraction(rec["containment_only_total_objective_bound"])
            if rec["containment_only_total_objective_bound"] is not None
            else Fraction(0),
            tuple(str(x) for x in rec["states"]),
        )
    )

    orientation_layers = [
        {"objective": key, "assignment_count": count}
        for key, count in sorted(
            layer_counts.items(), key=lambda item: Fraction(item[0])
        )
    ]
    bound_layers = [
        {"lower_bound": key, "assignment_count": count}
        for key, count in sorted(
            bound_layer_counts.items(), key=lambda item: Fraction(item[0])
        )
    ]

    return {
        "state_encoding": {
            "A": "polygon absent",
            "0": "rotation 0 degrees",
            "1": "rotation 90 degrees",
            "2": "rotation 180 degrees",
            "3": "rotation 270 degrees",
        },
        "assignment_count": len(records),
        "expected_assignment_count": 5 ** 7,
        "orientation_objective_layer_count": len(orientation_layers),
        "containment_bound_layer_count": len(bound_layers),
        "orientation_objective_layers": orientation_layers,
        "containment_bound_layers": bound_layers,
        "assignments_sorted_by_containment_only_bound": records,
        "qualification":
            "This is complete for the seven absent/orientation decisions only. "
            "It is not a complete placement enumeration: translations remain "
            "continuous and every selected pair retains a no-fit-region "
            "disjunction. The listed total is a containment-only minimization "
            "lower bound and does not assert pairwise feasibility.",
    }


# ---------------------------------------------------------------------------
# Public JSON conversion and compact summaries
# ---------------------------------------------------------------------------

def public_data(value):
    """Remove private working fields and convert Fractions recursively."""
    if isinstance(value, Fraction):
        return qstr(value)
    if isinstance(value, dict):
        return {
            str(k): public_data(v)
            for k, v in value.items()
            if not str(k).startswith("_")
        }
    if isinstance(value, (list, tuple)):
        return [public_data(v) for v in value]
    if isinstance(value, set):
        return sorted(public_data(v) for v in value)
    return value


def model_summary(model: ExactMPS) -> dict:
    continuous = [
        name for name in model.var_order if not model.vars[name].integer
    ]
    integer = [
        name for name in model.var_order if model.vars[name].integer
    ]
    binaries = [
        name for name in integer if is_binary(model.vars[name])
    ]
    objective = [
        {
            "variable": name,
            "coefficient": qstr(model.vars[name].obj),
            "type": "integer" if model.vars[name].integer else "continuous",
        }
        for name in model.var_order if model.vars[name].obj
    ]

    senses = defaultdict(int)
    nonzeros = 0
    for row in model.rows.values():
        senses[row.sense] += 1
        nonzeros += len(row.terms)

    return {
        "name": model.name,
        "objective_sense": model.sense,
        "objective_row": model.obj_row,
        "objective_constant": qstr(model.obj_constant),
        "variable_count": len(model.vars),
        "continuous_variable_count": len(continuous),
        "integer_variable_count": len(integer),
        "binary_variable_count": len(binaries),
        "constraint_count": len(model.rows),
        "nonzero_count": nonzeros,
        "row_senses": dict(sorted(senses.items())),
        "objective_nonzero_count": len(objective),
        "objective_terms": objective,
    }


def safe_stem(path: Path) -> str:
    name = path.name
    if name.endswith(".gz"):
        name = name[:-3]
    name = re.sub(r"[^A-Za-z0-9_.-]+", "_", name)
    return name or "solution"


def write_incumbent_fixed_smt(
    path: Path,
    model: ExactMPS,
    structure: dict,
    audit: dict,
) -> dict:
    values = audit["_values"]
    state_info = infer_exact_outer_state(structure, values)
    emit_reduced_smt(
        path,
        model,
        structure,
        fixed_states=state_info["states"],
        invalid_fixed_state=not state_info["exact"],
    )
    return {
        "path": str(path),
        "exact_outer_assignment": state_info["exact"],
        "states": {
            str(i): (
                "absent" if state_info["states"][i] is None
                else state_info["states"][i]
            )
            for i in range(7)
        },
        "qualification":
            "Only absent/orientation Booleans are fixed. Translations remain "
            "existential, so SAT proves that some placement exists for that "
            "outer assignment in the reduced saved-MPS model. If the source "
            "solution's orientation entries were not exact binaries, the file "
            "contains (assert false) rather than silently rounding them.",
    }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Recover and exactly audit the latent polygon-packing structure "
            "of polygonpack4-7 without invoking a solver."
        )
    )
    parser.add_argument(
        "--mps",
        type=Path,
        required=True,
        help="Path to polygonpack4-7.mps or polygonpack4-7.mps.gz",
    )
    parser.add_argument(
        "--sol",
        type=Path,
        action="append",
        default=[],
        help=(
            "Public solution file to audit. Repeat for multiple files, e.g. "
            "public-4 and public-3."
        ),
    )
    parser.add_argument(
        "--out",
        type=Path,
        required=True,
        help="Output directory",
    )
    parser.add_argument(
        "--objective-upper",
        type=str,
        default=None,
        help=(
            "Generate a strict saved-MPS minimization query objective < B, "
            "with B parsed as an exact decimal/rational. Example: -51837708"
        ),
    )
    parser.add_argument(
        "--near-boundary",
        type=str,
        default="0.0000001",
        help=(
            "Exact positive slack threshold reported as near-boundary "
            "(default 1e-7)."
        ),
    )
    parser.add_argument(
        "--top-violations",
        type=int,
        default=50,
        help="Maximum number of detailed violations retained per incumbent",
    )
    parser.add_argument(
        "--no-outer-enumeration",
        action="store_true",
        help="Skip generation of the complete 5^7 outer-state table",
    )
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    args.out.mkdir(parents=True, exist_ok=True)

    cutoff = q(args.objective_upper) if args.objective_upper is not None else None
    near_boundary = q(args.near_boundary)
    if near_boundary < 0:
        raise ValueError("--near-boundary must be nonnegative")

    model, mps_provenance = parse_mps(args.mps)
    structure = recover_structure(model)

    if not model.sense.upper().startswith("MIN"):
        raise ValueError(
            f"expected minimization model, found objective sense {model.sense!r}"
        )

    redundancy = {
        "proved": False,
        "checked_nonoverlap_rows": 0,
        "failure_count": 0,
        "failures": [],
        "minimum_redundancy_margin": None,
        "state_containment_boxes": {},
        "_state_boxes": {},
    }
    if not structure["errors"]:
        redundancy = prove_inactive_redundancy(model, structure)

    solution_reports = []
    fixed_smt_reports = []
    generated_files = []

    for sol_path in args.sol:
        parsed = parse_solution(sol_path)
        audit = audit_solution(model, parsed, topn=args.top_violations)
        audit["reduced_geometry"] = audit_reduced_geometry(
            model,
            structure,
            audit["_values"],
            near_boundary=near_boundary,
        )
        solution_reports.append(audit)

    latent_path = args.out / "latent_geometry.json.gz"
    dump_json(
        latent_path,
        {
            "mps": mps_provenance,
            "model": model_summary(model),
            "structure": public_data(structure),
            "inactive_big_m_redundancy_proof": public_data(redundancy),
        },
        compress=True,
    )
    generated_files.append(str(latent_path))

    reduction_available = (
        not structure["errors"] and redundancy["proved"]
    )

    if reduction_available:
        reduced_path = args.out / "exact_reduced.smt2"
        emit_reduced_smt(reduced_path, model, structure)
        generated_files.append(str(reduced_path))

        for audit in solution_reports:
            stem = safe_stem(Path(audit["path"]))
            fixed_path = args.out / f"{stem}-orientation-fixed.smt2"
            fixed_report = write_incumbent_fixed_smt(
                fixed_path, model, structure, audit
            )
            fixed_smt_reports.append(fixed_report)
            generated_files.append(str(fixed_path))

        if cutoff is not None:
            cutoff_path = args.out / "exact_reduced_strict_objective_cutoff.smt2"
            emit_reduced_smt(
                cutoff_path,
                model,
                structure,
                strict_objective_upper=cutoff,
            )
            generated_files.append(str(cutoff_path))

    outer_report = None
    if (
        not args.no_outer_enumeration
        and not structure["errors"]
        and redundancy.get("_state_boxes")
    ):
        outer_report = enumerate_outer_states(model, structure, redundancy)
        outer_path = args.out / "outer_states_5pow7.json.gz"
        dump_json(outer_path, public_data(outer_report), compress=True)
        generated_files.append(str(outer_path))

    public_solution_reports = []
    for audit in solution_reports:
        clean = public_data(audit)
        public_solution_reports.append(clean)

        audit_path = args.out / f"{safe_stem(Path(audit['path']))}-audit.json"
        dump_json(audit_path, clean)
        generated_files.append(str(audit_path))

    conclusions = {
        "saved_mps_exactness":
            "Every finite numeric token read from the MPS and solution files "
            "was parsed as an exact Fraction. Reported exact violations and "
            "objectives therefore refer to the decimal coefficients physically "
            "saved in those files.",
        "latent_structure":
            (
                "The latent structure was recovered without errors."
                if not structure["errors"]
                else "Structural recovery found errors; inspect structure.errors."
            ),
        "outer_search":
            (
                "The seven orientation families each impose at most one of four "
                "orientation binaries, hence the outer absent-or-oriented state "
                "space has at most 5^7 = 78,125 assignments. This does not remove "
                "the continuous translations or pairwise slice disjunctions."
                if structure["outer_choice_claim"][
                    "proved_at_most_one_orientation_per_polygon"
                ]
                else
                "The script did not prove the claimed 5^7 outer-state bound."
            ),
        "slice_elimination":
            (
                "All inactive big-M no-overlap rows were proved redundant by "
                "exact interval bounds. Thus existential slice binaries are "
                "equivalent to the emitted guarded OR-of-AND active-halfspace "
                "formulas."
                if redundancy["proved"]
                else
                "Inactive-row redundancy was not proved, so no reduced SMT was "
                "emitted. A failed interval proof is not itself a disproof."
            ),
        "boundary_semantics":
            "All saved-MPS inequalities are non-strict. Equality on a recovered "
            "no-fit boundary is accepted by the saved model. The report separately "
            "lists exact and near boundary contacts; it makes no claim that these "
            "rounded inequalities exactly match the intended source polygons.",
        "strict_optimality":
            (
                "If an exact SMT(LRA) solver proves the generated strict cutoff "
                "query UNSAT, and its proof/certificate is independently checked, "
                "that excludes every saved-MPS solution with objective below the "
                f"exact bound {qstr(cutoff)}. It proves a statement about the "
                "saved coefficients, not unrounded intended geometry."
                if cutoff is not None and reduction_available
                else
                "No strict cutoff certificate is claimed by this extractor. "
                "A future UNSAT result for an emitted strict objective query must "
                "be accompanied by a checkable exact proof before being called "
                "an optimality certificate."
            ),
        "incumbent_audit":
            "Each solution's listed decimal values are treated exactly; omitted "
            "variables are assigned zero, following sparse SOL-file convention. "
            "The computed objective, decomposition, bounds, integrality, every "
            "saved row, selected rotations, translations, and active no-fit "
            "slice witnesses are audited independently.",
    }

    report = {
        "program": "polygonpack4-7 exact structural forensics",
        "mps": mps_provenance,
        "model": model_summary(model),
        "structure_summary": {
            "errors": structure["errors"],
            "warnings": structure["warnings"],
            "counts": structure["counts"],
            "translations": structure["translations"],
            "orientations": structure["orientations"],
            "outer_choice_claim": structure["outer_choice_claim"],
        },
        "inactive_big_m_redundancy_proof": public_data(redundancy),
        "reduced_smt_emitted": reduction_available,
        "strict_objective_upper":
            None if cutoff is None else qstr(cutoff),
        "solutions": public_solution_reports,
        "orientation_fixed_smt_queries": fixed_smt_reports,
        "outer_enumeration": (
            None if outer_report is None else {
                "assignment_count": outer_report["assignment_count"],
                "expected_assignment_count":
                    outer_report["expected_assignment_count"],
                "orientation_objective_layer_count":
                    outer_report["orientation_objective_layer_count"],
                "containment_bound_layer_count":
                    outer_report["containment_bound_layer_count"],
                "file": str(args.out / "outer_states_5pow7.json.gz"),
            }
        ),
        "generated_files": generated_files,
        "what_the_output_establishes": conclusions,
    }

    report_path = args.out / "report.json"
    generated_files.append(str(report_path))
    report["generated_files"] = generated_files
    dump_json(report_path, public_data(report))

    print(json.dumps({
        "report": str(report_path),
        "structural_errors": len(structure["errors"]),
        "inactive_big_m_redundancy_proved": redundancy["proved"],
        "reduced_smt_emitted": reduction_available,
        "solutions_audited": len(solution_reports),
        "outer_assignments_enumerated":
            0 if outer_report is None else outer_report["assignment_count"],
        "generated_files": generated_files,
    }, indent=2))

    if structure["errors"]:
        return 2
    if not redundancy["proved"]:
        return 3
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
