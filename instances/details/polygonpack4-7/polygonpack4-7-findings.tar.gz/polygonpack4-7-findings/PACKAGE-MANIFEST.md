# Package manifest: polygonpack4-7

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 122
Excluded source files: 1

## Included files

- `README.md`
- `SHA256SUMS`
- `analysis/candidate-exact-audit.json`
- `analysis/copy-symmetry-audit.json`
- `analysis/gurobi-13.0.1-structure.json`
- `analysis/objective-layer-screen.json`
- `analysis/official-4-copt-audit.json`
- `analysis/official-4-rounded-audit.json`
- `analysis/orientation-feasibility-1111001-summary.json`
- `analysis/presence-mask-search-summary.json`
- `analysis/structure-and-official-strict-audit.json`
- `analysis/structure-and-zero-tolerance-repair.json`
- `analysis/zero-tolerance-nfp-geometry-certificate.json`
- `analysis/zero-tolerance-repair-audit.json`
- `artifacts/polygonpack4-7-diagnostic.json.gz`
- `artifacts/public3-gurobi-audit.json`
- `artifacts/public4-gurobi-audit.json`
- `artifacts/repair-report.json`
- `artifacts/repaired-audit.json.gz`
- `artifacts/report.json`
- `artifacts/structure.compact.json`
- `experiments/audit_candidates.py`
- `experiments/certify_copy_symmetry.py`
- `experiments/copt_fix_and_reoptimize.py`
- `experiments/copt_full_probe.py`
- `experiments/copt_orientation_enumeration.py`
- `experiments/copt_subset_probe.py`
- `experiments/direct-1011111-feas-30s/copt.log`
- `experiments/direct-1011111-feas-30s/stdout.log`
- `experiments/direct-1011111-feas-30s/summary.json`
- `experiments/direct-1101101-feas-30s/copt.log`
- `experiments/direct-1101101-feas-30s/stdout.log`
- `experiments/direct-1101101-feas-30s/summary.json`
- `experiments/direct-1101110-feas-30s/copt.log`
- `experiments/direct-1101110-feas-30s/stdout.log`
- `experiments/direct-1101110-feas-30s/summary.json`
- `experiments/direct-1110011-feas-30s/copt.log`
- `experiments/direct-1110011-feas-30s/stdout.log`
- `experiments/direct-1110011-feas-30s/summary.json`
- `experiments/direct-1110101-feas-30s/copt.log`
- `experiments/direct-1110101-feas-30s/stdout.log`
- `experiments/direct-1110101-feas-30s/summary.json`
- `experiments/direct-1110110-feas-30s/copt.log`
- `experiments/direct-1110110-feas-30s/stdout.log`
- `experiments/direct-1110110-feas-30s/summary.json`
- `experiments/direct-1110111-feas-30s/copt.log`
- `experiments/direct-1110111-feas-30s/stdout.log`
- `experiments/direct-1110111-feas-30s/summary.json`
- `experiments/direct-1111010-feas-30s/copt.log`
- `experiments/direct-1111010-feas-30s/stdout.log`
- `experiments/direct-1111010-feas-30s/summary.json`
- `experiments/direct-1111100-feas-30s/copt.log`
- `experiments/direct-1111100-feas-30s/stdout.log`
- `experiments/direct-1111100-feas-30s/summary.json`
- `experiments/direct-1111101-feas-30s/copt.log`
- `experiments/direct-1111101-feas-30s/stdout.log`
- `experiments/direct-1111101-feas-30s/summary.json`
- `experiments/direct-1111110-feas-30s/copt.log`
- `experiments/direct-1111110-feas-30s/stdout.log`
- `experiments/direct-1111110-feas-30s/summary.json`
- `experiments/fixed_pattern_lp.py`
- `experiments/full-copt-600s-summary.json`
- `experiments/gurobi_structure_read.py`
- `experiments/make_geometry_certificate.py`
- `experiments/official-4-copt-summary.json`
- `experiments/orbit-search/orbit-0111111-feas-120s/copt.log`
- `experiments/orbit-search/orbit-0111111-feas-120s/summary.json`
- `experiments/orbit-search/orbit-1100111-feas-120s/copt.log`
- `experiments/orbit-search/orbit-1100111-feas-120s/summary.json`
- `experiments/orbit-search/orbit-1101011-feas-120s/copt.log`
- `experiments/orbit-search/orbit-1101011-feas-120s/summary.json`
- `experiments/orbit-search/orbit-1101111-feas-120s/copt.log`
- `experiments/orbit-search/orbit-1101111-feas-120s/summary.json`
- `experiments/orbit-search/orbit-1111011-feas-120s/copt.log`
- `experiments/orbit-search/orbit-1111011-feas-120s/summary.json`
- `experiments/orbit-search/orbit-1111111-feas-120s/copt.log`
- `experiments/orbit-search/orbit-1111111-feas-120s/summary.json`
- `experiments/orientation-enum-1111000/summary.json`
- `experiments/orientation-feas-1111001/shard0-summary.json`
- `experiments/orientation-feas-1111001/shard1-summary.json`
- `experiments/orientation-feas-1111001/shard2-summary.json`
- `experiments/orientation-feas-1111001/shard3-summary.json`
- `experiments/recover_geometry.py`
- `experiments/screen_object_subsets.py`
- `experiments/subset-1111000-300s-summary.json`
- `experiments/subset-1111001-180s-summary.json`
- `experiments/summarize_orientation_shards.py`
- `experiments/summarize_presence_search.py`
- `input/polygonpack4-7-public-3.sol.gz`
- `input/polygonpack4-7-public-4.sol.gz`
- `logs/copt72-invalid-license-launch.log`
- `logs/full-copt-600s.log`
- `logs/gurobi-13.0.1-structure.log`
- `logs/official-4-copt.log`
- `logs/official-4-fixed-lp.log`
- `logs/subset-1111000-300s.log`
- `logs/subset-1111001-180s.log`
- `scripts/exact_repair.py`
- `scripts/polygonpack_forensics.py`
- `scripts/polygonpack_gurobi_forensics.py`
- `scripts/round_sparse_solution.py`
- `solutions/full-copt-600s-incumbent.sol`
- `solutions/full-copt-600s-incumbent.validation.log`
- `solutions/official-2-strict.sol`
- `solutions/official-2-strict.sol.gz`
- `solutions/official-2-strict.validation.log`
- `solutions/official-2-zero-tolerance-repair.sol`
- `solutions/official-3-partimip.sol`
- `solutions/official-3-partimip.sol.gz`
- `solutions/official-3-partimip.validation.log`
- `solutions/official-3-rounded.sol`
- `solutions/official-4-copt-placement.sol`
- `solutions/official-4-cuopt.sol`
- `solutions/official-4-cuopt.sol.gz`
- `solutions/official-4-cuopt.validation.log`
- `solutions/official-4-rounded.sol`
- `solutions/official-4-rounded.validation.log`
- `solutions/orientation-enum-1111000-best-floating.sol`
- `solutions/polygonpack4-7-repaired.sol`
- `solutions/subset-1111000-300s-incumbent.sol`
- `solutions/subset-1111000-300s-incumbent.validation.log`
- `solutions/zero-tolerance-repair.validation.log`

## Excluded files

- `input/polygonpack4-7.mps.gz (1590083 bytes; raw benchmark input; sha256 dcbed0f1ef6230b21175b335eac5a552a59fc3f93cbba14e7933302958ca9cb5)`
