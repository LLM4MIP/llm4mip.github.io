# `ivu06`

## Result

The public-transit duty-scheduling set-partitioning instance remains open. This
study establishes the certified interval

```text
135.900242315 <= OPT <= 142.864331576.
```

The upper bound is the independently audited public exact cover. The lower
bound is the exact rational value

```text
27180048463 / 200000000 = 135.900242315.
```

An LP solve supplied candidate row multipliers. A separate streaming checker
then parsed every decimal coefficient of the original compressed MPS, rounded
the multipliers downward to denominator `10^9`, and verified all 787,239 dual
column inequalities in integer arithmetic. The minimum integer slack is 5,660.
The certificate is therefore a global lower bound, but it does not prove
optimality because it is below the incumbent.

## Structural work and limitations

Exact support hashing found 15,320 safely removable non-cheapest duplicate
columns. A custom incumbent-owner search completed all singleton, all 6,328
owner-pair, and 11,404 observed owner-triple repairs without improvement.
Columns involving four or more incumbent owners and unobserved triple
structures were outside that neighborhood, so this is local evidence only.

The 12 MB reduced-cost retained-column list and 3 MB detailed exchange ledger
were omitted as large regenerable outputs. The scripts, compact diagnostics,
row-dual witness, exact audit, and incumbent are retained.

## Provenance

- [MIPLIB instance page](https://miplib.zib.de/instance_details_ivu06.html)
- Original MPS SHA-256:
  `c1bc0aa446a73e76f0c17a332c543e2dd37b52ba5e024d1f0f8ea88c7d49a02c`
- Research date: 2026-09-09
- Investigation exceeded 60 minutes; the only generic optimization was one LP solve

## Recheck the exact dual

From this instance directory:

```powershell
python .\scripts\ivu06_exact_dual_audit.py `
  .\input\ivu06.mps.gz `
  .\artifacts\ivu06.row_dual.txt `
  --incumbent 142.864331576 `
  --out .\artifacts\ivu06.exact_dual.recheck.json
```

The output must report `all_dual_inequalities_verified: true` and lower-bound
numerator/denominator `27180048463 / 200000000`.

## Contents

- [`reports/final_report.md`](reports/final_report.md): full analysis
- [`reports/effort_ledger.md`](reports/effort_ledger.md): experiment accounting
- [`reports/background_and_sources.md`](reports/background_and_sources.md): application background
- [`artifacts/ivu06.row_dual.txt`](artifacts/ivu06.row_dual.txt): rationalized row multipliers
- [`artifacts/ivu06.exact_dual.json`](artifacts/ivu06.exact_dual.json): exact full-column audit
- [`artifacts/public_solution_audit.json`](artifacts/public_solution_audit.json): incumbent audit
- [`solutions/best_exchange.sol`](solutions/best_exchange.sol): duplicate-normalized incumbent, with no improvement claimed

