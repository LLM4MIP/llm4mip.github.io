# ivu06 background and sources

- MIPLIB: https://miplib.zib.de/instance_details_ivu06.html
- Weider dissertation: https://d-nb.info/985576340/34
- Historical large-set-partitioning local-search paper:
  https://www.kurims.kyoto-u.ac.jp/~kyodo/kokyuroku/contents/pdf/1879-09.pdf
- Historical Lagrangian/bundle-method report:
  https://www.zib.de/userpage/groetschel/students/ZR-01-06.pdf

MIPLIB classifies `ivu06` as an open binary set-partitioning instance produced
by a column-generation algorithm for public-transport duty scheduling. Its
current public incumbent is 142.864331576, found with Gurobi's solution
improvement heuristic in 2020. The MIPLIB page also records an earlier 25-day,
48-thread CPLEX calculation, but the current collection still labels the
instance open; therefore that historical statement is not treated as a
reproducible certificate.

The literature identifies the source as integrated vehicle and duty scheduling.
The relevant pricing problem is a resource-constrained shortest-path problem
whose difficult duty/break rules materially affect the lower bound. Historical
work on this family used Lagrangian relaxation with subgradient, coordinate
ascent, and bundle variants; another study used sparse, lazily generated
co-occurrence candidate lists for multi-flip local search on very large set
partitioning models.

The MPS in this experiment is the 787,239-column restricted master, not the
older 48,058-column model reported in early algorithm papers and not the
2,277,736-column `ivu06-big` sibling. Numerical claims for those variants are
background only and cannot certify this MPS.
