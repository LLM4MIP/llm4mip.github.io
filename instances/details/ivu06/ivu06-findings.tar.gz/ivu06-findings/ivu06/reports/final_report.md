# ivu06 Final Report

## Result

The incumbent remains the best known feasible solution: cost
**142.864331576**, using 113 columns and independently satisfying
`Ax = 1` exactly. This work established the exact rational lower bound

```text
135900242315 / 10^9 = 27180048463 / 200000000 = 135.900242315.
```

The certified interval is therefore
`[135.900242315, 142.864331576]`. The instance remains **open**.

## Background and structure

`ivu06` is a public-transit duty-scheduling set-partitioning restricted master
created by column generation. It contains 787,239 bounded integer `[0,1]`
columns, 1,177 equations `Ax=1`, and 8,032,303 matrix coefficients, all exactly
`+1`. Costs are positive and range from 0.620000005 to 8.0. Family literature
uses resource-constrained-shortest-path pricing with difficult break rules,
Lagrangian bundle/coordinate methods, and lazy co-occurrence multi-flip search.
Results for older or larger column pools are background only and do not certify
this exact MPS.

## Structural and primal attempts

- Exact support hashing found 771,919 distinct supports and 11,945 duplicate
  groups. Removing the 15,320 non-cheapest duplicate columns is globally safe;
  the incumbent uses none of them.
- A non-solver coordinate dual produced lower bound 98.66931907128631.
- An incumbent-owner exact-cover search completed all 113 singleton subsets,
  all 6,328 owner pairs, and 11,404 observed owner triples. Replacement
  cardinality was unrestricted within each repair. It found no improvement.

The neighborhood result is local evidence only. Columns touching at least four
incumbent owners and unobserved connected triple structures remain outside it.

## Global dual certificate

One permitted LP baseline closed in seconds at 135.90135263152175. The nominal
row dual had maximum original-column violation about `8.0e-7`. Uniform downward
repair followed by a complete 787,239-column recheck gave floating lower bound
135.90024288020211. Its reduced-cost threshold removed only 1,177 additional
columns, so it did not yield a useful small core.

A separate streaming checker then parsed the original compressed decimal MPS
without Gurobi, rounded every repaired multiplier downward to denominator
`10^9`, and verified all 787,239 inequalities using integer arithmetic. It
also checked all 1,177 RHS values, all 8,032,303 unit coefficients, objective
cost scale, integer markers, and exact MPS counts. The minimum integer slack is
5,660 at column `c645418`. Hence 135.900242315 is a portable globally valid
lower bound, independent of solver-reported floating feasibility.

This does not prove optimality because the bound is below the incumbent.

## Effort and limitations

API failures, parser defects, and a memory-heavy first checker were rejected
fail-closed and corrected using actual execution feedback. The only generic
solver optimization was the single LP solve, lasting seconds and staying far
below 30 minutes. Total investigation exceeded 60 minutes.

The best next route is exact RCSP pricing using the certified row dual, if the
original duty network and break-rule data can be recovered. Without that data,
the next restricted-master work should prioritize dual-guided connected
four-owner and higher-degree repairs and a proof-producing exact-cover search
on any sound reduced core. Every new duty, witness, and pruning bound must
continue to be checked against the original model.
