# Package manifest: ivu06

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 17
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/diagnostic.json`
- `artifacts/ivu06.exact_dual.json`
- `artifacts/ivu06.lp_dual.json`
- `artifacts/ivu06.row_dual.txt`
- `artifacts/public_solution_audit.json`
- `input/ivu06.public.sol.gz`
- `reports/background_and_sources.md`
- `reports/effort_ledger.md`
- `reports/final_report.md`
- `scripts/ivu06_diagnostic.py`
- `scripts/ivu06_exact_dual_audit.py`
- `scripts/ivu06_exchange.py`
- `scripts/ivu06_lp_dual.py`
- `solutions/best_exchange.sol`
- `structure/structure.compact.json`
- `structure/structure.json`

## Excluded files

- `input/ivu06.mps.gz (31873449 bytes; raw benchmark input; sha256 c1bc0aa446a73e76f0c17a332c543e2dd37b52ba5e024d1f0f8ea88c7d49a02c)`
