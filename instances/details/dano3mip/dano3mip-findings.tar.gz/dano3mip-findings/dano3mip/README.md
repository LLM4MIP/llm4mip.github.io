# `dano3mip`

## Result

A feasible solution with objective **664.02083333333337** is verified within `1.1e-12` row residual; no integrality or bound violations occur. The best Gurobi bound obtained with the public start was **578.2171855753**, so global optimality remains open.

The model has 3,202 rows, 13,873 columns and 79,655 nonzeros: 552 binary decisions and 13,321 continuous variables. Its first 48 pure-binary equations form a 24×24 selection structure with row and column sums equal to two. The network-structured LNS retained the incumbent and improved the experimental bound to about 590.661 during a short neighborhood run, but did not find a better feasible solution.

## Input

- SHA-256: `2684BF9265CE303A7A30B115B6CF2FAA60B3177620F95E52B444EEDC99B683A8`

## Files

- [verified solution](solutions/dano3mip-verified664.sol)
- [structure inspector](scripts/dano3mip_structure.py)
- [network LNS](scripts/dano3_network_lns.py)
- [Gurobi run with public start](logs/dano3mip-gurobi-known664-focus3.log)
- [network LNS log](logs/dano3mip-network-lns.log)

The stored decimal solution has tiny representation residuals below `1.1e-12`; these are far below the `1e-6` verification threshold but are not described as exact zero.
