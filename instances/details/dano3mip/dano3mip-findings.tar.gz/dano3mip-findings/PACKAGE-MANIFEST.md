# Package manifest: dano3mip

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 10
Excluded source files: 1

## Included files

- `README.md`
- `logs/dano3mip-copt-baseline.log`
- `logs/dano3mip-gurobi-baseline.log`
- `logs/dano3mip-gurobi-known664-focus3.log`
- `logs/dano3mip-network-lns.log`
- `scripts/dano3_network_lns.py`
- `scripts/dano3mip_structure.py`
- `solutions/dano3mip-known664.sol`
- `solutions/dano3mip-known664.sol.gz`
- `solutions/dano3mip-verified664.sol`

## Excluded files

- `input/dano3mip.mps.gz (289820 bytes; raw benchmark input; sha256 2684bf9265ce303a7a30b115b6cf2faa60b3177620f95e52b444eedc99b683a8)`
