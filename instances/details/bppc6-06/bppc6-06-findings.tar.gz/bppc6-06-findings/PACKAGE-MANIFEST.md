# Package manifest: bppc6-06

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 56
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/proof-206/executed-code/audit_profile_mps.py`
- `artifacts/proof-206/executed-code/check_pattern_bound.py`
- `artifacts/proof-206/executed-code/freeze_preparation.py`
- `artifacts/proof-206/executed-code/pattern_bound.py`
- `artifacts/proof-206/executed-code/profile_core.py`
- `artifacts/proof-206/local-official-validation.json`
- `artifacts/proof-206/local-pattern-check.json`
- `artifacts/proof-206/manifest.json`
- `artifacts/proof-206/mps-audit.json`
- `artifacts/proof-206/pattern-bounds.json`
- `artifacts/proof-206/remote-pattern-check.json`
- `artifacts/proof-208/README.zh.md`
- `artifacts/proof-208/artifact-integrity.json`
- `artifacts/proof-208/drat-check.log`
- `artifacts/proof-208/encoding.log`
- `artifacts/proof-208/executed-code/launch_tight_sat_stage.py`
- `artifacts/proof-208/executed-code/limit_exec.py`
- `artifacts/proof-208/executed-code/profile_core.py`
- `artifacts/proof-208/executed-code/solve_tight_sat.py`
- `artifacts/proof-208/executed-code/test_proof_flush.py`
- `artifacts/proof-208/executed-code/test_tight_sat.py`
- `artifacts/proof-208/executed-code/tight_sat.py`
- `artifacts/proof-208/independent-check/check.log`
- `artifacts/proof-208/independent-check/check2.log`
- `artifacts/proof-208/independent-check/check_lrat_rup.py`
- `artifacts/proof-208/independent-check/independent-lrat-check.json`
- `artifacts/proof-208/independent-check/pattern-bound-recheck.json`
- `artifacts/proof-208/independent-check/pattern-bound-recheck.log`
- `artifacts/proof-208/independent-check/publication-pattern-replay.json`
- `artifacts/proof-208/independent-check/witness-208-validation.json`
- `artifacts/proof-208/manifest.json`
- `artifacts/proof-208/mapping.json`
- `artifacts/proof-208/proof-flush-regression.cnf`
- `artifacts/proof-208/proof-flush-regression.drat`
- `artifacts/proof-208/proof-flush-test.log`
- `artifacts/proof-208/sat-result.json`
- `artifacts/proof-208/solver-exit.json`
- `artifacts/proof-208/solver.log`
- `artifacts/proof-208/supervisor.json`
- `artifacts/proof-208/tests.log`
- `artifacts/publication-audit.json`
- `logs/bppc6-06-copt-baseline.log`
- `logs/bppc6-06-gurobi-baseline.log`
- `logs/bppc6-06-job-neighborhoods.log`
- `logs/bppc6-06-known208-gurobi.log`
- `logs/bppc6-06-target207.log`
- `reports/optimality-proof.zh.md`
- `scripts/bppc_job_neighborhood_proof.py`
- `scripts/bppc_target_proof.py`
- `scripts/solve_with_miplib_start.py`
- `solutions/bppc6-06-known208.sol`
- `solutions/bppc6-06-known208.sol.gz`
- `solutions/bppc6-06-verified208.sol`
- `solutions/official-best.sol.gz`
- `solutions/official-best.validation.json`

## Excluded files

- `input/bppc6-06.mps.gz (511692 bytes; raw benchmark input; sha256 960123d55e8802a11a3435608e6973b5c1f856eeebc14e9d0227b0592d8728c4)`
