#  bppc6-06: strict Maximum combined capacity of 208 with SAT certificate

2026 -09 -06 04: 49 Update: It has been strict proof **optimal = 208**.
The original 208 witness has zero tolerance on the original MPS;≤ 207's exact CNF cannot be met and the proof has been independently verified.

##  The exact structure of the original model

3,920 is a binary option, 20 is an item, 253 is a load line, objective is not fixed continuous variables h.
Another variable fixed zero. Direct decimal integer MPS reader with Gurobi read only path verifies all 3,922 columns and 273 lines pass.
Each option in a load line is a constantly high continuous interval, but the line index is not the same as the physical location.
The coordinate range recovered from the original variable name and all column support is 300; after column-by-column verification, the physical length of the object is:

`97,92,84,77,74,63,62,60,57,53,50,41,29,25,23,22,21,14,12,7`。

Therefore, the energy field 122 was weak, not the original physical area field.
The total physical area is 60190, with the purest area boundary being ceil (60190 / 300) = 201; the new boundary uses a stronger combined weight.
Both the 208 solution local and the remote were re-checked with the original MPS zero tolerance, without lines, boundaries, integer violations.

##  exclusion h≤ 205's integer certificate

0, ..., 19, authorized by the code of origin:

`q = [3,0,1,2,0,3,3,2,3,2,3,1,3,2,3,3,1,2,2,1]`。

If the sum of the original heights of a group of objects is ≤ 205, the sum of the group q is ≤ 6.
The independent inspectors use another Gray-code enumeration to inspect the entire **1,048,576 subset** one by one;
1,465, which meets the original height limit, all meet the weight limit.

Assuming there is a complete placement of h≤ 205. Active objects at each physical location satisfy the above conditions.
Therefore, after the score, the overload is as much as `6×300=1800`.
On the other hand, each item happens to be placed once, in a row confirming the physical length fixed, so the total demand is
`sum(q_i×width_i)=1844 >1800` is a contradiction.
The height and load of the raw material are integers, so strictly introduced ** h*≥ 206 **.

The continuous LP is only used to find the weight of this 20, concluding that complete is verified by the above arbitrary precision integer enumeration and original model mapping verification.
The search warranty does not rely on LP numerical optimization or MIP solver.
Freeze the evidence, source code, input and result SHA256:[ `../artifacts/proof-206/manifest.json` ](../artifacts/proof-206/manifest.json).

##  Scanning events driven by tight equations and ultimate proof

For h≤ 207, there is another integer weight
`[2,0,1,1,0,2,2,1,2,1,2,1,2,1,2,2,1,1,1,1]`，
The weight of any allowable combination does not exceed 4, and the weighted length of all items is exactly `1200=4×300`.
Therefore, each original load line must coincidentally fill the weight 4 without leaving a weight-added gap.

Positive-weighted objects can only be continuous at the end of a positive-weighted object, and the starting point 0 must also be filled in.
Event scanning enumeration All items that can be filled with a release weight and that meet the original allowable starting point and altitude limits.
Two zero-weight items (originals 1 and 4) were not omitted: they all remained in their original allowable locations.
Remove incompatible locations with a defined load segment while recording the two overlapping prohibition lines simultaneously.
State of preservation of unlaunched animal items, end of active items, two zero-weight position domains and common prohibition lines; the same state can be combined.

The prototype and independent examiner have passed the 154,286 poorly assigned test of a small instance of 120, in which 40 is feasible, 80 is infeasible;
The 80 willfully missing branches were rejected by the inspector, and the timeout unfolded returned.
02: 32, v2 Increased interrupt continuity, periodic progress/tree preservation, and independent DAG replay tests after 160 was restored passed.

03: After 16 completes the original instance, preview: The first scheduling in 0.07 seconds is due to the output directory protection statement exit, not searched;
After repair, an effective search of about 19.66 seconds reached 600,000 state, 262,863 independent verification failed leaf,
159 is still undeveloped, with no candidate. Trees and history grow to hundreds of MiB.
1.28 GiB, therefore, does not directly enlarge this JSON tree for two hours.

New tight-profile SAT route: Using the already proven q primal bound and the total weight-added length equation,
For each positive-physical width load segment, `q-load=4` is required, and then the original area is selected with the height `<=207`.
Manually write sequential exactly-one with BDD Tseitin encoded by a small model of a full-valued/full-assisted variable.
In the original instance CNF is a variable for 414,391, 1,541,322, SHA256
`85cd2537ef615b878f0a57d1cb5198bbc6cd3835261306c6dfcc7086d25ecc6b`。
The controlled 5-minute pilot `bppc-priority/runs/20260906-tight-sat-pilot-5m` reached TIME_LIMIT,
There is no candidate or proof. The 208 witness is then used to set the search phase (no constraint) to run the formal phase.
The initial CaDiCaL run reported UNSAT after 348.26 seconds, but PySAT read 971 MiB before the C-level proof buffer was flushed
The proof, drat-trim report lacks final conflict and is therefore not accepted by UNSAT. The first revision phase is 356.41 seconds.
Restored UNSAT, but only destroyed the solver and still not refreshed native stdio; the script is filled in after proof is drat-trim
`conflict claimed, but not detected` refuses and does not accept mail. It is now displayed when the tracer is still connected.
`fflush(NULL)`, refreshed again after destruction; PHP;; 3,2) returned to restore the complete 7 line and was passed by drat-trim.
`20260906-tight-sat-proof-flush-rerun2-6100s` freeze solve the script SHA256
It's the `94750885f7621f95a8824041029596d4df5e39297b74cade1b6658ebc49637e9`.
Events about 20 seconds, lead 300 seconds, solve 348.26 / 356.41 seconds the first two times, up to 6,100 seconds at this stage,
The actual total number of searches remains constraint within two hours, and after this stage no longer is the same code added.

CaDiCaL is given by UNSAT in 358.15 seconds, complete DRAT together with the 14,376,464 line, SHA256
`f57d7fb1f449190d9755fb62614012b66aae78af37c161deae1679ab9b8f782a` . external drat-trim
Extract the atomic nucleus of 503,102 and the nuclear arithmetic of 1,001,496 and summarize it by 195,457,073, 0 as a RAT.
The lemma returned `VERIFIED` after 408.76 seconds. The converted LRAT SHA256 is
`0ec65b65188ef4b1889e68c9fb7e1f6a72d1a6b237a69d1f2f781ebd30c77705`。
Stage supervisor status is `complete/UNSAT_DRAT_VERIFIED` and all search and conversion processes have been withdrawn.

Subsequently, again independently weigh the entire load subset 1,048,576, confirm h≤ 207 when q-load≤ 4, and add weighting.
is exactly `1200=4×300`; the original 208 solution also passed another zero-tolerance original-MPS check. Thus any original-model solution with h<=207
The solution will give the CNF a satisfactory attribution, but the CNF has proof UNSAT; combined with 208 feasible witness, strict introduction
** h*= 208 **. Pure Python, with no SAT/optimized repository, LRAT is prompting replay and checking the 1,001,496 arguments and
195,457,073 second unit propagation, at 172.43 second verification the final empty sentence.
Compact certificate The mirror and the list are kept [`../artifacts/proof-208/` ](../artifacts/proof-208/)].

##  Literary background

[MIPLIB original instance page ](https://miplib.zib.de/instance_details_bppc6-06.html) describes this instance as
The bar relaxation of the continuous container/parallel processor tuning is derived from Côté, Dell'Amico, Iori's 2014 annual model.
[A pre-printed summary of Akçay and Delorme's ](https://optimization-online.org/wp-content/uploads/2024/05/Solving-the-PPSP-and-the-BPP-with-contiguity-constraints-2.pdf)]
The performance of combined capacity, pre-processing, relaxation and different modeling methods are discussed; this is the case for self-constructed and complete kernel testing.
20 dimensional weight certificate combination and close-equation event search, not claiming to reproduce the entire text algorithm.
