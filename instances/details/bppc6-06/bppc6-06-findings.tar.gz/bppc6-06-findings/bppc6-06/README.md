# `bppc6-06` — OPT = 208

This directory archives a structure-specific optimality proof for the MIPLIB
open instance `bppc6-06`. The original model is the bar relaxation / bin
packing problem with contiguity: 20 set-partitioning rows choose one start for
each item, 253 profile rows impose `load(t) <= h`, and the objective minimizes
the continuous peak variable `h`.

## Result

**The global optimum is 208.**

- Upper bound: the public 208 placement has objective 208 and passes an exact
  Decimal evaluation of all 273 original rows, all bounds, and integrality with
  zero violation.
- Lower bound: every placement with `h <= 207` would satisfy an exact
  tight-profile CNF. CaDiCaL proved that CNF UNSAT, `drat-trim` verified the
  complete DRAT proof, and a separate standard-library Python checker replayed
  the converted positive-hint LRAT proof through the final empty clause.

The original compressed MPS has SHA-256
`960123d55e8802a11a3435608e6973b5c1f856eeebc14e9d0227b0592d8728c4`.

## Why the target-207 encoding is valid

The MPS columns recover a physical horizon of 300 and the following exact item
widths:

```text
97, 92, 84, 77, 74, 63, 62, 60, 57, 53,
50, 41, 29, 25, 23, 22, 21, 14, 12, 7
```

For target 207, assign the 20 items the integer weights

```text
2, 0, 1, 1, 0, 2, 2, 1, 2, 1, 2, 1, 2, 1, 2, 2, 1, 1, 1, 1.
```

An independent Gray-code enumeration checks all `2^20 = 1,048,576` item
subsets. Every subset whose original height is at most 207 has weight at most
4. The total weighted length is exactly `1200 = 4 * 300`; consequently every
positive-width profile segment of a hypothetical target-207 placement must
have weight exactly 4. The CNF encodes:

1. exactly one original start option per item;
2. the exact interval-to-profile incidence from the MPS;
3. original height at most 207 on every profile row; and
4. the forced weight-4 equality on every profile row.

Thus any original solution with `h <= 207` maps to a satisfying assignment of
the CNF. The checked UNSAT certificate excludes all such original solutions.

## Certificate results

| Artifact | Result |
|---|---:|
| CNF | 414,391 variables; 1,541,322 clauses |
| CaDiCaL | UNSAT in 358.15 s |
| DRAT | 14,376,464 lines; SHA-256 `f57d7fb1f449190d9755fb62614012b66aae78af37c161deae1679ab9b8f782a` |
| `drat-trim` | VERIFIED; 503,102 core input clauses, 1,001,496 lemmas, 195,457,073 resolution steps |
| LRAT | SHA-256 `0ec65b65188ef4b1889e68c9fb7e1f6a72d1a6b237a69d1f2f781ebd30c77705` |
| Independent LRAT replay | 1,001,496 lemmas and 195,457,073 unit-propagation steps; final empty clause verified |

The full CNF, DRAT, and LRAT files total about 2.65 GiB and are not committed to
Git. Their byte sizes and hashes are frozen in
[`artifacts/proof-208/manifest.json`](artifacts/proof-208/manifest.json). The
repository contains the encoder snapshots, exact MPS mapping, solver/checker
logs, independent replay summaries, and all compact evidence. This is a strict
optimality result, but reproducing the final LRAT replay requires obtaining or
regenerating the large proof files and matching the recorded hashes.

Two earlier proof-generation attempts produced truncated or invalid DRAT files
and are explicitly excluded. Only the final flushed proof whose hashes appear
above supports the result.

## Compact reproduction

The subset certificate and incumbent audit do not require an optimization
solver:

```sh
python artifacts/proof-206/executed-code/check_pattern_bound.py \
  input/bppc6-06.mps.gz artifacts/proof-206/pattern-bounds.json \
  --output pattern-replay.json

python ../../common/exact_mps_solution_check.py \
  input/bppc6-06.mps.gz solutions/bppc6-06-verified208.sol \
  --tolerance 0
```

To regenerate the exact target-207 CNF:

```sh
python artifacts/proof-208/executed-code/tight_sat.py \
  input/bppc6-06.mps.gz artifacts/proof-206/pattern-bounds.json \
  --target 207 --output regenerated-target-207
```

The regenerated `model.cnf` must have SHA-256
`85cd2537ef615b878f0a57d1cb5198bbc6cd3835261306c6dfcc7086d25ecc6b`.
Given the matching LRAT file, replay it with
[`check_lrat_rup.py`](artifacts/proof-208/independent-check/check_lrat_rup.py).
The checks rerun directly from this publication tree are summarized in
[`artifacts/publication-audit.json`](artifacts/publication-audit.json).

The complete Chinese derivation, failed-attempt accounting, and provenance are
in [`reports/optimality-proof.zh.md`](reports/optimality-proof.zh.md).

## Historical experiments

The older Gurobi/COPT logs and neighborhood scripts are retained for
provenance. Their time limits, lower bounds 201/202, and local infeasibility
results were useful intermediate evidence but are superseded by the exact
target-207 certificate above.
