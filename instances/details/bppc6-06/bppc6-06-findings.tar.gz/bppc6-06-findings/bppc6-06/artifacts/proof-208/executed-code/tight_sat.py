"""Exact CNF for the tight q-profile decision problem; no optimizer calls.

For target 207 the independently checked pattern certificate proves q-load <= 4
at each profile segment.  Its physical integral is exactly 4*horizon, so every
positive-width segment must have q-load == 4.  This script adds that implied
equality to the original interval placement and height constraints.
"""
import argparse
import hashlib
import json
from pathlib import Path

from profile_core import coordinates, load_mps


class CNF:
    def __init__(self):
        self.nvars = 0
        self.clauses = []
        self.names = {}

    def var(self, name):
        self.nvars += 1
        self.names[name] = self.nvars
        return self.nvars

    @staticmethod
    def neg(term):
        return not term if type(term) is bool else -term

    def add(self, *terms):
        if any(type(x) is bool and x for x in terms):
            return
        clause = [x for x in terms if type(x) is not bool]
        self.clauses.append(clause)

    def exactly_one(self, lits, prefix):
        assert lits
        self.add(*lits)
        if len(lits) == 1:
            return
        previous = self.var((prefix, 'seq', 0))
        self.add(-lits[0], previous)
        for i in range(1, len(lits)-1):
            current = self.var((prefix, 'seq', i))
            self.add(-lits[i], current)
            self.add(-previous, current)
            self.add(-lits[i], -previous)
            previous = current
        self.add(-lits[-1], -previous)

    def bdd(self, lits, weights, accept, prefix):
        """Reduced BDD with a full Tseitin equivalence; returns root term."""
        assert len(lits) == len(weights) and all(w > 0 for w in weights)
        suffix = [0] * (len(weights)+1)
        for i in range(len(weights)-1, -1, -1):
            suffix[i] = suffix[i+1] + weights[i]
        memo = {}

        def visit(i, total):
            terminal = accept(i, total, suffix[i])
            if terminal is not None:
                assert type(terminal) is bool
                return terminal
            key = i, total
            if key in memo:
                return memo[key]
            low = visit(i+1, total)
            high = visit(i+1, total+weights[i])
            if low == high:
                memo[key] = low
                return low
            node = self.var((prefix, 'bdd', i, total))
            x = lits[i]
            # node <-> ite(x, high, low)
            self.add(-node, -x, high)
            self.add(-node, x, low)
            self.add(node, -x, self.neg(high))
            self.add(node, x, self.neg(low))
            memo[key] = node
            return node

        root = visit(0, 0)
        self.add(root)
        return len(memo)

    def write(self, path):
        path = Path(path)
        with path.open('w', encoding='ascii', newline='\n') as f:
            f.write(f'p cnf {self.nvars} {len(self.clauses)}\n')
            for clause in self.clauses:
                f.write(' '.join(map(str, clause)) + ' 0\n')


def leq_accept(bound):
    def accept(i, total, remaining):
        if total > bound:
            return False
        if total + remaining <= bound:
            return True
        return None
    return accept


def eq_accept(value, n):
    def accept(i, total, remaining):
        if total > value or total + remaining < value:
            return False
        if i == n:
            return total == value
        return None
    return accept


def encode(mps, certificates, target):
    data = load_mps(mps)
    certs = json.loads(Path(certificates).read_text())
    cert = next(c for c in certs if c['target'] == target)
    assert cert['mps_sha256'] == data['mps_sha256']
    assert cert['scale'] == 4 and cert['numerator'] == cert['capacity_numerator'] == 1200
    coords, widths = coordinates(data)
    assert coords[0] == 0 and coords[-1] == 300
    assert sum(q*w for q, w in zip(cert['weights'], widths)) == 4*coords[-1]

    cnf = CNF()
    xvars = []
    for i, item in enumerate(data['items']):
        row = [cnf.var(('x', i, k)) for k in range(len(item['options']))]
        cnf.exactly_one(row, ('item', i))
        xvars.append(row)
    yvars = [[cnf.var(('y', i, r)) for r in range(data['profile_rows'])]
             for i in range(len(data['items']))]
    for i, item in enumerate(data['items']):
        for r in range(data['profile_rows']):
            covers = [xvars[i][k] for k, o in enumerate(item['options']) if o['a'] <= r < o['b']]
            y = yvars[i][r]
            for x in covers:
                cnf.add(-x, y)
            cnf.add(-y, *covers)

    qitems = [i for i, q in enumerate(cert['weights']) if q]
    qweights = [cert['weights'][i] for i in qitems]
    heights = [item['height'] for item in data['items']]
    qnodes = heightnodes = 0
    for r in range(data['profile_rows']):
        qlits = [yvars[i][r] for i in qitems]
        qnodes += cnf.bdd(qlits, qweights, eq_accept(4, len(qlits)), ('qeq', r))
        heightnodes += cnf.bdd([yvars[i][r] for i in range(len(data['items']))], heights,
                               leq_accept(target), ('height', r))
    mapping = {
        'instance': data['instance'], 'target': target, 'encoder_version': 1,
        'mps_sha256': data['mps_sha256'],
        'certificate_sha256': hashlib.sha256(Path(certificates).read_bytes()).hexdigest(),
        'tight_certificate': cert,
        'physical_horizon': coords[-1], 'profile_rows': data['profile_rows'],
        'variables': cnf.nvars, 'clauses': len(cnf.clauses),
        'q_bdd_nodes': qnodes, 'height_bdd_nodes': heightnodes,
        'x': [[{'variable': xvars[i][k], 'option_index': k, **o}
               for k, o in enumerate(item['options'])] for i, item in enumerate(data['items'])],
        'proof_scope': ('CNF is equivalent to original interval choices with peak <= target, '
                        'using the independently checked tight q-profile equality.')}
    return cnf, mapping


def main():
    p = argparse.ArgumentParser()
    p.add_argument('mps', type=Path)
    p.add_argument('certificates', type=Path)
    p.add_argument('--target', type=int, default=207)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    assert not a.output.exists(), 'Never overwrite an encoding'
    a.output.mkdir(parents=True)
    cnf, mapping = encode(a.mps, a.certificates, a.target)
    cnf.write(a.output/'model.cnf')
    mapping['cnf_sha256'] = hashlib.sha256((a.output/'model.cnf').read_bytes()).hexdigest()
    (a.output/'mapping.json').write_text(json.dumps(mapping, indent=2)+'\n')
    print(json.dumps({k: mapping[k] for k in ['target', 'variables', 'clauses',
                                              'q_bdd_nodes', 'height_bdd_nodes',
                                              'cnf_sha256']}))


if __name__ == '__main__':
    main()
