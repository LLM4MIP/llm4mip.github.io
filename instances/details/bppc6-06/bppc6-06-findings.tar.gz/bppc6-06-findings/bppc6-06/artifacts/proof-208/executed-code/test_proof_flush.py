"""Regression: finalized CaDiCaL proof must contain the empty clause."""
import argparse
from pathlib import Path
from pysat.formula import CNF
from pysat.solvers import Solver
from solve_tight_sat import finalized_proof


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    # PHP(3,2): inconsistent only after search, not while importing clauses.
    clauses = [[1, 2], [3, 4], [5, 6],
               [-1, -3], [-1, -5], [-3, -5],
               [-2, -4], [-2, -6], [-4, -6]]
    with Solver(name='cadical195', bootstrap_with=clauses, with_proof=True) as solver:
        assert not solver.solve()
        proof = finalized_proof(solver)
    cnf = CNF(from_clauses=clauses)
    cnf.to_file(str(a.output.with_suffix('.cnf')))
    a.output.write_text('\n'.join(proof)+'\n')
    print({'proof_lines': len(proof), 'last_line': proof[-1]})


if __name__ == '__main__':
    main()
