# bppc6-06 optimality certificate (compact mirror)

In the end, `optimal = 208` is the only one that can be used to solve the problem.

-  Primal bound: MIPLIB 208 witness Re-tested with zero tolerance on the original MPS, and all lines, boundaries and integer conditions were not violated.
-  lower bound: If `h <= 207`, the combined weight of the verification is poor enough to force each positive width profile segment to satisfy
`q-load = 4`. The exact interval/height CNF cannot be satisfied.
-  First checker: Drat-trim returns `VERIFIED` to the full DRAT, the core containing the 503,102 atomic point,
1,001,496 is derived from 195,457,073 and 0 is derived from RAT.
-  Second checker: Pure Python, LRAT RUP replay with no SAT/optimized repository checking 1,001,496 arguments and
195,457,073 second unit propagation, verification, and finally the empty sentence, taking 172.43 seconds.

This directory retains source snapshots, mappings, logs and verification results of about 650 KiB. The three major files remain.
The euler4 read-only study path, not the local repeat occupies about 2.65 GiB:

`/data1/wyc/automatic-research-10/bppc-priority/runs/20260906-tight-sat-proof-flush-rerun2-6100s/target-207/`

File size and SHA256 See `manifest.json`. DRATs that failed external checks twice earlier are not included in this certificate.

