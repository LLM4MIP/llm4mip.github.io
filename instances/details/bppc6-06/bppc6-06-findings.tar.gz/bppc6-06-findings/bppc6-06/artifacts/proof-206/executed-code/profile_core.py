"""Exact integer parsing and interval extraction for the original BPPC MPS."""
import gzip
import hashlib
import json
from decimal import Decimal
from pathlib import Path
import re


def integer(s):
    v = Decimal(s.replace('D', 'E'))
    assert v == int(v), s
    return int(v)


def dump(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, indent=2) + '\n')
    tmp.replace(path)


def load_mps(path):
    sections = {'NAME', 'OBJSENSE', 'OBJNAME', 'ROWS', 'COLUMNS', 'RHS', 'BOUNDS', 'RANGES', 'ENDATA'}
    section = None
    rows, senses, rid, columns, obj, rhs, bounds, integral = [], [], {}, {}, {}, {}, {}, set()
    objrow = None
    intmode = False
    with gzip.open(path, 'rt') as f:
        for raw in f:
            p = raw.split()
            if not p or p[0].startswith('*'):
                continue
            if not raw[0].isspace() and p[0] in sections:
                section = p[0]
                continue
            if section == 'OBJSENSE':
                assert p[0] == 'MIN'
            elif section == 'ROWS':
                if p[0] == 'N':
                    assert objrow is None
                    objrow = p[1]
                else:
                    assert p[1] not in rid
                    rid[p[1]] = len(rows)
                    rows.append(p[1])
                    senses.append(p[0])
            elif section == 'COLUMNS':
                if 'MARKER' in raw:
                    if 'INTORG' in raw:
                        intmode = True
                    elif 'INTEND' in raw:
                        intmode = False
                    else:
                        raise ValueError(raw)
                    continue
                name = p[0]
                columns.setdefault(name, {})
                obj.setdefault(name, 0)
                if intmode:
                    integral.add(name)
                assert len(p) % 2 == 1
                for j in range(1, len(p), 2):
                    v = integer(p[j + 1])
                    if p[j] == objrow:
                        obj[name] += v
                    else:
                        r = rid[p[j]]
                        columns[name][r] = columns[name].get(r, 0) + v
            elif section == 'RHS':
                for j in range(1, len(p), 2):
                    r = rid[p[j]]
                    assert r not in rhs
                    rhs[r] = integer(p[j + 1])
            elif section == 'BOUNDS':
                kind, name = p[0], p[2]
                assert name in columns
                lo, hi = bounds.get(name, (0, 1 if name in integral else None))
                if kind == 'BV':
                    lo, hi = 0, 1
                    integral.add(name)
                elif kind == 'LO':
                    lo = integer(p[3])
                elif kind == 'UP':
                    hi = integer(p[3])
                elif kind == 'FX':
                    lo = hi = integer(p[3])
                else:
                    raise ValueError('Unsupported bound ' + kind)
                bounds[name] = (lo, hi)
            elif section == 'RANGES':
                raise ValueError('Unexpected range')
    assert len(rows) == 273 and senses == ['E'] * 20 + ['L'] * 253
    assert all(rhs.get(r, 0) == (1 if r < 20 else 0) for r in range(273))
    assert len(columns) == 3922 and obj['h'] == 1 and 'h' not in integral
    assert bounds.get('h', (0, None)) == (0, None)
    assert columns['h'] == {r: -1 for r in range(20, 273)}
    items = [{'item': i, 'height': None, 'options': []} for i in range(20)]
    fixed = {}
    for name, col in columns.items():
        if name == 'h':
            continue
        match = re.fullmatch(r'X(\d+)\.(\d+)', name)
        if not match:
            assert bounds[name] == (0, 0)
            fixed[name] = 0
            continue
        assert obj[name] == 0
        i, start = map(int, match.groups())
        assert 0 <= i < 20 and name in integral
        lo, hi = bounds.get(name, (0, 1))
        assert lo == 0 and hi in (0, 1)
        assert {r: v for r, v in col.items() if r < 20 and v} == {i: 1}
        profile = {r - 20: v for r, v in col.items() if r >= 20 and v}
        a, b = min(profile), max(profile) + 1
        assert set(profile) == set(range(a, b)) and len(set(profile.values())) == 1
        height = profile[a]
        assert height > 0
        if items[i]['height'] is None:
            items[i]['height'] = height
        assert items[i]['height'] == height
        if hi:
            items[i]['options'].append(dict(name=name, label=start, a=a, b=b))
    assert sum(len(x['options']) for x in items) == 3920
    for item in items:
        item['options'].sort(key=lambda o: o['label'])
    return dict(instance='bppc6-06', mps_sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest(),
                profile_rows=253, items=items, fixed_zero_variables=fixed)


def verify_assignment(data, selected):
    assert len(selected) == len(data['items'])
    load = [0] * data['profile_rows']
    for item, k in zip(data['items'], selected):
        assert type(k) is int and 0 <= k < len(item['options'])
        option = item['options'][k]
        for t in range(option['a'], option['b']):
            load[t] += item['height']
    return max(load), load


def coordinates(data):
    """Recover physical lengths, accepting them only after all columns agree."""
    co = {}
    for item in data['items']:
        for o in item['options']:
            if o['a'] in co:
                assert co[o['a']] == o['label']
            co[o['a']] = o['label']
    assert set(co) == set(range(data['profile_rows']))
    widths, ends = [], set()
    for item in data['items']:
        candidates = {co[o['b']] - o['label'] for o in item['options'] if o['b'] in co}
        assert len(candidates) == 1
        width = candidates.pop()
        assert width > 0
        widths.append(width)
        ends.update(o['label'] + width for o in item['options'] if o['b'] == data['profile_rows'])
    assert len(ends) == 1
    co[data['profile_rows']] = ends.pop()
    coords = [co[r] for r in range(data['profile_rows'] + 1)]
    assert coords[0] == 0 and all(a < b for a, b in zip(coords, coords[1:]))
    for item, width in zip(data['items'], widths):
        assert all(coords[o['b']] - coords[o['a']] == width for o in item['options'])
    return coords, widths


if __name__ == '__main__':
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument('mps', type=Path)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    data = load_mps(args.mps)
    dump(args.output, data)
    print(json.dumps(dict(mps_sha256=data['mps_sha256'], items=[dict(item=x['item'], height=x['height'],
       choices=len(x['options']), first=x['options'][0], last=x['options'][-1],
       sizes=sorted(set(o['b']-o['a'] for o in x['options']))) for x in data['items']]), indent=2))
