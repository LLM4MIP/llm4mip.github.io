"""Freeze the exact lower-bound evidence, separate from mutable search prototypes."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
from profile_core import dump


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


base = Path(__file__).resolve().parent
root = base.parent
out = base / 'proof-206'
assert not out.exists(), 'Preserve existing proof package'
(out/'executed-code').mkdir(parents=True)
for name in ['profile_core.py', 'pattern_bound.py', 'check_pattern_bound.py', 'audit_profile_mps.py', 'freeze_preparation.py']:
    shutil.copy2(base/name, out/'executed-code'/name)
for name in ['pattern-bounds.json', 'local-pattern-check.json', 'remote-pattern-check.json',
             'mps-audit.json', 'local-official-validation.json']:
    shutil.copy2(base/'preparation'/name, out/name)
certs = json.loads((out/'pattern-bounds.json').read_text())
checks = json.loads((out/'local-pattern-check.json').read_text())
assert next(c for c in certs if c['target'] == 205)['numerator'] == 1844
assert next(c for c in checks if c['target'] == 205)['exact_lower_bound'] == 206
manifest = dict(instance='bppc6-06', certified_lower_bound=206, verified_upper_bound=208,
    status='NOT_YET_OPTIMAL', local_python=sys.version,
    source_sha256={p.name: digest(p) for p in sorted((out/'executed-code').iterdir())},
    evidence_sha256={p.name: digest(p) for p in sorted(out.glob('*.json'))},
    mps_sha256=digest(root/'bppc6-06/input/bppc6-06.mps.gz'),
    official_solution_sha256=digest(root/'bppc6-06/solutions/official-best.sol.gz'),
    shared_verifier_sha256=digest(root/'tools/verify_sol.py'),
    reasoning='Target <=205 implies every active subset has transformed weight <=6; original columns have exact physical widths. Required 1844 > 6*300=1800. All 2^20 subsets checked independently in local and remote runs.')
dump(out/'manifest.json', manifest)
print(json.dumps(manifest, indent=2))
