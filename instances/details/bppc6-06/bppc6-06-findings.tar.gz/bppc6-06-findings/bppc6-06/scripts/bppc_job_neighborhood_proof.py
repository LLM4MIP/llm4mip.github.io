#!/usr/bin/env python3
"""Prove strict target infeasibility in nested job neighborhoods for bppc6-06."""

from __future__ import annotations

import argparse
import collections
import re
from pathlib import Path

import gurobipy as gp

from solve_with_miplib_start import read_miplib_solution


START_RE = re.compile(r"^X(\d+)\.(\d+)$")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--target", type=float, default=207.0)
    parser.add_argument("--seconds", type=float, default=60.0)
    parser.add_argument("--threads", type=int, default=32)
    parser.add_argument("--log", type=Path, required=True)
    args = parser.parse_args()

    model = gp.read(str(args.mps))
    model.update()
    expected, supplied = read_miplib_solution(args.solution)

    choices: dict[int, list[gp.Var]] = collections.defaultdict(list)
    for variable in model.getVars():
        match = START_RE.match(variable.VarName)
        if match:
            choices[int(match.group(1))].append(variable)

    capacity_names = {
        constraint.ConstrName
        for constraint in model.getConstrs()
        if constraint.Sense == gp.GRB.LESS_EQUAL
    }
    impact: dict[int, float] = {}
    for job, variables in choices.items():
        representative = min(variables, key=lambda variable: int(START_RE.match(variable.VarName).group(2)))
        column = model.getCol(representative)
        coefficients = [
            abs(column.getCoeff(term))
            for term in range(column.size())
            if column.getConstr(term).ConstrName in capacity_names
            and abs(column.getCoeff(term)) > 1e-12
        ]
        impact[job] = len(coefficients) * coefficients[0]

    ordering = sorted(choices, key=lambda job: (-impact[job], job))
    print(f"known_objective={expected} target={args.target} job_impact_order={ordering}")
    strict_target = model.addConstr(model.getObjective() <= args.target + 0.5, name="StrictTarget")
    model.update()
    model.Params.LogFile = str(args.log)
    model.Params.Threads = args.threads
    model.Params.MIPFocus = 3
    model.Params.Cuts = 3
    model.Params.Symmetry = 2

    for released_count in (5, 10, 15):
        released = set(ordering[:released_count])
        for job, variables in choices.items():
            for variable in variables:
                if job in released:
                    variable.LB, variable.UB = 0.0, 1.0
                else:
                    value = round(supplied.get(variable.VarName, 0.0))
                    variable.LB = variable.UB = value
        model.reset(0)
        for variable in model.getVars():
            variable.Start = supplied.get(variable.VarName, 0.0)
        model.Params.TimeLimit = args.seconds
        print(f"BEGIN released_count={released_count} released_jobs={sorted(released)}")
        model.optimize()
        if model.Status == gp.GRB.INFEASIBLE:
            print(f"PROVED released_count={released_count} no_solution_at_or_below={args.target}")
        elif model.SolCount:
            print(
                f"FOUND released_count={released_count} objective={model.ObjVal:.15g} "
                f"bound={model.ObjBound:.15g} status={model.Status}"
            )
        else:
            print(
                f"UNRESOLVED released_count={released_count} bound={model.ObjBound:.15g} "
                f"nodes={model.NodeCount:g} status={model.Status}"
            )


if __name__ == "__main__":
    main()
