#!/usr/bin/env python3
"""Target-feasibility proof model for bppc6-06."""

from __future__ import annotations

import argparse
import collections
import re
from pathlib import Path

import gurobipy as gp

from solve_with_miplib_start import read_miplib_solution


START_RE = re.compile(r"^X(\d+)\.(\d+)$")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--target", type=float, default=207.0)
    parser.add_argument("--seconds", type=float, default=600.0)
    parser.add_argument("--threads", type=int, default=40)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--result", type=Path, required=True)
    args = parser.parse_args()

    model = gp.read(str(args.mps))
    model.update()
    expected, supplied = read_miplib_solution(args.solution)

    starts: dict[int, dict[int, gp.Var]] = collections.defaultdict(dict)
    for variable in model.getVars():
        match = START_RE.match(variable.VarName)
        if match:
            starts[int(match.group(1))][int(match.group(2))] = variable

    equality_rows = [constraint for constraint in model.getConstrs() if constraint.Sense == gp.GRB.EQUAL]
    capacity_rows = [constraint for constraint in model.getConstrs() if constraint.Sense == gp.GRB.LESS_EQUAL]
    horizon = len(capacity_rows)
    capacity_names = {constraint.ConstrName for constraint in capacity_rows}

    signatures: dict[tuple[int, float], list[int]] = collections.defaultdict(list)
    widths: dict[int, int] = {}
    heights: dict[int, float] = {}
    for job, choices in starts.items():
        representative = choices[min(choices)]
        column = model.getCol(representative)
        capacity_coefficients = [
            column.getCoeff(term)
            for term in range(column.size())
            if column.getConstr(term).ConstrName in capacity_names
            and abs(column.getCoeff(term)) > 1e-12
        ]
        width = len(capacity_coefficients)
        height = abs(capacity_coefficients[0])
        if any(abs(abs(value) - height) > 1e-9 for value in capacity_coefficients):
            raise ValueError(f"Nonconstant bar height for job {job}")
        widths[job] = width
        heights[job] = height
        signatures[(width, height)].append(job)

    print(
        f"jobs={len(starts)} horizon={horizon} equality_rows={len(equality_rows)} "
        f"known_objective={expected} target={args.target}"
    )
    for job in sorted(starts):
        print(
            f"job={job} width={widths[job]} height={heights[job]:g} "
            f"starts={len(starts[job])} max_start={max(starts[job])}"
        )

    model.addConstr(model.getObjective() <= args.target + 0.5, name="StrictTarget")
    model.update()
    print("added_strict_target_constraint=1")

    for job, choices in starts.items():
        priority = max(1, round(widths[job] * heights[job]))
        for variable in choices.values():
            variable.BranchPriority = priority
    for variable in model.getVars():
        variable.Start = supplied.get(variable.VarName, 0.0)

    model.Params.LogFile = str(args.log)
    model.Params.TimeLimit = args.seconds
    model.Params.Threads = args.threads
    model.Params.MIPFocus = 3
    model.Params.Cuts = 3
    model.Params.Symmetry = 2
    model.optimize()

    if model.Status == gp.GRB.INFEASIBLE:
        print(f"PROVED no solution with objective <= {args.target}")
    elif model.SolCount:
        model.write(str(args.result))
        print(
            f"RESULT objective={model.ObjVal:.15g} bound={model.ObjBound:.15g} "
            f"status={model.Status}"
        )
    else:
        print(f"RESULT no_solution_found bound={model.ObjBound:.15g} status={model.Status}")


if __name__ == "__main__":
    main()
