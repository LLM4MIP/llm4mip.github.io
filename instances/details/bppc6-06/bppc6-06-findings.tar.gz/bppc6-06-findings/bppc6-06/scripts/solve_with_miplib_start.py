#!/usr/bin/env python3
"""Load a MIPLIB .sol file as a complete MIP start and continue Gurobi."""

from __future__ import annotations

import argparse
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def read_miplib_solution(path: Path) -> tuple[float | None, dict[str, float]]:
    objective: float | None = None
    values: dict[str, float] = {}
    for line_number, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        tokens = raw.split()
        if not tokens or tokens[0].startswith("#"):
            continue
        # Some official MIPLIB solution files include an additional human-readable
        # objective line before the variable assignments.
        if raw.lstrip().lower().startswith("objective value:"):
            continue
        if tokens[0] == "=obj=" and len(tokens) == 2:
            objective = float(tokens[1])
        elif len(tokens) == 2:
            values[tokens[0]] = float(tokens[1])
        else:
            raise ValueError(f"Malformed solution line {line_number}: {raw}")
    return objective, values


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--time-limit", type=float, default=120.0)
    parser.add_argument("--threads", type=int, default=32)
    parser.add_argument("--mip-focus", type=int, choices=range(4), default=0)
    parser.add_argument("--log", type=Path)
    parser.add_argument("--result", type=Path)
    parser.add_argument("--cutoff", type=float)
    args = parser.parse_args()

    expected_objective, values = read_miplib_solution(args.solution)
    model = gp.read(str(args.mps))
    model.update()
    by_name = {variable.VarName: variable for variable in model.getVars()}
    unknown = sorted(set(values) - set(by_name))
    if unknown:
        raise ValueError(f"Solution contains unknown variables: {unknown[:10]}")

    # MIPLIB solution files are sparse: omitted variables have value zero.
    for variable in model.getVars():
        variable.Start = values.get(variable.VarName, 0.0)

    start_objective = sum(variable.Obj * values.get(variable.VarName, 0.0) for variable in model.getVars())
    print(
        f"model={model.ModelName} rows={model.NumConstrs} cols={model.NumVars} "
        f"general_constraints={model.NumGenConstrs}"
    )
    print(
        f"solution_nonzeros={len(values)} expected_objective={expected_objective} "
        f"computed_start_objective={start_objective:.15g}"
    )

    if expected_objective is not None and abs(start_objective - expected_objective) > 1e-6:
        raise ValueError("Objective in the solution header does not match its variable values")

    model.Params.TimeLimit = args.time_limit
    model.Params.Threads = args.threads
    model.Params.MIPFocus = args.mip_focus
    if args.log:
        model.Params.LogFile = str(args.log)
    if args.cutoff is not None:
        model.Params.Cutoff = args.cutoff
    model.optimize()

    print(
        f"status={model.Status} sol_count={model.SolCount} "
        f"runtime={model.Runtime:.3f} nodes={model.NodeCount:.0f}"
    )
    if model.SolCount:
        print(f"incumbent={model.ObjVal:.15g} bound={model.ObjBound:.15g} gap={model.MIPGap:.9g}")
        if args.result:
            model.write(str(args.result))
    elif model.Status == GRB.INFEASIBLE:
        print("No solution: model proved infeasible under the supplied settings")


if __name__ == "__main__":
    main()
