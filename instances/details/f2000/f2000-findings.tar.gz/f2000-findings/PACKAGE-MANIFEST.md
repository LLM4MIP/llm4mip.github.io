# Package manifest: f2000

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 16
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/f2000-literal-pairs.tsv`
- `artifacts/f2000-original-lb1810.opb`
- `artifacts/f2000-preprocess-summary.json`
- `artifacts/f2000-reduced-lb1810.opb`
- `artifacts/f2000-reduced.opb`
- `artifacts/f2000-reduced.wcnf`
- `artifacts/f2000-three-state-190.sol`
- `artifacts/f2000-three-state-run-input.lp`
- `artifacts/f2000-three-state.lp`
- `logs/f2000-three-state-600s.log`
- `logs/f2000-three-state-root.log`
- `reports/structural-investigation.md`
- `scripts/preprocess.py`
- `solutions/official-1810.sol.gz`
- `solutions/three-state-600s.sol`

## Excluded files

- `input/f2000.mps.gz (217701 bytes; raw benchmark input; sha256 56125eedea2317d23df9715fa39ac86ef7e9bfd572893662dabfac83690567f4)`
