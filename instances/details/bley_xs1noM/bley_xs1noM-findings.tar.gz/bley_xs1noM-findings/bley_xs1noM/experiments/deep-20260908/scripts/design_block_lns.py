#!/usr/bin/env python3
"""Exact strict-improvement search over bley_xs1noM capacity-design blocks.

All zero-objective routing/metric variables stay free.  Only positive-cost
design variables outside the chosen block(s) are fixed to the incumbent.
Thus CUTOFF/INFEASIBLE is a rigorous local-optimality result for that block.
"""

from __future__ import annotations

import argparse
import gzip
import itertools
import json
import math
import time
from pathlib import Path

import gurobipy as gp


EARLY = [
    [18, 19], [25, 26, 27], [37, 38], [106, 107, 108], [123, 124],
    [134, 135], [140, 141], [178, 179], [214, 215, 216], [256, 257],
    [433, 434],
]


def read_sol(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix == ".gz" else open
    out = {}
    with opener(path, "rt", encoding="latin-1") as h:
        for line in h:
            f = line.split()
            if len(f) >= 2 and not f[0].startswith(("#", "=")):
                try:
                    out[f[0]] = float(f[1])
                except ValueError:
                    pass
    return out


def blocks(model: gp.Model, values: dict[str, float]) -> list[dict]:
    by_name = {v.VarName: v for v in model.getVars()}
    groups = []
    for k, ids in enumerate(EARLY):
        names = [f"x{i}" for i in ids]
        groups.append({"id": f"early-{k:02d}", "names": names})
    for k in range(42):
        first = 1034 + 23 * k
        # The final 23-wide algebraic block includes x1999, which is the first
        # zero-cost routing variable; only objective-support variables define
        # the capacity-design neighborhood.
        names = [f"x{i}" for i in range(first, first + 23) if by_name[f"x{i}"].Obj != 0]
        groups.append({"id": f"link-{k:02d}", "names": names})
    used = {n for g in groups for n in g["names"]}
    obj_names = {v.VarName for v in model.getVars() if abs(v.Obj) > 0}
    if used != obj_names:
        raise RuntimeError(f"block recovery mismatch: missing={sorted(obj_names-used)}, extra={sorted(used-obj_names)}")
    for g in groups:
        g["incumbent_contribution"] = sum(by_name[n].Obj * values.get(n, 0.0) for n in g["names"])
        g["incumbent_nonzero"] = sum(abs(values.get(n, 0.0)) > 0 for n in g["names"])
    return groups


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mps", type=Path, required=True)
    ap.add_argument("--start", type=Path, required=True)
    ap.add_argument("--per-trial", type=float, default=12)
    ap.add_argument("--total", type=float, default=720)
    ap.add_argument("--threads", type=int, default=2)
    ap.add_argument("--pairs", type=int, default=0, help="also test this many expensive-block pairs")
    ap.add_argument("--log-dir", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--solution-dir", type=Path, required=True)
    args = ap.parse_args()
    args.log_dir.mkdir(parents=True, exist_ok=True)
    args.solution_dir.mkdir(parents=True, exist_ok=True)
    args.output.parent.mkdir(parents=True, exist_ok=True)

    base = gp.read(str(args.mps))
    vals = read_sol(args.start)
    groups = blocks(base, vals)
    # Exact cent lattice: strict improvement from 3,855,895.86 is <= .85.
    # The largest coefficient is about 1e7, so its binary64 product by 100
    # may differ from the nearest integer by ~1.2e-7.  A 1e-4 recognition
    # tolerance remains orders of magnitude below the cent lattice.
    if any(abs(v.Obj * 100 - round(v.Obj * 100)) > 1e-4 for v in base.getVars()):
        raise RuntimeError("objective is not on the expected 0.01 lattice")
    incumbent = sum(v.Obj * vals.get(v.VarName, 0.0) for v in base.getVars()) + base.ObjCon
    cutoff = incumbent - 0.005

    trials = [([i], f"single-{groups[i]['id']}") for i in range(len(groups))]
    if args.pairs:
        ranked = sorted(range(len(groups)), key=lambda i: groups[i]["incumbent_contribution"], reverse=True)[:14]
        pair_list = list(itertools.combinations(ranked, 2))[:args.pairs]
        trials += [([i, j], f"pair-{groups[i]['id']}-{groups[j]['id']}") for i, j in pair_list]

    records = []
    start_all = time.monotonic()
    for trial_idx, (free_ids, label) in enumerate(trials):
        remaining = args.total - (time.monotonic() - start_all)
        if remaining <= 0.5:
            break
        m = base.copy()
        free_names = {n for i in free_ids for n in groups[i]["names"]}
        for v in m.getVars():
            v.Start = vals.get(v.VarName, 0.0)
            if v.Obj != 0 and v.VarName not in free_names:
                value = round(vals.get(v.VarName, 0.0))
                v.LB = value
                v.UB = value
        m.Params.OutputFlag = 1
        m.Params.LogFile = str(args.log_dir / f"{label}.log")
        m.Params.TimeLimit = min(args.per_trial, remaining)
        m.Params.Threads = args.threads
        m.Params.MIPGap = 0
        m.Params.MIPGapAbs = 0
        m.Params.Cutoff = cutoff
        m.Params.MIPFocus = 3
        m.Params.Cuts = 2
        m.Params.NumericFocus = 2
        m.Params.FeasibilityTol = 1e-9
        m.Params.IntFeasTol = 1e-9
        t0 = time.monotonic()
        m.optimize()
        elapsed = time.monotonic() - t0
        names = {gp.GRB.CUTOFF: "CUTOFF", gp.GRB.INFEASIBLE: "INFEASIBLE", gp.GRB.OPTIMAL: "OPTIMAL", gp.GRB.TIME_LIMIT: "TIME_LIMIT"}
        rec = {
            "label": label,
            "free_blocks": [groups[i]["id"] for i in free_ids],
            "free_design_variables": len(free_names),
            "status": names.get(m.Status, str(m.Status)),
            "status_code": m.Status,
            "strict_better_excluded": m.Status in (gp.GRB.CUTOFF, gp.GRB.INFEASIBLE),
            "elapsed": elapsed,
            "nodes": m.NodeCount,
            "solutions": m.SolCount,
            "objective": m.ObjVal if m.SolCount else None,
            "bound": m.ObjBound,
        }
        if m.SolCount and m.ObjVal < incumbent - 0.005:
            m.write(str(args.solution_dir / f"{label}.sol"))
        records.append(rec)
        print(json.dumps(rec), flush=True)

    result = {
        "claim_scope": "exact local strict-improvement test; not a global proof unless all design blocks are jointly free",
        "incumbent": incumbent,
        "objective_lattice": 0.01,
        "strict_cutoff": cutoff,
        "groups": groups,
        "attempted": len(records),
        "strict_better_excluded": sum(r["strict_better_excluded"] for r in records),
        "timeouts": sum(r["status"] == "TIME_LIMIT" for r in records),
        "improving_solutions": sum(r["objective"] is not None and r["objective"] < incumbent - 0.005 for r in records),
        "elapsed": time.monotonic() - start_all,
        "trials": records,
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: result[k] for k in ("attempted", "strict_better_excluded", "timeouts", "improving_solutions", "elapsed")}, indent=2))


if __name__ == "__main__":
    main()
