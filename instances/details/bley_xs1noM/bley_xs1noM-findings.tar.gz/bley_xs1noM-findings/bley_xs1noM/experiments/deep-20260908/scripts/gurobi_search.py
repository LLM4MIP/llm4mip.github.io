#!/usr/bin/env python3
"""Proof-aware Gurobi search for bley_xs1noM with a strict MIP start."""

from __future__ import annotations

import argparse
import gzip
import json
import math
import time
from pathlib import Path

import gurobipy as gp


def read_sol(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix == ".gz" else open
    values = {}
    with opener(path, "rt", encoding="latin-1") as handle:
        for line in handle:
            f = line.split()
            if len(f) >= 2 and not f[0].startswith(("#", "=")):
                try:
                    values[f[0]] = float(f[1])
                except ValueError:
                    pass
    return values


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mps", type=Path, required=True)
    ap.add_argument("--start", type=Path, required=True)
    ap.add_argument("--seconds", type=float, default=600)
    ap.add_argument("--threads", type=int, default=2)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--mode", choices=["primal", "dual", "balanced", "strict"], default="balanced")
    ap.add_argument("--incumbent", type=float, default=3855895.86)
    ap.add_argument("--log", type=Path, required=True)
    ap.add_argument("--json", type=Path, required=True)
    ap.add_argument("--sol", type=Path, required=True)
    args = ap.parse_args()

    args.log.parent.mkdir(parents=True, exist_ok=True)
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.sol.parent.mkdir(parents=True, exist_ok=True)
    m = gp.read(str(args.mps))
    vals = read_sol(args.start)
    for v in m.getVars():
        v.Start = vals.get(v.VarName, 0.0)
    m.Params.TimeLimit = args.seconds
    m.Params.Threads = args.threads
    m.Params.Seed = args.seed
    m.Params.LogFile = str(args.log)
    m.Params.MIPGap = 0
    m.Params.MIPGapAbs = 0
    m.Params.NumericFocus = 2
    m.Params.FeasibilityTol = 1e-9
    m.Params.IntFeasTol = 1e-9
    if args.mode == "primal":
        m.Params.MIPFocus = 1
        m.Params.Heuristics = 0.5
        m.Params.RINS = 100
    elif args.mode == "dual":
        m.Params.MIPFocus = 3
        m.Params.Cuts = 3
        m.Params.Heuristics = 0.02
        m.Params.Symmetry = 2
    elif args.mode == "strict":
        # Objective data are multiples of 0.01 on integer variables.  Hence
        # objective <= incumbent - 0.005 is exactly the strict-better decision.
        m.Params.MIPFocus = 3
        m.Params.Cuts = 3
        m.Params.Heuristics = 0.2
        m.Params.Cutoff = args.incumbent - 0.005
    else:
        m.Params.MIPFocus = 0
        m.Params.Heuristics = 0.15
        m.Params.Cuts = 2

    start = time.monotonic()
    m.optimize()
    elapsed = time.monotonic() - start
    status_names = {
        gp.GRB.OPTIMAL: "OPTIMAL", gp.GRB.INFEASIBLE: "INFEASIBLE",
        gp.GRB.INF_OR_UNBD: "INF_OR_UNBD", gp.GRB.TIME_LIMIT: "TIME_LIMIT",
        gp.GRB.CUTOFF: "CUTOFF", gp.GRB.INTERRUPTED: "INTERRUPTED",
        gp.GRB.SUBOPTIMAL: "SUBOPTIMAL", gp.GRB.USER_OBJ_LIMIT: "USER_OBJ_LIMIT",
    }
    result = {
        "mode": args.mode,
        "seed": args.seed,
        "seconds_limit": args.seconds,
        "elapsed_seconds": elapsed,
        "status_code": m.Status,
        "status": status_names.get(m.Status, str(m.Status)),
        "solution_count": m.SolCount,
        "objective": m.ObjVal if m.SolCount else None,
        "bound": m.ObjBound if hasattr(m, "ObjBound") else None,
        "gap": m.MIPGap if m.SolCount and math.isfinite(m.ObjVal) else None,
        "nodes": m.NodeCount,
        "iterations": m.IterCount,
        "strict_cutoff": args.incumbent - 0.005 if args.mode == "strict" else None,
        "global_optimality_proved": m.Status == gp.GRB.OPTIMAL and m.SolCount > 0,
        "strict_better_infeasibility_proved": args.mode == "strict" and m.Status == gp.GRB.CUTOFF,
    }
    if m.SolCount:
        m.write(str(args.sol))
    args.json.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
