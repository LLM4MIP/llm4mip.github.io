#!/usr/bin/env python3
"""COPT 8 variable-type probe and optional district-oracle solve.

Run on altman with the COPT 8 Python path.  The script is CPU-only and never
uses GPU resources.
"""

from __future__ import annotations

import argparse
import json
from collections import Counter

import coptpy as cp


def safe_attr(obj, *names):
    for name in names:
        try:
            return getattr(obj, name)
        except Exception:
            pass
    return None


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model")
    parser.add_argument("--solve", action="store_true")
    parser.add_argument("--time-limit", type=float, default=300.0)
    parser.add_argument("--threads", type=int, default=32)
    parser.add_argument("--rel-gap", type=float, default=1e-4)
    parser.add_argument("--solution")
    args = parser.parse_args()

    env = cp.Envr()
    model = env.createModel("probe")
    model.read(args.model)
    variables = model.getVars()
    types = Counter(str(safe_attr(variable, "vtype", "VType")) for variable in variables)
    result = {
        "model": args.model,
        "copt_version": [cp.COPT.VERSION_MAJOR, cp.COPT.VERSION_MINOR, cp.COPT.VERSION_TECHNICAL],
        "variables": len(variables),
        "rows": len(model.getConstrs()),
        "variable_type_counts": dict(types),
        "gpu_used": False,
        "solved": False,
    }
    if args.solve:
        model.setParam(cp.COPT.Param.TimeLimit, args.time_limit)
        model.setParam(cp.COPT.Param.Threads, args.threads)
        model.setParam(cp.COPT.Param.RelGap, args.rel_gap)
        try:
            model.setParam(cp.COPT.Param.Logging, 1)
        except Exception:
            pass
        model.solve()
        result.update({
            "solved": True,
            "status": str(safe_attr(model, "status", "Status")),
            "objective": str(safe_attr(model, "objval", "ObjVal")),
            "best_bound": str(safe_attr(model, "bestbnd", "BestBnd")),
            "node_count": str(safe_attr(model, "nodecnt", "NodeCnt")),
            "relative_gap_limit": args.rel_gap,
        })
        if args.solution and safe_attr(model, "hasmipsol", "HasMipSol"):
            model.write(args.solution)
            result["solution"] = args.solution
    print("RESULT_JSON=" + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
