#  `bley_xs1noM` in-depth research report

**Date of study:** 2026 -09 -08
**: ** 00: 10: 38.041 00: 52: 39.507 (Asia/Shanghai)
**Actual duration:** 2,521.466 seconds, which is 42 points 1.466 seconds
**solver:** Gurobi 13.0.2 , mainly experimenting with 2 threads

##  1. Concluded

This round did not prove global optimality of `bley_xs1noM` or find a strictly feasible solution better than **3,855,895.86**. The best primal solution remains the variable-by-variable projection of the public solution for sibling `bley_xs1`; it improves the original MIPLIB `bley_xs1noM` page value **3,873,690.77**by**17,794.91**.

But this round has seen three new verifiable advances:

1. **Equivalent Big-M strengthening.** Mechanical inspection of the original model identified 349 constraints of the form `10^20·Σz − x ≥ 0`, containing 1,333 coefficients equal to `10^20`. Since `z` is 0/1 and `0≤x≤100`, replacing these coefficients with 100 leaves the integer feasible set and objective unchanged. The largest matrix-coefficient scale falls from `10^20` to approximately `3×10^4`.
2.  **conditions optimized proof.** fixed the current solution 2,253 zero-cost route/measurement variable, after re-exact optimization of all 990 non-zero-cost design variables; Gurobi in the 1 node proof optimal objective remains **3,855,895.86**.
3. **Capacity-block local optimality proof.** After recovering 53 capacity-design blocks, all 53 single-block neighborhoods and 20 high-cost two-block neighborhoods were tested. All 73 models reached `CUTOFF`, without timeout or improvement; every run kept all zero-cost routing/metric variables free. The solution is therefore locally optimal over all single-capacity-block neighborhoods and the 20 tested two-block neighborhoods.

None of these three results is a global optimality proof. In 720 seconds, the global strict-improvement decision search raised the lower bound only to **3,344,924.0428**, still well below the incumbent.

##  2. Background of the problem

MIPLIB describes the problem as a minimal cost network expansion problem with a set of finite link capacities and undivided routes. Its actual context is communication network planning: selecting or installing discrete capacity for each link, while placing each communication need entirely on a path, and making all the link capacity sufficient to carry through its needs.

The official MIPLIB page and Andreas Bley's original paper and doctoral thesis are recorded in [`SOURCES.md`](SOURCES-20260908.md). These sources directly informed this round: neighborhoods and strengthening target repeated link-capacity modules rather than relying solely on generic parameter tuning.

##  3. Gurobi Structure Reading with public solution audit

Gurobi's reading of the original compression MPS:

|  Project |  Numerical |
|---|---:|
|  Variables |  3,243  |
|  constraint |  3,290  |
| Gurobi reads nonzero entries |  26,111  |
|  integer variable |  3,243  |
|  `[0,1]` integer variable |  2,360  |
| `[0,100]` is a common integer variable |  883  |
| Non-zero objective coefficients variable |  990  |
| Zero objective coefficients variable |  2,253  |
|  `<= / = / >=` constraint |  320 / 202 / 2,768  |

The objective support variable 990 can be restored to:

-  An early capacity group of 11 with a total of 25 variables;
-  `x1034` is a 42 repeat link capacity module, with each algebraic block width 23; the last block is adjacent to the first zero-cost routing variable, so the actual objective support total remains 990.

The original MPS is consistent with the row, matrix, RHS, objective and integrality complete of the sibling `bley_xs1`; the difference is only the primal bound of the general integer variable 883: sibling without finite primal bound, `noM` for 100. Thus the feasible set of `noM` is a subset of the sibling feasible set, but the two models cannot be declared as a binary equivalent.

The public projection solution and the complete solution of this round reinforcement model output are returned to the **original** `bley_xs1noM.mps.gz` audit:

- objective :  3,855,895.86 ; 
-  Unknown variable: 0;
-  The maximum row violation: 0;
-  The maximum bound violation: 0;
-  The maximum integrity violation: 0;
-  The decimal exact solution dilator also violates the 0 line, boundary and integer.

##  4. equivalent Big-M reinforcement

The original model had a 349 clause containing the constraint of `10^20`.

\[
10^{20}\sum_{j\in J}z_j-x\ge 0,\qquad
z_j\in\{0,1\},\quad 0\le x\le100,\ x\in\mathbb Z.
\]

The `10^20` and 100 equivalents can be state-by-state proof:

-  If `Σz=0`, both are `-x≥0`; when combined with `x≥0`, both are mandatory `x=0`;
-  If the `Σz≥1` is at least `100-x≥0` after the left end of the 100 is used, it is guaranteed by `x≤100`; the original `10^20` is automatically satisfied, of course.

The replacement therefore neither removes nor adds any integer feasible points. The certificate covers 349 constraints and 1,333 replaced coefficients without relying on semantic guesses. The ordinary LP relaxation objective is approximately **2,920,144.9204** both before and after strengthening. The current root LP objective is unchanged, but numerically ill-conditioned coefficients are removed and strict search produces a slightly better final lower bound.

## 5. Global and local experiments

###  5.1 strict improved judgment

Decimal parsing of the original MPS confirms that every objective coefficient is an integer multiple of 0.01. The current objective is 3,855,895.86, so any strictly better integer solution must have objective at most 3,855,895.85. The experiment expresses this decision using `Cutoff=3,855,895.855`.

|  Model |  Pattern |  Time |  Nodes |  New solution | Finally lower bound |  Conclusion |
|---|---|---:|---:|---:|---:|---|
|  original MPS |  strict, seed 11  |  720.02 s  |  2,838  |  0  |  3,344,369.4370  |  `TIME_LIMIT`  |
| tight-M | strict, seed 17 | 720.01 s | 1,170 | 0 | 3,344,924.0428 | `TIME_LIMIT` |

The tight-M lower bound is **554.6058** higher than the original formulation under the same time limit. This is a dual improvement under one fixed compute budget, not a permanent global certificate. Neither run returned `CUTOFF`, so failure to find a better solution does not imply optimality.

###  5.2 fixed routing, re-optimized capacity design

2,253 is a zero-cost variable that releases all 990 non-zero-cost design variables:

|  Status |  Nodes |  Time | Optimum objective |
|---|---:|---:|---:|
| `OPTIMAL` | 1 | 0.019 s | 3,855,895.86 |

This is the best outcome for strict conditions: there is no cheaper capacity installation combination for the current path/measurement selection.

###  5.3 Structured capacity blocks LNS

Each neighborhood has only a fixed neighborhood outside the objective support variable; all zero-cost routing/measurement variables remain free, so solvers can be routed for global reconstruction.

|  Neighborhood |  Count |  `CUTOFF`  |  Timeout |  Improvement |
|---|---:|---:|---:|---:|
| All single-capacity units |  53  |  53  |  0  |  0  |
| High-cost dual capacity blocks |  20  |  20  |  0  |  0  |
|  Total |  73  |  73  |  0  |  0  |

This proves local optimality for the complete single-block exchange neighborhood and the listed 20 two-block neighborhoods. It does not cover joint changes in arbitrary subsets of the 53 blocks, so it is not a global proof.

###  Global search for 5.4 by primal

On tight-M, accept 3,855,895.86 as the MIP start, use `MIPFocus=1`, higher heuristic intensity and RINS, and run 540.01 seconds:

-  the node 7,279;
-  The optimum primal remains for 3,855,895.86;
-  There are no strict improvements.
-  The lower bound of the circle is 3,111,870.8792, gap 19.2958 %.

This round of objective is to find a new solution rather than proof lower bound, so it cannot be used to replace the dual-oriented strict above.

##  6. Evidence grades and boundaries of conclusion

|  Conclusion |  Status |  Evidence |
|---|---|---|
| 3,855,895.86 is the strictly feasible solution to the original noM. | It's been proven | Gurobi audit + Decimal exact audit of the original MPS |
| Improvements to the MIPLIB noM original public solution 17,794.91 | It's been proven | Both public solutions have exact values on the same source MPS. |
| 349 bar Big-M can be compressed from `10^20` equivalent to 100 | It's been proven | Complete row by row pattern affirmations and two-state logic proof |
| The current design is optimal for fixed routing conditions | It's been proven | `OPTIMAL`, gap 0 |
| Current solution single capacity blocks locally optimal | It's been proven | 53 / 53 strictly improved model `CUTOFF` |
| 20 double block neighborhood with no strict improvement | It's been proven |  20/20 `CUTOFF`  |
| There is no better global solution. | **is unproven** | The `TIME_LIMIT` is a dual-purpose strict global operating system. |
| Current solution for global optimal | **is unproven** | There is no complete gap closure or global infeasible certificate that can be independently verified. |

##  7. Experience summary and follow-up direction

1. **Sibling transfer is a highly effective primal method.** The algebraic relationship between `bley_xs1` and `noM` supports strict transfer of a better sibling solution to the target model, but does not itself establish global optimality.
2.  **This instance the current bottleneck is not a simple capacity mitigation.** fixed routing is completely design optimized, all single blocks as well as the already measured double blocks cannot be improved, indicating that if there is an optimal solution, it is likely that multi-link capacity and multi-commodity routing synchronous reconstruction will be required.
3.  **numerical clearance is worth preserving. The tightness of** `10^20→100` has complete equivalent proof, eliminates the Gurobi big coefficient warning, and produces an increase in the lower bound of the same budget as about 554.61. Subsequent solutions should be prioritized using the tight-M model, while ultimately testing solutions on the original MPS.
4.  **should be upgraded from a block LNS to a block by conflict decomposition.** can master the design block of a 42 link, sub-problem the feasibility of non-differentiated routes; extract the capacity conflict cut from infeasible routing. This is more likely to improve the lower bound while remaining auditable than continuing to expand the Gurobi time limit.
5.  **is suitable for continuing to do multi-block custom neighborhoods.** can be linked to share a commodity map to select the related 3 8 capacity blocks, rather than just cost-picking pairs; each time the route of the relevant commodity is left variable free to complete.

##  8 . Verification files

-  `../experiments/deep-20260908/results/gurobi-structure-audit.json`: The original MPS structure and public projection solution audit.
-  `../experiments/deep-20260908/results/bigM-equivalence-certificate.json`: 349 article constraint and complete certificate of the replacement coefficient 1,333.
-  `../experiments/deep-20260908/bley_xs1noM-tightM100.mps.gz`: an integers feasible set equivalent strengthening model.
-  `../experiments/deep-20260908/results/strict-seed11-720s.json`: the original strict global search.
-  `../experiments/deep-20260908/results/tightM-strict-seed17-720s.json`: Strengthened strict global search.
-  `../experiments/deep-20260908/results/routing-fixed.json`: The best proof of the conditions after routing is fixed.
-  `../experiments/deep-20260908/results/block-lns-720s.json`: 53 single block and 20 double block results.
-  `../experiments/deep-20260908/results/tightM-primal-seed23-540s.json`: partially primal global search.
-  `../experiments/deep-20260908/results/tightM-primal-original-mps-audit.json`: Enhanced output solution re-placing the Gurobi audit of the original MPS.
- `../experiments/deep-20260908/results/tightM-primal-exact-validation.json` : Decimal exact audit .
-  `../experiments/deep-20260908/logs/`: Gurobi diary solved each time.
-  `../experiments/deep-20260908/scripts/`: all reproducible experimental scripts


