# Package manifest: cvrpa-n64k9vrpi

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 65
Excluded source files: 1

## Included files

- `README.md`
- `analysis/compiled-mps-projection.json`
- `analysis/copt-route-lift-summary.json`
- `analysis/degree-relaxation-kge17-dual.json`
- `analysis/degree-relaxation-kge17-dual.validation.json`
- `analysis/gurobi-structure-euler4.json`
- `analysis/gurobi-structure.json`
- `analysis/k10-nonmerge-premises.json`
- `analysis/k10-singleton-load-partitions.json`
- `analysis/route-count-proof.md`
- `analysis/semantic-witness-1401.json`
- `analysis/source-equivalence.json`
- `experiments/audit_compiled_mps_projection.py`
- `experiments/audit_nonmerge_assumptions.py`
- `experiments/audit_source_equivalence.py`
- `experiments/build_degree_relaxation_dual.py`
- `experiments/check_degree_relaxation_dual.py`
- `experiments/check_indicator_mps_solution.py`
- `experiments/copt_route_lift.py`
- `experiments/copt_standard_cvrp.py`
- `experiments/cpsat_cvrp_cutoff.py`
- `experiments/exact_load_partition.py`
- `experiments/gurobi_customer_edge_cutoff.py`
- `experiments/gurobi_standard_cvrp_flow.py`
- `experiments/gurobi_structure_export.py`
- `experiments/run_route_count_copt_partition.sh`
- `experiments/run_route_count_flow_partition.sh`
- `experiments/run_route_count_partition.sh`
- `logs/copt-route-lift.log`
- `logs/executed-scripts/copt_standard_cvrp_k11_nonmerge.py`
- `logs/executed-scripts/copt_standard_cvrp_k12-k14.py`
- `logs/executed-scripts/gurobi_customer_edge_cutoff_k14-k16.py`
- `logs/executed-scripts/gurobi_customer_edge_nonmerge_k10.py`
- `logs/route-count/copt-k11-nonmerge/copt-standard-cvrp-summary.json`
- `logs/route-count/copt-k11-nonmerge/copt-standard-cvrp.log`
- `logs/route-count/copt-k12/copt-standard-cvrp-summary.json`
- `logs/route-count/copt-k12/copt-standard-cvrp.log`
- `logs/route-count/copt-k12/stdout.log`
- `logs/route-count/copt-k13/copt-standard-cvrp-summary.json`
- `logs/route-count/copt-k13/copt-standard-cvrp.log`
- `logs/route-count/copt-k13/stdout.log`
- `logs/route-count/copt-k14/copt-standard-cvrp-summary.json`
- `logs/route-count/copt-k14/copt-standard-cvrp.log`
- `logs/route-count/copt-k14/stdout.log`
- `logs/route-count/gurobi-k10-nonmerge/gurobi-customer-edge-cutoff-summary.json`
- `logs/route-count/gurobi-k10-nonmerge/gurobi-customer-edge-cutoff.log`
- `logs/route-count/gurobi-k10-nonmerge/stdout.log`
- `logs/route-count/gurobi-k14/gurobi-customer-edge-cutoff-summary.json`
- `logs/route-count/gurobi-k14/gurobi-customer-edge-cutoff.log`
- `logs/route-count/gurobi-k14/stdout.log`
- `logs/route-count/gurobi-k15/gurobi-customer-edge-cutoff-summary.json`
- `logs/route-count/gurobi-k15/gurobi-customer-edge-cutoff.log`
- `logs/route-count/gurobi-k15/stdout.log`
- `logs/route-count/gurobi-k16/gurobi-customer-edge-cutoff-summary.json`
- `logs/route-count/gurobi-k16/gurobi-customer-edge-cutoff.log`
- `logs/route-count/gurobi-k16/stdout.log`
- `solutions/cvrpa-1401-full.sol`
- `solutions/cvrpa-1401-full.validation.json`
- `solutions/miplib-incumbent-1617.sol.gz`
- `sources/A-n64-k9.sol`
- `sources/A-n64-k9.vrp`
- `sources/A-n64-k9.vrp.dzn`
- `sources/A-n64-k9.vrp.metadata`
- `sources/PROVENANCE.md`
- `sources/cvrp.mzn`

## Excluded files

- `input/cvrpa-n64k9vrpi.mps.gz (4224315 bytes; raw benchmark input; sha256 725230241fe30c12913e054214190f0551e66f191835fba6bdca11c13e8bfbd8)`
