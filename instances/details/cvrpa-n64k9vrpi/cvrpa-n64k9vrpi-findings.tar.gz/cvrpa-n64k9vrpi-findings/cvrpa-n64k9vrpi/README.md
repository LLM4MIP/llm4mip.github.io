# cvrpa-n64k9vrpi: OPT = 1401

2026-09-14 independent dual-bound review: [adopted bound, proof chain, checks, and limitations](../../docs/dual-bound-audit-2026-09-14/cases/cvrpa-n64k9vrpi.zh.md). Reviewed lower bound: **1401**. This review distinguishes exact, literature, and numerical evidence; historical statements below remain dated records.

## Result

The downloaded indicator MPS has optimum objective **1401**.  As of 2026-09-08,
MIPLIB listed this instance as open with incumbent 1617, so the new solution
improves the published upper bound by 216, or **13.3581%**, and closes the gap.

The conclusion uses a deliberately explicit mixture of evidence.  The upper
bound is a full MPS solution checked at exact zero tolerance.  The lower bound
combines a coefficient-level projection from the MPS to a free-fleet CVRP,
CVRPLIB's external `Opt=yes` status for the fixed-nine instance, terminal
Gurobi/COPT infeasibility runs for the remaining finite route-count cases, and
an independently replayable exact rational certificate for 17 or more routes.
There is no single portable proof trace for that complete lower-bound chain;
the precise evidence boundary is stated below and in the route-count note.

The full 75,340-entry solution is
[`solutions/cvrpa-1401-full.sol`](solutions/cvrpa-1401-full.sol).  Its
solver-independent exact validation is
[`solutions/cvrpa-1401-full.validation.json`](solutions/cvrpa-1401-full.validation.json).
The route-count argument and its precise logical boundaries are documented in
[`analysis/route-count-proof.md`](analysis/route-count-proof.md).

## Mandatory Gurobi structure read

The original MPS was first loaded read-only with Gurobi 13.0.1 on `euler4`;
`optimize()` was not called.  Gurobi's native indicator view reports:

- 75,340 variables: 49,951 integer and 25,389 continuous;
- 75,339 ordinary linear rows and 353,044 linear nonzeros;
- 118,943 general constraints, all indicators;
- one nonzero objective coefficient, on the variable named `objective`.

Among the indicators, 118,443 activate at one and enforce a two-term equality;
500 activate at zero and enforce a one-term inequality.  The complete reports
are [`analysis/gurobi-structure-euler4.json`](analysis/gurobi-structure-euler4.json)
and [`analysis/gurobi-structure.json`](analysis/gurobi-structure.json).  The
former records Gurobi 13.0.1, Python 3.10.20, the Linux platform, the compressed
MPS SHA-256, and `read_only_no_optimize=true`.

MIPLIB's web-page dimensions are larger because they describe an expanded view
of the indicator formulation.  The counts above are Gurobi's native view of
the exact downloaded bytes; this difference is not evidence of a different
instance.

## Recovered source and data identity

MIPLIB describes `cvrpa-n64k9vrpi` as a CPLEX 12.7.1 indicator-MPS compilation
of a MiniZinc Challenge CVRP model.  The recovered source is the MiniZinc
benchmark `cvrp/cvrp.mzn` with data `A-n64-k9.vrp.dzn`, corresponding to
CVRPLIB's Augerat `A-n64-k9` instance.

[`analysis/source-equivalence.json`](analysis/source-equivalence.json) checks
the identification entry by entry:

- the original instance has 64 points, consisting of one depot and 63
  customers;
- MiniZinc customer `c` is CVRPLIB node `c+1`, while DZN matrix index 0 is the
  depot;
- all 63 demands agree and are positive, capacity is 100, and total demand is
  848;
- all 4,096 entries of the 64 by 64 distance matrix agree with TSPLIB
  `EUC_2D`, `floor(sqrt(dx^2+dy^2)+0.5)`;
- the model permits as many as 63 vehicles, rather than fixing the fleet at
  the nine vehicles encoded in the historical instance name; and
- the finite arrival-time domain is redundant for capacity-feasible routes:
  the audit's safe per-route upper bound is 2,596, below `timeBudget=5,662`.

The source URLs, retrieval date, and hashes are in
[`sources/PROVENANCE.md`](sources/PROVENANCE.md).  In particular, the exact
compressed MPS used here has SHA-256
`725230241fe30c12913e054214190f0551e66f191835fba6bdca11c13e8bfbd8`.

## Coefficient-level projection from the MPS

Source-name identification and one feasible witness are not enough to transfer
a CVRP lower bound to an anonymous compiled MPS.  The independent exact parser
behind [`analysis/compiled-mps-projection.json`](analysis/compiled-mps-projection.json)
therefore checks a sufficient set of actual MPS coefficients and indicators.
It:

- closes 24,696 unconditional two-variable alias equations;
- recognizes all 252 shared one-hot element gadgets (`4N`);
- uses 126 predecessor-indexed gadgets plus 63 fixed end-to-next-start arcs to
  prove that the effective 189-entry successor vector is a permutation;
- verifies all 126 customer/start distance, arrival, and load-propagation
  blocks against the DZN data;
- verifies positive demands, integral loads in `0..100`, and the exact
  objective equation `objective = sum(arrival_time[127..189])`.

Deleting the 63 fixed connector arcs from this permutation leaves start-to-end
paths and possible customer-only cycles.  Positive demand and load propagation
exclude the cycles; each remaining path has load at most 100.  Arrival
propagation makes each end arrival at least the integer length of its route, so
the projected CVRP cost is no greater than the MPS objective.

This is deliberately a **one-way sufficient projection**: every feasible MPS
point yields capacity-feasible free-fleet routes of no greater cost.  It is not
a claim to reverse-compile every auxiliary constraint.  That one direction is
the direction needed for lower bounds.

## The 1401 feasible witness

CVRPLIB's downloaded nine-route solution has route loads
`[99, 56, 100, 99, 98, 100, 97, 99, 100]` and route costs
`[184, 47, 236, 138, 152, 165, 118, 98, 263]`.  It covers customers 1 through
63 exactly once and has recomputed total cost 1401; the full routes and all
data checks appear in
[`analysis/source-equivalence.json`](analysis/source-equivalence.json).

[`experiments/copt_route_lift.py`](experiments/copt_route_lift.py) constructs
the 189-entry `successor`, `predecessor`, `vehicle`, `load`, and `arrivalTime`
arrays, fixes every surviving source-level variable plus `objective=1401`, and
asks COPT only to complete compiler auxiliaries.  COPT 8.0.4 completed this
fixed subproblem in presolve in 0.504 seconds with zero branch-and-bound nodes.
The semantic witness and summary are
[`analysis/semantic-witness-1401.json`](analysis/semantic-witness-1401.json)
and [`analysis/copt-route-lift-summary.json`](analysis/copt-route-lift-summary.json).

The lift summary reports `best_bound=1401`, but that number belongs to the
subproblem in which both the semantic route variables and the objective were
already fixed.  It is a feasibility construction and **must not be interpreted
as a global lower bound for the original MPS**.

The resulting solution was checked without Gurobi or COPT by
[`experiments/check_indicator_mps_solution.py`](experiments/check_indicator_mps_solution.py).
The checker parses the compressed MPS with Python `Decimal`, treats a missing
solution entry as zero, and activates an indicator row only when its binary
trigger equals the stated value.  At exact zero tolerance it reports:

- all 75,340 MPS variables present in the solution;
- exact objective 1401;
- zero violations among 75,339 ordinary rows;
- zero violations among 880 active indicators, with 118,063 inactive;
- zero bound, integrality, malformed-trigger, and unknown-entry violations.

The full-solution SHA-256 is
`256a337f452f117720cfa66d965fcad31c9085f1b18ffafe62694e924172c4ed`.

## Optimality argument and evidence status

Total demand and capacity give at least `ceil(848/100)=9` nonempty routes.
CVRPLIB lists fixed-nine `A-n64-k9` with upper bound 1401 and `Opt=yes`.
That is authoritative external database evidence, but this repository does not
contain a standalone exact proof of the fixed-nine optimum.

The larger route counts were separated because the MiniZinc model allows a
free fleet.  Every possible count is now covered:

| nonempty routes | current evidence for cost `<=1400` | status used here |
|---:|---|---|
| 9 | CVRPLIB reports 1401 and `Opt=yes` | external fixed-fleet result, not an in-repository proof |
| 10 | Gurobi 13.0.1 terminally excluded the exact nonmerge submodel; the fixed-nine result and merge lemma show every improving 10-route solution would lie in that submodel | solver-certified exclusion, conditional on the external fixed-nine result |
| 11 | COPT 8.0.4 terminally excluded the nonmerge submodel; its 10-route prerequisite is now supplied by the preceding row | solver-certified exclusion, conditional on the same external fixed-nine result |
| 12--13 | COPT 8.0.4 returned terminal status 2 (`INFEASIBLE`) on the exact directed-flow models | solver-certified exclusion |
| 14 | both COPT 8.0.4 and Gurobi 13.0.1 returned terminal infeasibility | independently solver-certified exclusion |
| 15--16 | Gurobi 13.0.1 returned terminal `INFEASIBLE` | solver-certified exclusion |
| 17--63 | exact rational dual gives cost at least `2943/2 = 1471.5` | independently replayable exclusion |

The decisive fixed-10 archive is
[`logs/route-count/gurobi-k10-nonmerge/`](logs/route-count/gurobi-k10-nonmerge/),
and the exact executed source is
[`logs/executed-scripts/gurobi_customer_edge_nonmerge_k10.py`](logs/executed-scripts/gurobi_customer_edge_nonmerge_k10.py).
The summary records `INFEASIBLE` after 380.254 seconds and 333,634 nodes for
`K=10`, objective at most 1400, with the nonmerge strengthening enabled.  Its
script SHA-256 matches the archived source.  The JSON's short
`proof_statement` must be read together with
`forbid_mergeable_route_pairs=true` and its recorded prerequisite: the run by
itself excludes the nonmerge submodel, while the fixed-nine result plus the
merge lemma makes that submodel exhaustive for an improving 10-route solution.

The rational certificate and standard-library verifier are
[`analysis/degree-relaxation-kge17-dual.json`](analysis/degree-relaxation-kge17-dual.json)
and
[`analysis/degree-relaxation-kge17-dual.validation.json`](analysis/degree-relaxation-kge17-dual.validation.json).
The solver runs are exhaustive terminal results for exact CVRP formulations
or mathematically valid conditional strengthenings of them, but neither
Gurobi nor COPT emitted a standalone formal proof trace.  See
[`analysis/route-count-proof.md`](analysis/route-count-proof.md) for the
formulations, run inventory, and complete route-count disjunction.

## Reproduce the solver-independent checks

Run these commands from the repository root:

```bash
python instances/cvrpa-n64k9vrpi/experiments/audit_source_equivalence.py \
  instances/cvrpa-n64k9vrpi/sources/A-n64-k9.vrp \
  instances/cvrpa-n64k9vrpi/sources/A-n64-k9.vrp.dzn \
  instances/cvrpa-n64k9vrpi/sources/A-n64-k9.sol \
  instances/cvrpa-n64k9vrpi/sources/cvrp.mzn \
  --json instances/cvrpa-n64k9vrpi/analysis/source-equivalence.json

python instances/cvrpa-n64k9vrpi/experiments/audit_compiled_mps_projection.py \
  instances/cvrpa-n64k9vrpi/input/cvrpa-n64k9vrpi.mps.gz \
  instances/cvrpa-n64k9vrpi/sources/A-n64-k9.vrp.dzn \
  --json instances/cvrpa-n64k9vrpi/analysis/compiled-mps-projection.json

python instances/cvrpa-n64k9vrpi/experiments/check_indicator_mps_solution.py \
  instances/cvrpa-n64k9vrpi/input/cvrpa-n64k9vrpi.mps.gz \
  instances/cvrpa-n64k9vrpi/solutions/cvrpa-1401-full.sol \
  --json instances/cvrpa-n64k9vrpi/solutions/cvrpa-1401-full.validation.json

python instances/cvrpa-n64k9vrpi/experiments/check_degree_relaxation_dual.py \
  instances/cvrpa-n64k9vrpi/sources/A-n64-k9.vrp.dzn \
  instances/cvrpa-n64k9vrpi/analysis/degree-relaxation-kge17-dual.json \
  --json instances/cvrpa-n64k9vrpi/analysis/degree-relaxation-kge17-dual.validation.json

python instances/cvrpa-n64k9vrpi/experiments/audit_nonmerge_assumptions.py \
  instances/cvrpa-n64k9vrpi/sources/A-n64-k9.vrp.dzn \
  instances/cvrpa-n64k9vrpi/analysis/k10-nonmerge-premises.json \
  --routes 10
```

The two source/MPS audit wrappers call the repository's generic implementations
under `instances/cvrpb-n45k5vrpi/experiments/`; those generic files are part of
the reproducible dependency and must be retained with this directory.

## Evidence boundary

- CVRPLIB's `Opt=yes` supplies the fixed-nine lower bound only as an external
  authoritative status; no independently replayable fixed-nine proof trace is
  stored here.
- The 10--16 exclusions rely on terminal commercial-solver statuses.  The
  underlying exact formulations and the conditional nonmerge inequalities are
  audited, but the solvers did not emit independently checkable branch-and-bound
  proof traces.
- In particular, the fixed-10 terminal run is not an unconditional exact-CVRP
  certificate in isolation; it becomes exhaustive only when combined with the
  fixed-nine database result and the verified route-merging implication.
- Thus `OPT=1401` is a mixed database/computational conclusion, not a portable
  formally verified lower-bound certificate.  The feasible 1401 MPS witness
  and the `K>=17` rational layer are independently replayable.
