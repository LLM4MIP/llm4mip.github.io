# Source provenance

Retrieved and checked on 2026-09-08.

- MIPLIB instance page: <https://miplib.zib.de/instance_details_cvrpa-n64k9vrpi.html>
- Original MPS: <https://miplib.zib.de/WebData/instances/cvrpa-n64k9vrpi.mps.gz>
- MIPLIB incumbent 1617 (solution 4):
  <https://miplib.zib.de/downloads/solutions/cvrpa-n64k9vrpi/4/cvrpa-n64k9vrpi.sol.gz>
- Original MIPLIB decomposition (downloaded for inspection but not duplicated in Git):
  <https://miplib.zib.de/WebData/decomps_orig/cvrpa-n64k9vrpi.dec>
- CVRPLIB Augerat A-set table: <https://galgos.inf.puc-rio.br/cvrplib/en/instances/1>
- CVRPLIB `A-n64-k9` instance: <https://galgos.inf.puc-rio.br/cvrplib/en/download/instance/28>
- CVRPLIB `A-n64-k9` best-known solution: <https://galgos.inf.puc-rio.br/cvrplib/en/download/bks/28>
- MiniZinc benchmark model and data:
  <https://github.com/MiniZinc/minizinc-benchmarks/tree/master/cvrp>

The exact hashes used by the audits are:

| file | SHA-256 |
|---|---|
| `cvrpa-n64k9vrpi.mps.gz` | `725230241fe30c12913e054214190f0551e66f191835fba6bdca11c13e8bfbd8` |
| `A-n64-k9.vrp` | `1d690e428ea2de12f5996cf1e84aaa0508ec9977dfdb3d0c106e9006e9cc5124` |
| `A-n64-k9.vrp.dzn` | `b096dc119c52244ab5e5ace4c82f3e84a574aeffd37be43b52513aec9137946f` |
| `A-n64-k9.sol` | `28f689c79aaa0b9aed18b4b63aa9ed41cc6aa62fa23e58dcbed9d02b54e27759` |

MIPLIB describes this instance as an indicator-MPS compilation of a MiniZinc
Challenge CVRP benchmark made with CPLEX 12.7.1. The byte-level and
coefficient-level audits in `../analysis/` establish the precise local
crosswalk; the source names alone are not treated as a proof of equivalence.
