#!/usr/bin/env python3
"""Run the repository's generic CVRPLIB/MiniZinc source-equivalence audit."""

from pathlib import Path
import runpy

runpy.run_path(
    str(
        Path(__file__).resolve().parents[2]
        / "cvrpb-n45k5vrpi"
        / "experiments"
        / "audit_source_equivalence.py"
    ),
    run_name="__main__",
)
