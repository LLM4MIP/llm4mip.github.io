#!/usr/bin/env python3
"""Build a small exact dual certificate for the >=K-route degree relaxation."""

from __future__ import annotations

import argparse
import hashlib
import json
from fractions import Fraction
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB

from gurobi_customer_edge_cutoff import parse_dzn


def q(value: float, denominator: int) -> Fraction:
    return Fraction(str(value)).limit_denominator(denominator)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dzn", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("--minimum-routes", type=int, default=17)
    parser.add_argument("--dual-denominator", type=int, default=2)
    args = parser.parse_args()

    n, capacity, demands, distance = parse_dzn(args.dzn)
    customers = range(1, n + 1)
    edges = [(i, j) for i in customers for j in range(i + 1, n + 1)]
    savings = {
        (i, j): distance[0][i] + distance[0][j] - distance[i][j]
        for i, j in edges
    }
    model = gp.Model("customer-edge-degree-relaxation")
    model.Params.OutputFlag = 0
    model.Params.Method = 1
    x = {edge: model.addVar(lb=0, ub=1, vtype=GRB.CONTINUOUS) for edge in edges}
    degree = {
        i: model.addConstr(gp.quicksum(x[e] for e in edges if i in e) <= 2)
        for i in customers
    }
    cardinality = model.addConstr(
        gp.quicksum(x.values()) <= n - args.minimum_routes
    )
    model.setObjective(gp.quicksum(savings[e] * x[e] for e in edges), GRB.MAXIMIZE)
    model.optimize()
    if model.Status != GRB.OPTIMAL:
        raise RuntimeError(f"LP status {model.Status}")

    y = {i: q(degree[i].Pi, args.dual_denominator) for i in customers}
    z = q(cardinality.Pi, args.dual_denominator)
    if any(value < 0 for value in y.values()) or z < 0:
        raise RuntimeError("unexpected negative dual multiplier")
    upper = {
        edge: max(Fraction(0), Fraction(savings[edge]) - y[edge[0]] - y[edge[1]] - z)
        for edge in edges
    }
    dual_savings_bound = (
        2 * sum(y.values(), Fraction(0))
        + (n - args.minimum_routes) * z
        + sum(upper.values(), Fraction(0))
    )
    base = 2 * sum(distance[0][i] for i in customers)
    route_cost_lower_bound = Fraction(base) - dual_savings_bound
    certificate = {
        "schema": "cvrp-customer-edge-degree-lp-dual-v1",
        "dzn_sha256": hashlib.sha256(args.dzn.read_bytes()).hexdigest(),
        "customers": n,
        "capacity": capacity,
        "total_demand": sum(demands),
        "minimum_routes": args.minimum_routes,
        "maximum_customer_edges": n - args.minimum_routes,
        "objective_star_constant": base,
        "dual_customer_degree_multipliers": {str(i): str(y[i]) for i in customers},
        "dual_cardinality_multiplier": str(z),
        "derived_positive_upper_bound_multipliers": sum(value > 0 for value in upper.values()),
        "dual_savings_upper_bound": str(dual_savings_bound),
        "route_cost_lower_bound": str(route_cost_lower_bound),
        "gurobi_lp_objective": model.ObjVal,
        "gurobi_version": list(gp.gurobi.version()),
        "dual_denominator_limit": args.dual_denominator,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(certificate, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(certificate, sort_keys=True))


if __name__ == "__main__":
    main()
