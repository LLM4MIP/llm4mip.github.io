#!/usr/bin/env python3
"""Replay the degree-relaxation dual using only exact standard-library arithmetic."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
from fractions import Fraction
from pathlib import Path


def parse_dzn(path: Path) -> tuple[int, int, list[int], list[list[int]]]:
    text = path.read_text(encoding="utf-8")
    n = int(re.search(r"\bN\s*=\s*(\d+)\s*;", text).group(1))
    capacity = int(re.search(r"\bCapacity\s*=\s*(\d+)\s*;", text).group(1))
    demands = [0] + [
        int(v) for v in re.findall(r"-?\d+", re.search(r"Demand\s*=\s*\[(.*?)\]\s*;", text, re.S).group(1))
    ]
    matrix_text = re.search(r"Distance\s*=\s*\[\|(.*?)\|\]\s*;", text, re.S).group(1)
    distance = [
        [int(v) for v in re.findall(r"-?\d+", row)]
        for row in matrix_text.split("|")
        if re.findall(r"-?\d+", row)
    ]
    if len(demands) != n + 1 or len(distance) != n + 1 or any(len(row) != n + 1 for row in distance):
        raise ValueError("unexpected DZN dimensions")
    return n, capacity, demands, distance


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dzn", type=Path)
    parser.add_argument("certificate", type=Path)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    cert = json.loads(args.certificate.read_text(encoding="utf-8"))
    n, capacity, demands, distance = parse_dzn(args.dzn)
    if hashlib.sha256(args.dzn.read_bytes()).hexdigest() != cert["dzn_sha256"]:
        raise ValueError("DZN hash mismatch")
    if n != cert["customers"] or capacity != cert["capacity"] or sum(demands) != cert["total_demand"]:
        raise ValueError("instance metadata mismatch")

    y = {int(i): Fraction(value) for i, value in cert["dual_customer_degree_multipliers"].items()}
    z = Fraction(cert["dual_cardinality_multiplier"])
    if set(y) != set(range(1, n + 1)) or min(y.values()) < 0 or z < 0:
        raise ValueError("dual sign/domain check failed")
    upper_sum = Fraction(0)
    positive_upper = 0
    minimum_slack = None
    for i in range(1, n + 1):
        for j in range(i + 1, n + 1):
            saving = Fraction(distance[0][i] + distance[0][j] - distance[i][j])
            upper = max(Fraction(0), saving - y[i] - y[j] - z)
            slack = y[i] + y[j] + z + upper - saving
            if slack < 0:
                raise ValueError("dual inequality violated")
            minimum_slack = slack if minimum_slack is None else min(minimum_slack, slack)
            upper_sum += upper
            positive_upper += upper > 0
    maximum_edges = n - cert["minimum_routes"]
    dual_savings = 2 * sum(y.values(), Fraction(0)) + maximum_edges * z + upper_sum
    base = 2 * sum(distance[0][i] for i in range(1, n + 1))
    route_lb = Fraction(base) - dual_savings
    expected_min_routes = math.ceil(sum(demands) / capacity)
    report = {
        "checker": "Python standard library Fraction; no optimization library",
        "dzn_sha256": cert["dzn_sha256"],
        "customers": n,
        "demand_minimum_routes": expected_min_routes,
        "minimum_routes_certified": cert["minimum_routes"],
        "dual_variables_nonnegative": True,
        "dual_inequalities_checked": n * (n - 1) // 2,
        "minimum_dual_slack": str(minimum_slack),
        "positive_derived_upper_multipliers": positive_upper,
        "dual_savings_upper_bound": str(dual_savings),
        "route_cost_lower_bound": str(route_lb),
        "matches_certificate": (
            str(dual_savings) == cert["dual_savings_upper_bound"]
            and str(route_lb) == cert["route_cost_lower_bound"]
        ),
        "excludes_objective_at_most_1400": route_lb > 1400,
    }
    if not report["matches_certificate"] or not report["excludes_objective_at_most_1400"]:
        raise ValueError("certificate conclusion failed")
    output = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(output, encoding="utf-8")
    print(output, end="")


if __name__ == "__main__":
    main()
