#!/usr/bin/env bash
# Run fixed 10--14 route single-commodity-flow cutoff cases in parallel on altman.
set -euo pipefail

root="${1:-/home/huangyicheng/AI4MIP_cvrpa_20260908}"
seconds="${2:-1200}"
threads="${3:-8}"
python_bin="${PYTHON_BIN:-python3}"
run_root="$root/route-count-copt-partition"

export PYTHONPATH="/home/huangyicheng/copt80/lib/python/310"
export LD_LIBRARY_PATH="/home/huangyicheng/copt80/lib:/home/huangyicheng/copt80/lib/python/deps"
mkdir -p "$run_root"
: > "$run_root/pids.tsv"
pids=()
for route_count in $(seq 10 14); do
  out="$run_root/k${route_count}"
  mkdir -p "$out"
  "$python_bin" "$root/copt_standard_cvrp.py" \
    "$root/A-n64-k9.vrp.dzn" "$root/A-n64-k9.sol" "$out" \
    --seconds "$seconds" --threads "$threads" --focus bound \
    --minimum-routes "$route_count" --maximum-routes "$route_count" \
    --maximum-objective 1400 > "$out/stdout.log" 2>&1 &
  pid=$!
  pids+=("$pid")
  printf '%s\t%s\n' "$route_count" "$pid" >> "$run_root/pids.tsv"
done

status=0
for pid in "${pids[@]}"; do
  if ! wait "$pid"; then
    status=1
  fi
done
date --iso-8601=seconds > "$run_root/completed-at.txt"
exit "$status"
