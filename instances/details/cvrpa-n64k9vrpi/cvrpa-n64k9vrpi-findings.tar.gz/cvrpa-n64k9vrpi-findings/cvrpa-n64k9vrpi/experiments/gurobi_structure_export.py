#!/usr/bin/env python3
"""Read an indicator MPS with Gurobi and export a compact structural audit.

The script deliberately never calls ``optimize``.  It also avoids SciPy so the
audit can run with only the official ``gurobipy`` wheel.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import re
import sys
from collections import Counter
from pathlib import Path

import gurobipy as gp


def stable_number(value: float) -> str:
    return format(float(value), ".17g")


def counter_json(counter: Counter, limit: int | None = None) -> list[list[object]]:
    items = sorted(counter.items(), key=lambda item: (-item[1], str(item[0])))
    if limit is not None:
        items = items[:limit]
    return [[str(key), int(count)] for key, count in items]


def name_shape(name: str) -> str:
    return re.sub(r"\d+", "#", name)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1 << 20):
            digest.update(chunk)
    return digest.hexdigest()


def linear_terms(expr: gp.LinExpr) -> list[tuple[str, str, str]]:
    return [
        (
            expr.getVar(index).VarName,
            expr.getVar(index).VType,
            stable_number(expr.getCoeff(index)),
        )
        for index in range(expr.size())
    ]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    mps = args.mps.resolve()
    print(f"reading={mps}", flush=True)
    model = gp.read(str(mps))
    model.update()
    print(
        f"read_complete vars={model.NumVars} linear_rows={model.NumConstrs} "
        f"genconstrs={model.NumGenConstrs} nz={model.NumNZs}",
        flush=True,
    )

    variables = model.getVars()
    constraints = model.getConstrs()
    general_constraints = model.getGenConstrs()

    variable_types = Counter(variable.VType for variable in variables)
    lower_bounds = Counter(stable_number(variable.LB) for variable in variables)
    upper_bounds = Counter(stable_number(variable.UB) for variable in variables)
    objective_coefficients = Counter(stable_number(variable.Obj) for variable in variables)
    variable_name_shapes = Counter(name_shape(variable.VarName) for variable in variables)
    column_degrees = Counter()

    row_senses = Counter()
    row_rhs = Counter()
    row_degrees = Counter()
    row_coefficients = Counter()
    row_name_shapes = Counter()
    row_samples = []
    for row_index, constraint in enumerate(constraints):
        expr = model.getRow(constraint)
        terms = linear_terms(expr)
        row_senses[constraint.Sense] += 1
        row_rhs[stable_number(constraint.RHS)] += 1
        row_degrees[len(terms)] += 1
        row_coefficients.update(coefficient for _, _, coefficient in terms)
        row_name_shapes[name_shape(constraint.ConstrName)] += 1
        for variable_name, _, _ in terms:
            column_degrees[variable_name] += 1
        if row_index < 40:
            row_samples.append(
                {
                    "index": row_index,
                    "name": constraint.ConstrName,
                    "sense": constraint.Sense,
                    "rhs": stable_number(constraint.RHS),
                    "term_count": len(terms),
                    "terms": [[name, coefficient] for name, _, coefficient in terms[:30]],
                }
            )

    general_types = Counter()
    indicator_binvar_types = Counter()
    indicator_binvals = Counter()
    indicator_senses = Counter()
    indicator_rhs = Counter()
    indicator_degrees = Counter()
    indicator_coefficients = Counter()
    indicator_name_shapes = Counter()
    indicator_algebraic_signatures = Counter()
    indicator_samples = []
    other_general_samples = []
    for general_constraint in general_constraints:
        general_type = int(general_constraint.GenConstrType)
        general_types[general_type] += 1
        if general_type == int(gp.GRB.GENCONSTR_INDICATOR):
            binvar, binval, expr, sense, rhs = model.getGenConstrIndicator(general_constraint)
            terms = linear_terms(expr)
            indicator_binvar_types[binvar.VType] += 1
            indicator_binvals[int(binval)] += 1
            indicator_senses[sense] += 1
            indicator_rhs[stable_number(rhs)] += 1
            indicator_degrees[len(terms)] += 1
            indicator_coefficients.update(coefficient for _, _, coefficient in terms)
            indicator_name_shapes[name_shape(general_constraint.GenConstrName)] += 1
            signature = (
                int(binval),
                sense,
                stable_number(rhs),
                tuple(coefficient for _, _, coefficient in terms),
                tuple(vtype for _, vtype, _ in terms),
            )
            indicator_algebraic_signatures[repr(signature)] += 1
            if len(indicator_samples) < 40:
                indicator_samples.append(
                    {
                        "name": general_constraint.GenConstrName,
                        "binvar": binvar.VarName,
                        "binval": int(binval),
                        "sense": sense,
                        "rhs": stable_number(rhs),
                        "term_count": len(terms),
                        "terms": [[name, coefficient] for name, _, coefficient in terms[:30]],
                    }
                )
        elif len(other_general_samples) < 20:
            other_general_samples.append(
                {"name": general_constraint.GenConstrName, "type": general_type}
            )

    report = {
        "provenance": {
            "script": Path(__file__).name,
            "read_only_no_optimize": True,
            "mps_path": str(mps),
            "mps_sha256_compressed": sha256_file(mps),
            "python": sys.version,
            "platform": platform.platform(),
            "gurobi_version": list(gp.gurobi.version()),
        },
        "model": {
            "name": model.ModelName,
            "sense": "min" if model.ModelSense == gp.GRB.MINIMIZE else "max",
            "objective_constant": stable_number(model.ObjCon),
            "variables": model.NumVars,
            "linear_constraints": model.NumConstrs,
            "general_constraints": model.NumGenConstrs,
            "linear_nonzeros": model.NumNZs,
            "sos": model.NumSOS,
            "quadratic_constraints": model.NumQConstrs,
            "quadratic_objective_nonzeros": model.NumQNZs,
        },
        "variables": {
            "types": counter_json(variable_types),
            "lower_bounds": counter_json(lower_bounds, 40),
            "upper_bounds": counter_json(upper_bounds, 40),
            "objective_coefficients": counter_json(objective_coefficients, 60),
            "objective_nonzero_count": sum(variable.Obj != 0 for variable in variables),
            "name_shapes": counter_json(variable_name_shapes, 40),
            "linear_degree_histogram": counter_json(Counter(column_degrees.values()), 80),
            "linear_isolated_count": sum(variable.VarName not in column_degrees for variable in variables),
            "first": [
                {
                    "index": index,
                    "name": variable.VarName,
                    "type": variable.VType,
                    "lb": stable_number(variable.LB),
                    "ub": stable_number(variable.UB),
                    "obj": stable_number(variable.Obj),
                    "linear_degree": int(column_degrees.get(variable.VarName, 0)),
                }
                for index, variable in list(enumerate(variables))[:40]
            ],
        },
        "linear_matrix": {
            "senses": counter_json(row_senses),
            "rhs": counter_json(row_rhs, 60),
            "coefficient_histogram": counter_json(row_coefficients, 120),
            "row_degree_histogram": counter_json(row_degrees, 120),
            "row_name_shapes": counter_json(row_name_shapes, 40),
            "first_rows": row_samples,
        },
        "general_constraints": {
            "types": counter_json(general_types),
            "indicator_binvar_types": counter_json(indicator_binvar_types),
            "indicator_binvals": counter_json(indicator_binvals),
            "indicator_senses": counter_json(indicator_senses),
            "indicator_rhs": counter_json(indicator_rhs, 60),
            "indicator_degrees": counter_json(indicator_degrees, 120),
            "indicator_coefficients": counter_json(indicator_coefficients, 120),
            "indicator_name_shapes": counter_json(indicator_name_shapes, 40),
            "indicator_algebraic_signature_counts": counter_json(
                indicator_algebraic_signatures, 120
            ),
            "indicator_samples": indicator_samples,
            "other_samples": other_general_samples,
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"wrote={args.output} bytes={args.output.stat().st_size}", flush=True)


if __name__ == "__main__":
    main()
