#!/usr/bin/env python3
"""Exact-integer CP-SAT cutoff model for a fixed-route-count symmetric CVRP."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

from ortools.sat.python import cp_model


def parse_dzn(path: Path) -> tuple[int, int, list[int], list[list[int]]]:
    text = path.read_text(encoding="utf-8")
    n = int(re.search(r"\bN\s*=\s*(\d+)\s*;", text).group(1))
    capacity = int(re.search(r"\bCapacity\s*=\s*(\d+)\s*;", text).group(1))
    demand = [0] + [
        int(v) for v in re.findall(r"-?\d+", re.search(r"Demand\s*=\s*\[(.*?)\]\s*;", text, re.S).group(1))
    ]
    matrix_text = re.search(r"Distance\s*=\s*\[\|(.*?)\|\]\s*;", text, re.S).group(1)
    distance = [
        [int(v) for v in re.findall(r"-?\d+", row)]
        for row in matrix_text.split("|")
        if re.findall(r"-?\d+", row)
    ]
    if len(demand) != n + 1 or len(distance) != n + 1 or any(len(row) != n + 1 for row in distance):
        raise ValueError("unexpected DZN dimensions")
    if any(distance[i][j] != distance[j][i] for i in range(n + 1) for j in range(n + 1)):
        raise ValueError("non-symmetric distance matrix")
    return n, capacity, demand, distance


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dzn", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("--routes", type=int, required=True)
    parser.add_argument("--maximum-objective", type=int, required=True)
    parser.add_argument("--seconds", type=float, default=1200)
    parser.add_argument("--workers", type=int, default=32)
    parser.add_argument("--forbid-mergeable-route-pairs", action="store_true")
    parser.add_argument(
        "--routes-constraint",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="add CP-SAT's native multiple-circuit constraint as redundant propagation",
    )
    parser.add_argument("--fix-depot-degree", action="append", default=[], metavar="CUSTOMER=VALUE")
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    n, capacity, demand, distance = parse_dzn(args.dzn)
    minimum_depot_triangle_slack = min(
        distance[0][i] + distance[0][j] - distance[i][j]
        for i in range(1, n + 1)
        for j in range(i + 1, n + 1)
    )
    if args.forbid_mergeable_route_pairs and minimum_depot_triangle_slack < 0:
        raise ValueError("nonmerge strengthening fails a required depot-triangle inequality")
    nodes = range(n + 1)
    customers = range(1, n + 1)
    arcs = [(i, j) for i in nodes for j in nodes if i != j]
    model = cp_model.CpModel()
    x = {(i, j): model.new_bool_var(f"x_{i}_{j}") for i, j in arcs}
    load = {
        i: model.new_int_var(demand[i], capacity, f"load_{i}")
        for i in customers
    }
    end_load = {
        i: model.new_int_var(0, capacity, f"end_load_{i}")
        for i in customers
    }
    if args.routes_constraint:
        model.add_multiple_circuit([(i, j, x[i, j]) for i, j in arcs])

    for customer in customers:
        model.add_exactly_one(x[i, customer] for i in nodes if i != customer)
        model.add_exactly_one(x[customer, j] for j in nodes if j != customer)
        model.add(load[customer] == demand[customer]).only_enforce_if(x[0, customer])
        model.add(end_load[customer] == load[customer]).only_enforce_if(x[customer, 0])
        model.add(end_load[customer] == 0).only_enforce_if(x[customer, 0].Not())
    for i in customers:
        for j in customers:
            if i != j:
                model.add(load[j] == load[i] + demand[j]).only_enforce_if(x[i, j])

    model.add(sum(x[0, j] for j in customers) == args.routes)
    model.add(sum(x[i, 0] for i in customers) == args.routes)
    model.add(sum(end_load.values()) == sum(demand))
    objective = sum(distance[i][j] * x[i, j] for i, j in arcs)
    model.add(objective <= args.maximum_objective)

    if args.forbid_mergeable_route_pairs:
        for i in customers:
            for j in range(i + 1, n + 1):
                model.add(
                    end_load[i] + end_load[j]
                    >= (capacity + 1) * (x[i, 0] + x[j, 0] - 1)
                )

    fixed_degrees = []
    for specification in args.fix_depot_degree:
        customer_text, value_text = specification.split("=", 1)
        customer, value = int(customer_text), int(value_text)
        if customer not in customers or value not in (0, 1, 2):
            raise ValueError(f"invalid depot degree {specification!r}")
        fixed_degrees.append({"customer": customer, "value": value})
        if value == 1:
            model.add(x[0, customer] + x[customer, 0] == 1)
        else:
            model.add(x[0, customer] + x[customer, 0] == value)

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = args.seconds
    solver.parameters.num_search_workers = args.workers
    solver.parameters.log_search_progress = True
    solver.parameters.random_seed = 20260908
    solver.parameters.symmetry_level = 3
    solver.parameters.linearization_level = 2
    log_path = args.out / "cpsat-cvrp-cutoff.log"
    with log_path.open("w", encoding="utf-8") as log:
        solver.log_callback = lambda message: log.write(message)
        status = solver.solve(model)

    status_name = solver.status_name(status)
    result = {
        "schema": "cpsat-fixed-route-cvrp-cutoff-v1",
        "status": int(status),
        "status_name": status_name,
        "ortools_version": __import__("ortools").__version__,
        "customers": n,
        "capacity": capacity,
        "total_demand": sum(demand),
        "routes": args.routes,
        "maximum_objective": args.maximum_objective,
        "forbid_mergeable_route_pairs": args.forbid_mergeable_route_pairs,
        "minimum_customer_pair_depot_triangle_slack": minimum_depot_triangle_slack,
        "native_routes_constraint": args.routes_constraint,
        "manual_depot_degree_branches": fixed_degrees,
        "binary_arc_variables": len(arcs),
        "integer_load_variables": 2 * n,
        "wall_time": solver.wall_time,
        "branches": solver.num_branches,
        "conflicts": solver.num_conflicts,
        "dzn_sha256": hashlib.sha256(args.dzn.read_bytes()).hexdigest(),
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "response_stats": solver.response_stats(),
    }
    if status in (cp_model.FEASIBLE, cp_model.OPTIMAL):
        selected = [(i, j) for i, j in arcs if solver.value(x[i, j])]
        result["objective"] = sum(distance[i][j] for i, j in selected)
        result["selected_arcs"] = selected
    if status == cp_model.INFEASIBLE:
        result["proof_statement"] = (
            f"No represented {args.routes}-route CVRP solution has objective "
            f"at most {args.maximum_objective}."
        )
    (args.out / "cpsat-cvrp-cutoff-summary.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
