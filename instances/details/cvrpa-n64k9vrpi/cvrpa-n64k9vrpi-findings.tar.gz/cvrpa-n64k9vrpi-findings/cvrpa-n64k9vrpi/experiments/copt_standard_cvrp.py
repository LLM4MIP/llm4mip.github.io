#!/usr/bin/env python3
"""Solve or cutoff-test the semantic free-fleet CVRP with COPT.

The directed single-commodity load-flow formulation is independent of the
large MiniZinc compilation.  It enforces capacity and removes customer-only
subtours without callbacks.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import re
from pathlib import Path

import coptpy as cp
from coptpy import COPT


def parse_dzn(path: Path) -> tuple[int, int, list[int], list[list[int]]]:
    text = path.read_text(encoding="utf-8")
    n = int(re.search(r"\bN\s*=\s*(\d+)\s*;", text).group(1))
    capacity = int(re.search(r"\bCapacity\s*=\s*(\d+)\s*;", text).group(1))
    demand_text = re.search(r"Demand\s*=\s*\[(.*?)\]\s*;", text, re.S).group(1)
    demand = [0] + [int(value) for value in re.findall(r"-?\d+", demand_text)]
    distance_text = re.search(r"Distance\s*=\s*\[\|(.*?)\|\]\s*;", text, re.S).group(1)
    distance = []
    for raw_row in distance_text.split("|"):
        row = [int(value) for value in re.findall(r"-?\d+", raw_row)]
        if row:
            distance.append(row)
    if (
        len(demand) != n + 1
        or len(distance) != n + 1
        or any(len(row) != n + 1 for row in distance)
    ):
        raise ValueError("unexpected instance dimensions")
    return n, capacity, demand, distance


def parse_routes(path: Path) -> tuple[list[list[int]], int | None]:
    routes = []
    stated_cost = None
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.startswith("Route #"):
            routes.append([int(value) for value in line.split(":", 1)[1].split()])
        elif line.startswith("Cost "):
            stated_cost = int(line.split()[1])
    return routes, stated_cost


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dzn", type=Path)
    parser.add_argument("routes", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("--seconds", type=float, default=3600)
    parser.add_argument("--threads", type=int, default=32)
    parser.add_argument("--minimum-routes", type=int)
    parser.add_argument("--maximum-routes", type=int)
    parser.add_argument("--maximum-objective", type=int)
    parser.add_argument("--focus", choices=("balanced", "feasibility", "bound"), default="balanced")
    parser.add_argument("--root-cut-level", type=int)
    parser.add_argument("--tree-cut-level", type=int)
    parser.add_argument("--strong-branching", type=int)
    parser.add_argument("--root-cut-rounds", type=int)
    parser.add_argument("--node-cut-rounds", type=int)
    parser.add_argument("--depot-degree-customer", type=int)
    parser.add_argument("--depot-degree-value", type=int, choices=(0, 1, 2))
    parser.add_argument(
        "--fix-depot-degree",
        action="append",
        default=[],
        metavar="CUSTOMER=VALUE",
        help="repeatable manual branch; VALUE is 0, 1, or 2",
    )
    parser.add_argument(
        "--forbid-mergeable-route-pairs",
        action="store_true",
        help=(
            "require every pair of nonempty route loads to exceed capacity; "
            "valid only after all one-fewer-route improving solutions have been excluded"
        ),
    )
    parser.add_argument(
        "--small-rcc-size",
        type=int,
        default=0,
        help="pre-add every rounded-capacity cut for customer subsets up to this size",
    )
    parser.add_argument(
        "--forbid-singleton-customer",
        action="append",
        default=[],
        type=int,
        help="repeatable proven branch exclusion: customer may not form a one-customer route",
    )
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    n, capacity, demand, distance = parse_dzn(args.dzn)
    distance_is_symmetric = all(
        distance[i][j] == distance[j][i]
        for i in range(n + 1)
        for j in range(n + 1)
    )
    minimum_depot_triangle_slack = min(
        distance[0][i] + distance[0][j] - distance[i][j]
        for i in range(1, n + 1)
        for j in range(i + 1, n + 1)
    )
    if args.forbid_mergeable_route_pairs and (
        not distance_is_symmetric or minimum_depot_triangle_slack < 0
    ):
        raise ValueError(
            "nonmerge strengthening requires symmetry and every customer-pair "
            "depot-triangle inequality"
        )
    routes, stated_cost = parse_routes(args.routes)
    nodes = range(n + 1)
    customers = range(1, n + 1)
    arcs = [(tail, head) for tail in nodes for head in nodes if tail != head]

    model = cp.Envr().createModel(f"CVRP-{n}-free-fleet-flow")
    model.setParam(COPT.Param.Logging, 1)
    model.setLogFile(str(args.out / "copt-standard-cvrp.log"))
    model.setParam(COPT.Param.Threads, args.threads)
    model.setParam(COPT.Param.TimeLimit, args.seconds)
    model.setParam(COPT.Param.RelGap, 0.0)
    try:
        model.setParam(COPT.Param.GPUMode, 0)
    except Exception:
        pass
    if args.focus == "feasibility":
        try:
            model.setParam(COPT.Param.HeurLevel, 3)
        except Exception:
            pass
    elif args.focus == "bound":
        try:
            model.setParam(COPT.Param.HeurLevel, 0)
        except Exception:
            pass
    for value, parameter in (
        (args.root_cut_level, COPT.Param.RootCutLevel),
        (args.tree_cut_level, COPT.Param.TreeCutLevel),
        (args.strong_branching, COPT.Param.StrongBranching),
        (args.root_cut_rounds, COPT.Param.RootCutRounds),
        (args.node_cut_rounds, COPT.Param.NodeCutRounds),
    ):
        if value is not None:
            model.setParam(parameter, value)

    x = {
        arc: model.addVar(lb=0, ub=1, vtype=COPT.BINARY, name=f"x_{arc[0]}_{arc[1]}")
        for arc in arcs
    }
    flow = {
        arc: model.addVar(lb=0, ub=capacity, vtype=COPT.CONTINUOUS, name=f"f_{arc[0]}_{arc[1]}")
        for arc in arcs
    }
    for customer in customers:
        model.addConstr(
            cp.quicksum(x[tail, customer] for tail in nodes if tail != customer) == 1,
            name=f"in_{customer}",
        )
        model.addConstr(
            cp.quicksum(x[customer, head] for head in nodes if head != customer) == 1,
            name=f"out_{customer}",
        )
        model.addConstr(
            cp.quicksum(flow[tail, customer] for tail in nodes if tail != customer)
            - cp.quicksum(flow[customer, head] for head in nodes if head != customer)
            == demand[customer],
            name=f"flow_balance_{customer}",
        )
    for tail, head in arcs:
        model.addConstr(
            flow[tail, head]
            <= (capacity if tail == 0 else capacity - demand[tail]) * x[tail, head],
            name=f"flow_ub_{tail}_{head}",
        )
        if head == 0:
            model.addConstr(flow[tail, head] == 0, name=f"return_empty_{tail}")
        else:
            model.addConstr(
                flow[tail, head] >= demand[head] * x[tail, head],
                name=f"flow_lb_{tail}_{head}",
            )
    model.addConstr(
        cp.quicksum(flow[0, customer] for customer in customers) == sum(demand),
        name="redundant_total_depot_load",
    )

    small_rcc_counts = {}
    if args.small_rcc_size:
        if args.small_rcc_size < 2 or args.small_rcc_size > 5:
            raise ValueError("small-rcc-size must be 0 or between 2 and 5")
        for subset_size in range(2, args.small_rcc_size + 1):
            added = 0
            for subset in itertools.combinations(customers, subset_size):
                required_routes = math.ceil(sum(demand[i] for i in subset) / capacity)
                if required_routes <= 1:
                    continue
                model.addConstr(
                    cp.quicksum(x[i, j] for i in subset for j in subset if i != j)
                    <= subset_size - required_routes,
                    name="small_rcc_" + "_".join(map(str, subset)),
                )
                added += 1
            small_rcc_counts[str(subset_size)] = added

    demand_min_routes = math.ceil(sum(demand) / capacity)
    minimum_routes = args.minimum_routes or demand_min_routes
    if minimum_routes < demand_min_routes:
        raise ValueError("minimum route count weakens the demand lower bound")
    maximum_routes = args.maximum_routes or n
    if maximum_routes < minimum_routes or maximum_routes > n:
        raise ValueError("invalid route-count interval")
    route_count_expr = cp.quicksum(x[0, customer] for customer in customers)
    model.addConstr(route_count_expr >= minimum_routes, name="minimum_route_count")
    if maximum_routes < n:
        model.addConstr(route_count_expr <= maximum_routes, name="maximum_route_count")
    if (args.depot_degree_customer is None) != (args.depot_degree_value is None):
        raise ValueError("depot-degree customer and value must be supplied together")
    if args.depot_degree_customer is not None:
        customer = args.depot_degree_customer
        if customer < 1 or customer > n:
            raise ValueError("depot-degree customer outside 1..N")
        if args.depot_degree_value == 1:
            model.addConstr(
                x[0, customer] + x[customer, 0] == 1,
                name="fixed_undirected_depot_degree",
            )
        else:
            model.addConstr(
                x[0, customer] + x[customer, 0] == args.depot_degree_value,
                name="fixed_undirected_depot_degree",
            )
    parsed_extra_depot_degrees = []
    for specification in args.fix_depot_degree:
        try:
            customer_text, value_text = specification.split("=", 1)
            customer, value = int(customer_text), int(value_text)
        except Exception as error:
            raise ValueError(f"invalid depot-degree specification {specification!r}") from error
        if customer < 1 or customer > n or value not in (0, 1, 2):
            raise ValueError(f"invalid depot-degree specification {specification!r}")
        parsed_extra_depot_degrees.append({"customer": customer, "value": value})
        if value == 1:
            model.addConstr(
                x[0, customer] + x[customer, 0] == 1,
                name=f"fixed_undirected_depot_degree_{customer}",
            )
        else:
            model.addConstr(
                x[0, customer] + x[customer, 0] == value,
                name=f"fixed_undirected_depot_degree_{customer}",
            )
    if args.forbid_mergeable_route_pairs:
        implied_minimum_route_load = math.ceil(
            ((minimum_routes - 1) * (capacity + 1) - sum(demand))
            / (minimum_routes - 2)
        )
        for customer in customers:
            model.addConstr(
                flow[0, customer] >= implied_minimum_route_load * x[0, customer],
                name=f"implied_nonmergeable_minimum_load_{customer}",
            )
        for first in customers:
            for second in range(first + 1, n + 1):
                model.addConstr(
                    flow[0, first] + flow[0, second]
                    >= (capacity + 1) * (x[0, first] + x[0, second] - 1),
                    name=f"nonmergeable_route_loads_{first}_{second}",
                )
    for customer in args.forbid_singleton_customer:
        if customer < 1 or customer > n:
            raise ValueError("forbid-singleton customer outside 1..N")
        model.addConstr(
            x[0, customer] + x[customer, 0] <= 1,
            name=f"excluded_singleton_route_{customer}",
        )
    objective_expr = cp.quicksum(distance[tail][head] * x[tail, head] for tail, head in arcs)
    if args.maximum_objective is not None:
        model.addConstr(objective_expr <= args.maximum_objective, name="objective_ceiling")
    model.setObjective(objective_expr, COPT.MINIMIZE)

    if (
        minimum_routes <= len(routes) <= maximum_routes
        and (args.maximum_objective is None or stated_cost is None or stated_cost <= args.maximum_objective)
    ):
        x_start = {arc: 0.0 for arc in arcs}
        flow_start = {arc: 0.0 for arc in arcs}
        for route in routes:
            remaining = sum(demand[customer] for customer in route)
            previous = 0
            for customer in route:
                x_start[previous, customer] = 1.0
                flow_start[previous, customer] = float(remaining)
                remaining -= demand[customer]
                previous = customer
            x_start[previous, 0] = 1.0
        start_vars = [x[arc] for arc in arcs] + [flow[arc] for arc in arcs]
        start_values = [x_start[arc] for arc in arcs] + [flow_start[arc] for arc in arcs]
        model.setMipStart(start_vars, start_values)
        model.loadMipStart()

    model.solve()
    result = {
        "provenance": {
            "copt_version": [COPT.VERSION_MAJOR, COPT.VERSION_MINOR, COPT.VERSION_TECHNICAL],
            "dzn_sha256": hashlib.sha256(args.dzn.read_bytes()).hexdigest(),
            "routes_sha256": hashlib.sha256(args.routes.read_bytes()).hexdigest(),
            "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "cpu_only_gpu_mode": 0,
        },
        "status": int(model.status),
        "has_mip_solution": int(model.hasmipsol),
        "customers": n,
        "variables": 2 * len(arcs),
        "binary_arc_variables": len(arcs),
        "continuous_flow_variables": len(arcs),
        "route_count_fixed": minimum_routes == maximum_routes,
        "minimum_routes_by_total_demand": demand_min_routes,
        "minimum_routes_enforced": minimum_routes,
        "maximum_routes_enforced": maximum_routes,
        "maximum_objective_enforced": args.maximum_objective,
        "total_demand": sum(demand),
        "capacity": capacity,
        "focus": args.focus,
        "cut_and_branch_parameters": {
            "root_cut_level": args.root_cut_level,
            "tree_cut_level": args.tree_cut_level,
            "strong_branching": args.strong_branching,
            "root_cut_rounds": args.root_cut_rounds,
            "node_cut_rounds": args.node_cut_rounds,
        },
        "manual_depot_degree_branch": {
            "customer": args.depot_degree_customer,
            "value": args.depot_degree_value,
            "degree_one_is_undirected": args.depot_degree_value == 1,
        },
        "extra_manual_depot_degree_branches": parsed_extra_depot_degrees,
        "forbid_mergeable_route_pairs": args.forbid_mergeable_route_pairs,
        "distance_is_symmetric": distance_is_symmetric,
        "minimum_customer_pair_depot_triangle_slack": minimum_depot_triangle_slack,
        "small_rounded_capacity_cut_counts": small_rcc_counts,
        "forbidden_singleton_customers": sorted(set(args.forbid_singleton_customer)),
        "mergeability_prerequisite": (
            f"all improving solutions with {minimum_routes - 1} routes excluded"
            if args.forbid_mergeable_route_pairs
            else None
        ),
        "implied_minimum_route_load": (
            implied_minimum_route_load if args.forbid_mergeable_route_pairs else None
        ),
    }
    for key, attribute in (
        ("objective", "objval"),
        ("best_bound", "bestbnd"),
        ("gap", "mipgap"),
        ("node_count", "nodecnt"),
        ("runtime", "solvingtime"),
    ):
        try:
            result[key] = float(getattr(model, attribute))
        except Exception:
            pass
    if model.hasmipsol:
        model.writeSol(str(args.out / "standard-cvrp-flow.sol"))
    (args.out / "copt-standard-cvrp-summary.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print("RESULT_JSON=" + json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
