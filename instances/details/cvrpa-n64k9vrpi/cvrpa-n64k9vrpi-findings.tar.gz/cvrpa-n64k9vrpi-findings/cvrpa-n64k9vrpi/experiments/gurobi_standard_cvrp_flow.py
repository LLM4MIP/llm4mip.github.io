#!/usr/bin/env python3
"""Route-count cutoff test using a directed single-commodity-flow CVRP model."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import time
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def parse_dzn(path: Path) -> tuple[int, int, list[int], list[list[int]]]:
    text = path.read_text(encoding="utf-8")
    n = int(re.search(r"\bN\s*=\s*(\d+)\s*;", text).group(1))
    capacity = int(re.search(r"\bCapacity\s*=\s*(\d+)\s*;", text).group(1))
    demand_text = re.search(r"Demand\s*=\s*\[(.*?)\]\s*;", text, re.S).group(1)
    demand = [0] + [int(value) for value in re.findall(r"-?\d+", demand_text)]
    matrix_text = re.search(r"Distance\s*=\s*\[\|(.*?)\|\]\s*;", text, re.S).group(1)
    distance = []
    for raw_row in matrix_text.split("|"):
        row = [int(value) for value in re.findall(r"-?\d+", raw_row)]
        if row:
            distance.append(row)
    if len(demand) != n + 1 or len(distance) != n + 1 or any(len(row) != n + 1 for row in distance):
        raise ValueError("unexpected DZN dimensions")
    return n, capacity, demand, distance


def parse_routes(path: Path) -> tuple[list[list[int]], int | None]:
    routes = []
    stated_cost = None
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.startswith("Route #"):
            routes.append([int(value) for value in line.split(":", 1)[1].split()])
        elif line.startswith("Cost "):
            stated_cost = int(line.split()[1])
    return routes, stated_cost


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dzn", type=Path)
    parser.add_argument("routes", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("--seconds", type=float, default=1200)
    parser.add_argument("--threads", type=int, default=8)
    parser.add_argument("--minimum-routes", type=int)
    parser.add_argument("--maximum-routes", type=int)
    parser.add_argument("--maximum-objective", type=int)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    n, capacity, demand, distance = parse_dzn(args.dzn)
    routes, stated_cost = parse_routes(args.routes)
    nodes = range(n + 1)
    customers = range(1, n + 1)
    arcs = [(i, j) for i in nodes for j in nodes if i != j]
    demand_minimum = math.ceil(sum(demand) / capacity)
    minimum_routes = args.minimum_routes or demand_minimum
    maximum_routes = args.maximum_routes or n
    if minimum_routes < demand_minimum or not minimum_routes <= maximum_routes <= n:
        raise ValueError("invalid route-count interval")

    model = gp.Model(f"directed-flow-CVRP-{n}")
    x = {arc: model.addVar(vtype=GRB.BINARY, name=f"x_{arc[0]}_{arc[1]}") for arc in arcs}
    flow = {
        arc: model.addVar(lb=0, ub=capacity, vtype=GRB.CONTINUOUS, name=f"f_{arc[0]}_{arc[1]}")
        for arc in arcs
    }
    for customer in customers:
        model.addConstr(gp.quicksum(x[i, customer] for i in nodes if i != customer) == 1)
        model.addConstr(gp.quicksum(x[customer, j] for j in nodes if j != customer) == 1)
        model.addConstr(
            gp.quicksum(flow[i, customer] for i in nodes if i != customer)
            - gp.quicksum(flow[customer, j] for j in nodes if j != customer)
            == demand[customer]
        )
    for i, j in arcs:
        model.addConstr(flow[i, j] <= (capacity if i == 0 else capacity - demand[i]) * x[i, j])
        if j == 0:
            model.addConstr(flow[i, j] == 0)
        else:
            model.addConstr(flow[i, j] >= demand[j] * x[i, j])

    route_count = gp.quicksum(x[0, j] for j in customers)
    model.addConstr(route_count >= minimum_routes)
    model.addConstr(route_count <= maximum_routes)
    objective = gp.quicksum(distance[i][j] * x[i, j] for i, j in arcs)
    if args.maximum_objective is not None:
        model.addConstr(objective <= args.maximum_objective)
    model.setObjective(objective, GRB.MINIMIZE)

    if minimum_routes <= len(routes) <= maximum_routes and (
        args.maximum_objective is None or stated_cost is None or stated_cost <= args.maximum_objective
    ):
        x_start = {arc: 0.0 for arc in arcs}
        f_start = {arc: 0.0 for arc in arcs}
        for route in routes:
            remaining = sum(demand[j] for j in route)
            previous = 0
            for customer in route:
                x_start[previous, customer] = 1.0
                f_start[previous, customer] = remaining
                remaining -= demand[customer]
                previous = customer
            x_start[previous, 0] = 1.0
        for arc in arcs:
            x[arc].Start = x_start[arc]
            flow[arc].Start = f_start[arc]

    model.Params.TimeLimit = args.seconds
    model.Params.Threads = args.threads
    model.Params.MIPGap = 0
    model.Params.MIPFocus = 3
    model.Params.LogFile = str(args.out / "gurobi-standard-cvrp-flow.log")
    started = time.time()
    model.optimize()
    result = {
        "schema": "directed-single-commodity-flow-cvrp-cutoff-v1",
        "status": int(model.Status),
        "status_name": {
            GRB.OPTIMAL: "OPTIMAL",
            GRB.INFEASIBLE: "INFEASIBLE",
            GRB.TIME_LIMIT: "TIME_LIMIT",
        }.get(model.Status, str(model.Status)),
        "gurobi_version": list(gp.gurobi.version()),
        "customers": n,
        "capacity": capacity,
        "total_demand": sum(demand),
        "minimum_routes": minimum_routes,
        "maximum_routes": maximum_routes,
        "maximum_objective": args.maximum_objective,
        "binary_arc_variables": len(arcs),
        "continuous_flow_variables": len(arcs),
        "linear_constraints": model.NumConstrs,
        "runtime": model.Runtime,
        "wall_time": time.time() - started,
        "nodes": model.NodeCount,
        "solution_count": model.SolCount,
        "dzn_sha256": hashlib.sha256(args.dzn.read_bytes()).hexdigest(),
        "routes_sha256": hashlib.sha256(args.routes.read_bytes()).hexdigest(),
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "cpu_only": True,
    }
    try:
        result["best_bound"] = model.ObjBound
    except Exception:
        pass
    if model.SolCount:
        result["objective"] = model.ObjVal
        model.write(str(args.out / "gurobi-standard-cvrp-flow.sol"))
    if model.Status == GRB.INFEASIBLE and args.maximum_objective is not None:
        result["proof_statement"] = (
            f"No capacity-feasible CVRP solution with {minimum_routes} through "
            f"{maximum_routes} routes and objective at most {args.maximum_objective} exists."
        )
    (args.out / "gurobi-standard-cvrp-flow-summary.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print("RESULT_JSON=" + json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
