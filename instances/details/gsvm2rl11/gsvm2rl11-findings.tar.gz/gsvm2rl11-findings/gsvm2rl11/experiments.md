# Experiment ledger

This file is generated from `runs/*/result.json` by the controller.

| Run | Solver | Status | Primal | Dual | Gap | Verified | Runtime (s) |
|---|---|---|---:|---:|---:|---|---:|
| `copt-20260903-175003-45824498` | copt | TIMEOUT | 46710.2286683018 | 1915.16751668607 | 0.958998969363091 | yes @ 1e-9 | 300.030279874802 |
| `custom-20260903-175815-cca15fb8` | custom-python | completed | — | — | — | not checked | 0.722441673278809 |
| `custom-20260903-180125-835e6017` | custom-python | unsupported | — | — | — | not checked | 0.824058055877686 |
| `custom-20260903-184335-4a78fda4` | custom-python | unsupported | — | — | — | not checked | 0.875738620758057 |
| `custom-20260903-184533-2d18baf6` | custom-python | unsupported | — | — | — | not checked | 1.0261070728302 |
| `gurobi-20260903-174959-389eab23` | gurobi | TIME_LIMIT | 18539.1271131057 | 2096.75545782007 | 0.886901069018625 | no | 300.073030948639 |
| `gurobi-20260903-180936-fb7410f6` | gurobi | TIME_LIMIT | 18539.1271619264 | 1662.54834974925 | 0.910322188567561 | yes @ 1e-9 | 1800.18627309799 |
