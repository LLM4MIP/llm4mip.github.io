#!/usr/bin/env python3
"""Self-contained sparse feasibility and exchange search for gsvm2rl11.

The method parses linear rows from MPS, starts from bound-favorable integer values,
repairs violated rows by sparse variable moves, and then performs objective-improving
single-coordinate moves while preserving feasibility. It uses only the original model.
"""
import argparse, gzip, math, random, time, json


def tokens(path):
    op = gzip.open if path.endswith('.gz') else open
    with op(path, 'rt', errors='replace') as f:
        for line in f:
            if line and line[0] not in ('*', ' '):
                yield line.strip().split()
            elif line.strip() and not line.lstrip().startswith('*'):
                yield line.strip().split()


def parse(path):
    sec=''; sense={}; rhs={}; obj={}; cols={}; lo={}; up={}; integer=set(); objrow=None; intmode=False
    for z in tokens(path):
        if len(z)==1 and z[0] in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE'):
            sec=z[0]; continue
        if z[0]=='NAME': sec='NAME'; continue
        if z[0]=='ENDATA': break
        if sec=='OBJSENSE': continue
        if sec=='ROWS':
            t,r=z[0],z[1]
            if t=='N' and objrow is None: objrow=r
            elif t!='N': sense[r]=t
        elif sec=='COLUMNS':
            if len(z)>=3 and z[1].strip("'")=='MARKER':
                if 'INTORG' in z: intmode=True
                if 'INTEND' in z: intmode=False
                continue
            v=z[0]
            if intmode: integer.add(v)
            a=cols.setdefault(v,{})
            for i in range(1,len(z)-1,2):
                r=z[i]; val=float(z[i+1])
                if r==objrow: obj[v]=obj.get(v,0.0)+val
                else: a[r]=a.get(r,0.0)+val
        elif sec=='RHS':
            for i in range(1,len(z)-1,2): rhs[z[i]]=float(z[i+1])
        elif sec=='BOUNDS':
            typ=z[0]; v=z[2]; val=float(z[3]) if len(z)>3 else 0.0
            if typ=='LO': lo[v]=val
            elif typ=='UP': up[v]=val
            elif typ=='FX': lo[v]=up[v]=val
            elif typ=='FR': lo[v]=-1e30; up[v]=1e30
            elif typ=='MI': lo[v]=-1e30
            elif typ=='PL': up[v]=1e30
            elif typ=='BV': lo[v]=0; up[v]=1; integer.add(v)
            elif typ=='LI': lo[v]=val; integer.add(v)
            elif typ=='UI': up[v]=val; integer.add(v)
    vs=list(cols)
    for v in vs:
        lo.setdefault(v,0.0); up.setdefault(v,1e30)
    rows={r:[] for r in sense}
    for v,a in cols.items():
        for r,c in a.items():
            if r in rows and c: rows[r].append((v,c))
    return vs,sense,rhs,obj,rows,lo,up,integer


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--model',required=True); ap.add_argument('--seed',type=int,default=11); ap.add_argument('--seconds',type=int,default=2300); q=ap.parse_args()
    random.seed(q.seed); V,S,B,C,R,L,U,I=parse(q.model); start=time.time(); deadline=start+q.seconds
    finite=lambda x: abs(x)<1e29
    x={v:(round(L[v]) if v in I else L[v]) for v in V}
    act={r:sum(c*x[v] for v,c in a) for r,a in R.items()}
    def viol(r,a=None):
        if a is None:a=act[r]
        b=B.get(r,0.0); s=S[r]
        return max(0,b-a) if s=='G' else max(0,a-b) if s=='L' else abs(a-b)
    def feasible(): return max((viol(r) for r in R),default=0)<=1e-7
    # Greedy repair chooses a bounded move with best violation reduction per objective damage.
    for it in range(2000000):
        if time.time()>deadline: break
        bad=[r for r in R if viol(r)>1e-7]
        if not bad: break
        r=max(bad,key=viol); old=viol(r); best=None
        for v,c in R[r]:
            steps=[]
            if x[v]<U[v]-1e-9: steps.append(1 if v in I else min(U[v]-x[v],old/max(abs(c),1e-12)))
            if x[v]>L[v]+1e-9: steps.append(-1 if v in I else -min(x[v]-L[v],old/max(abs(c),1e-12)))
            for d in steps:
                nv=x[v]+d
                if nv<L[v]-1e-9 or nv>U[v]+1e-9: continue
                gain=old-viol(r,act[r]+c*d)
                if gain<=1e-12: continue
                collateral=0.0
                for rr,cc in cols_for(v,R): collateral+=max(0,viol(rr,act[rr]+cc*d)-viol(rr))
                score=gain/(1+collateral+max(0,C.get(v,0)*d)*1e-5)
                if best is None or score>best[0]: best=(score,v,d)
        if best is None: break
        _,v,d=best; x[v]+=d
        for rr,cc in cols_for(v,R): act[rr]+=cc*d
    # Feasible coordinate descent, mainly useful for sparse integer columns.
    if feasible():
        order=sorted(V,key=lambda v:abs(C.get(v,0)),reverse=True)
        improved=True
        while improved and time.time()<deadline:
            improved=False
            random.shuffle(order)
            for v in order:
                cv=C.get(v,0.0)
                if abs(cv)<1e-12: continue
                d=-1 if cv>0 else 1
                if v not in I: continue
                if x[v]+d<L[v]-1e-9 or x[v]+d>U[v]+1e-9: continue
                ok=True
                for rr,cc in cols_for(v,R):
                    if viol(rr,act[rr]+cc*d)>1e-7: ok=False; break
                if ok:
                    x[v]+=d
                    for rr,cc in cols_for(v,R): act[rr]+=cc*d
                    improved=True
    ok=feasible(); objective=sum(C.get(v,0)*x[v] for v in V)
    if ok:
        with open('best.sol','w') as f:
            f.write('# Objective value = %.17g\n'%objective)
            for v in V:
                if abs(x[v])>1e-15:f.write('%s %.17g\n'%(v,x[v]))
    with open('method_result.json','w') as f: json.dump({'feasible':ok,'objective':objective if ok else None,'max_violation':max((viol(r) for r in R),default=0),'runtime':time.time()-start},f)

def cols_for(v,R):
    # Rows are modest enough here; avoid a second large index in the prototype.
    for r,a in R.items():
        for w,c in a:
            if w==v:
                yield r,c; break

if __name__=='__main__': main()
