import argparse, gzip, json, math, os, random, time


def open_model(path):
    return gzip.open(path, 'rt', errors='replace') if path.endswith('.gz') else open(path, 'r', errors='replace')


def parse_mps(path):
    section = None
    sense = 'min'
    rowsense = {}
    objrow = None
    coeff = {}
    obj = {}
    rhs = {}
    ranges = False
    integer_mode = False
    integer_named = set()
    variables = []
    seen = set()
    lb = {}
    ub = {}
    with open_model(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('*'):
                continue
            tok = line.split()
            head = tok[0].upper()
            if head in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE','OBJNAME'):
                section = head
                if head == 'RANGES':
                    ranges = True
                if head == 'ENDATA':
                    break
                continue
            if section == 'OBJSENSE':
                if head.startswith('MAX'):
                    sense = 'max'
                elif head.startswith('MIN'):
                    sense = 'min'
            elif section == 'ROWS' and len(tok) >= 2:
                typ, name = tok[0].upper(), tok[1]
                if typ == 'N' and objrow is None:
                    objrow = name
                elif typ in ('L','G','E'):
                    rowsense[name] = typ
                    coeff[name] = {}
            elif section == 'COLUMNS':
                if any('MARKER' in x.upper() for x in tok):
                    if any('INTORG' in x.upper() for x in tok): integer_mode = True
                    if any('INTEND' in x.upper() for x in tok): integer_mode = False
                    continue
                if len(tok) < 3:
                    continue
                var = tok[0]
                if var not in seen:
                    seen.add(var); variables.append(var)
                if integer_mode:
                    integer_named.add(var)
                pairs = tok[1:]
                for k in range(0, len(pairs)-1, 2):
                    row = pairs[k]
                    try: val = float(pairs[k+1].replace('D','E').replace('d','e'))
                    except ValueError: continue
                    if row == objrow:
                        obj[var] = obj.get(var, 0.0) + val
                    elif row in coeff:
                        coeff[row][var] = coeff[row].get(var, 0.0) + val
            elif section == 'RHS' and len(tok) >= 3:
                pairs = tok[1:]
                for k in range(0, len(pairs)-1, 2):
                    row = pairs[k]
                    if row in rowsense and row not in rhs:
                        try: rhs[row] = float(pairs[k+1].replace('D','E').replace('d','e'))
                        except ValueError: pass
            elif section == 'BOUNDS' and len(tok) >= 3:
                typ = tok[0].upper(); var = tok[2]
                if var not in seen:
                    seen.add(var); variables.append(var)
                val = 0.0
                if len(tok) >= 4:
                    try: val = float(tok[3].replace('D','E').replace('d','e'))
                    except ValueError: val = 0.0
                if typ == 'BV':
                    integer_named.add(var); lb[var] = 0.0; ub[var] = 1.0
                elif typ == 'LI':
                    integer_named.add(var); lb[var] = val
                elif typ == 'UI':
                    integer_named.add(var); ub[var] = val
                elif typ == 'LO': lb[var] = val
                elif typ == 'UP': ub[var] = val
                elif typ == 'FX': lb[var] = val; ub[var] = val
                elif typ == 'FR': lb[var] = -math.inf; ub[var] = math.inf
                elif typ == 'MI': lb[var] = -math.inf
                elif typ == 'PL': ub[var] = math.inf
    for v in variables:
        lb.setdefault(v, 0.0)
        ub.setdefault(v, 1.0 if v in integer_named else math.inf)
    rows = list(rowsense)
    row_index = {r:i for i,r in enumerate(rows)}
    byvar = {v:[] for v in variables}
    row_terms = []
    for r in rows:
        terms = []
        for v,a in coeff[r].items():
            if abs(a) > 0:
                terms.append((v,a)); byvar.setdefault(v,[]).append((row_index[r],a))
        row_terms.append(terms)
    return {'sense':sense,'rows':rows,'rowsense':[rowsense[r] for r in rows],
            'rhs':[rhs.get(r,0.0) for r in rows], 'terms':row_terms, 'byvar':byvar,
            'vars':variables,'obj':obj,'lb':lb,'ub':ub,'ints':integer_named,'ranges':ranges}


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--model',required=True); ap.add_argument('--seed',type=int,default=731)
    ap.add_argument('--run-seconds',type=float,default=820.0); args=ap.parse_args()
    start=time.time(); rnd=random.Random(args.seed)
    try: m=parse_mps(args.model)
    except Exception as e:
        json.dump({'status':'parse_error','error':repr(e)},open('method_result.json','w')); return
    vs=m['vars']; n=len(vs); idx={v:i for i,v in enumerate(vs)}
    binary=[]; unsupported=[]
    for v in vs:
        lo,hi=m['lb'][v],m['ub'][v]
        if v in m['ints'] and lo >= -1e-12 and hi <= 1+1e-12:
            binary.append(v)
        elif abs(lo-hi) <= 1e-12:
            pass
        else:
            unsupported.append(v)
    report={'algorithm':'adaptive sparse binary row-repair with feasibility-preserving descent',
            'variables':n,'rows':len(m['rows']),'binary_variables':len(binary),
            'nonbinary_unfixed_variables':len(unsupported),'has_ranges':m['ranges'],'seed':args.seed}
    # This method intentionally avoids fabricating a candidate for a model whose free variables
    # cannot be represented by its binary neighborhood.
    if m['ranges'] or unsupported:
        report['status']='unsupported_after_robust_parse'
        report['reason']='The model contains ranged rows or nonbinary unfixed variables requiring a different structural elimination.'
        report['sample_nonbinary']=unsupported[:20]
        json.dump(report,open('sparse_binary_repair_report.json','w'),indent=2)
        json.dump({'status':'unsupported','report':'sparse_binary_repair_report.json'},open('method_result.json','w'),indent=2)
        return
    bidx=[idx[v] for v in binary]; bset=set(binary)
    obj=[m['obj'].get(v,0.0) for v in vs]
    orient=1.0 if m['sense']=='min' else -1.0
    row_by_var=[[] for _ in vs]
    for v,entries in m['byvar'].items():
        j=idx[v]
        row_by_var[j]=entries
    scale=[max(1.0,abs(x)) for x in m['rhs']]
    def rowviol(i,a):
        s=m['rowsense'][i]; b=m['rhs'][i]
        if s=='L': return max(0.0,a-b)/scale[i]
        if s=='G': return max(0.0,b-a)/scale[i]
        return abs(a-b)/scale[i]
    def initialize(kind):
        x=[0.0]*n
        for j,v in enumerate(vs):
            if abs(m['lb'][v]-m['ub'][v])<=1e-12: x[j]=m['lb'][v]
        if kind==1:
            for j in bidx:
                if orient*obj[j] < 0: x[j]=1.0
        elif kind>=2:
            p=min(0.85,0.04+0.06*(kind%12))
            for j in bidx: x[j]=1.0 if rnd.random()<p else 0.0
        act=[0.0]*len(m['rows'])
        for i,terms in enumerate(m['terms']):
            act[i]=sum(a*x[idx[v]] for v,a in terms)
        return x,act
    def objective(x): return sum(obj[j]*x[j] for j in range(n))
    def totalviol(act): return sum(rowviol(i,a) for i,a in enumerate(act))
    def feasible_raw(act):
        for i,a in enumerate(act):
            s=m['rowsense'][i]; b=m['rhs'][i]; tol=1e-7*max(1.0,abs(b))
            if (s=='L' and a>b+tol) or (s=='G' and a<b-tol) or (s=='E' and abs(a-b)>tol): return False
        return True
    deadline=start+args.run_seconds
    best=None; best_obj=math.inf; restarts=0; flips=0
    while time.time()<deadline:
        x,act=initialize(restarts); restarts+=1
        tv=totalviol(act)
        stagn=0
        while time.time()<deadline and stagn<2500:
            violated=[i for i,a in enumerate(act) if rowviol(i,a)>1e-10]
            if not violated:
                val=orient*objective(x)
                if feasible_raw(act) and val<best_obj-1e-8:
                    best_obj=val; best=x[:]
                # Feasibility-preserving objective descent.
                candidates=bidx[:]; rnd.shuffle(candidates)
                changed=False
                for j in candidates[:min(len(candidates),2500)]:
                    nv=1.0-x[j]; d=nv-x[j]
                    if orient*obj[j]*d >= -1e-10: continue
                    ok=True
                    for i,a in row_by_var[j]:
                        na=act[i]+a*d
                        s=m['rowsense'][i]; b=m['rhs'][i]; tol=1e-8*max(1.0,abs(b))
                        if (s=='L' and na>b+tol) or (s=='G' and na<b-tol) or (s=='E' and abs(na-b)>tol): ok=False; break
                    if ok:
                        x[j]=nv
                        for i,a in row_by_var[j]: act[i]+=a*d
                        flips+=1; changed=True
                if not changed: break
                stagn+=1; continue
            chosen_rows=violated if len(violated)<16 else rnd.sample(violated,16)
            cand=set()
            for i in chosen_rows:
                for v,a in m['terms'][i]:
                    if v in bset: cand.add(idx[v])
            if not cand: break
            oldtv=tv; choice=None; choice_score=math.inf
            for j in cand:
                d=1.0-2.0*x[j]
                delta=0.0
                for i,a in row_by_var[j]: delta += rowviol(i,act[i]+a*d)-rowviol(i,act[i])
                # Violation dominates until feasibility; objective breaks ties.
                score=delta + 1e-8*orient*obj[j]*d + rnd.random()*1e-11
                if score<choice_score: choice_score=score; choice=j
            if choice is None: break
            # Permit occasional worsening moves to escape row-repair cycles.
            if choice_score>1e-9 and rnd.random()>0.025:
                choice=rnd.choice(tuple(cand))
            d=1.0-2.0*x[choice]; x[choice]=1.0-x[choice]
            for i,a in row_by_var[choice]: act[i]+=a*d
            flips+=1; tv=totalviol(act)
            stagn=stagn+1 if tv>=oldtv-1e-11 else 0
    report.update({'status':'completed','runtime_seconds':time.time()-start,'restarts':restarts,'flips':flips,
                   'feasible_candidate_found':best is not None})
    if best is not None:
        true_obj=objective(best); report['objective']=true_obj
        with open('best.sol','w') as f:
            f.write('# Objective value = %.17g\n'%true_obj)
            for j,v in enumerate(vs): f.write('%s %.17g\n'%(v,best[j]))
        result={'status':'feasible_candidate','objective':true_obj,'solution_file':'best.sol','report':'sparse_binary_repair_report.json'}
    else:
        result={'status':'no_candidate','report':'sparse_binary_repair_report.json'}
    json.dump(report,open('sparse_binary_repair_report.json','w'),indent=2)
    json.dump(result,open('method_result.json','w'),indent=2)

if __name__=='__main__': main()
