import argparse, gzip, json, math, os, random, time


def open_model(path):
    return gzip.open(path, 'rt', errors='replace') if path.endswith('.gz') else open(path, 'r', errors='replace')


def parse_mps(path):
    section = None
    obj_sense = 'MIN'
    row_type = {}
    row_order = []
    obj_row = None
    var_index = {}
    names = []
    obj = []
    cols = []
    lb = []
    ub = []
    integer = []
    rhs = {}
    in_integer = False

    def variable(name):
        if name not in var_index:
            var_index[name] = len(names)
            names.append(name)
            obj.append(0.0)
            cols.append([])
            lb.append(0.0)
            ub.append(float('inf'))
            integer.append(False)
        return var_index[name]

    with open_model(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('*'):
                continue
            tok = line.split()
            head = tok[0].upper()
            if head in ('NAME','OBJSENSE','OBJNAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA'):
                section = head
                if head == 'ENDATA':
                    break
                continue
            if section == 'OBJSENSE':
                if head.startswith('MAX'):
                    obj_sense = 'MAX'
                elif head.startswith('MIN'):
                    obj_sense = 'MIN'
            elif section == 'ROWS':
                if len(tok) >= 2:
                    typ, rn = tok[0].upper(), tok[1]
                    row_type[rn] = typ
                    if typ == 'N' and obj_row is None:
                        obj_row = rn
                    elif typ in ('L','G','E'):
                        row_order.append(rn)
            elif section == 'COLUMNS':
                if len(tok) >= 3 and 'MARKER' in tok[1].upper():
                    marker = tok[-1].upper().replace("'", '')
                    if marker == 'INTORG':
                        in_integer = True
                    elif marker == 'INTEND':
                        in_integer = False
                    continue
                if len(tok) < 3:
                    continue
                j = variable(tok[0])
                if in_integer:
                    integer[j] = True
                pairs = tok[1:]
                for k in range(0, len(pairs)-1, 2):
                    rn = pairs[k]
                    try:
                        val = float(pairs[k+1].replace('D','E').replace('d','e'))
                    except ValueError:
                        continue
                    if rn == obj_row:
                        obj[j] += val
                    elif rn in row_type and row_type[rn] in ('L','G','E'):
                        cols[j].append((rn, val))
            elif section == 'RHS':
                if len(tok) >= 3:
                    pairs = tok[1:]
                    for k in range(0, len(pairs)-1, 2):
                        rn = pairs[k]
                        if rn not in rhs:
                            try:
                                rhs[rn] = float(pairs[k+1].replace('D','E').replace('d','e'))
                            except ValueError:
                                pass
            elif section == 'BOUNDS':
                if len(tok) < 3:
                    continue
                typ = tok[0].upper()
                j = variable(tok[2])
                val = 0.0
                if len(tok) >= 4:
                    try:
                        val = float(tok[3].replace('D','E').replace('d','e'))
                    except ValueError:
                        val = 0.0
                if typ == 'BV':
                    lb[j], ub[j], integer[j] = 0.0, 1.0, True
                elif typ in ('LI','UI'):
                    integer[j] = True
                    if typ == 'LI': lb[j] = val
                    else: ub[j] = val
                elif typ == 'LO': lb[j] = val
                elif typ == 'UP': ub[j] = val
                elif typ == 'FX': lb[j] = ub[j] = val
                elif typ == 'FR': lb[j], ub[j] = -float('inf'), float('inf')
                elif typ == 'MI': lb[j] = -float('inf')
                elif typ == 'PL': ub[j] = float('inf')

    rid = {r:i for i,r in enumerate(row_order)}
    senses = [row_type[r] for r in row_order]
    b = [rhs.get(r, 0.0) for r in row_order]
    numeric_cols = []
    incidence = [[] for _ in row_order]
    for j, col in enumerate(cols):
        merged = {}
        for rn, a in col:
            if rn in rid:
                i = rid[rn]
                merged[i] = merged.get(i, 0.0) + a
        cc = [(i,a) for i,a in merged.items() if a != 0.0]
        numeric_cols.append(cc)
        for i,a in cc:
            incidence[i].append((j,a))
    binary = []
    for j in range(len(names)):
        if integer[j] and lb[j] >= -1e-12 and ub[j] <= 1.0+1e-12:
            binary.append(j)
    return names, obj, numeric_cols, incidence, senses, b, lb, ub, binary, obj_sense


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--seed', type=int, default=41)
    ap.add_argument('--budget', type=float, default=1650.0)
    args = ap.parse_args()
    start = time.time()
    deadline = start + max(5.0, args.budget)
    rng = random.Random(args.seed)
    names, obj, cols, inc, sense, rhs, lb, ub, binary, osense = parse_mps(args.model)
    n, m = len(names), len(rhs)
    binary_set = set(binary)
    unsupported = [j for j in range(n) if j not in binary_set and (abs(lb[j]) > 1e-12 or ub[j] < float('inf'))]
    # This method is deliberately specialized to binary conflict/cover structure.
    # Nonbinary variables are held at zero when allowed; otherwise no false feasibility claim is made.
    if unsupported:
        out = {'status':'unsupported','reason':'nonbinary variables with nonzero mandatory bounds','variables':n,'rows':m,'binary_variables':len(binary),'elapsed_seconds':time.time()-start}
        with open('method_result.json','w') as f: json.dump(out,f,indent=2)
        return
    cost = obj[:] if osense == 'MIN' else [-v for v in obj]
    tol = 1e-8

    def viol(i, value):
        if sense[i] == 'L': return max(0.0, value-rhs[i])
        if sense[i] == 'G': return max(0.0, rhs[i]-value)
        return abs(value-rhs[i])

    def feasible(act):
        return all(viol(i, act[i]) <= tol for i in range(m))

    def objective(x):
        return sum(obj[j]*x[j] for j in binary)

    def min_objective(x):
        return sum(cost[j]*x[j] for j in binary)

    def flip_delta_violation(j, x, act):
        d = 1.0 if x[j] == 0 else -1.0
        old = new = 0.0
        for i,a in cols[j]:
            old += viol(i, act[i])
            new += viol(i, act[i] + d*a)
        return new-old

    def apply(j, x, act):
        d = 1.0 if x[j] == 0 else -1.0
        x[j] = 1-x[j]
        for i,a in cols[j]: act[i] += d*a

    def repair(x, act, limit):
        stall = 0
        for _ in range(limit):
            bad = [i for i in range(m) if viol(i,act[i]) > tol]
            if not bad:
                return True
            i = rng.choice(bad)
            cand = []
            entries = inc[i]
            if len(entries) > 160:
                entries = rng.sample(entries,160)
            oldi = viol(i,act[i])
            for j,a in entries:
                if j not in binary_set: continue
                d = 1.0 if x[j] == 0 else -1.0
                newi = viol(i,act[i]+d*a)
                if newi >= oldi-1e-12: continue
                dv = flip_delta_violation(j,x,act)
                dc = cost[j]*d
                score = dv + 1e-7*max(-1e6,min(1e6,dc)) + rng.random()*1e-10
                cand.append((score,j))
            if not cand:
                stall += 1
                pool = [j for j,a in inc[i] if j in binary_set]
                if not pool or stall > 50: return False
                apply(rng.choice(pool),x,act)
            else:
                cand.sort()
                q = min(4,len(cand))
                apply(cand[rng.randrange(q)][1],x,act)
                stall = 0
        return feasible(act)

    def greedy_improve(x,act,passes=4):
        improved = True
        p = 0
        while improved and p < passes and time.time() < deadline:
            improved = False
            p += 1
            order = binary[:]
            rng.shuffle(order)
            order.sort(key=lambda j: cost[j]*(1 if x[j] == 0 else -1))
            for j in order:
                d = 1 if x[j] == 0 else -1
                if cost[j]*d >= -1e-10: continue
                ok = True
                for i,a in cols[j]:
                    if viol(i,act[i]+d*a) > tol:
                        ok = False; break
                if ok:
                    apply(j,x,act); improved = True
        return x,act

    best_x = None
    best_min = float('inf')
    feasible_count = 0
    attempts = 0
    exchanges = 0
    trace = []

    while time.time() < deadline:
        attempts += 1
        x = [0]*n
        act = [0.0]*m
        # Mostly start at zero; diversified starts perturb sparse conflict components.
        if attempts > 1:
            target = min(len(binary), max(1, int(math.sqrt(max(1,len(binary))))))
            for j in rng.sample(binary, target):
                if rng.random() < 0.35:
                    apply(j,x,act)
        if not repair(x,act,max(2000,8*max(1,m))):
            if attempts >= 20 and best_x is None and time.time()+2 >= deadline: break
            continue
        feasible_count += 1
        x,act = greedy_improve(x,act,5)
        cur = min_objective(x)
        if cur < best_min-1e-8:
            best_min, best_x = cur, x[:]
            trace.append({'seconds':time.time()-start,'attempt':attempts,'objective':objective(x),'phase':'construct'})
        # Conflict exchange: remove one chosen variable, repair the affected rows,
        # then greedily refill. Keep only strictly improving feasible exchanges.
        for _ in range(max(50,min(3000,5*max(1,len(binary))))):
            if time.time() >= deadline: break
            chosen = [j for j in binary if x[j] == 1]
            if not chosen: break
            j = rng.choice(chosen)
            y, ay = x[:], act[:]
            apply(j,y,ay)
            if repair(y,ay,max(100,2*len(cols[j])+m//4)):
                y,ay = greedy_improve(y,ay,2)
                val = min_objective(y)
                if val < cur-1e-8:
                    x,act,cur = y,ay,val
                    exchanges += 1
                    if val < best_min-1e-8:
                        best_min,best_x = val,y[:]
                        trace.append({'seconds':time.time()-start,'attempt':attempts,'objective':objective(y),'phase':'exchange'})
        if attempts >= 200 and best_x is not None:
            break

    result = {'status':'no_feasible_solution','method':'binary incidence repair and conflict exchange','variables':n,'rows':m,'binary_variables':len(binary),'objective_sense':osense,'attempts':attempts,'feasible_constructions':feasible_count,'accepted_exchanges':exchanges,'elapsed_seconds':time.time()-start}
    if best_x is not None:
        act = [0.0]*m
        for j in binary:
            if best_x[j]:
                for i,a in cols[j]: act[i] += a
        maxv = max([viol(i,act[i]) for i in range(m)] or [0.0])
        val = objective(best_x)
        if maxv <= tol:
            with open('best.sol','w') as f:
                f.write('# Objective value = %.17g\n' % val)
                for j,name in enumerate(names):
                    f.write('%s %.17g\n' % (name, float(best_x[j]) if j in binary_set else 0.0))
            result.update({'status':'feasible_candidate','objective':val,'maximum_internal_row_violation':maxv,'solution_file':'best.sol'})
    with open('conflict_trace.json','w') as f: json.dump(trace,f,indent=2)
    with open('method_result.json','w') as f: json.dump(result,f,indent=2)

if __name__ == '__main__':
    main()
