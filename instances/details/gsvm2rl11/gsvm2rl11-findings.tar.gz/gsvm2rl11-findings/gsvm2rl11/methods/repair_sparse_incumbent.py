import argparse, gzip, json, math, os
from collections import defaultdict


def open_model(path):
    return gzip.open(path, 'rt', errors='replace') if path.endswith('.gz') else open(path, 'r', errors='replace')


def parse_mps(path):
    rows = {}
    row_order = []
    objrow = None
    cols = defaultdict(dict)
    rhs = defaultdict(float)
    lb = defaultdict(lambda: 0.0)
    ub = defaultdict(lambda: math.inf)
    integer = set()
    var_order = []
    seen_vars = set()
    section = None
    int_mode = False
    obj_sense = 1.0
    with open_model(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('*'):
                continue
            tok = line.split()
            head = tok[0].upper()
            if head in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE','OBJNAME'):
                section = head
                continue
            if section == 'OBJSENSE':
                if head.startswith('MAX'):
                    obj_sense = -1.0
                elif head.startswith('MIN'):
                    obj_sense = 1.0
                continue
            if section == 'ROWS':
                if len(tok) >= 2:
                    typ, name = tok[0].upper(), tok[1]
                    if typ == 'N' and objrow is None:
                        objrow = name
                    else:
                        rows[name] = typ
                        row_order.append(name)
                continue
            if section == 'COLUMNS':
                if 'MARKER' in raw.upper():
                    if 'INTORG' in raw.upper():
                        int_mode = True
                    elif 'INTEND' in raw.upper():
                        int_mode = False
                    continue
                if len(tok) < 3:
                    continue
                var = tok[0]
                if var not in seen_vars:
                    seen_vars.add(var); var_order.append(var)
                if int_mode:
                    integer.add(var)
                pairs = tok[1:]
                for k in range(0, len(pairs)-1, 2):
                    rn = pairs[k]
                    try: val = float(pairs[k+1].replace('D','E'))
                    except ValueError: continue
                    cols[var][rn] = cols[var].get(rn, 0.0) + val
                continue
            if section == 'RHS':
                if len(tok) >= 3:
                    pairs = tok[1:]
                    for k in range(0, len(pairs)-1, 2):
                        try: rhs[pairs[k]] = float(pairs[k+1].replace('D','E'))
                        except ValueError: pass
                continue
            if section == 'BOUNDS':
                if len(tok) < 3:
                    continue
                typ = tok[0].upper(); var = tok[2]
                if var not in seen_vars:
                    seen_vars.add(var); var_order.append(var)
                val = 0.0
                if len(tok) >= 4:
                    try: val = float(tok[3].replace('D','E'))
                    except ValueError: val = 0.0
                if typ == 'LO': lb[var] = val
                elif typ == 'UP': ub[var] = val
                elif typ == 'FX': lb[var] = val; ub[var] = val
                elif typ == 'FR': lb[var] = -math.inf; ub[var] = math.inf
                elif typ == 'MI': lb[var] = -math.inf
                elif typ == 'PL': ub[var] = math.inf
                elif typ == 'BV': lb[var] = 0.0; ub[var] = 1.0; integer.add(var)
                elif typ == 'LI': lb[var] = val; integer.add(var)
                elif typ == 'UI': ub[var] = val; integer.add(var)
    rowvars = defaultdict(list)
    obj = defaultdict(float)
    for v, ent in cols.items():
        for r, a in ent.items():
            if r == objrow:
                obj[v] += obj_sense * a
            elif r in rows:
                rowvars[r].append((v, a))
    return rows, row_order, rowvars, rhs, lb, ub, integer, obj, var_order


def read_sol(path):
    x = defaultdict(float)
    with open(path, 'r', errors='replace') as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith('#'):
                continue
            p = s.split()
            if len(p) >= 2:
                try: x[p[0]] = float(p[1])
                except ValueError: pass
    return x


def violation(typ, activity, bound):
    if typ == 'L': return max(0.0, activity-bound)
    if typ == 'G': return max(0.0, bound-activity)
    if typ == 'E': return abs(activity-bound)
    return 0.0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--incumbent', required=True)
    ap.add_argument('--tol', type=float, default=2e-10)
    args = ap.parse_args()
    rows, order, rowvars, rhs, lb, ub, integer, obj, var_order = parse_mps(args.model)
    x = read_sol(args.incumbent)
    activity = {}
    for r in order:
        activity[r] = math.fsum(a*x[v] for v,a in rowvars[r])

    def metrics():
        vals = [(violation(rows[r], activity[r], rhs[r]), r) for r in order]
        vals.sort(reverse=True)
        return vals[0] if vals else (0.0, ''), sum(1 for z,_ in vals if z > args.tol), sum(z for z,_ in vals)

    before, before_count, before_sum = metrics()
    changes = []
    # Correct one violated sparse row at a time. Candidate changes are accepted only
    # when they reduce the lexicographic global violation score.
    for iteration in range(200):
        current, cnt, total = metrics()
        if current[0] <= args.tol:
            break
        r = current[1]
        typ = rows[r]; act = activity[r]; b = rhs[r]
        if typ == 'L': desired = b - args.tol
        elif typ == 'G': desired = b + args.tol
        else: desired = b
        candidates = []
        # Continuous corrections preserve the incumbent's combinatorial decision.
        # Integer moves are considered only if the required correction is integral.
        for v,a in rowvars[r]:
            if a == 0.0:
                continue
            delta = (desired-act)/a
            if v in integer:
                rd = round(delta)
                if abs(delta-rd) > 1e-9 or rd == 0:
                    continue
                delta = float(rd)
            nv = x[v] + delta
            if nv < lb[v]-1e-12 or nv > ub[v]+1e-12:
                continue
            new_max = 0.0; new_count = 0; new_total = 0.0
            for rr in order:
                aa = activity[rr] + colsafe(rowvars[rr], v)*delta
                z = violation(rows[rr], aa, rhs[rr])
                new_max = max(new_max, z)
                new_total += z
                if z > args.tol: new_count += 1
            degradation = max(0.0, obj[v]*delta)
            candidates.append(((new_count, new_max, new_total, degradation, abs(delta)), v, delta))
        if not candidates:
            break
        candidates.sort(key=lambda q:q[0])
        score, v, delta = candidates[0]
        old_score = (cnt, current[0], total)
        if (score[0], score[1], score[2]) >= old_score:
            break
        x[v] += delta
        for rr,a in ((rr,a) for rr in order for vv,a in rowvars[rr] if vv == v):
            activity[rr] += a*delta
        changes.append({'variable':v,'delta':delta,'objective_delta':obj[v]*delta,'target_row':r})

    after, after_count, after_sum = metrics()
    bound_bad = []
    int_bad = []
    for v in var_order:
        if x[v] < lb[v]-args.tol or x[v] > ub[v]+args.tol:
            bound_bad.append(v)
        if v in integer and abs(x[v]-round(x[v])) > args.tol:
            int_bad.append(v)
    objective = math.fsum(obj[v]*x[v] for v in var_order)
    feasible = after[0] <= args.tol and not bound_bad and not int_bad
    with open('best.sol','w',encoding='utf-8') as f:
        f.write('# Sparse incumbent numerical repair\n')
        f.write('# Objective value = %.17g\n' % objective)
        for v in var_order:
            if x[v] != 0.0:
                f.write('%s %.17g\n' % (v,x[v]))
    result = {
        'status':'feasible_candidate' if feasible else 'repair_incomplete',
        'objective':objective,
        'feasible_internal':feasible,
        'before_max_row_violation':before[0],
        'before_worst_row':before[1],
        'before_violated_rows':before_count,
        'after_max_row_violation':after[0],
        'after_worst_row':after[1],
        'after_violated_rows':after_count,
        'bound_violations':len(bound_bad),
        'integrality_violations':len(int_bad),
        'changes':changes
    }
    with open('method_result.json','w',encoding='utf-8') as f: json.dump(result,f,indent=2)
    with open('repair_report.txt','w',encoding='utf-8') as f:
        f.write(json.dumps(result,indent=2))


def colsafe(entries, variable):
    for v,a in entries:
        if v == variable:
            return a
    return 0.0

if __name__ == '__main__':
    main()
