import argparse
import gzip
import json
from decimal import Decimal, getcontext
from pathlib import Path

getcontext().prec = 60
ZERO = Decimal(0)
TOL = Decimal('1e-12')


def open_text(path):
    path = str(path)
    if path.endswith('.gz'):
        return gzip.open(path, 'rt', encoding='utf-8', errors='replace')
    return open(path, 'r', encoding='utf-8', errors='replace')


def parse_mps(path):
    section = None
    sense = 'MIN'
    row_type = {}
    obj_row = None
    coeff = {}
    obj = {}
    rhs = {}
    bounds = {}
    integer_mode = False
    integer_vars = set()
    variables = []
    seen_vars = set()
    ranges_seen = False

    with open_text(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('*'):
                continue
            tok = line.split()
            head = tok[0].upper()
            if head in {'NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE','OBJNAME'}:
                section = head
                if head == 'RANGES':
                    ranges_seen = True
                if head == 'ENDATA':
                    break
                continue
            if section == 'OBJSENSE':
                if head.startswith('MAX'):
                    sense = 'MAX'
                elif head.startswith('MIN'):
                    sense = 'MIN'
            elif section == 'ROWS':
                if len(tok) >= 2:
                    typ, name = tok[0].upper(), tok[1]
                    row_type[name] = typ
                    if typ == 'N' and obj_row is None:
                        obj_row = name
            elif section == 'COLUMNS':
                if len(tok) >= 3 and tok[1].strip("'").upper() == 'MARKER':
                    marker = tok[2].strip("'").upper()
                    integer_mode = marker == 'INTORG'
                    if marker == 'INTEND':
                        integer_mode = False
                    continue
                var = tok[0]
                if var not in seen_vars:
                    seen_vars.add(var)
                    variables.append(var)
                if integer_mode:
                    integer_vars.add(var)
                pairs = tok[1:]
                for i in range(0, len(pairs) - 1, 2):
                    row = pairs[i]
                    val = Decimal(pairs[i + 1].replace('D','E').replace('d','e'))
                    if row == obj_row:
                        obj[var] = obj.get(var, ZERO) + val
                    elif row in row_type and row_type[row] != 'N':
                        coeff.setdefault(var, {})[row] = coeff.setdefault(var, {}).get(row, ZERO) + val
            elif section == 'RHS':
                pairs = tok[1:]
                for i in range(0, len(pairs) - 1, 2):
                    row = pairs[i]
                    if row in row_type and row_type[row] != 'N':
                        rhs[row] = Decimal(pairs[i + 1].replace('D','E').replace('d','e'))
            elif section == 'BOUNDS':
                if len(tok) < 3:
                    continue
                typ = tok[0].upper()
                var = tok[2]
                val = Decimal(tok[3].replace('D','E').replace('d','e')) if len(tok) >= 4 else ZERO
                lo, up = bounds.get(var, (ZERO, None))
                if typ == 'BV':
                    lo, up = ZERO, Decimal(1)
                    integer_vars.add(var)
                elif typ in {'LI','UI'}:
                    integer_vars.add(var)
                    if typ == 'LI': lo = val
                    else: up = val
                elif typ == 'LO': lo = val
                elif typ == 'UP': up = val
                elif typ == 'FX': lo, up = val, val
                elif typ == 'FR': lo, up = None, None
                elif typ == 'MI': lo = None
                elif typ == 'PL': up = None
                bounds[var] = (lo, up)

    return {
        'sense': sense, 'row_type': row_type, 'obj_row': obj_row,
        'coeff': coeff, 'obj': obj, 'rhs': rhs, 'bounds': bounds,
        'integer_vars': integer_vars, 'variables': variables,
        'ranges_seen': ranges_seen
    }


def parse_solution(path):
    vals = {}
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('#'):
                continue
            tok = line.split()
            if len(tok) >= 2:
                try:
                    vals[tok[0]] = Decimal(tok[1].replace('D','E').replace('d','e'))
                except Exception:
                    pass
    return vals


def feasible(typ, lhs, rhs):
    if typ == 'L': return lhs <= rhs + TOL
    if typ == 'G': return lhs >= rhs - TOL
    if typ == 'E': return abs(lhs - rhs) <= TOL
    return True


def decstr(x):
    if x == 0:
        return '0'
    return format(x, 'f')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--start', required=True)
    args = ap.parse_args()
    m = parse_mps(args.model)
    vals = parse_solution(args.start)
    for v in m['variables']:
        vals.setdefault(v, ZERO)

    row_lhs = {r: ZERO for r, t in m['row_type'].items() if t != 'N'}
    for v, rows in m['coeff'].items():
        x = vals.get(v, ZERO)
        if x:
            for r, a in rows.items():
                row_lhs[r] = row_lhs.get(r, ZERO) + a * x

    before = sum((m['obj'].get(v, ZERO) * vals.get(v, ZERO) for v in m['variables']), ZERO)
    changed = []
    eligible = 0
    no_feasible_choice = 0

    if not m['ranges_seen']:
        for v in sorted(m['integer_vars']):
            rows = m['coeff'].get(v, {})
            lo, up = m['bounds'].get(v, (ZERO, None))
            if len(rows) != 1 or lo != ZERO or up != Decimal(1):
                continue
            eligible += 1
            r, a = next(iter(rows.items()))
            old = vals.get(v, ZERO)
            base = row_lhs[r] - a * old
            choices = []
            for x in (ZERO, Decimal(1)):
                lhs = base + a * x
                if feasible(m['row_type'][r], lhs, m['rhs'].get(r, ZERO)):
                    choices.append(x)
            if not choices:
                no_feasible_choice += 1
                continue
            c = m['obj'].get(v, ZERO)
            if m['sense'] == 'MIN':
                best = min(choices, key=lambda x: (c * x, abs(x-old)))
            else:
                best = max(choices, key=lambda x: (c * x, -abs(x-old)))
            if best != old:
                vals[v] = best
                row_lhs[r] = base + a * best
                changed.append({'variable': v, 'old': decstr(old), 'new': decstr(best), 'row': r})

    after = sum((m['obj'].get(v, ZERO) * vals.get(v, ZERO) for v in m['variables']), ZERO)
    violations = []
    for r, typ in m['row_type'].items():
        if typ == 'N':
            continue
        rr = m['rhs'].get(r, ZERO)
        if not feasible(typ, row_lhs.get(r, ZERO), rr):
            violations.append(r)

    with open('best.sol', 'w', encoding='utf-8') as f:
        f.write('# Objective value = ' + decstr(after) + '\n')
        for v in m['variables']:
            f.write(v + ' ' + decstr(vals.get(v, ZERO)) + '\n')

    result = {
        'method': 'private_binary_exact_decimal_closure',
        'objective_sense': m['sense'],
        'objective_before': decstr(before),
        'objective_after': decstr(after),
        'objective_change': decstr(after-before),
        'eligible_private_binary_count': eligible,
        'changed_binary_count': len(changed),
        'no_feasible_choice_count': no_feasible_choice,
        'ranges_seen': m['ranges_seen'],
        'internal_row_violation_count_at_1e-12': len(violations),
        'violating_rows_sample': violations[:20],
        'changes_sample': changed[:50],
        'claim': 'Candidate only; feasibility and objective require the controller exact checker.'
    }
    with open('method_result.json', 'w', encoding='utf-8') as f:
        json.dump(result, f, indent=2)


if __name__ == '__main__':
    main()
