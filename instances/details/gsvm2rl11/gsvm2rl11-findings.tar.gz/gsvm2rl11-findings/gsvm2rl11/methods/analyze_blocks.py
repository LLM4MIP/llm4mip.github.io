#!/usr/bin/env python3
import argparse
import collections
import gzip
import hashlib
import json
import math
import os


def open_model(path):
    return gzip.open(path, 'rt', encoding='utf-8', errors='replace') if path.endswith('.gz') else open(path, 'r', encoding='utf-8', errors='replace')


def parse_mps(path):
    rows = {}
    objective_rows = set()
    columns = collections.defaultdict(dict)
    rhs = collections.defaultdict(float)
    lower = collections.defaultdict(lambda: 0.0)
    upper = collections.defaultdict(lambda: math.inf)
    integer = set()
    section = None
    integer_mode = False
    objective_sense = 'MIN'
    with open_model(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('*'):
                continue
            tok = line.split()
            head = tok[0].upper()
            if head in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE'):
                section = head
                if head == 'ENDATA':
                    break
                if head == 'OBJSENSE' and len(tok) > 1:
                    objective_sense = tok[1].upper()
                continue
            if section == 'OBJSENSE':
                objective_sense = tok[0].upper()
            elif section == 'ROWS':
                if len(tok) >= 2:
                    sense, name = tok[0].upper(), tok[1]
                    if sense == 'N':
                        objective_rows.add(name)
                    else:
                        rows[name] = sense
            elif section == 'COLUMNS':
                if len(tok) >= 3 and tok[1].strip("'").upper() == 'MARKER':
                    marker = tok[2].strip("'").upper()
                    integer_mode = marker == 'INTORG'
                    continue
                var = tok[0]
                if integer_mode:
                    integer.add(var)
                for k in range(1, len(tok) - 1, 2):
                    name = tok[k]
                    try:
                        value = float(tok[k+1].replace('D','E').replace('d','e'))
                    except ValueError:
                        continue
                    columns[var][name] = columns[var].get(name, 0.0) + value
            elif section == 'RHS':
                for k in range(1, len(tok) - 1, 2):
                    try:
                        rhs[tok[k]] = float(tok[k+1].replace('D','E').replace('d','e'))
                    except ValueError:
                        pass
            elif section == 'BOUNDS' and len(tok) >= 3:
                kind = tok[0].upper()
                var = tok[2]
                value = float(tok[3].replace('D','E').replace('d','e')) if len(tok) > 3 else 0.0
                if kind == 'LO': lower[var] = value
                elif kind == 'UP': upper[var] = value
                elif kind == 'FX': lower[var] = value; upper[var] = value
                elif kind == 'FR': lower[var] = -math.inf; upper[var] = math.inf
                elif kind == 'MI': lower[var] = -math.inf
                elif kind == 'PL': upper[var] = math.inf
                elif kind == 'BV': lower[var] = 0.0; upper[var] = 1.0; integer.add(var)
                elif kind == 'LI': lower[var] = value; integer.add(var)
                elif kind == 'UI': upper[var] = value; integer.add(var)
    variables = list(columns)
    row_entries = collections.defaultdict(list)
    objective = collections.defaultdict(float)
    for var, entries in columns.items():
        for row, value in entries.items():
            if row in objective_rows:
                objective[var] += value
            elif row in rows:
                row_entries[row].append((var, value))
    return rows, objective_rows, variables, row_entries, objective, rhs, lower, upper, integer, objective_sense


def histogram(values):
    c = collections.Counter(values)
    return {str(k): c[k] for k in sorted(c, key=lambda x: (isinstance(x, str), x))}


def q(value, digits=10):
    if value == 0.0:
        return 0.0
    return round(value, digits)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    args = ap.parse_args()
    rows, objrows, variables, row_entries, objective, rhs, lower, upper, integer, objsense = parse_mps(args.model)
    continuous = set(variables) - integer
    row_records = []
    support_groups = collections.defaultdict(list)
    typed_support_groups = collections.defaultdict(list)
    integer_neighborhood = collections.defaultdict(list)
    continuous_degree = collections.Counter()
    integer_degree = collections.Counter()
    for r, sense in rows.items():
        entries = row_entries.get(r, [])
        iv = sorted(v for v, a in entries if v in integer)
        cv = sorted(v for v, a in entries if v in continuous)
        for v in iv: integer_degree[v] += 1; integer_neighborhood[v].append(r)
        for v in cv: continuous_degree[v] += 1
        support_hash = hashlib.sha256(('\0'.join(cv)).encode()).hexdigest()[:16]
        typed_hash = hashlib.sha256((sense + '\0' + '\0'.join(cv)).encode()).hexdigest()[:16]
        support_groups[support_hash].append(r)
        typed_support_groups[typed_hash].append(r)
        coeffs = [abs(a) for v, a in entries if a != 0]
        row_records.append({
            'row': r, 'sense': sense, 'rhs': rhs[r], 'degree': len(entries),
            'integer_count': len(iv), 'continuous_count': len(cv),
            'integer_variables': iv[:8], 'continuous_support_hash': support_hash,
            'minimum_abs_coefficient': min(coeffs) if coeffs else None,
            'maximum_abs_coefficient': max(coeffs) if coeffs else None
        })
    neighborhood_signatures = collections.defaultdict(list)
    for v in sorted(integer):
        rr = sorted(integer_neighborhood[v])
        signature = tuple(sorted((rows[r], len(row_entries[r]), sum(1 for x,a in row_entries[r] if x in integer)) for r in rr))
        neighborhood_signatures[str(signature)].append(v)
    shared_continuous = sorted(((continuous_degree[v], v) for v in continuous), reverse=True)
    local_continuous = sorted(((continuous_degree[v], v) for v in continuous))
    int_bounds = collections.Counter()
    for v in integer:
        lo = lower[v]; up = upper[v]
        int_bounds[(str(lo), str(up))] += 1
    objective_classes = collections.Counter()
    for v in variables:
        kind = 'integer' if v in integer else 'continuous'
        objective_classes[(kind, q(objective[v], 8))] += 1
    report = {
        'parser_summary': {
            'objective_sense': objsense, 'row_count': len(rows), 'variable_count': len(variables),
            'integer_count': len(integer), 'continuous_count': len(continuous),
            'objective_row_names': sorted(objrows),
            'sense_histogram': histogram(rows.values()),
            'nonzero_count': sum(len(x) for x in row_entries.values()) + sum(1 for x in objective.values() if x != 0)
        },
        'row_composition': {
            'degree_histogram': histogram(x['degree'] for x in row_records),
            'integer_count_histogram': histogram(x['integer_count'] for x in row_records),
            'continuous_count_histogram': histogram(x['continuous_count'] for x in row_records),
            'sense_integer_count_histogram': histogram(x['sense'] + ':' + str(x['integer_count']) for x in row_records),
            'rhs_histogram': histogram(q(x['rhs']) for x in row_records)
        },
        'column_composition': {
            'integer_degree_histogram': histogram(integer_degree[v] for v in integer),
            'continuous_degree_histogram': histogram(continuous_degree[v] for v in continuous),
            'integer_bound_histogram': {str(k): v for k,v in int_bounds.items()},
            'most_global_continuous_variables': [{'variable':v,'row_degree':d,'objective':objective[v]} for d,v in shared_continuous[:25]],
            'most_local_continuous_variables': [{'variable':v,'row_degree':d,'objective':objective[v]} for d,v in local_continuous[:25]]
        },
        'repetition': {
            'distinct_continuous_supports': len(support_groups),
            'continuous_support_group_size_histogram': histogram(len(v) for v in support_groups.values()),
            'largest_support_groups': [{'size':len(v),'rows':v[:12]} for v in sorted(support_groups.values(), key=len, reverse=True)[:20]],
            'distinct_typed_continuous_supports': len(typed_support_groups),
            'integer_neighborhood_signature_counts': [{'count':len(v),'sample_variables':v[:12],'signature':k} for k,v in sorted(neighborhood_signatures.items(), key=lambda z:len(z[1]), reverse=True)[:20]]
        },
        'samples': {
            'variables': variables[:30],
            'integer_variables': sorted(integer)[:30],
            'rows': row_records[:30],
            'objective_classes_most_common': [{'kind':k[0],'coefficient':k[1],'count':n} for k,n in objective_classes.most_common(30)]
        }
    }
    with open('structural_analysis.json','w',encoding='utf-8') as f:
        json.dump(report, f, indent=2, sort_keys=True)
    conclusion = {
        'status': 'completed',
        'method': 'solver-independent incidence and repeated-block analysis',
        'candidate_solution_written': False,
        'key_counts': report['parser_summary'],
        'distinct_continuous_supports': report['repetition']['distinct_continuous_supports'],
        'largest_support_group_size': max((len(v) for v in support_groups.values()), default=0),
        'integer_neighborhood_signature_count': len(neighborhood_signatures),
        'recommended_next_step': 'Use structural_analysis.json to implement integer-centered block enumeration if neighborhoods are small and regular; otherwise derive a global-continuous/local-variable decomposition.'
    }
    with open('method_result.json','w',encoding='utf-8') as f:
        json.dump(conclusion, f, indent=2, sort_keys=True)

if __name__ == '__main__':
    main()
