#!/usr/bin/env python3
"""Solver-independent structural inspection of a GSVM MPS instance and public solutions."""
import argparse, gzip, json, math, os
from collections import Counter, defaultdict


def open_text(path):
    return gzip.open(path, "rt", encoding="utf-8", errors="replace") if path.endswith(".gz") else open(path, "rt", encoding="utf-8", errors="replace")


def parse_mps(path):
    section = None
    objrow = None
    rows = {}
    cols = defaultdict(dict)
    rhs = defaultdict(float)
    lo, up, vtype = {}, {}, {}
    integer_mode = False
    with open_text(path) as f:
        for raw in f:
            s = raw.strip()
            if not s or s.startswith("*"):
                continue
            p = s.split()
            head = p[0].upper()
            if head in {"NAME","ROWS","COLUMNS","RHS","RANGES","BOUNDS","ENDATA","OBJSENSE","OBJNAME"}:
                section = head
                if head == "ENDATA": break
                continue
            if section == "ROWS" and len(p) >= 2:
                typ, name = p[0].upper(), p[1]
                if typ == "N" and objrow is None: objrow = name
                else: rows[name] = typ
            elif section == "COLUMNS":
                if "MARKER" in [x.upper().strip("'\"") for x in p]:
                    q = " ".join(p).upper()
                    if "INTORG" in q: integer_mode = True
                    elif "INTEND" in q: integer_mode = False
                    continue
                var = p[0]
                if integer_mode: vtype[var] = "I"
                for j in range(1, len(p)-1, 2):
                    try: cols[var][p[j]] = cols[var].get(p[j], 0.0) + float(p[j+1])
                    except ValueError: pass
            elif section == "RHS":
                for j in range(1, len(p)-1, 2):
                    try: rhs[p[j]] = float(p[j+1])
                    except ValueError: pass
            elif section == "BOUNDS" and len(p) >= 3:
                bt, var = p[0].upper(), p[2]
                val = float(p[3]) if len(p) > 3 else 0.0
                if bt in {"LO","LI"}: lo[var] = val
                elif bt in {"UP","UI"}: up[var] = val
                elif bt == "FX": lo[var] = up[var] = val
                elif bt == "FR": lo[var], up[var] = -math.inf, math.inf
                elif bt == "MI": lo[var] = -math.inf
                elif bt == "PL": up[var] = math.inf
                elif bt == "BV": lo[var], up[var], vtype[var] = 0.0, 1.0, "I"
                if bt in {"LI","UI"}: vtype[var] = "I"
    for v in cols:
        vtype.setdefault(v, "C")
        lo.setdefault(v, 0.0)
        up.setdefault(v, math.inf)
    return objrow, rows, cols, rhs, lo, up, vtype


def finite(x): return None if math.isinf(x) else x

def parse_solution(path):
    out = {"file": os.path.basename(path), "assignments": 0, "nonzero": 0, "objective_text": None, "name_prefixes": Counter(), "value_histogram": Counter(), "sample": []}
    with open_text(path) as f:
        for raw in f:
            s = raw.strip()
            if not s: continue
            if s.startswith("#"):
                if "objective" in s.lower(): out["objective_text"] = s
                continue
            p = s.split()
            if len(p) < 2: continue
            try: val = float(p[-1])
            except ValueError: continue
            name = p[0]
            out["assignments"] += 1
            if abs(val) > 1e-12: out["nonzero"] += 1
            prefix = name.rstrip("0123456789[]_-") or name
            out["name_prefixes"][prefix] += 1
            key = str(round(val, 8)) if abs(val-round(val)) > 1e-9 else str(int(round(val)))
            out["value_histogram"][key] += 1
            if len(out["sample"]) < 30: out["sample"].append([name,val])
    out["name_prefixes"] = out["name_prefixes"].most_common(20)
    out["value_histogram"] = out["value_histogram"].most_common(20)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--solutions", nargs="*", default=[])
    a = ap.parse_args()
    objrow, rows, cols, rhs, lo, up, vt = parse_mps(a.model)
    rowvars = defaultdict(list)
    for v, terms in cols.items():
        for r,c in terms.items():
            if r != objrow: rowvars[r].append((v,c))
    obj = {v:t[objrow] for v,t in cols.items() if objrow in t and abs(t[objrow])>0}
    var_report=[]
    for v in list(cols)[:80]:
        terms=[(r,c) for r,c in cols[v].items() if r != objrow]
        var_report.append({"name":v,"type":vt[v],"lb":finite(lo[v]),"ub":finite(up[v]),"obj":obj.get(v,0.0),"degree":len(terms),"terms":terms[:8]})
    row_report=[]
    for r in list(rows)[:80]:
        ts=rowvars[r]
        row_report.append({"name":r,"sense":rows[r],"rhs":rhs.get(r,0.0),"nnz":len(ts),"terms":ts[:20]})
    degree_hist=Counter(len([r for r in t if r != objrow]) for t in cols.values())
    row_nnz_hist=Counter(len(rowvars[r]) for r in rows)
    bound_type=Counter((vt[v],finite(lo[v]),finite(up[v])) for v in cols)
    objective_by_type=defaultdict(list)
    for v,c in obj.items(): objective_by_type[vt[v]].append(c)
    report={
      "model":os.path.basename(a.model),"objective_row":objrow,
      "counts":{"rows":len(rows),"columns":len(cols),"nonzeros":sum(len(t)-(1 if objrow in t else 0) for t in cols.values()),"objective_nonzeros":len(obj)},
      "row_senses":Counter(rows.values()),"variable_types":Counter(vt.values()),
      "degree_histogram":degree_hist.most_common(),"row_nnz_histogram":row_nnz_hist.most_common(),
      "bound_patterns":[{"type":list(k),"count":n} for k,n in bound_type.most_common()],
      "objective_stats":{k:{"count":len(z),"min":min(z),"max":max(z),"sum":sum(z),"distinct":len(set(z))} for k,z in objective_by_type.items()},
      "rows_preview":row_report,"variables_preview":var_report,
      "solutions":[parse_solution(x) for x in a.solutions]
    }
    with open("structural_probe.json","w",encoding="utf-8") as f: json.dump(report,f,indent=2,sort_keys=True)
    with open("method_result.json","w",encoding="utf-8") as f: json.dump({"status":"inspection_complete","artifact":"structural_probe.json"},f)

if __name__ == "__main__": main()
