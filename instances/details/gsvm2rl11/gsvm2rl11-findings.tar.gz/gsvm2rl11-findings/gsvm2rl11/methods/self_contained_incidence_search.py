import argparse, gzip, json, math, random, time
from collections import defaultdict


def open_model(path):
    return gzip.open(path, 'rt', errors='replace') if path.endswith('.gz') else open(path, 'r', errors='replace')


def parse_mps(path):
    rows = {}
    row_order = []
    objrow = None
    cols = defaultdict(dict)
    rhs = defaultdict(float)
    lo = defaultdict(float)
    up = defaultdict(lambda: float('inf'))
    integer = set()
    section = None
    int_mode = False
    sense = 'MIN'
    with open_model(path) as f:
        for raw in f:
            s = raw.strip()
            if not s or s.startswith('*'):
                continue
            p = s.split()
            head = p[0].upper()
            if head in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE'):
                section = head
                if head == 'ENDATA':
                    break
                continue
            if section == 'OBJSENSE':
                if head.startswith('MAX'):
                    sense = 'MAX'
                elif head.startswith('MIN'):
                    sense = 'MIN'
                continue
            if section == 'ROWS':
                if len(p) >= 2:
                    typ, name = p[0].upper(), p[1]
                    if typ == 'N' and objrow is None:
                        objrow = name
                    else:
                        rows[name] = typ
                        row_order.append(name)
                continue
            if section == 'COLUMNS':
                if 'MARKER' in [q.upper().strip("'") for q in p]:
                    joined = ' '.join(p).upper()
                    if 'INTORG' in joined:
                        int_mode = True
                    elif 'INTEND' in joined:
                        int_mode = False
                    continue
                if len(p) < 3:
                    continue
                v = p[0]
                if int_mode:
                    integer.add(v)
                for k in range(1, len(p)-1, 2):
                    try:
                        cols[v][p[k]] = cols[v].get(p[k], 0.0) + float(p[k+1])
                    except ValueError:
                        pass
                continue
            if section == 'RHS':
                for k in range(1, len(p)-1, 2):
                    try:
                        rhs[p[k]] = float(p[k+1])
                    except ValueError:
                        pass
                continue
            if section == 'BOUNDS' and len(p) >= 3:
                typ, v = p[0].upper(), p[2]
                val = 0.0
                if len(p) >= 4:
                    try: val = float(p[3])
                    except ValueError: val = 0.0
                if typ == 'BV':
                    integer.add(v); lo[v] = 0.0; up[v] = 1.0
                elif typ in ('LI','UI'):
                    integer.add(v)
                    if typ == 'LI': lo[v] = val
                    else: up[v] = val
                elif typ == 'LO': lo[v] = val
                elif typ == 'UP': up[v] = val
                elif typ == 'FX': lo[v] = val; up[v] = val
                elif typ == 'FR': lo[v] = -float('inf'); up[v] = float('inf')
                elif typ == 'MI': lo[v] = -float('inf')
                elif typ == 'PL': up[v] = float('inf')
    names = list(cols.keys())
    obj = {v: cols[v].get(objrow, 0.0) for v in names}
    matrix = {r: [] for r in row_order}
    for v in names:
        for r, a in cols[v].items():
            if r in rows and a != 0.0:
                matrix[r].append((v, a))
    return names, rows, row_order, matrix, rhs, lo, up, integer, obj, sense


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--search-seconds', type=float, default=900.0)
    ap.add_argument('--seed', type=int, default=11711)
    args = ap.parse_args()
    start = time.time()
    rng = random.Random(args.seed)
    names, rtype, row_names, matrix, rhs, lo, up, ints, obj, sense = parse_mps(args.model)
    finite_binary = []
    unsupported = []
    for v in names:
        lv, uv = lo[v], up[v]
        if v in ints and lv >= -1e-12 and uv <= 1.0 + 1e-12:
            finite_binary.append(v)
        elif abs(uv-lv) <= 1e-12 and math.isfinite(lv):
            pass
        else:
            unsupported.append(v)
    report = {
        'variables': len(names), 'rows': len(row_names), 'integer_variables': len(ints),
        'binary_search_variables': len(finite_binary), 'unsupported_nonfixed_variables': len(unsupported),
        'objective_sense': sense, 'seed': args.seed
    }
    # This method is intentionally restricted to pure binary incidence models.
    if unsupported:
        report['status'] = 'unsupported_mixed_domain'
        report['sample_unsupported'] = unsupported[:20]
        with open('incidence_search_report.json','w') as f: json.dump(report,f,indent=2)
        with open('method_result.json','w') as f:
            json.dump({'status':'unsupported','reason':'nonfixed nonbinary variables are present','report':'incidence_search_report.json'},f,indent=2)
        return
    idx = {v:i for i,v in enumerate(names)}
    n = len(names)
    x = [0.0]*n
    movable = []
    for v in names:
        i = idx[v]
        if v in finite_binary:
            x[i] = 1.0 if lo[v] > 0.5 else 0.0
            if up[v]-lo[v] > 0.5: movable.append(i)
        else:
            x[i] = lo[v]
    ridx = {r:i for i,r in enumerate(row_names)}
    row_terms = [[] for _ in row_names]
    incidence = [[] for _ in names]
    scale = [1.0]*len(row_names)
    for r in row_names:
        j = ridx[r]
        sm = 0.0
        for v,a in matrix[r]:
            i=idx[v]; row_terms[j].append((i,a)); incidence[i].append((j,a)); sm += abs(a)
        scale[j] = max(1.0, abs(rhs[r]), sm/max(1,len(row_terms[j])))
    activity = [sum(a*x[i] for i,a in terms) for terms in row_terms]
    def violation(j, act=None):
        a = activity[j] if act is None else act
        b = rhs[row_names[j]]
        t = rtype[row_names[j]]
        if t == 'L': return max(0.0, a-b)/scale[j]
        if t == 'G': return max(0.0, b-a)/scale[j]
        if t == 'E': return abs(a-b)/scale[j]
        return 0.0
    weights = [1.0]*len(row_names)
    def total_violation(): return sum(violation(j) for j in range(len(row_names)))
    objsign = 1.0 if sense == 'MIN' else -1.0
    def objective(): return sum(obj.get(v,0.0)*x[idx[v]] for v in names)
    best_x = None
    best_obj = float('inf')
    best_viol = total_violation()
    iterations = 0
    feasible_hits = 0
    deadline = start + max(1.0,args.search_seconds)
    # Adaptive min-conflicts: prioritize variables occurring in violated rows, with random restarts.
    while time.time() < deadline:
        iterations += 1
        violated = [j for j in range(len(row_names)) if violation(j) > 1e-9]
        tv = sum(violation(j) for j in violated)
        if not violated:
            feasible_hits += 1
            z = objsign*objective()
            if z < best_obj - 1e-8:
                best_obj = z; best_x = x[:]
            # Feasibility-preserving objective descent, including occasional two-flip perturbations.
            cand = rng.sample(movable, min(len(movable), 256)) if movable else []
        else:
            chosen_rows = rng.sample(violated, min(len(violated), 32))
            pool = set()
            for j in chosen_rows:
                for i,a in row_terms[j]:
                    if i in movable: pool.add(i)
            if not pool:
                break
            cand = list(pool)
            if len(cand)>512: cand=rng.sample(cand,512)
        current_pen = sum(weights[j]*violation(j) for j in range(len(row_names)))
        best_delta = float('inf'); choices=[]
        for i in cand:
            d = 1.0-2.0*x[i]
            pen_delta=0.0
            feasible_after=True
            for j,a in incidence[i]:
                oldv=violation(j); newv=violation(j,activity[j]+a*d)
                pen_delta += weights[j]*(newv-oldv)
                if newv>1e-9: feasible_after=False
            od = objsign*obj.get(names[i],0.0)*d
            if violated:
                score = pen_delta + 1e-8*od
            else:
                score = od if feasible_after else 1e6 + pen_delta
            score += rng.random()*1e-10
            if score < best_delta-1e-12:
                best_delta=score; choices=[i]
            elif abs(score-best_delta)<=1e-12:
                choices.append(i)
        if not choices:
            break
        i=rng.choice(choices); d=1.0-2.0*x[i]; x[i]=1.0-x[i]
        for j,a in incidence[i]: activity[j]+=a*d
        if violated and iterations%250==0:
            for j in violated: weights[j]=min(1e6,weights[j]*1.08+0.01)
        # Diversify after stagnation while retaining bound-valid binary values.
        if iterations%5000==0 and best_x is not None:
            x=best_x[:]
            for j in range(len(row_names)):
                activity[j]=sum(a*x[i] for i,a in row_terms[j])
            for i in rng.sample(movable,min(3,len(movable))):
                d=1.0-2.0*x[i]; x[i]=1.0-x[i]
                for j,a in incidence[i]: activity[j]+=a*d
        best_viol=min(best_viol,tv)
    elapsed=time.time()-start
    report.update({'status':'completed','iterations':iterations,'feasible_hits':feasible_hits,
                   'smallest_normalized_violation_seen':best_viol,'elapsed_seconds':elapsed})
    if best_x is not None:
        raw_obj=sum(obj.get(v,0.0)*best_x[idx[v]] for v in names)
        report['candidate_objective']=raw_obj
        with open('best.sol','w') as f:
            f.write('# Objective value = %.17g\n'%raw_obj)
            for v in names:
                val=best_x[idx[v]]
                if abs(val)>1e-14: f.write('%s %.17g\n'%(v,val))
        result={'status':'candidate_found','objective':raw_obj,'solution':'best.sol',
                'claim':'Candidate only; feasibility and objective require independent exact checking.'}
    else:
        result={'status':'no_candidate','smallest_normalized_violation_seen':best_viol,
                'claim':'No infeasibility conclusion is made.'}
    with open('incidence_search_report.json','w') as f: json.dump(report,f,indent=2)
    with open('method_result.json','w') as f: json.dump(result,f,indent=2)

if __name__=='__main__': main()
