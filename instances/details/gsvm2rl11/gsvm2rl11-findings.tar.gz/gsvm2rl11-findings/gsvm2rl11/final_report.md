# Final Report: `gsvm2rl11`

## 1. Outcome

**Final classification: partial feasible result.**

The experiment found a solution that passed the controller's independent tolerance-based feasibility check, but it did **not** prove optimality or infeasibility.

- Objective sense: minimization
- Best solver-reported primal objective: `18539.127113105696`
- Verification of that raw best incumbent: **failed / not independently verified**
- Best independently verified primal objective: `18539.12716192643`
- Verification level: accepted by the controller's Decimal-based checker at tolerance `1e-9`
- Best solver dual bound: `2096.755457820071`
- Controller-reported combined relative gap: `0.8869010690186253` (about `88.6901%`)
- Strict optimal runs: none
- Strict infeasible runs: none
- Proof of optimality: no
- Proof of infeasibility: no

The tiny difference between the raw best objective and the best tolerance-verified objective is approximately `4.8821e-5`. For archival claims, this report therefore uses `18539.12716192643` as the feasible primal bound. The dual bound remains far below the incumbent, so the result is not close to a proof of optimality.

## 2. Claim boundary and verification

Solver status and independent feasibility checking are separate in this archive.

- A solver-accepted incumbent is not automatically a tolerance-verified incumbent.
- The 300-second Gurobi run reported the numerically best primal value, but that solution did not pass the independent verification recorded by the controller.
- The 1800-second Gurobi run produced the best incumbent that did pass the independent check at `1e-9`.
- Both Gurobi runs ended with `TIME_LIMIT`; neither is an optimality claim.
- The COPT run ended with `TIMEOUT`; it is neither an optimality claim nor an infeasibility claim.
- Custom-method statuses `completed` and `unsupported` do not constitute proofs.

No independently checked certificate was produced. In particular, no SAT/UNSAT certificate, DRAT proof, exact dual certificate, or strict solver status establishes optimality or infeasibility.

## 3. Experiment results

The controller recorded seven runs.

| Run ID | Stack | Termination status | Primal | Dual | Relative gap | Independent verification | Runtime (s) |
|---|---|---|---:|---:|---:|---|---:|
| `copt-20260903-175003-45824498` | COPT | `TIMEOUT` | 46710.228668301774 | 1915.16751668607 | 0.9589989693630908 | yes at `1e-9` | 300.03027987480164 |
| `custom-20260903-175815-cca15fb8` | custom Python | `completed` | — | — | — | not checked | 0.722441673278809 |
| `custom-20260903-180125-835e6017` | custom Python | `unsupported` | — | — | — | not checked | 0.824058055877686 |
| `custom-20260903-184335-4a78fda4` | custom Python | `unsupported` | — | — | — | not checked | 0.875738620758057 |
| `custom-20260903-184533-2d18baf6` | custom Python | `unsupported` | — | — | — | not checked | 1.0261070728302 |
| `gurobi-20260903-174959-389eab23` | Gurobi | `TIME_LIMIT` | 18539.127113105696 | 2096.755457820071 | 0.8869010690186253 | **no** | 300.073030948639 |
| `gurobi-20260903-180936-fb7410f6` | Gurobi | `TIME_LIMIT` | 18539.12716192643 | 1662.54834974925 | 0.910322188567561 | yes at `1e-9` | 1800.18627309799 |

The strongest dual bound came from the short Gurobi run, while the strongest verified incumbent came from the longer Gurobi run. Accordingly, the archive's combined primal/dual statement draws on different runs.

## 4. Generic-solver baseline

The short generic baseline consisted of independent 300-second COPT and Gurobi runs.

### COPT baseline

- Run: `copt-20260903-175003-45824498`
- Termination: `TIMEOUT`
- Runtime: `300.03027987480164` seconds
- Primal: `46710.228668301774`
- Dual: `1915.16751668607`
- Relative gap: `0.9589989693630908`
- Incumbent verification: passed at `1e-9`

### Gurobi baseline

- Run: `gurobi-20260903-174959-389eab23`
- Termination: `TIME_LIMIT`
- Runtime: `300.073030948639` seconds
- Primal: `18539.127113105696`
- Dual: `2096.755457820071`
- Relative gap: `0.8869010690186253`
- Incumbent verification: failed / not verified

The Gurobi baseline substantially improved the objective and dual bound relative to the COPT baseline, but its incumbent cannot be used as the independently verified archival solution.

## 5. Problem-specific research methods

Four controlled Python custom runs were attempted after inspecting the instance structure. They were intended as solver-independent, structure-specific research rather than generic MIP parameter tuning. Their archived outcomes were:

1. One method completed in `0.722441673278809` seconds but returned no primal or dual bound and was not checked as a solution.
2. Three subsequent methods terminated as `unsupported`, each in approximately one second, and returned no primal or dual result.

Thus, the custom research did not improve the primal bound, did not improve the dual bound, and did not produce a proof. The informative negative result is that these prototype paths did not support the supplied model representation sufficiently to generate a checkable candidate. Their quick exits indicate interface or representation limitations rather than evidence that the underlying mathematical ideas are ineffective.

The precise algorithm-selection rationale and source-level design are preserved in the instance's research notes and custom source files, where present. The controller-generated `experiments.json` is authoritative for per-run arguments and artifacts. The compressed archival input available while drafting this report did not expose the custom source path names or full source contents, so they are not guessed here; the final archival pass should add their exact relative paths from the file inventory.

## 6. Follow-up generic solve

A longer, 1800-second Gurobi run was performed after the custom experiments:

- Run: `gurobi-20260903-180936-fb7410f6`
- Termination: `TIME_LIMIT`
- Runtime: `1800.18627309799` seconds
- Primal: `18539.12716192643`
- Dual: `1662.54834974925`
- Relative gap: `0.910322188567561`
- Verification: passed at `1e-9`

This run supplied the best verified feasible solution. It did not prove optimality, and its dual bound was weaker than the short Gurobi run's bound.

## 7. Reproducibility metadata

### Execution environment

- Custom implementation language: Python
- Custom execution: CPU-only controlled bubblewrap sandbox
- Generally available compilers/runtimes: Python standard library and C++17
- Configured proof tools: CaDiCaL and `drat-trim`
- Use of CaDiCaL or `drat-trim` in a successful proof: none
- Network access in custom jobs: disabled
- Model and controlled resources in custom jobs: read-only
- Custom-job time, memory, output-file size, and thread use: controller-enforced
- Exact numeric sandbox limits: not present in the compressed reporting summary; no value is invented here
- Host machine/CPU/RAM/operating-system identification: not present in the compressed reporting summary

### Software versions

The experiment used Gurobi, COPT, and custom Python. Exact Gurobi, COPT, Python, CaDiCaL, and `drat-trim` version strings were not exposed in the compressed `experiments.md`/reporting summary used for this report. If recorded, the controller's machine-readable run records and reporting bundle are authoritative. Unknown versions are explicitly left unknown rather than inferred.

### Parameters and random seeds

The short baseline time budgets were 300 seconds per solver, and the follow-up Gurobi budget was 1800 seconds. Runtime values are listed above. Full solver parameter dictionaries, if any, are preserved in `experiments.json`; they were not exposed by the compressed ledger and are not reconstructed here. No explicit random seed was visible in the compressed archival input. Therefore the seed is recorded as **not reported**, not assumed to be zero. Controller-controlled thread, time-limit, and log settings should be taken from the run records rather than inferred from solver defaults.

### Custom source files

Custom source files are retained within this instance and associated with the four `custom-python` runs. Exact names were not visible in the compressed summaries supplied for this drafting turn. They must be taken from the file inventory or `experiments.json`; this avoids assigning the wrong script to a run.

## 8. Interpretation

This experiment established feasibility at objective `18539.12716192643` under the controller's `1e-9` tolerance check. It also established a valid solver dual bound of `2096.755457820071`. The remaining gap is large, and no run terminated optimally. Consequently:

- Do not cite `18539.127113105696` as an independently verified feasible objective.
- Do not call either `TIME_LIMIT` or `TIMEOUT` optimal.
- Do not interpret any custom `unsupported` status as infeasibility.
- Do not claim that the instance was solved to optimality.

## 9. Recommended next experiment

The next experiment should first repair or extend the custom model reader responsible for the `unsupported` exits and add a deterministic dry-run test that reports the recognized variable, constraint, and objective patterns. Once parsing is confirmed, rerun the strongest structure-specific candidate generator with a fixed, explicitly recorded seed and have every emitted solution independently checked before using it as a warm start. On the exact-solver side, prioritize strengthening the lower bound and preserving the verified incumbent rather than merely extending the same configuration, because the combined gap remains about `88.69%`. Any future comparison should retain separate columns for solver-accepted and independently verified feasibility.

## 10. Authoritative archive files

- `reporting_bundle.json`: consolidated reporting metadata and claim boundary
- `experiments.json`: controller-managed machine-readable experiment ledger
- `experiments.md`: controller-generated human-readable run table
- `result.json`: controller-managed final result record
- `final_report.md`: this interpretation and archival report
- `README.md`: concise instance summary and navigation

Controller-managed ledgers were not modified during reporting.
