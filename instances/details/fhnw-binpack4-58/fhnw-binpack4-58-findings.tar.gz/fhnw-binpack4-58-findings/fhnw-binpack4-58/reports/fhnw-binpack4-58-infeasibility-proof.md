# `fhnw-binpack4-58` infeasibility proof

## Conclusion

`fhnw-binpack4-58.mps.gz` **infeasible**. Proof uses only the previous 30 large object and its 435 to two non-overlapping constraints, does not rely on the later 20 object, nor does it rely on the search results of a floating-point solver.

The certificate checker verifies each variable type, boundary, line direction, right end and coefficient used by the proof in the original MPS, and then verifies a strict two-dimensional projection area paradox:

```text
verified_large_items=30
verified_large_item_pairs=435
x_separation_impossible: max_coordinate_difference=150 < min_item_length=210
yz_projection: pairwise_disjoint=true minimum_required_area=63000 container_area=56000 excess=7000
CERTIFICATE VERIFIED: fhnw-binpack4-58 is infeasible
```

SHA-256 of the original compression file is as follows:

```text
8A6F2581D61E56C38DDAA2FE625E2DF1A67871E6D39DC661A148D07994BBEAE3
```

##  Model structure

The Gurobi 13.0.1 original model readings are as follows:

-  9900 line, 7550 column, 35750 nonzero entries;
-  7400 is a binary variable, 150 is a continuous variable;
-  The objective function is always 0, so this is a pure feasibility problem.
-  50 long squares, each 3 continuous coordinate, two-dimensional variables for each object 6;
-  `50 choose 2 = 1225` has a constraint line for each object, 8.

The public page of MIPLIB still lists the instance as `open`, `no_solution`, which is described as the 3 D container feasibility problem with the additional constraint:< https://miplib.zib.de/instance_details_fhnw-binpack4-58.html>.

A variable map of the previous 30 object is as follows, where `i=0,...,29`:

|  Meaning |  MPS variable |
|---|---|
| It's not the same as the `b_i`. |  `C_i`  |
| X coordinates `x_i` |  `C_(50+i)`  |
| z Coordinates `z_i` |  `C_(100+i)`  |
| and coordinates `y_i` |  `C_(150+i)`  |

`b_i` is binary. The MPS bounds and rows `2i,2i+1` imply

```text
0 <= x_i <= 150,   x_i - 20 b_i <= 130,
0 <= y_i <= 350,   y_i + 20 b_i <= 350,
0 <= z_i <= 90.
```

Therefore, the large object of `i` can be placed in the `360 × 560 × 100` container in the lower left corner as the long square of `(x_i,y_i,z_i)`.

```text
w_i = 230 - 20 b_i,
d_i = 210 + 20 b_i,
h_i = 10.
```

The plane size rotates between `230×210` and `210×230`.

## infeasibility proof

###  1. It is impossible for any two large objects to be separated along the x direction.

For any `0 <= i < j < 30`, the six-direction mapping of MPS contains two x directions:

```text
x_j - x_i >= 230 - 20 b_i = w_i,
```

or

```text
x_i - x_j >= 230 - 20 b_j = w_j.
```

However, `b_i,b_j` is a binary variable, so `w_i,w_j >= 210`; on the other hand, `x_i,x_j` is all in `[0,150]`, with the maximum arbitrary coordinate difference being 150. So both x directions cannot be established, and the strict residual is at least `210-150=60`.

###  2. Yz projection of all large objects

The two-way variable for each pair of objects is 0 / 1, and their MPS constraint does not exceed 5, so at least one direction must be activated.

So every big object is a projection on the yz plane.

```text
[y_i, y_i + d_i] × [z_i, z_i + 10]
```

All of these projections are located within the container intersection of `560×100`, and the two projections do not intersect internally.

###  3 . projection Area of Contradiction

Each projection has an area of at least

```text
d_i × 10 >= 210 × 10 = 2100.
```

30 A two-by-two non-overlapping projection requires a total area of at least

```text
30 × 2100 = 63000.
```

The area of the container yz at the intersection is only

```text
560 × 100 = 56000.
```

So there has to be a `63000 <= 56000`, contradicted by 7000.

##  Solver cross-checking

The general MIP search itself did not identify any of the above global projection area contradictions in a short time:

| Solver / machine |  Time limit | Presolve after-scale | Search results |
|---|---:|---:|---|
|  Gurobi 13.0.1 / euler4  | 60 seconds | 7253 rows, 6080 columns, 27846 nonzero entries | 96552 node, no feasible solution, timeout |
|  COPT 8.0.4 / altman  | 60 seconds | 7253 rows, 6080 columns, 27846 nonzero entries | No feasible solution, timeout |

These two operations are used only to independently verify model readings, presolve structures, and general search performance; ultimately, infeasible conclusions are derived from the exact geometric proof above.

##  Verification command

Check the original input of the compressed:

```powershell
python .\test\fhnw_binpack_infeasibility_certificate.py .\test\fhnw-binpack4-58.mps.gz
```

Check the solution after pressing input:

```powershell
python .\test\fhnw_binpack_infeasibility_certificate.py .\test\fhnw-binpack4-58.mps
```

The certificate checker uses only the Python standard library and does not require Gurobi or COPT.
