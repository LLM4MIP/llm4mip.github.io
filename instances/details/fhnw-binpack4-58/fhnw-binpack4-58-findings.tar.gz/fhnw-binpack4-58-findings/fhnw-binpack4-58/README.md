# `fhnw-binpack4-58`

## Result

The original MPS is **infeasible**. The certificate uses only the first 30 large boxes and their pairwise non-overlap constraints:

1. No pair can be separated along the x-axis because every box needs at least 210 units while the maximum coordinate difference is 150.
2. Their yz projections must therefore be pairwise disjoint.
3. They require area at least `30 × 210 × 10 = 63,000`, but the yz cross-section has area only `560 × 100 = 56,000`.

The resulting contradiction is exact and independent of Gurobi/COPT search.

## Input

- SHA-256: `8A6F2581D61E56C38DDAA2FE625E2DF1A67871E6D39DC661A148D07994BBEAE3`
- MIPLIB metadata: [instance page](https://miplib.zib.de/instance_details_fhnw-binpack4-58.html)

## Reproduce the certificate

```powershell
python .\instances\fhnw-binpack4-58\scripts\fhnw_binpack_infeasibility_certificate.py `
  .\instances\fhnw-binpack4-58\input\fhnw-binpack4-58.mps.gz
```

Expected final line: `CERTIFICATE VERIFIED: fhnw-binpack4-58 is infeasible`.

See the [full proof](reports/fhnw-binpack4-58-infeasibility-proof.md) and raw [Gurobi](logs/fhnw-binpack4-58-gurobi-baseline.log)/[COPT](logs/fhnw-binpack4-58-copt-baseline.log) baselines.
