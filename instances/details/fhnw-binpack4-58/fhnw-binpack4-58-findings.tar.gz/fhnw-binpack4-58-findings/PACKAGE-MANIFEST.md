# Package manifest: fhnw-binpack4-58

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 6
Excluded source files: 1

## Included files

- `README.md`
- `logs/fhnw-binpack4-58-copt-baseline.log`
- `logs/fhnw-binpack4-58-gurobi-baseline.log`
- `reports/fhnw-binpack4-58-infeasibility-proof.md`
- `scripts/fhnw_binpack_infeasibility_certificate.py`
- `scripts/fhnw_binpack_structure.py`

## Excluded files

- `input/fhnw-binpack4-58.mps.gz (195326 bytes; raw benchmark input; sha256 8a6f2581d61e56c38ddaa2fe625e2df1a67871e6d39dc661a148d07994bbeae3)`
