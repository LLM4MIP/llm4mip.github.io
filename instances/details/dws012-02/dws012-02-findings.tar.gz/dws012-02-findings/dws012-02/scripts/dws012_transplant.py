#!/usr/bin/env python3
"""
dws012-02 sibling-design transplant and bounded Hamming-2 search.

The only optimization performed is on the ORIGINAL dws012-02 MPS, with
selected design variables fixed. The sibling MPS is used only for read-only
structural verification and extraction of its official design pattern.

Design positions are defined structurally as the ordered list of all
objective-nonzero integer variables, not by variable names or assumed raw
column numbers.

Example:
    python dws012_transplant.py \
        --target-mps dws012-02.mps.gz \
        --target-sol dws012-02.sol.gz \
        --sibling-mps dws012-01.mps.gz \
        --sibling-sol dws012-01.sol.gz \
        --out-dir artifacts/dws012_transplant \
        --total-time-limit 1800 \
        --per-solve-limit 120 \
        --max-hamming2 100

The output directory contains:
    audit.json
    best.sol
    candidate_*.json

No candidate is declared globally valid until best.sol is independently
rechecked against the original target MPS.
"""

import argparse
import collections
import gzip
import itertools
import json
import math
import os
import time

import gurobipy as gp


# ---------------------------------------------------------------------------
# Input and validation utilities
# ---------------------------------------------------------------------------

def open_text(path):
    return gzip.open(path, "rt", errors="replace") if path.endswith(".gz") \
        else open(path, "rt", errors="replace")


def read_sol(path):
    values = {}
    with open_text(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("<") or line.startswith(">"):
                continue

            fields = line.split()
            if len(fields) < 2:
                continue

            try:
                value = float(fields[1])
            except Exception:
                continue

            name = fields[0]
            if name.lower() in {
                "objective", "objective_value", "status",
                "solution", "solution_status", "solstatus"
            }:
                continue

            values[name] = value

    return values


def load_model(path):
    model = gp.read(path)
    model.update()
    return model


def objective_integer_design(model):
    """
    Structural design-variable identification.

    A design variable must:
      * have nonzero objective coefficient;
      * be integer or binary.

    The returned order is the model's actual column order restricted to this
    structurally identified set.
    """
    result = []
    for v in model.getVars():
        if abs(float(v.Obj)) > 0.0 and v.VType in ("B", "I"):
            result.append(v)
    return result


def descriptor(v):
    return {
        "type": str(v.VType),
        "lb": float(v.LB),
        "ub": float(v.UB),
        "obj": float(v.Obj),
    }


def descriptor_equal(a, b, abs_tol=1e-8, rel_tol=1e-10):
    if a["type"] != b["type"]:
        return False

    for key in ("lb", "ub", "obj"):
        x = a[key]
        y = b[key]
        if abs(x - y) > abs_tol + rel_tol * max(1.0, abs(x), abs(y)):
            return False

    return True


def solution_vector(model, sol):
    x = [0.0] * model.NumVars
    recognized = 0

    for v in model.getVars():
        if v.VarName in sol:
            x[v.index] = sol[v.VarName]
            recognized += 1

    return x, recognized


def selected_positions(design_vars, x, threshold=0.5):
    return [
        p for p, v in enumerate(design_vars)
        if x[v.index] >= threshold
    ]


def design_pattern(design_vars, x):
    return tuple(
        1 if x[v.index] >= 0.5 else 0
        for v in design_vars
    )


def objective_value(model, x):
    return sum(float(v.Obj) * x[v.index] for v in model.getVars())


def validate_vector(model, x, tolerance=1e-6):
    max_int = 0.0
    max_bound = 0.0
    max_row = 0.0
    bad_rows = []

    for v in model.getVars():
        xv = x[v.index]

        if v.VType in ("B", "I"):
            max_int = max(max_int, abs(xv - round(xv)))

        max_bound = max(max_bound, max(float(v.LB) - xv, 0.0))
        max_bound = max(max_bound, xv - float(v.UB), 0.0)

    for i, con in enumerate(model.getConstrs()):
        expr = model.getRow(con)
        activity = 0.0

        for k in range(expr.size()):
            v = expr.getVar(k)
            activity += float(expr.getCoeff(k)) * x[v.index]

        residual = activity - float(con.RHS)

        if con.Sense == "=":
            violation = abs(residual)
        elif con.Sense == "<":
            violation = max(residual, 0.0)
        else:
            violation = max(-residual, 0.0)

        max_row = max(max_row, violation)

        if violation > tolerance and len(bad_rows) < 20:
            bad_rows.append({
                "row": con.ConstrName,
                "sense": con.Sense,
                "rhs": float(con.RHS),
                "activity": activity,
                "violation": violation,
            })

    return {
        "objective": objective_value(model, x),
        "max_integrality_violation": max_int,
        "max_bound_violation": max_bound,
        "max_row_violation": max_row,
        "accepted_at_tolerance": (
            max_int <= tolerance and
            max_bound <= tolerance and
            max_row <= tolerance
        ),
        "bad_row_examples": bad_rows,
    }


def write_solution(path, model, x):
    """
    Write a simple Gurobi-compatible name/value solution file.

    This avoids relying on model.write() having a current incumbent after
    restoring bounds.
    """
    with open(path, "w") as f:
        f.write("# dws012-02 research solution\n")
        for v in model.getVars():
            value = x[v.index]
            if abs(value) > 1e-12:
                f.write("{} {:.17g}\n".format(v.VarName, value))


# ---------------------------------------------------------------------------
# Design mapping and candidate construction
# ---------------------------------------------------------------------------

def verify_design_mapping(target_design, sibling_design):
    if len(target_design) != 264 or len(sibling_design) != 264:
        raise RuntimeError(
            "Expected exactly 264 objective-supported integer variables in "
            "each instance; got target={} sibling={}".format(
                len(target_design), len(sibling_design)
            )
        )

    mismatches = []

    for p, (a, b) in enumerate(zip(target_design, sibling_design)):
        da = descriptor(a)
        db = descriptor(b)

        if not descriptor_equal(da, db):
            mismatches.append({
                "position": p + 1,
                "target_name": a.VarName,
                "sibling_name": b.VarName,
                "target": da,
                "sibling": db,
            })

    return {
        "verified": len(mismatches) == 0,
        "count": len(target_design),
        "mismatch_count": len(mismatches),
        "mismatch_examples": mismatches[:30],
        "target_names_sample": [
            v.VarName for v in target_design[:20]
        ],
        "sibling_names_sample": [
            v.VarName for v in sibling_design[:20]
        ],
    }


def sibling_pattern(target_design, sibling_design, sibling_x):
    pattern = []
    for v in sibling_design:
        value = sibling_x[v.index]

        if v.VType == "B":
            bit = 1 if value >= 0.5 else 0
        else:
            # The stated cross-instance mapping is expected to be binary.
            # Refuse a non-binary sibling design rather than silently rounding.
            if abs(value - round(value)) > 1e-6:
                raise RuntimeError(
                    "Sibling design position {} is not integral: {}".format(
                        len(pattern) + 1, value
                    )
                )
            bit = int(round(value))

        if bit < math.ceil(v.LB - 1e-8) or bit > math.floor(v.UB + 1e-8):
            raise RuntimeError(
                "Sibling design value violates mapped bounds at position {}"
                .format(len(pattern) + 1)
            )

        pattern.append(bit)

    return tuple(pattern)


def hamming2_patterns(base, max_count, seed_patterns=()):
    """
    Generate cardinality-preserving Hamming-2 exchanges first:
       one selected position 1 -> 0
       one unselected position 0 -> 1

    These are the most relevant alternatives when the incumbent has a fixed
    number of selected design units. The exact sibling pattern is handled
    separately and can also be included as a Hamming-2 pattern if applicable.
    """
    n = len(base)
    ones = [i for i, z in enumerate(base) if z == 1]
    zeros = [i for i, z in enumerate(base) if z == 0]

    seen = set(seed_patterns)
    generated = []

    for off in ones:
        for on in zeros:
            q = list(base)
            q[off] = 0
            q[on] = 1
            q = tuple(q)

            if q in seen:
                continue

            seen.add(q)
            generated.append((q, [off, on]))

            if len(generated) >= max_count:
                return generated

    return generated


def design_differences(base, candidate):
    return [
        {
            "position": p + 1,
            "official_value": int(base[p]),
            "candidate_value": int(candidate[p]),
        }
        for p in range(len(base))
        if base[p] != candidate[p]
    ]


# ---------------------------------------------------------------------------
# Fixed-design target solves
# ---------------------------------------------------------------------------

def solve_fixed_design(model, target_design, incumbent_x, pattern,
                       label, time_limit):
    """
    Solve the full target model with exactly the design pattern fixed.

    All non-design variables retain the full original model, including all
    pump extended-formulation and hydraulic coupling rows.
    """
    old_bounds = [(v, float(v.LB), float(v.UB)) for v in target_design]

    try:
        for p, v in enumerate(target_design):
            value = float(pattern[p])
            v.LB = value
            v.UB = value

        # Warm-start the full model from the official target incumbent,
        # replacing only the fixed design values.
        for v in model.getVars():
            v.Start = float(incumbent_x[v.index])

        for p, v in enumerate(target_design):
            v.Start = float(pattern[p])

        model.update()
        model.Params.OutputFlag = 0
        model.Params.TimeLimit = max(0.0, float(time_limit))
        model.Params.SolutionLimit = 1

        started = time.monotonic()
        model.optimize()
        elapsed = time.monotonic() - started

        status_names = {
            gp.GRB.OPTIMAL: "optimal",
            gp.GRB.TIME_LIMIT: "time_limit",
            gp.GRB.INFEASIBLE: "infeasible",
            gp.GRB.INF_OR_UNBD: "inf_or_unbd",
            gp.GRB.SUBOPTIMAL: "suboptimal",
            gp.GRB.INTERRUPTED: "interrupted",
        }

        result = {
            "label": label,
            "status_code": int(model.Status),
            "status": status_names.get(model.Status, "other"),
            "runtime": elapsed,
            "solution_count": int(model.SolCount),
            "objective": None,
            "bound": None,
            "mip_gap": None,
            "vector": None,
        }

        if model.SolCount > 0:
            x = [float(v.X) for v in model.getVars()]
            result["objective"] = objective_value(model, x)
            result["vector"] = x

        try:
            result["bound"] = float(model.ObjBound)
        except Exception:
            result["bound"] = None

        try:
            if model.MIPGap < 1e100:
                result["mip_gap"] = float(model.MIPGap)
        except Exception:
            result["mip_gap"] = None

        return result

    finally:
        for v, lb, ub in old_bounds:
            v.LB = lb
            v.UB = ub

        model.update()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--target-mps", required=True)
    ap.add_argument("--target-sol", required=True)
    ap.add_argument("--sibling-mps", required=True)
    ap.add_argument("--sibling-sol", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--total-time-limit", type=float, default=1800.0)
    ap.add_argument("--per-solve-limit", type=float, default=120.0)
    ap.add_argument("--max-hamming2", type=int, default=100)
    ap.add_argument("--tolerance", type=float, default=1e-6)
    args = ap.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)

    target = load_model(args.target_mps)
    sibling = load_model(args.sibling_mps)

    target_design = objective_integer_design(target)
    sibling_design = objective_integer_design(sibling)

    mapping = verify_design_mapping(target_design, sibling_design)
    if not mapping["verified"]:
        raise RuntimeError(
            "Refusing to transplant: positional design descriptors do not "
            "match. See mismatch details."
        )

    target_sol = read_sol(args.target_sol)
    sibling_sol = read_sol(args.sibling_sol)

    target_x, target_recognized = solution_vector(target, target_sol)
    sibling_x, sibling_recognized = solution_vector(sibling, sibling_sol)

    official_audit = validate_vector(
        target, target_x, args.tolerance
    )

    if not official_audit["accepted_at_tolerance"]:
        raise RuntimeError(
            "Official target solution failed raw-MPS validation; refusing "
            "to use it as a warm start."
        )

    target_base = design_pattern(target_design, target_x)
    sibling_design_pattern = sibling_pattern(
        target_design, sibling_design, sibling_x
    )

    # Candidate order is intentional:
    #   1. exact cross-instance transplant;
    #   2. incumbent-preserving Hamming-2 exchanges.
    candidates = []
    candidates.append({
        "label": "exact_sibling_design",
        "pattern": sibling_design_pattern,
        "kind": "sibling_transplant",
    })

    h2 = hamming2_patterns(
        target_base,
        args.max_hamming2,
        seed_patterns={sibling_design_pattern},
    )

    for k, (pattern, flips) in enumerate(h2, 1):
        candidates.append({
            "label": "hamming2_{:04d}".format(k),
            "pattern": pattern,
            "kind": "hamming_2_exchange",
            "flip_positions_zero_based": flips,
        })

    # Preserve official incumbent as current best.
    best_x = list(target_x)
    best_audit = official_audit
    best_label = "official_incumbent"
    best_pattern = target_base

    results = []
    total_started = time.monotonic()

    for candidate in candidates:
        elapsed_total = time.monotonic() - total_started
        remaining = args.total_time_limit - elapsed_total

        if remaining <= 0.0:
            results.append({
                "label": candidate["label"],
                "kind": candidate["kind"],
                "status": "not_run_total_budget_exhausted",
                "design_positions": [
                    p + 1 for p, z in enumerate(candidate["pattern"]) if z
                ],
                "differences_from_official": design_differences(
                    target_base, candidate["pattern"]
                ),
            })
            continue

        limit = min(args.per_solve_limit, remaining)

        result = solve_fixed_design(
            target,
            target_design,
            target_x,
            candidate["pattern"],
            candidate["label"],
            limit,
        )

        record = {
            "label": candidate["label"],
            "kind": candidate["kind"],
            "status": result["status"],
            "status_code": result["status_code"],
            "runtime": result["runtime"],
            "solution_count": result["solution_count"],
            "objective": result["objective"],
            "bound": result["bound"],
            "mip_gap": result["mip_gap"],
            "design_positions": [
                p + 1 for p, z in enumerate(candidate["pattern"]) if z
            ],
            "differences_from_official": design_differences(
                target_base, candidate["pattern"]
            ),
        }

        if result["vector"] is not None:
            candidate_audit = validate_vector(
                target, result["vector"], args.tolerance
            )
            record["validation"] = {
                k: v for k, v in candidate_audit.items()
                if k != "bad_row_examples"
            }
            record["bad_row_examples"] = candidate_audit["bad_row_examples"]

            # Candidate acceptance is deliberately strict:
            # it must be numerically validated and strictly better than the
            # current best, not merely have a better bound.
            if (
                candidate_audit["accepted_at_tolerance"] and
                candidate_audit["objective"] <
                best_audit["objective"] - args.tolerance
            ):
                best_x = list(result["vector"])
                best_audit = candidate_audit
                best_label = candidate["label"]
                best_pattern = candidate["pattern"]
                record["strict_improvement_over_previous_best"] = True
            else:
                record["strict_improvement_over_previous_best"] = False
        else:
            record["strict_improvement_over_previous_best"] = False

        results.append(record)

    best_path = os.path.join(args.out_dir, "best.sol")
    write_solution(best_path, target, best_x)

    # Verify the file we just wrote through the same parser and raw-MPS
    # evaluator. This is still an internal check; an independent orchestrator
    # check on the original MPS remains required.
    reread_sol = read_sol(best_path)
    reread_x, reread_recognized = solution_vector(target, reread_sol)
    saved_audit = validate_vector(
        target, reread_x, args.tolerance
    )

    design_position_summary = {
        "official_selected_positions": [
            p + 1 for p, z in enumerate(target_base) if z
        ],
        "best_selected_positions": [
            p + 1 for p, z in enumerate(best_pattern) if z
        ],
        "best_differences_from_official": design_differences(
            target_base, best_pattern
        ),
        "official_selected_count": sum(target_base),
        "best_selected_count": sum(best_pattern),
    }

    output = {
        "instance": "dws012-02",
        "route": (
            "full original target model with exact sibling design transplant "
            "and bounded cardinality-preserving Hamming-2 design exchanges"
        ),
        "inputs": {
            "target_mps": os.path.abspath(args.target_mps),
            "target_solution": os.path.abspath(args.target_sol),
            "sibling_mps": os.path.abspath(args.sibling_mps),
            "sibling_solution": os.path.abspath(args.sibling_sol),
            "total_time_limit": args.total_time_limit,
            "per_solve_limit": args.per_solve_limit,
            "max_hamming2": args.max_hamming2,
            "tolerance": args.tolerance,
        },
        "target_model": {
            "variables": target.NumVars,
            "constraints": target.NumConstrs,
        },
        "sibling_model": {
            "variables": sibling.NumVars,
            "constraints": sibling.NumConstrs,
        },
        "design_mapping_verification": mapping,
        "solution_recognition": {
            "target_solution_variables_recognized": target_recognized,
            "sibling_solution_variables_recognized": sibling_recognized,
        },
        "official_target_audit": official_audit,
        "sibling_design": {
            "selected_positions": [
                p + 1 for p, z in enumerate(sibling_design_pattern) if z
            ],
            "selected_count": sum(sibling_design_pattern),
        },
        "design_positions": design_position_summary,
        "candidate_count": len(candidates),
        "candidate_results": results,
        "best": {
            "label": best_label,
            "objective": best_audit["objective"],
            "bound_from_last_fixed_design_solve": (
                next(
                    (
                        r["bound"] for r in reversed(results)
                        if r.get("label") == best_label
                    ),
                    None,
                )
                if best_label != "official_incumbent" else None
            ),
            "validated": best_audit,
            "solution_file": os.path.abspath(best_path),
        },
        "saved_solution_reread_audit": {
            "recognized_variables": reread_recognized,
            **saved_audit,
        },
        "warnings": [
            "A fixed-design subproblem bound is conditional on that design and "
            "is not a global lower bound for the original MIP.",
            "A candidate is only a research improvement after independent "
            "revalidation against the original target MPS.",
            "The sibling mapping is positional and coefficient/bound/type "
            "verified; variable names are never transferred.",
            "Hamming-2 means one incumbent-selected position is removed and one "
            "unselected position is added, preserving the incumbent design "
            "cardinality.",
            "No claim of optimality is made from any subproblem status, gap, or "
            "bound."
        ],
    }

    with open(os.path.join(args.out_dir, "audit.json"), "w") as f:
        json.dump(output, f, indent=2, sort_keys=True)

    print(json.dumps({
        "audit": os.path.abspath(os.path.join(args.out_dir, "audit.json")),
        "best_solution": os.path.abspath(best_path),
        "best_label": best_label,
        "best_objective": best_audit["objective"],
        "official_objective": official_audit["objective"],
        "strict_improvement_found": (
            best_audit["objective"] <
            official_audit["objective"] - args.tolerance
        ),
        "candidates_constructed": len(candidates),
        "candidates_run": sum(
            r.get("status") not in {
                "not_run_total_budget_exhausted"
            }
            for r in results
        ),
    }, indent=2))


if __name__ == "__main__":
    main()
