#!/usr/bin/env python3
"""
dws012-02 globally valid relaxation hierarchy.

Constructs and solves three structure-derived relaxations of the ORIGINAL MPS:

  1. lp:
       all integer variables relaxed to continuous;

  2. design_integral:
       only the 264 objective-supported integer variables remain integral;

  3. layout_core:
       the 264 design variables remain integral, together with integer
       variables local to official DEC block 1. Integer variables occurring in
       DEC blocks 2--396 are relaxed.

Every relaxation retains:
  * every original row;
  * every original variable;
  * every original bound;
  * every original objective coefficient.

The program never adds incumbent-based cuts and never fixes variables.

Usage:
    python dws012_relaxations.py \
      --mps dws012-02.mps.gz \
      --dec dws012-02.dec \
      --upper-sol artifacts/dws012_transplant/best.sol \
      --out-dir artifacts/dws012_relaxations \
      --total-time-limit 600

Optional:
      --official-sol dws012-02.sol.gz
      --tolerance 1e-6

The output directory contains:
  lp.mps
  design_integral.mps
  layout_core.mps
  manifest.json
  results.json
  upper_solution_audit.json

No global optimality claim is made unless a relaxation lower bound meets the
independently validated upper bound within the explicitly reported tolerance.
"""

import argparse
import collections
import gzip
import json
import math
import os
import re
import time

import gurobipy as gp


# ---------------------------------------------------------------------------
# File and numeric utilities
# ---------------------------------------------------------------------------

def open_text(path):
    if path.endswith(".gz"):
        return gzip.open(path, "rt", errors="replace")
    return open(path, "rt", errors="replace")


def canon(x):
    x = float(x)
    if x == 0.0:
        return "0"
    return format(x, ".17g")


def read_solution(path):
    result = {}

    with open_text(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("<") or line.startswith(">"):
                continue

            fields = line.split()
            if len(fields) < 2:
                continue

            try:
                value = float(fields[1])
            except Exception:
                continue

            name = fields[0]
            if name.lower() in {
                "objective",
                "objective_value",
                "status",
                "solution",
                "solution_status",
                "solstatus",
            }:
                continue

            result[name] = value

    return result


def vector_from_solution(model, solution):
    x = [0.0] * model.NumVars
    recognized = 0

    for v in model.getVars():
        if v.VarName in solution:
            x[v.index] = solution[v.VarName]
            recognized += 1

    return x, recognized


def objective_value(model, x):
    return sum(float(v.Obj) * x[v.index] for v in model.getVars())


# ---------------------------------------------------------------------------
# Original-MPS validation
# ---------------------------------------------------------------------------

def validate_vector(model, x, tolerance):
    max_integer = 0.0
    max_bound = 0.0
    max_row = 0.0
    bad_rows = []

    for v in model.getVars():
        value = float(x[v.index])

        if v.VType in ("B", "I"):
            max_integer = max(max_integer, abs(value - round(value)))

        max_bound = max(
            max_bound,
            max(float(v.LB) - value, 0.0),
            max(value - float(v.UB), 0.0),
        )

    for i, con in enumerate(model.getConstrs()):
        expr = model.getRow(con)
        activity = 0.0

        for k in range(expr.size()):
            v = expr.getVar(k)
            activity += float(expr.getCoeff(k)) * x[v.index]

        residual = activity - float(con.RHS)

        if con.Sense == "=":
            violation = abs(residual)
        elif con.Sense == "<":
            violation = max(residual, 0.0)
        else:
            violation = max(-residual, 0.0)

        max_row = max(max_row, violation)

        if violation > tolerance and len(bad_rows) < 30:
            bad_rows.append({
                "row_index": i,
                "row_name": con.ConstrName,
                "sense": con.Sense,
                "rhs": float(con.RHS),
                "activity": activity,
                "residual": residual,
                "violation": violation,
            })

    obj = objective_value(model, x)

    return {
        "objective": obj,
        "max_integrality_violation": max_integer,
        "max_bound_violation": max_bound,
        "max_row_violation": max_row,
        "accepted_at_tolerance": (
            max_integer <= tolerance
            and max_bound <= tolerance
            and max_row <= tolerance
        ),
        "bad_row_examples": bad_rows,
    }


# ---------------------------------------------------------------------------
# DEC parser
# ---------------------------------------------------------------------------

def parse_dec(path, row_names):
    """
    Supports the common MIPLIB decomposition forms:

        MASTERCONSS
        c1 c2 ...
        BLOCK 1
        c3 c4 ...
        BLOCK 2
        ...

    Also accepts MASTER, MASTERCONS, and BLOCKS declarations. Only row names
    already present in the MPS are assigned.
    """
    assignment = {}
    conflicts = []
    declared_ids = set()
    section = None
    current_block = None

    with open_text(path) as f:
        for line_number, raw in enumerate(f, 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue

            upper = line.upper()

            if re.search(r"\bMASTER(CONSS|CONS)?\b", upper):
                section = "master"
                current_block = 0
                declared_ids.add(0)
                continue

            m = re.search(r"\bBLOCK\s+(\d+)\b", upper)
            if m:
                current_block = int(m.group(1))
                declared_ids.add(current_block)
                section = "block"
                continue

            if upper in {"END", "ENDATA"}:
                section = None
                current_block = None
                continue

            tokens = re.findall(r"[A-Za-z_][A-Za-z0-9_.-]*", line)
            names = [t for t in tokens if t in row_names]

            if not names or section is None or current_block is None:
                continue

            for name in names:
                if name in assignment:
                    if assignment[name] != current_block:
                        conflicts.append({
                            "line": line_number,
                            "row": name,
                            "old_block": assignment[name],
                            "new_block": current_block,
                        })
                else:
                    assignment[name] = current_block

    return {
        "assignment": assignment,
        "declared_block_ids": sorted(declared_ids),
        "conflicts": conflicts,
    }


# ---------------------------------------------------------------------------
# Structural classification
# ---------------------------------------------------------------------------

def extract_rows(model):
    rows = []

    for i, con in enumerate(model.getConstrs()):
        expr = model.getRow(con)
        entries = []

        for k in range(expr.size()):
            v = expr.getVar(k)
            entries.append((v.index, float(expr.getCoeff(k))))

        rows.append({
            "index": i,
            "name": con.ConstrName,
            "sense": con.Sense,
            "rhs": float(con.RHS),
            "entries": entries,
        })

    return rows


def identify_design(model):
    design = [
        v for v in model.getVars()
        if v.VType in ("B", "I") and abs(float(v.Obj)) > 0.0
    ]

    if len(design) != 264:
        raise RuntimeError(
            "Expected 264 objective-supported integer variables; found {}".format(
                len(design)
            )
        )

    return design


def classify_blocks(model, rows, dec_assignment, design):
    row_block = {}
    for row in rows:
        if row["name"] in dec_assignment:
            row_block[row["index"]] = dec_assignment[row["name"]]

    variable_blocks = collections.defaultdict(set)

    for row in rows:
        b = row_block.get(row["index"])
        if b is None:
            continue
        for j, coefficient in row["entries"]:
            variable_blocks[j].add(b)

    design_set = {v.index for v in design}
    block1_local_integer = set()
    shared_integer = set()
    unassigned_integer = set()

    for v in model.getVars():
        if v.VType not in ("B", "I"):
            continue

        j = v.index
        blocks = variable_blocks.get(j, set())

        if j in design_set:
            continue

        # A variable is local to block 1 only if every assigned row in which
        # it occurs belongs to block 1 and it occurs in at least one such row.
        if blocks == {1}:
            block1_local_integer.add(j)
        elif len(blocks) == 0:
            unassigned_integer.add(j)
        else:
            shared_integer.add(j)

    return {
        "row_block": row_block,
        "variable_blocks": variable_blocks,
        "design_set": design_set,
        "block1_local_integer": block1_local_integer,
        "shared_integer": shared_integer,
        "unassigned_integer": unassigned_integer,
    }


# ---------------------------------------------------------------------------
# Relaxation construction
# ---------------------------------------------------------------------------

def relaxation_integer_set(model, classification, name):
    design = classification["design_set"]
    block1 = classification["block1_local_integer"]

    if name == "lp":
        return set()

    if name == "design_integral":
        return set(design)

    if name == "layout_core":
        return set(design) | set(block1)

    raise ValueError(name)


def build_relaxation(original, integer_set):
    """
    Copy the complete original model and relax all integer variables not in
    integer_set. No rows, bounds, or objective terms are removed.
    """
    model = original.copy()
    model.update()

    changed = 0
    retained = 0

    for v in model.getVars():
        if v.VType in ("B", "I"):
            if v.index in integer_set:
                retained += 1
            else:
                v.VType = gp.GRB.CONTINUOUS
                changed += 1

    model.update()

    return model, {
        "retained_integer_variables": retained,
        "relaxed_integer_variables": changed,
        "continuous_variables_after_relaxation": sum(
            v.VType == gp.GRB.CONTINUOUS for v in model.getVars()
        ),
    }


def solve_relaxation(model, name, time_limit):
    model.Params.OutputFlag = 0
    model.Params.TimeLimit = max(0.0, time_limit)
    # Do not set Cutoff: for minimization, -infinity would reject every
    # finite relaxation solution and can invalidate the intended experiment.
    model.update()

    start = time.monotonic()
    model.optimize()
    runtime = time.monotonic() - start

    status_names = {
        gp.GRB.OPTIMAL: "optimal",
        gp.GRB.TIME_LIMIT: "time_limit",
        gp.GRB.INFEASIBLE: "infeasible",
        gp.GRB.INF_OR_UNBD: "inf_or_unbd",
        gp.GRB.SUBOPTIMAL: "suboptimal",
        gp.GRB.INTERRUPTED: "interrupted",
    }

    result = {
        "name": name,
        "status_code": int(model.Status),
        "status": status_names.get(model.Status, "other"),
        "runtime": runtime,
        "solution_count": int(model.SolCount),
        "relaxation_primal_objective": None,
        "dual_bound": None,
        "mip_gap": None,
        "bound_is_global_for_original": (
            model.Status in {
                gp.GRB.OPTIMAL,
                gp.GRB.TIME_LIMIT,
                gp.GRB.SUBOPTIMAL,
            }
        ),
    }

    if model.SolCount > 0:
        result["relaxation_primal_objective"] = float(model.ObjVal)

    try:
        result["dual_bound"] = float(model.ObjBound)
    except Exception:
        result["dual_bound"] = None

    try:
        if model.MIPGap < 1e100:
            result["mip_gap"] = float(model.MIPGap)
    except Exception:
        result["mip_gap"] = None

    return result


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mps", required=True)
    ap.add_argument("--dec", required=True)
    ap.add_argument("--upper-sol", required=True)
    ap.add_argument("--official-sol", default=None)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--total-time-limit", type=float, default=600.0)
    ap.add_argument("--tolerance", type=float, default=1e-6)
    args = ap.parse_args()

    if args.total_time_limit > 600.0 + 1e-9:
        raise RuntimeError("The total solver budget may not exceed 600 seconds")

    os.makedirs(args.out_dir, exist_ok=True)

    original = gp.read(args.mps)
    original.update()

    rows = extract_rows(original)
    design = identify_design(original)
    row_names = {row["name"] for row in rows}

    dec = parse_dec(args.dec, row_names)

    if dec["conflicts"]:
        raise RuntimeError(
            "DEC row assignment conflicts found: {}".format(
                len(dec["conflicts"])
            )
        )

    if len(dec["assignment"]) != len(rows):
        missing = [
            row["name"] for row in rows
            if row["name"] not in dec["assignment"]
        ]
        raise RuntimeError(
            "DEC did not assign every MPS row: {} missing; examples={}".format(
                len(missing), missing[:20]
            )
        )

    classification = classify_blocks(
        original,
        rows,
        dec["assignment"],
        design,
    )

    upper_solution = read_solution(args.upper_sol)
    upper_x, upper_recognized = vector_from_solution(
        original, upper_solution
    )
    upper_audit = validate_vector(
        original, upper_x, args.tolerance
    )

    if not upper_audit["accepted_at_tolerance"]:
        raise RuntimeError(
            "The supplied upper solution failed validation on the original MPS"
        )

    official_audit = None
    if args.official_sol:
        official_solution = read_solution(args.official_sol)
        official_x, official_recognized = vector_from_solution(
            original, official_solution
        )
        official_audit = validate_vector(
            original, official_x, args.tolerance
        )
        official_audit["recognized_variables"] = official_recognized

    # Write a structural manifest before optimization. It gives an
    # independently reproducible account of all variable-role decisions.
    variable_manifest = []

    variable_blocks = classification["variable_blocks"]

    for v in original.getVars():
        j = v.index
        variable_manifest.append({
            "index": j,
            "name": v.VarName,
            "original_type": str(v.VType),
            "lb": float(v.LB),
            "ub": float(v.UB),
            "objective": float(v.Obj),
            "blocks": sorted(variable_blocks.get(j, set())),
            "is_design": j in classification["design_set"],
            "is_block1_local_integer": (
                j in classification["block1_local_integer"]
            ),
            "is_shared_integer": j in classification["shared_integer"],
        })

    manifest = {
        "instance": "dws012-02",
        "source_mps": os.path.abspath(args.mps),
        "source_dec": os.path.abspath(args.dec),
        "rows": original.NumConstrs,
        "variables": original.NumVars,
        "design_variable_count": len(design),
        "design_columns": [v.index for v in design],
        "dec_assigned_rows": len(dec["assignment"]),
        "dec_declared_block_ids": dec["declared_block_ids"],
        "variable_role_counts": {
            "block1_local_integer": len(
                classification["block1_local_integer"]
            ),
            "shared_integer": len(classification["shared_integer"]),
            "unassigned_integer": len(classification["unassigned_integer"]),
            "design_integer": len(classification["design_set"]),
        },
        "variable_map": variable_manifest,
        "relaxation_definitions": {
            "lp": {
                "retained_integer_rule": "none",
                "relaxed_integer_rule": "all original integer variables",
            },
            "design_integral": {
                "retained_integer_rule": (
                    "all 264 objective-supported integer variables"
                ),
                "relaxed_integer_rule": (
                    "all other original integer variables"
                ),
            },
            "layout_core": {
                "retained_integer_rule": (
                    "the 264 design variables plus integer variables "
                    "whose assigned DEC block set is exactly {1}"
                ),
                "relaxed_integer_rule": (
                    "all other original integer variables, including "
                    "variables participating in blocks 2--396"
                ),
            },
        },
        "validity_argument": (
            "Each relaxation preserves every original row, variable bound, "
            "objective coefficient, and variable domain bound, while replacing "
            "some integrality restrictions by continuity. Therefore every "
            "feasible solution of the original MIP remains feasible in each "
            "relaxation. Since the problem is minimization, each relaxation "
            "optimum, and each certified relaxation dual bound, is a valid "
            "lower bound on the original optimum. No incumbent value is used "
            "as a cut or restriction."
        ),
    }

    with open(os.path.join(args.out_dir, "manifest.json"), "w") as f:
        json.dump(manifest, f, indent=2, sort_keys=True)

    total_start = time.monotonic()
    results = []

    relaxation_order = [
        ("lp", "lp"),
        ("design_integral", "design_integral"),
        ("layout_core", "layout_core"),
    ]

    for filename, relaxation_name in relaxation_order:
        elapsed = time.monotonic() - total_start
        remaining = args.total_time_limit - elapsed

        if remaining <= 0.0:
            results.append({
                "name": relaxation_name,
                "status": "not_run_budget_exhausted",
                "retained_integer_variables": None,
                "relaxed_integer_variables": None,
                "runtime": 0.0,
                "relaxation_primal_objective": None,
                "dual_bound": None,
                "bound_is_global_for_original": False,
            })
            continue

        integer_set = relaxation_integer_set(
            original,
            classification,
            relaxation_name,
        )

        relaxation, counts = build_relaxation(
            original,
            integer_set,
        )

        mps_path = os.path.join(
            args.out_dir,
            "{}.mps".format(filename),
        )
        relaxation.write(mps_path)

        solve_result = solve_relaxation(
            relaxation,
            relaxation_name,
            remaining,
        )

        solve_result.update({
            "mps_file": os.path.abspath(mps_path),
            "retained_integer_variables": len(integer_set),
            "relaxed_integer_variables": counts[
                "relaxed_integer_variables"
            ],
            "continuous_variables_after_relaxation": counts[
                "continuous_variables_after_relaxation"
            ],
            "all_original_rows_preserved": (
                relaxation.NumConstrs == original.NumConstrs
            ),
            "all_original_variables_preserved": (
                relaxation.NumVars == original.NumVars
            ),
        })

        # A model dump of the relaxation is useful for independent checks,
        # but the original MPS remains the authority.
        results.append(solve_result)

        del relaxation

    upper = upper_audit["objective"]
    valid_lower_bounds = [
        r["dual_bound"]
        for r in results
        if r.get("bound_is_global_for_original")
        and r.get("dual_bound") is not None
    ]

    strongest_lower_bound = (
        max(valid_lower_bounds)
        if valid_lower_bounds else None
    )

    optimality_test = {
        "validated_upper_bound": upper,
        "strongest_relaxation_dual_bound": strongest_lower_bound,
        "gap_upper_minus_lower": (
            None if strongest_lower_bound is None
            else upper - strongest_lower_bound
        ),
        "claim_optimality": (
            strongest_lower_bound is not None
            and upper - strongest_lower_bound <= args.tolerance
        ),
        "reason": (
            "A claim is allowed only when a certified lower bound from one "
            "of the relaxations meets the independently validated upper "
            "bound within tolerance."
        ),
    }

    output = {
        "instance": "dws012-02",
        "budget": {
            "requested_total_seconds": args.total_time_limit,
            "actual_elapsed_seconds": time.monotonic() - total_start,
            "maximum_allowed_seconds": 600.0,
        },
        "upper_solution": {
            "file": os.path.abspath(args.upper_sol),
            "recognized_variables": upper_recognized,
            "audit": upper_audit,
        },
        "official_solution": {
            "file": (
                os.path.abspath(args.official_sol)
                if args.official_sol else None
            ),
            "audit": official_audit,
        },
        "dec_summary": {
            "declared_block_ids": dec["declared_block_ids"],
            "assigned_rows": len(dec["assignment"]),
            "conflicts": len(dec["conflicts"]),
            "block_row_counts": {
                str(block): sum(
                    1 for b in dec["assignment"].values()
                    if b == block
                )
                for block in sorted(set(dec["assignment"].values()))
            },
        },
        "classification_summary": {
            "design_integer_count": len(
                classification["design_set"]
            ),
            "block1_local_integer_count": len(
                classification["block1_local_integer"]
            ),
            "shared_integer_count": len(
                classification["shared_integer"]
            ),
            "unassigned_integer_count": len(
                classification["unassigned_integer"]
            ),
        },
        "relaxations": results,
        "optimality_test": optimality_test,
        "reproduction_files": {
            "manifest": os.path.abspath(
                os.path.join(args.out_dir, "manifest.json")
            ),
            "relaxation_mps_files": [
                r["mps_file"] for r in results if "mps_file" in r
            ],
        },
        "warnings": [
            "Relaxation dual bounds are globally valid lower bounds only "
            "because all original rows and bounds are retained and only "
            "integrality restrictions are removed.",
            "Relaxation primal objectives are not upper bounds for the "
            "original MIP unless the relaxation solution independently "
            "satisfies the original integrality restrictions.",
            "No fixed-design, fixed-operation, incumbent-centered, or "
            "conditional subproblem bound is used here.",
            "A time-limited solver bound is reported as conditional on the "
            "solver's certified dual-bound status and must be independently "
            "reproduced from the emitted MPS.",
        ],
    }

    with open(os.path.join(args.out_dir, "results.json"), "w") as f:
        json.dump(output, f, indent=2, sort_keys=True)

    with open(os.path.join(args.out_dir, "upper_solution_audit.json"), "w") as f:
        json.dump(upper_audit, f, indent=2, sort_keys=True)

    print(json.dumps({
        "results": os.path.abspath(
            os.path.join(args.out_dir, "results.json")
        ),
        "manifest": os.path.abspath(
            os.path.join(args.out_dir, "manifest.json")
        ),
        "upper_bound": upper,
        "strongest_relaxation_dual_bound": strongest_lower_bound,
        "claim_optimality": optimality_test["claim_optimality"],
        "relaxation_statuses": [
            {
                "name": r["name"],
                "status": r["status"],
                "dual_bound": r["dual_bound"],
                "runtime": r["runtime"],
            }
            for r in results
        ],
    }, indent=2))


if __name__ == "__main__":
    main()
