"""Compare objective-supported design choices in dws012-01 and dws012-02.

No optimization is performed.  Models and public incumbents are only parsed.
"""
from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path

import gurobipy as gp


def read_solution(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix == ".gz" else open
    values: dict[str, float] = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as stream:
        for line in stream:
            fields = line.split()
            if len(fields) < 2:
                continue
            try:
                values[fields[0]] = float(fields[1])
            except ValueError:
                pass
    return values


def profile(mps: Path, solution: Path) -> dict:
    environment = gp.Env(empty=True)
    environment.setParam("OutputFlag", 0)
    environment.start()
    model = gp.read(str(mps), environment)
    incumbent = read_solution(solution)
    objective_integer = []
    objective_continuous = []
    for variable in model.getVars():
        if variable.Obj == 0:
            continue
        record = {
            "name": variable.VarName,
            "coefficient": variable.Obj,
            "value": incumbent.get(variable.VarName, 0.0),
        }
        if variable.VType in ("B", "I"):
            objective_integer.append(record)
        else:
            objective_continuous.append(record)
    return {
        "model": model.ModelName,
        "variables": model.NumVars,
        "rows": model.NumConstrs,
        "objective_integer": objective_integer,
        "objective_continuous": objective_continuous,
        "selected_integer_names": sorted(
            item["name"] for item in objective_integer if item["value"] > 0.5
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps-a", type=Path, required=True)
    parser.add_argument("--sol-a", type=Path, required=True)
    parser.add_argument("--mps-b", type=Path, required=True)
    parser.add_argument("--sol-b", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    a = profile(args.mps_a, args.sol_a)
    b = profile(args.mps_b, args.sol_b)
    ia = {item["name"]: item for item in a["objective_integer"]}
    ib = {item["name"]: item for item in b["objective_integer"]}
    common = sorted(set(ia) & set(ib))
    coefficient_mismatches = [
        name for name in common
        if abs(ia[name]["coefficient"] - ib[name]["coefficient"]) > 1e-12
    ]
    selected_a = set(a["selected_integer_names"])
    selected_b = set(b["selected_integer_names"])
    sequence_a = a["objective_integer"]
    sequence_b = b["objective_integer"]
    common_length = min(len(sequence_a), len(sequence_b))
    positional_coefficient_mismatches = [
        index for index in range(common_length)
        if abs(sequence_a[index]["coefficient"] - sequence_b[index]["coefficient"])
        > 1e-12
    ]
    selected_positions_a = {
        index for index, item in enumerate(sequence_a) if item["value"] > 0.5
    }
    selected_positions_b = {
        index for index, item in enumerate(sequence_b) if item["value"] > 0.5
    }
    payload = {
        "a": {
            "model": a["model"],
            "variables": a["variables"],
            "rows": a["rows"],
            "objective_integer_count": len(a["objective_integer"]),
            "objective_continuous_count": len(a["objective_continuous"]),
            "selected_integer_count": len(selected_a),
        },
        "b": {
            "model": b["model"],
            "variables": b["variables"],
            "rows": b["rows"],
            "objective_integer_count": len(b["objective_integer"]),
            "objective_continuous_count": len(b["objective_continuous"]),
            "selected_integer_count": len(selected_b),
        },
        "common_objective_integer_names": len(common),
        "coefficient_mismatch_count": len(coefficient_mismatches),
        "coefficient_mismatch_sample": coefficient_mismatches[:30],
        "selected_intersection": sorted(selected_a & selected_b),
        "selected_only_a": sorted(selected_a - selected_b),
        "selected_only_b": sorted(selected_b - selected_a),
        "selected_jaccard": (
            len(selected_a & selected_b) / len(selected_a | selected_b)
            if selected_a | selected_b else 1.0
        ),
        "positional_objective_integer_comparison": {
            "common_length": common_length,
            "coefficient_mismatch_count": len(positional_coefficient_mismatches),
            "coefficient_mismatch_positions_sample": positional_coefficient_mismatches[:30],
            "selected_positions_a": sorted(selected_positions_a),
            "selected_positions_b": sorted(selected_positions_b),
            "selected_position_intersection": sorted(
                selected_positions_a & selected_positions_b
            ),
            "selected_position_only_a": sorted(
                selected_positions_a - selected_positions_b
            ),
            "selected_position_only_b": sorted(
                selected_positions_b - selected_positions_a
            ),
            "selected_position_jaccard": (
                len(selected_positions_a & selected_positions_b)
                / len(selected_positions_a | selected_positions_b)
                if selected_positions_a | selected_positions_b else 1.0
            ),
        },
        "notes": [
            "Only objective-supported integer variables are compared.",
            "No optimize or presolve call was made.",
        ],
    }
    args.out.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
