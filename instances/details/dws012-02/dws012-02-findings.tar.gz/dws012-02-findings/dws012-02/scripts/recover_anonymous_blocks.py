"""Recover repeated contiguous structure in the anonymized dws012-02 MPS.

This is a read-only matrix audit.  It never optimizes the model.  The goal is
to turn repeated row signatures into falsifiable hypotheses about replicated
scenario/floor blocks before any decomposition is attempted.
"""
from __future__ import annotations

from collections import Counter, defaultdict
import json
from pathlib import Path
import sys

import gurobipy as gp


def rounded(value: float) -> float:
    return round(float(value), 10)


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: recover_anonymous_blocks.py MODEL.mps.gz OUTPUT.json")
    source, target = map(Path, sys.argv[1:])
    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()
    model = gp.read(str(source), env)
    variables = model.getVars()
    rows = model.getConstrs()

    # Contiguous variable runs capture where type/bounds/objective roles change.
    descriptors = [
        (v.VType, rounded(v.LB), rounded(v.UB), v.Obj != 0.0) for v in variables
    ]
    variable_runs = []
    begin = 0
    for i in range(1, len(descriptors) + 1):
        if i == len(descriptors) or descriptors[i] != descriptors[begin]:
            variable_runs.append(
                {
                    "first_1based": begin + 1,
                    "last_1based": i,
                    "count": i - begin,
                    "type": descriptors[begin][0],
                    "lb": descriptors[begin][1],
                    "ub": descriptors[begin][2],
                    "objective_nonzero": descriptors[begin][3],
                }
            )
            begin = i

    signatures: dict[tuple, list[dict]] = defaultdict(list)
    signature_ids: list[tuple] = []
    column_rows: list[list[int]] = [[] for _ in variables]
    for row_index, con in enumerate(rows):
        expression = model.getRow(con)
        terms = sorted(
            (expression.getVar(k).index, rounded(expression.getCoeff(k)))
            for k in range(expression.size())
        )
        for column, _ in terms:
            column_rows[column].append(row_index)
        coefficients = tuple(sorted(coef for _, coef in terms))
        signature = (con.Sense, rounded(con.RHS), len(terms), coefficients)
        signature_ids.append(signature)
        indices = [index for index, _ in terms]
        if len(signatures[signature]) < 30:
            signatures[signature].append(
                {
                    "row_1based": row_index + 1,
                    "first_column_1based": min(indices) + 1 if indices else None,
                    "last_column_1based": max(indices) + 1 if indices else None,
                    "span": max(indices) - min(indices) if indices else 0,
                    "terms": [[index + 1, coef] for index, coef in terms[:20]],
                }
            )

    counts = Counter(signature_ids)
    top_signatures = []
    for signature, count in counts.most_common(60):
        sense, rhs, degree, coefficients = signature
        examples = signatures[signature]
        row_steps = [
            examples[i + 1]["row_1based"] - examples[i]["row_1based"]
            for i in range(len(examples) - 1)
        ]
        first_column_steps = [
            examples[i + 1]["first_column_1based"]
            - examples[i]["first_column_1based"]
            for i in range(len(examples) - 1)
            if examples[i]["first_column_1based"] is not None
            and examples[i + 1]["first_column_1based"] is not None
        ]
        top_signatures.append(
            {
                "count": count,
                "sense": sense,
                "rhs": rhs,
                "degree": degree,
                "coefficient_multiset": list(coefficients[:40]),
                "coefficient_distinct": len(set(coefficients)),
                "example_row_steps": row_steps,
                "example_first_column_steps": first_column_steps,
                "examples": examples,
            }
        )

    # Row runs show exact ordering of template blocks without assuming names.
    row_runs = []
    begin = 0
    for i in range(1, len(signature_ids) + 1):
        if i == len(signature_ids) or signature_ids[i] != signature_ids[begin]:
            signature = signature_ids[begin]
            row_runs.append(
                {
                    "first_row_1based": begin + 1,
                    "last_row_1based": i,
                    "count": i - begin,
                    "sense": signature[0],
                    "rhs": signature[1],
                    "degree": signature[2],
                }
            )
            begin = i

    incidence_histogram = Counter(len(row_ids) for row_ids in column_rows)
    high_incidence = sorted(
        (
            {
                "column_1based": i + 1,
                "name": variables[i].VarName,
                "incidence": len(row_ids),
                "type": variables[i].VType,
                "objective": variables[i].Obj,
                "first_rows_1based": [r + 1 for r in row_ids[:30]],
            }
            for i, row_ids in enumerate(column_rows)
        ),
        key=lambda item: (-item["incidence"], item["column_1based"]),
    )[:200]

    payload = {
        "source": str(source.resolve()),
        "model": model.ModelName,
        "variable_runs": variable_runs,
        "variable_run_count": len(variable_runs),
        "row_runs_first_500": row_runs[:500],
        "row_run_count": len(row_runs),
        "top_exact_signatures": top_signatures,
        "column_incidence_histogram": dict(sorted(incidence_histogram.items())),
        "highest_incidence_columns": high_incidence,
        "notes": [
            "No optimize or presolve call was made.",
            "Repeated signatures ignore column indices; examples retain indices to test translation symmetry.",
            "All indices in this report are one-based.",
        ],
    }
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(
        json.dumps(
            {
                "variables": len(variables),
                "rows": len(rows),
                "variable_runs": len(variable_runs),
                "row_runs": len(row_runs),
                "exact_signatures": len(counts),
                "output": str(target),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
