#!/usr/bin/env python3
"""
dws012-02 official decomposition audit.

This program performs no global optimization. Gurobi is used for:
  * reading the original MPS;
  * optionally solving a small number of isolated block subproblems.

The DEC file defines row blocks. Variables are classified from actual MPS
incidence, rather than inferred from column numbering.

Usage:
    python dws012_dec_audit.py \
        --mps dws012-02.mps.gz \
        --dec dws012-02.dec \
        --sol dws012-02.sol.gz \
        --out artifacts/dws012_dec_audit.json

Optional local validation:
    --local-solves 5
    --local-time-limit 20
    --enumeration-limit 24

The optional local solves are independent block subproblems with all linking
variables fixed to their official incumbent values. They are not evidence of
global optimality.
"""

import argparse
import collections
import gzip
import hashlib
import itertools
import json
import math
import os
import re
import sys

import gurobipy as gp


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------

def canon(x):
    x = float(x)
    if x == 0.0:
        return "0"
    return format(x, ".17g")


def bounded(xs, n):
    return list(xs[:n])


def percentile(xs, q):
    if not xs:
        return None
    ys = sorted(xs)
    k = int(round((len(ys) - 1) * q))
    return ys[max(0, min(len(ys) - 1, k))]


def digest(obj):
    return hashlib.sha1(repr(obj).encode("utf-8")).hexdigest()[:16]


def row_name_tokens(line, valid_names):
    """
    Extract row names from a DEC line.

    DEC files vary slightly between MIPLIB releases. This accepts ordinary
    whitespace-separated names and ignores punctuation around them.
    """
    out = []
    for tok in re.findall(r"[A-Za-z_][A-Za-z0-9_.-]*", line):
        if tok in valid_names:
            out.append(tok)
    return out


# ---------------------------------------------------------------------------
# Solution parser
# ---------------------------------------------------------------------------

def read_solution(path):
    if path is None:
        return {}

    opener = gzip.open if path.endswith(".gz") else open
    result = {}

    with opener(path, "rt", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("<") or line.startswith(">"):
                continue

            fields = line.split()
            if len(fields) < 2:
                continue

            try:
                value = float(fields[1])
            except Exception:
                continue

            name = fields[0].strip()
            if name.lower() in {
                "objective", "objective_value", "status",
                "solution", "solution_status", "solstatus"
            }:
                continue

            result[name] = value

    return result


def incumbent_vector(model, solution):
    x = [0.0] * model.NumVars
    recognized = 0

    for v in model.getVars():
        if v.VarName in solution:
            x[v.index] = solution[v.VarName]
            recognized += 1

    return x, recognized


# ---------------------------------------------------------------------------
# MPS extraction
# ---------------------------------------------------------------------------

def extract_mps(model):
    vars_ = model.getVars()
    cons = model.getConstrs()

    rows = []
    incidence = [[] for _ in vars_]

    for i, con in enumerate(cons):
        expr = model.getRow(con)
        entries = []

        for k in range(expr.size()):
            v = expr.getVar(k)
            j = v.index
            a = float(expr.getCoeff(k))
            if abs(a) <= 0.0:
                continue
            entries.append((j, a))
            incidence[j].append(i)

        entries.sort()

        if con.Sense == "<":
            sense = "<"
        elif con.Sense == ">":
            sense = ">"
        else:
            sense = "="

        rows.append({
            "index": i,
            "name": con.ConstrName,
            "sense": sense,
            "rhs": float(con.RHS),
            "entries": entries,
        })

    return vars_, rows, incidence


# ---------------------------------------------------------------------------
# DEC parser
# ---------------------------------------------------------------------------

def parse_dec(path, row_names, expected_blocks):
    """
    Parse block row declarations from common MIPLIB decomposition syntax.

    Recognized forms include:

        BLOCKS 396
        MASTERCONSS
        c1 c2 c3
        BLOCK 1
        c4 c5
        BLOCK 2
        c6 c7

    Some files use MASTERCONS, MASTER, or END markers. Unrecognized text is
    ignored. Rows listed more than once are reported as conflicts.
    """
    row_to_block = {}
    conflicts = []
    declared_blocks = set()
    section = None
    current_block = None

    opener = gzip.open if path.endswith(".gz") else open

    with opener(path, "rt", errors="replace") as f:
        for line_number, raw in enumerate(f, 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue

            upper = line.upper()

            # Test a concrete BLOCK before any block-count header.  The API
            # draft used ``BLOCKS?`` first, which also matched ``BLOCK 1`` and
            # consequently discarded every block section.
            bm = re.search(r"\bBLOCK\s+(\d+)\b", upper)
            if bm:
                current_block = int(bm.group(1))
                section = "block"
                declared_blocks.add(current_block)
                continue

            m = re.search(r"\b(?:NBLOCKS|BLOCKS)\s+(\d+)\b", upper)
            if m:
                declared_blocks.add(int(m.group(1)))
                continue

            if re.search(r"\bMASTER(CONSS|CONS)?\b", upper):
                section = "master"
                current_block = None
                continue

            if upper in {"END", "ENDATA"}:
                section = None
                current_block = None
                continue

            names = row_name_tokens(line, row_names)
            if not names:
                continue

            if section == "master":
                target = 0
            elif section == "block" and current_block is not None:
                target = current_block
            else:
                continue

            for name in names:
                if name in row_to_block and row_to_block[name] != target:
                    conflicts.append({
                        "line": line_number,
                        "row": name,
                        "previous_block": row_to_block[name],
                        "new_block": target,
                    })
                else:
                    row_to_block[name] = target

    declared = sorted(declared_blocks)
    if expected_blocks is not None:
        # A BLOCKS declaration can be represented either as {396} or as
        # individual block IDs. Keep both forms in the output.
        declared_count = expected_blocks
    else:
        declared_count = max(declared) if declared else None

    return {
        "row_to_block": row_to_block,
        "declared_block_ids": declared,
        "declared_block_count": declared_count,
        "conflicts": conflicts,
    }


# ---------------------------------------------------------------------------
# Block incidence classification
# ---------------------------------------------------------------------------

def classify_variables(vars_, rows, incidence, row_to_block):
    row_blocks = {}

    for i, row in enumerate(rows):
        row_blocks[i] = row_to_block.get(row["name"], None)

    block_rows = collections.defaultdict(list)
    unassigned_rows = []

    for i, b in row_blocks.items():
        if b is None:
            unassigned_rows.append(i)
        else:
            block_rows[b].append(i)

    var_info = []

    for j, v in enumerate(vars_):
        touched_blocks = sorted({
            row_blocks[i]
            for i in incidence[j]
            if row_blocks[i] is not None
        })

        touches_master = 0 in touched_blocks
        positive_blocks = [b for b in touched_blocks if b != 0]

        if not touched_blocks:
            role = "unincident"
        elif len(touched_blocks) >= 2:
            role = "linking"
        elif touches_master:
            role = "master_only"
        elif len(positive_blocks) == 1:
            role = "local_only"
        else:
            role = "unclassified"

        var_info.append({
            "column": j,
            "name": v.VarName,
            "role": role,
            "blocks": touched_blocks,
            "incidence": len(incidence[j]),
            "type": str(v.VType),
            "lb": float(v.LB),
            "ub": float(v.UB),
            "objective": float(v.Obj),
        })

    return row_blocks, block_rows, unassigned_rows, var_info


def block_variable_sets(var_info, block_rows, rows, row_blocks):
    result = {}

    for b, rids in block_rows.items():
        all_vars = set()
        local_vars = set()
        linking_vars = set()
        master_vars = set()

        for i in rids:
            for j, a in rows[i]["entries"]:
                all_vars.add(j)

        for j in all_vars:
            blocks = set(var_info[j]["blocks"])
            if b in blocks and len(blocks) == 1:
                local_vars.add(j)
            elif len(blocks) >= 2:
                linking_vars.add(j)
            elif 0 in blocks:
                master_vars.add(j)

        result[b] = {
            "rows": set(rids),
            "all_vars": all_vars,
            "local_vars": local_vars,
            "linking_vars": linking_vars,
            "master_vars": master_vars,
        }

    return result


# ---------------------------------------------------------------------------
# Exact block signatures and translation tests
# ---------------------------------------------------------------------------

def exact_block_signature(block_id, block_sets, rows, vars_):
    """
    Exact index-translation signature.

    Variable indices are normalized by the smallest column appearing in the
    block. Rows are sorted by their full normalized coefficient pattern.
    This detects literal translated copies. It is intentionally stricter than
    graph isomorphism.
    """
    data = block_sets[block_id]
    all_vars = sorted(data["all_vars"])

    if not all_vars:
        return ("empty",)

    base = all_vars[0]
    normalized_rows = []

    for i in data["rows"]:
        row = rows[i]
        terms = tuple(
            (j - base, canon(a))
            for j, a in row["entries"]
        )
        normalized_rows.append((
            row["sense"],
            canon(row["rhs"]),
            len(row["entries"]),
            terms,
        ))

    normalized_rows.sort()

    var_descriptors = []
    for j in all_vars:
        v = vars_[j]
        var_descriptors.append((
            j - base,
            str(v.VType),
            canon(v.LB),
            canon(v.UB),
            canon(v.Obj),
        ))

    return (
        len(data["rows"]),
        len(all_vars),
        tuple(normalized_rows),
        tuple(var_descriptors),
    )


def colored_block_fingerprint(block_id, block_sets, rows, vars_, rounds=6):
    """
    Weisfeiler-Lehman-style colored incidence fingerprint.

    This is a strong necessary test for block isomorphism. Equal fingerprints
    are candidates, not a formal graph-isomorphism certificate when colors
    collide.
    """
    data = block_sets[block_id]
    rids = sorted(data["rows"])
    vids = sorted(data["all_vars"])

    row_colors = {}
    var_colors = {}

    for i in rids:
        row = rows[i]
        row_colors[("r", i)] = digest((
            row["sense"], canon(row["rhs"]), len(row["entries"])
        ))

    for j in vids:
        v = vars_[j]
        var_colors[("v", j)] = digest((
            str(v.VType), canon(v.LB), canon(v.UB), canon(v.Obj)
        ))

    for _ in range(rounds):
        new_r = {}
        new_v = {}

        for i in rids:
            incident = []
            for j, a in rows[i]["entries"]:
                if j in data["all_vars"]:
                    incident.append((canon(a), var_colors[("v", j)]))
            new_r[("r", i)] = digest((
                row_colors[("r", i)],
                tuple(sorted(incident)),
            ))

        var_rows = collections.defaultdict(list)
        for i in rids:
            for j, a in rows[i]["entries"]:
                if j in data["all_vars"]:
                    var_rows[j].append((canon(a), new_r[("r", i)]))

        for j in vids:
            new_v[("v", j)] = digest((
                var_colors[("v", j)],
                tuple(sorted(var_rows[j])),
            ))

        row_colors = new_r
        var_colors = new_v

    return {
        "row_color_histogram": dict(collections.Counter(row_colors.values())),
        "variable_color_histogram": dict(collections.Counter(var_colors.values())),
        "digest": digest((
            tuple(sorted(collections.Counter(row_colors.values()).items())),
            tuple(sorted(collections.Counter(var_colors.values()).items())),
        )),
    }


def compare_small_blocks(block_sets, rows, vars_, small_blocks, max_examples):
    exact_groups = collections.defaultdict(list)
    wl_groups = collections.defaultdict(list)
    summaries = []

    for b in small_blocks:
        sig = exact_block_signature(b, block_sets, rows, vars_)
        fp = colored_block_fingerprint(b, block_sets, rows, vars_)

        exact_groups[digest(sig)].append(b)
        wl_groups[fp["digest"]].append(b)

        summaries.append({
            "block": b,
            "row_count": len(block_sets[b]["rows"]),
            "variable_count": len(block_sets[b]["all_vars"]),
            "local_variable_count": len(block_sets[b]["local_vars"]),
            "linking_variable_count": len(block_sets[b]["linking_vars"]),
            "exact_signature_digest": digest(sig),
            "wl_fingerprint_digest": fp["digest"],
        })

    exact_group_list = [
        {
            "digest": d,
            "count": len(bs),
            "blocks_sample": bounded(sorted(bs), max_examples),
        }
        for d, bs in sorted(
            exact_groups.items(),
            key=lambda x: (-len(x[1]), x[0])
        )
    ]

    wl_group_list = [
        {
            "digest": d,
            "count": len(bs),
            "blocks_sample": bounded(sorted(bs), max_examples),
        }
        for d, bs in sorted(
            wl_groups.items(),
            key=lambda x: (-len(x[1]), x[0])
        )
    ]

    return {
        "block_summaries": summaries[:max_examples * 4],
        "exact_translation_groups": exact_group_list[:max_examples],
        "wl_isomorphism_candidate_groups": wl_group_list[:max_examples],
        "exact_signature_group_count": len(exact_groups),
        "wl_group_count": len(wl_groups),
        "all_small_blocks_exactly_same": (
            len(exact_groups) == 1 and len(small_blocks) > 0
        ),
        "all_small_blocks_wl_same": (
            len(wl_groups) == 1 and len(small_blocks) > 0
        ),
    }


# ---------------------------------------------------------------------------
# Incumbent and objective mapping
# ---------------------------------------------------------------------------

def block_metrics(block_sets, rows, vars_, var_info, x, max_examples):
    output = []

    for b in sorted(block_sets):
        data = block_sets[b]

        obj_total = 0.0
        obj_incumbent = 0.0
        nonzero = 0
        max_row_violation = 0.0
        row_violation_count = 0

        safe_min = 0.0
        safe_max = 0.0

        for j in sorted(data["all_vars"]):
            v = vars_[j]
            c = float(v.Obj)
            xv = x[j]

            obj_total += c
            obj_incumbent += c * xv
            if abs(xv) > 1e-8:
                nonzero += 1

            # Independent bound interval. This ignores constraints, so it is
            # safe but generally weak.
            lo = float(v.LB)
            hi = float(v.UB)
            if c >= 0.0:
                safe_min += c * lo
                safe_max += c * hi
            else:
                safe_min += c * hi
                safe_max += c * lo

        for i in sorted(data["rows"]):
            row = rows[i]
            activity = sum(a * x[j] for j, a in row["entries"])
            residual = activity - row["rhs"]

            if row["sense"] == "=":
                viol = abs(residual)
            elif row["sense"] == "<":
                viol = max(residual, 0.0)
            else:
                viol = max(-residual, 0.0)

            max_row_violation = max(max_row_violation, viol)
            if viol > 1e-6:
                row_violation_count += 1

        local_count = len(data["local_vars"])
        linking_count = len(data["linking_vars"])
        all_binary_local = all(
            vars_[j].VType == "B"
            for j in data["local_vars"]
        )

        output.append({
            "block": b,
            "rows": len(data["rows"]),
            "all_variables": len(data["all_vars"]),
            "local_variables": local_count,
            "linking_variables": linking_count,
            "master_variables": len(data["master_vars"]),
            "nonzero_incumbent_variables": nonzero,
            "objective_sum_coefficients": obj_total,
            "objective_incumbent_contribution": obj_incumbent,
            "safe_unconstrained_objective_min": safe_min,
            "safe_unconstrained_objective_max": safe_max,
            "incumbent_max_row_violation": max_row_violation,
            "incumbent_rows_above_1e-6": row_violation_count,
            "local_all_binary": all_binary_local,
            "exact_enumeration_eligible_at_24_bits": (
                all_binary_local and local_count <= 24
            ),
            "local_variable_sample": bounded(sorted(data["local_vars"]), max_examples),
            "linking_variable_sample": bounded(
                sorted(data["linking_vars"]), max_examples
            ),
        })

    return output


# ---------------------------------------------------------------------------
# Exact local enumeration when mathematically applicable
# ---------------------------------------------------------------------------

def row_satisfied(sense, activity, rhs, tol=1e-9):
    if sense == "=":
        return abs(activity - rhs) <= tol
    if sense == "<":
        return activity <= rhs + tol
    return activity >= rhs - tol


def enumerate_binary_block(block_id, block_sets, rows, vars_, x,
                           limit, max_examples):
    """
    Enumerate local binary variables while fixing all linking variables to x.

    This is exact only when:
      * every local variable is binary;
      * the local variable count is <= limit;
      * all variables in block rows are either local or linking.

    Continuous variables make enumeration inapplicable.
    """
    data = block_sets[block_id]
    local = sorted(data["local_vars"])
    linking = sorted(data["linking_vars"])
    all_vars = data["all_vars"]

    if len(local) > limit:
        return {
            "eligible": False,
            "reason": "too_many_local_binary_variables",
            "local_count": len(local),
        }

    if any(vars_[j].VType != "B" for j in local):
        return {
            "eligible": False,
            "reason": "local_continuous_or_integer_variable_present",
            "local_count": len(local),
        }

    uncovered = all_vars - set(local) - set(linking)
    if uncovered:
        return {
            "eligible": False,
            "reason": "variables_not_classified_as_local_or_linking",
            "uncovered_variable_count": len(uncovered),
        }

    feasible = 0
    best_obj = math.inf
    best_assignment = None
    feasible_examples = []

    fixed_activity = {}
    for i in data["rows"]:
        fixed_activity[i] = sum(
            a * x[j]
            for j, a in rows[i]["entries"]
            if j in linking
        )

    for bits in itertools.product((0.0, 1.0), repeat=len(local)):
        assignment = dict(zip(local, bits))
        feasible_here = True

        for i in data["rows"]:
            row = rows[i]
            activity = fixed_activity[i]
            for j, a in row["entries"]:
                if j in assignment:
                    activity += a * assignment[j]

            if not row_satisfied(row["sense"], activity, row["rhs"]):
                feasible_here = False
                break

        if not feasible_here:
            continue

        feasible += 1
        obj = sum(vars_[j].Obj * assignment[j] for j in local)
        if obj < best_obj:
            best_obj = obj
            best_assignment = assignment

        if len(feasible_examples) < max_examples:
            feasible_examples.append({
                "objective": obj,
                "ones": [
                    j for j, value in assignment.items()
                    if value > 0.5
                ],
            })

    return {
        "eligible": True,
        "local_count": len(local),
        "feasible_configuration_count": feasible,
        "best_local_objective_at_fixed_linking": (
            None if best_assignment is None else best_obj
        ),
        "best_assignment_ones": (
            None if best_assignment is None else [
                j for j, value in best_assignment.items()
                if value > 0.5
            ]
        ),
        "feasible_configuration_examples": feasible_examples,
    }


# ---------------------------------------------------------------------------
# Optional local MIP solves
# ---------------------------------------------------------------------------

def solve_local_block(model, block_id, block_sets, rows, vars_, x,
                      time_limit, output_limit):
    """
    Build and solve only the rows of one block.

    Linking variables are fixed to incumbent values. Local variables retain
    their original types and bounds. The objective is the original objective
    restricted to variables appearing in the block.

    This is a bounded diagnostic subproblem, not a global solve.
    """
    data = block_sets[block_id]
    involved = sorted(data["all_vars"])

    if not involved:
        return {
            "status": "empty",
            "block": block_id,
        }

    sub = gp.Model("dws012_local_block_{}".format(block_id))
    sub.Params.OutputFlag = 0
    sub.Params.TimeLimit = time_limit
    sub.Params.SolutionLimit = output_limit

    newvars = {}

    for j in involved:
        v = vars_[j]
        lb = float(v.LB)
        ub = float(v.UB)

        if j in data["linking_vars"]:
            lb = x[j]
            ub = x[j]

        newvars[j] = sub.addVar(
            lb=lb,
            ub=ub,
            vtype=v.VType,
            obj=float(v.Obj),
            name="v{}".format(j),
        )

    sub.update()

    for i in sorted(data["rows"]):
        row = rows[i]
        expr = gp.LinExpr()
        for j, a in row["entries"]:
            expr.addTerms(float(a), newvars[j])

        if row["sense"] == "=":
            sub.addConstr(expr == row["rhs"], name="r{}".format(i))
        elif row["sense"] == "<":
            sub.addConstr(expr <= row["rhs"], name="r{}".format(i))
        else:
            sub.addConstr(expr >= row["rhs"], name="r{}".format(i))

    sub.ModelSense = model.ModelSense
    sub.optimize()

    result = {
        "block": block_id,
        "status_code": int(sub.Status),
        "status_name": {
            gp.GRB.OPTIMAL: "optimal",
            gp.GRB.TIME_LIMIT: "time_limit",
            gp.GRB.INFEASIBLE: "infeasible",
            gp.GRB.SUBOPTIMAL: "suboptimal",
            gp.GRB.INTERRUPTED: "interrupted",
        }.get(sub.Status, "other"),
        "runtime": float(sub.Runtime),
        "mip_gap": None,
        "objective": None,
        "bound": None,
    }

    if sub.SolCount > 0:
        result["objective"] = float(sub.ObjVal)
    if sub.IsMIP and sub.ObjBound is not None:
        result["bound"] = float(sub.ObjBound)
    if sub.IsMIP and sub.MIPGap < 1e100:
        result["mip_gap"] = float(sub.MIPGap)

    return result


# ---------------------------------------------------------------------------
# Recommendation
# ---------------------------------------------------------------------------

def recommend(block_audit, translation, metrics, local_results):
    small = [
        x for x in metrics
        if x["block"] >= 2
    ]

    if not small:
        return (
            "The DEC parser did not recover small blocks. Validate DEC syntax "
            "before selecting an algorithm."
        )

    exact_same = translation["all_small_blocks_exactly_same"]
    wl_same = translation["all_small_blocks_wl_same"]

    local_counts = [x["local_variables"] for x in small]
    linking_counts = [x["linking_variables"] for x in small]
    enum_eligible = sum(
        x["exact_enumeration_eligible_at_24_bits"]
        for x in small
    )

    if exact_same and enum_eligible == len(small):
        return (
            "Use exact local configuration enumeration. The 395 small blocks "
            "are literal translated copies and each has at most 24 binary "
            "local variables. Enumerate once with linking values symbolic or "
            "sampled, then build a configuration master over block copies. "
            "This can improve the primal immediately and can yield a valid "
            "lower bound if every local configuration is included exactly."
        )

    if (exact_same or wl_same) and max(local_counts) <= 40:
        return (
            "Use a canonical local-block subproblem and configuration "
            "generation. The small blocks appear interchangeable, but their "
            "local state space is too large for blind enumeration. Generate "
            "feasible configurations by fixing linking variables, use "
            "incumbent-centered local replacement for primal improvement, "
            "and add exact block lower bounds or columns to a master."
        )

    if exact_same or wl_same:
        return (
            "Use repeated-block decomposition with local MIP/LP recourse. "
            "The small blocks have strong structural similarity, but exact "
            "finite enumeration is not presently justified. First solve a "
            "few blocks with incumbent linking values, compare bounds and "
            "objective ranges, then implement logic-based Benders or "
            "Dantzig-Wolfe only after confirming the linking interface."
        )

    if max(linking_counts) <= 10:
        return (
            "The blocks have narrow interfaces but are not exact copies. "
            "Use block-specific configuration generation or logic-based "
            "Benders. A primal large-neighborhood move can replace one block "
            "at a time while preserving the master/layout variables."
        )

    return (
        "The official blocks are not interchangeable under the recovered "
        "signatures and have broad interfaces. Do not assume a block master. "
        "Use the incumbent to construct bounded neighborhoods around selected "
        "blocks and audit whether any local replacement improves the "
        "validated objective before attempting a global decomposition."
    )


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", required=True)
    parser.add_argument("--dec", required=True)
    parser.add_argument("--sol", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--expected-blocks", type=int, default=396)
    parser.add_argument("--enumeration-limit", type=int, default=24)
    parser.add_argument("--local-solves", type=int, default=0)
    parser.add_argument("--local-time-limit", type=float, default=20.0)
    parser.add_argument("--max-examples", type=int, default=20)
    args = parser.parse_args()

    model = gp.read(args.mps)
    model.update()

    vars_, rows, incidence = extract_mps(model)
    row_names = {r["name"] for r in rows}

    dec = parse_dec(
        args.dec,
        row_names,
        args.expected_blocks,
    )

    solution = read_solution(args.sol)
    x, recognized = incumbent_vector(model, solution)

    row_to_block = dec["row_to_block"]
    row_blocks, block_rows, unassigned_rows, var_info = classify_variables(
        vars_, rows, incidence, row_to_block
    )

    block_sets = block_variable_sets(
        var_info, block_rows, rows, row_blocks
    )

    all_declared_blocks = sorted(
        b for b in block_sets
        if b != 0
    )
    small_blocks = [
        b for b in all_declared_blocks
        if len(block_sets[b]["rows"]) == 49
    ]

    translation = compare_small_blocks(
        block_sets,
        rows,
        vars_,
        small_blocks,
        args.max_examples,
    )

    metrics = block_metrics(
        block_sets,
        rows,
        vars_,
        var_info,
        x,
        args.max_examples,
    )

    exact_enum_results = []
    for b in small_blocks:
        if len(exact_enum_results) >= args.max_examples:
            break
        result = enumerate_binary_block(
            b,
            block_sets,
            rows,
            vars_,
            x,
            args.enumeration_limit,
            args.max_examples,
        )
        result["block"] = b
        exact_enum_results.append(result)

    local_results = []
    if args.local_solves > 0:
        for b in small_blocks[:args.local_solves]:
            local_results.append(
                solve_local_block(
                    model,
                    b,
                    block_sets,
                    rows,
                    vars_,
                    x,
                    args.local_time_limit,
                    1,
                )
            )

    # Aggregate variable role and block-size statistics.
    role_counts = collections.Counter(v["role"] for v in var_info)
    block_size_counts = collections.Counter(
        len(block_sets[b]["rows"])
        for b in block_sets
    )

    objective_by_role = collections.defaultdict(float)
    objective_by_block = collections.Counter()

    for v in var_info:
        if abs(v["objective"]) <= 0.0:
            continue
        objective_by_role[v["role"]] += v["objective"]
        for b in v["blocks"]:
            objective_by_block[b] += v["objective"]

    recommendation = recommend(
        {
            "block_count": len(block_sets),
            "unassigned_rows": len(unassigned_rows),
        },
        translation,
        metrics,
        local_results,
    )

    output = {
        "instance": "dws012-02",
        "inputs": {
            "mps": os.path.abspath(args.mps),
            "dec": os.path.abspath(args.dec),
            "solution": os.path.abspath(args.sol),
            "expected_blocks": args.expected_blocks,
        },
        "mps_summary": {
            "variables": model.NumVars,
            "constraints": model.NumConstrs,
            "binary_variables": sum(v.VType == "B" for v in vars_),
            "continuous_variables": sum(v.VType == "C" for v in vars_),
            "integer_variables": sum(v.VType == "I" for v in vars_),
            "objective_nonzero_variables": sum(
                abs(float(v.Obj)) > 0.0 for v in vars_
            ),
        },
        "dec_summary": {
            "declared_block_ids": dec["declared_block_ids"],
            "declared_block_count": dec["declared_block_count"],
            "parsed_row_assignments": len(row_to_block),
            "unassigned_mps_rows": len(unassigned_rows),
            "unassigned_row_sample": [
                rows[i]["name"] for i in unassigned_rows[:args.max_examples]
            ],
            "assignment_conflict_count": len(dec["conflicts"]),
            "assignment_conflict_examples": dec["conflicts"][
                :args.max_examples
            ],
            "parsed_blocks": sorted(block_sets),
            "block_size_histogram": {
                str(k): v for k, v in sorted(block_size_counts.items())
            },
            "rows_in_master_block_0": len(block_sets.get(0, {}).get("rows", [])),
        },
        "incumbent_summary": {
            "solution_file_variables": len(solution),
            "recognized_variables": recognized,
            "nonzero_variables": sum(abs(v) > 1e-8 for v in x),
            "objective_recomputed": sum(
                float(v.Obj) * x[v.index]
                for v in vars_
            ),
        },
        "variable_role_summary": {
            "counts": dict(role_counts),
            "objective_sum_by_role": dict(objective_by_role),
            "objective_sum_by_block": {
                str(k): float(v)
                for k, v in objective_by_block.items()
            },
        },
        "small_block_definition": {
            "small_block_count": len(small_blocks),
            "small_block_ids_sample": small_blocks[:args.max_examples],
            "criterion": "exactly 49 assigned rows",
        },
        "translation_analysis": translation,
        "block_metrics": metrics[:args.max_examples * 4],
        "exact_enumeration_tests": exact_enum_results,
        "optional_local_solves": local_results,
        "recommendation": recommendation,
        "interpretation_tests": [
            "DEC parsing is invalid if the expected master row count or "
            "396-block count is not recovered.",
            "Literal translation requires equality of exact normalized row "
            "and variable signatures, not merely equal row counts.",
            "WL fingerprint equality is a necessary-structure candidate, not "
            "a formal graph-isomorphism proof when colors collide.",
            "A local configuration enumeration is exact only when every "
            "non-linking variable is binary and the number of such variables "
            "is within the enumeration limit.",
            "The safe objective interval ignores constraints; it is a valid "
            "interval but may be very weak.",
            "A local solve with incumbent linking values proves only the "
            "conditional local result, never a global bound.",
            "A valid global lower bound requires a complete master relaxation "
            "and valid lower bounds for every omitted or generated block "
            "configuration."
        ],
    }

    with open(args.out, "w") as f:
        json.dump(output, f, indent=2, sort_keys=True)

    print(json.dumps({
        "output": os.path.abspath(args.out),
        "parsed_rows": len(row_to_block),
        "parsed_blocks": len(block_sets),
        "small_blocks": len(small_blocks),
        "exactly_same_small_block_signatures": (
            translation["all_small_blocks_exactly_same"]
        ),
        "wl_same_small_block_fingerprints": (
            translation["all_small_blocks_wl_same"]
        ),
        "recognized_incumbent_variables": recognized,
        "objective_recomputed": output["incumbent_summary"][
            "objective_recomputed"
        ],
        "recommendation": recommendation,
    }, indent=2))


if __name__ == "__main__":
    main()
