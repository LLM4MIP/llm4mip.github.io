# Read-only Gurobi structure summary for dws012-02

The original minimization MPS has 51,108 variables, 26,382 linear rows and
261,120 nonzeros. Variable types are 30,096 integer variables (all have 0/1
bounds when inspected) and 21,012 continuous variables. There are 2,270
equalities, 22,176 <= rows and 1,936 >= rows. The objective has only 660
nonzero coefficients. Row degree: min 1, median 4, max 73. Column incidence:
min 1, median 4, max 28. There are no quadratic, SOS, or general constraints.

Variable and row names are anonymized and ordered (`VAR1` ... `VAR51108`, `c1`
... `c26382`). Prominent repeated exact row signatures are:

- 9,900 rows: sense <=, degree 7, rhs 0;
- 7,920 rows: sense <=, degree 4, rhs 0;
- 1,518 rows: sense <=, degree 2, rhs 0;
- 792 rows: sense <=, degree 3, rhs 0;
- 396 rows each of two distinct degree-50 equality signatures at rhs 0;
- 396 rows: degree-73 equality at rhs 0;
- 198 rows: degree-3 >= at rhs 0;
- 132 rows: degree-3 <= at rhs 61;
- 132 rows: degree-2 <= at rhs 0;
- 132 rows each: degree-44 <= at rhs 30 and degree-44 >= at rhs -30.

The largest objective coefficients are layout-looking binary costs near
`VAR1483`--`VAR1560` (examples: 4,650; 4,500; 4,200; 4,050; 3,600; 2,484.75).
The official incumbent has only 541 nonzero entries and was independently
recomputed as 119893.31070966377. It has zero integrality violation; maximum
row violation 1.36e-7 and maximum bound violation 6.12e-7, both below 1e-6.

Full machine evidence remains in `structure/structure.json` and contains
representative rows and coefficient signatures. Do not infer semantic indices
solely from contiguous numbering: generate an incidence/template audit from
the raw MPS to test any proposed floor/scenario/layout mapping.
