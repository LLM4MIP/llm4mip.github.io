# `graphdraw-mainerd`

## Result

The official objective **38,842** is independently reconstructed as a solution
with zero violation in exact decimal arithmetic.  No better layout was found,
and global optimality remains open.  The strongest range established in this
study is

```text
31,882 <= OPT <= 38,842.
```

The lower bound 31,882 is certified by the new exact global geometric proof
and rational branch certificates; see the [2026-09-14 proof and replay](../../docs/dual-bound-audit-2026-09-14/README.md). It improves the historical CP-SAT bound 31,769 by 113. The historical searches below are retained.  A strict local certificate additionally proves that no layout with
objective at most 38,841.5 changes the positions of at most **six** of the 31
rectangles.  Hence any strict improvement must move at least seven rectangles.

## Input and provenance

- MPS SHA-256: `922559B42529658AD1A1CF2539364CDDE65122C2457AED7186D66A344ECF986F`
- Official compressed solution SHA-256: `11BFE42CABFB0AB3D672D705DBFDF60F98C8414C27951D224B726661B4786375`
- Exact reconstructed solution SHA-256: `C0D4816AA2E98CE902D6AFCCFEAC3260FCA89FEE5DC32963CF56CB9F34DAE33A`
- [MIPLIB instance page](https://miplib.zib.de/instance_details_graphdraw-mainerd.html)
- Silva and Santos, [*Drawing graphs with mathematical programming and variable neighborhood search*](https://doi.org/10.1016/j.endm.2017.03.027)
- [MIPLIB download and solution archives](https://miplib.zib.de/download.html)

MIPLIB lists the instance as open and gives the best submitted objective as
`38841.9999999991`, obtained by Mars Davletshin with OptVerse in July 2024.

## Recovered structure

The original MPS places 31 named rectangles on a 62-by-62 integer coordinate
range.  Its 2,050 variables split into

- 1,860 pair-order variables: four directions for every one of the 465
  rectangle pairs;
- 62 integer position variables;
- 66 continuous coordinate-distance variables for 33 graph edges; and
- 62 continuous deviations from the drawing center.

The 17,980 triangle rows are transitivity inequalities for the pair orders.
There are also 1,860 big-M non-overlap rows and 465 one-hot rows.  Rectangle
dimensions range from 5 to 10 on one axis and 6 to 14 on the other; total area
is 1,961, or 51.0% of the 62-by-62 placement area.

The relationship graph has 33 edges.  Thirty rectangles form one connected
component with cycle rank four, while `system` is isolated.  Twelve graph
vertices are leaves.

## Objective and incumbent audit

The objective recovered from the MPS is

```text
126 * sum(edge Manhattan center distances)
+     sum(deviation from the drawing center).
```

For the official layout the two terms are `126 * 302.5` and `727`, giving
exactly 38,842 after removing textual rounding.  Only nine of the 33 edges are
at their individual geometric minimum; the other edges contain 61 distance
units of excess.  The three largest excesses are 9, 8, and 6.5.

Summing every edge's individual minimum and the explicit center-deviation
lower bound gives the elementary valid bound 30,496.  Because coordinates are
integral and all offsets are half-integral, every objective lies on a
half-integer lattice, so the next strict target below 38,842 is 38,841.5.

The downloaded solution has eight tiny decimal row residuals, all at most
`9e-12`, and no integrality or bound violation.  The compact-model translator
rewrites the same layout with exact integer/half-integer values; the shared
checker then reports zero violations on all 20,661 original MPS rows even at
tolerance zero.

## Exact compact reformulation

[`solve_compact_cpsat.py`](scripts/solve_compact_cpsat.py) replaces 1,860 order
variables and 17,980 transitivity rows with one global `NoOverlap2D`
constraint.  It retains only 62 positions, 66 doubled edge-distance variables,
and 62 doubled center-deviation variables: 190 integer variables in total.
All half-integral quantities and the objective are multiplied by two.

The formulation is exact.  A non-overlapping coordinate layout induces
transitive row/column orders, and an original MPS solution is a non-overlapping
layout.  The omitted conditional distance rows are implied by the selected
separation axis and the two rectangle sizes.  Translation of the CP solution
back to all original variables provides an independent executable check of
this correspondence.

## Experiments

| Method | CPU threads | Limit | Result |
|---|---:|---:|---|
| Gurobi 13.0.1 on original MPS, official start | 64 | 600 s | incumbent 38,842; bound 31,424.3446368981 |
| COPT 8.0.4 on original MPS, official start | 64 | 600 s | incumbent 38,842; bound 31,406.044583688 |
| compact CP-SAT global, official hint | 32 | 600 s | incumbent 38,842; **bound 31,769** |
| compact CP-SAT, target `<=38841.5`, at most 1 moved rectangle | 16 | 300 s | **infeasible in 0.23 s** |
| same, at most 2 moved rectangles | 16 | 300 s | **infeasible in 1.02 s** |
| same, at most 3 moved rectangles | 16 | 300 s | **infeasible in 11.58 s** |
| same, at most 4 moved rectangles | 16 | 300 s | **infeasible in 70.47 s** |
| same, at most 5 moved rectangles | 32 | 300 s | **infeasible in 127.88 s** |
| same, at most 6 moved rectangles | 48 | 300 s | **infeasible in 250.83 s** |
| same, at most 7 moved rectangles | 64 | 300 s | no improving layout found; time limit, no certificate |

All work on `altman` used CPU only; **GPU0 was not used**.

## Interpretation and next algorithm

Generic branch-and-bound spends most of its effort on a redundant extended
ordering formulation.  The compact model gives a better bound, but its 600
second search still does not improve the incumbent.  The local certificates
show why coordinate descent and small swaps are ineffective: a better drawing
must reorganize at least seven rectangles simultaneously.

The next upper-bound search should therefore be a graph-aware variable
neighborhood search.  Destroy a connected set containing endpoints of the
largest excess edges, also free the rectangles blocking their shortest paths,
and use the compact CP-SAT model to repair that neighborhood exactly.  The
penalty 126 makes reducing edge length by one unit worthwhile even if center
deviation rises by as much as 125.  For a global proof, valid packing cuts and
component/subgraph distance lower bounds should be added to the compact model;
longer runs on the unchanged original MPS are unlikely to be competitive.

## Reproduction

Run the structural and exact audits from the repository root:

```powershell
python .\instances\graphdraw-mainerd\scripts\analyze_structure.py `
  .\instances\graphdraw-mainerd\input\graphdraw-mainerd.mps.gz `
  .\instances\graphdraw-mainerd\solutions\official-38842.sol `
  --json .\instances\graphdraw-mainerd\artifacts\structure-and-solution-audit.json

python .\common\exact_mps_solution_check.py `
  .\instances\graphdraw-mainerd\input\graphdraw-mainerd.mps.gz `
  .\instances\graphdraw-mainerd\solutions\cpsat-reconstructed-38842.sol `
  --tolerance 0
```

The compact solver requires OR-Tools:

```powershell
python .\instances\graphdraw-mainerd\scripts\solve_compact_cpsat.py `
  .\instances\graphdraw-mainerd\input\graphdraw-mainerd.mps.gz `
  --hint .\instances\graphdraw-mainerd\solutions\official-38842.sol `
  --time-limit 600 --workers 32 `
  --solution .\instances\graphdraw-mainerd\solutions\compact.sol
```

See the [Chinese study report](reports/graphdraw-mainerd-study-zh.md),
[`artifacts/`](artifacts/), and [`logs/`](logs/).
