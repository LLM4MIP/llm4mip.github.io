#  `graphdraw-mainerd` Structural analysis and solve experiments

## Conclusion

This study neither found a layout below 38842 nor proved that 38842 is globally optimal. The official solution, checked against the original
MPS high-precision replications only allow the maximum `9e-12` text space to be residual; compact models are reproduced
The integer/half integer solution defaulted on the original 20,661 row by row exactly zero.

```text
31769 <= OPT <= 38842, and any strict improvements must at least simultaneously move the 7 rectangle.
```

31769 comes from the equivalent compact CP-SAT model 600 with the effective lower bound after seconds.
Infeasibility proof of `<=38841.5`: fixed official coordinates, only allowing a maximum of 1, 2,..., 6
The rectangle changes any of the coordinates, and all six models are closed and determined to be infeasible.

##  Real problems recovered from MPS

This instance is the first-stage layout problem for a database entity-relationship diagram. The 31 named rectangles must be placed in
In an integer coordinate grid, any two rectangles cannot overlap. The original model 2,050 can be broken down into:

-  `zV` 1,860 one: four relative directions per pair of rectangles, right
  `4*C(31,2)=1860`；
-  `x` 62: the line of each rectangle, the starting coordinates;
-  `dist` 66: The center distance on the two axes on the relationship side of the 33 bar;
-  `center_dist` 62 One: Each rectangle deviates from the center of the canvas on the two axes.

In the 20,661 row, the 17,980 row triangle/transfer is unequal, the number is exactly
`4*C(31,3)`; another 1,860 clause is the big-M separation constraint and 465 clause is a four-way constraint.
The rectangular one axis size is 5 10, the other axis is 6 14, the total area of 1,961, which is 62 × 62 layout
51.0 % of the region.

The relationship graph has a 33 bar: the 30 rectangle forms a connected fraction, and the `system` is an isolated point;
has cycle rank 4 and 12 leaf nodes. This is not a dense graph, so the real difficulty lies in
In the case of non-overlapping containers, a small number of relationships are shortened.

##  Objective function and 38842 solution

The objective function is

```text
126
+ the deviation of all rectangles to the center of the canvas.
```

The marginal distance of the official layout is 302.5, the center deviation is 727, so

```text
126 * 302.5 + 727 = 38842。
```

Only 9 reaches the shortest distance separately from each other on the 33 line, while the rest of the line adds up to 61 distance units.
The three largest surpluses are:

| Relationships | The actual distance | The shortest distance of independence |  Excess |
|---|---:|---:|---:|
| `samples`–`sample_attributes` | 17.5 | 8.5 | 9 |
| `terms`–`termlists_terms` | 14 | 6 | 8 |
| `entrycards`–`entrycards_occurrence_attributes` | 12 | 5.5 | 6.5 |

Since every marginal decrease in the 1 directly improves the 126, and the center deviation is only calculated according to the 1, improvement algorithms should be prioritized.
Rearrange the adjacent rectangles of these high-ultra-relationships. Add the shortest independent distances on each side, plus the model expression.
The given center deviation lower bound can only be obtained by 30496; it ignores the shared rectangle and container conflict between the different sides.

All coordinates are integers, the center of dimension and the point of reference are integers or half-integers, and the positive coefficient assists the variable when optimal.
Take the absolute value lower bound, so the objective value falls on the lattice of step length 0.5. 38842 is the first possible value below
38841.5 is the cutoff for all strict local experiments.

##  Equivalent compact model

The original MPS uses the direction variable 1,860 and the 17,980 bar to transmit unequal descriptive rectangles that do not overlap.
Replace this part with a `NoOverlap2D` global constraint, with only:

```text
62 coordinate + 66 double lateral distance + 62 double center distance = 190 an integer variable.
```

All half-integer distances and objectives are multiplied by two, and the entire CP-SAT model is an integer model.

1.  A four-choice separation of the original MPS necessarily gives a non-overlapping rectangular layout;
2.  Any arbitrary non-overlapping coordinate can generate a certain effective direction for each pair of rectangles in a coordinate sequence that is natural.
satisfy all triangle passing inequalities;
3.  The omitted condition distance from the lower bound is semi-dimensional and automatically introduced by the selected separation axis and two rectangles.

solve The script translates the compact solution into the entire original MPS variable. For 38842 reconstruction solution use tolerance.
The 0 check, the 20,661 line, the lower bound on the variable and the integrality all passed exactly, which also gives executable
Independent conformity verification.

##  Solve the experiment

###  Global baseline

|  Method | CPU threads |  Time | The best solution | Finally lower bound |
|---|---:|---:|---:|---:|
|  Gurobi 13.0.1 ,  original MPS + official start |  64  |  600 s  |  38842  |  31424.3446368981  |
|  COPT 8.0.4 ,  original MPS + official start |  64  |  600 s  |  38842  |  31406.044583688  |
| CP-SAT, 190 variable Compact model + official hint |  32  |  600 s  |  38842  |  **31769**  |

All three routes did not find any strict improvement. The compact model lower bound is clearer than the original MIP, but the remaining global gap is clearer.
Still around 18.2 %, so the 600 second experiment is not enough to prove optimal.
**does not use GPU0**.

###  The button moves rectangular by the number of rows strict local certificate

For each rectangle, a `moved` Bul quantity is introduced; if 0, its two coordinates are fixed as the official value.
add

```text
sum(moved) <= k
objective <= 38841.5
```

The result is a complete solution:

| Maximum number of moving rectangles `k` |  result | proof time |
|---:|---|---:|
|  1  |  infeasible |  0.23 s  |
|  2  |  infeasible |  1.02 s  |
|  3  |  infeasible |  11.58 s  |
|  4  |  infeasible |  70.47 s  |
|  5  |  infeasible |  127.88 s  |
|  6  |  infeasible |  250.83 s  |
|  7  | 300 seconds not found improved, search not closed | Non-certified |

The neighborhood is defined by actual rectangle positions rather than redundant `zV` bits. A rectangle position
Changes can override many pair-order bits simultaneously, so this certificate more directly illustrates the layout algorithms.
Localism. The conclusion is that single-point movement, pairs of exchanges and a maximum of six rectangles cannot be repaired exactly.
The seven-rectangle experiment found no improvement, but the state is `UNKNOWN`, so it cannot be written as
infeasible proof .

##  What algorithm should be used next?

It is reasonable to use variable neighborhood search in the paper; the current certificate further explains the neighborhood must be
Release at least seven rectangles at a time. The recommended primal bound route is to destroy/repair a graph-driven structure:

1.  Starting at the extreme largest relation, select its endpoints and the neighbours of the relation;
2.  Add a geometrical rectangle near the blocking endpoint to form a destroy set of 7 12 rectangles;
3.  Fixed out-set coordinates with tight CP-SAT exact repair;
4.  If improved, update the incumbent and reproduce the next set of neighborhoods by margin override; if infeasible, expand.
destroy the set instead of going back to 1 - flip.

The lower bound direction requires that the total marginal length of a subgraph be added to a compact model for at least a few cubes in a finite rectangular region.
These types of joint cuts, as well as packing cuts for high-area/high-connection subset.
The order extension will dilute LP information, simply extending the same Gurobi/COPT parameters unlikely to be efficient closure
18 % gap.

## material

-  [MIPLIB `graphdraw-mainerd` page ](https://miplib.zib.de/instance_details_graphdraw-mainerd.html)]
-  [MIPLIB download with solution archive ](https://miplib.zib.de/download.html)]
-  [Silva and Santos, Drawing graphs with mathematical programming and variable neighborhood search ](https://doi.org/10.1016/j.endm.2017.03.027)
