#!/usr/bin/env python3
"""
Exact-cover attack for neos-3634244-kauru.

Main engine:
    Custom enumeration of all independent 7-sets followed by exact-cover
    search. Gurobi is used only to parse the original MPS.

Modes:
    solve
        Recover graph, enumerate every independent 7-set, and solve exact
        cover. Emits either:
          * candidate JSON and original-variable .sol; or
          * a complete UNSAT proof tree.
        On timeout or resource limit prints UNKNOWN/TIME_LIMIT.

    verify-candidate
        Recover graph independently and check a candidate partition.

    verify-proof
        Recover graph, independently enumerate the 7-sets, and replay the
        complete proof tree.

Proof records:
    B v sid1 sid2 ...
        After deterministic forced propagation, branch on uncovered vertex v.
        The listed set IDs must be exactly all currently compatible independent
        7-sets containing v, in deterministic branch order.

    Z
        After deterministic forced propagation, an uncovered vertex has zero
        compatible sets.

    M
        The normalized uncovered state was already completely proved
        impossible earlier in this depth-first traversal.

Forced propagation is implicit and deterministic:
    If the selected minimum-support uncovered vertex has exactly one compatible
    set, that set must be selected.

Completeness:
    Independent 7-sets are enumerated exhaustively. Every feasible cluster is
    therefore a generated set. Exact-cover search branches over every
    compatible set containing a minimum-support uncovered vertex. Z and M are
    independently checked. A valid complete proof establishes infeasibility.

A timeout, interrupted run, .tmp file, or incomplete enumeration proves
nothing.
"""

import argparse
import gzip
import hashlib
import json
import os
import sys
import time

import gurobipy as gp
from gurobipy import GRB


N = 175
K = 25
CAP = 7
ALL = (1 << N) - 1
DEFAULT_THRESHOLD = 1397.4872804
EXPECTED_GRAPH_HASH = (
    "bfb674b9e3a504468278da0aae3b84b9ca8937c02d36f7b26c0fba18090a14d7"
)

BOUND_TOL = 1e-9
ROW_TOL = 1e-8
COEFF_TOL = 1e-7
THRESHOLD_AUDIT_TOL = 1e-7


class StopRun(Exception):
    pass


class Limits:
    def __init__(self, seconds):
        self.started = time.monotonic()
        self.deadline = (
            None if seconds is None or seconds <= 0
            else self.started + seconds
        )

    def elapsed(self):
        return time.monotonic() - self.started

    def check(self):
        if self.deadline is not None and time.monotonic() >= self.deadline:
            raise StopRun("wall-clock limit reached")

    def remaining(self):
        if self.deadline is None:
            return None
        return max(0.0, self.deadline - time.monotonic())


def bit_vertices(mask):
    while mask:
        bit = mask & -mask
        yield bit.bit_length() - 1
        mask ^= bit


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as inp:
        while True:
            block = inp.read(1 << 20)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def graph_sha256(adj):
    h = hashlib.sha256()
    width = (N + 7) // 8
    for mask in adj:
        h.update(mask.to_bytes(width, "little", signed=False))
    return h.hexdigest()


def sets_sha256(set_masks):
    h = hashlib.sha256()
    width = (N + 7) // 8
    for mask in set_masks:
        h.update(mask.to_bytes(width, "little", signed=False))
    return h.hexdigest()


def near(a, b, tolerance=ROW_TOL):
    return abs(a - b) <= tolerance


def is_integral_type(vtype):
    return vtype in (GRB.BINARY, GRB.INTEGER, "B", "I")


def is_continuous_type(vtype):
    return vtype in (GRB.CONTINUOUS, "C")


def is_semantic_binary(var):
    return (
        is_integral_type(var.VType)
        and near(var.LB, 0.0, BOUND_TOL)
        and near(var.UB, 1.0, BOUND_TOL)
    )


def recover_graph(mps_path, threshold, limits, enforce_known_hash):
    limits.check()
    print("[recover] reading:", mps_path, flush=True)

    model = gp.read(mps_path)
    model.update()
    limits.check()

    variables = model.getVars()
    constraints = model.getConstrs()

    print(
        "[recover] variables=%d constraints=%d"
        % (len(variables), len(constraints)),
        flush=True,
    )

    type_counts = {}
    for var in variables:
        type_counts[var.VType] = type_counts.get(var.VType, 0) + 1
    print("[recover] variable types:", type_counts, flush=True)

    binary_indices = {
        var.index for var in variables if is_semantic_binary(var)
    }
    if len(binary_indices) != 4375:
        raise RuntimeError(
            "expected 4375 integral [0,1] variables, got %d"
            % len(binary_indices)
        )

    other_indices = [
        var.index for var in variables if var.index not in binary_indices
    ]
    if len(other_indices) != 1:
        raise RuntimeError(
            "expected one non-assignment variable, got %d"
            % len(other_indices)
        )

    t_index = other_indices[0]
    tvar = variables[t_index]

    if not is_continuous_type(tvar.VType):
        raise RuntimeError("unique non-assignment variable is not continuous")
    if model.ModelSense != GRB.MINIMIZE:
        raise RuntimeError("model is not minimization")

    nonzero_objective = [
        (v.index, v.Obj) for v in variables if abs(v.Obj) > ROW_TOL
    ]
    if (
        len(nonzero_objective) != 1
        or nonzero_objective[0][0] != t_index
        or nonzero_objective[0][1] <= 0
    ):
        raise RuntimeError(
            "objective is not a positive multiple of the epigraph variable"
        )

    assignment_groups = []
    capacity_groups = []

    for row_number, constr in enumerate(constraints):
        if (row_number & 16383) == 0:
            limits.check()

        row = model.getRow(constr)
        terms = [
            (row.getVar(pos).index, row.getCoeff(pos))
            for pos in range(row.size())
        ]

        if (
            constr.Sense == GRB.EQUAL
            and len(terms) == K
            and near(constr.RHS, 1.0)
            and all(
                idx in binary_indices and near(coef, 1.0)
                for idx, coef in terms
            )
        ):
            group = sorted(idx for idx, _ in terms)
            if len(set(group)) != K:
                raise RuntimeError("duplicate variable in assignment row")
            assignment_groups.append(group)

        elif (
            constr.Sense == GRB.LESS_EQUAL
            and len(terms) == N
            and near(constr.RHS, float(CAP))
            and all(
                idx in binary_indices and near(coef, 1.0)
                for idx, coef in terms
            )
        ):
            group = sorted(idx for idx, _ in terms)
            if len(set(group)) != N:
                raise RuntimeError("duplicate variable in capacity row")
            capacity_groups.append(group)

    if len(assignment_groups) != N:
        raise RuntimeError(
            "expected %d assignment rows, got %d"
            % (N, len(assignment_groups))
        )
    if len(capacity_groups) != K:
        raise RuntimeError(
            "expected %d capacity rows, got %d"
            % (K, len(capacity_groups))
        )

    # Deterministic order based only on original column indices.
    assignment_groups.sort(key=lambda group: tuple(group))
    capacity_groups.sort(key=lambda group: tuple(group))

    entity_of = {}
    for entity, group in enumerate(assignment_groups):
        for idx in group:
            if idx in entity_of:
                raise RuntimeError(
                    "column occurs in multiple assignment rows: %d" % idx
                )
            entity_of[idx] = entity

    color_of = {}
    for color, group in enumerate(capacity_groups):
        for idx in group:
            if idx in color_of:
                raise RuntimeError(
                    "column occurs in multiple capacity rows: %d" % idx
                )
            color_of[idx] = color

    if set(entity_of) != binary_indices:
        raise RuntimeError("assignment rows do not partition all binaries")
    if set(color_of) != binary_indices:
        raise RuntimeError("capacity rows do not partition all binaries")

    x_index = [[None] * K for _ in range(N)]
    for idx in sorted(binary_indices):
        i = entity_of[idx]
        k = color_of[idx]
        if x_index[i][k] is not None:
            raise RuntimeError("duplicate entity/color intersection")
        x_index[i][k] = idx

    if any(
        x_index[i][k] is None
        for i in range(N)
        for k in range(K)
    ):
        raise RuntimeError("incomplete 175 x 25 assignment matrix")

    pair_cost = [[float("-inf")] * N for _ in range(N)]
    epigraph_rows = 0
    nearest = None

    for row_number, constr in enumerate(constraints):
        if (row_number & 8191) == 0:
            limits.check()

        row = model.getRow(constr)
        if row.size() != 3 or constr.Sense != GRB.LESS_EQUAL:
            continue

        t_coefficients = []
        binary_terms = []
        recognized = True

        for pos in range(3):
            var = row.getVar(pos)
            idx = var.index
            coef = row.getCoeff(pos)

            if idx == t_index:
                t_coefficients.append(coef)
            elif idx in binary_indices:
                binary_terms.append((idx, coef))
            else:
                recognized = False
                break

        if not recognized:
            continue
        if len(t_coefficients) != 1 or len(binary_terms) != 2:
            continue

        if not near(t_coefficients[0], -1.0):
            raise RuntimeError(
                "malformed epigraph t coefficient in row %s"
                % constr.ConstrName
            )

        idx1, coef1 = binary_terms[0]
        idx2, coef2 = binary_terms[1]

        i = entity_of[idx1]
        j = entity_of[idx2]
        k1 = color_of[idx1]
        k2 = color_of[idx2]

        if i == j or k1 != k2:
            raise RuntimeError(
                "malformed epigraph entity/color structure in row %s"
                % constr.ConstrName
            )

        if (
            abs(coef1 - coef2) > COEFF_TOL
            or abs(coef1 - constr.RHS) > COEFF_TOL
            or abs(coef2 - constr.RHS) > COEFF_TOL
        ):
            raise RuntimeError(
                "malformed epigraph coefficients in row %s"
                % constr.ConstrName
            )

        d = max(coef1, coef2, constr.RHS)
        if i > j:
            i, j = j, i

        if d > pair_cost[i][j]:
            pair_cost[i][j] = d

        epigraph_rows += 1
        candidate = (abs(d - threshold), d, constr.ConstrName)
        if nearest is None or candidate < nearest:
            nearest = candidate

    expected_rows = 2 * (N * (N - 1) // 2) * K
    if epigraph_rows != expected_rows:
        raise RuntimeError(
            "expected %d epigraph rows, got %d"
            % (expected_rows, epigraph_rows)
        )

    for i in range(N):
        for j in range(i + 1, N):
            if pair_cost[i][j] == float("-inf"):
                raise RuntimeError("missing pair cost for (%d,%d)" % (i, j))

    print("[recover] epigraph rows:", epigraph_rows, flush=True)
    print("[recover] nearest threshold coefficient:", nearest, flush=True)

    if nearest is not None and 0.0 < nearest[0] < THRESHOLD_AUDIT_TOL:
        raise RuntimeError(
            "coefficient is within %.1e of threshold without equality: %r"
            % (THRESHOLD_AUDIT_TOL, nearest)
        )

    adj = [0] * N
    edge_count = 0
    greatest_allowed = float("-inf")
    least_forbidden = float("inf")

    for i in range(N):
        for j in range(i + 1, N):
            d = pair_cost[i][j]
            if d <= threshold:
                greatest_allowed = max(greatest_allowed, d)
            else:
                least_forbidden = min(least_forbidden, d)
                adj[i] |= 1 << j
                adj[j] |= 1 << i
                edge_count += 1

    graph_hash = graph_sha256(adj)
    degrees = [mask.bit_count() for mask in adj]

    print("[graph] threshold:", repr(threshold), flush=True)
    print("[graph] conflict edges:", edge_count, "/ 15225", flush=True)
    print(
        "[graph] density:",
        2.0 * edge_count / (N * (N - 1)),
        flush=True,
    )
    print(
        "[graph] greatest allowed effective cost:",
        repr(greatest_allowed),
        flush=True,
    )
    print(
        "[graph] least forbidden effective cost:",
        repr(least_forbidden),
        flush=True,
    )
    print(
        "[graph] degree min/avg/max:",
        min(degrees),
        sum(degrees) / N,
        max(degrees),
        flush=True,
    )
    print("[graph] SHA256:", graph_hash, flush=True)

    if enforce_known_hash and threshold == DEFAULT_THRESHOLD:
        if graph_hash != EXPECTED_GRAPH_HASH:
            raise RuntimeError(
                "recovered graph hash mismatch: expected %s, got %s"
                % (EXPECTED_GRAPH_HASH, graph_hash)
            )

    variable_names = [
        [variables[x_index[i][k]].VarName for k in range(K)]
        for i in range(N)
    ]

    t_name = tvar.VarName
    del model

    return adj, t_name, variable_names, graph_hash


class IndependentSetEnumerator:
    def __init__(
        self,
        adj,
        limits,
        max_sets,
        progress_seconds,
    ):
        self.adj = adj
        self.allowed = [
            ALL & ~(adj[v] | (1 << v))
            for v in range(N)
        ]
        self.limits = limits
        self.max_sets = max_sets
        self.progress_seconds = progress_seconds

        self.set_masks = []
        self.recursion_nodes = 0
        self.last_report = time.monotonic()

    def report_if_needed(self):
        now = time.monotonic()
        if now - self.last_report >= self.progress_seconds:
            print(
                "[enumerate] recursion_nodes=%d independent_7_sets=%d "
                "elapsed=%.1fs"
                % (
                    self.recursion_nodes,
                    len(self.set_masks),
                    self.limits.elapsed(),
                ),
                flush=True,
            )
            self.last_report = now

    def recurse(self, chosen_mask, candidates, depth):
        self.recursion_nodes += 1

        if (self.recursion_nodes & 4095) == 0:
            self.limits.check()
            self.report_if_needed()

        need = CAP - depth
        if candidates.bit_count() < need:
            return

        if need == 0:
            self.set_masks.append(chosen_mask)
            if (
                self.max_sets > 0
                and len(self.set_masks) > self.max_sets
            ):
                raise StopRun(
                    "independent-set count exceeded --max-sets=%d"
                    % self.max_sets
                )
            return

        # Ascending vertex order. After selecting v, only vertices still in
        # 'remaining' can follow it, so every set is generated exactly once.
        remaining = candidates
        while remaining:
            if remaining.bit_count() < need:
                break

            bit = remaining & -remaining
            remaining ^= bit
            vertex = bit.bit_length() - 1

            self.recurse(
                chosen_mask | bit,
                remaining & self.allowed[vertex],
                depth + 1,
            )

    def run(self):
        print("[enumerate] starting exhaustive independent 7-set generation")
        self.recurse(0, ALL, 0)
        self.limits.check()

        print(
            "[enumerate] COMPLETE recursion_nodes=%d sets=%d elapsed=%.1fs"
            % (
                self.recursion_nodes,
                len(self.set_masks),
                self.limits.elapsed(),
            ),
            flush=True,
        )
        print(
            "[enumerate] set-list SHA256:",
            sets_sha256(self.set_masks),
            flush=True,
        )
        return self.set_masks


def build_incidence(set_masks):
    incidence = [[] for _ in range(N)]

    for sid, mask in enumerate(set_masks):
        if mask.bit_count() != CAP:
            raise RuntimeError("enumerated set does not have size 7")
        for vertex in bit_vertices(mask):
            incidence[vertex].append(sid)

    counts = [len(row) for row in incidence]
    print(
        "[exact-cover] incidence min/avg/max:",
        min(counts),
        sum(counts) / N,
        max(counts),
        flush=True,
    )
    print(
        "[exact-cover] total incidences:",
        sum(counts),
        flush=True,
    )
    return incidence


class ExactCoverSearch:
    def __init__(
        self,
        set_masks,
        incidence,
        limits,
        proof_file,
        progress_seconds,
        max_memo_states,
    ):
        self.set_masks = set_masks
        self.incidence = incidence
        self.limits = limits
        self.proof_file = proof_file
        self.progress_seconds = progress_seconds
        self.max_memo_states = max_memo_states

        self.nodes = 0
        self.compatibility_tests = 0
        self.last_report = time.monotonic()
        self.selected = []
        self.solution = None
        self.failed = set()

        self.forced_count = 0
        self.zero_prunes = 0
        self.memo_prunes = 0

    def check_limits(self):
        if (self.compatibility_tests & 65535) == 0:
            self.limits.check()

        now = time.monotonic()
        if now - self.last_report >= self.progress_seconds:
            print(
                "[exact-cover] nodes=%d selected=%d failed_states=%d "
                "forced=%d zero=%d memo=%d tests=%d elapsed=%.1fs"
                % (
                    self.nodes,
                    len(self.selected),
                    len(self.failed),
                    self.forced_count,
                    self.zero_prunes,
                    self.memo_prunes,
                    self.compatibility_tests,
                    self.limits.elapsed(),
                ),
                flush=True,
            )
            self.last_report = now

            if self.proof_file is not None:
                self.proof_file.flush()

    def compatible_ids(self, vertex, uncovered):
        result = []
        forbidden = ALL ^ uncovered

        for sid in self.incidence[vertex]:
            self.compatibility_tests += 1
            if (self.compatibility_tests & 65535) == 0:
                self.check_limits()

            if not (self.set_masks[sid] & forbidden):
                result.append(sid)

        return result

    def choose_vertex(self, uncovered):
        best_vertex = None
        best_ids = None
        best_count = None

        for vertex in bit_vertices(uncovered):
            ids = self.compatible_ids(vertex, uncovered)
            count = len(ids)

            if count == 0:
                return vertex, ids

            if best_count is None or count < best_count:
                best_vertex = vertex
                best_ids = ids
                best_count = count

                if count == 1:
                    return best_vertex, best_ids

        return best_vertex, best_ids

    def branch_order(self, ids, uncovered):
        # Prefer sets containing vertices with small static incidence.
        # This affects performance only; the proof lists and checks all IDs.
        def key(sid):
            mask = self.set_masks[sid]
            rarity = sum(len(self.incidence[v]) for v in bit_vertices(mask))
            return rarity, sid

        return sorted(ids, key=key)

    def remember_failed(self, uncovered):
        if (
            self.max_memo_states <= 0
            or len(self.failed) < self.max_memo_states
        ):
            self.failed.add(uncovered)

    def write_record(self, text):
        if self.proof_file is not None:
            self.proof_file.write(text + "\n")

    def dfs(self, initial_uncovered):
        self.nodes += 1
        if (self.nodes & 1023) == 0:
            self.check_limits()

        uncovered = initial_uncovered
        forced_here = 0

        while True:
            if uncovered == 0:
                if len(self.selected) != K:
                    raise AssertionError(
                        "175 vertices covered by a non-25 number of 7-sets"
                    )
                self.solution = list(self.selected)
                return True

            if uncovered in self.failed:
                self.memo_prunes += 1
                self.write_record("M")
                del self.selected[len(self.selected) - forced_here:]
                return False

            vertex, ids = self.choose_vertex(uncovered)

            if not ids:
                self.zero_prunes += 1
                self.write_record("Z")
                self.remember_failed(uncovered)
                del self.selected[len(self.selected) - forced_here:]
                return False

            if len(ids) == 1:
                sid = ids[0]
                self.forced_count += 1
                self.selected.append(sid)
                forced_here += 1
                uncovered ^= self.set_masks[sid]
                continue

            break

        ordered = self.branch_order(ids, uncovered)
        self.write_record(
            "B %d %s"
            % (vertex, " ".join(str(sid) for sid in ordered))
        )

        for sid in ordered:
            self.selected.append(sid)
            if self.dfs(uncovered ^ self.set_masks[sid]):
                return True
            self.selected.pop()

        self.remember_failed(uncovered)
        del self.selected[len(self.selected) - forced_here:]
        return False


class ExactCoverProofVerifier:
    def __init__(
        self,
        set_masks,
        incidence,
        proof_file,
        limits,
        progress_seconds,
        max_memo_states,
    ):
        self.set_masks = set_masks
        self.incidence = incidence
        self.proof_file = proof_file
        self.limits = limits
        self.progress_seconds = progress_seconds
        self.max_memo_states = max_memo_states

        self.failed = set()
        self.records = 0
        self.compatibility_tests = 0
        self.last_report = time.monotonic()

    def check_progress(self):
        self.limits.check()
        now = time.monotonic()
        if now - self.last_report >= self.progress_seconds:
            print(
                "[verify-proof] records=%d failed_states=%d tests=%d "
                "elapsed=%.1fs"
                % (
                    self.records,
                    len(self.failed),
                    self.compatibility_tests,
                    self.limits.elapsed(),
                ),
                flush=True,
            )
            self.last_report = now

    def remember_failed(self, uncovered):
        if (
            self.max_memo_states <= 0
            or len(self.failed) < self.max_memo_states
        ):
            self.failed.add(uncovered)

    def compatible_ids(self, vertex, uncovered):
        forbidden = ALL ^ uncovered
        result = []

        for sid in self.incidence[vertex]:
            self.compatibility_tests += 1
            if (self.compatibility_tests & 65535) == 0:
                self.check_progress()
            if not (self.set_masks[sid] & forbidden):
                result.append(sid)

        return result

    def choose_vertex(self, uncovered):
        best_vertex = None
        best_ids = None
        best_count = None

        for vertex in bit_vertices(uncovered):
            ids = self.compatible_ids(vertex, uncovered)
            count = len(ids)

            if count == 0:
                return vertex, ids
            if best_count is None or count < best_count:
                best_vertex = vertex
                best_ids = ids
                best_count = count
                if count == 1:
                    return best_vertex, best_ids

        return best_vertex, best_ids

    def branch_order(self, ids):
        def key(sid):
            rarity = sum(
                len(self.incidence[v])
                for v in bit_vertices(self.set_masks[sid])
            )
            return rarity, sid

        return sorted(ids, key=key)

    def get_record(self):
        line = self.proof_file.readline()
        if not line:
            raise RuntimeError("unexpected end of proof")

        self.records += 1
        if (self.records & 4095) == 0:
            self.check_progress()

        line = line.strip()
        if not line:
            raise RuntimeError(
                "blank proof record at record %d" % self.records
            )
        return line

    def verify_node(self, initial_uncovered, selected_count):
        uncovered = initial_uncovered
        count = selected_count

        # Reproduce deterministic forced propagation before consuming a record.
        while True:
            if uncovered == 0:
                raise RuntimeError(
                    "proof reaches a feasible exact cover of 25 sets"
                )

            if uncovered in self.failed:
                line = self.get_record()
                if line != "M":
                    raise RuntimeError(
                        "expected M at record %d, got %s"
                        % (self.records, line)
                    )
                return

            vertex, ids = self.choose_vertex(uncovered)

            if not ids:
                line = self.get_record()
                if line != "Z":
                    raise RuntimeError(
                        "expected Z at record %d, got %s"
                        % (self.records, line)
                    )
                self.remember_failed(uncovered)
                return

            if len(ids) == 1:
                sid = ids[0]
                uncovered ^= self.set_masks[sid]
                count += 1
                if count > K:
                    raise RuntimeError("forced path selected over 25 sets")
                continue

            break

        line = self.get_record()
        tokens = line.split()

        if not tokens or tokens[0] != "B" or len(tokens) < 4:
            raise RuntimeError(
                "expected branch record at %d, got %s"
                % (self.records, line)
            )

        claimed_vertex = int(tokens[1])
        claimed_ids = [int(token) for token in tokens[2:]]
        expected_ids = self.branch_order(ids)

        if claimed_vertex != vertex or claimed_ids != expected_ids:
            raise RuntimeError(
                "branch mismatch at record %d: expected B %d %s, got %s"
                % (
                    self.records,
                    vertex,
                    " ".join(map(str, expected_ids)),
                    line,
                )
            )

        for sid in expected_ids:
            self.verify_node(
                uncovered ^ self.set_masks[sid],
                count + 1,
            )

        self.remember_failed(uncovered)


def validate_selected_sets(set_masks, selected_ids):
    if len(selected_ids) != K:
        raise RuntimeError(
            "candidate uses %d sets instead of %d"
            % (len(selected_ids), K)
        )

    union = 0
    clusters = []

    for sid in selected_ids:
        if sid < 0 or sid >= len(set_masks):
            raise RuntimeError("candidate set ID out of range: %d" % sid)

        mask = set_masks[sid]
        if mask.bit_count() != CAP:
            raise RuntimeError("candidate set does not have size 7")
        if union & mask:
            raise RuntimeError("candidate clusters overlap")

        union |= mask
        clusters.append(list(bit_vertices(mask)))

    if union != ALL:
        raise RuntimeError("candidate does not cover all 175 vertices")

    return clusters


def validate_clusters_against_graph(adj, clusters):
    if len(clusters) != K:
        raise RuntimeError("candidate must contain 25 clusters")

    seen = set()

    for cluster_number, cluster in enumerate(clusters):
        if len(cluster) != CAP or len(set(cluster)) != CAP:
            raise RuntimeError(
                "cluster %d is not a seven-element set" % cluster_number
            )

        for vertex in cluster:
            if not 0 <= vertex < N:
                raise RuntimeError("vertex out of range: %d" % vertex)
            if vertex in seen:
                raise RuntimeError("vertex appears in multiple clusters")
            seen.add(vertex)

        for pos, u in enumerate(cluster):
            for v in cluster[pos + 1:]:
                if adj[u] & (1 << v):
                    raise RuntimeError(
                        "conflict edge (%d,%d) inside cluster %d"
                        % (u, v, cluster_number)
                    )

    if seen != set(range(N)):
        raise RuntimeError("candidate does not cover exactly vertices 0..174")


def write_candidate(
    json_path,
    sol_path,
    threshold,
    graph_hash,
    set_hash,
    clusters,
    t_name,
    variable_names,
):
    data = {
        "format": "kauru-exact-cover-candidate-v1",
        "threshold": threshold,
        "graph_sha256": graph_hash,
        "set_list_sha256": set_hash,
        "clusters": clusters,
    }

    with open(json_path, "w", newline="\n") as out:
        json.dump(data, out, indent=2, sort_keys=True)
        out.write("\n")

    # Arbitrarily label the 25 unlabeled exact-cover sets by JSON order.
    entity_color = [-1] * N
    for color, cluster in enumerate(clusters):
        for entity in cluster:
            entity_color[entity] = color

    with open(sol_path, "w", newline="\n") as out:
        out.write("# generated by kauru_exact_cover.py\n")
        out.write("%s %.17g\n" % (t_name, threshold))
        for entity in range(N):
            for color in range(K):
                out.write(
                    "%s %d\n"
                    % (
                        variable_names[entity][color],
                        int(entity_color[entity] == color),
                    )
                )

    print("[result] candidate JSON:", json_path, flush=True)
    print("[result] original-variable solution:", sol_path, flush=True)


def enumerate_for_mode(args, adj, limits):
    enumerator = IndependentSetEnumerator(
        adj=adj,
        limits=limits,
        max_sets=args.max_sets,
        progress_seconds=args.progress_seconds,
    )
    set_masks = enumerator.run()
    incidence = build_incidence(set_masks)
    return set_masks, incidence


def solve(args, limits):
    adj, t_name, variable_names, graph_hash = recover_graph(
        args.mps,
        args.threshold,
        limits,
        not args.allow_unexpected_graph,
    )

    set_masks, incidence = enumerate_for_mode(args, adj, limits)
    set_hash = sets_sha256(set_masks)

    uncovered_vertices = [
        vertex for vertex in range(N) if not incidence[vertex]
    ]
    if uncovered_vertices:
        print(
            "[exact-cover] vertices in no independent 7-set:",
            uncovered_vertices,
            flush=True,
        )

    metadata = {
        "format": "kauru-exact-cover-proof-v1",
        "mps_sha256": sha256_file(args.mps),
        "threshold": args.threshold,
        "graph_sha256": graph_hash,
        "set_list_sha256": set_hash,
        "set_count": len(set_masks),
        "vertices": N,
        "cluster_count": K,
        "cluster_size": CAP,
        "max_memo_states": args.max_memo_states,
    }

    temporary = args.proof + ".tmp"

    try:
        with open(temporary, "w", buffering=1, newline="\n") as proof:
            proof.write("# " + json.dumps(metadata, sort_keys=True) + "\n")

            search = ExactCoverSearch(
                set_masks=set_masks,
                incidence=incidence,
                limits=limits,
                proof_file=proof,
                progress_seconds=args.progress_seconds,
                max_memo_states=args.max_memo_states,
            )

            feasible = search.dfs(ALL)

        print(
            "[exact-cover] finished nodes=%d forced=%d zero=%d memo=%d "
            "elapsed=%.1fs"
            % (
                search.nodes,
                search.forced_count,
                search.zero_prunes,
                search.memo_prunes,
                limits.elapsed(),
            ),
            flush=True,
        )

        if feasible:
            os.remove(temporary)
            clusters = validate_selected_sets(
                set_masks, search.solution
            )
            validate_clusters_against_graph(adj, clusters)
            write_candidate(
                args.candidate,
                args.solution,
                args.threshold,
                graph_hash,
                set_hash,
                clusters,
                t_name,
                variable_names,
            )
            print("STATUS: FEASIBLE", flush=True)
            return 0

        os.replace(temporary, args.proof)
        print("[result] complete proof:", args.proof, flush=True)
        print("STATUS: PROVED_INFEASIBLE", flush=True)
        print(
            "[result] run verify-proof before accepting the conclusion",
            flush=True,
        )
        return 0

    except StopRun:
        if os.path.exists(temporary):
            try:
                os.remove(temporary)
            except OSError:
                pass
        raise


def verify_candidate(args, limits):
    adj, _, _, graph_hash = recover_graph(
        args.mps,
        args.threshold,
        limits,
        not args.allow_unexpected_graph,
    )

    with open(args.candidate, "r") as inp:
        data = json.load(inp)

    if data.get("format") != "kauru-exact-cover-candidate-v1":
        raise RuntimeError("unknown candidate format")
    if data.get("threshold") != args.threshold:
        raise RuntimeError("candidate threshold mismatch")
    if data.get("graph_sha256") != graph_hash:
        raise RuntimeError("candidate graph hash mismatch")

    clusters = data.get("clusters")
    if not isinstance(clusters, list):
        raise RuntimeError("candidate has no cluster list")

    validate_clusters_against_graph(adj, clusters)

    print("[verify-candidate] candidate is a valid threshold partition")
    print("STATUS: FEASIBLE")
    return 0


def verify_proof(args, limits):
    adj, _, _, graph_hash = recover_graph(
        args.mps,
        args.threshold,
        limits,
        not args.allow_unexpected_graph,
    )

    set_masks, incidence = enumerate_for_mode(args, adj, limits)
    set_hash = sets_sha256(set_masks)

    with open(args.proof, "r", newline="") as proof:
        header = proof.readline()
        if not header.startswith("# "):
            raise RuntimeError("proof metadata header is missing")

        metadata = json.loads(header[2:])
        expected = {
            "format": "kauru-exact-cover-proof-v1",
            "mps_sha256": sha256_file(args.mps),
            "threshold": args.threshold,
            "graph_sha256": graph_hash,
            "set_list_sha256": set_hash,
            "set_count": len(set_masks),
            "vertices": N,
            "cluster_count": K,
            "cluster_size": CAP,
        }

        for key, value in expected.items():
            if metadata.get(key) != value:
                raise RuntimeError(
                    "proof metadata mismatch for %s: expected %r, got %r"
                    % (key, value, metadata.get(key))
                )

        memo_limit = metadata.get("max_memo_states")
        if not isinstance(memo_limit, int):
            raise RuntimeError("invalid proof memo limit")

        verifier = ExactCoverProofVerifier(
            set_masks=set_masks,
            incidence=incidence,
            proof_file=proof,
            limits=limits,
            progress_seconds=args.progress_seconds,
            max_memo_states=memo_limit,
        )
        verifier.verify_node(ALL, 0)

        trailing = proof.read().strip()
        if trailing:
            raise RuntimeError("trailing records after complete proof tree")

    print(
        "[verify-proof] valid complete exact-cover infeasibility proof",
        flush=True,
    )
    print("STATUS: PROVED_INFEASIBLE", flush=True)
    return 0


def add_common(parser):
    parser.add_argument("mps")
    parser.add_argument(
        "--threshold",
        type=float,
        default=DEFAULT_THRESHOLD,
    )
    parser.add_argument(
        "--time-limit",
        type=float,
        default=3600.0,
        help="total wall-clock seconds; <=0 means unlimited",
    )
    parser.add_argument(
        "--progress-seconds",
        type=float,
        default=10.0,
    )
    parser.add_argument(
        "--allow-unexpected-graph",
        action="store_true",
        help="do not require the known graph hash at the default threshold",
    )


def add_enumeration_options(parser):
    parser.add_argument(
        "--max-sets",
        type=int,
        default=5000000,
        help="abort as UNKNOWN if more sets are generated; <=0 is unlimited",
    )


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="mode", required=True)

    ps = sub.add_parser("solve")
    add_common(ps)
    add_enumeration_options(ps)
    ps.add_argument("--proof", default="kauru_exact_cover.unsat")
    ps.add_argument("--candidate", default="kauru_exact_cover_candidate.json")
    ps.add_argument("--solution", default="kauru_exact_cover_candidate.sol")
    ps.add_argument(
        "--max-memo-states",
        type=int,
        default=2000000,
        help="maximum failed uncovered masks retained; <=0 is unlimited",
    )

    pc = sub.add_parser("verify-candidate")
    add_common(pc)
    pc.add_argument("candidate")

    pp = sub.add_parser("verify-proof")
    add_common(pp)
    add_enumeration_options(pp)
    pp.add_argument("proof")

    args = parser.parse_args()
    limits = Limits(args.time_limit)

    try:
        if args.mode == "solve":
            return solve(args, limits)
        if args.mode == "verify-candidate":
            return verify_candidate(args, limits)
        return verify_proof(args, limits)

    except StopRun as exc:
        print(
            "[result] stopped without a complete conclusion:",
            str(exc),
            flush=True,
        )
        print("STATUS: UNKNOWN/TIME_LIMIT", flush=True)
        return 2

    except MemoryError:
        print(
            "[result] memory exhausted without a complete conclusion",
            flush=True,
        )
        print("STATUS: UNKNOWN/TIME_LIMIT", flush=True)
        return 2


if __name__ == "__main__":
    sys.exit(main())
