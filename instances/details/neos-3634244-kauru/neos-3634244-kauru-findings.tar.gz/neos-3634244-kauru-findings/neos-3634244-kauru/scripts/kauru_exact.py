#!/usr/bin/env python3
"""
Exact threshold decision search for neos-3634244-kauru.

Modes:
  solve   Parse the original MPS, recover the conflict graph, run a complete
          canonical 25-color search, and write:
            - kauru_candidate.sol if feasible; or
            - kauru_unsat.proof if infeasible.
  verify  Parse the MPS again and independently replay/verify an UNSAT proof.

The proof is a complete deterministic search tree:
  B v c1 c2 ...   branch on vertex v, with exactly these legal canonical colors
  P               prune because the current state is independently recognized
                  as impossible by one of the verifier's sound tests

The verifier recomputes the selected vertex, legal branches, and every prune.
Thus a truncated tree, omitted branch, or invalid prune is rejected.

No Gurobi optimization is performed. Gurobi is used only to read the MPS.
"""

import argparse
import hashlib
import json
import os
import sys
import time

import gurobipy as gp
from gurobipy import GRB

THRESHOLD = 1397.4872804
N = 175
K = 25
CAP = 7
ALL = (1 << N) - 1


def bit_vertices(mask):
    while mask:
        b = mask & -mask
        yield b.bit_length() - 1
        mask ^= b


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(1 << 20)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def recover(mps_path, threshold):
    print("[recover] reading:", mps_path, flush=True)
    model = gp.read(mps_path)
    model.update()

    vars_ = model.getVars()
    rows = model.getConstrs()
    print("[recover] variables:", len(vars_),
          "constraints:", len(rows), flush=True)

    binaries = [v for v in vars_ if v.VType in (GRB.BINARY, "B")]
    continuous = [v for v in vars_ if v not in binaries]

    if len(binaries) != 4375:
        raise RuntimeError("expected 4375 binaries, got %d" % len(binaries))
    if len(continuous) != 1:
        raise RuntimeError("expected one nonbinary variable, got %d"
                           % len(continuous))

    tvar = continuous[0]
    print("[recover] objective variable:", tvar.VarName,
          "obj =", tvar.Obj, flush=True)

    # Recover entity groups from the 175 degree-25 assignment equalities.
    entity_groups = []
    capacity_groups = []

    for r in rows:
        rr = model.getRow(r)
        terms = [(rr.getVar(i), rr.getCoeff(i))
                 for i in range(rr.size())]

        if r.Sense == GRB.EQUAL and len(terms) == 25:
            if abs(r.RHS - 1.0) <= 1e-9 and all(
                    v in binaries and abs(a - 1.0) <= 1e-9
                    for v, a in terms):
                entity_groups.append([v for v, _ in terms])

        elif r.Sense == GRB.LESS_EQUAL and len(terms) == 175:
            if abs(r.RHS - 7.0) <= 1e-9 and all(
                    v in binaries and abs(a - 1.0) <= 1e-9
                    for v, a in terms):
                capacity_groups.append([v for v, _ in terms])

    if len(entity_groups) != N:
        raise RuntimeError("expected 175 assignment rows, got %d"
                           % len(entity_groups))
    if len(capacity_groups) != K:
        raise RuntimeError("expected 25 capacity rows, got %d"
                           % len(capacity_groups))

    # Use deterministic row-independent ordering.
    entity_groups.sort(key=lambda g: min(v.index for v in g))
    capacity_groups.sort(key=lambda g: min(v.index for v in g))

    entity_of = {}
    for i, group in enumerate(entity_groups):
        if len(set(group)) != K:
            raise RuntimeError("duplicate binary in entity row")
        for v in group:
            if v in entity_of:
                raise RuntimeError("binary appears in multiple entity rows")
            entity_of[v] = i

    color_of = {}
    for k, group in enumerate(capacity_groups):
        if len(set(group)) != N:
            raise RuntimeError("duplicate binary in capacity row")
        for v in group:
            if v in color_of:
                raise RuntimeError("binary appears in multiple capacity rows")
            color_of[v] = k

    if set(entity_of) != set(binaries) or set(color_of) != set(binaries):
        raise RuntimeError("assignment/capacity rows do not cover binaries")

    xvar = [[None] * K for _ in range(N)]
    for v in binaries:
        i, k = entity_of[v], color_of[v]
        if xvar[i][k] is not None:
            raise RuntimeError("duplicate entity/color variable")
        xvar[i][k] = v

    if any(xvar[i][k] is None for i in range(N) for k in range(K)):
        raise RuntimeError("incomplete 175 x 25 assignment matrix")

    # Recover max directed cost for every unordered pair.
    pair_cost = [[float("-inf")] * N for _ in range(N)]
    epi_rows = 0
    bad_epi = 0
    nearest = None

    for r in rows:
        rr = model.getRow(r)
        if rr.size() != 3 or r.Sense != GRB.LESS_EQUAL:
            continue

        tvcoef = None
        bs = []
        for z in range(3):
            v = rr.getVar(z)
            a = rr.getCoeff(z)
            if v is tvar:
                tvcoef = a
            elif v in entity_of:
                bs.append((v, a))

        if tvcoef is None or len(bs) != 2:
            continue
        if abs(tvcoef + 1.0) > 1e-8:
            bad_epi += 1
            continue

        v1, a1 = bs[0]
        v2, a2 = bs[1]
        i, j = entity_of[v1], entity_of[v2]
        k1, k2 = color_of[v1], color_of[v2]

        if i == j or k1 != k2:
            bad_epi += 1
            continue
        if abs(a1 - a2) > 1e-7 or abs(a1 - r.RHS) > 1e-7:
            bad_epi += 1
            continue

        d = max(a1, a2, r.RHS)
        if i > j:
            i, j = j, i
        if d > pair_cost[i][j]:
            pair_cost[i][j] = d
        epi_rows += 1

        gap = abs(d - threshold)
        if nearest is None or gap < nearest[0]:
            nearest = (gap, d, r.ConstrName)

    if epi_rows != 761250:
        raise RuntimeError("expected 761250 epigraph rows, got %d"
                           % epi_rows)
    if bad_epi:
        raise RuntimeError("%d malformed candidate epigraph rows" % bad_epi)

    missing = [(i, j) for i in range(N) for j in range(i + 1, N)
               if pair_cost[i][j] == float("-inf")]
    if missing:
        raise RuntimeError("missing costs for %d unordered pairs" % len(missing))

    print("[recover] epigraph rows:", epi_rows, flush=True)
    print("[recover] nearest row coefficient to threshold:",
          nearest, flush=True)

    # Equality with threshold is legal. Abort only for suspicious nonzero gaps.
    if nearest and 0.0 < nearest[0] < 1e-7:
        raise RuntimeError(
            "coefficient lies within 1e-7 of threshold but is not equal; "
            "audit original decimal MPS tokens before classifying it")

    adj = [0] * N
    edges = 0
    maxcost = float("-inf")
    below = float("-inf")
    above = float("inf")

    for i in range(N):
        for j in range(i + 1, N):
            d = pair_cost[i][j]
            maxcost = max(maxcost, d)
            if d <= threshold:
                below = max(below, d)
            else:
                above = min(above, d)
                adj[i] |= 1 << j
                adj[j] |= 1 << i
                edges += 1

    print("[graph] threshold:", repr(threshold), flush=True)
    print("[graph] conflict edges:", edges,
          "density:", 2.0 * edges / (N * (N - 1)), flush=True)
    print("[graph] greatest allowed cost:", repr(below), flush=True)
    print("[graph] least forbidden cost:", repr(above), flush=True)
    print("[graph] maximum cost:", repr(maxcost), flush=True)

    degrees = [adj[i].bit_count() for i in range(N)]
    print("[graph] degree min/avg/max:",
          min(degrees), sum(degrees) / N, max(degrees), flush=True)

    names = [[xvar[i][k].VarName for k in range(K)] for i in range(N)]
    return model, tvar.VarName, names, adj


class Search:
    def __init__(self, adj, proof_file=None, progress_every=100000):
        self.adj = adj
        self.deg = [a.bit_count() for a in adj]
        self.assign = [-1] * N
        self.cmask = [0] * K
        self.csize = [0] * K
        self.used = 0
        self.unassigned = ALL
        self.nodes = 0
        self.started = time.time()
        self.proof = proof_file
        self.progress_every = progress_every
        self.solution = None

    def legal_colors(self, v):
        out = []
        for c in range(self.used):
            if self.csize[c] < CAP and not (self.cmask[c] & self.adj[v]):
                out.append(c)
        if self.used < K:
            out.append(self.used)       # only canonical new color
        return out

    def saturation(self, v):
        s = 0
        av = self.adj[v]
        for c in range(self.used):
            if self.cmask[c] & av:
                s += 1
        return s

    def choose_vertex(self):
        best = None
        best_legal = None
        for v in bit_vertices(self.unassigned):
            legal = self.legal_colors(v)
            key = (len(legal), -self.saturation(v), -self.deg[v], v)
            if best is None or key < best:
                best = key
                best_legal = legal
        return best[3], best_legal

    def sound_prune(self):
        remaining = self.unassigned.bit_count()

        # There must be enough total room in the 25 clusters.
        free = sum(CAP - self.csize[c] for c in range(self.used))
        free += (K - self.used) * CAP
        if free < remaining:
            return True

        # Existing partially filled cluster c still needs need vertices.
        # Every added vertex must be nonadjacent to all current members.
        for c in range(self.used):
            need = CAP - self.csize[c]
            if need:
                compatible = self.unassigned
                for u in bit_vertices(self.cmask[c]):
                    compatible &= ~self.adj[u]
                compatible &= ALL
                if compatible.bit_count() < need:
                    return True

        # Even if all remaining colors were introduced, no vertex may have
        # an empty legal canonical domain at the point it is selected.
        if remaining:
            v, legal = self.choose_vertex()
            if not legal:
                return True

        return False

    def put(self, v, c):
        new = (c == self.used)
        if new:
            self.used += 1
        self.assign[v] = c
        self.cmask[c] |= 1 << v
        self.csize[c] += 1
        self.unassigned &= ~(1 << v)
        return new

    def undo(self, v, c, new):
        self.unassigned |= 1 << v
        self.csize[c] -= 1
        self.cmask[c] &= ~(1 << v)
        self.assign[v] = -1
        if new:
            if self.csize[c] != 0 or c != self.used - 1:
                raise AssertionError("bad canonical undo")
            self.used -= 1

    def dfs(self):
        self.nodes += 1
        if self.nodes % self.progress_every == 0:
            elapsed = time.time() - self.started
            print("[search] nodes=%d elapsed=%.1fs rate=%.1f/s "
                  "assigned=%d used=%d" %
                  (self.nodes, elapsed, self.nodes / max(elapsed, 1e-9),
                   N - self.unassigned.bit_count(), self.used),
                  flush=True)

        if not self.unassigned:
            if self.used == K and all(s == CAP for s in self.csize):
                self.solution = self.assign[:]
                return True
            if self.proof:
                self.proof.write("P\n")
            return False

        if self.sound_prune():
            if self.proof:
                self.proof.write("P\n")
            return False

        v, legal = self.choose_vertex()
        if self.proof:
            self.proof.write("B %d %s\n" %
                             (v, " ".join(map(str, legal))))

        for c in legal:
            new = self.put(v, c)
            if self.dfs():
                return True
            self.undo(v, c, new)
        return False


def write_solution(path, tname, names, assignment, threshold):
    with open(path, "w", newline="\n") as f:
        f.write("# feasible threshold partition generated by kauru_exact.py\n")
        f.write("%s %.17g\n" % (tname, threshold))
        for i in range(N):
            for k in range(K):
                f.write("%s %d\n" % (names[i][k],
                                     1 if assignment[i] == k else 0))
    print("[result] wrote candidate:", path, flush=True)


class ProofVerifier(Search):
    def __init__(self, adj, proof):
        super().__init__(adj, proof_file=None, progress_every=10**18)
        self.fp = proof
        self.lines = 0

    def getline(self):
        line = self.fp.readline()
        if not line:
            raise RuntimeError("unexpected end of proof")
        self.lines += 1
        if self.lines % 100000 == 0:
            print("[verify] proof records:", self.lines, flush=True)
        return line.strip()

    def verify_node(self):
        line = self.getline()

        if line == "P":
            if not self.unassigned:
                if self.used == K and all(s == CAP for s in self.csize):
                    raise RuntimeError("proof prunes a feasible complete state")
                return
            if not self.sound_prune():
                raise RuntimeError("invalid prune at proof line %d" % self.lines)
            return

        tok = line.split()
        if not tok or tok[0] != "B":
            raise RuntimeError("unknown proof record at line %d" % self.lines)
        if not self.unassigned:
            raise RuntimeError("branch below complete state")

        if self.sound_prune():
            raise RuntimeError("branch record used where P was required")

        v, legal = self.choose_vertex()
        pv = int(tok[1])
        pc = list(map(int, tok[2:]))
        if pv != v or pc != legal:
            raise RuntimeError(
                "branch mismatch at line %d: expected B %d %s, got %s" %
                (self.lines, v, " ".join(map(str, legal)), line))

        for c in legal:
            new = self.put(v, c)
            self.verify_node()
            self.undo(v, c, new)


def solve(args):
    model, tname, names, adj = recover(args.mps, args.threshold)
    del model

    meta = {
        "format": "kauru-canonical-tree-v1",
        "mps_sha256": sha256_file(args.mps),
        "threshold": args.threshold,
        "vertices": N,
        "colors": K,
        "capacity": CAP,
    }

    tmp = args.proof + ".tmp"
    with open(tmp, "w", buffering=1, newline="\n") as pf:
        pf.write("# " + json.dumps(meta, sort_keys=True) + "\n")
        search = Search(adj, proof_file=pf,
                        progress_every=args.progress_every)
        feasible = search.dfs()

    elapsed = time.time() - search.started
    print("[search] finished nodes=%d elapsed=%.3fs" %
          (search.nodes, elapsed), flush=True)

    if feasible:
        os.remove(tmp)
        write_solution(args.solution, tname, names,
                       search.solution, args.threshold)
        print("[result] FEASIBLE at threshold", repr(args.threshold))
        print("[result] this disproves threshold infeasibility; it does not "
              "by itself prove global optimality")
        return 0

    os.replace(tmp, args.proof)
    print("[result] INFEASIBLE by complete canonical search")
    print("[result] proof:", args.proof)
    print("[result] run verify mode before treating this as established")
    return 0


def verify(args):
    _, _, _, adj = recover(args.mps, args.threshold)

    with open(args.proof, "r", newline="") as pf:
        header = pf.readline()
        if not header.startswith("# "):
            raise RuntimeError("missing proof metadata")
        meta = json.loads(header[2:])

        expected_hash = sha256_file(args.mps)
        if meta.get("mps_sha256") != expected_hash:
            raise RuntimeError("proof belongs to a different MPS file")
        if meta.get("threshold") != args.threshold:
            raise RuntimeError("proof threshold mismatch")
        if (meta.get("vertices"), meta.get("colors"), meta.get("capacity")) != \
                (N, K, CAP):
            raise RuntimeError("proof dimension mismatch")

        verifier = ProofVerifier(adj, pf)
        verifier.verify_node()

        extra = pf.read().strip()
        if extra:
            raise RuntimeError("trailing records after complete proof tree")

    print("[verify] VALID complete infeasibility proof")
    print("[verify] threshold", repr(args.threshold),
          "has no partition into 25 independent sets of size 7")
    return 0


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="mode", required=True)

    ps = sub.add_parser("solve")
    ps.add_argument("mps")
    ps.add_argument("--threshold", type=float, default=THRESHOLD)
    ps.add_argument("--proof", default="kauru_unsat.proof")
    ps.add_argument("--solution", default="kauru_candidate.sol")
    ps.add_argument("--progress-every", type=int, default=100000)

    pv = sub.add_parser("verify")
    pv.add_argument("mps")
    pv.add_argument("proof")
    pv.add_argument("--threshold", type=float, default=THRESHOLD)

    args = ap.parse_args()
    return solve(args) if args.mode == "solve" else verify(args)


if __name__ == "__main__":
    sys.exit(main())
