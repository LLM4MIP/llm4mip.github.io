# `neos-3634244-kauru`

## Result

Status: **open; strict feasible solution reconstructed**.

A strictly integral solution of objective **1398.0156859** was reconstructed
from the public incumbent and checked against all 761,450 rows of the untouched
MPS with zero bound, integrality, and row violation. The established statement
is therefore

```text
OPT <= 1398.0156859.
```

No new global lower bound or optimality certificate was obtained. In
particular, the lower-threshold search at `1397.4872804` did not terminate.

[MIPLIB instance page](https://miplib.zib.de/instance_details_neos-3634244-kauru.html)

## Recovered structure and methods

The problem is an equitable minimax clustering instance: assign 175 entities
to 25 interchangeable clusters of exactly seven and minimize the largest of
two directed costs for any co-clustered pair. At threshold `1397.4872804`, it
is a 25-coloring of a 175-vertex conflict graph with 7,725 edges.

Two custom exact routes were executed without generic MIP optimization:

1. A restricted-growth canonical coloring search removed the 25! cluster-label
   symmetry and explored 700,000 nodes in 568.3 seconds. Its partial trace is
   not a certificate.
2. An exact-cover route enumerated more than five million independent
   seven-sets in about 11 seconds and hit its memory guard, showing that
   explicit column materialization is unsuitable here.

## Evidence

- [`solutions/rounded-public-strict.sol`](solutions/rounded-public-strict.sol)
  is the accepted solution.
- [`artifacts/rounded-public-strict.audit.json`](artifacts/rounded-public-strict.audit.json)
  is its complete original-MPS audit.
- [`structure/recovered_model.json`](structure/recovered_model.json) records
  the verified clustering reconstruction and all pair costs.
- [`scripts/kauru_exact_v2.py`](scripts/kauru_exact_v2.py) and
  [`scripts/kauru_sat.py`](scripts/kauru_sat.py) implement the two custom routes.
- [`reports/final_report.md`](reports/final_report.md) and
  [`logs/run-summary.md`](logs/run-summary.md) document the run.

The incomplete `.proof.tmp`, raw API exchanges, and runtime session files are
intentionally omitted. They establish no result.

SHA-256:

- MPS: `E805D533F2216A6BA683E186B730C517CBD22425F730077D51269CA9C03AD87F`
- strict solution: `596F7BBE42169478855F35DD48C9BE132ABB7CA9C71245AC9AD4F0A42CAF80AD`
