# neos-3634244-kauru - final research report

## Outcome

The instance remains **open** after 87.2 minutes of instance-specific research.
No global-optimality claim is made.

A strict integral feasible solution with objective **1398.0156859** was
independently reconstructed and checked against every row of the untouched
official MPS. The audit found zero bound, integrality, or constraint violation.
The file is `solutions/rounded-public-strict.sol`, and the full checker record is
`artifacts/rounded-public-strict.audit.json`.

The exact lower decision still required for an optimality proof is
infeasibility at **1397.4872804**. Neither executed custom route completed that
proof.

## Recovered problem

Gurobi was used only as a read-only MPS parser. The formulation is an equitable
minimax clustering problem:

- assign 175 entities to 25 interchangeable clusters;
- each cluster contains exactly seven entities;
- the objective is the maximum of two directed costs for any co-clustered pair.

For a threshold T this is a 25-coloring of a 175-vertex conflict graph with
classes of exactly seven. At T=1397.4872804 the graph has 7,725 edges (density
0.507389), degree range 47-127. The next higher effective pair cost is exactly
1398.0156859, so UNSAT at the lower threshold plus the verified incumbent would
be sufficient for optimality.

## Methods actually executed

1. **Canonical graph-coloring proof search.** The API designed a restricted-
   growth color naming scheme to remove the full 25! label symmetry, with
   compatibility and bipartite residual-capacity matching prunes. After direct
   feedback fixed its incorrect assumption about MPS `I` versus `B` types, the
   corrected program processed 700,000 nodes in 568.3 seconds. It did not
   terminate; its `.proof.tmp` is not a certificate.

2. **Independent-seven-set exact cover.** The second API-designed route removes
   cluster labels completely and would branch over all feasible clusters.
   Exhaustive enumeration passed five million independent seven-sets in about
   11 seconds and hit the deliberate memory guard before completion. It is not
   viable as an explicitly materialized model on this graph.

3. **PySAT/value-precedence design request.** The failed exact-cover observation
   was supplied to a third stateful API segment. The endpoint did not return a
   nonempty completion, so no SAT implementation was invented or counted as an
   executed result.

No general-purpose MIP optimization was run. The work therefore stayed within
the 30-minute solver cap and did not reduce the study to solver tuning.

## Evidence and limitations

- `structure/gurobi_structure.json`: generic read-only structure dump.
- `structure/recovered_model.json`: verified combinatorial recovery and all
  pair costs.
- Raw API prompts, responses, and session state were retained only in the local
  research workspace and are deliberately omitted from this publication copy.
- `scripts/kauru_exact_v2.py`: corrected canonical search and proof verifier.
- `scripts/kauru_sat.py`: exact-cover route and verifier.
- `logs/run-summary.md`: chronological execution observations.

The strongest verified statement is only

`OPT <= 1398.0156859`.

The incomplete search does not establish a new lower bound. A promising next
step is a non-materialized SAT/PB encoding with value-precedence symmetry
breaking and a proof-producing CaDiCaL backend, followed by independent DRAT or
LRAT verification. This should be resumed from the recorded threshold graph,
not by rerunning generic MIP parameter sweeps.

## Sources

- MIPLIB instance page:
  https://miplib.zib.de/instance_details_neos-3634244-kauru.html
- MIPLIB download/checker documentation: https://miplib.zib.de/download.html
- TU Darmstadt MIPLIB symmetry census:
  https://wwwopt.mathematik.tu-darmstadt.de/~pfetsch/symmetries/miplib2017-presol-symmetries.pdf
- Matrix/Instance Collection: https://mic.optimatorlab.org/instances/index.html
