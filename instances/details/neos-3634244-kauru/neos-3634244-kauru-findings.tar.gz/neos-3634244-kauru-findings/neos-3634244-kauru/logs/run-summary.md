# Execution log summary

All timestamps are Asia/Shanghai on 2026-09-09. Raw API responses are omitted
from the publication copy; this file records only observations actually seen
from executions, and the accepted generated programs are retained under
`scripts/`.

## 01:30-01:35: acquisition and structural recovery

- Downloaded the official 15,573,466-byte MPS from MIPLIB.
- `extract_gurobi_structure.py` read it with Gurobi 13.0.2 without presolve or
  optimization: 4,376 variables, 761,450 rows, 2,292,500 nonzeros.
- `recover_model.py` verified all 175 assignment rows, 25 capacity rows, and
  761,250 epigraph rows. No malformed rows were found.

## 01:35-01:54: API design and repair

- Two long initial API attempts returned empty content and were not committed.
- A bounded low-effort request succeeded and designed a canonical capacitated
  graph-coloring proof search (the accepted implementation is under `scripts/`).
- First execution failed before search because the API assumed Gurobi would
  label [0,1] integer columns as `B`; the MPS imports them as `I`.
- The observation was fed back. A stateful API repair audited variable identity
  use and generated the full corrected program `kauru_exact_v2.py`.

## 01:54-02:04: route 1 - canonical graph-coloring proof search

- Threshold graph: 7,725 conflict edges, density 0.5073891626, degrees 47-127.
- `kauru_exact_v2.py` verified graph SHA-256
  `bfb674b9e3a504468278da0aae3b84b9ca8937c02d36f7b26c0fba18090a14d7`.
- It explored 700,000 nodes in 568.3 seconds (~1,232 nodes/s).
- Observed prunes at that point: 92,677 cluster-compatibility and 257,074
  matching-capacity prunes.
- The run was interrupted as planned to leave time for a distinct route. The
  resulting `kauru_unsat_v2.proof.tmp` is incomplete and is explicitly not a
  certificate.

## 02:04-02:08: route 2 - explicit independent-seven-set exact cover

- The first-route observations were sent back to the same API session.
- API generated `kauru_sat.py`, an exhaustive independent-seven-set enumerator
  plus exact-cover proof search.
- Enumeration exceeded the explicit 5,000,000-set safety limit in about 11
  seconds, before completion. It returned `STATUS: UNKNOWN/TIME_LIMIT` and did
  not emit a candidate or proof. This falsified the assumption that explicit
  column materialization would be compact enough.

## 02:08-02:57: third-route design attempt and independent incumbent audit

- A stateful PySAT/value-precedence request was submitted after feeding back the
  >5,000,000-set observation. That segment did not produce a committed nonempty
  response, so it is not represented as a completed method.
- The official solution ID 2 was downloaded, integral variables were rounded,
  and the epigraph was raised from the tolerance-affected displayed value to
  the exact active pair coefficient 1398.0156859.
- `common_audit_solution.py` evaluated all 761,450 original rows and all 4,376
  original variables: maximum bound, integrality, and row violations were all
  exactly 0.0 in double-precision evaluation.

No call to `Model.optimize()` was made. General-purpose solver optimization
time was therefore 0 minutes, below the 30-minute cap.
