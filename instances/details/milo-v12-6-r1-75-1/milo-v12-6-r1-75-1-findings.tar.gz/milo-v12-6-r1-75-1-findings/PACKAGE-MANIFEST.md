# Package manifest: milo-v12-6-r1-75-1

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 15
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/disaggregated-formulation-comparison.json`
- `artifacts/gurobi-global-300s.json`
- `artifacts/gurobi-global-900s.json`
- `artifacts/neighborhood-audit.json`
- `artifacts/neighborhood-top5000.json`
- `input/SHA256SUMS`
- `logs/gurobi-global-300s.log`
- `logs/gurobi-global-900s.log`
- `scripts/build_augmented_hull.py`
- `scripts/build_convex_hull.py`
- `scripts/milo_neighborhood.py`
- `scripts/run_convex_hull.py`
- `scripts/run_global_gurobi.py`
- `solutions/milo-v12-6-r1-75-1-public-3.sol.gz`

## Excluded files

- `input/milo-v12-6-r1-75-1.mps.gz (202481 bytes; raw benchmark input; sha256 6a8c835e832d473566a9920d1fd5eae6ac2f4a9f26fdaeaee610246fac2b83b7)`
