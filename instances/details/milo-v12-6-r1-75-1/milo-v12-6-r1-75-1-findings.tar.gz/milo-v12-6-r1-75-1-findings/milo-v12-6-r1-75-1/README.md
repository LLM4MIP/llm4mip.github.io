# milo-v12-6-r1-75-1 — 2.4138% numerical gap and neighborhood study

Official MIPLIB page: <https://miplib.zib.de/instance_details_milo-v12-6-r1-75-1.html>

## Current result

The public design retains objective **1,153,756.398205675**. A 900-second
Gurobi run reached numerical lower bound **1,125,907.0416245167**, leaving a
**2.4138%** gap. No better feasible solution and no global proof were found.

## Recovered design structure

The model is a two-dimensional cantilever sizing problem with 385 structural
members. Each member chooses one of six cross-section levels:

```text
2, 10, 25, 100, 200, 500.
```

The public design uses 149, 84, 10, 44, 56, and 42 members at these respective
levels. Its objective was recomputed as 1,153,756.3982056752; the largest
floating-point row residual was `2.09e-12`, with no reported bound or
integrality violation.

## Fixed-topology experiments

After fixing the discrete member sizes, the remaining recourse problem is an
LP. This provides an inexpensive oracle for physically meaningful local moves.

- All 236 possible one-level member decreases were tested; Gurobi classified
  every fixed-topology LP as infeasible.
- There are 43,512 nominally improving one-down/one-up exchanges.
- The 5,000 exchanges with the largest nominal savings were tested; every
  fixed-topology LP was classified infeasible.

These are numerical LP results. They do not exclude the remaining 38,512
exchanges, multi-member changes, or any unrestricted global improvement.

## Global and reformulation runs

With the public solution as a start and priority on the cumulative size
variables, Gurobi 13.0.2 produced:

| Limit | Incumbent | Numerical lower bound | Gap | Nodes |
|---:|---:|---:|---:|---:|
| 300 s | 1,153,756.398205675 | 1,122,560.6482495745 | 2.7038% | 100,438 |
| 900 s | 1,153,756.398205675 | 1,125,907.0416245167 | 2.4138% | 208,913 |

Two exact local disaggregation formulations were also built: replacement of
the cumulative product linearization, and a redundant augmented version. Both
gave weaker short-run bounds and were stopped. The negative comparison is kept
in [`disaggregated-formulation-comparison.json`](artifacts/disaggregated-formulation-comparison.json).

## Reproduction

The experiments require Gurobi and a valid license:

```sh
python instances/milo-v12-6-r1-75-1/scripts/milo_neighborhood.py \
  instances/milo-v12-6-r1-75-1/input/milo-v12-6-r1-75-1.mps.gz \
  instances/milo-v12-6-r1-75-1/solutions/milo-v12-6-r1-75-1-public-3.sol.gz \
  --output neighborhood-top5000.json --max-pairs 5000
```

Input hashes are recorded in [`input/SHA256SUMS`](input/SHA256SUMS).
