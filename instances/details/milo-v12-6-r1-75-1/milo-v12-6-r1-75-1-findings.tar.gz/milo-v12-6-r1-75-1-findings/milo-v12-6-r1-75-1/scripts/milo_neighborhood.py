#!/usr/bin/env python3
"""Audit the public design and solve fixed-topology LP neighborhoods."""

from __future__ import annotations

import argparse
from collections import Counter
import gzip
import json
import math
from pathlib import Path
import re

import gurobipy as gp
from gurobipy import GRB


Z_PATTERN = re.compile(r"z_(\d+)_(\d+)$")


def read_values(path: Path) -> tuple[float | None, dict[str, float]]:
    opener = gzip.open if path.suffix == ".gz" else open
    declared = None
    values: dict[str, float] = {}
    with opener(path, "rt", errors="replace") as stream:
        for raw in stream:
            fields = raw.split()
            if len(fields) < 2:
                continue
            if fields[0] == "=obj=":
                declared = float(fields[1])
                continue
            try:
                values[fields[0]] = float(fields[1])
            except ValueError:
                pass
    return declared, values


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--max-pairs", type=int, default=0)
    args = parser.parse_args()

    declared, values = read_values(args.solution)
    model = gp.read(str(args.model))
    model.Params.OutputFlag = 0
    model.Params.Threads = 4
    model.Params.Method = 1
    model.Params.Presolve = 2
    model.Params.NumericFocus = 2
    model.Params.FeasibilityTol = 1e-8

    variables = model.getVars()
    value_vector = [values.get(var.VarName, 0.0) for var in variables]
    computed_objective = sum(var.Obj * value_vector[var.index] for var in variables) + model.ObjCon
    max_bound_violation = 0.0
    max_integrality_violation = 0.0
    for var, value in zip(variables, value_vector):
        max_bound_violation = max(max_bound_violation, var.LB - value, value - var.UB)
        if var.VType != GRB.CONTINUOUS:
            max_integrality_violation = max(max_integrality_violation, abs(value - round(value)))
    max_constraint_violation = 0.0
    for constraint in model.getConstrs():
        expression = model.getRow(constraint)
        activity = sum(
            expression.getCoeff(position) * value_vector[expression.getVar(position).index]
            for position in range(expression.size())
        )
        if constraint.Sense == "<":
            violation = activity - constraint.RHS
        elif constraint.Sense == ">":
            violation = constraint.RHS - activity
        else:
            violation = abs(activity - constraint.RHS)
        max_constraint_violation = max(max_constraint_violation, violation)

    z_variables = {
        (int(match.group(1)), int(match.group(2))): var
        for var in variables
        if (match := Z_PATTERN.fullmatch(var.VarName))
    }
    member_count = max(index for index, _ in z_variables) + 1
    levels_per_member = max(level for _, level in z_variables) + 1
    if len(z_variables) != member_count * levels_per_member:
        raise RuntimeError("incomplete rectangular z index set")
    patterns = {
        index: tuple(round(values.get(f"z_{index}_{level}", 0.0)) for level in range(levels_per_member))
        for index in range(member_count)
    }
    if any(pattern != (1,) * sum(pattern) + (0,) * (levels_per_member - sum(pattern)) for pattern in patterns.values()):
        raise RuntimeError("public solution violates cumulative level encoding")
    current_level = {index: sum(pattern) for index, pattern in patterns.items()}

    increments = None
    for index in range(member_count):
        constraint = model.getConstrByName(f"x{index}")
        if constraint is None or constraint.Sense != "=":
            raise RuntimeError(f"missing size equation x{index}")
        expression = model.getRow(constraint)
        found = [
            expression.getCoeff(position)
            for position in range(expression.size())
            if expression.getVar(position).VarName.startswith(f"z_{index}_")
        ]
        if increments is None:
            increments = tuple(found)
        elif tuple(found) != increments:
            raise RuntimeError("member size increments are inconsistent")
    assert increments is not None
    base_size = -model.getConstrByName("x0").RHS
    size_levels = [base_size + sum(increments[:level]) for level in range(levels_per_member + 1)]

    for (index, level), var in z_variables.items():
        fixed = patterns[index][level]
        var.LB = fixed
        var.UB = fixed
    model.update()
    model.optimize()
    if model.Status != GRB.OPTIMAL:
        raise RuntimeError("public topology did not yield feasible continuous recourse")
    fixed_topology_objective = model.ObjVal

    one_down = []
    for index in range(member_count):
        level = current_level[index]
        if level == 0:
            continue
        changed = z_variables[index, level - 1]
        changed.LB = 0.0
        changed.UB = 0.0
        model.update()
        model.optimize()
        feasible = model.Status == GRB.OPTIMAL
        one_down.append(
            {
                "member": index,
                "from_level": level,
                "to_level": level - 1,
                "status": int(model.Status),
                "feasible": feasible,
                "objective": model.ObjVal if feasible else None,
            }
        )
        changed.LB = 1.0
        changed.UB = 1.0

    objective_weight = {index: model.getVarByName(f"x_{index}").Obj for index in range(member_count)}
    pair_candidates = []
    for down in range(member_count):
        down_level = current_level[down]
        if down_level == 0:
            continue
        saving = objective_weight[down] * increments[down_level - 1]
        for up in range(member_count):
            up_level = current_level[up]
            if up == down or up_level == levels_per_member:
                continue
            cost = objective_weight[up] * increments[up_level]
            if cost + 1e-9 < saving:
                pair_candidates.append((saving - cost, down, up))
    pair_candidates.sort(reverse=True)

    pair_tests = []
    best_pair = None
    for nominal_saving, down, up in pair_candidates[: args.max_pairs]:
        down_level = current_level[down]
        up_level = current_level[up]
        down_var = z_variables[down, down_level - 1]
        up_var = z_variables[up, up_level]
        down_var.LB = down_var.UB = 0.0
        up_var.LB = up_var.UB = 1.0
        model.update()
        model.optimize()
        feasible = model.Status == GRB.OPTIMAL
        objective = model.ObjVal if feasible else None
        record = {
            "down": down,
            "up": up,
            "nominal_saving": nominal_saving,
            "status": int(model.Status),
            "feasible": feasible,
            "objective": objective,
        }
        pair_tests.append(record)
        if feasible and objective < fixed_topology_objective - 1e-6:
            if best_pair is None or objective < best_pair[0]:
                best_pair = (objective, down, up)
        down_var.LB = down_var.UB = 1.0
        up_var.LB = up_var.UB = 0.0

    report = {
        "instance": "milo-v12-6-r1-75-1",
        "model_counts": {
            "variables": model.NumVars,
            "constraints": model.NumConstrs,
            "nonzeros": model.NumNZs,
            "members": member_count,
            "levels_per_member": levels_per_member,
        },
        "public_solution_audit": {
            "declared_objective": declared,
            "computed_objective": computed_objective,
            "objective_mismatch": abs((declared or computed_objective) - computed_objective),
            "max_bound_violation": max(0.0, max_bound_violation),
            "max_integrality_violation": max_integrality_violation,
            "max_constraint_violation": max(0.0, max_constraint_violation),
        },
        "discrete_design": {
            "base_size": base_size,
            "increments": increments,
            "size_levels": size_levels,
            "level_histogram": dict(sorted(Counter(current_level.values()).items())),
        },
        "fixed_topology_objective": fixed_topology_objective,
        "one_step_down_tests": len(one_down),
        "feasible_one_step_downs": [record for record in one_down if record["feasible"]],
        "improving_pair_candidates": len(pair_candidates),
        "pair_tests_run": len(pair_tests),
        "feasible_pair_tests": sum(record["feasible"] for record in pair_tests),
        "improving_pair_tests": sum(record["feasible"] and record["objective"] < fixed_topology_objective - 1e-6 for record in pair_tests),
        "best_pair": best_pair,
        "pair_test_records": pair_tests,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in report.items() if key != "pair_test_records"}, indent=2))


if __name__ == "__main__":
    main()
