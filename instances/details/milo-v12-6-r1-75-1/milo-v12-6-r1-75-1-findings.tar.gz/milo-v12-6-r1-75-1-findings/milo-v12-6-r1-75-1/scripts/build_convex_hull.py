#!/usr/bin/env python3
"""Build an exact disaggregated convex-hull formulation of the six size choices."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


SIZES = (2.0, 10.0, 25.0, 100.0, 200.0, 500.0)
GLOBAL_STRESS = 2.76


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("--output-model", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    args = parser.parse_args()

    model = gp.read(str(args.model))
    member_count = sum(var.VarName.startswith("x_") for var in model.getVars())
    if member_count != 385:
        raise RuntimeError(f"unexpected member count: {member_count}")

    weights = [model.getVarByName(f"x_{index}").Obj for index in range(member_count)]
    compression = []
    removable_names = {
        var.VarName
        for var in model.getVars()
        if var.VarName.startswith(("x_", "z_", "phi_"))
    }
    constraints_to_remove = []
    for constraint in model.getConstrs():
        expression = model.getRow(constraint)
        names = {expression.getVar(position).VarName for position in range(expression.size())}
        if not names.isdisjoint(removable_names):
            constraints_to_remove.append(constraint)
        for index in range(member_count):
            if names == {f"x_{index}", f"sigma_{index}"}:
                x_coefficient = next(
                    expression.getCoeff(position)
                    for position in range(expression.size())
                    if expression.getVar(position).VarName == f"x_{index}"
                )
                sigma_coefficient = next(
                    expression.getCoeff(position)
                    for position in range(expression.size())
                    if expression.getVar(position).VarName == f"sigma_{index}"
                )
                if constraint.Sense == "<" and constraint.RHS == 0 and sigma_coefficient == -1:
                    compression.append((index, -x_coefficient))
    compression_by_member = dict(compression)
    if set(compression_by_member) != set(range(member_count)):
        raise RuntimeError("failed to recover every compression coefficient")

    variables_to_remove = [var for var in model.getVars() if var.VarName in removable_names]
    model.remove(constraints_to_remove)
    model.remove(variables_to_remove)
    model.update()

    y = {}
    stress_piece = {}
    for index in range(member_count):
        for level, size in enumerate(SIZES):
            y[index, level] = model.addVar(
                vtype=GRB.BINARY,
                obj=weights[index] * size,
                name=f"y_{index}_{level}",
            )
            lower = max(-GLOBAL_STRESS, -compression_by_member[index] * size)
            stress_piece[index, level] = model.addVar(
                lb=lower,
                ub=GLOBAL_STRESS,
                obj=0.0,
                name=f"stress_piece_{index}_{level}",
            )
    model.update()

    for index in range(member_count):
        model.addConstr(gp.quicksum(y[index, level] for level in range(len(SIZES))) == 1, name=f"choose_size_{index}")
        model.addConstr(
            model.getVarByName(f"sigma_{index}")
            == gp.quicksum(stress_piece[index, level] for level in range(len(SIZES))),
            name=f"disaggregate_stress_{index}",
        )
        model.addConstr(
            model.getVarByName(f"q_{index}")
            == gp.quicksum(SIZES[level] * stress_piece[index, level] for level in range(len(SIZES))),
            name=f"disaggregate_force_{index}",
        )
        for level, size in enumerate(SIZES):
            lower = max(-GLOBAL_STRESS, -compression_by_member[index] * size)
            model.addConstr(
                stress_piece[index, level] >= lower * y[index, level],
                name=f"stress_piece_lb_{index}_{level}",
            )
            model.addConstr(
                stress_piece[index, level] <= GLOBAL_STRESS * y[index, level],
                name=f"stress_piece_ub_{index}_{level}",
            )
            y[index, level].BranchPriority = 100

    model.ModelName = "milo-v12-6-r1-75-1-convex-hull"
    model.ModelSense = GRB.MINIMIZE
    model.update()
    args.output_model.parent.mkdir(parents=True, exist_ok=True)
    model.write(str(args.output_model))
    report = {
        "instance": "milo-v12-6-r1-75-1",
        "method": "exact six-choice disaggregated stress/force convex hull",
        "sizes": SIZES,
        "members": member_count,
        "removed_variables": len(variables_to_remove),
        "removed_constraints": len(constraints_to_remove),
        "result_variables": model.NumVars,
        "result_constraints": model.NumConstrs,
        "result_nonzeros": model.NumNZs,
        "compression_coefficient_range": [min(compression_by_member.values()), max(compression_by_member.values())],
    }
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
