#!/usr/bin/env python3
"""Run a documented global branch-and-cut baseline for the 2D MILO model."""

from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path
import re

import gurobipy as gp
from gurobipy import GRB


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--time-limit", type=float, default=300.0)
    parser.add_argument("--threads", type=int, default=16)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--output-solution", type=Path)
    args = parser.parse_args()

    model = gp.read(str(args.model))
    opener = gzip.open if args.solution.suffix == ".gz" else open
    start_values = {}
    with opener(args.solution, "rt", errors="replace") as stream:
        for raw in stream:
            fields = raw.split()
            if len(fields) < 2:
                continue
            try:
                start_values[fields[0]] = float(fields[1])
            except ValueError:
                pass
    levels = {
        index: sum(start_values.get(f"z_{index}_{level}", 0.0) > 0.5 for level in range(5))
        for index in range(385)
    }
    for variable in model.getVars():
        if match := re.fullmatch(r"hull_y_(\d+)_(\d+)", variable.VarName):
            index, level = map(int, match.groups())
            variable.Start = 1.0 if levels[index] == level else 0.0
        elif match := re.fullmatch(r"hull_stress_piece_(\d+)_(\d+)", variable.VarName):
            index, level = map(int, match.groups())
            variable.Start = start_values.get(f"sigma_{index}", 0.0) if levels[index] == level else 0.0
        else:
            variable.Start = start_values.get(variable.VarName, 0.0)
        if variable.VarName.startswith("z_"):
            variable.BranchPriority = 100
    args.log.parent.mkdir(parents=True, exist_ok=True)
    model.Params.LogFile = str(args.log)
    model.Params.TimeLimit = args.time_limit
    model.Params.Threads = args.threads
    model.Params.MIPFocus = 3
    model.Params.Cuts = 2
    model.Params.NumericFocus = 2
    model.Params.IntegralityFocus = 1
    model.Params.Seed = 1
    model.optimize()

    report = {
        "instance": "milo-v12-6-r1-75-1",
        "method": "Gurobi 13 global branch-and-cut with z-level branching priority",
        "gurobi_version": list(gp.gurobi.version()),
        "status": int(model.Status),
        "status_name": {
            GRB.OPTIMAL: "OPTIMAL",
            GRB.TIME_LIMIT: "TIME_LIMIT",
            GRB.INFEASIBLE: "INFEASIBLE",
            GRB.INTERRUPTED: "INTERRUPTED",
        }.get(model.Status, str(model.Status)),
        "runtime": model.Runtime,
        "work": model.Work,
        "nodes": model.NodeCount,
        "solution_count": model.SolCount,
        "objective": model.ObjVal if model.SolCount else None,
        "best_bound": model.ObjBound,
        "relative_gap": model.MIPGap if model.SolCount else None,
        "parameters": {
            "time_limit": args.time_limit,
            "threads": args.threads,
            "mip_focus": 3,
            "cuts": 2,
            "numeric_focus": 2,
            "integrality_focus": 1,
            "z_branch_priority": 100,
            "seed": 1,
        },
    }
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    if args.output_solution and model.SolCount:
        args.output_solution.parent.mkdir(parents=True, exist_ok=True)
        model.write(str(args.output_solution))
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
