#!/usr/bin/env python3
"""Validate and solve the exact disaggregated convex-hull MILO formulation."""

from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path
import re

import gurobipy as gp
from gurobipy import GRB


Y_PATTERN = re.compile(r"y_(\d+)_(\d+)$")
PIECE_PATTERN = re.compile(r"stress_piece_(\d+)_(\d+)$")


def read_values(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix == ".gz" else open
    values = {}
    with opener(path, "rt", errors="replace") as stream:
        for raw in stream:
            fields = raw.split()
            if len(fields) < 2:
                continue
            try:
                values[fields[0]] = float(fields[1])
            except ValueError:
                pass
    return values


def set_start(model: gp.Model, values: dict[str, float]) -> dict[int, int]:
    levels = {
        index: sum(values.get(f"z_{index}_{level}", 0.0) > 0.5 for level in range(5))
        for index in range(385)
    }
    for variable in model.getVars():
        if match := Y_PATTERN.fullmatch(variable.VarName):
            index, level = map(int, match.groups())
            variable.Start = 1.0 if level == levels[index] else 0.0
        elif match := PIECE_PATTERN.fullmatch(variable.VarName):
            index, level = map(int, match.groups())
            variable.Start = values.get(f"sigma_{index}", 0.0) if level == levels[index] else 0.0
        else:
            variable.Start = values.get(variable.VarName, 0.0)
    return levels


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("public_solution", type=Path)
    parser.add_argument("--time-limit", type=float, default=300.0)
    parser.add_argument("--threads", type=int, default=16)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--output-solution", type=Path)
    args = parser.parse_args()

    values = read_values(args.public_solution)
    model = gp.read(str(args.model))
    levels = set_start(model, values)
    model.update()

    fixed = model.copy()
    fixed.Params.OutputFlag = 0
    for variable in fixed.getVars():
        if match := Y_PATTERN.fullmatch(variable.VarName):
            index, level = map(int, match.groups())
            value = 1.0 if level == levels[index] else 0.0
            variable.LB = value
            variable.UB = value
    fixed.optimize()
    if fixed.Status != GRB.OPTIMAL:
        raise RuntimeError("public design is not feasible in convex-hull formulation")
    fixed_objective = fixed.ObjVal

    args.log.parent.mkdir(parents=True, exist_ok=True)
    model.Params.LogFile = str(args.log)
    model.Params.TimeLimit = args.time_limit
    model.Params.Threads = args.threads
    model.Params.MIPFocus = 3
    model.Params.Cuts = 2
    model.Params.NumericFocus = 2
    model.Params.IntegralityFocus = 1
    model.Params.Seed = 1
    model.optimize()
    report = {
        "instance": "milo-v12-6-r1-75-1",
        "method": "exact six-choice disaggregated convex hull plus Gurobi 13 branch-and-cut",
        "public_fixed_design_objective": fixed_objective,
        "status": int(model.Status),
        "status_name": {
            GRB.OPTIMAL: "OPTIMAL",
            GRB.TIME_LIMIT: "TIME_LIMIT",
            GRB.INFEASIBLE: "INFEASIBLE",
            GRB.INTERRUPTED: "INTERRUPTED",
        }.get(model.Status, str(model.Status)),
        "runtime": model.Runtime,
        "work": model.Work,
        "nodes": model.NodeCount,
        "solution_count": model.SolCount,
        "objective": model.ObjVal if model.SolCount else None,
        "best_bound": model.ObjBound,
        "relative_gap": model.MIPGap if model.SolCount else None,
        "parameters": {
            "time_limit": args.time_limit,
            "threads": args.threads,
            "mip_focus": 3,
            "cuts": 2,
            "numeric_focus": 2,
            "integrality_focus": 1,
            "seed": 1,
        },
    }
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    if args.output_solution and model.SolCount:
        args.output_solution.parent.mkdir(parents=True, exist_ok=True)
        model.write(str(args.output_solution))
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
