#!/usr/bin/env python3
import json
import sys

import gurobipy as gp


gp.setParam("OutputFlag", 0)
model = gp.read(sys.argv[1])
fixed = {}
for variable in model.getVars()[:900]:
    if abs(variable.LB - variable.UB) <= 1e-12:
        value = int(round(variable.LB))
        if value not in (0, 1):
            raise ValueError(f"invalid fixed cell {variable.VarName}={variable.LB}")
        fixed[variable.index] = value

if len(fixed) != 192:
    raise ValueError(f"expected 192 fixed cells, found {len(fixed)}")
json.dump(fixed, sys.stdout, indent=2, sort_keys=True)
print()
