import gzip
import sys

values = {}
with gzip.open(sys.argv[1], "rt", encoding="utf-8") as source:
    for line in source:
        fields = line.split()
        if len(fields) >= 2 and fields[0].startswith("C"):
            try:
                values[fields[0]] = float(fields[1])
            except ValueError:
                pass

for i in range(30):
    print("".join("#" if values.get(f"C{30*i+j}", 0) > 0.5 else "." for j in range(30)))
