#!/usr/bin/env python3
"""
Solve the cell projection of MIPLIB xmas10-2 and audit/reconstruct original MPS
solutions.

The reduced model contains every original linear row whose support is wholly in
C0,...,C899.  It maximizes selected cells and separates disconnected selected
components lazily.  Under the verified local degree constraints, every such
component is a cycle, so sum_{v in S} x_v <= |S|-1 is valid: selecting all of
S already gives every v in S its required two selected neighbours inside S,
hence no vertex of S can connect to a selected vertex outside S.

Usage:
  python3 solve_xmas10_2.py xmas10-2.mps.gz xmas10-2.sol.gz result.json

Optional arguments:
  --time-limit SECONDS       Total Gurobi Runtime budget, default 1800
  --solution-out FILE        Reconstructed original-name solution file
"""

import argparse
import gzip
import json
import math
import os
import sys
import time

import gurobipy as gp
from gurobipy import GRB


N = 30
NCELL = N * N
TOL = 1e-7


def die(message):
    raise RuntimeError(message)


def open_text(path):
    return gzip.open(path, "rt") if path.endswith(".gz") else open(path, "rt")


def read_sparse_sol(path):
    """Read Gurobi .sol text; variables omitted from the sparse file are zero."""
    values = {}
    with open_text(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            fields = line.split()
            # MIPLIB public solutions append annotations such as `(obj:-1)`.
            if len(fields) < 2:
                continue
            name, value_text = fields[:2]
            try:
                values[name] = float(value_text)
            except ValueError:
                continue
    return values


def row_terms(model, constr):
    row = model.getRow(constr)
    return {row.getVar(k).VarName: row.getCoeff(k) for k in range(row.size())}


def close(a, b, tol=TOL):
    return abs(a - b) <= tol


def audit_values(model, values):
    """Audit all variable bounds/types and every original linear constraint."""
    failures = []
    max_bound_violation = 0.0
    max_row_violation = 0.0

    for var in model.getVars():
        value = values.get(var.VarName, 0.0)
        if not math.isfinite(value):
            failures.append("nonfinite variable value: " + var.VarName)
            continue
        lbv = max(0.0, var.LB - value)
        ubv = max(0.0, value - var.UB)
        violation = max(lbv, ubv)
        max_bound_violation = max(max_bound_violation, violation)
        if violation > TOL:
            failures.append(
                "bound violation %s value=%r bounds=[%r,%r]"
                % (var.VarName, value, var.LB, var.UB)
            )
        if var.VType in (GRB.BINARY, GRB.INTEGER):
            iv = abs(value - round(value))
            if iv > TOL:
                failures.append("integrality violation %s value=%r" % (var.VarName, value))

    for constr in model.getConstrs():
        row = model.getRow(constr)
        activity = sum(
            row.getCoeff(k) * values.get(row.getVar(k).VarName, 0.0)
            for k in range(row.size())
        )
        if constr.Sense == GRB.LESS_EQUAL:
            violation = max(0.0, activity - constr.RHS)
        elif constr.Sense == GRB.GREATER_EQUAL:
            violation = max(0.0, constr.RHS - activity)
        elif constr.Sense == GRB.EQUAL:
            violation = abs(activity - constr.RHS)
        else:
            die("unexpected constraint sense for " + constr.ConstrName)
        max_row_violation = max(max_row_violation, violation)
        if violation > TOL:
            failures.append(
                "row violation %s activity=%r sense=%s rhs=%r"
                % (constr.ConstrName, activity, constr.Sense, constr.RHS)
            )

    return {
        "passed": not failures,
        "failure_count": len(failures),
        "failures": failures[:50],
        "max_bound_violation": max_bound_violation,
        "max_row_violation": max_row_violation,
    }


def neighbors(v):
    i, j = divmod(v, N)
    ans = []
    if i:
        ans.append(v - N)
    if i + 1 < N:
        ans.append(v + N)
    if j:
        ans.append(v - 1)
    if j + 1 < N:
        ans.append(v + 1)
    return ans


def components(selected):
    remaining = set(selected)
    answer = []
    while remaining:
        root = remaining.pop()
        comp = {root}
        stack = [root]
        while stack:
            v = stack.pop()
            for w in neighbors(v):
                if w in remaining:
                    remaining.remove(w)
                    comp.add(w)
                    stack.append(w)
        answer.append(comp)
    return answer


def path_audit(selected):
    selected = set(selected)
    comps = components(selected) if selected else []
    degree = {v: sum(w in selected for w in neighbors(v)) for v in selected}
    endpoints = sorted(v for v, d in degree.items() if d == 1)
    bad_degree = sorted(v for v, d in degree.items() if d not in (1, 2))
    return {
        "selected_count": len(selected),
        "component_count": len(comps),
        "component_sizes": sorted((len(c) for c in comps), reverse=True),
        "degree_one_cells": endpoints,
        "bad_degree_cells": bad_degree,
        "is_one_orthogonal_path": (
            len(comps) == 1
            and len(endpoints) == 2
            and not bad_degree
            and all(d in (1, 2) for d in degree.values())
        ),
    }


def expected_row(coefficients):
    return tuple(sorted((int(k), float(v)) for k, v in coefficients.items()))


def classify_and_validate(original):
    original.update()
    vars_ = original.getVars()
    constrs = original.getConstrs()

    if len(vars_) != 8100 or len(constrs) != 8184:
        die("unexpected original dimensions")
    cells = vars_[:NCELL]
    if [v.VarName for v in cells] != ["C%d" % k for k in range(NCELL)]:
        die("first 900 variables are not exactly C0,...,C899")
    if any(not close(v.Obj, -1.0) for v in cells):
        die("cell objective coefficients are not all -1")
    if any(v.VType not in (GRB.BINARY, GRB.INTEGER) for v in cells):
        die("a cell is neither binary nor integer")
    if any(v.LB < -TOL or v.UB > 1.0 + TOL for v in cells):
        die("cell bounds are not within [0,1]")
    if any(v.VType != GRB.CONTINUOUS for v in vars_[NCELL:]):
        die("variables after C899 are not all continuous")

    xnames = {v.VarName for v in cells}
    xrows = []
    signature_to_rows = {}
    for c in constrs:
        terms = row_terms(original, c)
        if set(terms).issubset(xnames):
            signature = (
                tuple(sorted((int(name[1:]), coeff) for name, coeff in terms.items())),
                c.Sense,
                c.RHS,
            )
            signature_to_rows.setdefault(signature, []).append(c.ConstrName)
            xrows.append((c, terms))

    def has_exact(coeffs, sense, rhs):
        sig = (expected_row(coeffs), sense, float(rhs))
        return signature_to_rows.get(sig, [])

    squares = 0
    for i in range(N - 1):
        for j in range(N - 1):
            vs = [N * i + j, N * i + j + 1, N * (i + 1) + j, N * (i + 1) + j + 1]
            found = has_exact({v: 1.0 for v in vs}, GRB.LESS_EQUAL, 3.0)
            if len(found) != 1:
                die("missing/nonunique 2x2 row at (%d,%d): %r" % (i, j, found))
            squares += 1

    degree_lower = 0
    degree_upper = 0
    for v in range(1, NCELL - 1):
        ns = neighbors(v)
        low = {w: 1.0 for w in ns}
        low[v] = -2.0
        up = {w: 1.0 for w in ns}
        up[v] = 2.0
        found_low = has_exact(low, GRB.GREATER_EQUAL, 0.0)
        found_up = has_exact(up, GRB.LESS_EQUAL, 4.0)
        if len(found_low) != 1 or len(found_up) != 1:
            die("missing/nonunique degree pair at C%d" % v)
        degree_lower += 1
        degree_upper += 1

    start_endpoint = has_exact({1: 1.0, N: 1.0}, GRB.EQUAL, 1.0)
    end_endpoint = has_exact({NCELL - N - 1: 1.0, NCELL - 2: 1.0}, GRB.EQUAL, 1.0)
    if len(start_endpoint) != 1 or len(end_endpoint) != 1:
        die("endpoint-selection equations do not match the expected two corners")
    if not (close(cells[0].LB, 1.0) and close(cells[0].UB, 1.0)):
        die("C0 is not fixed to one")
    if not (close(cells[-1].LB, 1.0) and close(cells[-1].UB, 1.0)):
        die("C899 is not fixed to one")

    return {
        "cell_rows": xrows,
        "checks": {
            "dimensions": True,
            "cell_names_C0_to_C899": True,
            "cell_objective_is_min_negative_cardinality": True,
            "cell_bounds_within_zero_one": True,
            "noncell_variables_are_continuous": True,
            "two_by_two_rows": squares,
            "degree_lower_rows": degree_lower,
            "degree_upper_rows": degree_upper,
            "endpoint_rows": [start_endpoint[0], end_endpoint[0]],
            "corner_cells_fixed_one": True,
            "all_x_only_rows_copied": len(xrows),
        },
    }


def build_reduced(original, cell_rows):
    reduced = gp.Model("xmas10_2_cell_projection")
    reduced.Params.OutputFlag = 1
    reduced.Params.LazyConstraints = 1
    x = []
    for old in original.getVars()[:NCELL]:
        x.append(reduced.addVar(lb=old.LB, ub=old.UB, vtype=GRB.BINARY, name=old.VarName))
    reduced.update()

    by_name = {v.VarName: v for v in x}
    for old_c, terms in cell_rows:
        expr = gp.LinExpr()
        for name, coeff in terms.items():
            expr.add(by_name[name], coeff)
        if old_c.Sense == GRB.LESS_EQUAL:
            reduced.addConstr(expr <= old_c.RHS, name=old_c.ConstrName)
        elif old_c.Sense == GRB.GREATER_EQUAL:
            reduced.addConstr(expr >= old_c.RHS, name=old_c.ConstrName)
        else:
            reduced.addConstr(expr == old_c.RHS, name=old_c.ConstrName)

    reduced.setObjective(gp.quicksum(x), GRB.MAXIMIZE)
    reduced.update()
    return reduced, x


class CycleSeparator:
    def __init__(self, x):
        self.x = x
        self.rejected_sizes = []
        self.callback_calls = 0

    def __call__(self, model, where):
        if where != GRB.Callback.MIPSOL:
            return
        self.callback_calls += 1
        values = model.cbGetSolution(self.x)
        selected = [v for v, value in enumerate(values) if value > 0.5]
        for comp in components(selected):
            # Every disconnected component must be a cycle under the verified
            # endpoint and degree equations.  The cut excludes this closed cycle.
            boundary = any(w not in comp and w in selected for v in comp for w in neighbors(v))
            if boundary:
                die("component computation inconsistency")
            if len(comp) != len(selected):
                model.cbLazy(gp.quicksum(self.x[v] for v in comp) <= len(comp) - 1)
                self.rejected_sizes.append(len(comp))


def write_sol(path, values, original_objective):
    with open(path, "wt") as f:
        f.write("# Objective value = %.16g\n" % original_objective)
        for name in sorted(values):
            value = values[name]
            if abs(value) > 1e-10:
                f.write("%s %.16g\n" % (name, value))


def reconstruct(original_path, selected, time_limit):
    model = gp.read(original_path)
    model.Params.OutputFlag = 0
    model.Params.TimeLimit = max(0.0, time_limit)
    for i, var in enumerate(model.getVars()[:NCELL]):
        value = 1.0 if i in selected else 0.0
        var.LB = value
        var.UB = value
    model.setObjective(0.0, GRB.MINIMIZE)
    model.optimize()
    if model.Status not in (GRB.OPTIMAL, GRB.SUBOPTIMAL):
        return model, None
    values = {v.VarName: v.X for v in model.getVars()}
    return model, values


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mps")
    parser.add_argument("public_solution")
    parser.add_argument("json_out")
    parser.add_argument("--time-limit", type=float, default=1800.0)
    parser.add_argument("--solution-out", default="xmas10-2-reconstructed.sol")
    args = parser.parse_args()

    started = time.monotonic()
    original = gp.read(args.mps)
    structure = classify_and_validate(original)

    public_sparse = read_sparse_sol(args.public_solution)
    original_names = {v.VarName for v in original.getVars()}
    unknown_public_names = sorted(set(public_sparse) - original_names)
    public_values = {v.VarName: public_sparse.get(v.VarName, 0.0) for v in original.getVars()}
    public_audit = audit_values(original, public_values)
    public_selected = [
        i for i in range(NCELL) if public_values["C%d" % i] > 0.5
    ]
    public_path = path_audit(public_selected)
    if not public_audit["passed"]:
        die("public solution fails original audit")
    if len(public_selected) != 497 or not public_path["is_one_orthogonal_path"]:
        die("public solution is not an audited 497-cell orthogonal path")

    reduced, x = build_reduced(original, structure["cell_rows"])
    for i, var in enumerate(x):
        var.Start = 1.0 if i in public_selected else 0.0

    separator = CycleSeparator(x)
    # Preserve up to one minute of the total solver budget for reconstructing
    # and auditing the original continuous flow variables.
    reserve = min(60.0, max(0.0, args.time_limit * 0.1))
    remaining = max(0.0, args.time_limit - reserve - (time.monotonic() - started))
    reduced.Params.TimeLimit = remaining
    reduced.optimize(separator)

    reduced_status = int(reduced.Status)
    reduced_runtime = float(reduced.Runtime)
    reduced_bound = float(reduced.ObjBound)
    selected = []
    reduced_objective = None
    reduced_path = None
    reconstruction = {"attempted": False, "passed": False}

    if reduced.SolCount:
        selected = [i for i, var in enumerate(x) if var.X > 0.5]
        reduced_objective = len(selected)
        reduced_path = path_audit(selected)
        if not reduced_path["is_one_orthogonal_path"]:
            die("lazy separation returned a disconnected/non-path incumbent")

        remaining = max(0.0, args.time_limit - (time.monotonic() - started))
        if remaining > 0.0:
            reconstruction["attempted"] = True
            flow_model, reconstructed_values = reconstruct(args.mps, set(selected), remaining)
            reconstruction["gurobi_status"] = int(flow_model.Status)
            reconstruction["gurobi_runtime"] = float(flow_model.Runtime)
            if reconstructed_values is not None:
                reconstruction["audit"] = audit_values(flow_model, reconstructed_values)
                reconstruction["passed"] = reconstruction["audit"]["passed"]
                reconstruction["original_objective"] = -len(selected)
                if reconstruction["passed"]:
                    write_sol(args.solution_out, reconstructed_values, -len(selected))
                    reconstruction["solution_file"] = os.path.abspath(args.solution_out)

    proven_optimal = reduced.Status == GRB.OPTIMAL
    result = {
        "instance": "xmas10-2",
        "interpretation_checks": structure["checks"],
        "public_solution": {
            "unknown_names_ignored": unknown_public_names,
            "audit": public_audit,
            "path": public_path,
        },
        "rejected_disconnected_components": {
            "count": len(separator.rejected_sizes),
            "sizes": separator.rejected_sizes,
            "callback_calls": separator.callback_calls,
        },
        "reduced_projection": {
            "status": reduced_status,
            "status_name": {
                GRB.OPTIMAL: "OPTIMAL",
                GRB.TIME_LIMIT: "TIME_LIMIT",
                GRB.INTERRUPTED: "INTERRUPTED",
            }.get(reduced_status, str(reduced_status)),
            "runtime": reduced_runtime,
            "objective_max_selected_cells": reduced_objective,
            "best_bound_max_selected_cells": reduced_bound,
            "proven_optimal": proven_optimal,
            "certificate_interpretation": (
                "Gurobi proved the exact reduced cell projection optimal."
                if proven_optimal else
                "Numerical branch-and-cut bound for the exact reduced cell projection; "
                "not an independent combinatorial certificate."
            ),
            "path": reduced_path,
        },
        "reconstruction": reconstruction,
        "wall_seconds": time.monotonic() - started,
        "solver_time_budget_seconds": args.time_limit,
    }
    with open(args.json_out, "wt") as f:
        json.dump(result, f, indent=2, sort_keys=True)
        f.write("\n")

    print(json.dumps(result, indent=2, sort_keys=True))
    if proven_optimal and round(reduced_bound) == 497 and reduced_objective == 497:
        print("CERTIFICATE: reduced projection proven optimal at 497 selected cells.")
    elif reduced_objective is not None:
        print(
            "NUMERICAL STATUS: best path %d, reduced upper bound %.12g."
            % (reduced_objective, reduced_bound)
        )
    else:
        print("NO REDUCED INCUMBENT")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print("ERROR:", exc, file=sys.stderr)
        sys.exit(2)
