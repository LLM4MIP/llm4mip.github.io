#!/usr/bin/env python3
"""Exact preprocessing audit for core2586-950's weighted set-cover core.

The three non-cover rows are redundant for every solution no worse than the
published incumbent 944, so this script analyzes the corresponding exact
optimization kernel under that cutoff.
"""

from __future__ import annotations

import argparse
import collections
import json
from pathlib import Path

from structural_audit import parse_mps, q


def components(rows, cols, row_to_cols, col_to_rows):
    unseen_r = set(rows)
    unseen_c = set(cols)
    out = []
    while unseen_r:
        seed = unseen_r.pop()
        rs = {seed}
        cs = set()
        qr = [seed]
        qc = []
        while qr or qc:
            while qr:
                r = qr.pop()
                for c in row_to_cols[r] & unseen_c:
                    unseen_c.remove(c)
                    cs.add(c)
                    qc.append(c)
            while qc:
                c = qc.pop()
                for r in col_to_rows[c] & unseen_r:
                    unseen_r.remove(r)
                    rs.add(r)
                    qr.append(r)
        out.append((rs, cs))
    for c in unseen_c:
        out.append((set(), {c}))
    return out


def write_mps(path, name, rows, cols, r2c, c2r, cost, offset=0.0, cutoff=None):
    """Write a free-format binary set-cover MPS with a fixed offset variable."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as fh:
        fh.write(f"NAME {name}\nOBJSENSE\n MIN\nROWS\n N OBJ\n")
        for r in sorted(rows):
            fh.write(f" G {r}\n")
        if cutoff is not None:
            fh.write(" L CUTOFF\n")
        fh.write("COLUMNS\n")
        if offset:
            fh.write(f" OFFSET OBJ {offset:g}\n")
        for c in sorted(cols):
            fh.write(f" {c} OBJ {cost[c]:g}\n")
            if cutoff is not None:
                fh.write(f" {c} CUTOFF {cost[c]:g}\n")
            for r in sorted(c2r[c] & rows):
                fh.write(f" {c} {r} 1\n")
        fh.write("RHS\n")
        for r in sorted(rows):
            fh.write(f" RHS1 {r} 1\n")
        if cutoff is not None:
            fh.write(f" RHS1 CUTOFF {cutoff:g}\n")
        fh.write("BOUNDS\n")
        if offset:
            fh.write(" FX BND OFFSET 1\n")
        for c in sorted(cols):
            fh.write(f" BV BND {c}\n")
        fh.write("ENDATA\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mps", type=Path)
    ap.add_argument("--write-lp", type=Path, help="write the reduced two-component set-cover kernel")
    ap.add_argument("--write-mps-dir", type=Path, help="write whole-kernel and per-component MPS files")
    ap.add_argument("--write-mapping", type=Path, help="write machine-readable lift/reduction mapping")
    args = ap.parse_args()
    senses, col_coeff, row_coeff, rhs, bounds, integer = parse_mps(args.mps)
    objective_row = next(r for r, t in senses.items() if t == "N")
    cover_rows = {
        r for r, t in senses.items()
        if t == "G" and rhs.get(r, 0.0) == 1.0
    }
    cols = {v for v in col_coeff if v.startswith("X")}
    cost = {v: col_coeff[v][objective_row] for v in cols}
    r2c = {r: set(row_coeff[r]) & cols for r in cover_rows}
    c2r = {c: set(col_coeff[c]) & cover_rows for c in cols}

    by_cost_degree = collections.Counter((cost[c], len(c2r[c])) for c in cols)
    singleton_rows = [r for r in cover_rows if len(r2c[r]) == 1]
    initially_forced = {next(iter(r2c[r])) for r in singleton_rows}
    initially_covered = set().union(*(c2r[c] for c in initially_forced))

    active_r = set(cover_rows)
    active_c = set(cols)
    forced = set()
    forced_witness = {}
    dropped_rows = set()
    row_witness = {}
    dominated_cols = set()
    column_witness = {}
    empty_cols = set()
    iterations = []

    while True:
        changed = False
        it = {"start_rows": len(active_r), "start_cols": len(active_c)}

        newly_forced = set()
        for r in active_r:
            candidates = r2c[r] & active_c
            if len(candidates) == 1:
                newly_forced.add(next(iter(candidates)))
            elif not candidates:
                raise RuntimeError(f"Reduction produced uncovered row {r}")
        newly_forced -= forced
        if newly_forced:
            for c in newly_forced:
                forced_witness[c] = min(r for r in active_r if (r2c[r] & active_c) == {c})
            forced |= newly_forced
            covered = set().union(*(c2r[c] for c in newly_forced)) & active_r
            active_r -= covered
            active_c -= newly_forced
            changed = True
        it["new_forced_cols"] = len(newly_forced)

        newly_empty = {c for c in active_c if not (c2r[c] & active_r)}
        if newly_empty:
            active_c -= newly_empty
            empty_cols |= newly_empty
            changed = True
        it["new_empty_cols"] = len(newly_empty)

        # A covering row with a superset of another row's active columns is
        # redundant.  Degrees first makes most comparisons terminate quickly.
        ordered = sorted(active_r, key=lambda r: (len(r2c[r] & active_c), r))
        row_sets = {r: r2c[r] & active_c for r in ordered}
        newly_dropped_rows = set()
        for i, a in enumerate(ordered):
            if a in newly_dropped_rows:
                continue
            sa = row_sets[a]
            for b in ordered[i + 1:]:
                if b in newly_dropped_rows:
                    continue
                sb = row_sets[b]
                if len(sb) < len(sa):
                    continue
                if sa <= sb:
                    # Equal sets: retain lexicographically first representative.
                    newly_dropped_rows.add(b)
                    row_witness[b] = a
        if newly_dropped_rows:
            active_r -= newly_dropped_rows
            dropped_rows |= newly_dropped_rows
            changed = True
        it["new_subsumed_rows"] = len(newly_dropped_rows)

        newly_empty = {c for c in active_c if not (c2r[c] & active_r)}
        if newly_empty:
            active_c -= newly_empty
            empty_cols |= newly_empty
            changed = True
        it["new_empty_cols_after_rows"] = len(newly_empty)

        # Column v is dominated if another active column w has no larger cost
        # and covers every still-active row v covers.  Equal-cost ties retain
        # one canonical representative rather than deleting both.
        active_row_cols = {r: r2c[r] & active_c for r in active_r}
        newly_dominated = set()
        for v in sorted(active_c):
            rv = c2r[v] & active_r
            if not rv:
                continue
            candidates = None
            for r in sorted(rv, key=lambda z: len(active_row_cols[z])):
                candidates = set(active_row_cols[r]) if candidates is None else candidates & active_row_cols[r]
                if len(candidates) <= 1:
                    break
            for w in candidates or ():
                if w == v:
                    continue
                if cost[w] < cost[v] or (cost[w] == cost[v] and w < v):
                    newly_dominated.add(v)
                    column_witness[v] = w
                    break
        if newly_dominated:
            active_c -= newly_dominated
            dominated_cols |= newly_dominated
            changed = True
        it["new_dominated_cols"] = len(newly_dominated)
        it["end_rows"] = len(active_r)
        it["end_cols"] = len(active_c)
        iterations.append(it)
        if not changed:
            break

    comps = sorted(
        components(active_r, active_c, r2c, c2r),
        key=lambda z: (-len(z[0]), -len(z[1]), min(z[0]) if z[0] else ""),
    )
    comp_stats = sorted(
        ({"rows": len(rs), "cols": len(cs)} for rs, cs in comps),
        key=lambda x: (x["rows"], x["cols"]), reverse=True,
    )

    if args.write_lp:
        args.write_lp.parent.mkdir(parents=True, exist_ok=True)
        with args.write_lp.open("w") as fh:
            fh.write("\\ Exact set-cover kernel for core2586-950; lift by also selecting forced columns.\n")
            fh.write(f"Minimize\n obj: {sum(cost[c] for c in forced):g} OFFSET")
            for c in sorted(active_c):
                fh.write(f" + {cost[c]:g} {c}")
            fh.write("\nSubject To\n")
            for r in sorted(active_r):
                lhs = " + ".join(sorted(r2c[r] & active_c))
                fh.write(f" {r}: {lhs} >= 1\n")
            fh.write("Bounds\n OFFSET = 1\n")
            fh.write("Binary\n")
            for c in sorted(active_c):
                fh.write(f" {c}\n")
            fh.write("End\n")

    fixed_cost = sum(cost[c] for c in forced)
    if args.write_mps_dir:
        write_mps(
            args.write_mps_dir / "core2586-950-kernel.mps",
            "core2586-950-kernel", active_r, active_c, r2c, c2r, cost, fixed_cost,
        )
        for k, (rs, cs) in enumerate(comps):
            write_mps(
                args.write_mps_dir / f"core2586-950-component-{k}.mps",
                f"core2586-950-c{k}", rs, cs, r2c, c2r, cost, 0.0,
            )
        # Since component 1 has certified optimum 19 and the fixed offset is
        # 68, improving the official 944 requires component 0 <= 856.
        rs0, cs0 = comps[0]
        write_mps(
            args.write_mps_dir / "core2586-950-component-0-cutoff856.mps",
            "core2586-950-c0-cut856", rs0, cs0, r2c, c2r, cost, 0.0, 856.0,
        )

    if args.write_mapping:
        args.write_mapping.parent.mkdir(parents=True, exist_ok=True)
        mapping = {
            "original_mps": str(args.mps),
            "objective_relation": f"original optimum = {fixed_cost:g} + sum(component optima)",
            "fixed_cost": fixed_cost,
            "forced_columns": sorted(forced),
            "forced_witness_singleton_row": dict(sorted(forced_witness.items())),
            "active_rows": sorted(active_r),
            "active_columns": sorted(active_c),
            "subsumed_row_witness": dict(sorted(row_witness.items())),
            "dominated_column_witness": dict(sorted(column_witness.items())),
            "empty_columns": sorted(empty_cols),
            "components": [
                {"id": k, "rows": sorted(rs), "columns": sorted(cs)}
                for k, (rs, cs) in enumerate(comps)
            ],
        }
        args.write_mapping.write_text(json.dumps(mapping, indent=2, sort_keys=True) + "\n")

    out = {
        "interpretation": {
            "cover_constraints": len(cover_rows),
            "candidate_columns": len(cols),
            "cost_histogram": {str(k): v for k, v in sorted(collections.Counter(cost.values()).items())},
            "why_special_rows_are_redundant_below_944": {
                "UB": "objective <= 944 implies objective <= 1e10",
                "INERZIA": "sum of 597 nonnegative binaries >= -597 always",
                "R7002": "all X costs >= 1, so objective <= 944 implies sum of its 10632 binaries <= 944 < 9256",
                "S_variables": "positive-cost variables cover no unit-demand row, hence an optimum sets all 11 to zero",
            },
        },
        "initial": {
            "singleton_rows": len(singleton_rows),
            "distinct_forced_columns": len(initially_forced),
            "rows_covered_by_forced_columns": len(initially_covered),
            "forced_cost": sum(cost[c] for c in initially_forced),
            "cost_degree_histogram": {
                f"cost={k[0]},degree={k[1]}": v for k, v in sorted(by_cost_degree.items())
            },
        },
        "exact_reduction": {
            "forced_columns": len(forced),
            "forced_cost": sum(cost[c] for c in forced),
            "subsumed_rows": len(dropped_rows),
            "dominated_columns": len(dominated_cols),
            "empty_columns_removed": len(empty_cols),
            "kernel_rows": len(active_r),
            "kernel_columns": len(active_c),
            "kernel_row_degree_quantiles": q([len(r2c[r] & active_c) for r in active_r]),
            "kernel_col_degree_quantiles": q([len(c2r[c] & active_r) for c in active_c]),
            "components": len(comp_stats),
            "largest_components": comp_stats[:20],
            "iterations": iterations,
            "forced_column_names": sorted(forced),
        },
    }
    print(json.dumps(out, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
