# `core2586-950` structural reduction

## Original formulation

The official MPS has SHA-256
`a906fd42549287b0604e682167fe867f81ba2b41c2ed76ec4f2fa8e24f5f6dc5`.
It contains 2,589 constraints, 13,215 binary `X` variables, and 11
nonnegative continuous `S` variables.  Its optimization-relevant core is

\[
  \min \sum_{j\in J_1}x_j+2\sum_{j\in J_2}x_j
  \quad\text{s.t.}\quad Ax\geq \mathbf 1,\quad x\in\{0,1\}^{13215},
\]

where `A` is a 2,586 by 13,215 zero-one covering matrix,
`|J1| = 2,583`, and `|J2| = 10,632`.

The remaining structure does not alter an optimum:

- Every `S` variable has positive objective coefficient, covers no demand
  row, and otherwise occurs only in `UB`, so it is optimally zero.
- `UB` is a copy of the objective with right-hand side `1e10`.
- `INERZIA` is the vacuous inequality `sum(597 nonnegative binaries) >= -597`.
- `R7002` is exactly `sum(j in J2) x_j <= 9256`.  The verified feasible
  solution of value 944 implies an optimum of value at most 944, and hence at
  most 472 variables from `J2`; therefore this row is redundant at optimum.

## Exact reduction

The reproducible reducer applies only elementary exact set-cover rules:

1. select the sole column in every singleton row;
2. delete a row when its column set is a superset of another active row;
3. delete a column when a no-more-expensive column covers a superset of its
   active rows (equal-cost ties keep one canonical representative);
4. delete columns that no longer cover an active row; repeat to closure.

The closure selects 42 columns of total cost 68, deletes 215 subsumed rows,
3,422 dominated columns, and 11 empty columns.  The remaining kernel has
2,257 rows and 9,740 binaries and splits into two independent components:

| component | rows | binaries | known feasible | status |
|---:|---:|---:|---:|---|
| 0 | 2,233 | 9,688 | 857 | open |
| 1 | 24 | 52 | 19 | **optimal** (Gurobi, one thread, 0.00 s) |

Consequently

\[
  z^*_{\rm original}=68+z^*_0+19=87+z^*_0.
\]

The official value-944 solution projects to component objectives 857 and 19
without loss.  Thus improving 944 requires `z0 <= 856`; proving the supplied
component-0 cutoff model infeasible proves that 944 is globally optimal.

## Files

- `structural_audit.py`: independent MPS parser and structural statistics.
- `reduce_setcover.py`: reduction, witness mapping, LP/MPS, and components.
- `kernel_mapping.json`: forced columns, row/column witnesses, active kernel,
  and component membership.
- `reduce_setcover.py` regenerates the whole kernel, both independent
  components, and the hard-component cutoff model. Generated MPS files are
  intentionally not stored in Git.
- `project_incumbent.py` and `starts/`: projection of the official solution to
  the kernel/components.  Component 0 gets objective 857; component 1 gets 19.
- `lift_and_check.py`: reconstructs all original variables and directly checks
  all 2,589 original constraints, integrality, and objective.  The combined
  projected starts pass with objective 944 and zero violations.

Artifact SHA-256 values:

| artifact | SHA-256 |
|---|---|
| original `core2586-950.mps.gz` | `a906fd42549287b0604e682167fe867f81ba2b41c2ed76ec4f2fa8e24f5f6dc5` |
| whole kernel MPS | `6b1f2a489ef5ce8a84b522f54bedf60f9730c3c8a0e3cd47ef19abfa3f80dc96` |
| component 0 MPS | `10261151fe5bb345a7facb46c681838defbe01e7fdc32d3fbcc305a381b48294` |
| component 1 MPS | `b3cf82286681ecc6a7ac1e5283a2501e71050a5ec2948a02ec8647ba163f19be` |
| component 0 cutoff-856 MPS | `d7b7adceda2ae55da80a114f43b94311467cb59cae07cce143f1cedca15069b8` |
| kernel mapping | `3197498647ef3a731f07cbc0a7eedd0c0343a27783c1fe4408d4b8a12d05938c` |
| projected component 0 start | `7d8861efc1509a3232872b6edc32606240681104416cfd60aa542ace6f7786a6` |
| projected component 1 start | `4b28a5d51cb87ed68b861555ea6bc59164c26a26440b87d4018f01614ce0a425` |

## Reproduction

From `instances/core2586-950/`, generate all reduced files and the mapping:

```sh
python structural/reduce_setcover.py \
  input/core2586-950.mps.gz \
  --write-lp structural/core2586-950-kernel.lp \
  --write-mps-dir structural/models \
  --write-mapping structural/kernel_mapping.json
```

Project the official incumbent:

```sh
python structural/project_incumbent.py \
  input/core2586-950.mps.gz \
  structural/kernel_mapping.json \
  solutions/strict-944-relifted.sol \
  structural/starts
```

Independently lift and check the two component starts:

```sh
python structural/lift_and_check.py \
  input/core2586-950.mps.gz \
  structural/kernel_mapping.json \
  --component-solution 0=structural/starts/official-944-component-0.sol \
  --component-solution 1=structural/starts/official-944-component-1.sol
```
