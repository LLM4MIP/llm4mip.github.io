# `core2586-950` — exact set-cover reduction; global optimum open

Official MIPLIB page: <https://miplib.zib.de/instance_details_core2586-950.html>

## Result

The strict incumbent `944` is independently validated, but the instance
remains **globally open**.

| quantity | value | evidence |
|---|---:|---|
| strict feasible UB | **`944`** | exact-decimal original-MPS replay |
| numerical LB | **`937`** | Gurobi 13.0.2, 600 s, two threads |
| numerical gap | `0.7415%` | time-limit result |
| exact small component | `19` | zero-gap 24-row/52-column set cover |

## Exact reduction

Below the known incumbent, the formulation is optimization-equivalent to a
weighted set cover. Exact preprocessing fixes 42 columns of total cost 68,
removes 215 subsumed rows, 3,422 dominated columns and 11 empty columns, and
splits the kernel into a 2,233-row/9,688-column hard component and a
24-row/52-column component. The small component is solved exactly at 19.
Therefore:

```text
OPT = 87 + OPT(hard component).
```

The incumbent projects to hard-component cost 857. The supplied cutoff
experiment searches under `cost <= 856`, but stops at the time limit without
a point **and without an infeasibility proof**. Its absence of a solution does
not prove that 944 is optimal.

The mapping and deterministic lift are in [`structural/`](structural/).
[`strict-944-relifted.sol`](solutions/strict-944-relifted.sol) has objective
944 with exact-zero row, bound and integrality violations on the original MPS.

## Local incumbent neighborhood

An exhaustive audit checked all 586 one-column drops and 171,405 two-column
drops, including strictly cheaper repairs using at most three cost-1 columns.
No improvement was found. This is an exact neighborhood result, not a global
optimality certificate.

The sanitized [original-model](logs/original-proof-600s.log) and
[`cutoff856`](logs/component0-cutoff856-600s.log) logs retain the numerical
run evidence. Neither contains a portable proof trace.
