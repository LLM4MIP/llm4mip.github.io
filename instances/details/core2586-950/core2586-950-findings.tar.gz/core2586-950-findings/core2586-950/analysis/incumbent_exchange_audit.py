#!/usr/bin/env python3
"""Exact 1-drop/2-drop improving-exchange audit for the 944 incumbent.

For each one- or two-column subset D of the incumbent, this script asks whether
the rows exposed by deleting D can be covered by currently unselected columns
of total cost at most cost(D)-1.  Costs are integral (1 or 2), so this examines
every strictly cost-improving replacement, including up to three added cost-1
columns after dropping two cost-2 columns.
"""

from __future__ import annotations

import collections
import functools
import gzip
import itertools
import sys
import time


def parse_mps(path: str):
    columns: dict[str, dict[str, float]] = collections.defaultdict(dict)
    integers: set[str] = set()
    section = ""
    in_integer = False
    with gzip.open(path, "rt", encoding="ascii") as stream:
        for raw in stream:
            fields = raw.split()
            if not fields:
                continue
            if fields[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "BOUNDS", "ENDATA"}:
                section = fields[0]
                continue
            if section != "COLUMNS":
                continue
            if len(fields) >= 3 and fields[1] == "'MARKER'":
                in_integer = fields[2] == "'INTORG'"
                continue
            var = fields[0]
            if in_integer:
                integers.add(var)
            for pos in range(1, len(fields), 2):
                columns[var][fields[pos]] = float(fields[pos + 1])
    rows = {f"R{i}" for i in range(1, 2587)}
    costs = {var: int(columns[var]["obj"]) for var in integers}
    supports = {var: frozenset(columns[var]) & rows for var in integers}
    return rows, costs, supports


def parse_solution(path: str) -> set[str]:
    chosen = set()
    with open(path, encoding="ascii") as stream:
        for raw in stream:
            fields = raw.split()
            if len(fields) == 2 and fields[0].startswith("X") and float(fields[1]) > 0.5:
                chosen.add(fields[0])
    return chosen


def main(mps_path: str, solution_path: str) -> None:
    started = time.monotonic()
    rows, costs, supports = parse_mps(mps_path)
    chosen = parse_solution(solution_path)
    unchosen = set(supports) - chosen
    coverers = {row: {var for var in chosen if row in supports[var]} for row in rows}
    uncovered = [row for row in rows if not coverers[row]]
    if uncovered:
        raise RuntimeError(f"incumbent is infeasible; first uncovered row is {uncovered[0]}")
    objective = sum(costs[var] for var in chosen)

    unchosen_by_row = {row: [] for row in rows}
    for var in unchosen:
        for row in supports[var]:
            unchosen_by_row[row].append(var)
    for row in rows:
        unchosen_by_row[row].sort(key=lambda var: (costs[var], -len(supports[var]), var))

    # Rows uniquely covered by one incumbent column are exposed whenever it is dropped.
    unique_rows = {var: set() for var in chosen}
    # A doubly covered row is exposed only when its particular two coverers are both dropped.
    double_rows: dict[frozenset[str], set[str]] = collections.defaultdict(set)
    for row, row_coverers in coverers.items():
        if len(row_coverers) == 1:
            unique_rows[next(iter(row_coverers))].add(row)
        elif len(row_coverers) == 2:
            double_rows[frozenset(row_coverers)].add(row)

    search_states = 0

    @functools.lru_cache(maxsize=None)
    def find_cover(deficit: frozenset[str], budget: int):
        nonlocal search_states
        search_states += 1
        if not deficit:
            return ()
        if budget <= 0:
            return None
        row = min(
            deficit,
            key=lambda r: sum(costs[var] <= budget for var in unchosen_by_row[r]),
        )
        for var in unchosen_by_row[row]:
            cost = costs[var]
            if cost > budget:
                break
            result = find_cover(deficit - supports[var], budget - cost)
            if result is not None:
                return (var,) + result
        return None

    one_drop_checked = 0
    two_drop_checked = 0
    witness = None

    for var in sorted(chosen):
        one_drop_checked += 1
        budget = costs[var] - 1
        replacement = find_cover(frozenset(unique_rows[var]), budget)
        if replacement is not None:
            witness = ((var,), replacement)
            break

    if witness is None:
        for first, second in itertools.combinations(sorted(chosen), 2):
            two_drop_checked += 1
            dropped = frozenset((first, second))
            deficit = unique_rows[first] | unique_rows[second] | double_rows.get(dropped, set())
            budget = costs[first] + costs[second] - 1
            replacement = find_cover(frozenset(deficit), budget)
            if replacement is not None:
                witness = ((first, second), replacement)
                break

    coverage_hist = collections.Counter(len(value) for value in coverers.values())
    unique_hist = collections.Counter(len(value) for value in unique_rows.values())
    print(f"incumbent_columns={len(chosen)} objective={objective} feasible=yes")
    print(f"incumbent_cost_histogram={sorted(collections.Counter(costs[v] for v in chosen).items())}")
    print(f"row_incumbent_coverage_histogram={sorted(coverage_hist.items())}")
    print(f"unique_rows_per_incumbent_column_histogram={sorted(unique_hist.items())}")
    print(f"one_drop_checked={one_drop_checked}")
    print(f"two_drop_checked={two_drop_checked}")
    print(f"cached_cover_states={find_cover.cache_info().currsize} recursive_states={search_states}")
    if witness is None:
        print("strictly_improving_exchange=none")
    else:
        dropped, added = witness
        new_chosen = (chosen - set(dropped)) | set(added)
        new_objective = sum(costs[var] for var in new_chosen)
        newly_uncovered = [row for row in rows if not any(row in supports[var] for var in new_chosen)]
        print("strictly_improving_exchange=found")
        print("drop=" + " ".join(dropped))
        print("add=" + " ".join(added))
        print(f"new_objective={new_objective} feasible={'yes' if not newly_uncovered else 'no'}")
    print(f"elapsed_seconds={time.monotonic() - started:.3f}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
