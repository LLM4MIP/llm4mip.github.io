# Package manifest: core2586-950

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 17
Excluded source files: 0

## Included files

- `README.md`
- `analysis/incumbent_exchange_audit.py`
- `artifacts/incumbent-exchange-audit.txt`
- `artifacts/result.json`
- `input/README.md`
- `input/SHA256SUMS`
- `logs/component0-cutoff856-600s.log`
- `logs/original-proof-600s.log`
- `solutions/strict-944-relifted.sol`
- `structural/README.md`
- `structural/kernel_mapping.json`
- `structural/lift_and_check.py`
- `structural/project_incumbent.py`
- `structural/reduce_setcover.py`
- `structural/starts/official-944-component-0.sol`
- `structural/starts/official-944-component-1.sol`
- `structural/structural_audit.py`

## Excluded files

- None
