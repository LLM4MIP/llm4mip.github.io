# `supportcase30`

## Result

No globally feasible solution was found, and global infeasibility was not proved.

The best independently checked partial solution is [`supportcase30_best_partial.sol`](artifacts/supportcase30_best_partial.sol). It selects exactly 114 binary variables, satisfies the four required group cardinalities `(30, 30, 24, 30)`, and covers 987 of the 1,024 covering rows. The remaining 37 uncovered rows make it a near-feasible point, **not** a feasible solution of the original MPS.

Cold-start Gurobi 13.0.1 and COPT 8.0.4 feasibility runs both found zero feasible points in 15 minutes. A maximum-coverage reformulation, NoRel search, quota-preserving tabu search, and Hamming local branching were then used to quantify and improve the near-feasible points. None closed the global gap: an objective of 1,024 in the maximum-coverage model is equivalent to feasibility of the original instance.

## Input and structure

- Compressed MPS SHA-256: `8398737D9C65B5C9F7435F4284C09E27218C44A54472229AC46EC5F570DE5D91`
- Uncompressed MPS SHA-256: `1BFDA1A84217A8135D7628F723956D9BB4623B15A285F617033B3C4501BD1E1B`
- Model: 1,024 binary variables, 1,024 covering rows, four cardinality equalities, and 12,288 nonzeros.
- Every covering row and every variable has covering degree 11.
- The four variable groups contain 256 variables each and require `(30, 30, 24, 30)` selections.
- Row-to-group profiles are `(0,1,9,1)`, `(1,0,1,9)`, `(1,9,1,0)`, and `(9,1,0,1)`, each occurring 256 times.
- Row-pair and column-pair covering intersections both have the Q10 radius-one signature: 495,616 pairs intersect in zero positions and 28,160 pairs intersect in two.
- MIPLIB metadata: [instance page](https://miplib.zib.de/instance_details_supportcase30.html)

The intersection calculation verifies a structural signature; it is not by itself a complete graph-isomorphism proof.

## Experiment summary

| Method | CPU threads | Limit | Result |
|---|---:|---:|---|
| Gurobi direct feasibility | 32 | 900 s | 0 feasible points; 29,032 nodes |
| COPT direct feasibility | 32 | 900 s | 0 feasible points; 19,027 nodes |
| Gurobi maximum coverage | 32 | 900 s | 984/1,024 |
| Gurobi NoRel maximum coverage | 32 | 900 s | 985/1,024 |
| COPT maximum coverage, default | 32 | 900 s | 969/1,024 |
| COPT maximum coverage, aggressive heuristics | 32 | 900 s | 979/1,024 |
| Gurobi local branch, radius 20 around 984 | 24 | 600 s | 985/1,024; bound 992 |
| Gurobi local branch, radius 40 around 984 | 24 | 600 s | 986/1,024; bound 1,002 |
| Gurobi local branch, radius 30 around 986 | 32 | 600 s | **987/1,024**; bound 991 |
| Quota-preserving tabu from 985 | 1 | 180 s | 985/1,024 |
| Quota-preserving tabu from 986 | 1 | 180 s | 986/1,024 |

All `altman` experiments used the COPT CPU solver only; GPU0 was not used. A time-limit result with no feasible point is not an infeasibility certificate, and a local-branching bound applies only to its stated Hamming ball.

## Legacy workspace sync

The earlier `miplib/miplib` workspace was audited on 2026-09-02.  Its
uncompressed MPS is byte-identical to this directory's compressed input after
decompression, and its maximum-coverage LP and MIP start are byte-identical to
the archived artifacts here.  Its three-minute Gurobi log is already preserved
as `gurobi_mac_maxcover_3min.log` with private license data redacted.  The
remaining legacy smoke runs and 979-row partial point are superseded by the
longer runs and independently checked 987-row point in this study, so they were
not duplicated.

The scripts read the checked-in `.mps.gz` directly. For example:

```powershell
python .\instances\supportcase30\scripts\analyze_structure.py .\instances\supportcase30\input\supportcase30.mps.gz
python .\instances\supportcase30\scripts\supportcase30_search.py .\instances\supportcase30\input\supportcase30.mps.gz --input-sol .\instances\supportcase30\artifacts\supportcase30_best_partial.sol --output checked.sol
```

See the [full study](reports/supportcase30-study.md), [exact structure checker](scripts/analyze_structure.py), [quota-preserving search](scripts/supportcase30_search.py), and [local-branch generator](scripts/make_local_branch_lp.py).
