#!/usr/bin/env python3
"""Parse and search the supportcase30 feasibility instance."""

from __future__ import annotations

import argparse
import gzip
import random
import time
from collections import Counter, defaultdict
from dataclasses import dataclass
from decimal import Decimal
from pathlib import Path


def number(text: str) -> Decimal:
    return Decimal(text.replace("D", "E").replace("d", "e"))


@dataclass
class MPSModel:
    name: str
    row_types: dict[str, str]
    rhs: dict[str, Decimal]
    columns: dict[str, dict[str, Decimal]]
    integer_variables: set[str]
    lower: dict[str, Decimal]
    upper: dict[str, Decimal | None]


def parse_mps(path: Path) -> MPSModel:
    section = ""
    name = path.stem
    row_types: dict[str, str] = {}
    rhs: dict[str, Decimal] = defaultdict(Decimal)
    columns: dict[str, dict[str, Decimal]] = defaultdict(lambda: defaultdict(Decimal))
    integer_variables: set[str] = set()
    bound_records: list[list[str]] = []
    integer_mode = False

    if path.suffix.lower() == ".gz":
        handle_source = gzip.open(path, "rt", encoding="latin-1")
    else:
        handle_source = path.open(encoding="latin-1")

    with handle_source as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if tokens[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = tokens[0]
                if section == "NAME" and len(tokens) > 1:
                    name = tokens[1]
                continue
            if section == "ROWS":
                row_types[tokens[1]] = tokens[0]
            elif section == "COLUMNS":
                if "'MARKER'" in tokens:
                    if "'INTORG'" in tokens:
                        integer_mode = True
                    elif "'INTEND'" in tokens:
                        integer_mode = False
                    continue
                var = tokens[0]
                if integer_mode:
                    integer_variables.add(var)
                for row, coefficient_text in zip(tokens[1::2], tokens[2::2]):
                    columns[var][row] += number(coefficient_text)
            elif section == "RHS":
                for row, value_text in zip(tokens[1::2], tokens[2::2]):
                    rhs[row] += number(value_text)
            elif section == "BOUNDS":
                bound_records.append(tokens)

    lower = {var: Decimal(0) for var in columns}
    upper: dict[str, Decimal | None] = {var: None for var in columns}
    for tokens in bound_records:
        kind, var = tokens[0], tokens[2]
        value = number(tokens[3]) if len(tokens) > 3 else Decimal(0)
        if kind == "LO":
            lower[var] = value
        elif kind == "UP":
            upper[var] = value
        elif kind == "FX":
            lower[var] = upper[var] = value
        elif kind == "FR":
            lower[var], upper[var] = Decimal("-Infinity"), None
        elif kind == "MI":
            lower[var] = Decimal("-Infinity")
        elif kind == "PL":
            upper[var] = None
        elif kind == "BV":
            lower[var], upper[var] = Decimal(0), Decimal(1)
            integer_variables.add(var)
        elif kind == "LI":
            lower[var] = value
            integer_variables.add(var)
        elif kind == "UI":
            upper[var] = value
            integer_variables.add(var)
        else:
            raise ValueError(f"Unsupported bound type {kind}")
    return MPSModel(name, row_types, dict(rhs), dict(columns), integer_variables, lower, upper)


def summarize(model: MPSModel) -> None:
    constraint_rows = {row for row, kind in model.row_types.items() if kind != "N"}
    by_row: dict[str, list[tuple[str, Decimal]]] = defaultdict(list)
    coefficient_counts: Counter[Decimal] = Counter()
    for var, entries in model.columns.items():
        for row, coefficient in entries.items():
            if row in constraint_rows:
                by_row[row].append((var, coefficient))
                coefficient_counts[coefficient] += 1

    print(f"model={model.name}")
    print(f"variables={len(model.columns)} integer={len(model.integer_variables)}")
    print(f"constraints={len(constraint_rows)} row_types={Counter(model.row_types[r] for r in constraint_rows)}")
    print(f"rhs={Counter(model.rhs.get(r, Decimal(0)) for r in constraint_rows)}")
    print(f"row_sizes={Counter(len(by_row[r]) for r in constraint_rows)}")
    print(f"column_sizes={Counter(sum(r in constraint_rows for r in entries) for entries in model.columns.values())}")
    print(f"coefficients={coefficient_counts}")
    print(f"lower_bounds={Counter(model.lower.values())}")
    print(f"upper_bounds={Counter(model.upper.values())}")
    for row in sorted(constraint_rows, key=lambda r: int(r[1:])):
        if model.row_types[row] == "E":
            print(
                f"special row {row}: type={model.row_types[row]} rhs={model.rhs.get(row, Decimal(0))} "
                f"size={len(by_row[row])} vars={[v for v, _ in by_row[row]][:40]}"
            )


@dataclass
class CoverProblem:
    variables: list[str]
    cover_rows: list[str]
    var_rows: list[list[int]]
    row_vars: list[list[int]]
    group_of: list[int]
    group_vars: list[list[int]]
    quotas: list[int]


def extract_cover_problem(model: MPSModel) -> CoverProblem:
    variables = sorted(model.columns, key=lambda v: int(v[1:]))
    variable_index = {var: i for i, var in enumerate(variables)}
    cover_rows = sorted(
        (row for row, kind in model.row_types.items() if kind == "L"),
        key=lambda row: int(row[1:]),
    )
    cover_index = {row: i for i, row in enumerate(cover_rows)}
    var_rows: list[list[int]] = [[] for _ in variables]
    row_vars: list[list[int]] = [[] for _ in cover_rows]
    for var, entries in model.columns.items():
        v = variable_index[var]
        for row, coefficient in entries.items():
            if row not in cover_index:
                continue
            if coefficient != -1 or model.rhs.get(row, Decimal(0)) != -1:
                raise ValueError(f"Unexpected covering row {row}")
            r = cover_index[row]
            var_rows[v].append(r)
            row_vars[r].append(v)

    quota_rows = sorted(
        (row for row, kind in model.row_types.items() if kind == "E"),
        key=lambda row: int(row[1:]),
    )
    group_vars: list[list[int]] = []
    quotas: list[int] = []
    group_of = [-1] * len(variables)
    for group, row in enumerate(quota_rows):
        members = [
            variable_index[var]
            for var, entries in model.columns.items()
            if entries.get(row, Decimal(0)) == 1
        ]
        group_vars.append(sorted(members))
        quotas.append(int(model.rhs[row]))
        for v in members:
            if group_of[v] != -1:
                raise ValueError(f"Variable {variables[v]} belongs to multiple quota groups")
            group_of[v] = group

    if any(group < 0 for group in group_of):
        raise ValueError("Quota rows do not partition the variables")
    if any(len(rows) != 11 for rows in var_rows) or any(len(vars_) != 11 for vars_ in row_vars):
        raise ValueError("Expected an 11-regular radius-one covering matrix")
    return CoverProblem(variables, cover_rows, var_rows, row_vars, group_of, group_vars, quotas)


def greedy_start(problem: CoverProblem, rng: random.Random, randomized: bool) -> list[bool]:
    selected = [False] * len(problem.variables)
    counts = [0] * len(problem.cover_rows)
    used = [0] * len(problem.quotas)
    total = sum(problem.quotas)
    for _ in range(total):
        candidates: list[tuple[int, float, int]] = []
        for v, rows in enumerate(problem.var_rows):
            group = problem.group_of[v]
            if selected[v] or used[group] >= problem.quotas[group]:
                continue
            gain = sum(counts[r] == 0 for r in rows)
            candidates.append((gain, rng.random(), v))
        best_gain = max(gain for gain, _, _ in candidates)
        if randomized:
            restricted = [item for item in candidates if item[0] >= best_gain - 1]
            _, _, chosen = rng.choice(restricted)
        else:
            _, _, chosen = max(candidates)
        selected[chosen] = True
        used[problem.group_of[chosen]] += 1
        for r in problem.var_rows[chosen]:
            counts[r] += 1
    return selected


def move_delta(
    problem: CoverProblem,
    counts: list[int],
    weights: list[int],
    remove: int,
    add: int,
) -> tuple[int, int, int]:
    remove_rows = set(problem.var_rows[remove])
    add_rows = set(problem.var_rows[add])
    delta_uncovered = 0
    delta_weight = 0
    delta_overlap = 0
    for r in remove_rows | add_rows:
        old = counts[r]
        new = old - int(r in remove_rows) + int(r in add_rows)
        old_uncovered = old == 0
        new_uncovered = new == 0
        if old_uncovered != new_uncovered:
            sign = 1 if new_uncovered else -1
            delta_uncovered += sign
            delta_weight += sign * weights[r]
        delta_overlap += new * (new - 1) // 2 - old * (old - 1) // 2
    return delta_weight, delta_uncovered, delta_overlap


def focused_tabu_search(
    problem: CoverProblem,
    selected: list[bool],
    rng: random.Random,
    deadline: float,
    best_known: int,
) -> tuple[list[bool], int, int]:
    counts = [0] * len(problem.cover_rows)
    selected_by_group = [set() for _ in problem.quotas]
    for v, is_selected in enumerate(selected):
        if not is_selected:
            continue
        selected_by_group[problem.group_of[v]].add(v)
        for r in problem.var_rows[v]:
            counts[r] += 1
    uncovered = {r for r, count in enumerate(counts) if count == 0}
    weights = [1] * len(problem.cover_rows)
    cannot_add = [0] * len(problem.variables)
    cannot_remove = [0] * len(problem.variables)
    best_selected = selected.copy()
    best_uncovered = len(uncovered)
    iteration = 0
    stagnation = 0

    while uncovered and time.monotonic() < deadline:
        iteration += 1
        max_weight = max(weights[r] for r in uncovered)
        focus_pool = [r for r in uncovered if weights[r] == max_weight]
        focus = rng.choice(focus_pool)
        moves: list[tuple[tuple[int, int, int, float], int, int]] = []
        tabu_moves: list[tuple[tuple[int, int, int, float], int, int]] = []
        for add in problem.row_vars[focus]:
            if selected[add]:
                continue
            group = problem.group_of[add]
            for remove in selected_by_group[group]:
                delta_weight, delta_uncovered, delta_overlap = move_delta(
                    problem, counts, weights, remove, add
                )
                key = (delta_weight, delta_uncovered, delta_overlap, rng.random())
                entry = (key, remove, add)
                if iteration < cannot_add[add] or iteration < cannot_remove[remove]:
                    if len(uncovered) + delta_uncovered < best_uncovered:
                        moves.append(entry)
                    else:
                        tabu_moves.append(entry)
                else:
                    moves.append(entry)
        if not moves:
            moves = tabu_moves
        key, remove, add = min(moves)
        improving_weight = key[0] < 0

        remove_rows = set(problem.var_rows[remove])
        add_rows = set(problem.var_rows[add])
        for r in remove_rows | add_rows:
            counts[r] += -int(r in remove_rows) + int(r in add_rows)
            if counts[r] == 0:
                uncovered.add(r)
            else:
                uncovered.discard(r)
        group = problem.group_of[add]
        selected[remove] = False
        selected[add] = True
        selected_by_group[group].remove(remove)
        selected_by_group[group].add(add)
        tenure = 7 + rng.randrange(11)
        cannot_add[remove] = iteration + tenure
        cannot_remove[add] = iteration + tenure

        if len(uncovered) < best_uncovered:
            best_uncovered = len(uncovered)
            best_selected = selected.copy()
            stagnation = 0
        else:
            stagnation += 1

        if not improving_weight or stagnation >= 25:
            for r in uncovered:
                weights[r] += 1
            stagnation = 0
        if iteration % 20_000 == 0 and max(weights) > 50:
            weights = [1 + weight // 2 for weight in weights]

        if best_uncovered < best_known:
            return best_selected, best_uncovered, iteration
    return best_selected, best_uncovered, iteration


def search(
    problem: CoverProblem,
    seconds: float,
    seed: int,
    initial: list[bool] | None = None,
) -> tuple[list[bool], int]:
    rng = random.Random(seed)
    deadline = time.monotonic() + seconds
    global_best = initial.copy() if initial is not None else None
    global_uncovered = (
        int(validate_selection(problem, initial)["uncovered"])
        if initial is not None
        else len(problem.cover_rows)
    )
    restart = 0
    while time.monotonic() < deadline and global_uncovered:
        restart += 1
        if restart == 1 and global_best is not None:
            start = global_best.copy()
        else:
            start = greedy_start(problem, rng, randomized=restart > 1)
        candidate, uncovered, iterations = focused_tabu_search(
            problem, start, rng, deadline, global_uncovered
        )
        if uncovered < global_uncovered:
            global_best, global_uncovered = candidate, uncovered
            print(
                f"restart {restart}: uncovered={uncovered}, local_iterations={iterations}",
                flush=True,
            )
    if global_best is None:
        raise RuntimeError("Search produced no candidate")
    return global_best, global_uncovered


def validate_selection(problem: CoverProblem, selected: list[bool]) -> dict[str, object]:
    counts = [0] * len(problem.cover_rows)
    group_counts = [0] * len(problem.quotas)
    for v, chosen in enumerate(selected):
        if not chosen:
            continue
        group_counts[problem.group_of[v]] += 1
        for r in problem.var_rows[v]:
            counts[r] += 1
    return {
        "selected": sum(selected),
        "uncovered": sum(count == 0 for count in counts),
        "minimum_cover": min(counts),
        "maximum_cover": max(counts),
        "group_counts": group_counts,
        "quotas": problem.quotas,
        "overlap_pairs": sum(count * (count - 1) // 2 for count in counts),
    }


def write_solution(path: Path, problem: CoverProblem, selected: list[bool]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        handle.write("# Solution for model supportcase30\n")
        handle.write("# Objective value = 0\n")
        for var, chosen in zip(problem.variables, selected):
            handle.write(f"{var} {int(chosen)}\n")


def write_maxcover_lp(path: Path, problem: CoverProblem) -> None:
    """Write an equivalent guided model whose objective counts covered rows."""
    with path.open("w", encoding="utf-8") as handle:
        handle.write("\\ Maximum-coverage reformulation of supportcase30\n")
        handle.write("Maximize\n coverage:")
        for r in range(len(problem.cover_rows)):
            if r % 16 == 0:
                handle.write("\n ")
            handle.write(f" + y{r + 1}")
        handle.write("\nSubject To\n")
        for r, members in enumerate(problem.row_vars):
            centers = " - ".join(problem.variables[v] for v in members)
            handle.write(f" cover_{r + 1}: y{r + 1} - {centers} <= 0\n")
        for group, members in enumerate(problem.group_vars):
            terms = " + ".join(problem.variables[v] for v in members)
            handle.write(f" quota_{group + 1}: {terms} = {problem.quotas[group]}\n")
        handle.write("Bounds\n")
        for r in range(len(problem.cover_rows)):
            handle.write(f" y{r + 1} <= 1\n")
        handle.write("Binaries\n")
        for start in range(0, len(problem.variables), 16):
            handle.write(" " + " ".join(problem.variables[start : start + 16]) + "\n")
        handle.write("End\n")


def write_maxcover_mst(path: Path, problem: CoverProblem, selected: list[bool]) -> None:
    counts = [0] * len(problem.cover_rows)
    for v, chosen in enumerate(selected):
        if chosen:
            for r in problem.var_rows[v]:
                counts[r] += 1
    with path.open("w", encoding="utf-8") as handle:
        handle.write("# MIP start for supportcase30 maximum-coverage reformulation\n")
        for var, chosen in zip(problem.variables, selected):
            handle.write(f"{var} {int(chosen)}\n")
        for r, count in enumerate(counts):
            handle.write(f"y{r + 1} {int(count > 0)}\n")


def selection_from_solution(path: Path, problem: CoverProblem) -> list[bool]:
    values: dict[str, Decimal] = {}
    with path.open(encoding="utf-8") as handle:
        for raw in handle:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            tokens = line.split()
            if len(tokens) >= 2:
                values[tokens[0]] = number(tokens[1])
    return [values.get(var, Decimal(0)) > Decimal("0.5") for var in problem.variables]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", nargs="?", type=Path, default=Path("supportcase30.mps"))
    parser.add_argument("--summary", action="store_true")
    parser.add_argument("--seconds", type=float, default=60.0)
    parser.add_argument("--seed", type=int, default=30)
    parser.add_argument("--output", type=Path, default=Path("supportcase30_candidate.sol"))
    parser.add_argument("--input-sol", type=Path, help="validate/convert an existing solver solution")
    parser.add_argument(
        "--start-sol",
        type=Path,
        help="continue tabu search from an existing solver or heuristic solution",
    )
    parser.add_argument("--maxcover-lp", type=Path, help="write a guided maximum-coverage LP model")
    parser.add_argument("--maxcover-mst", type=Path, help="write a warm start for the guided model")
    args = parser.parse_args()
    model = parse_mps(args.mps)
    if args.summary:
        summarize(model)
    problem = extract_cover_problem(model)
    if args.input_sol:
        selected = selection_from_solution(args.input_sol, problem)
        uncovered = int(validate_selection(problem, selected)["uncovered"])
    else:
        initial = selection_from_solution(args.start_sol, problem) if args.start_sol else None
        selected, uncovered = search(problem, args.seconds, args.seed, initial)
    report = validate_selection(problem, selected)
    write_solution(args.output, problem, selected)
    if args.maxcover_lp:
        write_maxcover_lp(args.maxcover_lp, problem)
        print(f"wrote {args.maxcover_lp}")
    if args.maxcover_mst:
        write_maxcover_mst(args.maxcover_mst, problem, selected)
        print(f"wrote {args.maxcover_mst}")
    print(f"wrote {args.output}")
    print(f"validation={report}")
    if uncovered:
        raise SystemExit(f"No feasible solution yet: {uncovered} row(s) remain uncovered")


if __name__ == "__main__":
    main()
