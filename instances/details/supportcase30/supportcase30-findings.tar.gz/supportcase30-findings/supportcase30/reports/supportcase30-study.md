#  `supportcase30` experimental report

Date of experiment: 2026 -09 -01 (Asia/Shanghai)

## Conclusion

This round **does not find a feasible solution to the original problem, nor does it prove the entire instance infeasible**.

Currently, the best exact calculation results cover the 1,024 clause covering the 987 clause in the constraint, leaving only the 37 clause blank. The solution happens to select 114 as a binary variable, with the four sets of options numbered `(30,30,24,30)`, which is consistent with the four base number equations of the original model complete; but the 37 clause covering means that it is only a near-feasible partial solution and cannot be submitted as a MIPLIB feasible solution.

The official MIPLIB page still labels `supportcase30` as `open / no_solution`. It is a pure feasibility model, so the two real endpoints of the experiment can only be: finding the option to cover the entire 1,024 line, or giving global infeasible proof.

##  Model structure

The original model had a 1,024 binary variable, a 1,024 bar covering constraints, a 4 bar base number equation and a 12,288 nonzero entries. The four groups of variables each had 256, and each had to select 30, 30, 24, 30, for a total of 114.

Parsing the MPS entry by entry gives:

```text
cover row degree = 11 (all 1,024 lines)
cover column degree = 11 (all 1,024 columns)
group sizes = [256, 256, 256, 256]
quotas = [30, 30, 24, 30]
row group profiles:
  (0,1,9,1), (1,0,1,9), (1,9,1,0), (9,1,0,1)
Each class has 256.
```

The number of common variables between any two covering rows and the number of common rows covered by any two variables have the same distribution: 495,616 pairs with intersection 0 and 28,160 pairs with intersection 2. This matches radius-1 neighborhood intersection counts in the ten-dimensional hypercube Q10. The repository script verifies this **intersection signature**, not a complete graph-isomorphism certificate, so the report does not claim proven isomorphism.

##  Maximum coverage equivalent to relaxation

Introduce the binary variable `y_r` for each line of coverage, retaining the original four group selection quotas, and add:

```text
y_r <= sum(x_j : j covers row r)
maximize sum_r y_r
```

The model can always construct an integer solution; objective 1,024 is feasible if and only if the original MPS is feasible. Thus it can both generate a near-feasible solution that satisfies all of the baseline equations, and can accurately express progress as how much coverage behavior is left in the vacuum. However, only finding 987 is an incumbent of the maximization problem, not proof of the original problem infeasible primal bound.

##  Solver and heuristic results

| Method / host |  Threads |  Time limit |  incumbent  | Global or Neighborhood boundaries |  Notes |
|---|---:|---:|---:|---:|---|
|  Gurobi 13.0.1 original model / `euler4` |  32  |  900 s  | There is no feasible solution |  —  |  29,032 nodes  |
|  COPT 8.0.4 original model / `altman` |  32  |  900 s  | There is no feasible solution |  —  |  19,027 nodes  |
|  Gurobi max-cover / `euler4`  |  32  |  900 s  |  984  |  1,024  | 40 Not covered |
|  Gurobi NoRel max-cover / `euler4`  |  32  |  900 s  |  985  |  1,024  | 39 Not covered |
|  COPT max-cover default / `altman`  |  32  |  900 s  |  969  |  1,024  | 55 Not covered |
|  COPT max-cover aggressive heuristics / `altman`  |  32  |  900 s  |  979  |  1,024  | 45 Not covered |
|  local branch radius 20 around 984 / `euler4`  |  24  |  600 s  |  985  |  992  | Only the Hamming ball is valid. |
|  local branch radius 40 around 984 / `euler4`  |  24  |  600 s  |  986  |  1,002  | Only the Hamming ball is valid. |
|  local branch radius 30 around 986 / `euler4`  |  32  |  600 s  |  **987**  |  991  | Only valid for the Hamming ball; 609,593 nodes |
|  quota-preserving tabu from 985  |  1  |  180 s  |  985  |  —  | No further improvement |
|  quota-preserving tabu from 986  |  1  |  180 s  |  986  |  —  | No further improvement |

COPT aggressive configuration uses `HeurLevel=3`, `PreRoot=3`, `Rounding=3`, `Diving=3`, `SubMip=3`, `FAP=4`. Gurobi NoRel configuration uses `Heuristics=1` and `NoRelHeurTime=300`. All experiments on `altman` are CPU-only, and **does not use GPU0**.

##  The best partial solution is independent computation.

For `supportcase30_best_partial.sol` just read the `x` variable and then recalculate all coverage and allowance from the original MPS:

```text
selected = 114
group_counts = [30, 30, 24, 30]
uncovered = 37
minimum_cover = 0
maximum_cover = 4
overlap_pairs = 302
```

`minimum_cover=0` cannot be used as a feasible solution to the original problem. The calculator does not rely on Gurobi or COPT and uses only Python standard library parse MPS and solution.

##  Conclusion on the Border

-  There is no feasible solution within the time limit of the direct solver.
-  The objective 987 of the max-cover is a feasible lower bound; the solver global primal bound of the non-local branch is still 1,024, with no exclusion of full coverage.
-  The operation of the radius 20 / 40 / 30 also ends at the time limit; its boundary belongs only to the corresponding Hamming ball and cannot be extended to the entire model.
-  Currently, the most reliable results are structural recovery, reproducible search processes and a strictly validated 987 / 1,024 partial solution.

##  Reproducible files

-  `input/supportcase30.mps.gz`: the original compressed MPS.
-  `scripts/analyze_structure.py`: exact statistics, group profile and crossover signature.
-  `scripts/supportcase30_search.py`: generate a max-cover model, read a solver solution, maintain a quota tabu, search and independent test.
-  `scripts/make_local_branch_lp.py`: Add a Hamming ball with a relatively specified incumbent to the max-cover LP.
-  `artifacts/supportcase30_best_partial.sol`: The current best 987 / 1,024 partial solution with only the original model variable.
-  `artifacts/gurobi_lb30_from986_10m.sol`: a complete max-cover solver solution that produces the best current solution.
-  `artifacts/supportcase30_maxcover.lp`: The largest model of coverage.
-  `logs/`: Gurobi and the original diary of COPT.

## material

- [MIPLIB：supportcase30 instance details](https://miplib.zib.de/instance_details_supportcase30.html)
- [MIPLIB：open tag](https://miplib.zib.de/tag_open.html)
