# Package manifest: supportcase30

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 29
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/best_partial_validation.txt`
- `artifacts/copt_maxcover_15m.sol`
- `artifacts/copt_maxcover_heur_15m.sol`
- `artifacts/gurobi_lb20_10m.sol`
- `artifacts/gurobi_lb30_from986_10m.sol`
- `artifacts/gurobi_lb40_10m.sol`
- `artifacts/gurobi_maxcover_15m.sol`
- `artifacts/gurobi_maxcover_norel_15m.sol`
- `artifacts/supportcase30_best_partial.sol`
- `artifacts/supportcase30_maxcover.lp`
- `artifacts/supportcase30_maxcover.mst`
- `artifacts/supportcase30_tabu_from_985_180s.sol`
- `artifacts/supportcase30_tabu_from_986_180s.sol`
- `artifacts/supportcase30_tabu_from_gurobi_120s.sol`
- `logs/copt_maxcover_15m.log`
- `logs/copt_maxcover_heur_15m.log`
- `logs/copt_raw_15m.log`
- `logs/gurobi_lb20_10m.log`
- `logs/gurobi_lb30_from986_10m.log`
- `logs/gurobi_lb40_10m.log`
- `logs/gurobi_mac_maxcover_3min.log`
- `logs/gurobi_maxcover_15m.log`
- `logs/gurobi_maxcover_norel_15m.log`
- `logs/gurobi_raw_15m.log`
- `reports/supportcase30-study.md`
- `scripts/analyze_structure.py`
- `scripts/make_local_branch_lp.py`
- `scripts/supportcase30_search.py`

## Excluded files

- `input/supportcase30.mps.gz (56295 bytes; raw benchmark input; sha256 8398737d9c65b5c9f7435f4284c09e27218c44a54472229ac46ec5f570de5d91)`
