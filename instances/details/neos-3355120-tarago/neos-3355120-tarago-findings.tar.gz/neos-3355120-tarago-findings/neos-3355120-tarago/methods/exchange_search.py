#!/usr/bin/env python3
import argparse, gzip, json, math, os, random, time


def open_text(path):
    return gzip.open(path, "rt", errors="replace") if path.endswith(".gz") else open(path, "r", errors="replace")


def parse_mps(path):
    section = None
    objective_row = None
    sense = {}
    rhs = {}
    columns = {}
    obj = {}
    integer_vars = set()
    marker_integer = False
    lb, ub = {}, {}
    first_rhs_set = None
    first_bound_set = None
    objective_multiplier = 1.0
    with open_text(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("*"):
                continue
            tok = line.split()
            key = tok[0].upper()
            if key in ("NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA", "OBJSENSE", "OBJNAME"):
                section = key
                if key == "ENDATA":
                    break
                continue
            if section == "OBJSENSE":
                if key.startswith("MAX"):
                    objective_multiplier = -1.0
                section = None
                continue
            if section == "ROWS":
                if len(tok) >= 2:
                    typ, name = tok[0].upper(), tok[1]
                    if typ == "N" and objective_row is None:
                        objective_row = name
                    elif typ in ("L", "G", "E"):
                        sense[name] = typ
                continue
            if section == "COLUMNS":
                if "MARKER" in line.upper():
                    upper = line.upper()
                    marker_integer = "INTORG" in upper
                    if "INTEND" in upper:
                        marker_integer = False
                    continue
                if len(tok) < 3:
                    continue
                var = tok[0]
                if marker_integer:
                    integer_vars.add(var)
                columns.setdefault(var, {})
                pairs = tok[1:]
                for i in range(0, len(pairs) - 1, 2):
                    row = pairs[i]
                    try:
                        val = float(pairs[i + 1].replace("D", "E").replace("d", "e"))
                    except ValueError:
                        continue
                    if row == objective_row:
                        obj[var] = obj.get(var, 0.0) + objective_multiplier * val
                    elif row in sense:
                        columns[var][row] = columns[var].get(row, 0.0) + val
                continue
            if section == "RHS":
                if len(tok) < 3:
                    continue
                setname = tok[0]
                if first_rhs_set is None:
                    first_rhs_set = setname
                if setname != first_rhs_set:
                    continue
                pairs = tok[1:]
                for i in range(0, len(pairs) - 1, 2):
                    try:
                        rhs[pairs[i]] = float(pairs[i + 1].replace("D", "E").replace("d", "e"))
                    except ValueError:
                        pass
                continue
            if section == "BOUNDS":
                if len(tok) < 3:
                    continue
                typ, setname, var = tok[0].upper(), tok[1], tok[2]
                if first_bound_set is None:
                    first_bound_set = setname
                if setname != first_bound_set:
                    continue
                val = 0.0
                if len(tok) >= 4:
                    try:
                        val = float(tok[3].replace("D", "E").replace("d", "e"))
                    except ValueError:
                        val = 0.0
                if typ == "LO": lb[var] = val
                elif typ == "UP": ub[var] = val
                elif typ == "FX": lb[var] = val; ub[var] = val
                elif typ == "FR": lb[var] = -math.inf; ub[var] = math.inf
                elif typ == "MI": lb[var] = -math.inf
                elif typ == "PL": ub[var] = math.inf
                elif typ == "BV": lb[var] = 0.0; ub[var] = 1.0; integer_vars.add(var)
                elif typ == "LI": lb[var] = val; integer_vars.add(var)
                elif typ == "UI": ub[var] = val; integer_vars.add(var)
    variables = list(columns.keys())
    for v in variables:
        lb.setdefault(v, 0.0)
        ub.setdefault(v, math.inf)
        obj.setdefault(v, 0.0)
    for r in sense:
        rhs.setdefault(r, 0.0)
    return variables, columns, obj, sense, rhs, lb, ub, integer_vars


def read_solution(path):
    values = {}
    if not path or not os.path.exists(path):
        raise FileNotFoundError("The required verified incumbent was not mounted: " + str(path))
    with open(path, "r", errors="replace") as f:
        for raw in f:
            s = raw.strip()
            if not s or s.startswith("#"):
                continue
            tok = s.split()
            if len(tok) >= 2:
                try:
                    values[tok[0]] = float(tok[1])
                except ValueError:
                    pass
    return values


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--start", required=True)
    ap.add_argument("--seconds", type=float, default=1600.0)
    ap.add_argument("--seed", type=int, default=3355120)
    args = ap.parse_args()
    started = time.time()
    rng = random.Random(args.seed)
    variables, columns, obj, senses, rhsv, lbs, ubs, integers = parse_mps(args.model)
    start_values = read_solution(args.start)
    values = {v: start_values.get(v, 0.0) for v in variables}
    rows = list(senses)
    rid = {r: i for i, r in enumerate(rows)}
    rhs = [rhsv[r] for r in rows]
    row_sense = [senses[r] for r in rows]
    incidence = {}
    row_entries = [[] for _ in rows]
    for v in variables:
        ent = []
        for r, a in columns[v].items():
            if abs(a) > 1e-15:
                j = rid[r]
                ent.append((j, a))
                row_entries[j].append((v, a))
        incidence[v] = ent
    activity = [0.0] * len(rows)
    for v in variables:
        xv = values[v]
        if xv:
            for j, a in incidence[v]:
                activity[j] += a * xv
    binaries = [v for v in variables if v in integers and abs(lbs[v]) <= 1e-10 and abs(ubs[v] - 1.0) <= 1e-10 and abs(values[v] - round(values[v])) <= 1e-7]
    binary_set = set(binaries)
    tol = 2e-7

    def row_ok(j, a):
        if row_sense[j] == "L": return a <= rhs[j] + tol
        if row_sense[j] == "G": return a >= rhs[j] - tol
        return abs(a - rhs[j]) <= tol

    initial_feasible = all(row_ok(j, activity[j]) for j in range(len(rows)))
    if not initial_feasible:
        raise RuntimeError("Mounted incumbent is not feasible under the independently parsed MPS")

    packing_rows = all(s == "L" for s in row_sense)
    negative_mutable_coefficients = 0
    mutable_coefficients = 0
    for v in binaries:
        for _, a in incidence[v]:
            mutable_coefficients += 1
            if a < -1e-12:
                negative_mutable_coefficients += 1
    packing = packing_rows and negative_mutable_coefficients == 0

    def objective(x):
        return sum(obj[v] * x[v] for v in variables)

    current_obj = objective(values)
    initial_obj = current_obj
    best_values = dict(values)
    best_obj = current_obj
    improvements = 0
    attempted_exchanges = 0

    def can_set(v, nv, acts, vals):
        delta = nv - vals[v]
        if abs(delta) < 0.5:
            return True
        for j, a in incidence[v]:
            if not row_ok(j, acts[j] + a * delta):
                return False
        return True

    def apply(v, nv, acts, vals):
        delta = nv - vals[v]
        if abs(delta) < 0.5:
            return
        vals[v] = float(nv)
        for j, a in incidence[v]:
            acts[j] += a * delta

    # Always-safe improving coordinate descent.
    changed = True
    while changed:
        changed = False
        order = list(binaries)
        rng.shuffle(order)
        order.sort(key=lambda v: obj[v] * (1.0 - 2.0 * values[v]))
        for v in order:
            nv = 1 - int(round(values[v]))
            delta_obj = obj[v] * (nv - values[v])
            if delta_obj < -1e-8 and can_set(v, nv, activity, values):
                apply(v, nv, activity, values)
                current_obj += delta_obj
                changed = True
                improvements += 1
        if time.time() - started > args.seconds:
            break
    if current_obj < best_obj - 1e-7:
        best_obj = current_obj
        best_values = dict(values)

    # Monotone packing permits safe deletion, blocker exchanges, and ruin/recreate.
    if packing and time.time() - started < args.seconds:
        profitable = [v for v in binaries if obj[v] < -1e-10]

        def greedy_fill(vals, acts, randomized=True):
            cand = [v for v in profitable if vals[v] < 0.5]
            def score(v):
                burden = 0.0
                for j, a in incidence[v]:
                    slack = max(1e-9, rhs[j] - acts[j])
                    burden += a / (slack + a + 1e-9)
                base = (-obj[v]) / (0.05 + burden)
                return base * (rng.uniform(0.75, 1.25) if randomized else 1.0)
            cand.sort(key=score, reverse=True)
            for v in cand:
                if can_set(v, 1, acts, vals):
                    apply(v, 1, acts, vals)

        # Target valuable excluded variables and remove cheap blockers until they fit.
        targets = sorted(profitable, key=lambda v: obj[v])
        for target in targets:
            if time.time() - started > args.seconds:
                break
            if best_values[target] > 0.5:
                continue
            attempted_exchanges += 1
            vals = dict(best_values)
            acts = [0.0] * len(rows)
            for v in variables:
                if vals[v]:
                    for j, a in incidence[v]: acts[j] += a * vals[v]
            removed = set()
            guard = 0
            while not can_set(target, 1, acts, vals) and guard < 100:
                guard += 1
                violated = []
                for j, a in incidence[target]:
                    excess = acts[j] + a - rhs[j]
                    if excess > tol: violated.append((j, excess))
                blockers = {}
                for j, excess in violated:
                    for v, a in row_entries[j]:
                        if v in binary_set and vals.get(v, 0.0) > 0.5 and a > 1e-12:
                            blockers[v] = blockers.get(v, 0.0) + min(a, excess) / max(excess, 1e-12)
                if not blockers:
                    break
                def removal_cost(v):
                    lost_profit = max(0.0, -obj[v])
                    return (lost_profit + 1e-6) / blockers[v]
                victim = min(blockers, key=removal_cost)
                apply(victim, 0, acts, vals)
                removed.add(victim)
            if can_set(target, 1, acts, vals):
                apply(target, 1, acts, vals)
                greedy_fill(vals, acts, randomized=False)
                val_obj = objective(vals)
                if val_obj < best_obj - 1e-7:
                    best_obj, best_values = val_obj, dict(vals)
                    improvements += 1

        # Randomized neighborhoods vary both the removed seed and destruction size.
        iteration = 0
        while time.time() - started < args.seconds:
            iteration += 1
            vals = dict(best_values)
            acts = [0.0] * len(rows)
            for v in variables:
                if vals[v]:
                    for j, a in incidence[v]: acts[j] += a * vals[v]
            selected = [v for v in binaries if vals[v] > 0.5]
            if not selected:
                break
            k = 1 + int(rng.random() ** 2 * min(24, len(selected)))
            seed = rng.choice(selected)
            neighborhood = {seed}
            touched = {j for j, _ in incidence[seed]}
            nearby = []
            for j in touched:
                nearby.extend(v for v, a in row_entries[j] if v in binary_set and vals.get(v, 0.0) > 0.5 and v != seed)
            rng.shuffle(nearby)
            for v in nearby:
                if len(neighborhood) >= k: break
                neighborhood.add(v)
            while len(neighborhood) < k:
                neighborhood.add(rng.choice(selected))
            for v in neighborhood:
                apply(v, 0, acts, vals)
            greedy_fill(vals, acts, randomized=True)
            val_obj = objective(vals)
            if val_obj < best_obj - 1e-7:
                best_obj, best_values = val_obj, dict(vals)
                improvements += 1
            if iteration % 25 == 0:
                with open("exchange_trace.txt", "a", encoding="utf-8") as tr:
                    tr.write(f"iteration={iteration} best_objective={best_obj:.17g} elapsed={time.time()-started:.3f}\n")

    # Recompute and strictly test the emitted candidate under parsed rows and bounds.
    final_activity = [0.0] * len(rows)
    for v in variables:
        xv = best_values[v]
        for j, a in incidence[v]: final_activity[j] += a * xv
    final_feasible = all(row_ok(j, final_activity[j]) for j in range(len(rows)))
    bound_violation = max([max(0.0, lbs[v] - best_values[v], best_values[v] - ubs[v]) for v in variables] + [0.0])
    integral_violation = max([abs(best_values[v] - round(best_values[v])) for v in integers] + [0.0])
    final_feasible = final_feasible and bound_violation <= tol and integral_violation <= tol
    if not final_feasible:
        raise RuntimeError("Internal feasibility check rejected the final exchange candidate")
    with open("best.sol", "w", encoding="utf-8") as out:
        out.write(f"# Objective value = {best_obj:.17g}\n")
        for v in variables:
            out.write(f"{v} {best_values[v]:.17g}\n")
    result = {
        "method": "incumbent_centered_binary_exchange",
        "status": "candidate_written",
        "initial_objective_parsed": initial_obj,
        "best_objective_parsed": best_obj,
        "improvement": initial_obj - best_obj,
        "packing_structure_detected": packing,
        "all_rows_upper_bound": packing_rows,
        "mutable_binary_count": len(binaries),
        "mutable_coefficient_count": mutable_coefficients,
        "negative_mutable_coefficient_count": negative_mutable_coefficients,
        "row_count": len(rows),
        "variable_count": len(variables),
        "attempted_target_exchanges": attempted_exchanges,
        "accepted_improvements": improvements,
        "independent_internal_feasible": final_feasible,
        "max_bound_violation": bound_violation,
        "max_integrality_violation": integral_violation,
        "runtime_seconds": time.time() - started,
        "note": "Optimality is not claimed; the controller must independently verify best.sol."
    }
    with open("method_result.json", "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, sort_keys=True)

if __name__ == "__main__":
    main()
