import argparse, gzip, json, math, os, sys, time
from collections import defaultdict


def open_model(path):
    return gzip.open(path, 'rt', errors='replace') if path.lower().endswith('.gz') else open(path, 'r', errors='replace')


def parse_mps(path):
    section = None
    objrow = None
    objsense = 1.0
    rows = {}
    cols = defaultdict(dict)
    obj = defaultdict(float)
    rhs = defaultdict(float)
    ranges = {}
    lb = defaultdict(float)
    ub = defaultdict(lambda: math.inf)
    integer = set()
    in_integer = False
    active_rhs = None
    active_range = None
    active_bound = None
    with open_model(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('*'):
                continue
            t = line.split()
            key = t[0].upper()
            if key in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE','OBJNAME'):
                section = key
                if key == 'ENDATA':
                    break
                continue
            if section == 'OBJSENSE':
                if key.startswith('MAX'):
                    objsense = -1.0
                elif key.startswith('MIN'):
                    objsense = 1.0
                continue
            if section == 'ROWS':
                if len(t) >= 2:
                    typ, name = t[0].upper(), t[1]
                    if typ == 'N' and objrow is None:
                        objrow = name
                    elif typ in ('L','G','E'):
                        rows[name] = typ
                continue
            if section == 'COLUMNS':
                if len(t) >= 3 and t[1].strip("'\"").upper() == 'MARKER':
                    mark = t[2].strip("'\"").upper()
                    in_integer = mark == 'INTORG' if mark in ('INTORG','INTEND') else in_integer
                    continue
                var = t[0]
                if in_integer:
                    integer.add(var)
                k = 1
                while k + 1 < len(t):
                    row = t[k]
                    try:
                        val = float(t[k+1].replace('D','E').replace('d','e'))
                    except ValueError:
                        k += 2
                        continue
                    if row == objrow:
                        obj[var] += objsense * val
                    elif row in rows:
                        cols[var][row] = cols[var].get(row, 0.0) + val
                    k += 2
                continue
            if section == 'RHS':
                if len(t) < 3:
                    continue
                if active_rhs is None:
                    active_rhs = t[0]
                if t[0] != active_rhs:
                    continue
                k = 1
                while k + 1 < len(t):
                    try: rhs[t[k]] = float(t[k+1].replace('D','E').replace('d','e'))
                    except ValueError: pass
                    k += 2
                continue
            if section == 'RANGES':
                if len(t) < 3:
                    continue
                if active_range is None:
                    active_range = t[0]
                if t[0] != active_range:
                    continue
                k = 1
                while k + 1 < len(t):
                    try: ranges[t[k]] = float(t[k+1].replace('D','E').replace('d','e'))
                    except ValueError: pass
                    k += 2
                continue
            if section == 'BOUNDS':
                if len(t) < 3:
                    continue
                typ, bset, var = t[0].upper(), t[1], t[2]
                if active_bound is None:
                    active_bound = bset
                if bset != active_bound:
                    continue
                val = 0.0
                if len(t) >= 4:
                    try: val = float(t[3].replace('D','E').replace('d','e'))
                    except ValueError: val = 0.0
                if typ == 'LO': lb[var] = val
                elif typ == 'UP': ub[var] = val
                elif typ == 'FX': lb[var] = val; ub[var] = val
                elif typ == 'FR': lb[var] = -math.inf; ub[var] = math.inf
                elif typ == 'MI': lb[var] = -math.inf
                elif typ == 'PL': ub[var] = math.inf
                elif typ == 'BV': lb[var] = 0.0; ub[var] = 1.0; integer.add(var)
                elif typ == 'LI': lb[var] = val; integer.add(var)
                elif typ == 'UI': ub[var] = val; integer.add(var)
    allvars = set(cols) | set(obj) | set(lb) | set(ub)
    lower, upper = {}, {}
    for r, typ in rows.items():
        b = rhs.get(r, 0.0)
        if r not in ranges:
            lower[r] = b if typ in ('G','E') else -math.inf
            upper[r] = b if typ in ('L','E') else math.inf
        else:
            q = ranges[r]
            a = abs(q)
            if typ == 'L': lower[r], upper[r] = b-a, b
            elif typ == 'G': lower[r], upper[r] = b, b+a
            elif q >= 0: lower[r], upper[r] = b, b+a
            else: lower[r], upper[r] = b-a, b
    return allvars, cols, obj, lb, ub, integer, lower, upper


def find_start():
    preferred = '/resources/best.sol'
    if os.path.isfile(preferred):
        return preferred
    if os.path.isdir('/resources'):
        sols = sorted(os.path.join('/resources', x) for x in os.listdir('/resources') if x.lower().endswith(('.sol','.mst')))
        if sols:
            return sols[0]
    return None


def read_solution(path):
    x = {}
    with open(path, 'r', errors='replace') as f:
        for raw in f:
            s = raw.strip()
            if not s or s.startswith('#'):
                continue
            t = s.split()
            if len(t) < 2:
                continue
            try: x[t[0]] = float(t[1])
            except ValueError: pass
    return x


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--max-seconds', type=float, default=1050.0)
    ap.add_argument('--max-primary', type=int, default=4000)
    ap.add_argument('--max-partners', type=int, default=6000)
    args = ap.parse_args()
    began = time.time()
    start = find_start()
    if start is None:
        raise FileNotFoundError('No incumbent .sol or .mst file was mounted under /resources')
    allvars, cols, obj, lb, ub, integer, lower, upper = parse_mps(args.model)
    x = read_solution(start)
    for v in allvars:
        x.setdefault(v, 0.0)
    activity = defaultdict(float)
    rowvars = defaultdict(list)
    for v, cv in cols.items():
        xv = x.get(v, 0.0)
        for r, a in cv.items():
            activity[r] += a*xv
            rowvars[r].append(v)
    binaries = []
    for v in integer:
        if lb[v] >= -1e-9 and ub[v] <= 1.0+1e-9 and abs(x[v]-round(x[v])) <= 1e-6:
            binaries.append(v)
    tol = 2e-7

    def row_ok(r, value):
        scale = max(1.0, abs(value), abs(lower[r]) if math.isfinite(lower[r]) else 1.0, abs(upper[r]) if math.isfinite(upper[r]) else 1.0)
        return value >= lower[r]-tol*scale and value <= upper[r]+tol*scale

    def feasible_changes(changes):
        delta_rows = defaultdict(float)
        for v, d in changes:
            for r, a in cols.get(v, {}).items():
                delta_rows[r] += a*d
        for r, d in delta_rows.items():
            if not row_ok(r, activity[r]+d):
                return False
        return True

    def apply(changes):
        for v, d in changes:
            x[v] += d
            for r, a in cols.get(v, {}).items():
                activity[r] += a*d

    initial_obj = sum(obj.get(v,0.0)*val for v,val in x.items())
    moves = 0
    single_tests = 0
    pair_tests = 0
    while time.time()-began < args.max_seconds:
        toggles = []
        for v in binaries:
            d = 1.0 if x[v] < 0.5 else -1.0
            dc = obj.get(v,0.0)*d
            toggles.append((dc, v, d))
        toggles.sort()
        improved = False
        for dc, v, d in toggles:
            if dc >= -1e-10:
                break
            single_tests += 1
            if feasible_changes([(v,d)]):
                apply([(v,d)]); moves += 1; improved = True
                break
        if improved:
            continue
        best = None
        primary = toggles[:args.max_primary]
        for dc1, v, d1 in primary:
            if time.time()-began >= args.max_seconds:
                break
            # Sparse exchanges only need inspect variables sharing an affected row.
            partners = set()
            for r in cols.get(v,{}):
                partners.update(rowvars[r])
                if len(partners) >= args.max_partners:
                    break
            checked = 0
            for w in partners:
                if w == v or w not in integer or not (lb[w] >= -1e-9 and ub[w] <= 1.0+1e-9):
                    continue
                d2 = 1.0 if x[w] < 0.5 else -1.0
                gain = dc1 + obj.get(w,0.0)*d2
                if gain >= -1e-10 or (best is not None and gain >= best[0]):
                    continue
                pair_tests += 1
                checked += 1
                if feasible_changes([(v,d1),(w,d2)]):
                    best = (gain,v,d1,w,d2)
                if checked >= args.max_partners:
                    break
        if best is None:
            break
        apply([(best[1],best[2]),(best[3],best[4])])
        moves += 1
    final_obj = sum(obj.get(v,0.0)*val for v,val in x.items())
    with open('best.sol','w') as f:
        f.write('# Structure-specific sparse exchange candidate\n')
        f.write('# Objective value = %.17g\n' % final_obj)
        for v in sorted(x):
            val = x[v]
            if abs(val) < 1e-15: val = 0.0
            f.write('%s %.17g\n' % (v,val))
    result = {
        'status':'candidate', 'method':'incumbent_sparse_binary_exchange',
        'start_file':os.path.basename(start), 'initial_objective':initial_obj,
        'candidate_objective':final_obj, 'improvement':initial_obj-final_obj,
        'binary_variables':len(binaries), 'accepted_moves':moves,
        'single_tests':single_tests, 'pair_tests':pair_tests,
        'runtime_seconds':time.time()-began,
        'claim':'Heuristic candidate only; controller verification is required.'
    }
    with open('method_result.json','w') as f: json.dump(result,f,indent=2,sort_keys=True)
    print(json.dumps(result,sort_keys=True))

if __name__ == '__main__':
    main()
