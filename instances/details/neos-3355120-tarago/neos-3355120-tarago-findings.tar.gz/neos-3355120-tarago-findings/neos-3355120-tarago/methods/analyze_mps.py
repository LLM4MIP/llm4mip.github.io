#!/usr/bin/env python3
import argparse, collections, gzip, hashlib, json, math, os, re

p = argparse.ArgumentParser()
p.add_argument('--model', required=True)
p.add_argument('--output', default='mps_pattern_analysis.json')
a = p.parse_args()

def op(path):
    return gzip.open(path, 'rt', encoding='utf-8', errors='replace') if path.endswith('.gz') else open(path, 'rt', encoding='utf-8', errors='replace')

def stem(s):
    s = re.sub(r'\d+', '#', s)
    s = re.sub(r'[#_\-.]+$', '', s)
    return s or '#'

def fnum(x):
    return float(x.replace('D','E').replace('d','e'))

section = None
objrow = None
rowsense = {}
rowcoef = collections.defaultdict(list)
varrows = collections.defaultdict(list)
obj = collections.defaultdict(float)
rhs = collections.defaultdict(float)
ranges = collections.defaultdict(float)
bounds = collections.defaultdict(dict)
integer_mode = False
allvars = set()
raw_hash = hashlib.sha256()
with op(a.model) as fh:
    for raw in fh:
        raw_hash.update(raw.encode('utf-8', errors='replace'))
        line = raw.rstrip('\n\r')
        if not line or line.lstrip().startswith('*'):
            continue
        tok = line.split()
        if not tok:
            continue
        head = tok[0].upper()
        if head in {'NAME','OBJSENSE','OBJNAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA'}:
            section = head
            if head == 'ENDATA': break
            continue
        if section == 'OBJSENSE':
            continue
        if section == 'ROWS':
            if len(tok) >= 2:
                s, r = tok[0].upper(), tok[1]
                if s == 'N' and objrow is None: objrow = r
                elif s in {'L','G','E'}: rowsense[r] = s
        elif section == 'COLUMNS':
            if any('MARKER' in z.upper() for z in tok):
                u = ' '.join(tok).upper()
                if 'INTORG' in u: integer_mode = True
                elif 'INTEND' in u: integer_mode = False
                continue
            if len(tok) < 3: continue
            v = tok[0]; allvars.add(v)
            pairs = tok[1:]
            for i in range(0, len(pairs)-1, 2):
                r = pairs[i]
                try: val = fnum(pairs[i+1])
                except Exception: continue
                if r == objrow: obj[v] += val
                elif r in rowsense:
                    rowcoef[r].append((v,val)); varrows[v].append((r,val))
        elif section in {'RHS','RANGES'}:
            if len(tok) < 3: continue
            pairs = tok[1:]
            target = rhs if section == 'RHS' else ranges
            for i in range(0, len(pairs)-1, 2):
                try: target[pairs[i]] = fnum(pairs[i+1])
                except Exception: pass
        elif section == 'BOUNDS':
            if len(tok) >= 3:
                bt, v = tok[0].upper(), tok[2]; allvars.add(v)
                val = None
                if len(tok) >= 4:
                    try: val = fnum(tok[3])
                    except Exception: pass
                bounds[v][bt] = val

support_hist = collections.Counter(len(rowcoef[r]) for r in rowsense)
degree_hist = collections.Counter(len(varrows[v]) for v in allvars)
row_prefix = collections.Counter(stem(r) for r in rowsense)
var_prefix = collections.Counter(stem(v) for v in allvars)
coef_freq = collections.Counter(round(abs(x),12) for r in rowcoef.values() for _,x in r)
rhs_freq = collections.Counter(round(x,12) for x in rhs.values())
obj_freq = collections.Counter(round(x,12) for x in obj.values() if x != 0)

def signature(r):
    vals = tuple(sorted(round(x,9) for _,x in rowcoef[r]))
    return (rowsense[r], len(vals), round(rhs.get(r,0.0),9), vals)
sig = collections.defaultdict(list)
for r in rowsense: sig[signature(r)].append(r)
large_families = sorted(sig.values(), key=len, reverse=True)[:30]

# Connected components in the row-variable incidence graph.
seen_v, seen_r, comps = set(), set(), []
for seed in allvars:
    if seed in seen_v: continue
    qv=[seed]; seen_v.add(seed); nv=nr=ne=0
    while qv:
        v=qv.pop(); nv += 1
        for r,_ in varrows[v]:
            ne += 1
            if r in seen_r: continue
            seen_r.add(r); nr += 1
            for w,_ in rowcoef[r]:
                if w not in seen_v: seen_v.add(w); qv.append(w)
    comps.append({'variables':nv,'rows':nr,'incidences_counted_from_variables':ne})
for r in rowsense:
    if r not in seen_r: comps.append({'variables':0,'rows':1,'incidences_counted_from_variables':0})
comps.sort(key=lambda z:(z['variables']+z['rows']), reverse=True)

out = {
 'model_sha256_as_read_text': raw_hash.hexdigest(), 'objective_row': objrow,
 'counts': {'variables':len(allvars),'rows':len(rowsense),'nonzeros':sum(map(len,rowcoef.values())),'objective_nonzeros':sum(1 for x in obj.values() if x)},
 'row_senses': dict(collections.Counter(rowsense.values())),
 'row_support_histogram': {str(k):v for k,v in sorted(support_hist.items())},
 'variable_degree_histogram': {str(k):v for k,v in sorted(degree_hist.items())},
 'row_name_families': row_prefix.most_common(40), 'variable_name_families': var_prefix.most_common(40),
 'row_name_samples': list(rowsense)[:80], 'variable_name_samples': sorted(allvars)[:80],
 'most_common_absolute_matrix_coefficients': coef_freq.most_common(40),
 'most_common_rhs_values': rhs_freq.most_common(30), 'most_common_objective_values': obj_freq.most_common(30),
 'largest_exact_row_signature_families': [{'count':len(g),'sample':g[:12]} for g in large_families],
 'connected_components': comps[:50], 'component_count':len(comps),
 'bounds_type_counts': dict(collections.Counter(k for d in bounds.values() for k in d)),
 'largest_rows': [{'row':r,'sense':rowsense[r],'rhs':rhs.get(r,0.0),'nnz':len(rowcoef[r]),'terms':rowcoef[r][:20]} for r in sorted(rowsense,key=lambda x:len(rowcoef[x]),reverse=True)[:25]],
 'highest_degree_variables': [{'variable':v,'degree':len(varrows[v]),'objective':obj.get(v,0.0),'bounds':bounds.get(v,{}),'rows':varrows[v][:20]} for v in sorted(allvars,key=lambda x:len(varrows[x]),reverse=True)[:25]]
}
with open(a.output,'w',encoding='utf-8') as f: json.dump(out,f,indent=2,sort_keys=True)
print(json.dumps({'output':a.output,'counts':out['counts'],'component_count':len(comps)}))
