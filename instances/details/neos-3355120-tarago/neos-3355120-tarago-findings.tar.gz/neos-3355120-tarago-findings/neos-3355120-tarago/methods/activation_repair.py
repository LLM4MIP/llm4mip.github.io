import argparse, gzip, json, math, os, random, time
from collections import defaultdict


def tokens(line):
    return line.strip().split()


def read_mps(path):
    op = gzip.open if path.lower().endswith('.gz') else open
    rows = {}
    row_order = []
    objrow = None
    cols = defaultdict(dict)
    obj = defaultdict(float)
    rhs = defaultdict(float)
    lb = defaultdict(float)
    ub = defaultdict(lambda: float('inf'))
    integer = set()
    section = None
    int_mode = False
    sense = 1.0
    with op(path, 'rt', errors='replace') as f:
        for raw in f:
            s = raw.strip()
            if not s or s.startswith('*'):
                continue
            t = tokens(raw)
            head = t[0].upper()
            if head in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE'):
                section = head
                if head == 'ENDATA':
                    break
                continue
            if section == 'OBJSENSE':
                if head.startswith('MAX'):
                    sense = -1.0
                elif head.startswith('MIN'):
                    sense = 1.0
                continue
            if section == 'ROWS':
                typ, name = t[0].upper(), t[1]
                if typ == 'N' and objrow is None:
                    objrow = name
                elif typ in ('L','G','E'):
                    rows[name] = typ
                    row_order.append(name)
                continue
            if section == 'COLUMNS':
                if len(t) >= 3 and 'MARKER' in t[1].upper():
                    mark = t[2].upper().replace("'", '')
                    int_mode = mark == 'INTORG'
                    continue
                var = t[0]
                if int_mode:
                    integer.add(var)
                for k in range(1, len(t)-1, 2):
                    r = t[k]
                    try:
                        a = float(t[k+1])
                    except ValueError:
                        continue
                    if r == objrow:
                        obj[var] += sense * a
                    elif r in rows:
                        cols[var][r] = cols[var].get(r, 0.0) + a
                continue
            if section == 'RHS':
                for k in range(1, len(t)-1, 2):
                    r = t[k]
                    if r in rows:
                        rhs[r] = float(t[k+1])
                continue
            if section == 'RANGES':
                # This heuristic declines ranged rows because preserving them requires
                # retaining both bounds explicitly. The result records this condition.
                continue
            if section == 'BOUNDS':
                typ = t[0].upper()
                var = t[2]
                val = float(t[3]) if len(t) > 3 else 0.0
                if typ == 'BV':
                    integer.add(var); lb[var] = 0.0; ub[var] = 1.0
                elif typ in ('LI','UI'):
                    integer.add(var)
                    if typ == 'LI': lb[var] = val
                    else: ub[var] = val
                elif typ == 'LO': lb[var] = val
                elif typ == 'UP': ub[var] = val
                elif typ == 'FX': lb[var] = val; ub[var] = val
                elif typ == 'FR': lb[var] = -float('inf'); ub[var] = float('inf')
                elif typ == 'MI': lb[var] = -float('inf')
                elif typ == 'PL': ub[var] = float('inf')
    allvars = set(cols) | set(obj) | set(lb) | set(ub)
    return rows, row_order, cols, obj, rhs, lb, ub, integer, allvars


def read_solution(path):
    x = {}
    with open(path, 'rt', errors='replace') as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith('#'):
                continue
            p = s.split()
            if len(p) >= 2:
                try: x[p[0]] = float(p[1])
                except ValueError: pass
    return x


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--start', default='/resources/best.sol')
    ap.add_argument('--seconds', type=float, default=3300.0)
    ap.add_argument('--seed', type=int, default=3355120)
    args = ap.parse_args()
    began = time.time()
    rng = random.Random(args.seed)
    rows, row_order, cols, obj, rhs, lb, ub, integer, allvars = read_mps(args.model)
    if not os.path.exists(args.start):
        raise FileNotFoundError('The verified incumbent resource is unavailable: ' + args.start)
    x0 = read_solution(args.start)
    x = {v: x0.get(v, 0.0) for v in allvars | set(x0)}
    incident = defaultdict(list)
    rowvars = defaultdict(list)
    act = defaultdict(float)
    for v, rc in cols.items():
        xv = x.get(v, 0.0)
        for r, a in rc.items():
            act[r] += a*xv
            incident[v].append((r,a))
            rowvars[r].append((v,a))

    def rviol(r, value):
        b = rhs.get(r, 0.0)
        typ = rows[r]
        if typ == 'L': return max(0.0, value-b)
        if typ == 'G': return max(0.0, b-value)
        return abs(value-b)

    def feasible(activities, tol=2e-7):
        return all(rviol(r, activities.get(r,0.0)) <= tol for r in row_order)

    def objective(vals):
        return sum(obj.get(v,0.0)*vals.get(v,0.0) for v in obj)

    binary = [v for v in integer if lb[v] >= -1e-12 and ub[v] <= 1.0+1e-12]
    binary = [v for v in binary if abs(x.get(v,0.0)-round(x.get(v,0.0))) <= 1e-6]
    for v in binary:
        x[v] = float(round(x[v]))
    initial_feasible = feasible(act)
    current_obj = objective(x)
    best_x = dict(x)
    best_obj = current_obj
    accepted = 0
    trials = 0
    repair_success = 0
    one_flip_improvements = 0

    def apply(vals, activities, v):
        old = vals.get(v,0.0)
        new = 1.0-old
        d = new-old
        vals[v] = new
        for r,a in incident[v]: activities[r] += a*d
        return obj.get(v,0.0)*d

    # Exhaust a deterministic feasible one-flip neighborhood first.
    order = sorted(binary, key=lambda v: (obj.get(v,0.0)*(1.0-2.0*x[v]), len(incident[v]), v))
    changed = True
    while changed and time.time()-began < args.seconds:
        changed = False
        for v in order:
            dc = obj.get(v,0.0)*(1.0-2.0*x[v])
            if dc >= -1e-10: continue
            impacted = incident[v]
            d = 1.0-2.0*x[v]
            if all(rviol(r, act[r]+a*d) <= 2e-7 for r,a in impacted):
                apply(x,act,v); current_obj += dc
                accepted += 1; one_flip_improvements += 1; changed = True
                if current_obj < best_obj-1e-8:
                    best_obj=current_obj; best_x=dict(x)

    promising = sorted(binary, key=lambda v: obj.get(v,0.0)*(1.0-2.0*x[v]))
    limit = min(args.seconds, max(1.0,args.seconds-2.0))
    while time.time()-began < limit and binary:
        trials += 1
        vals = dict(x)
        activities = defaultdict(float, act)
        if rng.random() < 0.78 and promising:
            pool = promising[:max(20,min(len(promising),400))]
            seed = rng.choice(pool)
        else:
            seed = rng.choice(binary)
        delta_obj = apply(vals,activities,seed)
        touched = {seed}
        repaired = False
        for step in range(18):
            bad = [(rviol(r,activities[r]),r) for r in row_order if rviol(r,activities[r]) > 2e-7]
            if not bad:
                repaired = True
                break
            _, r = max(bad)
            candidates = rowvars[r]
            if len(candidates) > 700:
                candidates = rng.sample(candidates,700)
            best_choice = None
            best_score = -1e100
            for v,a in candidates:
                if v not in binary or v in touched: continue
                d = 1.0-2.0*vals[v]
                if vals[v]+d < lb[v]-1e-9 or vals[v]+d > ub[v]+1e-9: continue
                before = 0.0; after = 0.0
                for q,c in incident[v]:
                    before += rviol(q,activities[q])
                    after += rviol(q,activities[q]+c*d)
                reduction = before-after
                if reduction <= 1e-10: continue
                cost = obj.get(v,0.0)*d
                score = reduction/(1.0+max(0.0,cost)/(1.0+abs(best_obj))) + 1e-9*rng.random()
                if score > best_score:
                    best_score=score; best_choice=v
            if best_choice is None: break
            delta_obj += apply(vals,activities,best_choice)
            touched.add(best_choice)
        if repaired and feasible(activities):
            repair_success += 1
            # Greedily polish the repaired candidate with safe improving flips.
            for v in promising[:min(len(promising),1200)]:
                if v in touched: continue
                dc=obj.get(v,0.0)*(1.0-2.0*vals[v])
                if dc >= -1e-10: continue
                d=1.0-2.0*vals[v]
                if all(rviol(r,activities[r]+a*d)<=2e-7 for r,a in incident[v]):
                    delta_obj += apply(vals,activities,v)
            cand_obj = objective(vals)
            if cand_obj < best_obj-1e-8:
                best_obj=cand_obj; best_x=dict(vals); accepted += 1
                x=dict(vals); act=defaultdict(float,activities); current_obj=cand_obj
                promising=sorted(binary,key=lambda v: obj.get(v,0.0)*(1.0-2.0*x[v]))

    # Recompute activities from scratch before emitting anything.
    check_act=defaultdict(float)
    for v,rc in cols.items():
        xv=best_x.get(v,0.0)
        for r,a in rc.items(): check_act[r]+=a*xv
    maxviol=max([rviol(r,check_act[r]) for r in row_order] or [0.0])
    integral=max([abs(best_x.get(v,0.0)-round(best_x.get(v,0.0))) for v in integer] or [0.0])
    valid=maxviol<=2e-7 and integral<=1e-7
    improved=valid and best_obj < objective({v:x0.get(v,0.0) for v in allvars|set(x0)})-1e-8
    outvals=best_x if valid else {v:x0.get(v,0.0) for v in allvars|set(x0)}
    with open('best.sol','w') as f:
        f.write('# Activation-first sparse row-repair candidate\n')
        for v in sorted(outvals):
            if abs(outvals[v])>1e-14:
                f.write('%s %.17g\n'%(v,outvals[v]))
    trace={
      'method':'activation_first_sparse_row_repair','seed':args.seed,
      'rows':len(rows),'variables':len(allvars),'integer_variables':len(integer),'binary_variables':len(binary),
      'initial_feasible_internal':initial_feasible,'initial_objective_internal':objective({v:x0.get(v,0.0) for v in allvars|set(x0)}),
      'best_objective_internal':best_obj,'improved_internal':improved,'max_row_violation_internal':maxviol,
      'max_integrality_violation_internal':integral,'trials':trials,'successful_repairs':repair_success,
      'accepted_improvements':accepted,'one_flip_improvements':one_flip_improvements,'runtime_seconds':time.time()-began
    }
    with open('activation_repair_trace.json','w') as f: json.dump(trace,f,indent=2,sort_keys=True)
    result={'status':'feasible_candidate' if valid else 'no_candidate','objective':best_obj if valid else None,
            'solution_file':'best.sol' if valid else None,'improved':improved,'proof':False,'trace_file':'activation_repair_trace.json'}
    with open('method_result.json','w') as f: json.dump(result,f,indent=2,sort_keys=True)

if __name__=='__main__': main()
