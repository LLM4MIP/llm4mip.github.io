import argparse, gzip, json, math, os, random, time
from collections import defaultdict


def lines(path):
    op = gzip.open if path.endswith('.gz') else open
    with op(path, 'rt', encoding='utf-8', errors='replace') as f:
        for line in f:
            yield line.rstrip('\n\r')


def parse_mps(path):
    section = None
    row_type = {}
    objrow = None
    obj = defaultdict(float)
    cols = defaultdict(dict)
    rhs = defaultdict(float)
    ranges = {}
    integer_mode = False
    integer = set()
    lb = defaultdict(float)
    ub = defaultdict(lambda: math.inf)
    variables = set()
    for raw in lines(path):
        s = raw.strip()
        if not s or s.startswith('*'):
            continue
        t = s.split()
        head = t[0].upper()
        if head in ('NAME','OBJSENSE','OBJNAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA'):
            section = head
            if head == 'ENDATA': break
            continue
        if section == 'OBJSENSE':
            continue
        if section == 'ROWS':
            if len(t) >= 2:
                typ, name = t[0].upper(), t[1]
                row_type[name] = typ
                if typ == 'N' and objrow is None: objrow = name
        elif section == 'COLUMNS':
            if any('MARKER' in x.upper() for x in t):
                u = ' '.join(t).upper()
                if 'INTORG' in u: integer_mode = True
                elif 'INTEND' in u: integer_mode = False
                continue
            if len(t) < 3: continue
            v = t[0]; variables.add(v)
            if integer_mode: integer.add(v)
            for k in range(1, len(t)-1, 2):
                r = t[k]
                try: a = float(t[k+1].replace('D','E').replace('d','e'))
                except Exception: continue
                if r == objrow: obj[v] += a
                elif row_type.get(r) != 'N': cols[v][r] = cols[v].get(r,0.0) + a
        elif section == 'RHS':
            for k in range(1, len(t)-1, 2):
                try: rhs[t[k]] = float(t[k+1].replace('D','E').replace('d','e'))
                except Exception: pass
        elif section == 'RANGES':
            for k in range(1, len(t)-1, 2):
                try: ranges[t[k]] = float(t[k+1].replace('D','E').replace('d','e'))
                except Exception: pass
        elif section == 'BOUNDS' and len(t) >= 3:
            typ, v = t[0].upper(), t[2]; variables.add(v)
            val = 0.0
            if len(t) >= 4:
                try: val = float(t[3].replace('D','E').replace('d','e'))
                except Exception: val = 0.0
            if typ == 'LO': lb[v] = val
            elif typ == 'UP': ub[v] = val
            elif typ == 'FX': lb[v] = ub[v] = val
            elif typ == 'FR': lb[v], ub[v] = -math.inf, math.inf
            elif typ == 'MI': lb[v] = -math.inf
            elif typ == 'PL': ub[v] = math.inf
            elif typ == 'BV': lb[v], ub[v] = 0.0, 1.0; integer.add(v)
            elif typ == 'LI': lb[v] = val; integer.add(v)
            elif typ == 'UI': ub[v] = val; integer.add(v)
            elif typ == 'SC': ub[v] = val
    lo, hi = {}, {}
    for r, typ in row_type.items():
        if typ == 'N': continue
        b = rhs.get(r, 0.0)
        if typ == 'E': lo[r] = hi[r] = b
        elif typ == 'L': lo[r], hi[r] = -math.inf, b
        elif typ == 'G': lo[r], hi[r] = b, math.inf
        if r in ranges:
            q = ranges[r]
            if typ == 'E':
                if q >= 0: lo[r], hi[r] = b, b + q
                else: lo[r], hi[r] = b + q, b
            elif typ == 'L': lo[r] = b - abs(q)
            elif typ == 'G': hi[r] = b + abs(q)
    return sorted(variables), obj, cols, lb, ub, integer, lo, hi


def read_sol(path):
    x = {}
    with open(path, 'rt', encoding='utf-8', errors='replace') as f:
        for raw in f:
            s = raw.strip()
            if not s or s.startswith('#'): continue
            t = s.split()
            if len(t) >= 2:
                try: x[t[0]] = float(t[1])
                except Exception: pass
    return x


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--incumbent', required=True)
    ap.add_argument('--pair-limit', type=int, default=6000000)
    ap.add_argument('--passes', type=int, default=12)
    ap.add_argument('--seed', type=int, default=3355120)
    a = ap.parse_args()
    started = time.time(); random.seed(a.seed)
    names,obj,cols,lb,ub,ints,rlo,rhi = parse_mps(a.model)
    supplied = read_sol(a.incumbent)
    x = {v:supplied.get(v,0.0) for v in names}
    activity = defaultdict(float)
    for v in names:
        xv=x[v]
        if xv:
            for r,c in cols[v].items(): activity[r] += c*xv
    def row_ok(r,z):
        scale=max(1.0,abs(z),abs(rlo.get(r,0.0)) if math.isfinite(rlo.get(r,-math.inf)) else 1.0,abs(rhi.get(r,0.0)) if math.isfinite(rhi.get(r,math.inf)) else 1.0)
        tol=2e-10*scale
        return z >= rlo.get(r,-math.inf)-tol and z <= rhi.get(r,math.inf)+tol
    initial_bad=[r for r,z in activity.items() if not row_ok(r,z)]
    binary=[]
    for v in ints:
        if lb[v] >= -1e-12 and ub[v] <= 1+1e-12 and (abs(x[v]) <= 1e-7 or abs(x[v]-1) <= 1e-7):
            x[v]=float(round(x[v])); binary.append(v)
    accepted=[]; pair_tests=0
    for ps in range(a.passes):
        moves=[]
        for v in binary:
            d=1.0-2.0*x[v]
            od=obj.get(v,0.0)*d
            if od >= -1e-10: continue
            bad=[]; feasible=True
            for r,c in cols[v].items():
                if not row_ok(r,activity[r]+c*d): feasible=False; bad.append(r)
            moves.append((od,v,d,feasible,bad))
        moves.sort()
        chosen=None
        for od,v,d,feas,bad in moves:
            if feas: chosen=(od,v,d,None,0.0); break
        if chosen is None and moves:
            byrow=defaultdict(list)
            for i,m in enumerate(moves):
                for r in m[4]: byrow[r].append(i)
            tested=set(); best=None
            for i,m in enumerate(moves):
                cand=set()
                for r in m[4]: cand.update(byrow.get(r,()))
                # Variables sharing any affected row can compensate even if not themselves blocked there.
                if len(cand)<80:
                    affected=set(cols[m[1]])
                    for j,n in enumerate(moves[:2500]):
                        if affected.intersection(cols[n[1]]): cand.add(j)
                for j in cand:
                    if j<=i: continue
                    key=(i,j)
                    if key in tested: continue
                    tested.add(key); pair_tests+=1
                    if pair_tests>a.pair_limit: break
                    n=moves[j]; total=m[0]+n[0]
                    if total>=-1e-10: continue
                    ok=True
                    for r in set(cols[m[1]])|set(cols[n[1]]):
                        z=activity[r]+cols[m[1]].get(r,0.0)*m[2]+cols[n[1]].get(r,0.0)*n[2]
                        if not row_ok(r,z): ok=False; break
                    if ok and (best is None or total<best[0]): best=(total,m[1],m[2],n[1],n[2])
                if pair_tests>a.pair_limit: break
            chosen=best
        if chosen is None: break
        od,v,d,w,e=chosen
        x[v]+=d
        for r,c in cols[v].items(): activity[r]+=c*d
        if w is not None:
            x[w]+=e
            for r,c in cols[w].items(): activity[r]+=c*e
        accepted.append({'pass':ps,'objective_delta':od,'first':v,'second':w})
    final_bad=[]
    allrows=set(rlo)|set(rhi)
    for r in allrows:
        if not row_ok(r,activity[r]): final_bad.append(r)
    objective=sum(obj.get(v,0.0)*x[v] for v in names)
    with open('best.sol','w',encoding='utf-8') as f:
        f.write('# Objective value = %.17g\n'%objective)
        for v in names:
            f.write('%s %.17g\n'%(v,x[v]))
    report={'status':'candidate_generated','objective':objective,'accepted_moves':accepted,'accepted_count':len(accepted),'binary_candidates':len(binary),'pair_tests':pair_tests,'initial_bad_rows':initial_bad[:50],'initial_bad_count':len(initial_bad),'final_bad_rows':final_bad[:50],'final_bad_count':len(final_bad),'runtime_seconds':time.time()-started}
    with open('exchange_report.json','w',encoding='utf-8') as f: json.dump(report,f,indent=2)
    result={'status':'feasible_candidate' if not final_bad else 'unchecked_candidate','objective':objective,'solution_file':'best.sol','report_file':'exchange_report.json','accepted_count':len(accepted)}
    with open('method_result.json','w',encoding='utf-8') as f: json.dump(result,f,indent=2)

if __name__=='__main__': main()
