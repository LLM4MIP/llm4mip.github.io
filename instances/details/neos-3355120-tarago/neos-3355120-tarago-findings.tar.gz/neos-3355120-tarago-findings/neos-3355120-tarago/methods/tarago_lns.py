#!/usr/bin/env python3
"""Structure-specific activation/flow repair prototype for Tarago.

This program uses only the Python standard library. It parses the supplied MPS,
identifies binary activation variables coupled to continuous flow variables, and
runs activation-first sparse constraint repair with randomized restarts. A .sol
file is emitted only when every row, bound, and integrality condition passes an
independent check performed by this program.
"""
import argparse
import gzip
import json
import math
import os
import random
import time
from collections import defaultdict, deque

INF = float("inf")


def open_model(path):
    if path.lower().endswith(".gz"):
        return gzip.open(path, "rt", errors="replace")
    return open(path, "rt", errors="replace")


def parse_mps(path):
    rowsense = {}
    row_order = []
    objrow = None
    cols = defaultdict(dict)
    obj = defaultdict(float)
    rhs = defaultdict(float)
    ranges = {}
    lb = defaultdict(lambda: 0.0)
    ub = defaultdict(lambda: INF)
    integer = set()
    var_order = []
    seen_var = set()
    section = None
    int_mode = False
    obj_sense = 1.0

    with open_model(path) as f:
        for raw in f:
            line = raw.rstrip("\n\r")
            if not line or line.lstrip().startswith("*"):
                continue
            tok = line.split()
            if not tok:
                continue
            key = tok[0].upper()
            if key in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA", "OBJSENSE", "OBJNAME"}:
                section = key
                if key == "ENDATA":
                    break
                continue
            if section == "OBJSENSE":
                if key.startswith("MAX"):
                    obj_sense = -1.0
                elif key.startswith("MIN"):
                    obj_sense = 1.0
                continue
            if section == "ROWS":
                if len(tok) >= 2:
                    s, r = tok[0].upper(), tok[1]
                    if s == "N" and objrow is None:
                        objrow = r
                    elif s in {"L", "G", "E"}:
                        rowsense[r] = s
                        row_order.append(r)
                continue
            if section == "COLUMNS":
                if len(tok) >= 3 and ("MARKER" in line.upper()):
                    u = line.upper()
                    if "INTORG" in u:
                        int_mode = True
                    elif "INTEND" in u:
                        int_mode = False
                    continue
                v = tok[0]
                if v not in seen_var:
                    seen_var.add(v)
                    var_order.append(v)
                if int_mode:
                    integer.add(v)
                pairs = tok[1:]
                for i in range(0, len(pairs) - 1, 2):
                    r = pairs[i]
                    try:
                        a = float(pairs[i + 1].replace("D", "E"))
                    except ValueError:
                        continue
                    if r == objrow:
                        obj[v] += obj_sense * a
                    elif r in rowsense:
                        cols[v][r] = cols[v].get(r, 0.0) + a
                continue
            if section == "RHS":
                pairs = tok[1:]
                for i in range(0, len(pairs) - 1, 2):
                    r = pairs[i]
                    if r in rowsense:
                        rhs[r] = float(pairs[i + 1].replace("D", "E"))
                continue
            if section == "RANGES":
                pairs = tok[1:]
                for i in range(0, len(pairs) - 1, 2):
                    r = pairs[i]
                    if r in rowsense:
                        ranges[r] = float(pairs[i + 1].replace("D", "E"))
                continue
            if section == "BOUNDS" and len(tok) >= 3:
                bt = tok[0].upper()
                v = tok[2]
                if v not in seen_var:
                    seen_var.add(v)
                    var_order.append(v)
                val = 0.0
                if len(tok) >= 4:
                    val = float(tok[3].replace("D", "E"))
                if bt == "LO": lb[v] = val
                elif bt == "UP": ub[v] = val
                elif bt == "FX": lb[v] = val; ub[v] = val
                elif bt == "FR": lb[v] = -INF; ub[v] = INF
                elif bt == "MI": lb[v] = -INF
                elif bt == "PL": ub[v] = INF
                elif bt == "BV": lb[v] = 0.0; ub[v] = 1.0; integer.add(v)
                elif bt == "LI": lb[v] = val; integer.add(v)
                elif bt == "UI": ub[v] = val; integer.add(v)

    rowlb, rowub = {}, {}
    for r in row_order:
        b = rhs[r]
        s = rowsense[r]
        if s == "L": rowlb[r], rowub[r] = -INF, b
        elif s == "G": rowlb[r], rowub[r] = b, INF
        else: rowlb[r], rowub[r] = b, b
        if r in ranges:
            q = ranges[r]
            if s == "L": rowlb[r] = b - abs(q)
            elif s == "G": rowub[r] = b + abs(q)
            elif q >= 0: rowub[r] = b + q
            else: rowlb[r] = b + q
    rows = defaultdict(list)
    for v in var_order:
        for r, a in cols[v].items():
            if a:
                rows[r].append((v, a))
    return var_order, row_order, cols, rows, obj, lb, ub, integer, rowlb, rowub


def finite_clip(z, lo, hi):
    if lo != -INF and z < lo: z = lo
    if hi != INF and z > hi: z = hi
    return z


def violation(a, lo, hi):
    scale = max(1.0, abs(lo) if lo != -INF else 0.0, abs(hi) if hi != INF else 0.0)
    if lo != -INF and a < lo:
        return (lo - a) / scale
    if hi != INF and a > hi:
        return (a - hi) / scale
    return 0.0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--search-seconds", type=int, default=3300)
    ap.add_argument("--seed", type=int, default=3355120)
    args = ap.parse_args()
    random.seed(args.seed)
    start = time.time()
    V, R, cols, rows, obj, lb, ub, integer, rlb, rub = parse_mps(args.model)
    binaries = {v for v in integer if lb[v] >= -1e-12 and ub[v] <= 1.0 + 1e-12}
    continuous = set(V) - integer

    # Activation candidates are binary columns sharing at least one row with a
    # continuous variable. This captures fixed-charge linking without relying
    # on instance-specific names.
    row_has_cont = {r: any(v in continuous for v, _ in rows[r]) for r in R}
    activators = {v for v in binaries if any(row_has_cont.get(r, False) for r in cols[v])}
    incident = {v: list(cols[v].keys()) for v in V}
    degree_order = sorted(V, key=lambda v: len(incident[v]), reverse=True)

    best_x = None
    best_merit = INF
    best_maxv = INF
    best_obj = INF
    total_moves = 0
    restarts = 0

    def evaluate(x, activity):
        sv = 0.0
        mv = 0.0
        for r in R:
            q = violation(activity[r], rlb[r], rub[r])
            sv += q
            mv = max(mv, q)
        return sv, mv

    deadline = start + max(1, args.search_seconds)
    while time.time() < deadline:
        restarts += 1
        x = {}
        for v in V:
            lo, hi = lb[v], ub[v]
            z = 0.0
            if lo != -INF and z < lo: z = lo
            if hi != INF and z > hi: z = hi
            if v in binaries:
                if v in activators:
                    z = 1.0 if restarts <= 2 or random.random() < 0.80 else 0.0
                else:
                    z = 1.0 if obj[v] < 0 and random.random() < 0.8 else 0.0
                z = finite_clip(z, lo, hi)
            elif v in integer:
                z = round(finite_clip(z, lo, hi))
            x[v] = z
        activity = {r: 0.0 for r in R}
        for v in V:
            if x[v]:
                for r, a in cols[v].items(): activity[r] += a * x[v]

        stagnant = 0
        max_moves = max(20000, min(250000, 80 * len(V)))
        for it in range(max_moves):
            if time.time() >= deadline: break
            sv, mv = evaluate(x, activity)
            objective = sum(obj[v] * x[v] for v in V)
            merit = sv
            if merit < best_merit - 1e-12 or (mv <= 1e-8 and objective < best_obj):
                best_merit, best_maxv, best_obj = merit, mv, objective
                best_x = dict(x)
            if mv <= 1e-8:
                # Once feasible, attempt objective-improving binary closures;
                # subsequent repair either validates or reverses their effect.
                cand = [v for v in activators if x[v] > 0.5 and obj[v] > 0]
                if not cand:
                    break
                v = random.choice(cand)
                old = x[v]; x[v] = 0.0
                for r, a in cols[v].items(): activity[r] -= a * old
                continue

            violated = [r for r in R if violation(activity[r], rlb[r], rub[r]) > 1e-10]
            if not violated: break
            violated.sort(key=lambda r: violation(activity[r], rlb[r], rub[r]), reverse=True)
            r = random.choice(violated[:min(8, len(violated))])
            ar = activity[r]
            target = rlb[r] if rlb[r] != -INF and ar < rlb[r] else rub[r]
            candidates = rows[r]
            if len(candidates) > 120:
                candidates = random.sample(candidates, 120)
            best = None
            old_local = sum(violation(activity[q], rlb[q], rub[q]) for v, _ in candidates for q in () )
            for v, a in candidates:
                if abs(a) < 1e-15: continue
                desired = x[v] + (target - ar) / a
                desired = finite_clip(desired, lb[v], ub[v])
                trial_values = [desired]
                if v in integer:
                    trial_values = [math.floor(desired + 1e-10), math.ceil(desired - 1e-10)]
                    if v in binaries: trial_values += [0.0, 1.0]
                for nv in trial_values:
                    nv = finite_clip(float(nv), lb[v], ub[v])
                    d = nv - x[v]
                    if abs(d) < 1e-12: continue
                    before = after = 0.0
                    for q in incident[v]:
                        before += violation(activity[q], rlb[q], rub[q])
                        after += violation(activity[q] + cols[v][q] * d, rlb[q], rub[q])
                    gain = before - after
                    # Tiny objective tie-break; feasibility remains dominant.
                    score = gain - 1e-12 * max(0.0, obj[v] * d)
                    if best is None or score > best[0]: best = (score, v, nv, d)
            if best is None or best[0] <= 1e-14:
                stagnant += 1
                # Diversify an activation variable incident to a difficult row.
                av = [v for v, _ in rows[r] if v in activators]
                if av:
                    v = random.choice(av); nv = 1.0 - round(x[v]); d = nv - x[v]
                    x[v] = nv
                    for q, a in cols[v].items(): activity[q] += a * d
                else:
                    random.shuffle(degree_order)
                if stagnant > 2000: break
            else:
                stagnant = 0
                _, v, nv, d = best
                x[v] = nv
                for q, a in cols[v].items(): activity[q] += a * d
                total_moves += 1

    feasible = False
    check = {r: 0.0 for r in R}
    bound_bad = int_bad = 0
    if best_x is not None:
        for v in V:
            z = best_x[v]
            if (lb[v] != -INF and z < lb[v] - 1e-7) or (ub[v] != INF and z > ub[v] + 1e-7): bound_bad += 1
            if v in integer and abs(z - round(z)) > 1e-7: int_bad += 1
            for r, a in cols[v].items(): check[r] += a * z
        raw_bad = 0
        max_raw = 0.0
        for r in R:
            a = check[r]
            q = 0.0
            if rlb[r] != -INF and a < rlb[r] - 1e-6: q = max(q, rlb[r] - a)
            if rub[r] != INF and a > rub[r] + 1e-6: q = max(q, a - rub[r])
            if q > 0: raw_bad += 1; max_raw = max(max_raw, q)
        feasible = raw_bad == 0 and bound_bad == 0 and int_bad == 0
    else:
        raw_bad = len(R); max_raw = INF

    result = {
        "method": "activation_first_sparse_flow_repair",
        "variables": len(V), "rows": len(R), "integer_variables": len(integer),
        "binary_variables": len(binaries), "activation_candidates": len(activators),
        "restarts": restarts, "accepted_moves": total_moves,
        "feasible_internal": feasible, "best_normalized_violation_sum": best_merit,
        "best_normalized_max_violation": best_maxv, "violated_rows_raw_check": raw_bad,
        "max_raw_row_violation": max_raw, "bound_violations": bound_bad,
        "integrality_violations": int_bad, "internal_objective_minimized_sense": best_obj,
        "elapsed_seconds": time.time() - start,
        "note": "Any emitted solution still requires controller verification against the original model."
    }
    with open("method_result.json", "w") as f: json.dump(result, f, indent=2, sort_keys=True)
    with open("structure_analysis.json", "w") as f:
        json.dump({k: result[k] for k in ["variables", "rows", "integer_variables", "binary_variables", "activation_candidates"]}, f, indent=2)
    if feasible:
        with open("best.sol", "w") as f:
            f.write("# Candidate generated by activation-first sparse flow repair\n")
            for v in V:
                z = best_x[v]
                if abs(z) > 1e-15:
                    f.write(f"{v} {z:.17g}\n")


if __name__ == "__main__":
    main()
