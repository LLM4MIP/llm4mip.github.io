import argparse, gzip, json, math, os, time
from collections import defaultdict


def open_model(path):
    return gzip.open(path, 'rt', errors='replace') if path.endswith('.gz') else open(path, 'r', errors='replace')


def parse_mps(path):
    section = None
    row_type = {}
    objective_row = None
    columns = defaultdict(lambda: defaultdict(float))
    objective = defaultdict(float)
    rhs = defaultdict(float)
    lb = defaultdict(lambda: 0.0)
    ub = defaultdict(lambda: math.inf)
    integer = set()
    variables = []
    seen_variables = set()
    integer_mode = False
    objective_sense = 1.0
    ranges_seen = False
    with open_model(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('*'):
                continue
            tok = line.split()
            key = tok[0].upper()
            if key in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE','OBJNAME'):
                section = key
                if key == 'RANGES':
                    ranges_seen = True
                if key == 'ENDATA':
                    break
                continue
            if section == 'OBJSENSE':
                if key.startswith('MAX'):
                    objective_sense = -1.0
                elif key.startswith('MIN'):
                    objective_sense = 1.0
            elif section == 'ROWS' and len(tok) >= 2:
                typ, name = tok[0].upper(), tok[1]
                row_type[name] = typ
                if typ == 'N' and objective_row is None:
                    objective_row = name
            elif section == 'COLUMNS':
                if any('MARKER' in x.upper() for x in tok):
                    if any('INTORG' in x.upper() for x in tok):
                        integer_mode = True
                    elif any('INTEND' in x.upper() for x in tok):
                        integer_mode = False
                    continue
                var = tok[0]
                if var not in seen_variables:
                    seen_variables.add(var)
                    variables.append(var)
                if integer_mode:
                    integer.add(var)
                for i in range(1, len(tok)-1, 2):
                    row = tok[i]
                    try:
                        val = float(tok[i+1].replace('D','E'))
                    except ValueError:
                        continue
                    if row == objective_row:
                        objective[var] += objective_sense * val
                    else:
                        columns[var][row] += val
            elif section == 'RHS':
                for i in range(1, len(tok)-1, 2):
                    try:
                        rhs[tok[i]] = float(tok[i+1].replace('D','E'))
                    except ValueError:
                        pass
            elif section == 'BOUNDS' and len(tok) >= 3:
                typ, var = tok[0].upper(), tok[2]
                val = 0.0
                if len(tok) >= 4:
                    try:
                        val = float(tok[3].replace('D','E'))
                    except ValueError:
                        val = 0.0
                if var not in seen_variables:
                    seen_variables.add(var)
                    variables.append(var)
                if typ == 'LO': lb[var] = val
                elif typ == 'UP': ub[var] = val
                elif typ == 'FX': lb[var] = val; ub[var] = val
                elif typ == 'FR': lb[var] = -math.inf; ub[var] = math.inf
                elif typ == 'MI': lb[var] = -math.inf
                elif typ == 'PL': ub[var] = math.inf
                elif typ == 'BV': lb[var] = 0.0; ub[var] = 1.0; integer.add(var)
                elif typ == 'LI': lb[var] = val; integer.add(var)
                elif typ == 'UI': ub[var] = val; integer.add(var)
    return variables, row_type, columns, objective, rhs, lb, ub, integer, ranges_seen


def read_solution(path):
    values = {}
    if not path or not os.path.exists(path):
        return values
    with open(path, 'r', errors='replace') as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('#') or line.startswith('<') or line.startswith('>'):
                continue
            tok = line.replace('=', ' ').split()
            if len(tok) >= 2:
                try:
                    values[tok[0]] = float(tok[1])
                except ValueError:
                    pass
    return values


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--incumbent', default='/resources/best.sol')
    ap.add_argument('--pair-limit', type=int, default=1200)
    args = ap.parse_args()
    started = time.time()
    variables, row_type, cols, obj, rhs, lb, ub, integer, ranges_seen = parse_mps(args.model)
    x = read_solution(args.incumbent)
    for v in variables:
        x.setdefault(v, 0.0)
    initial_x = dict(x)
    binary = [v for v in variables if v in integer and lb[v] >= -1e-12 and ub[v] <= 1.0 + 1e-12]
    activity = defaultdict(float)
    for v in variables:
        xv = x[v]
        if xv:
            for r, a in cols[v].items():
                activity[r] += a * xv

    def row_ok(r, value):
        typ = row_type.get(r, 'N')
        b = rhs[r]
        if typ == 'E': return abs(value-b) <= 2e-9
        if typ == 'L': return value <= b + 2e-9
        if typ == 'G': return value >= b - 2e-9
        return True

    def delta_for(changes):
        d = defaultdict(float)
        for v, nv in changes.items():
            dv = nv - x[v]
            if dv:
                for r, a in cols[v].items():
                    d[r] += a * dv
        return d

    def feasible_delta(d):
        return all(row_ok(r, activity[r] + dr) for r, dr in d.items())

    def objective_delta(changes):
        return sum(obj[v] * (nv-x[v]) for v, nv in changes.items())

    # Detect equality rows representing one-hot or fixed-cardinality choices. A move
    # replaces one selected binary by one unselected binary with the same coefficient.
    row_members = defaultdict(list)
    for v in binary:
        for r, a in cols[v].items():
            if row_type.get(r) == 'E' and abs(a) > 1e-12:
                row_members[r].append((v, a))

    accepted_single = 0
    accepted_pair = 0
    examined_single = 0
    examined_pair = 0
    passes = 0
    if not ranges_seen:
        while passes < 25:
            passes += 1
            moves = []
            signatures = set()
            for r, members in row_members.items():
                if len(members) < 2 or len(members) > 20000:
                    continue
                bycoef = defaultdict(list)
                for v, a in members:
                    bycoef[round(a, 12)].append(v)
                for group in bycoef.values():
                    selected = [v for v in group if x[v] > 0.5]
                    unselected = [v for v in group if x[v] < 0.5]
                    if not selected or not unselected:
                        continue
                    # Limit obviously non-improving alternatives before constructing sparse deltas.
                    unselected.sort(key=lambda v: obj[v])
                    for old in selected:
                        for new in unselected[:400]:
                            changes = {old: 0.0, new: 1.0}
                            od = objective_delta(changes)
                            if od >= -1e-10:
                                continue
                            sig = (old, new)
                            if sig in signatures:
                                continue
                            signatures.add(sig)
                            d = delta_for(changes)
                            moves.append((od, old, new, d))
            moves.sort(key=lambda z: z[0])
            examined_single += len(moves)
            chosen = None
            for move in moves:
                if feasible_delta(move[3]):
                    chosen = move
                    break
            if chosen is not None:
                _, old, new, d = chosen
                x[old] = 0.0; x[new] = 1.0
                for r, dr in d.items(): activity[r] += dr
                accepted_single += 1
                continue

            # Pair individually blocked improving exchanges; combined deltas can satisfy
            # linking, balance, or conservation rows that prevent either exchange alone.
            pool = moves[:args.pair_limit]
            best_pair = None
            for i in range(len(pool)):
                od1, o1, n1, d1 = pool[i]
                for j in range(i+1, len(pool)):
                    od2, o2, n2, d2 = pool[j]
                    examined_pair += 1
                    if len({o1,n1,o2,n2}) < 4 or od1 + od2 >= -1e-10:
                        continue
                    keys = set(d1) | set(d2)
                    if all(row_ok(r, activity[r] + d1.get(r,0.0) + d2.get(r,0.0)) for r in keys):
                        best_pair = (od1+od2, o1,n1,o2,n2,d1,d2)
                        break
                if best_pair is not None:
                    break
            if best_pair is None:
                break
            _, o1,n1,o2,n2,d1,d2 = best_pair
            x[o1]=0.0; x[n1]=1.0; x[o2]=0.0; x[n2]=1.0
            for r in set(d1)|set(d2): activity[r] += d1.get(r,0.0)+d2.get(r,0.0)
            accepted_pair += 1

    initial_obj = sum(obj[v]*initial_x[v] for v in variables)
    final_obj = sum(obj[v]*x[v] for v in variables)
    changed = sum(1 for v in variables if abs(x[v]-initial_x[v]) > 1e-12)
    all_rows_ok = all(row_ok(r, activity[r]) for r,t in row_type.items() if t != 'N')
    # Never publish a modified candidate unless the complete internally parsed row system passes.
    if ranges_seen or not all_rows_ok or final_obj >= initial_obj - 1e-9:
        x = initial_x
        final_obj = initial_obj
        changed = 0
    with open('best.sol','w') as f:
        f.write('# Structural exchange candidate\n')
        f.write('# Objective value = %.17g\n' % final_obj)
        for v in variables:
            f.write('%s %.17g\n' % (v, x[v]))
    result = {
        'status':'candidate_generated',
        'method':'one_hot_single_and_paired_exchange',
        'initial_objective':initial_obj,
        'candidate_objective':final_obj,
        'improvement':initial_obj-final_obj,
        'changed_variables':changed,
        'binary_variables':len(binary),
        'candidate_equality_rows':sum(1 for r,m in row_members.items() if len(m)>=2),
        'passes':passes,
        'accepted_single_moves':accepted_single,
        'accepted_pair_moves':accepted_pair,
        'examined_single_moves':examined_single,
        'examined_pair_combinations':examined_pair,
        'ranges_seen':ranges_seen,
        'internal_rows_feasible':all_rows_ok,
        'runtime_seconds':time.time()-started
    }
    with open('method_result.json','w') as f:
        json.dump(result,f,indent=2,sort_keys=True)
    with open('exchange_report.json','w') as f:
        json.dump(result,f,indent=2,sort_keys=True)

if __name__ == '__main__':
    main()
