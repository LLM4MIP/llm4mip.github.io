# Method selection

## Evidence

The fixed baselines provide a verified feasible objective of `-10092857.35633746687350892` and a Gurobi dual bound of `-11642746.797247356`, leaving a relative gap of about 15.36%. COPT found no incumbent in 300 seconds, while Gurobi found ten incumbents. This suggests that feasible-solution construction and improvement are meaningful, but the short generic branch-and-bound runs are not close to a proof.

## Selected structural experiment

The first custom experiment is an incumbent-centered binary exchange search. It parses the original MPS independently, fixes nonbinary variables at their values in the verified solver incumbent, and tests whether the mutable binary subsystem is a monotone packing model: all active rows must be upper-bound rows and all coefficients of mutable binaries must be nonnegative. On that structure, removing selected items cannot damage feasibility. The algorithm therefore explores blocker-aware one-for-many exchanges and randomized ruin-and-recreate neighborhoods, always checking row activities before additions. This is materially different from another solver parameter run and directly exploits the packing/exchange geometry inferred during structural analysis.

If the monotone-packing test does not hold, the implementation does not pretend that removal is safe. It falls back to feasible improving single-bit moves only and reports the failed structural assumptions in `method_result.json`. The experimental result will therefore either improve the incumbent or provide reproducible evidence that the packing-exchange abstraction should be replaced.

Generic solver tuning is deferred until this custom structural experiment has been evaluated. A later solver run may be useful as a validator, warm-start improver, or proof engine for a custom incumbent, but not merely as another seed or parameter portfolio.
