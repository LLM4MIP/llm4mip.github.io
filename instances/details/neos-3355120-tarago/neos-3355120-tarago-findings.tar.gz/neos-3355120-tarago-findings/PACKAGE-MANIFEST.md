# Package manifest: neos-3355120-tarago

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 57
Excluded source files: 1

## Included files

- `README.md`
- `experiments.json`
- `experiments.md`
- `final_report.md`
- `method_selection.md`
- `methods/activation_repair.py`
- `methods/analyze_mps.py`
- `methods/equality_exchange.py`
- `methods/exchange_relaunch.py`
- `methods/exchange_search.py`
- `methods/sparse_exchange_search.py`
- `methods/tarago_exchange.py`
- `methods/tarago_lns.py`
- `methods/tarago_search.py`
- `reporting_bundle.json`
- `result.json`
- `runs/copt-20260903-174958-adfd4169/driver.stderr`
- `runs/copt-20260903-174958-adfd4169/driver.stdout`
- `runs/copt-20260903-174958-adfd4169/result.json`
- `runs/copt-20260903-174958-adfd4169/solver.log`
- `runs/copt-20260903-191947-2f3002ee/best.sol`
- `runs/copt-20260903-191947-2f3002ee/driver.stderr`
- `runs/copt-20260903-191947-2f3002ee/driver.stdout`
- `runs/copt-20260903-191947-2f3002ee/result.json`
- `runs/copt-20260903-191947-2f3002ee/solver.log`
- `runs/custom-20260903-181644-ca9e4b8b/algorithm.stderr`
- `runs/custom-20260903-181644-ca9e4b8b/algorithm.stdout`
- `runs/custom-20260903-181644-ca9e4b8b/driver.stderr`
- `runs/custom-20260903-181644-ca9e4b8b/driver.stdout`
- `runs/custom-20260903-181644-ca9e4b8b/result.json`
- `runs/gurobi-20260903-174954-c7cc3629/best.sol`
- `runs/gurobi-20260903-174954-c7cc3629/driver.stderr`
- `runs/gurobi-20260903-174954-c7cc3629/driver.stdout`
- `runs/gurobi-20260903-174954-c7cc3629/result.json`
- `runs/gurobi-20260903-174954-c7cc3629/solver.log`
- `runs/gurobi-20260903-181838-81b619e2/best.sol`
- `runs/gurobi-20260903-181838-81b619e2/driver.stderr`
- `runs/gurobi-20260903-181838-81b619e2/driver.stdout`
- `runs/gurobi-20260903-181838-81b619e2/result.json`
- `runs/gurobi-20260903-181838-81b619e2/solver.log`
- `runs/gurobi-20260903-191942-b870c1ab/best.sol`
- `runs/gurobi-20260903-191942-b870c1ab/driver.stderr`
- `runs/gurobi-20260903-191942-b870c1ab/driver.stdout`
- `runs/gurobi-20260903-191942-b870c1ab/result.json`
- `runs/gurobi-20260903-191942-b870c1ab/solver.log`
- `solutions/public/neos-3355120-tarago-v4.sol.gz`
- `strategy.md`
- `structure-gurobi.log`
- `structure.json`
- `verification/copt-20260903-191947-2f3002ee.exact-check.json`
- `verification/copt-20260903-191947-2f3002ee.exact-check.txt`
- `verification/gurobi-20260903-174954-c7cc3629.exact-check.json`
- `verification/gurobi-20260903-174954-c7cc3629.exact-check.txt`
- `verification/gurobi-20260903-181838-81b619e2.exact-check.json`
- `verification/gurobi-20260903-181838-81b619e2.exact-check.txt`
- `verification/gurobi-20260903-191942-b870c1ab.exact-check.json`
- `verification/gurobi-20260903-191942-b870c1ab.exact-check.txt`

## Excluded files

- `input/neos-3355120-tarago.mps.gz (1674966 bytes; raw benchmark input; sha256 564dfe61a1a3abd4f51d5fa62d4351c3c6e7afaf85afe87b5a37bebf8a54cae2)`
