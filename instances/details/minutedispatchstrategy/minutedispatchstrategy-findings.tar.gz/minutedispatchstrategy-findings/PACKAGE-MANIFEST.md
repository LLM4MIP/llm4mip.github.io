# Package manifest: minutedispatchstrategy

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 31
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/copt-window-audit.txt`
- `artifacts/copt-window-schedule.json`
- `artifacts/fixed-solution-audit.json`
- `artifacts/incumbent-schedule.json`
- `artifacts/primary-schedule-comparison.json`
- `artifacts/strict-solution-audit.txt`
- `artifacts/structure-summary.json`
- `experiments/baseline-copt/copt.log`
- `experiments/baseline-copt/summary.json`
- `experiments/baseline-gurobi/gurobi.log`
- `experiments/baseline-gurobi/incumbent.sol`
- `experiments/baseline-gurobi/summary.json`
- `experiments/fixed-copt-window-gurobi/gurobi.log`
- `experiments/fixed-copt-window-gurobi/incumbent.sol`
- `experiments/fixed-copt-window-gurobi/summary.json`
- `experiments/window-0001-0480-copt/copt.log`
- `experiments/window-0001-0480-copt/incumbent.sol`
- `experiments/window-0001-0480-copt/summary.json`
- `reports/computational-optimality.zh.md`
- `scripts/analyze_schedule.py`
- `scripts/analyze_structure.py`
- `scripts/compare_primary_schedules.py`
- `scripts/run_copt.py`
- `scripts/run_copt_window.py`
- `scripts/run_gurobi.py`
- `scripts/run_gurobi_window.py`
- `solutions/fixed-official-binaries-gurobi.sol`
- `solutions/miplib-solution-1.sol`
- `solutions/miplib-solution-1.sol.gz`
- `solutions/strict-gurobi.sol`

## Excluded files

- `input/minutedispatchstrategy.mps.gz (1591409 bytes; raw benchmark input; sha256 5d0e489aa811d0b1bb716c09617b9970162690c6c66db5fb5f52f1c69b7202c7)`
