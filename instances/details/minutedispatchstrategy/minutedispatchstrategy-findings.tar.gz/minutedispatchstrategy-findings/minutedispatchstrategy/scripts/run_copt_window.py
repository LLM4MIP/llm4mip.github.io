#!/usr/bin/env python3
"""Reoptimize one contiguous time window of the six primary binary schedules."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import coptpy as cp
from coptpy import COPT


PERIODS = 1440
PRIMARY_SERIES = {16, 17, 18, 19, 28, 29}


def read_solution(path: Path) -> dict[str, float]:
    values: dict[str, float] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        tokens = line.split()
        if len(tokens) >= 2 and not tokens[0].startswith(("=obj=", "#")):
            values[tokens[0]] = float(tokens[1])
    return values


def series_period(name: str) -> tuple[int, int] | None:
    if not name.startswith("x") or not name[1:].isdigit():
        return None
    index = int(name[1:])
    if not 1 <= index <= 29 * PERIODS:
        return None
    return (index - 1) // PERIODS + 1, (index - 1) % PERIODS + 1


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--start", type=int, required=True)
    parser.add_argument("--end", type=int, required=True)
    parser.add_argument("--seconds", type=float, default=300)
    parser.add_argument("--threads", type=int, default=32)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if not 1 <= args.start <= args.end <= PERIODS:
        raise ValueError("window must satisfy 1 <= start <= end <= 1440")

    args.out.mkdir(parents=True, exist_ok=True)
    values = read_solution(args.solution)
    model = cp.Envr().createModel("minutedispatch-window")
    model.read(str(args.model))
    variables = model.getVars().getAll()
    fixed_primary = 0
    free_primary = 0
    for variable in variables:
        name = variable.name
        coordinate = series_period(name)
        if coordinate and coordinate[0] in PRIMARY_SERIES:
            if args.start <= coordinate[1] <= args.end:
                free_primary += 1
            else:
                value = float(round(values.get(name, 0.0)))
                variable.setInfo(COPT.Info.LB, value)
                variable.setInfo(COPT.Info.UB, value)
                fixed_primary += 1

    model.setMipStart(variables, [values.get(variable.name, 0.0) for variable in variables])
    model.loadMipStart()
    model.setParam(COPT.Param.Logging, 1)
    model.setLogFile(str(args.out / "copt.log"))
    model.setParam(COPT.Param.Threads, args.threads)
    model.setParam(COPT.Param.TimeLimit, args.seconds)
    model.setParam(COPT.Param.RelGap, 0.0)
    model.solve()

    result = {
        "window_start": args.start,
        "window_end": args.end,
        "fixed_primary_binaries": fixed_primary,
        "free_primary_binaries": free_primary,
        "status": int(model.status),
        "solution_count": int(model.hasmipsol),
    }
    for key, attribute in (
        ("objective", "objval"),
        ("best_bound", "bestbnd"),
        ("relative_gap", "mipgap"),
        ("node_count", "nodecnt"),
        ("runtime", "solvingtime"),
    ):
        try:
            result[key] = float(getattr(model, attribute))
        except Exception:
            pass
    if model.hasmipsol:
        model.writeSol(str(args.out / "incumbent.sol"))
    (args.out / "summary.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
