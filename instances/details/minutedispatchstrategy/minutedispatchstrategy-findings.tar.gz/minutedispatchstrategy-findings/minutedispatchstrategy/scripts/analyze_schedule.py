#!/usr/bin/env python3
"""Summarize the binary time series in a minutedispatchstrategy solution."""

from __future__ import annotations

import argparse
import json
from decimal import Decimal
from pathlib import Path


PERIODS = 1440


def read_solution(path: Path) -> dict[str, Decimal]:
    values: dict[str, Decimal] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        tokens = line.split()
        if len(tokens) >= 2 and tokens[0].startswith("x"):
            values[tokens[0]] = Decimal(tokens[1])
    return values


def variable(series: int, period: int) -> str:
    return f"x{(series - 1) * PERIODS + period}"


def runs(bits: list[int]) -> list[dict[str, int]]:
    answer = []
    start = 1
    value = bits[0]
    for period, next_value in enumerate(bits[1:], 2):
        if next_value != value:
            answer.append(
                {"start": start, "end": period - 1, "length": period - start, "value": value}
            )
            start = period
            value = next_value
    answer.append(
        {"start": start, "end": len(bits), "length": len(bits) - start + 1, "value": value}
    )
    return answer


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()
    values = read_solution(args.solution)

    report = {}
    for series in range(16, 30):
        bits = [int(values.get(variable(series, period), Decimal(0)) > Decimal("0.5")) for period in range(1, PERIODS + 1)]
        encoded = runs(bits)
        report[str(series)] = {
            "ones": sum(bits),
            "transitions": len(encoded) - 1,
            "runs": encoded,
        }

    args.json.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(report, indent=2, sort_keys=True) + "\n"
    args.json.write_text(payload, encoding="utf-8")
    print(payload, end="")


if __name__ == "__main__":
    main()
