#!/usr/bin/env python3
"""Run the reproducible strict Gurobi solve or fixed-integer audit."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def read_solution(path: Path) -> dict[str, float]:
    values: dict[str, float] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        tokens = line.split()
        if len(tokens) >= 2 and not tokens[0].startswith(("=obj=", "#")):
            values[tokens[0]] = float(tokens[1])
    return values


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--mode", choices=["fixed", "solve"], default="solve")
    parser.add_argument("--seconds", type=float, default=1800)
    parser.add_argument("--threads", type=int, default=32)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)
    values = read_solution(args.solution)
    model = gp.read(str(args.model))
    model.Params.LogFile = str(args.out / "gurobi.log")
    model.Params.Threads = args.threads
    model.Params.TimeLimit = args.seconds
    model.Params.MIPGap = 0
    model.Params.FeasibilityTol = 1e-9
    model.Params.IntFeasTol = 1e-9
    model.Params.NumericFocus = 2
    if args.mode == "solve":
        model.Params.MIPFocus = 3
        model.Params.Heuristics = 0.1
    for variable in model.getVars():
        if args.mode == "fixed" and variable.VType in (GRB.BINARY, GRB.INTEGER):
            value = round(values.get(variable.VarName, 0.0))
            variable.LB = value
            variable.UB = value
        elif variable.VarName in values:
            value = values[variable.VarName]
            if variable.VType in (GRB.BINARY, GRB.INTEGER):
                value = round(value)
            variable.Start = value
    model.optimize()

    result = {
        "status": int(model.Status),
        "runtime": model.Runtime,
        "node_count": model.NodeCount,
        "solution_count": model.SolCount,
    }
    if model.SolCount:
        result.update(
            objective=model.ObjVal,
            max_constraint_violation=model.ConstrVio,
            max_bound_violation=model.BoundVio,
            max_integrality_violation=model.IntVio,
        )
        model.write(str(args.out / "incumbent.sol"))
    if model.IsMIP:
        result["best_bound"] = model.ObjBound
        result["relative_gap"] = model.MIPGap
    (args.out / "summary.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
