#!/usr/bin/env python3
"""Parse and audit the ranged MPS for minutedispatchstrategy."""

from __future__ import annotations

import argparse
import gzip
import json
from collections import Counter, defaultdict
from decimal import Decimal
from pathlib import Path


def number(text: str) -> Decimal:
    return Decimal(text.replace("D", "E").replace("d", "e"))


def compact(value: Decimal) -> str:
    return str(value.normalize()) if value else "0"


def open_text(path: Path):
    if path.suffix.lower() == ".gz":
        return gzip.open(path, "rt", encoding="latin-1")
    return path.open(encoding="latin-1")


def parse(path: Path):
    section = ""
    row_types = {}
    row_order = []
    objective_rows = set()
    columns = defaultdict(list)
    variable_order = []
    seen_variables = set()
    integer_variables = set()
    integer_mode = False
    rhs = defaultdict(Decimal)
    ranges = defaultdict(Decimal)
    bound_records = []
    with open_text(path) as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if not raw[0].isspace() and tokens[0] in {
                "NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"
            }:
                section = tokens[0]
                continue
            if section == "ROWS":
                kind, row = tokens[:2]
                row_types[row] = kind
                if kind == "N":
                    objective_rows.add(row)
                else:
                    row_order.append(row)
            elif section == "COLUMNS":
                if "'MARKER'" in tokens:
                    integer_mode = "'INTORG'" in tokens
                    continue
                variable = tokens[0]
                if variable not in seen_variables:
                    seen_variables.add(variable)
                    variable_order.append(variable)
                if integer_mode:
                    integer_variables.add(variable)
                for row, value in zip(tokens[1::2], tokens[2::2]):
                    columns[variable].append((row, number(value)))
            elif section == "RHS":
                for row, value in zip(tokens[1::2], tokens[2::2]):
                    rhs[row] += number(value)
            elif section == "RANGES":
                for row, value in zip(tokens[1::2], tokens[2::2]):
                    ranges[row] += number(value)
            elif section == "BOUNDS":
                bound_records.append(tokens)

    lower = {v: Decimal(0) for v in variable_order}
    upper = {v: None for v in variable_order}
    for tokens in bound_records:
        kind, variable = tokens[0], tokens[2]
        value = number(tokens[3]) if len(tokens) > 3 else Decimal(0)
        if kind == "LO":
            lower[variable] = value
        elif kind == "UP":
            upper[variable] = value
        elif kind == "FX":
            lower[variable] = upper[variable] = value
        elif kind == "FR":
            lower[variable], upper[variable] = None, None
        elif kind == "MI":
            lower[variable] = None
        elif kind == "PL":
            upper[variable] = None
        elif kind == "BV":
            lower[variable], upper[variable] = Decimal(0), Decimal(1)
            integer_variables.add(variable)
        elif kind == "LI":
            lower[variable] = value
            integer_variables.add(variable)
        elif kind == "UI":
            upper[variable] = value
            integer_variables.add(variable)
        else:
            raise ValueError(f"unsupported bound type {kind}")

    entries = defaultdict(list)
    objective = defaultdict(Decimal)
    for variable in variable_order:
        for row, coefficient in columns[variable]:
            if row in objective_rows:
                objective[variable] += coefficient
            else:
                entries[row].append((variable, coefficient))
    return {
        "row_types": row_types,
        "row_order": row_order,
        "variable_order": variable_order,
        "integer_variables": integer_variables,
        "rhs": rhs,
        "ranges": ranges,
        "lower": lower,
        "upper": upper,
        "entries": entries,
        "objective": objective,
    }


def row_interval(kind: str, rhs: Decimal, range_value: Decimal | None):
    if range_value is None or range_value == 0:
        if kind == "E":
            return rhs, rhs
        if kind == "G":
            return rhs, None
        return None, rhs
    width = abs(range_value)
    if kind == "G":
        return rhs, rhs + width
    if kind == "L":
        return rhs - width, rhs
    if range_value > 0:
        return rhs, rhs + width
    return rhs - width, rhs


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("--solution", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--quiet", action="store_true", help="write JSON without echoing it")
    args = parser.parse_args()
    model = parse(args.mps)
    variables = model["variable_order"]
    variable_set = set(variables)
    integers = model["integer_variables"]
    binary = {
        v for v in integers if model["lower"][v] == 0 and model["upper"][v] == 1
    }
    continuous = set(variables) - integers

    row_signatures = Counter()
    row_summaries = []
    two_variable_deltas = Counter()
    variable_degrees = Counter()
    for row in model["row_order"]:
        terms = model["entries"][row]
        for variable, _ in terms:
            variable_degrees[variable] += 1
        bterms = [(v, a) for v, a in terms if v in binary]
        cterms = [(v, a) for v, a in terms if v in continuous]
        lower, upper = row_interval(
            model["row_types"][row],
            model["rhs"][row],
            model["ranges"].get(row),
        )
        signature = (
            model["row_types"][row],
            len(bterms),
            len(cterms),
            len(terms),
            compact(model["rhs"][row]),
            compact(model["ranges"][row]) if row in model["ranges"] else None,
            tuple(sorted(Counter(compact(a) for _, a in terms).items())),
        )
        row_signatures[signature] += 1
        if len(terms) == 2 and all(v.startswith("x") and v[1:].isdigit() for v, _ in terms):
            indices = sorted(int(v[1:]) for v, _ in terms)
            two_variable_deltas[indices[1] - indices[0]] += 1
        row_summaries.append(
            {
                "row": row,
                "sense": model["row_types"][row],
                "binary_nz": len(bterms),
                "continuous_nz": len(cterms),
                "nz": len(terms),
                "rhs": compact(model["rhs"][row]),
                "range": compact(model["ranges"][row]) if row in model["ranges"] else None,
                "lower": compact(lower) if lower is not None else None,
                "upper": compact(upper) if upper is not None else None,
                "terms": [[v, compact(a)] for v, a in terms],
            }
        )

    # Consecutive blocks of identical coarse row type expose the time-series
    # formulation without needing original variable names.
    row_blocks = []
    for index, summary in enumerate(row_summaries, 1):
        coarse = (
            summary["sense"], summary["binary_nz"], summary["continuous_nz"],
            summary["nz"], summary["range"] is not None,
        )
        if row_blocks and row_blocks[-1]["signature"] == coarse:
            row_blocks[-1]["end"] = index
            row_blocks[-1]["count"] += 1
        else:
            row_blocks.append(
                {"start": index, "end": index, "count": 1, "signature": coarse}
            )

    objective_nonzero = [v for v in variables if model["objective"].get(v, 0)]
    objective_counts = Counter(compact(model["objective"][v]) for v in objective_nonzero)

    # Compare anonymous variable signatures at the two natural periods:
    # 1440 (series-major) and 29 (time-major).
    variable_signature = []
    for variable in variables:
        variable_signature.append(
            (
                variable in integers,
                compact(model["objective"].get(variable, Decimal(0))),
                variable_degrees[variable],
                compact(model["lower"][variable]) if model["lower"][variable] is not None else None,
                compact(model["upper"][variable]) if model["upper"][variable] is not None else None,
            )
        )
    lag_matches = {}
    for lag in (1, 29, 1439, 1440):
        matches = sum(
            variable_signature[i] == variable_signature[i + lag]
            for i in range(len(variable_signature) - lag)
        )
        lag_matches[str(lag)] = {
            "matches": matches,
            "comparisons": len(variable_signature) - lag,
            "fraction": matches / (len(variable_signature) - lag),
        }

    solution_summary = None
    solution_values = None
    if args.solution:
        values = {v: Decimal(0) for v in variables}
        solution_values = values
        declared_objective = None
        for line in args.solution.read_text(encoding="utf-8").splitlines():
            tokens = line.split()
            if not tokens:
                continue
            if tokens[0].startswith("=obj="):
                declared_objective = tokens[-1]
            elif len(tokens) >= 2 and tokens[0] in values:
                values[tokens[0]] = number(tokens[1])
        exact_objective = sum(model["objective"].get(v, 0) * values[v] for v in variables)
        violations = []
        for summary in row_summaries:
            row = summary["row"]
            activity = sum(a * values[v] for v, a in model["entries"][row])
            lower, upper = row_interval(
                model["row_types"][row], model["rhs"][row], model["ranges"].get(row)
            )
            violation = Decimal(0)
            if lower is not None:
                violation = max(violation, lower - activity)
            if upper is not None:
                violation = max(violation, activity - upper)
            if violation > 0:
                violations.append((violation, row, activity, lower, upper))
        bound_violations = []
        integrality_violations = []
        for variable in variables:
            value = values[variable]
            lower = model["lower"][variable]
            upper = model["upper"][variable]
            violation = Decimal(0)
            if lower is not None:
                violation = max(violation, lower - value)
            if upper is not None:
                violation = max(violation, value - upper)
            if violation > 0:
                bound_violations.append((violation, variable))
            if variable in integers:
                violation = abs(value - value.to_integral_value())
                if violation > 0:
                    integrality_violations.append((violation, variable))
        violations.sort(reverse=True)
        bound_violations.sort(reverse=True)
        integrality_violations.sort(reverse=True)
        solution_summary = {
            "declared_objective": declared_objective,
            "computed_objective": compact(exact_objective),
            "exact_row_violations": len(violations),
            "row_violations_above_1e-6": sum(v[0] > Decimal("1e-6") for v in violations),
            "max_row_violation": compact(violations[0][0]) if violations else "0",
            "violation_head": [
                {
                    "row": row,
                    "violation": compact(violation),
                    "activity": compact(activity),
                    "lower": compact(lower) if lower is not None else None,
                    "upper": compact(upper) if upper is not None else None,
                }
                for violation, row, activity, lower, upper in violations[:30]
            ],
            "bound_violations_above_1e-6": sum(
                v[0] > Decimal("1e-6") for v in bound_violations
            ),
            "max_bound_violation": compact(bound_violations[0][0]) if bound_violations else "0",
            "integrality_violations_above_1e-6": sum(
                v[0] > Decimal("1e-6") for v in integrality_violations
            ),
            "max_integrality_violation": (
                compact(integrality_violations[0][0]) if integrality_violations else "0"
            ),
            "nonzero_variables_above_1e-8": sum(abs(values[v]) > Decimal("1e-8") for v in variables),
            "selected_binaries": sum(values[v] > Decimal("0.5") for v in binary),
        }

    series_summaries = []
    for series in range(1, 30):
        members = [f"x{(series - 1) * 1440 + t}" for t in range(1, 1441)]
        existing = [v for v in members if v in variable_set]
        types = Counter("binary" if v in binary else "continuous" for v in existing)
        objectives = [model["objective"].get(v, Decimal(0)) for v in existing]
        lowers = Counter(
            compact(model["lower"][v]) if model["lower"][v] is not None else "-inf"
            for v in existing
        )
        uppers = Counter(
            compact(model["upper"][v]) if model["upper"][v] is not None else "+inf"
            for v in existing
        )
        item = {
            "series": series,
            "first_variable": existing[0],
            "last_variable": existing[-1],
            "type_counts": dict(types),
            "objective_nonzeros": sum(value != 0 for value in objectives),
            "objective_head": [compact(value) for value in objectives[:10]],
            "objective_distinct": len(set(objectives)),
            "lower_bound_counts": dict(lowers),
            "upper_bound_counts": dict(uppers),
            "degree_counts": dict(Counter(variable_degrees[v] for v in existing)),
        }
        if solution_values is not None:
            active = [v for v in existing if abs(solution_values[v]) > Decimal("1e-8")]
            item.update(
                solution_nonzeros=len(active),
                solution_min=compact(min(solution_values[v] for v in existing)),
                solution_max=compact(max(solution_values[v] for v in existing)),
                solution_head=[compact(solution_values[v]) for v in existing[:10]],
                objective_contribution=compact(
                    sum(model["objective"].get(v, 0) * solution_values[v] for v in existing)
                ),
            )
        series_summaries.append(item)

    scalar_variable = "x41761"
    scalar_summary = {
        "variable": scalar_variable,
        "type": "binary" if scalar_variable in binary else "continuous",
        "lower": compact(model["lower"][scalar_variable]),
        "upper": compact(model["upper"][scalar_variable]),
        "objective": compact(model["objective"].get(scalar_variable, 0)),
        "degree": variable_degrees[scalar_variable],
    }
    if solution_values is not None:
        scalar_summary["solution_value"] = compact(solution_values[scalar_variable])
        scalar_summary["objective_contribution"] = compact(
            model["objective"].get(scalar_variable, 0) * solution_values[scalar_variable]
        )

    support_patterns = Counter()
    for row in model["row_order"]:
        series_and_times = []
        for variable, _coefficient in model["entries"][row]:
            index = int(variable[1:])
            if index == 41761:
                series_and_times.append((30, 0))
            else:
                series_and_times.append(((index - 1) // 1440 + 1, (index - 1) % 1440 + 1))
        ordinary_times = [time for series, time in series_and_times if series <= 29]
        time_span = max(ordinary_times) - min(ordinary_times) if ordinary_times else 0
        support_patterns[
            (
                model["row_types"][row],
                tuple(sorted(series for series, _ in series_and_times)),
                time_span,
            )
        ] += 1

    for block in row_blocks:
        for label, position in (("first_row", block["start"] - 1), ("last_row", block["end"] - 1)):
            sample = row_summaries[position]
            converted_terms = []
            for variable, coefficient in sample["terms"]:
                index = int(variable[1:])
                if index == 41761:
                    converted_terms.append([variable, 30, 0, coefficient])
                else:
                    converted_terms.append(
                        [variable, (index - 1) // 1440 + 1, (index - 1) % 1440 + 1, coefficient]
                    )
            block[label] = {
                "row": sample["row"],
                "sense": sample["sense"],
                "rhs": sample["rhs"],
                "terms": converted_terms,
            }

    report = {
        "rows": len(model["row_order"]),
        "variables": len(variables),
        "binary_variables": len(binary),
        "other_integer_variables": len(integers - binary),
        "continuous_variables": len(continuous),
        "nonzeros": sum(len(model["entries"][r]) for r in model["row_order"]),
        "row_sense_counts": dict(Counter(model["row_types"][r] for r in model["row_order"])),
        "ranged_rows": len(model["ranges"]),
        "range_value_counts": dict(Counter(compact(v) for v in model["ranges"].values())),
        "objective_nonzeros": len(objective_nonzero),
        "objective_coefficient_counts": dict(objective_counts),
        "top_row_signatures": [
            {
                "count": count,
                "sense": signature[0],
                "binary_nz": signature[1],
                "continuous_nz": signature[2],
                "nz": signature[3],
                "rhs": signature[4],
                "range": signature[5],
                "coefficient_counts": dict(signature[6]),
            }
            for signature, count in row_signatures.most_common(40)
        ],
        "two_variable_index_delta_counts": dict(two_variable_deltas.most_common(40)),
        "lag_signature_matches": lag_matches,
        "variable_series": series_summaries,
        "scalar_variable": scalar_summary,
        "top_series_support_patterns": [
            {
                "count": count,
                "sense": signature[0],
                "series": signature[1],
                "time_span": signature[2],
            }
            for signature, count in support_patterns.most_common(60)
        ],
        "row_blocks": row_blocks,
        "row_samples": row_summaries[:30] + row_summaries[-30:],
        "solution": solution_summary,
    }
    payload = json.dumps(report, indent=2, sort_keys=True) + "\n"
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(payload, encoding="utf-8")
    if not args.quiet:
        print(payload, end="")


if __name__ == "__main__":
    main()
