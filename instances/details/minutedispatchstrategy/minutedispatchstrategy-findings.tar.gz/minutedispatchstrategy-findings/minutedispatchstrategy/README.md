# `minutedispatchstrategy` — computational closure at 3109.9034777596576 (official status: `open`)

## Official-status boundary

As of 2026-09-09, the [MIPLIB instance page](https://miplib.zib.de/instance_details_minutedispatchstrategy.html)
still labels this instance `open`, and the latest official
[`miplib2017-v36.solu`](https://miplib.zib.de/downloads/miplib2017-v36.solu),
released on 2026-01-26, records `3109.903477759654` as `=best=`, not `=opt=`.
The zero-gap run archived here was produced on 2026-09-07, after that official
snapshot, and has not yet been incorporated into or confirmed by MIPLIB.  Thus
this directory reports a **new computational closure of an
officially open instance**, not an already accepted MIPLIB status change.

The contribution is not a primal improvement: for this minimization model, the
strictly replayed objective `3109.90347775965745281461` is about `3.45e-12`
higher than the v36 headline `3109.903477759654`, a display/recomputation-scale
difference.  The new evidence is the floating-point branch-and-bound lower
bound that meets the strict incumbent.

2026-09-14 independent dual-bound review: [adopted bound, proof chain, checks, and limitations](../../docs/dual-bound-audit-2026-09-14/cases/minutedispatchstrategy.zh.md). Reviewed lower bound: **approximately 3109.9034777596576**. The conflicting old PDF primal record remains unresolved. This review distinguishes exact, literature, and numerical evidence; historical statements below remain dated records.

## Result

Gurobi 13.0.1 closed the original compressed MPS at
**3109.9034777596576** in 646.47 seconds and 68,212 branch-and-bound nodes.
The run used zero requested MIP gap, feasibility and integrality tolerances of
`1e-9`, `NumericFocus=2`, `MIPFocus=3`, `Heuristics=0.1`, and 32 threads.
It loaded the public MIPLIB solution as a MIP start but did not fix its variables
or add any problem-specific user cuts.  Gurobi's own presolve and generic cuts
were active.  Its final primal and dual bounds are identical; the MIP start
provided only the incumbent, while the branch-and-bound search established the
matching lower bound.

The written incumbent was independently evaluated with `Decimal` arithmetic:

```text
objective=3109.90347775965745281461
rows=80194 exact_row_violations=2461 row_violations_above_1E-9=0 max_row_violation=1.10903484517902902E-11
bound_violations_above_1E-9=0 exact_integrality_violations=0 integrality_violations_above_1E-9=0 max_integrality_violation=0
```

This is a **computational global conclusion**, not a portable exact
lower-bound certificate: the primal witness has an independent strict audit,
while the lower bound is the floating-point branch-and-bound result in the
archived Gurobi log.

The compressed input SHA-256 is
`5d0e489aa811d0b1bb716c09617b9970162690c6c66db5fb5f52f1c69b7202c7`.

## Recovered structure

The anonymous model has 41,761 columns, 80,194 rows, and 239,480 nonzeros.
It is organized as 29 time series of length 1,440 plus one fixed objective
offset column.  Direct matrix inspection and the application paper identify:

- four generator-output series with 60/60/30/30 kW capacities;
- fuel use, battery state of charge, and electrochemical concentration states;
- four generator on/off series and eight derived start/minimum-up/down series;
- two mutually exclusive battery charge/discharge mode series;
- minute-by-minute power balance, capacity, ramp, state-transition, and
  mode-disjunction rows.

Although the original model contains 20,156 integer columns, Gurobi presolve
leaves 8,640 binary decisions: six primary schedules times 1,440 minutes.  The
other binary series are logical auxiliaries eliminated by propagation.  The
verified optimum turns the first two 60 kW generators off, runs the third
generator from minute 235 through minute 1,440, and uses the fourth generator
only in the four supplied initial-history periods.  The battery charge and
discharge indicators contain 38 and 11 transitions, respectively.

## Numerical-tolerance experiment

A structure-specific COPT 8.0.4 experiment fixed all six primary schedules
outside minutes 1--480 and reoptimized the remaining 2,880 primary binaries.
It returned a nominally better value, `3109.903146813258`, in 9.48 seconds.
However:

- the primary generator and battery schedules are identical to the strict
  Gurobi solution;
- exact decimal replay finds maximum row violation `7.5762573883e-7`;
- Gurobi rejects that start at `1e-9`; fixing its integer vector and
  reoptimizing the continuous variables restores `3109.9034777596576`.

Thus the apparent `0.0003309464` improvement is a feasibility-tolerance
artifact, not a new strict incumbent.  This also gives a concrete reason to
treat externally reported rounded values such as `3109.9026` cautiously when
the underlying solution is unavailable.

The generic COPT baseline was stopped after 566 seconds at its displayed
29.41% gap because it was clearly dominated by both the structural window and
the Gurobi run.

## Reproduction

```sh
python scripts/analyze_structure.py input/minutedispatchstrategy.mps.gz \
  --solution solutions/strict-gurobi.sol \
  --json artifacts/structure-summary.json --quiet

python scripts/analyze_schedule.py solutions/strict-gurobi.sol \
  --json artifacts/incumbent-schedule.json

python scripts/run_gurobi.py input/minutedispatchstrategy.mps.gz \
  solutions/miplib-solution-1.sol --mode solve --seconds 1800 --threads 32 \
  --out experiments/baseline-gurobi

python ../../common/exact_mps_solution_check.py \
  input/minutedispatchstrategy.mps.gz solutions/strict-gurobi.sol \
  --tolerance 1e-9
```

Key evidence is in
[`baseline-gurobi/summary.json`](experiments/baseline-gurobi/summary.json),
[`baseline-gurobi/gurobi.log`](experiments/baseline-gurobi/gurobi.log),
[`strict-solution-audit.txt`](artifacts/strict-solution-audit.txt), and the
[`COPT window audit`](artifacts/copt-window-audit.txt).  The zero-difference
check for all 8,640 primary schedule bits is archived in
[`primary-schedule-comparison.json`](artifacts/primary-schedule-comparison.json).

## Sources and status boundary

- [MIPLIB instance page](https://miplib.zib.de/instance_details_minutedispatchstrategy.html)
- [Husted et al., Applied Energy 219 (2018), 394--407](https://doi.org/10.1016/j.apenergy.2017.08.139)
- [Smoothie Phase I report](https://optimization-online.org/wp-content/uploads/2025/10/Smoothie-PhaseI.pdf)

The MIPLIB page still labels the instance `open` and displays
`3109.903477759654*`; the timing and review boundary are stated at the top of
this file.  Smoothie reports `3109.9026 / 3109.8537` but explicitly
warns that its computed dual bounds were not independently verified, and no
corresponding solution is available in the materials found here.  Those facts
do not override the evidence boundary of this package.
