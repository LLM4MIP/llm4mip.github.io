#  `minutedispatchstrategy` study report

## Conclusion

The original MPS is in Gurobi 13.0.1, `FeasibilityTol=1e-9`, `IntFeasTol=1e-9`,
`MIPGap=0`, `NumericFocus=2` is given by:

\[
\mathrm{UB}=\mathrm{LB}=3109.9034777596576.
\]

The run took 646.47 seconds and searched 68,212 nodes. The written solution underwent independent row-by-row `Decimal`
The maximum error for the 80,194 bar constraint is `1.1091e-11`, which does not exceed the constraint for `1e-9`.
Border or integrality is violated. This can therefore be referred to as **numerical branch-and-bound supported computational optimal solution**.
Boundaries need to be maintained: there is currently no dual certificate that can be replayed by an independent exact checker.

##  official state boundaries

As of 2026 -09 -09, the official MIPLIB website still labels this title as `open`.
`miplib2017-v36.solu` was released on 2026 -01 -26 with objective value
`3109.903477759654` is still referred to as `=best=` instead of `=opt=`. Gurobi in this directory
The zero gap operation was generated at 2026 -09 -07, later than this snapshot, which has not yet been collected or confirmed by MIPLIB.
So the conclusion here is that **is a new computational closure of the official open instance**, not already.
MIPLIB official status changes in effect.

This result does not constitute a primal improvement: for this minimization model, the strict recalculation value
`3109.90347775965745281461` exceeds the v36 headline `3109.903477759654` by approximately
`3.45e-12`, just the difference in the accuracy of the display/recalculation scale.
The floating-point branch-and-bound lower bound.
Unmodified official MPS, loaded public solution as MIP start, no fixed variable, nor added
The problem is the backdrop of artificial cuts; but it uses 32 threads, `MIPFocus=3`, `NumericFocus=2`,
`Heuristics=0.1` and other non-default settings, as well as Gurobi's own pre-processing and general cuts.

## Structure

The model consists of the 29 group length as a minute-to-minute time sequence of 1,440 and a fixed constant column matrix.
Structure consistent with the application paper: four diesel generators, photovoltaic/load balance, high reliability battery concentration gradient
State of charge, disconnection, climbing and minimum downtime.

In an integer column 20,156, a large number of columns are just auxiliary variables that start the stop-motion logic.
8,640 is a binary variable that is exactly six sets of major decisions multiplied by 1,440 minutes: four sets of generating unit switches and two sets.
Battery charging/discharging mode

Optimum timetable: The first two 60 kW generating units are completely shut down; the third 30 kW generating unit from the second 235 minute
Run through minute 1,440; the fourth 30 kW generating unit is on only during four historical initial periods. The battery
The charging mode has 383, 1, 38, and the discharge mode has 239, 1, 11.

##  Why a slightly lower objective value is not an improvement

COPT returned to `3109.903146813258` after the main binary variable outside the fixed window.
strict solution is good for `0.0003309464`, but its main switching schedule is complete unchanged.
`c49154` violated `7.5762573883e-7`; Gurobi rejected the starting point under `1e-9`.
After recalling the continuous LP, the objective is restored to `3109.9034777596576`.

So this experiment directly proves that the subject is very sensitive to feasibility tolerance.
`3109.9026` does not have a public solution document and cannot therefore be considered strictly superior to the current solution; the paper itself also discusses
The dual boundary that cannot be verified independently warns.

##  Classification of evidence

-  Primal bound: independent row by row decimal nuclear test with error less than `1e-9`;
-  lower bound: Gurobi floating-point branch-and-bound zero gap;
-  COPT: The general baseline is significantly weaker; window experiments are used to reveal numerical tolerance effects;
-  In general, the best calculation is without pretending to be an exact certificate proof.
