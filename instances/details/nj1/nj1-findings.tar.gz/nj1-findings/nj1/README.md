# nj1: improved first strict incumbent, 382.0606208032

## Result and claim boundary

This directory contains a new **strictly feasible original-MPS solution** with
objective

```text
382.0606208032
```

The official MIPLIB page still listed `nj1` as `open`, `no_solution`, and with
no objective value when checked on 2026-09-08. Thus this is a first public
incumbent relative to that page. It is **not** an optimality result: this work
does not provide a global lower bound or proof that 382.0606208032 is optimal.

The current archived artifacts are:

- [`solutions/compound-kick-382.0606208032.sol`](solutions/compound-kick-382.0606208032.sol):
  sparse full-model solution in MIPLIB-compatible `=obj=` format, SHA-256
  `98024c992d8c5e20f72a4f3d7e0c4c7d9c8c0c18c2cf3682eee1aeda48063950`;
- [`analysis/final-assignment-382.0606208032.json`](analysis/final-assignment-382.0606208032.json):
  compact self-contained 595-label assignment, SHA-256
  `a13e58bd98050c830ca3436eb616410cb60fc64d3b2424f8bf5f29cac6ddeba5`;
- [`analysis/continuation-403-to-382.0606208032-archive.json`](analysis/continuation-403-to-382.0606208032-archive.json):
  hashes, exact continuation, terminal-neighborhood counts, strict witnesses,
  and the precise evidence boundary;
- [`../nj3/analysis/exact-pair-copt8-from382/`](../nj3/analysis/exact-pair-copt8-from382/):
  COPT 8 computational closure of all 21 current adjacent-district-pair
  repartition subproblems;
- [`../nj3/analysis/exact-triple-copt8-from382/`](../nj3/analysis/exact-triple-copt8-from382/)
  and [`../nj3/analysis/exact-quad-copt8-from382/`](../nj3/analysis/exact-quad-copt8-from382/):
  computational closures of all 39 current anchor-fixed connected triple and
  all 67 current anchor-fixed connected quad subproblems;
- [`analysis/compound-kick-from383-382.0606208032.full.json.gz`](analysis/compound-kick-from383-382.0606208032.full.json.gz)
  and [`analysis/compound-kick-terminal-from382.0606208032.full.json.gz`](analysis/compound-kick-terminal-from382.0606208032.full.json.gz):
  complete per-candidate kick and descent traces, with compact summaries beside them;
- [`analysis/compound-kick-382.0606208032-validation.json`](analysis/compound-kick-382.0606208032-validation.json)
  and [`solutions/compound-kick-382.0606208032.independent-check.log`](solutions/compound-kick-382.0606208032.independent-check.log):
  two zero-tolerance original-MPS checks.

The preceding `383.6229250390` evidence remains archived as:

- [`solutions/pair-recombination-383.6229250390.sol`](solutions/pair-recombination-383.6229250390.sol):
  sparse full-model solution in MIPLIB-compatible `=obj=` format, SHA-256
  `237c76a8ce69c0c3a6966831452fb33a9e567b8334f08d93e9f5e4a646c66f25`;
- [`../nj3/analysis/district-pair-recombination-from403.json`](../nj3/analysis/district-pair-recombination-from403.json):
  exact 11-step district-pair recombination trace from `403.4107959378`,
  SHA-256 `3b0d3aef550731d9a62338c7a9ae22b7c4f8d5f4fdf70c36b0678936a8c2c942`;
- [`../nj3/analysis/district-pair-recombination-post-two-node.json`](../nj3/analysis/district-pair-recombination-post-two-node.json):
  shared final 595-label assignment and audited local-search boundary, SHA-256
  `82eb07cba899020d7361618f73c2d2f984e036dc346b95f6d0e573df3a401401`;
- [`analysis/pair-recombination-383.6229250390-validation.json`](analysis/pair-recombination-383.6229250390-validation.json)
  and [`solutions/pair-recombination-383.6229250390.independent-check.log`](solutions/pair-recombination-383.6229250390.independent-check.log):
  two zero-tolerance original-MPS checks.

The preceding `403.4107959378` evidence remains archived as:

- [`solutions/large-neighborhood-403.4107959378.sol`](solutions/large-neighborhood-403.4107959378.sol):
  sparse full-model solution in MIPLIB-compatible `=obj=` format, SHA-256
  `8910184c9778351f27044d29090959e28e1516aa8555c5457f4ed873795528a3`;
- [`analysis/large-neighborhood-chain-403.4107959378.json`](analysis/large-neighborhood-chain-403.4107959378.json):
  self-contained 46-move exact chain and final 595 labels, SHA-256
  `73ee1479655d1b5ac3b821b36faa892f8745c7a64489a8f69ba3ca63e898e7c9`;
- [`analysis/large-neighborhood-403.4107959378-archive.json`](analysis/large-neighborhood-403.4107959378-archive.json):
  hashes, terminal-neighborhood counts, strict-witness paths and evidence boundary;
- [`analysis/large-neighborhood-403.4107959378-validation.json`](analysis/large-neighborhood-403.4107959378-validation.json)
  and [`solutions/large-neighborhood-403.4107959378.independent-check.log`](solutions/large-neighborhood-403.4107959378.independent-check.log):
  two zero-tolerance original-MPS checks;
- [`analysis/large-neighborhood-terminal-scan-403.4107959378.json.gz`](analysis/large-neighborhood-terminal-scan-403.4107959378.json.gz)
  and [`analysis/large-neighborhood-terminal-kicks-403.4107959378.compact.json.gz`](analysis/large-neighborhood-terminal-kicks-403.4107959378.compact.json.gz):
  compressed terminal scan and all 2,322 fully descended kick outcomes.

The preceding `438.5907110388` evidence remains archived as:

- [`solutions/copt8-post-descent-438.5907110388.sol`](solutions/copt8-post-descent-438.5907110388.sol):
  sparse full-model solution in MIPLIB-compatible `=obj=` format, SHA-256
  `55a82eb41966a65fc4fa3a5c7372bf3707fb670a464c7df915666c8c1bc5543e`;
- [`../nj2/analysis/copt8-post-two-node-assignment.json`](../nj2/analysis/copt8-post-two-node-assignment.json):
  shared 595-node district assignment and exact postprocessing trace, SHA-256
  `35a3bfeca3331fd3c3f09511c56c5509ddabc9da95944f92386e15e60680e760`;
- [`analysis/copt8-post-descent-438.5907110388-validation.json`](analysis/copt8-post-descent-438.5907110388-validation.json):
  full zero-tolerance Decimal reconstruction check;
- [`solutions/copt8-post-descent-438.5907110388.independent-check.log`](solutions/copt8-post-descent-438.5907110388.independent-check.log):
  a second check by the repository-wide independent MPS checker;
- [`../nj2/analysis/copt8-post-descent-archive.json`](../nj2/analysis/copt8-post-descent-archive.json):
  frozen COPT, extraction, reconstruction, exact-search, hash and evidence record;
- [`logs/tree-partition-search.log`](logs/tree-partition-search.log): the compact
  improvement trace from the 200-restart constructive search.

The earlier `529.9611973238`, `465.1832684642`, `459.0072494478`,
`438.5907110388`, `403.4107959378`, and `383.6229250390` solutions
are retained under their original names as reproducible intermediate history.

Both validators agree exactly:

```text
objective=382.0606208032
rows=97579 exact_row_violations=0 row_violations_above_0=0 max_row_violation=0
bound_violations_above_0=0 exact_integrality_violations=0
```

The district populations are

```text
734319 698622 709713 753854 745737 722380
752155 708458 765299 707970 762659 730728
```

and every one is in the exact MPS interval `[696025, 769290]`. Each district
is connected in the decoded 595-node, 1,574-edge graph. The same assignment is
also lifted to a strict `nj2` incumbent with the identical objective; see
[`../nj2/README.md`](../nj2/README.md).

## Gurobi 13 read-only structure audit

The original MPS was read on `euler4` by Gurobi 13.0.1 before any solve was
attempted. [`analysis/nj1-gurobi13-structure.json`](analysis/nj1-gurobi13-structure.json)
and [`experiments/gurobi13_structure.py`](experiments/gurobi13_structure.py)
record that `optimize()` and `presolve()` were not called.

Gurobi read:

- 78,084 variables, 97,579 linear rows, and 321,540 nonzeros;
- 63,804 continuous variables and 14,280 integral `[0,1]` variables;
- 44,916 `<=`, 7,747 equality, and 44,916 `>=` rows;
- 18,888 nonzero objective coefficients, all positive;
- 607 all-integral unit-coefficient partitioning rows: 595 rows of size 12 and
  12 rows of size 595;
- no quadratic, SOS, or general constraints;
- Gurobi fingerprint `2122841654`.

The Gurobi parser labels the 14,280 marker-declared columns as integer (`I`),
while their exact bounds are `[0,1]`; the JSON therefore reports both the raw
reader type and the independently counted logical-binary total.

## Exact model reconstruction

The official MIPLIB decomposition is recovered exactly as 12 variable-disjoint
district blocks coupled by 607 master rows. The machine-readable audit is
[`analysis/structure.json`](analysis/structure.json):

- all 78,084 columns belong to exactly one block and no column crosses blocks;
- columns are interleaved by district with
  `block(C_k) = 1 + ((k-1) mod 12)`;
- rows `R0001`--`R0595` assign each of 595 geographic units to one district;
- rows `R38372`--`R38383` select one connectivity root per district;
- each block has 6,507 variables and 8,081 local rows;
- the common core contains 1,574 undirected adjacency edges, two directed-flow
  arcs per edge and district, population balance, and weighted-boundary terms.

The exact decoded population total is 8,791,894, so the ideal district size is
732,657.8333. The MPS permits approximately +/-5% around that value.

## Constructive method

[`experiments/connected_tree_partition.py`](experiments/connected_tree_partition.py)
uses the decoded graph instead of treating the 78,084-column model as a black
box. In each restart it repeatedly:

1. builds a randomized DFS spanning tree of the remaining connected graph;
2. cuts a descendant subtree whose exact population is in the allowed interval
   and leaves enough population for the remaining districts;
3. repeats for eleven districts, leaving the connected remainder as district
   twelve.

Both sides of every tree cut stay connected by construction. In 200 deterministic
restarts with seed `20260915`, feasible objectives improved as follows:

```text
restart 1   634.5767255470
restart 2   551.9134772038
restart 29  537.8616230246
restart 95  535.4494957308
restart 163 529.9611973238
```

[`experiments/connected_boundary_steepest_descent.py`](experiments/connected_boundary_steepest_descent.py)
then exhaustively inspects every one-node move from a district to an adjacent
district. A move is admitted only if exact integer populations remain in range
and both affected districts remain connected. It deterministically applies the
largest exact objective decrease and stops only after a complete pass finds no
improving feasible one-node move. Starting from 529.9611973238, 27 such moves
give

```text
465.1832684642
```

an exact improvement of `64.7779288596`. The final pass examined 126 feasible
one-node boundary moves and found none improving. This proves local optimality
only in that explicitly enumerated neighborhood.

[`experiments/connected_two_node_steepest_descent.py`](experiments/connected_two_node_steepest_descent.py)
continues from that intermediate solution. Its neighborhood is the union of
one-node transfers, cross-district two-point exchanges, and transfers of an
adjacent two-node pair to another district. Every candidate receives a full
`Decimal` objective recomputation and explicit exact population/connectivity
checks. Three pair transfers, one exchange, and one newly enabled one-node
transfer improve the objective by another `6.1760190164`, to

```text
459.0072494478
```

The terminal pass exhaustively checked 114 feasible one-node transfers, 325
feasible exchanges, and 155 feasible adjacent-pair transfers without finding
an improvement. This was a local result for that starting point, not global
optimality.

A 1,800-second COPT 8.0.4 run on the stronger `nj2` formulation then found a
different integer assignment. The raw solver point reported `458.9242116973`,
but is deliberately **not** used as strict evidence: an independent zero-
tolerance check found nine row residuals up to `2.77e-11` and one integrality
residual of `1.1e-16`. The audited extractor rounds only that one assignment
entry within an explicit `1e-9` tolerance. Deterministic exact reconstruction
removes a redundant boundary variable `C16597` of cost `0.0056995457`, giving
the strict assignment objective `458.9185121516`.

Starting from this assignment, exact one-node descent applies one move to reach
`458.5271075712`. The joint one/two-node procedure then applies three exchanges
and four one-node transfers, reaching

```text
438.5907110388
```

The terminal pass checks 127 feasible one-node transfers, 375 exchanges, and
173 adjacent-pair transfers with no improvement. A second deterministic replay
produces byte-identical assignment hashes. Relative to the first 529.9611973238
construction, the total exact improvement is `91.3704862850` (17.24098%). This
is still only local optimality in the stated neighborhood union.

## Larger connected-neighborhood search: 403 stage

[`experiments/connected_large_neighborhood.py`](experiments/connected_large_neighborhood.py)
adds three compound move classes not present above: transfer of a connected
three-node set, exchange of a connected two-node set for one node, and a
one-node cycle among three districts. Every candidate is evaluated with exact
integer populations, explicit connectivity of every affected district, and an
exact `Decimal` boundary delta.

Direct steepest moves first reach `434.5476868456`. To leave strict local
minima, [`experiments/compound_kick_descent.py`](experiments/compound_kick_descent.py)
deterministically tries feasible compound moves even when their immediate delta
is positive, and fully descends each resulting assignment in the audited
one/two-node neighborhood. Progressively wider batches, followed by complete
batches once the search approached its final basin, gave these exact milestones:

```text
438.5907110388  434.5476868456  430.9422863344  429.1694453236
422.6463512340  417.7831477394  410.5559967264  407.6920114592
405.5876227044  404.4264706542  403.4107959378
```

The self-contained
[`analysis/large-neighborhood-chain-403.4107959378.json`](analysis/large-neighborhood-chain-403.4107959378.json)
records all 46 accepted exact steps, including the deliberately worsening kicks.
Two complete replays produced the same byte-level SHA-256. The independent
[`experiments/verify_large_neighborhood_chain.py`](experiments/verify_large_neighborhood_chain.py)
checks every old label, new label, population, connectivity condition, objective
delta, and final assignment directly from that compact certificate.

At `403.4107959378`, the final large scan generated 9,123 unique compound
candidates and admitted 2,322 as exactly feasible: 290 connected-triple
transfers, 1,272 two-for-one exchanges, and 760 three-district cycles. The best
direct delta was positive (`+0.3535736730`). All 2,322 feasible kicks were then
fully descended; 2,130 returned to the same objective, 192 ended worse, and none
improved it. The compressed scan and per-candidate outcomes are linked above.
This is an exhaustive terminal result only for the stated compound-kick-plus-
descent procedure; it is not global or unrestricted local optimality.

Relative to `438.5907110388`, the exact improvement is `35.1799151010`.
Relative to the first `529.9611973238` construction it is `126.5504013860`
(23.87918%).

This `403.4107959378` result is retained as a fully reproducible historical
stage. It was subsequently improved by the searches below.

## District-pair recombination and compound continuation

[`../nj3/experiments/district_pair_recombination.py`](../nj3/experiments/district_pair_recombination.py)
repartitions the union of each adjacent district pair. For every pair it builds
deterministically seeded randomized Kruskal spanning trees and evaluates every
tree edge whose removal gives two population-feasible components. Connectivity
is guaranteed by the tree cut, while the full boundary objective is recomputed
with `Decimal`. The
[`archived starting file`](../nj3/analysis/large-neighborhood-relabelled-assignment-403.4107959378.json)
is an objective-preserving district-label permutation of the 403 chain that
places node 0 in district 0 for the nj3-compatible anchor. Starting from
`403.4107959378`, 11 accepted pair
repartitions reach the intermediate strict incumbent

```text
383.6229250390
```

an exact improvement of `19.7878708988`. The complete sequence is in
[`../nj3/analysis/district-pair-recombination-from403.json`](../nj3/analysis/district-pair-recombination-from403.json).
Its terminal round built 4,200 trees across 21 adjacent district pairs and found
no improving cut among 3,710 population-feasible tree cuts. Independent complete
one-node and joint one/two-node scans also found no improvement, and two further
seeds built 42,000 pair trees without improvement. These are method-specific
local results, not an optimality proof.

The three compound move classes were then enumerated from `383.6229250390`.
Among 1,821 exactly feasible kicks, 165 led to a strict improvement after full
one/two-node descent. The best retained path deliberately begins with the
worsening connected-triple transfer of nodes `[195, 266, 422]` from district 8
to district 7, raising the objective by `6.0170098638` to `389.6399349028`.
Six exact descent moves then reach the current strict incumbent

```text
382.0606208032
```

The full per-candidate trace is compressed in
[`analysis/compound-kick-from383-382.0606208032.full.json.gz`](analysis/compound-kick-from383-382.0606208032.full.json.gz),
and its compact summary retains the complete best path and final 595 labels in
[`analysis/compound-kick-from383-382.0606208032.compact.json.gz`](analysis/compound-kick-from383-382.0606208032.compact.json.gz).

At `382.0606208032`, a new exact large scan generated 9,049 unique candidates
and admitted 2,133 as feasible: 264 connected-triple transfers, 1,055 connected
two-for-one exchanges, and 814 three-district cycles. The best direct delta was
positive (`+0.7695066230`). All 2,133 feasible kicks were fully descended;
1,950 returned to the same objective, 183 ended worse, and none improved it.
Three additional seeded district-pair scans built 231,000 trees in total and
also found no improving tree cut. The full and compact terminal evidence is
archived under [`analysis/`](analysis/), with every hash and count consolidated
in
[`analysis/continuation-403-to-382.0606208032-archive.json`](analysis/continuation-403-to-382.0606208032-archive.json).

A stronger exact pair audit uses
[`../nj3/experiments/exact_district_pair_copt.py`](../nj3/experiments/exact_district_pair_copt.py)
to optimize an arbitrary repartition of each current adjacent district pair's
entire induced node union. The MILP has exact integer-scaled cut weights and
population arithmetic; a finite rooted connectivity-cut loop enforces both
districts' connectedness. COPT 8 computationally closed all 21 of 21 adjacent
pairs and reported the incumbent pair cut optimal, with objective delta zero,
no timeout, and no unproved pair. The complete batch manifest and individual
solver evidence are in
[`../nj3/analysis/exact-pair-copt8-from382/`](../nj3/analysis/exact-pair-copt8-from382/).
This is a solver-backed computational certificate of local optimality for
changing any one complete adjacent district pair while all other districts
remain fixed; it is not a separately formalized proof checker. It is also not a
full-MIP lower bound and does not prove global optimality or cover simultaneous
changes to three or more districts. The compound-kick statement likewise
remains exhaustive only for its explicitly enumerated move-and-descent procedure.

The next anchored neighborhood enumerates all 39 connected triples in the
current district-adjacency graph. For each triple, it fixes the current
minimum-index node of every district as that district's anchor, then optimizes
all remaining labels in the three-district union with exact integer-scaled cut
weights and population arithmetic. COPT 8 computationally closed 39 of 39
models with zero objective delta, no timeout, and no unproved case; in every
case the current connected partition already attained the optimum of the
weaker model without connectivity constraints. See
[`../nj3/analysis/exact-triple-copt8-from382/`](../nj3/analysis/exact-triple-copt8-from382/).
This is an anchor-fixed, solver-backed local result without a portable MILP
proof trace. It does not cover a three-way repartition that moves two current
anchors into the same new district and is not a full-instance lower bound.

The same anchored formulation was then expanded to every one of the 67
connected four-district subsets in the current district-adjacency graph.
COPT 8 closed all 67 models with exact full-objective delta zero; one case
needed a 600-second retry after the initial 120-second batch limit. Complete
results and hashes are in
[`../nj3/analysis/exact-quad-copt8-from382/`](../nj3/analysis/exact-quad-copt8-from382/).
This remains an anchor-fixed local result: repartitions that merge two current
anchors are outside the formulation, and no full-instance lower bound follows.

A separate 1,800-second, 16-thread COPT 8.0.4 run warm-started the full `nj1`
MPS from `382.0606208032`. It stopped at the time limit without improving the
incumbent, after 63 nodes and with numerical best bound
`74.54284297688875`. The result and raw solver log are in the shared
[`full-model archive`](../nj3/analysis/copt8-full-model-from382/); this floating-point
bound is not promoted to a strict lower-bound certificate.

Relative to `438.5907110388`, the current exact improvement is `56.5300902356`.
Relative to the first `529.9611973238` construction it is `147.9005765206`
(27.90781%).

[`experiments/build_and_check_nj_solution.py`](experiments/build_and_check_nj_solution.py)
then lifts the 595 labels back to every original variable. It sets weighted
boundary variables exactly, chooses a root, and routes integer population flow
on a BFS tree inside every district. It evaluates every original row using
`Decimal`; the independent repository checker parses the MPS again separately.

The exploratory alternatives are retained as reproducible code:

- [`experiments/connected_partition_cpsat.py`](experiments/connected_partition_cpsat.py):
  compact assignment/cut-edge CP-SAT with separated connectivity cuts;
- [`experiments/connected_partition_flow_cpsat.py`](experiments/connected_partition_flow_cpsat.py):
  exact compact single-commodity-flow CP-SAT;
- [`experiments/connected_region_grow.py`](experiments/connected_region_grow.py):
  simultaneous region-growing baseline;
- [`experiments/copt8_warmstart.py`](experiments/copt8_warmstart.py): original-MPS
  COPT 8 warm-start probe;
- [`experiments/replay_large_neighborhood_chain.py`](experiments/replay_large_neighborhood_chain.py):
  the consolidation utility used on the remote run to create the self-contained
  chain certificate. Its archived manifest records remote-only provenance; the
  large intermediate stage files are intentionally not duplicated here;
- [`experiments/compact_terminal_kick_result.py`](experiments/compact_terminal_kick_result.py):
  deterministic compaction of all terminal outcomes without retaining 2,322
  duplicate 595-label arrays.

The archived 300-second COPT 8.0.4 probe accepted the earlier 537.8616230246
solution as a complete MIP start but did not improve it. It terminated at the
time limit after 31 nodes with numerical best bound `64.30681498346442`; this
large numerical gap is not an exact lower-bound certificate. See
[`analysis/copt8-warmstart-300s-result.json`](analysis/copt8-warmstart-300s-result.json)
and [`logs/copt8-warmstart-300s.log`](logs/copt8-warmstart-300s.log). A later
1,800-second `nj1` run warm-started at 459.0072494478 also found no improvement;
it ended after 191 nodes with numerical bound `74.68784326515015`. Its
[result](analysis/copt8-warmstart-1800s-result.json),
[raw solution](solutions/copt8-warmstart-1800s.raw.sol), and
[complete log](logs/copt8-warmstart-1800s.log) are archived. Neither numerical
bound is promoted to a strict lower bound.

## Single-district decomposition prototype

Earlier structural work extracted one exact district oracle by projecting away
the 595 assignment master rows. The resulting
[`experiments/district1-oracle.mps.gz`](experiments/district1-oracle.mps.gz)
has 8,082 rows and 6,507 columns. COPT 8.0.4 reported objective/bound
`8.2139470317` at relative-gap limit `1e-4` in 53.76 seconds; this is a
subproblem result, not a full-instance bound. See
[`experiments/district1-oracle-copt-result.json`](experiments/district1-oracle-copt-result.json).

## Background and provenance

- MIPLIB instance page and original decomposition:
  <https://miplib.zib.de/instance_details_nj1.html> and
  <https://miplib.zib.de/WebData/decomps_orig/nj1.dec>.
- Validi and Buchanan, *Political districting to minimize cut edges*,
  Mathematical Programming Computation 14 (2022), 623--672,
  <https://doi.org/10.1007/s12532-022-00221-5>. The paper explicitly identifies
  `nj1`, `nj2`, and `nj3` as unresolved MIPLIB districting instances, discusses
  labeling/flow/cut formulations, symmetry, and weak LP bounds, and points to
  the authors' code at
  <https://github.com/hamidrezavalidi/Political-Districting-to-Minimize-Cut-Edges>.

Exact input hashes are in [`input/SHA256SUMS`](input/SHA256SUMS). The archived
`nj1.mps.gz` SHA-256 is
`72ae4e301408a5e9ffe3f96c18f2b37b4243a74dfdaee1480c13997fd01a6166`.

## Reproduce

From the repository root, the exact replay, neighborhood, reconstruction and
validation scripts below use the Python standard library. The separate CP-SAT
alternatives listed above require OR-Tools.

```bash
python instances/nj1/experiments/gurobi13_structure.py \
  instances/nj1/input/nj1.mps.gz \
  instances/nj1/analysis/nj1-gurobi13-structure.json

python instances/nj2/experiments/extract_copt_assignment.py \
  instances/nj2/solutions/copt8-warmstart-1800s.raw.sol \
  instances/nj2/analysis/copt8-warmstart-1800s-assignment.json

python instances/nj1/experiments/connected_boundary_steepest_descent.py \
  instances/nj1/input/nj1.mps.gz \
  instances/nj2/analysis/copt8-warmstart-1800s-assignment.json \
  instances/nj2/analysis/copt8-post-one-node-assignment.json

python instances/nj1/experiments/connected_two_node_steepest_descent.py \
  instances/nj1/input/nj1.mps.gz \
  instances/nj2/analysis/copt8-post-one-node-assignment.json \
  instances/nj2/analysis/copt8-post-two-node-assignment.json

python instances/nj1/experiments/verify_large_neighborhood_chain.py \
  instances/nj1/input/nj1.mps.gz \
  instances/nj2/analysis/copt8-post-two-node-assignment.json \
  instances/nj1/analysis/large-neighborhood-chain-403.4107959378.json

# Reproduce the 403 -> 383 district-pair stage.
python instances/nj3/experiments/district_pair_recombination.py \
  instances/nj1/input/nj1.mps.gz \
  instances/nj3/analysis/large-neighborhood-relabelled-assignment-403.4107959378.json \
  /tmp/nj-pair-383.json \
  --restarts-per-pair 200 --max-iterations 20 --seed 20260908

# Reproduce the 383 -> 382 compound-kick continuation.
python instances/nj1/experiments/connected_large_neighborhood.py \
  instances/nj1/input/nj1.mps.gz \
  /tmp/nj-pair-383.json /tmp/nj-large-383.json \
  --top-candidates 5000

python instances/nj1/experiments/compound_kick_descent.py \
  instances/nj1/input/nj1.mps.gz \
  /tmp/nj-pair-383.json /tmp/nj-large-383.json /tmp/nj-kicks-383.json \
  --workers 64 --candidate-limit 5000

python instances/nj1/experiments/build_and_check_nj_solution.py \
  instances/nj1/input/nj1.mps.gz \
  instances/nj1/analysis/final-assignment-382.0606208032.json \
  instances/nj1/solutions/compound-kick-382.0606208032.sol \
  instances/nj1/analysis/compound-kick-382.0606208032-validation.json

python common/exact_mps_solution_check.py \
  instances/nj1/input/nj1.mps.gz \
  instances/nj1/solutions/compound-kick-382.0606208032.sol \
  --tolerance 0

# Re-run one exact adjacent-pair MILP; the manifest lists all 21 pairs.
python instances/nj3/experiments/exact_district_pair_copt.py \
  instances/nj1/input/nj1.mps.gz \
  instances/nj1/analysis/final-assignment-382.0606208032.json \
  /tmp/nj-exact-pair-0-5.json --pair 0 5 \
  --time-limit 60 --threads 1 --log /tmp/nj-exact-pair-0-5.log

# Recompute the exhaustive 382 terminal neighborhood into disposable files.
python instances/nj1/experiments/connected_large_neighborhood.py \
  instances/nj1/input/nj1.mps.gz \
  instances/nj1/analysis/final-assignment-382.0606208032.json \
  /tmp/nj-terminal-large.json --top-candidates 5000

python instances/nj1/experiments/compound_kick_descent.py \
  instances/nj1/input/nj1.mps.gz \
  instances/nj1/analysis/final-assignment-382.0606208032.json \
  /tmp/nj-terminal-large.json /tmp/nj-terminal-kicks.json \
  --workers 64 --candidate-limit 5000

python instances/nj1/experiments/compact_terminal_kick_result.py \
  /tmp/nj-terminal-kicks.json /tmp/nj-terminal-kicks.compact.json
```
