#!/usr/bin/env python3
"""Recover and audit the 12-district block structure in nj1/nj2.

The official MPS files anonymize every row and column.  The arithmetic layout
still exposes a strict Dantzig--Wolfe decomposition: 12 district blocks plus a
small set of linking equations.  This script verifies that claim from the
original matrix and the official MIPLIB .dec file, and emits a compact JSON
description suitable for designing a block/configuration algorithm.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import re
from collections import Counter, OrderedDict, defaultdict
from decimal import Decimal, getcontext
from pathlib import Path


getcontext().prec = 80
NAME_NUMBER = re.compile(r"^[RC](\d+)$")


def number(text: str) -> Decimal:
    return Decimal(text.replace("D", "E").replace("d", "e"))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_mps(path: Path) -> dict:
    rows: OrderedDict[str, dict] = OrderedDict()
    variables: OrderedDict[str, dict] = OrderedDict()
    rhs: dict[str, Decimal] = defaultdict(Decimal)
    section = ""
    integer_mode = False
    with gzip.open(path, "rt", encoding="latin-1") as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if not raw[0].isspace() and tokens[0] in {
                "NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"
            }:
                section = tokens[0]
                continue
            if section == "ROWS":
                rows[tokens[1]] = {"sense": tokens[0], "terms": []}
            elif section == "COLUMNS":
                if "'MARKER'" in tokens:
                    integer_mode = "'INTORG'" in tokens
                    continue
                variable = tokens[0]
                info = variables.setdefault(variable, {
                    "integer": integer_mode,
                    "lower": Decimal(0),
                    "upper": None,
                    "rows": [],
                })
                info["integer"] = info["integer"] or integer_mode
                for row, value_text in zip(tokens[1::2], tokens[2::2]):
                    value = number(value_text)
                    rows[row]["terms"].append((variable, value))
                    info["rows"].append((row, value))
            elif section == "RHS":
                for row, value in zip(tokens[1::2], tokens[2::2]):
                    rhs[row] += number(value)
            elif section == "BOUNDS":
                kind, variable = tokens[0], tokens[2]
                value = number(tokens[3]) if len(tokens) > 3 else Decimal(0)
                info = variables[variable]
                if kind == "UP":
                    info["upper"] = value
                elif kind == "LO":
                    info["lower"] = value
                elif kind == "FX":
                    info["lower"] = info["upper"] = value
                elif kind == "FR":
                    info["lower"], info["upper"] = Decimal("-Infinity"), None
                elif kind == "MI":
                    info["lower"] = Decimal("-Infinity")
                elif kind == "PL":
                    info["upper"] = None
                elif kind == "BV":
                    info["lower"], info["upper"], info["integer"] = Decimal(0), Decimal(1), True
                elif kind == "LI":
                    info["lower"], info["integer"] = value, True
                elif kind == "UI":
                    info["upper"], info["integer"] = value, True
                else:
                    raise ValueError(f"unsupported bound kind {kind}")
    return {"rows": rows, "variables": variables, "rhs": rhs}


def parse_dec(path: Path) -> tuple[dict[str, int], list[str]]:
    block_of_row: dict[str, int] = {}
    master: list[str] = []
    state = ""
    block = None
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    index = 0
    while index < len(lines):
        token = lines[index].strip()
        if token == "BLOCK" or token.startswith("BLOCK "):
            parts = token.split()
            block = int(parts[1]) if len(parts) > 1 else int(lines[index + 1].strip())
            state = "block"
            index += 1 if len(parts) > 1 else 2
            continue
        if token == "MASTERCONSS":
            state = "master"
            block = None
            index += 1
            continue
        if token.startswith("R"):
            if state == "block":
                if token in block_of_row:
                    raise ValueError(f"row {token} appears in multiple blocks")
                block_of_row[token] = int(block)
            elif state == "master":
                master.append(token)
        index += 1
    return block_of_row, master


def numeric_suffix(name: str) -> int:
    match = NAME_NUMBER.match(name)
    if not match:
        raise ValueError(f"unexpected anonymous MPS name {name}")
    return int(match.group(1))


def row_summary(row: str, model: dict) -> dict:
    info = model["rows"][row]
    integer_count = sum(model["variables"][var]["integer"] for var, _ in info["terms"])
    coefficients = Counter(str(value) for _, value in info["terms"])
    return {
        "row": row,
        "sense": info["sense"],
        "rhs": str(model["rhs"].get(row, Decimal(0))),
        "nonzeros": len(info["terms"]),
        "integer_terms": integer_count,
        "continuous_terms": len(info["terms"]) - integer_count,
        "coefficient_histogram": dict(sorted(coefficients.items())),
        "columns": [var for var, _ in info["terms"][:24]],
        "columns_truncated": len(info["terms"]) > 24,
    }


def coarse_row_signature(row: str, model: dict) -> tuple:
    info = model["rows"][row]
    integer_count = sum(model["variables"][var]["integer"] for var, _ in info["terms"])
    signs = Counter("positive" if value > 0 else "negative" if value < 0 else "zero"
                    for _, value in info["terms"])
    return (
        info["sense"],
        str(model["rhs"].get(row, Decimal(0))),
        len(info["terms"]),
        integer_count,
        tuple(sorted(signs.items())),
    )


def contiguous_ranges(numbers: list[int]) -> list[list[int]]:
    if not numbers:
        return []
    answer = [[numbers[0], numbers[0]]]
    for value in numbers[1:]:
        if value == answer[-1][1] + 1:
            answer[-1][1] = value
        else:
            answer.append([value, value])
    return answer


def analyze(mps: Path, dec_path: Path) -> dict:
    model = parse_mps(mps)
    block_of_row, master_rows = parse_dec(dec_path)
    rows = model["rows"]
    variables = model["variables"]
    objective_rows = [row for row, info in rows.items() if info["sense"] == "N"]
    algebraic_rows = [row for row in rows if row not in objective_rows]
    block_ids = sorted(set(block_of_row.values()))

    dec_partition_exact = (
        set(block_of_row).isdisjoint(master_rows)
        and set(block_of_row) | set(master_rows) == set(algebraic_rows)
    )
    variable_block: dict[str, int | None] = {}
    cross_block_variables: dict[str, list[int]] = {}
    for variable, info in variables.items():
        touched = sorted({block_of_row[row] for row, _ in info["rows"] if row in block_of_row})
        if len(touched) == 1:
            variable_block[variable] = touched[0]
        elif not touched:
            variable_block[variable] = None
        else:
            cross_block_variables[variable] = touched
            variable_block[variable] = None

    block_stats = []
    for block in block_ids:
        block_rows = [row for row, value in block_of_row.items() if value == block]
        block_vars = [var for var, value in variable_block.items() if value == block]
        block_stats.append({
            "block": block,
            "rows": len(block_rows),
            "variables": len(block_vars),
            "binary_variables": sum(
                variables[var]["integer"] and variables[var]["lower"] == 0 and variables[var]["upper"] == 1
                for var in block_vars
            ),
            "other_integer_variables": sum(
                variables[var]["integer"] and not (
                    variables[var]["lower"] == 0 and variables[var]["upper"] == 1
                ) for var in block_vars
            ),
            "continuous_variables": sum(not variables[var]["integer"] for var in block_vars),
        })

    interleaving_failures = []
    for variable, block in variable_block.items():
        if block is None:
            continue
        expected = (numeric_suffix(variable) - 1) % len(block_ids) + 1
        if block != expected:
            interleaving_failures.append({"variable": variable, "block": block, "expected": expected})

    master_summaries = [row_summary(row, model) for row in master_rows]
    master_signatures = Counter(
        (item["sense"], item["rhs"], item["nonzeros"], item["integer_terms"], item["continuous_terms"])
        for item in master_summaries
    )
    master_groups = []
    by_signature: dict[tuple, list[int]] = defaultdict(list)
    for item in master_summaries:
        signature = (
            item["sense"], item["rhs"], item["nonzeros"],
            item["integer_terms"], item["continuous_terms"],
        )
        by_signature[signature].append(numeric_suffix(item["row"]))
    for signature, numbers in sorted(by_signature.items(), key=lambda pair: min(pair[1])):
        master_groups.append({
            "sense": signature[0],
            "rhs": signature[1],
            "nonzeros": signature[2],
            "integer_terms": signature[3],
            "continuous_terms": signature[4],
            "row_ranges": contiguous_ranges(sorted(numbers)),
            "count": len(numbers),
        })

    local_signature_histogram = Counter()
    for row in block_of_row:
        local_signature_histogram[coarse_row_signature(row, model)] += 1
    local_families = [
        {
            "sense": signature[0],
            "rhs": signature[1],
            "nonzeros": signature[2],
            "integer_terms": signature[3],
            "sign_histogram": dict(signature[4]),
            "rows_total": count,
            "rows_per_district": count // len(block_ids),
        }
        for signature, count in local_signature_histogram.most_common()
    ]

    assignment_rows = [
        item for item in master_summaries
        if item["sense"] == "E" and item["rhs"] == "1"
        and item["nonzeros"] == len(block_ids)
        and item["integer_terms"] == len(block_ids)
    ]
    district_total_rows = [
        item for item in master_summaries
        if item["sense"] == "E" and item["nonzeros"] == 595
        and item["integer_terms"] == 595
    ]
    assignment_columns = sorted({column for item in assignment_rows for column in item["columns"]}, key=numeric_suffix)

    # The anonymous numbering itself is a useful certificate.  These band
    # boundaries follow from 595 units, 1,574 undirected adjacencies, 3,148
    # directed arcs, and 12 districts; assert them against the parsed model.
    expected_bands = [
        (1, 595, "master: each geographic unit assigned to one district"),
        (596, 19483, "district: first |x_i-x_j| boundary inequality (inferred)"),
        (19484, 38371, "district: second |x_i-x_j| boundary inequality (inferred)"),
        (38372, 38383, "master: choose one connectivity root per district"),
        (38384, 45523, "district: root-source lower link (inferred)"),
        (45524, 52663, "district: root-source upper link (inferred)"),
        (52664, 71551, "district: first directed-flow gate (inferred)"),
        (71552, 90439, "district: second directed-flow gate (inferred)"),
        (90440, 97579, "district: node flow balance (inferred)"),
    ]
    if len(algebraic_rows) == 118975:
        expected_bands.extend([
            (97580, 104707, "nj2 symmetry: x_i <= q_(i+1)"),
            (104708, 111835, "nj2 symmetry: q_i <= q_(i+1)"),
            (111836, 118975, "nj2 symmetry: q_i + root_i <= 1"),
        ])
    row_bands = []
    for first, last, interpretation in expected_bands:
        names = [f"R{index:04d}" for index in range(first, last + 1)]
        present = all(name in rows for name in names)
        row_bands.append({
            "row_range": [names[0], names[-1]],
            "count": last - first + 1,
            "all_rows_present": present,
            "interpretation": interpretation,
            "first_row": row_summary(names[0], model) if present else None,
        })

    # Collapse the period-12 column order into logical variable layers.  A
    # layer contains the same geography/arc variable for all 12 districts.
    column_names = list(variables)
    layer_records = []
    for start in range(0, len(column_names), len(block_ids)):
        columns = column_names[start:start + len(block_ids)]
        signatures = []
        for column in columns:
            info = variables[column]
            local_rows = [row for row, _ in info["rows"] if row in block_of_row]
            masters = [row for row, _ in info["rows"] if row in master_rows]
            objective = [value for row, value in info["rows"] if row in objective_rows]
            master_kind = "none"
            if masters:
                master_kind = "assignment" if numeric_suffix(masters[0]) <= 595 else "district-root-total"
            if info["integer"]:
                # Assignment incidence depends on geographic degree.  Exclude
                # that accidental degree from the family signature.
                signatures.append((
                    True, str(info["lower"]),
                    None if info["upper"] is None else str(info["upper"]),
                    master_kind, bool(objective),
                ))
            else:
                signatures.append((
                    False, str(info["lower"]),
                    None if info["upper"] is None else str(info["upper"]),
                    master_kind, bool(objective), len(local_rows),
                    tuple(sorted(Counter(rows[row]["sense"] for row in local_rows).items())),
                ))
        if len(set(signatures)) != 1:
            layer_signature = ("nonuniform",)
        else:
            layer_signature = signatures[0]
        layer_records.append({
            "layer": start // len(block_ids) + 1,
            "columns": [columns[0], columns[-1]],
            "signature": layer_signature,
        })
    layer_runs = []
    for layer in layer_records:
        if layer_runs and layer_runs[-1]["signature"] == layer["signature"]:
            layer_runs[-1]["layer_range"][1] = layer["layer"]
            layer_runs[-1]["column_range"][1] = layer["columns"][1]
            layer_runs[-1]["layer_count"] += 1
        else:
            signature = layer["signature"]
            if signature == ("nonuniform",):
                detail = {"raw_signature": list(signature)}
            elif signature[0]:
                detail = {
                    "integer": True,
                    "lower": signature[1],
                    "upper": signature[2],
                    "master_role": signature[3],
                    "has_objective_coefficient": signature[4],
                }
            else:
                detail = {
                    "integer": False,
                    "lower": signature[1],
                    "upper": signature[2],
                    "master_role": signature[3],
                    "has_objective_coefficient": signature[4],
                    "local_row_count_per_column": signature[5],
                    "local_row_sense_histogram": dict(signature[6]),
                }
            layer_runs.append({
                "layer_range": [layer["layer"], layer["layer"]],
                "column_range": list(layer["columns"]),
                "layer_count": 1,
                "signature": layer["signature"],
                "detail": detail,
            })
    for run in layer_runs:
        del run["signature"]

    return {
        "evidence_level": "exact matrix/decomposition audit; semantic labels are stated separately as inferences",
        "input": {
            "mps": str(mps.as_posix()),
            "mps_sha256": sha256(mps),
            "dec": str(dec_path.as_posix()),
            "dec_sha256": sha256(dec_path),
        },
        "dimensions": {
            "algebraic_rows": len(algebraic_rows),
            "objective_rows": objective_rows,
            "variables": len(variables),
            "integer_variables": sum(info["integer"] for info in variables.values()),
            "continuous_variables": sum(not info["integer"] for info in variables.values()),
        },
        "decomposition": {
            "block_count": len(block_ids),
            "master_row_count": len(master_rows),
            "block_row_count": len(block_of_row),
            "dec_is_exact_row_partition": dec_partition_exact,
            "cross_block_variable_count": len(cross_block_variables),
            "variables_without_a_block_count": sum(value is None for value in variable_block.values()),
            "district_interleaving_rule": "block(C_k) = 1 + ((k-1) mod 12)",
            "interleaving_failure_count": len(interleaving_failures),
            "block_statistics": block_stats,
        },
        "master_structure": {
            "signature_counts": [
                {
                    "sense": signature[0], "rhs": signature[1], "nonzeros": signature[2],
                    "integer_terms": signature[3], "continuous_terms": signature[4], "count": count,
                }
                for signature, count in master_signatures.items()
            ],
            "groups": master_groups,
            "assignment_equations_detected": len(assignment_rows),
            "district_total_equations_detected": len(district_total_rows),
            "representative_rows": [
                row_summary(master_rows[index], model)
                for index in sorted({0, min(594, len(master_rows) - 1), max(0, len(master_rows) - 12), len(master_rows) - 1})
            ],
        },
        "row_bands": row_bands,
        "variable_layer_runs": layer_runs,
        "local_row_signature_histogram": local_families,
        "semantic_reconstruction": {
            "known_from_official_metadata": "electoral district design with symmetry-breaking variants",
            "exactly_supported": [
                "12 variable-disjoint district blocks after removing master rows",
                "595 master assignment equations, each containing one binary from every district",
                "12 district-total equations, each containing 595 binaries from one district",
                "all columns are interleaved in district order with period 12",
            ],
            "inferred": [
                "the 595 repeated assignment equations correspond to 595 geographic units",
                "the 12 blocks correspond to the 12 electoral districts",
                "mixed binary/continuous local rows encode district feasibility and connectivity/flow",
            ],
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("dec", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    result = analyze(args.mps, args.dec)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({
        "blocks": result["decomposition"]["block_count"],
        "master_rows": result["decomposition"]["master_row_count"],
        "cross_block_variables": result["decomposition"]["cross_block_variable_count"],
        "assignment_equations": result["master_structure"]["assignment_equations_detected"],
        "district_total_equations": result["master_structure"]["district_total_equations_detected"],
        "interleaving_failures": result["decomposition"]["interleaving_failure_count"],
    }, indent=2))


if __name__ == "__main__":
    main()
