#!/usr/bin/env python3
"""Compact a full compound-kick result while retaining every terminal outcome."""

from __future__ import annotations

import argparse
import hashlib
import json
from decimal import Decimal
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def assignment_sha256(labels: list[int]) -> str:
    encoded = json.dumps(list(map(int, labels)), separators=(",", ":")).encode("ascii")
    return hashlib.sha256(encoded).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("full_result", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    source = json.loads(args.full_result.read_text(encoding="utf-8"))
    assert source["schema"] == "nj-compound-kick-small-descent-v1"
    base = Decimal(source["base_objective"])
    results = source["results"]
    assert len(results) == int(source["candidate_count"])
    assert {int(result["candidate_index"]) for result in results} == set(range(len(results)))

    outcomes = []
    for result in sorted(results, key=lambda item: int(item["candidate_index"])):
        final = Decimal(result["final_objective"])
        kick = result["kick"]
        outcomes.append({
            "candidate_index": int(result["candidate_index"]),
            "kind": kick["kind"],
            "nodes_zero_based": list(map(int, kick["nodes_zero_based"])),
            "new_districts_zero_based": list(map(int, kick["new_districts_zero_based"])),
            "kick_delta": result["recomputed_kick_delta"],
            "descent_move_count": int(result["descent_move_count"]),
            "final_objective": str(final),
            "final_assignment_sha256": assignment_sha256(result["final_assignment"]),
        })

    final_values = [Decimal(outcome["final_objective"]) for outcome in outcomes]
    minimum = min(final_values)
    best_index = min(
        int(result["candidate_index"])
        for result in results if Decimal(result["final_objective"]) == minimum
    )
    best_result = next(
        result for result in results if int(result["candidate_index"]) == best_index
    )
    compact = {
        "schema": "nj-terminal-compound-kick-summary-v1",
        "full_result_sha256": sha256(args.full_result),
        "source_mps_sha256": source["source_mps_sha256"],
        "base_assignment_sha256": source["base_assignment_sha256"],
        "large_scan_sha256": source["large_scan_sha256"],
        "base_objective": str(base),
        "candidate_count": len(results),
        "minimum_final_objective": str(minimum),
        "strict_improvement_count": sum(value < base for value in final_values),
        "equal_objective_count": sum(value == base for value in final_values),
        "worse_objective_count": sum(value > base for value in final_values),
        "all_fully_descended_outcomes_at_least_base": all(value >= base for value in final_values),
        "best_candidate_index": best_index,
        # Retain the complete best path (kick, exact descent, and final labels)
        # while replacing all other repeated 595-label arrays by hashes.
        "best_result": best_result,
        "outcomes": outcomes,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(compact, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({key: value for key, value in compact.items() if key != "outcomes"}, indent=2))


if __name__ == "__main__":
    main()
