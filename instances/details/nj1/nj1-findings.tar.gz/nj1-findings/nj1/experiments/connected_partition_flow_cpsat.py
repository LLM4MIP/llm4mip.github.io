#!/usr/bin/env python3
"""Exact compact CP-SAT feasibility model for the nj district partitions.

One fixed farthest-point seed is used per district.  Integer single-commodity
flows send one unit from that seed to every other selected vertex, which proves
connectivity without the much larger population-flow layer of the original MPS.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import deque
from pathlib import Path

from ortools.sat.python import cp_model


THIS = Path(__file__).resolve()
sys.path.insert(0, str(THIS.parent))
from connected_partition_cpsat import (  # noqa: E402
    DISTRICTS,
    EDGES,
    LOWER_POPULATION,
    NODES,
    UPPER_POPULATION,
    components,
    extract_graph,
    farthest_seeds,
)
from nj_block_forensics import sha256  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--time-limit", type=float, default=900.0)
    parser.add_argument("--workers", type=int, default=24)
    parser.add_argument("--seed", type=int, default=20260908)
    parser.add_argument("--farthest-seed-start", type=int, default=0)
    parser.add_argument("--cost-scale", type=int, default=1_000_000)
    parser.add_argument("--hint", type=Path)
    parser.add_argument("--hint-history-index", type=int, default=-1)
    parser.add_argument("--roots-from-hint-largest-components", action="store_true")
    parser.add_argument("--log-search-progress", action="store_true")
    args = parser.parse_args()

    populations, edges = extract_graph(args.mps)
    adjacency = [[] for _ in range(NODES)]
    directed_edges = []
    incoming = [[] for _ in range(NODES)]
    outgoing = [[] for _ in range(NODES)]
    for edge, (left, right, _) in enumerate(edges):
        adjacency[left].append(right)
        adjacency[right].append(left)
        forward = len(directed_edges)
        directed_edges.append((left, right, edge))
        outgoing[left].append(forward)
        incoming[right].append(forward)
        reverse = len(directed_edges)
        directed_edges.append((right, left, edge))
        outgoing[right].append(reverse)
        incoming[left].append(reverse)
    assignment_hint = None
    if args.hint:
        hint = json.loads(args.hint.read_text(encoding="utf-8"))
        if "assignment_zero_based_district" in hint:
            assignment_hint = hint["assignment_zero_based_district"]
        else:
            assignment_hint = hint["history"][args.hint_history_index]["assignment_zero_based_district"]
    if args.roots_from_hint_largest_components:
        if assignment_hint is None:
            raise ValueError("--roots-from-hint-largest-components requires --hint")
        fixed_roots = [min(components(assignment_hint, district, adjacency)[0])
                       for district in range(DISTRICTS)]
    else:
        fixed_roots = farthest_seeds(adjacency, args.farthest_seed_start)

    model = cp_model.CpModel()
    x = [[model.new_bool_var(f"x_{node}_{district}") for district in range(DISTRICTS)]
         for node in range(NODES)]
    cut_edge = [model.new_bool_var(f"cut_{edge}") for edge in range(EDGES)]
    flow = [[model.new_int_var(0, NODES - 1, f"f_{arc}_{district}")
             for district in range(DISTRICTS)] for arc in range(len(directed_edges))]

    for node in range(NODES):
        model.add_exactly_one(x[node])
    for district in range(DISTRICTS):
        root = fixed_roots[district]
        model.add(x[root][district] == 1)
        district_size_except_root = sum(x[node][district] for node in range(NODES) if node != root)
        model.add(sum(populations[node] * x[node][district] for node in range(NODES))
                  >= LOWER_POPULATION)
        model.add(sum(populations[node] * x[node][district] for node in range(NODES))
                  <= UPPER_POPULATION)
        for node in range(NODES):
            inflow = sum(flow[arc][district] for arc in incoming[node])
            outflow = sum(flow[arc][district] for arc in outgoing[node])
            if node == root:
                model.add(outflow - inflow == district_size_except_root)
            else:
                model.add(inflow - outflow == x[node][district])
        for arc, (tail, head, _) in enumerate(directed_edges):
            model.add(flow[arc][district] <= (NODES - 1) * x[tail][district])
            model.add(flow[arc][district] <= (NODES - 1) * x[head][district])

    for edge, (left, right, _) in enumerate(edges):
        for district in range(DISTRICTS):
            model.add(cut_edge[edge] >= x[left][district] - x[right][district])
            model.add(cut_edge[edge] >= x[right][district] - x[left][district])
    scaled_costs = [max(1, int((cost * args.cost_scale).to_integral_value()))
                    for _, _, cost in edges]
    model.minimize(sum(scaled_costs[edge] * cut_edge[edge] for edge in range(EDGES)))

    if assignment_hint is not None:
        for node, label in enumerate(assignment_hint):
            for district in range(DISTRICTS):
                model.add_hint(x[node][district], int(label == district))
        for edge, (left, right, _) in enumerate(edges):
            model.add_hint(cut_edge[edge], int(assignment_hint[left] != assignment_hint[right]))

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = args.time_limit
    solver.parameters.num_search_workers = args.workers
    solver.parameters.random_seed = args.seed
    solver.parameters.log_search_progress = args.log_search_progress
    status = solver.solve(model)
    summary = {
        "status": solver.status_name(status),
        "wall_time": solver.wall_time,
        "best_bound_scaled": solver.best_objective_bound,
        "objective_scaled": solver.objective_value if status in (cp_model.FEASIBLE, cp_model.OPTIMAL) else None,
        "fixed_roots_zero_based": fixed_roots,
    }
    if status not in (cp_model.FEASIBLE, cp_model.OPTIMAL):
        print(json.dumps(summary, indent=2))
        raise SystemExit("no feasible connected partition found")

    assignment = [next(district for district in range(DISTRICTS)
                       if solver.boolean_value(x[node][district])) for node in range(NODES)]
    component_lists = [components(assignment, district, adjacency) for district in range(DISTRICTS)]
    if not all(len(items) == 1 for items in component_lists):
        raise RuntimeError(f"flow model returned disconnected assignment: {component_lists}")
    result = {
        "evidence_level": "CP-SAT single-commodity-flow certificate plus explicit graph-component check; requires original-MPS lift/check",
        "source_mps_sha256": sha256(args.mps),
        "solver": {
            "name": "OR-Tools CP-SAT",
            "status": solver.status_name(status),
            "wall_time": solver.wall_time,
            "workers": args.workers,
            "random_seed": args.seed,
            "cost_scale": args.cost_scale,
            "best_bound_scaled": solver.best_objective_bound,
            "objective_scaled": solver.objective_value,
        },
        "fixed_roots_zero_based": fixed_roots,
        "population_bounds": [LOWER_POPULATION, UPPER_POPULATION],
        "total_population": sum(populations),
        "assignment_zero_based_district": assignment,
        "district_populations": [sum(populations[node] for node in range(NODES)
                                     if assignment[node] == district)
                                 for district in range(DISTRICTS)],
        "district_component_sizes": [len(items[0]) for items in component_lists],
        "cut_edges": sum(assignment[left] != assignment[right] for left, right, _ in edges),
        "boundary_objective_original_units": str(sum(
            2 * cost for left, right, cost in edges if assignment[left] != assignment[right]
        )),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({**summary, "output": str(args.output),
                      "district_populations": result["district_populations"],
                      "district_component_sizes": result["district_component_sizes"]}, indent=2))


if __name__ == "__main__":
    main()
