#!/usr/bin/env python3
"""Deterministic exact large-neighborhood scan for the NJ districting instances.

This archived experimental driver reads the audited nj1 graph through the
existing helper modules and searches three compound move classes that are not
contained in the one/two-node descent:

* transfer a connected three-node set to one adjacent district;
* exchange a connected two-node set with one node of another district; and
* cyclically exchange one node among three distinct districts.

Every candidate is checked with integer populations, full connectivity of every
affected district, and an exact Decimal cut-objective delta.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from collections import Counter
from decimal import Decimal
from itertools import product
from pathlib import Path


HELPER_DIR = Path(os.environ.get("NJ_HELPER_DIR", Path(__file__).resolve().parent))
sys.path.insert(0, str(HELPER_DIR))

from connected_boundary_steepest_descent import (  # noqa: E402
    DISTRICTS,
    LOWER_POPULATION,
    NODES,
    UPPER_POPULATION,
    component,
    extract_graph,
    objective,
)
from nj_block_forensics import sha256  # noqa: E402


def connected(assignment: list[int], district: int,
              adjacency: list[list[int]]) -> bool:
    return len(component(assignment, district, adjacency)) == assignment.count(district)


def district_populations(assignment: list[int], populations: list[int]) -> list[int]:
    return [
        sum(populations[node] for node, label in enumerate(assignment) if label == district)
        for district in range(DISTRICTS)
    ]


def in_bounds(value: int) -> bool:
    return LOWER_POPULATION <= value <= UPPER_POPULATION


def canonical_changes(changes: dict[int, int]) -> tuple[tuple[int, int], ...]:
    return tuple(sorted(changes.items()))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("initial_assignment", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--max-large-moves", type=int, default=100)
    parser.add_argument("--top-candidates", type=int, default=100)
    args = parser.parse_args()

    populations, edges = extract_graph(args.mps)
    adjacency = [[] for _ in range(NODES)]
    incident_edges = [[] for _ in range(NODES)]
    for edge_index, (left, right, _) in enumerate(edges):
        adjacency[left].append(right)
        adjacency[right].append(left)
        incident_edges[left].append(edge_index)
        incident_edges[right].append(edge_index)
    for neighbors in adjacency:
        neighbors.sort()

    source = json.loads(args.initial_assignment.read_text(encoding="utf-8"))
    assignment = list(map(int, source["assignment_zero_based_district"]))
    if len(assignment) != NODES or set(assignment) - set(range(DISTRICTS)):
        raise ValueError("assignment must contain 595 district labels in 0..11")
    pops = district_populations(assignment, populations)
    if any(not in_bounds(value) for value in pops):
        raise ValueError(f"initial population outside bounds: {pops}")
    if any(not connected(assignment, district, adjacency)
           for district in range(DISTRICTS)):
        raise ValueError("initial assignment is disconnected")
    initial_objective = objective(assignment, edges)
    if (recorded := source.get("boundary_objective_original_units")) is not None:
        if Decimal(recorded) != initial_objective:
            raise ValueError(f"objective mismatch: {recorded} != {initial_objective}")

    def evaluate(changes: dict[int, int]):
        """Return (trial, delta) for an exactly feasible compound move, else None."""
        if not changes or any(assignment[node] == new for node, new in changes.items()):
            return None
        affected_districts = set()
        trial_pops = pops.copy()
        for node, new in changes.items():
            old = assignment[node]
            if new < 0 or new >= DISTRICTS:
                return None
            affected_districts.update((old, new))
            trial_pops[old] -= populations[node]
            trial_pops[new] += populations[node]
        if any(not in_bounds(trial_pops[district]) for district in affected_districts):
            return None

        trial = assignment.copy()
        for node, new in changes.items():
            trial[node] = new
        if any(not connected(trial, district, adjacency)
               for district in affected_districts):
            return None

        affected_edge_indices = {
            edge_index for node in changes for edge_index in incident_edges[node]
        }
        delta = Decimal(0)
        for edge_index in affected_edge_indices:
            left, right, cost = edges[edge_index]
            delta += 2 * cost * (
                int(trial[left] != trial[right]) - int(assignment[left] != assignment[right])
            )
        return trial, delta

    traces = []
    terminal = None
    for iteration in range(1, args.max_large_moves + 1):
        current_objective = objective(assignment, edges)
        generated: dict[tuple[tuple[int, int], ...], dict] = {}
        generation_counts = Counter()

        # Every connected three-node set contains an internal edge; grow that
        # edge by one adjacent node and deduplicate the resulting triples.
        triples = set()
        for left, right, _ in edges:
            district = assignment[left]
            if assignment[right] != district:
                continue
            for third in set(adjacency[left]) | set(adjacency[right]):
                if third not in (left, right) and assignment[third] == district:
                    triples.add(tuple(sorted((left, right, third))))
        for nodes in sorted(triples):
            old = assignment[nodes[0]]
            destinations = sorted({
                assignment[neighbor]
                for node in nodes for neighbor in adjacency[node]
                if assignment[neighbor] != old
            })
            for new in destinations:
                changes = {node: new for node in nodes}
                key = canonical_changes(changes)
                generated.setdefault(key, {
                    "kind": "connected_triple_transfer",
                    "nodes_zero_based": list(nodes),
                    "old_districts_zero_based": [old] * 3,
                    "new_districts_zero_based": [new] * 3,
                })
                generation_counts["connected_triple_transfer"] += 1

        # Exchange an internal edge of A with one boundary node of B.  Full
        # connectivity tests below make adjacency filters optional; the filter
        # only avoids combinations that cannot possibly attach to each target.
        nodes_by_district = [
            [node for node, label in enumerate(assignment) if label == district]
            for district in range(DISTRICTS)
        ]
        for left, right, _ in edges:
            old = assignment[left]
            if assignment[right] != old:
                continue
            pair = (left, right)
            destinations = sorted({
                assignment[neighbor]
                for node in pair for neighbor in adjacency[node]
                if assignment[neighbor] != old
            })
            for new in destinations:
                for back in nodes_by_district[new]:
                    # The B->A node needs an A neighbor that is not leaving.
                    if not any(assignment[nbr] == old and nbr not in pair
                               for nbr in adjacency[back]):
                        continue
                    # The pair must attach to B after `back` leaves.
                    if not any(assignment[nbr] == new and nbr != back
                               for node in pair for nbr in adjacency[node]):
                        continue
                    changes = {left: new, right: new, back: old}
                    key = canonical_changes(changes)
                    generated.setdefault(key, {
                        "kind": "connected_two_for_one_exchange",
                        "nodes_zero_based": [left, right, back],
                        "old_districts_zero_based": [old, old, new],
                        "new_districts_zero_based": [new, new, old],
                    })
                    generation_counts["connected_two_for_one_exchange"] += 1

        # Directed one-node cycles A->B, B->C, C->A.  Requiring each node to
        # touch its target district is an exact necessary condition unless its
        # only target neighbor is another moved node; those cases are still
        # included because the movable lists are formed before the move.
        movable: dict[tuple[int, int], list[int]] = {}
        for old in range(DISTRICTS):
            for new in range(DISTRICTS):
                if old == new:
                    continue
                movable[(old, new)] = [
                    node for node in nodes_by_district[old]
                    if any(assignment[nbr] == new for nbr in adjacency[node])
                ]
        for first in range(DISTRICTS):
            for second in range(first + 1, DISTRICTS):
                for third in range(second + 1, DISTRICTS):
                    for cycle in ((first, second, third), (first, third, second)):
                        a, b, c = cycle
                        for na, nb, nc in product(
                            movable[(a, b)], movable[(b, c)], movable[(c, a)]
                        ):
                            changes = {na: b, nb: c, nc: a}
                            key = canonical_changes(changes)
                            generated.setdefault(key, {
                                "kind": "three_district_one_node_cycle",
                                "nodes_zero_based": [na, nb, nc],
                                "old_districts_zero_based": [a, b, c],
                                "new_districts_zero_based": [b, c, a],
                            })
                            generation_counts["three_district_one_node_cycle"] += 1

        feasible_counts = Counter()
        candidates = []
        for changes_key, record in generated.items():
            changes = dict(changes_key)
            checked = evaluate(changes)
            if checked is None:
                continue
            trial, delta = checked
            feasible_counts[record["kind"]] += 1
            rank = {
                "connected_triple_transfer": 0,
                "connected_two_for_one_exchange": 1,
                "three_district_one_node_cycle": 2,
            }[record["kind"]]
            sort_key = (delta, rank, changes_key)
            candidates.append((sort_key, trial, record))
        candidates.sort(key=lambda item: item[0])

        top = []
        for sort_key, _, record in candidates[:args.top_candidates]:
            top.append({
                **record,
                "objective_delta": str(sort_key[0]),
                "objective_after": str(current_objective + sort_key[0]),
            })

        if not candidates or candidates[0][0][0] >= 0:
            terminal = {
                "generated_unique_candidates": len(generated),
                "generation_counts_before_deduplication": dict(generation_counts),
                "feasible_counts": dict(feasible_counts),
                "best_feasible_candidates": top,
            }
            print(
                f"terminal objective={current_objective} unique={len(generated)} "
                f"feasible={sum(feasible_counts.values())} "
                f"best_delta={candidates[0][0][0] if candidates else 'none'}",
                flush=True,
            )
            break

        sort_key, trial, record = candidates[0]
        delta = sort_key[0]
        record = {
            **record,
            "iteration": iteration,
            "node_populations": [populations[node] for node in record["nodes_zero_based"]],
            "objective_before": str(current_objective),
            "objective_delta": str(delta),
            "objective_after": str(current_objective + delta),
            "generated_unique_candidates": len(generated),
            "feasible_counts": dict(feasible_counts),
        }
        assignment = trial
        pops = district_populations(assignment, populations)
        if objective(assignment, edges) != current_objective + delta:
            raise RuntimeError("exact incremental objective disagreement")
        traces.append(record)
        print(
            f"large_move={iteration} kind={record['kind']} "
            f"nodes={record['nodes_zero_based']} delta={delta} "
            f"objective={current_objective + delta}",
            flush=True,
        )
    else:
        raise SystemExit("max large moves reached before terminal scan")

    final_objective = objective(assignment, edges)
    result = {
        "schema": "nj-exact-large-neighborhood-v1",
        "evidence_level": "deterministic exhaustive exact scan of the three stated compound move classes; full original-MPS lifting remains required",
        "source_mps_sha256": sha256(args.mps),
        "initial_assignment_sha256": sha256(args.initial_assignment),
        "initial_boundary_objective_original_units": str(initial_objective),
        "boundary_objective_original_units": str(final_objective),
        "objective_improvement": str(initial_objective - final_objective),
        "moves_applied": len(traces),
        "moves": traces,
        "terminal_scan": terminal,
        "assignment_zero_based_district": assignment,
        "district_populations": pops,
        "district_component_sizes": [assignment.count(d) for d in range(DISTRICTS)],
        "cut_edges": sum(assignment[left] != assignment[right] for left, right, _ in edges),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ("assignment_zero_based_district", "terminal_scan")}, indent=2))


if __name__ == "__main__":
    main()
