#!/usr/bin/env python3
"""Run a reproducible COPT search on an nj model from a strict warm start.

The output is computational evidence only.  Any improved incumbent must be
converted back to a district assignment and checked independently against the
original MPS before it is promoted to a strict upper bound.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import time
from pathlib import Path

import coptpy as cp


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def safe_attr(model, *names):
    for name in names:
        try:
            return getattr(model, name)
        except Exception:
            pass
    return None


def read_solution(path: Path) -> dict[str, float]:
    values: dict[str, float] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        tokens = raw.split()
        if len(tokens) < 2 or tokens[0].startswith(("#", "=")):
            continue
        values[tokens[0]] = float(tokens[1])
    return values


def set_parameter(model, parameter, value, record: dict[str, object]) -> None:
    name = str(parameter)
    try:
        model.setParam(parameter, value)
        record[name] = value
    except Exception as error:
        record[name] = f"unsupported: {error}"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path)
    parser.add_argument("warm_start", type=Path)
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--time-limit", type=float, default=3600.0)
    parser.add_argument("--threads", type=int, default=16)
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--mode", choices=("default", "aggressive"), default="aggressive")
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    environment = cp.Envr()
    model = environment.createModel("nj-search")
    model.read(str(args.model))
    variables = list(model.getVars())
    names = [variable.name for variable in variables]
    sparse = read_solution(args.warm_start)
    unknown = sorted(set(sparse) - set(names))
    if unknown:
        raise ValueError(f"warm start has unknown variables: {unknown[:20]}")
    model.setMipStart(variables, [sparse.get(name, 0.0) for name in names])
    load_return = model.loadMipStart()
    model.setLogFile(str(args.outdir / "solver.log"))

    parameters: dict[str, object] = {}
    for parameter, value in (
        (cp.COPT.Param.TimeLimit, args.time_limit),
        (cp.COPT.Param.Threads, args.threads),
        (cp.COPT.Param.RelGap, 0.0),
        (cp.COPT.Param.GPUMode, 0),
    ):
        set_parameter(model, parameter, value, parameters)
    set_parameter(model, "RandomSeed", args.seed, parameters)
    if args.mode == "aggressive":
        for parameter, value in (
            (cp.COPT.Param.HeurLevel, 3),
            (cp.COPT.Param.PreRootHeurLevel, 3),
            (cp.COPT.Param.RoundingHeurLevel, 3),
            (cp.COPT.Param.DivingHeurLevel, 3),
            (cp.COPT.Param.FAPHeurLevel, 4),
            (cp.COPT.Param.SubMipHeurLevel, 3),
            (cp.COPT.Param.MipRepair, 3),
        ):
            set_parameter(model, parameter, value, parameters)

    started = time.time()
    model.solve()
    wall_seconds = time.time() - started
    has_solution = bool(safe_attr(model, "hasmipsol", "HasMipSol"))
    solution_path = args.outdir / "incumbent.sol"
    if has_solution:
        model.write(str(solution_path))

    report = {
        "schema": "nj-copt8-search-v1",
        "evidence_level": "limited COPT run; incumbent and bound are numerical until independently checked",
        "solver": "COPT",
        "solver_version": [
            cp.COPT.VERSION_MAJOR,
            cp.COPT.VERSION_MINOR,
            cp.COPT.VERSION_TECHNICAL,
        ],
        "host": platform.node(),
        "model": args.model.as_posix(),
        "model_sha256": sha256(args.model),
        "warm_start": args.warm_start.as_posix(),
        "warm_start_sha256": sha256(args.warm_start),
        "warm_start_sparse_values": len(sparse),
        "warm_start_dense_values": len(names),
        "load_mip_start_return": repr(load_return),
        "mode": args.mode,
        "seed": args.seed,
        "parameters": parameters,
        "wall_seconds": wall_seconds,
        "status": str(safe_attr(model, "status", "Status")),
        "has_mip_solution": has_solution,
        "objective": str(safe_attr(model, "objval", "ObjVal")),
        "numerical_best_bound": str(safe_attr(model, "bestbnd", "BestBnd")),
        "node_count": str(safe_attr(model, "nodecnt", "NodeCnt")),
        "solution": solution_path.as_posix() if has_solution else None,
        "solution_sha256": sha256(solution_path) if has_solution else None,
    }
    (args.outdir / "result.json").write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print("RESULT_JSON=" + json.dumps(report, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
