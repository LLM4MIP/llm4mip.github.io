#!/usr/bin/env python3
"""Fast randomized connected region-growing heuristic for nj1/nj2."""

from __future__ import annotations

import argparse
import json
import random
import sys
import time
from pathlib import Path


THIS = Path(__file__).resolve()
sys.path.insert(0, str(THIS.parent))
from connected_partition_cpsat import (  # noqa: E402
    DISTRICTS,
    LOWER_POPULATION,
    NODES,
    UPPER_POPULATION,
    components,
    extract_graph,
    farthest_seeds,
)
from nj_block_forensics import sha256  # noqa: E402


TARGET = 8_791_894 / 12


def attempt(populations, edges, adjacency, weighted_neighbors, rng, start):
    seeds = farthest_seeds(adjacency, start)
    assignment = [-1] * NODES
    district_population = [0] * DISTRICTS
    frontier = [set() for _ in range(DISTRICTS)]
    for district, node in enumerate(seeds):
        assignment[node] = district
        district_population[district] = populations[node]
    for district, seed in enumerate(seeds):
        frontier[district].update(node for node in adjacency[seed] if assignment[node] < 0)

    unassigned = NODES - DISTRICTS
    while unassigned:
        viable = []
        for district in range(DISTRICTS):
            choices = [node for node in frontier[district]
                       if assignment[node] < 0
                       and district_population[district] + populations[node] <= UPPER_POPULATION]
            if choices:
                viable.append((district_population[district] / TARGET, rng.random(), district, choices))
        if not viable:
            return None
        viable.sort()
        # Usually grow the most underweight region, with mild randomized diversity.
        window = viable[:min(3, len(viable))]
        _, _, district, choices = window[0] if rng.random() < 0.72 else rng.choice(window)
        scored = []
        for node in choices:
            delta = 0.0
            own_neighbors = 0
            foreign_neighbors = 0
            for neighbor, weight in weighted_neighbors[node]:
                label = assignment[neighbor]
                if label == district:
                    delta -= weight
                    own_neighbors += 1
                elif label >= 0:
                    delta += weight
                    foreign_neighbors += 1
            after = district_population[district] + populations[node]
            overshoot = max(0.0, after - TARGET) / TARGET
            score = (delta + 0.04 * foreign_neighbors - 0.015 * own_neighbors
                     + 8.0 * overshoot * overshoot + rng.random() * 0.35)
            scored.append((score, rng.random(), node))
        scored.sort()
        shortlist = scored[:min(4, len(scored))]
        _, _, node = shortlist[0] if rng.random() < 0.78 else rng.choice(shortlist)
        assignment[node] = district
        district_population[district] += populations[node]
        unassigned -= 1
        for values in frontier:
            values.discard(node)
        frontier[district].update(neighbor for neighbor in adjacency[node] if assignment[neighbor] < 0)

    if min(district_population) < LOWER_POPULATION:
        return None
    return assignment, seeds, district_population


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--restarts", type=int, default=5000)
    parser.add_argument("--seed", type=int, default=20260908)
    parser.add_argument("--time-limit", type=float, default=600)
    args = parser.parse_args()

    populations, edges = extract_graph(args.mps)
    adjacency = [[] for _ in range(NODES)]
    weighted_neighbors = [[] for _ in range(NODES)]
    for left, right, cost in edges:
        adjacency[left].append(right)
        adjacency[right].append(left)
        weighted_neighbors[left].append((right, float(cost)))
        weighted_neighbors[right].append((left, float(cost)))
    rng = random.Random(args.seed)
    started = time.time()
    failures = 0
    best = None
    for restart in range(1, args.restarts + 1):
        if time.time() - started > args.time_limit:
            break
        result = attempt(populations, edges, adjacency, weighted_neighbors, rng, rng.randrange(NODES))
        if result is None:
            failures += 1
            continue
        assignment, seeds, district_populations = result
        component_lists = [components(assignment, district, adjacency) for district in range(DISTRICTS)]
        if not all(len(items) == 1 for items in component_lists):
            raise RuntimeError("region-growing construction lost connectivity")
        objective = sum(2 * cost for left, right, cost in edges
                        if assignment[left] != assignment[right])
        candidate = (objective, assignment, seeds, district_populations, restart)
        if best is None or candidate[0] < best[0]:
            best = candidate
            print(f"restart={restart} objective={objective} populations={district_populations}", flush=True)

    if best is None:
        raise SystemExit(f"no feasible connected partition; failed_restarts={failures}")
    objective, assignment, seeds, district_populations, restart = best
    component_lists = [components(assignment, district, adjacency) for district in range(DISTRICTS)]
    result = {
        "evidence_level": "constructive connected region growth plus explicit population/component checks; requires original-MPS lift/check",
        "source_mps_sha256": sha256(args.mps),
        "algorithm": "randomized simultaneous farthest-seed region growth",
        "random_seed": args.seed,
        "restarts_attempted": restart,
        "failed_restarts_before_best": failures,
        "wall_time": time.time() - started,
        "population_bounds": [LOWER_POPULATION, UPPER_POPULATION],
        "total_population": sum(populations),
        "assignment_zero_based_district": assignment,
        "construction_seeds_zero_based_node": seeds,
        "district_populations": district_populations,
        "district_component_sizes": [len(items[0]) for items in component_lists],
        "cut_edges": sum(assignment[left] != assignment[right] for left, right, _ in edges),
        "boundary_objective_original_units": str(objective),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print("CONNECTED_ASSIGNMENT=" + str(args.output))


if __name__ == "__main__":
    main()
