#!/usr/bin/env python3
"""Run a bounded Gurobi 13 search on nj1, nj2, or nj3 from a warm start.

The solver output is numerical search evidence only.  A returned incumbent
must be converted to a district assignment and reconstructed/checked with
exact arithmetic against the original MPS before it is promoted to a strict
upper bound.  Likewise, ``ObjBound`` is not an exact lower-bound certificate.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import time
from decimal import Decimal, InvalidOperation
from pathlib import Path

import gurobipy as gp


EXPECTED_INSTANCES = {
    (78_084, 97_579): "nj1",
    (85_224, 118_975): "nj2",
    (85_224, 118_986): "nj3",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def nonnegative_float(text: str) -> float:
    value = float(text)
    if not math.isfinite(value) or value < 0:
        raise argparse.ArgumentTypeError("value must be a finite nonnegative number")
    return value


def positive_int(text: str) -> int:
    value = int(text)
    if value <= 0:
        raise argparse.ArgumentTypeError("value must be positive")
    return value


def seed_value(text: str) -> int:
    value = int(text)
    if not 0 <= value <= 2_000_000_000:
        raise argparse.ArgumentTypeError("seed must lie in 0..2000000000")
    return value


def probability(text: str) -> float:
    value = float(text)
    if not math.isfinite(value) or not 0 <= value <= 1:
        raise argparse.ArgumentTypeError("value must lie in [0,1]")
    return value


def read_solution(path: Path) -> tuple[dict[str, Decimal], str | None]:
    """Read the sparse text subset shared by MIPLIB, Gurobi, and COPT .sol files."""
    values: dict[str, Decimal] = {}
    objective_header = None
    with path.open(encoding="utf-8") as handle:
        for line_number, raw in enumerate(handle, start=1):
            tokens = raw.split()
            if not tokens:
                continue
            if tokens[0] == "=obj=" and len(tokens) >= 2:
                objective_header = tokens[1]
                continue
            if raw.lstrip().startswith("#"):
                if raw.lstrip().startswith("# Objective value") and "=" in raw:
                    objective_header = raw.split("=", 1)[1].strip()
                continue
            if len(tokens) < 2:
                continue
            name = tokens[0]
            if name in values:
                raise ValueError(f"duplicate warm-start variable {name!r} on line {line_number}")
            try:
                value = Decimal(tokens[1].replace("D", "E").replace("d", "e"))
            except InvalidOperation as error:
                raise ValueError(
                    f"invalid warm-start value {tokens[1]!r} on line {line_number}"
                ) from error
            if not value.is_finite():
                raise ValueError(f"non-finite warm-start value for {name!r} on line {line_number}")
            values[name] = value
    return values, objective_header


def status_name(code: int) -> str:
    for name in (
        "LOADED", "OPTIMAL", "INFEASIBLE", "INF_OR_UNBD", "UNBOUNDED",
        "CUTOFF", "ITERATION_LIMIT", "NODE_LIMIT", "TIME_LIMIT",
        "SOLUTION_LIMIT", "INTERRUPTED", "NUMERIC", "SUBOPTIMAL",
        "INPROGRESS", "USER_OBJ_LIMIT", "WORK_LIMIT", "MEM_LIMIT",
    ):
        if getattr(gp.GRB, name, None) == code:
            return name
    return f"UNKNOWN_{code}"


def safe_model_attr(model: gp.Model, name: str):
    try:
        value = getattr(model, name)
    except (AttributeError, gp.GurobiError):
        return None
    if isinstance(value, float) and not math.isfinite(value):
        return str(value)
    return value


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path, help="official nj1/nj2/nj3 MPS or MPS.GZ")
    parser.add_argument("warm_start", type=Path, help="sparse .sol; omitted variables mean zero")
    parser.add_argument("outdir", type=Path, help="new/empty output directory")
    parser.add_argument("--time-limit", type=nonnegative_float, default=3600.0)
    parser.add_argument("--threads", type=positive_int, default=16)
    parser.add_argument("--seed", type=seed_value, default=1)
    parser.add_argument("--mip-focus", type=int, choices=range(4), default=1)
    parser.add_argument("--heuristics", type=probability, default=0.20)
    parser.add_argument("--no-rel-heur-time", type=nonnegative_float, default=0.0)
    parser.add_argument("--mip-gap", type=probability, default=0.0)
    args = parser.parse_args()

    if not args.model.is_file():
        raise FileNotFoundError(args.model)
    if not args.warm_start.is_file():
        raise FileNotFoundError(args.warm_start)
    args.outdir.mkdir(parents=True, exist_ok=True)
    result_path = args.outdir / "result.json"
    log_path = args.outdir / "solver.log"
    solution_path = args.outdir / "incumbent.sol"
    collisions = [path for path in (result_path, log_path, solution_path) if path.exists()]
    if collisions:
        raise FileExistsError(
            "refusing to overwrite existing outputs: " + ", ".join(str(path) for path in collisions)
        )

    version = tuple(gp.gurobi.version())
    if not version or version[0] != 13:
        raise RuntimeError(f"this audited runner requires Gurobi 13.x; found {version}")

    model = gp.read(str(args.model))
    model.update()
    dimensions = (model.NumVars, model.NumConstrs)
    instance = EXPECTED_INSTANCES.get(dimensions)
    if instance is None:
        raise ValueError(
            f"input dimensions {dimensions} do not match audited nj1/nj2/nj3 dimensions"
        )
    if model.ModelSense != gp.GRB.MINIMIZE:
        raise ValueError("audited nj models must be minimization models")

    variables = model.getVars()
    variables_by_name = {variable.VarName: variable for variable in variables}
    if len(variables_by_name) != len(variables):
        raise ValueError("model has duplicate variable names")
    sparse, objective_header = read_solution(args.warm_start)
    unknown = sorted(set(sparse) - set(variables_by_name))
    if unknown:
        raise ValueError(f"warm start has unknown variables: {unknown[:20]}")

    dense = [float(sparse.get(variable.VarName, Decimal(0))) for variable in variables]
    bound_violations = []
    integrality_violations = []
    for variable, value in zip(variables, dense):
        violation = max(0.0, variable.LB - value, value - variable.UB)
        if violation:
            bound_violations.append((violation, variable.VarName, value))
        if variable.VType in (gp.GRB.BINARY, gp.GRB.INTEGER, gp.GRB.SEMIINT):
            violation = abs(value - round(value))
            if violation:
                integrality_violations.append((violation, variable.VarName, value))
    bound_violations.sort(reverse=True)
    integrality_violations.sort(reverse=True)
    if bound_violations or integrality_violations:
        raise ValueError(
            "warm start violates declared variable domains: "
            f"bounds={bound_violations[:5]}, integrality={integrality_violations[:5]}"
        )

    model.setAttr(gp.GRB.Attr.Start, variables, dense)
    model.Params.TimeLimit = args.time_limit
    model.Params.Threads = args.threads
    model.Params.Seed = args.seed
    model.Params.MIPFocus = args.mip_focus
    model.Params.Heuristics = args.heuristics
    model.Params.NoRelHeurTime = args.no_rel_heur_time
    model.Params.MIPGap = args.mip_gap
    model.Params.LogFile = str(log_path.resolve())
    model.Params.OutputFlag = 1

    requested_parameters = {
        "TimeLimit": args.time_limit,
        "Threads": args.threads,
        "Seed": args.seed,
        "MIPFocus": args.mip_focus,
        "Heuristics": args.heuristics,
        "NoRelHeurTime": args.no_rel_heur_time,
        "MIPGap": args.mip_gap,
    }
    effective_parameters = {
        name: getattr(model.Params, name) for name in requested_parameters
    }
    warm_start_float_objective = math.fsum(
        variable.Obj * value for variable, value in zip(variables, dense)
    ) + model.ObjCon

    wall_started = time.monotonic()
    optimization_error = None
    try:
        model.optimize()
    except gp.GurobiError as error:
        # Preserve a machine-readable failure record (not just a traceback),
        # for example when a host has a size-limited license.
        optimization_error = {
            "type": type(error).__name__,
            "errno": getattr(error, "errno", None),
            "message": str(error),
        }
    wall_seconds = time.monotonic() - wall_started
    raw_status = safe_model_attr(model, "Status")
    status_code = int(raw_status) if raw_status is not None else int(gp.GRB.LOADED)
    raw_solution_count = safe_model_attr(model, "SolCount")
    solution_count = int(raw_solution_count) if raw_solution_count is not None else 0
    if solution_count:
        model.write(str(solution_path.resolve()))

    report = {
        "schema": "nj-gurobi13-search-v1",
        "evidence_level": (
            "limited Gurobi floating-point MIP search; any incumbent must be independently "
            "reconstructed and checked at zero tolerance against the original MPS before being "
            "promoted to a strict upper bound; ObjBound is numerical evidence, not an exact "
            "lower-bound or optimality certificate"
        ),
        "solver": {
            "name": "Gurobi",
            "version": list(version),
            "platform": gp.gurobi.platform(),
            "host": platform.node(),
        },
        "instance": instance,
        "model": {
            "path": args.model.as_posix(),
            "sha256": sha256(args.model),
            "variables": model.NumVars,
            "linear_constraints": model.NumConstrs,
            "linear_nonzeros": model.NumNZs,
            "integer_variables": model.NumIntVars,
            "binary_variables": model.NumBinVars,
            "fingerprint": safe_model_attr(model, "Fingerprint"),
        },
        "warm_start": {
            "path": args.warm_start.as_posix(),
            "sha256": sha256(args.warm_start),
            "sparse_values_read": len(sparse),
            "dense_values_supplied": len(dense),
            "unknown_variable_count": len(unknown),
            "bound_violation_count": len(bound_violations),
            "integrality_violation_count": len(integrality_violations),
            "objective_header": objective_header,
            "float_recomputed_objective": repr(warm_start_float_objective),
            "row_feasibility_checked_before_solve": False,
        },
        "parameters": {
            "requested": requested_parameters,
            "effective": effective_parameters,
        },
        "termination": {
            "status_code": status_code,
            "status_name": status_name(status_code),
            "runtime_seconds": safe_model_attr(model, "Runtime"),
            "wall_seconds": wall_seconds,
            "work": safe_model_attr(model, "Work"),
            "node_count": safe_model_attr(model, "NodeCount"),
            "iteration_count": safe_model_attr(model, "IterCount"),
            "optimization_error": optimization_error,
        },
        "numerical_result": {
            "solution_count": solution_count,
            "has_incumbent": solution_count > 0,
            "objective": safe_model_attr(model, "ObjVal") if solution_count else None,
            "best_bound": safe_model_attr(model, "ObjBound"),
            "relative_gap": safe_model_attr(model, "MIPGap") if solution_count else None,
            "solution": solution_path.as_posix() if solution_count else None,
            "solution_sha256": sha256(solution_path) if solution_count else None,
            "strict_upper_bound": None,
            "certified_lower_bound": None,
            "optimality_proved": False,
        },
    }
    result_path.write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print("RESULT_JSON=" + json.dumps(report, sort_keys=True), flush=True)
    if optimization_error is not None:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
