#!/usr/bin/env python3
"""Independently replay an archived NJ large-neighborhood chain certificate."""

from __future__ import annotations

import argparse
import json
import sys
from decimal import Decimal
from pathlib import Path


THIS = Path(__file__).resolve()
sys.path.insert(0, str(THIS.parent))
from connected_boundary_steepest_descent import (  # noqa: E402
    DISTRICTS,
    LOWER_POPULATION,
    NODES,
    UPPER_POPULATION,
    component,
    extract_graph,
    objective,
)
from nj_block_forensics import sha256  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("initial_assignment", type=Path)
    parser.add_argument("certificate", type=Path)
    args = parser.parse_args()

    populations, edges = extract_graph(args.mps)
    adjacency = [[] for _ in range(NODES)]
    for left, right, _ in edges:
        adjacency[left].append(right)
        adjacency[right].append(left)
    for neighbors in adjacency:
        neighbors.sort()

    initial_data = json.loads(args.initial_assignment.read_text(encoding="utf-8"))
    certificate = json.loads(args.certificate.read_text(encoding="utf-8"))
    assert certificate["schema"] == "nj-exact-large-neighborhood-chain-v1"
    assert certificate["source_mps_sha256"] == sha256(args.mps)
    assert certificate["initial_assignment_sha256"] == sha256(args.initial_assignment)
    assignment = list(map(int, initial_data["assignment_zero_based_district"]))
    assert len(assignment) == NODES and not (set(assignment) - set(range(DISTRICTS)))

    def check_state(expected: str) -> tuple[Decimal, list[int]]:
        value = objective(assignment, edges)
        assert value == Decimal(expected)
        district_populations = [
            sum(populations[node] for node, label in enumerate(assignment)
                if label == district)
            for district in range(DISTRICTS)
        ]
        assert all(LOWER_POPULATION <= pop <= UPPER_POPULATION
                   for pop in district_populations)
        for district in range(DISTRICTS):
            selected_count = assignment.count(district)
            assert len(component(assignment, district, adjacency)) == selected_count
        return value, district_populations

    initial_objective, _ = check_state(
        certificate["initial_boundary_objective_original_units"]
    )
    for expected_step, move in enumerate(certificate["moves"], 1):
        assert int(move["global_step"]) == expected_step
        before, _ = check_state(move["objective_before"])
        nodes = list(map(int, move["nodes_zero_based"]))
        old_labels = list(map(int, move["old_districts_zero_based"]))
        new_labels = list(map(int, move["new_districts_zero_based"]))
        assert len(nodes) == len(set(nodes)) == len(old_labels) == len(new_labels)
        assert [assignment[node] for node in nodes] == old_labels
        assert not (set(new_labels) - set(range(DISTRICTS)))
        assert [populations[node] for node in nodes] == list(map(int, move["node_populations"]))
        for node, new_label in zip(nodes, new_labels):
            assignment[node] = new_label
        after, _ = check_state(move["objective_after"])
        assert after - before == Decimal(move["objective_delta"])

    assert len(certificate["moves"]) == int(
        certificate["accepted_move_count_including_kicks"]
    )
    final_objective, final_populations = check_state(
        certificate["boundary_objective_original_units"]
    )
    assert initial_objective - final_objective == Decimal(
        certificate["objective_improvement"]
    )
    assert assignment == list(map(int, certificate["assignment_zero_based_district"]))
    assert final_populations == list(map(int, certificate["district_populations"]))
    assert [assignment.count(district) for district in range(DISTRICTS)] == list(
        map(int, certificate["district_component_sizes"])
    )
    cut_edges = sum(assignment[left] != assignment[right] for left, right, _ in edges)
    assert cut_edges == int(certificate["cut_edges"])

    print(json.dumps({
        "verified": True,
        "initial_objective": str(initial_objective),
        "final_objective": str(final_objective),
        "accepted_moves_checked": len(certificate["moves"]),
        "districts_checked": DISTRICTS,
        "terminal_compound_kicks_reported": int(
            certificate["terminal_compound_kicks_fully_descended"]
        ),
        "certificate_sha256": sha256(args.certificate),
    }, indent=2))


if __name__ == "__main__":
    main()
