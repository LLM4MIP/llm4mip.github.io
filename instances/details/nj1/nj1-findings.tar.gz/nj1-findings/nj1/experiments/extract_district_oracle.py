#!/usr/bin/env python3
"""Extract one exact nj district configuration oracle as a standalone MPS.

The extracted model keeps one official .dec block, its one root-total master
equation, and the original objective.  The 595 cross-district assignment rows
are deliberately omitted: their incidence vector is the configuration returned
to a future Dantzig--Wolfe/Benders master.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import sys
from contextlib import contextmanager
from decimal import Decimal
from pathlib import Path


sys.path.insert(0, str(Path(__file__).resolve().parent))
from nj_block_forensics import parse_dec, parse_mps, sha256  # noqa: E402


def decimal_text(value: Decimal) -> str:
    return format(value, "f")


@contextmanager
def deterministic_text_writer(path: Path):
    """Write text, using an mtime-free gzip header for reproducible archives."""
    if path.suffix != ".gz":
        with path.open("w", encoding="latin-1", newline="\n") as handle:
            yield handle
        return
    with path.open("wb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as compressed:
            with io.TextIOWrapper(compressed, encoding="latin-1", newline="\n") as handle:
                yield handle


def uncompressed_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_mps(path: Path, model: dict, selected_rows: list[str], selected_vars: list[str]) -> None:
    objective_rows = [row for row, info in model["rows"].items() if info["sense"] == "N"]
    if len(objective_rows) != 1:
        raise ValueError(f"expected one objective row, found {objective_rows}")
    objective = objective_rows[0]
    keep_rows = set(selected_rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    with deterministic_text_writer(path) as handle:
        handle.write("NAME          nj_district_oracle\nROWS\n")
        handle.write(f" N  {objective}\n")
        for row in selected_rows:
            handle.write(f" {model['rows'][row]['sense']}  {row}\n")
        handle.write("COLUMNS\n")
        integer_open = False
        marker = 0
        for variable in selected_vars:
            info = model["variables"][variable]
            if info["integer"] and not integer_open:
                handle.write(f"    MARK{marker:04d}  'MARKER'                 'INTORG'\n")
                integer_open = True
                marker += 1
            elif not info["integer"] and integer_open:
                handle.write(f"    MARK{marker:04d}  'MARKER'                 'INTEND'\n")
                integer_open = False
                marker += 1
            terms = [(row, value) for row, value in info["rows"] if row == objective or row in keep_rows]
            for start in range(0, len(terms), 2):
                fields = "    " + variable
                for row, value in terms[start:start + 2]:
                    fields += f"  {row}  {decimal_text(value)}"
                handle.write(fields + "\n")
        if integer_open:
            handle.write(f"    MARK{marker:04d}  'MARKER'                 'INTEND'\n")
        handle.write("RHS\n")
        for row in selected_rows:
            value = model["rhs"].get(row, Decimal(0))
            if value:
                handle.write(f"    RHS1  {row}  {decimal_text(value)}\n")
        handle.write("BOUNDS\n")
        for variable in selected_vars:
            info = model["variables"][variable]
            lower, upper = info["lower"], info["upper"]
            if info["integer"] and lower == 0 and upper == 1:
                handle.write(f" BV BND1  {variable}\n")
                continue
            if lower != 0:
                if lower.is_infinite() and lower < 0:
                    handle.write(f" MI BND1  {variable}\n")
                else:
                    handle.write(f" LO BND1  {variable}  {decimal_text(lower)}\n")
            if upper is not None:
                handle.write(f" UP BND1  {variable}  {decimal_text(upper)}\n")
        handle.write("ENDATA\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("dec", type=Path)
    parser.add_argument("output_mps", type=Path)
    parser.add_argument("report", type=Path)
    parser.add_argument("--block", type=int, default=1)
    args = parser.parse_args()
    model = parse_mps(args.mps)
    block_of_row, master_rows = parse_dec(args.dec)
    selected_rows = [row for row, block in block_of_row.items() if block == args.block]
    selected_row_set = set(selected_rows)
    selected_vars = [
        variable for variable, info in model["variables"].items()
        if any(row in selected_row_set for row, _ in info["rows"])
    ]
    selected_var_set = set(selected_vars)
    root_rows = [
        row for row in master_rows
        if len(model["rows"][row]["terms"]) == 595
        and all(variable in selected_var_set for variable, _ in model["rows"][row]["terms"])
    ]
    if len(root_rows) != 1:
        raise ValueError(f"expected one root-total row for block {args.block}, found {root_rows}")
    selected_rows.append(root_rows[0])

    assignment_rows = [
        row for row in master_rows
        if len(model["rows"][row]["terms"]) == 12
        and any(variable in selected_var_set for variable, _ in model["rows"][row]["terms"])
    ]
    if len(assignment_rows) != 595:
        raise ValueError(f"expected 595 projected assignment coordinates, found {len(assignment_rows)}")
    assignment_columns = []
    for row in assignment_rows:
        columns = [variable for variable, _ in model["rows"][row]["terms"] if variable in selected_var_set]
        if len(columns) != 1:
            raise ValueError(f"assignment row {row} has {len(columns)} columns in selected block")
        assignment_columns.append(columns[0])

    write_mps(args.output_mps, model, selected_rows, selected_vars)
    report = {
        "algorithm": "single-district configuration oracle extraction",
        "role": "Dantzig-Wolfe/Benders subproblem prototype; not a full nj solution",
        "source_mps_sha256": sha256(args.mps),
        "source_dec_sha256": sha256(args.dec),
        "block": args.block,
        "local_rows": len(selected_rows) - 1,
        "root_total_rows_kept": root_rows,
        "variables": len(selected_vars),
        "integer_variables": sum(model["variables"][var]["integer"] for var in selected_vars),
        "continuous_variables": sum(not model["variables"][var]["integer"] for var in selected_vars),
        "master_assignment_rows_projected_out": len(assignment_rows),
        "configuration_incidence_columns": assignment_columns,
        "output_mps": str(args.output_mps.as_posix()),
        "output_mps_sha256": sha256(args.output_mps),
        "output_mps_uncompressed_sha256": uncompressed_sha256(args.output_mps),
        "claim_boundary": "A solution of this oracle is one district configuration, not a 12-district incumbent.",
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "block": args.block,
        "rows": len(selected_rows),
        "variables": len(selected_vars),
        "configuration_coordinates": len(assignment_columns),
        "output_sha256": report["output_mps_sha256"],
    }, indent=2))


if __name__ == "__main__":
    main()
