#!/usr/bin/env python3
"""Exact deterministic local search over one- and two-node nj moves.

The neighborhood is the union of:

* moving one boundary node to an adjacent district;
* exchanging two boundary nodes belonging to different districts; and
* moving an adjacent pair from one district to an adjacent district.

Every candidate is checked with exact integer populations, explicit graph
connectivity for both affected districts, and a full Decimal objective
recomputation.  The lexicographically deterministic best improving candidate
is applied until a complete pass finds no improvement.
"""

from __future__ import annotations

import argparse
import json
import sys
from decimal import Decimal
from itertools import combinations
from pathlib import Path


THIS = Path(__file__).resolve()
sys.path.insert(0, str(THIS.parent))
from connected_boundary_steepest_descent import (  # noqa: E402
    DISTRICTS,
    LOWER_POPULATION,
    NODES,
    UPPER_POPULATION,
    component,
    extract_graph,
    objective,
)
from nj_block_forensics import sha256  # noqa: E402


def is_connected(assignment: list[int], district: int,
                 adjacency: list[list[int]]) -> bool:
    return len(component(assignment, district, adjacency)) == assignment.count(district)


def populations_by_district(assignment: list[int], populations: list[int]) -> list[int]:
    return [
        sum(populations[node] for node, label in enumerate(assignment) if label == district)
        for district in range(DISTRICTS)
    ]


def in_bounds(value: int) -> bool:
    return LOWER_POPULATION <= value <= UPPER_POPULATION


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("initial_assignment", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--max-moves", type=int, default=1_000)
    args = parser.parse_args()

    populations, edges = extract_graph(args.mps)
    adjacency = [[] for _ in range(NODES)]
    for left, right, _ in edges:
        adjacency[left].append(right)
        adjacency[right].append(left)
    for values in adjacency:
        values.sort()

    source = json.loads(args.initial_assignment.read_text(encoding="utf-8"))
    assignment = list(source["assignment_zero_based_district"])
    if len(assignment) != NODES or set(assignment) - set(range(DISTRICTS)):
        raise ValueError("assignment must contain 595 district labels in 0..11")
    district_populations = populations_by_district(assignment, populations)
    if any(not in_bounds(value) for value in district_populations):
        raise ValueError(f"initial population outside bounds: {district_populations}")
    if any(not is_connected(assignment, district, adjacency)
           for district in range(DISTRICTS)):
        raise ValueError("initial assignment has a disconnected district")

    initial_objective = objective(assignment, edges)
    recorded = source.get("boundary_objective_original_units")
    if recorded is not None and Decimal(recorded) != initial_objective:
        raise ValueError(f"initial objective mismatch: JSON={recorded}, decoded={initial_objective}")

    move_trace = []
    for iteration in range(1, args.max_moves + 1):
        current_objective = objective(assignment, edges)
        best_key = None
        best_assignment = None
        best_record = None
        feasible_counts = {
            "one_node_transfer": 0,
            "two_point_exchange": 0,
            "adjacent_pair_transfer": 0,
        }

        # One-node moves remain in the union so that a two-node move cannot
        # leave an immediately improving one-node move unexamined.
        for node in range(NODES):
            old_district = assignment[node]
            destinations = sorted({assignment[neighbor] for neighbor in adjacency[node]
                                   if assignment[neighbor] != old_district})
            if not destinations:
                continue
            if not in_bounds(district_populations[old_district] - populations[node]):
                continue
            trial = assignment.copy()
            trial[node] = -1
            if not is_connected(trial, old_district, adjacency):
                continue
            for new_district in destinations:
                if not in_bounds(district_populations[new_district] + populations[node]):
                    continue
                trial[node] = new_district
                if not is_connected(trial, new_district, adjacency):
                    trial[node] = -1
                    continue
                feasible_counts["one_node_transfer"] += 1
                value = objective(trial, edges)
                key = (value, 0, node, new_district, old_district)
                if value < current_objective and (best_key is None or key < best_key):
                    best_key = key
                    best_assignment = trial.copy()
                    best_record = {
                        "kind": "one_node_transfer",
                        "nodes_zero_based": [node],
                        "old_districts_zero_based": [old_district],
                        "new_districts_zero_based": [new_district],
                        "node_populations": [populations[node]],
                    }
                trial[node] = -1

        # A node that has no neighbor outside its current district cannot be
        # connected after an exchange, so this exact filter removes only
        # impossible exchange candidates.
        boundary_nodes = [
            node for node in range(NODES)
            if any(assignment[neighbor] != assignment[node] for neighbor in adjacency[node])
        ]
        for left_node, right_node in combinations(boundary_nodes, 2):
            left_district = assignment[left_node]
            right_district = assignment[right_node]
            if left_district == right_district:
                continue
            if not in_bounds(district_populations[left_district]
                             - populations[left_node] + populations[right_node]):
                continue
            if not in_bounds(district_populations[right_district]
                             - populations[right_node] + populations[left_node]):
                continue
            trial = assignment.copy()
            trial[left_node] = right_district
            trial[right_node] = left_district
            if not is_connected(trial, left_district, adjacency):
                continue
            if not is_connected(trial, right_district, adjacency):
                continue
            feasible_counts["two_point_exchange"] += 1
            value = objective(trial, edges)
            key = (value, 1, left_node, right_node, left_district, right_district)
            if value < current_objective and (best_key is None or key < best_key):
                best_key = key
                best_assignment = trial
                best_record = {
                    "kind": "two_point_exchange",
                    "nodes_zero_based": [left_node, right_node],
                    "old_districts_zero_based": [left_district, right_district],
                    "new_districts_zero_based": [right_district, left_district],
                    "node_populations": [populations[left_node], populations[right_node]],
                }

        # Each pair below is a graph edge, hence connected before and after the
        # transfer.  Destination connectivity is nevertheless checked in full.
        for left_node, right_node, _ in edges:
            old_district = assignment[left_node]
            if assignment[right_node] != old_district:
                continue
            pair_population = populations[left_node] + populations[right_node]
            destinations = sorted(
                ({assignment[neighbor] for neighbor in adjacency[left_node]}
                 | {assignment[neighbor] for neighbor in adjacency[right_node]})
                - {old_district}
            )
            if not destinations:
                continue
            if not in_bounds(district_populations[old_district] - pair_population):
                continue
            for new_district in destinations:
                if not in_bounds(district_populations[new_district] + pair_population):
                    continue
                trial = assignment.copy()
                trial[left_node] = new_district
                trial[right_node] = new_district
                if not is_connected(trial, old_district, adjacency):
                    continue
                if not is_connected(trial, new_district, adjacency):
                    continue
                feasible_counts["adjacent_pair_transfer"] += 1
                value = objective(trial, edges)
                key = (value, 2, min(left_node, right_node), max(left_node, right_node),
                       new_district, old_district)
                if value < current_objective and (best_key is None or key < best_key):
                    best_key = key
                    best_assignment = trial
                    best_record = {
                        "kind": "adjacent_pair_transfer",
                        "nodes_zero_based": [left_node, right_node],
                        "old_districts_zero_based": [old_district, old_district],
                        "new_districts_zero_based": [new_district, new_district],
                        "node_populations": [populations[left_node], populations[right_node]],
                    }

        if best_assignment is None or best_record is None or best_key is None:
            terminal_feasible_counts = feasible_counts
            break

        new_objective = objective(best_assignment, edges)
        if new_objective != best_key[0] or new_objective >= current_objective:
            raise RuntimeError("selected move disagrees with full exact objective comparison")
        assignment = best_assignment
        district_populations = populations_by_district(assignment, populations)
        if any(not in_bounds(value) for value in district_populations):
            raise RuntimeError("selected move violated a population bound")
        if any(not is_connected(assignment, district, adjacency)
               for district in set(best_record["old_districts_zero_based"]
                                   + best_record["new_districts_zero_based"])):
            raise RuntimeError("selected move violated district connectivity")
        best_record.update({
            "iteration": iteration,
            "objective_before": str(current_objective),
            "objective_delta": str(new_objective - current_objective),
            "objective_after": str(new_objective),
            "feasible_candidates_examined": feasible_counts,
        })
        move_trace.append(best_record)
        print(f"move={iteration} kind={best_record['kind']} "
              f"nodes={best_record['nodes_zero_based']} "
              f"delta={new_objective - current_objective} objective={new_objective}",
              flush=True)
    else:
        raise SystemExit(f"hit --max-moves={args.max_moves} before proving local optimality")

    final_objective = objective(assignment, edges)
    component_sizes = []
    for district in range(DISTRICTS):
        if not is_connected(assignment, district, adjacency):
            raise RuntimeError(f"final district {district} is disconnected")
        component_sizes.append(assignment.count(district))

    result = {
        "evidence_level": "deterministic exhaustive exact steepest descent over the union of feasible one-node transfers, cross-district two-point exchanges, and connected adjacent-pair transfers; requires original-MPS lift/check",
        "source_mps_sha256": sha256(args.mps),
        "initial_assignment_sha256": sha256(args.initial_assignment),
        "algorithm": "repeat the lexicographically deterministic maximum-decrease move from the audited one/two-node neighborhood union",
        "population_bounds": [LOWER_POPULATION, UPPER_POPULATION],
        "total_population": sum(populations),
        "initial_boundary_objective_original_units": str(initial_objective),
        "boundary_objective_original_units": str(final_objective),
        "objective_improvement": str(initial_objective - final_objective),
        "moves_applied": len(move_trace),
        "moves": move_trace,
        "terminal_feasible_candidates_examined": terminal_feasible_counts,
        "strictly_locally_optimal_in_audited_one_and_two_node_neighborhood_union": True,
        "assignment_zero_based_district": assignment,
        "district_populations": district_populations,
        "district_component_sizes": component_sizes,
        "cut_edges": sum(assignment[left] != assignment[right] for left, right, _ in edges),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n"
    )
    print("IMPROVED_ASSIGNMENT=" + str(args.output))


if __name__ == "__main__":
    main()
