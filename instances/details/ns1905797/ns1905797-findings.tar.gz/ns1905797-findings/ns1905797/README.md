# ns1905797: exact structural recovery and feasibility experiments

## Current conclusion

This study found a new strictly validated feasible solution with objective
`699129/50000 = 13.98258`.  It is a new finite upper bound, not a proof of
optimality.  The serialized solution is
`solutions/ns1905797-feasible-13.98258.sol`, SHA-256
`e8faedb2b88ae0567487e76cbe93a612f1816b2de5070382fb201dfa4fd48691`.
The file itself was reparsed with `Fraction` and checked at zero tolerance
against all 18,192 variable domains and all 51,884 original MPS rows: there are
no bound, integrality, or row violations, and the maximum exact row violation
is zero.  The durable audit is
`analysis/helper_feasible_13.98258/strict-audit.json`.

The input used throughout is `input/ns1905797.mps.gz`, SHA-256
`510f8d4863756bbf931592a965e00e03a705455ad1cf28994226064d6f592021`.

The [current MIPLIB page](https://miplib.zib.de/instance_details_ns1905797.html)
labels the instance `open` and `no_solution` and says that no solution is
available.  Relative to that public status, `13.98258` therefore supplies a
strict new incumbent/upper bound.  The LP value is `11.75098`, so the remaining
gap to that relaxation is 15.96% when normalized by the new upper bound.

## Provenance and historical evidence

The historical
[MIPLIB 2010 page](https://miplib2010.zib.de/miplib2010/ns1905797.php) marked
feasibility as `Feasible`, while leaving the integer objective unknown and
reporting LP objective `11.75098`; the
[historical feasibility legend](https://miplib2010.zib.de/miplib2010-feas.php)
defines that label as a known feasible solution.  However, the official
download area has no `ns1905797.sol.gz`, and `miplib2010_all.solu` records the
instance as `=unkn=`.  Thus the old label was useful evidence, but not a public
primal certificate.

The original contributor directory is
[`mittelmann1`](https://miplib2010.zib.de/contrib/submission2010/mittelmann1/),
whose [data index](https://miplib2010.zib.de/contrib/submission2010/mittelmann1/data/)
lists `ns1905797.mod`; its body currently returns HTTP 403.  A recovered
contributor MPS has compressed SHA-256
`4342dbbeff0146508f79c247a65f5ac4800ae5058775237d15d57b6d4e621b22`
and uncompressed SHA-256
`1cb32ea991a1e8006b6352dec5a9a918b9681b27fbf225cbd87a166742599aad`.
Line comparison against this repository's input found exactly one textual
difference, the first `NAME` line (`temp` versus `ns1905797`); the remaining
378,548 lines are byte-identical.  The structural and solution certificates
therefore address the historical constraint matrix exactly.

## Gurobi read-only structure audit

Gurobi 13.0.1 on `euler4` read the original compressed MPS without modifying
it.  The host's size-limited license permits this audit but not optimization of
the full model.

| item | exact count |
|---|---:|
| variables | 18,192 |
| rows | 51,884 |
| nonzeros | 239,700 |
| binary-domain integer variables | 17,676 |
| other integer variables | 4 |
| continuous variables | 512 |
| equality / inequality rows | 352 / 51,532 |
| nonzero objective coefficients | 17,148 |

The machine-readable audit is `analysis/gurobi-structure.json`; the solver
transcript is `logs/gurobi-structure.log`.  The ordered matrix hash recorded by
the deeper audit is
`b453af3572b9e821a5ad6e95e786a27f41c7ff812fcdc937cc56a37be68466cb`.

## Recovered routing formulation

The official decomposition and a direct coefficient-level reconstruction agree
on four exchangeable blocks.  Each block has 12,953 local rows and 4,548 local
variables.  The decomposition marks 72 rows as master, but only
`R0001`--`R0060` truly couple blocks; the other 12 marked rows are single-block
degree rows.  There are no linking variables.

Within each block:

- 4,419 binary variables are directed arcs on 67 nodes.  They are exactly the
  complete loopless digraph (`67*66 = 4,422`) minus `(61,0)`, `(63,0)`, and
  `(64,0)`.
- 67 continuous variables are time potentials.  Their windows are one node in
  `[6,18]`, ten in `[6,12]`, thirty in `[8,14]`, twenty-five in `[6,18]`, and
  node 66 in `[11,12]`.
- 61 continuous variables are work/load potentials in `[0,10]`.
- one general integer variable lies in `[1,305]`.

Nodes 1 through 60 are the ordinary visits.  Every such visit is assigned to
exactly one of the four blocks, and flow conservation gives one incoming and
one outgoing selected arc in its assigned block.  Node 0 has one outgoing arc
per block.  Node 66 has one incoming and one outgoing arc per block.  The
predecessor of node 0 is constrained to be node 62 or 65.

The general integer equals the number of selected arcs entering special nodes
61 through 65 from the complementary side; the reverse crossing count is one
less.  A weighted visit total, with visit weights `1`, `0.2`, and `2` for the
three ordinary-visit classes, is at most ten times this integer.  The work
potential rows enforce the corresponding within-segment accumulation.

The remaining 50,912 mixed rows are one- or two-trigger difference constraints
for time and work potentials.  This explains both the vehicle-routing origin
and the unusual numerical/search difficulty much more precisely than the raw
anonymous `C...`/`R...` names.  Full coefficient maps are in
`analysis/gurobi-forensics.json` and `analysis/route-structure.json`; they can be
regenerated with `experiments/gurobi_forensics.py` and
`experiments/decode_route_structure.py`.

## Exact CP-SAT translation

`experiments/solve_exact_cpsat.py` parses the MPS with `Fraction`, rather than
through floating-point solver objects.  All 512 continuous variables occur
only with coefficients `+1` or `-1`, at most two per row.  After multiplication
by 100,000, their bounds and every affected right-hand side are integral.  For
any fixed binary vector this is a system of difference constraints, whose
signed node-arc matrix is totally unimodular.  Hence real feasibility is
equivalent to feasibility with integral scaled potentials.  This makes the
CP-SAT translation an exact feasibility reformulation, not a discretization.

Further exact transformations are checked from variable bounds before use:

- 50,908 of the 50,912 big-M rows are replaced by logically equivalent
  enforcement constraints; the four unproved cases retain their original row.
- 264 two-variable conflicts become native at-most-one constraints.
- 60 assignment rows and 240 ordinary-node flow rows become 240 block
  assignment channels plus 60 exactly-one constraints.
- 180 first-use partitioning-orbitope inequalities remove the full `S_4`
  block-label symmetry.

Every accepted CP-SAT block output is converted back to original variable
values and checked with exact rational arithmetic.  For the final certificate,
`helper_combine_blocks.py` additionally writes exact terminating decimals,
reparses the actual `.sol` file, and repeats the full original-MPS check.

### Why the native circuit is redundant

`experiments/helper_circuit_solver.py` adds one optional-node `Circuit` per
block, but this does not cut off any solution of the original MPS.  The claim is
checked directly from the anonymous original rows as follows.

1. `R0001`--`R0060`, together with the node-balance rows
   `R16413`--`R16680`, give every assigned ordinary node one selected incoming
   and outgoing arc in its block.  `R0061`--`R0064` give node 0 one outgoing
   arc in each block.
2. `R16401`--`R16404` say that exactly one of `62->0` and `65->0` is selected
   per block.  Node-0 balance and the preceding unit outdegree therefore force
   every other arc entering 0 to zero and give node 0 indegree one.
3. `R16405`--`R16408` require exactly one listed predecessor of node 66, while
   `R16409`--`R16412` require exactly one successor.  The former rows omit
   `0->66`; node-66 balance consequently forces that otherwise exceptional arc
   to zero.
4. The coefficient audit in `analysis/helper_route_logic.json` accounts for all
   17,676 block arcs: 17,428 have an active time-potential implication and the
   remaining 248 all enter node 0.  Every active time increment is strictly
   positive except the four copies of `0->66`, already forced to zero above.
   Summing the implications around any selected directed cycle not containing
   node 0 would therefore give `t >= t + positive`, a contradiction.

The balanced selected-arc graph is thus a union of directed cycles, has exactly
one cycle through node 0, and cannot have any other cycle.  It is already the
single optional-node circuit imposed by CP-SAT.  Unassigned ordinary nodes and
unused special nodes receive self-loops only in the native representation; the
self-loops are not MPS variables.

## Experiments

All full solves ran CPU-only on `altman`; `CUDA_VISIBLE_DEVICES` was empty.
Gurobi was used for structure on `euler4`, while COPT 8.0.4 and OR-Tools CP-SAT
9.15.6755 performed the optimization experiments.

The principal negative full-model runs were:

| run | limit / threads | terminal evidence |
|---|---:|---|
| COPT, all 60 LP assignments fixed | 600 s / 16 | no incumbent; status 8; solver bound 13.48958 |
| COPT, 44 confidence-0.95 assignments fixed | 600 s / 16 | no incumbent; status 8; solver bound 12.60833 |
| exact CP-SAT, same 44 fixed, original objective | 600 s / 16 | `UNKNOWN`; 1,926,105 branches |
| exact CP-SAT plus four redundant native circuits | 900 s / 16 | `UNKNOWN`; 1,570,065 branches |
| original 24-task fourth block, seven seeds | 300 s each / 4 or 8 | all `UNKNOWN`; no infeasibility claim |

These transcripts are archived under `logs/helper_negative_full_runs` and
`logs/helper_negative_block4`.

### Construction of the initial incumbent

The LP argmax assignment had block task counts `19/8/9/24`.  Exact independent
block models quickly found routes for blocks 1--3, while every 300-second seed
for the 24-task fourth block timed out.  Moving tasks `46, 51, 54` to block 2,
tasks `47, 55` to block 3, and task `56` to block 1 produced final counts
`20/11/11/18`.  Each fixed-assignment block retains every original local row;
the 60 cross-block assignment equations become the corresponding local RHS
zero or one.  A redundant native circuit strengthens route search.

| block | tasks | exact CP-SAT status | solve seconds | block objective |
|---:|---:|---|---:|---:|
| 1 | 20 | `OPTIMAL` in the preserved-order insertion neighborhood | 0.123 | 4.58400 |
| 2 | 11 | `OPTIMAL` for the fixed assignment | 92.055 | 3.60400 |
| 3 | 11 | `OPTIMAL` for the fixed assignment | 61.708 | 3.66100 |
| 4 | 18 | `OPTIMAL` for the fixed assignment | 1.186 | 3.18529 |

The four component results and sparse partial vectors are archived under
`logs/helper_feasible_15.03429`.  Their assigned-task sets are each checked
against the common assignment file, SHA-256
`61f6e3f12a8ae1ff4227ed7a6d8a27bf58c1b1d599ca0786c309ff3a7645b45e`.
Combining them gives objective `15.03429`.  A mistakenly mixed diagnostic
combination had apparent objective `14.94729` but violated `R0054`; the exact
validator rejected it, and it is not a feasible result.

### COPT warm-start improvement

The complete, strictly validated `15.03429` vector was then supplied to COPT as
a MIP start, with all 18,192 original variables loaded and omitted sparse
entries materialized as zero.  A five-second smoke run returned `14.62129`; its
serialized candidate was independently exactified and validated before it was
used as the next start.  A 120-second CPU-only run with 24 threads then returned
`13.98258` and a numerical solver bound of `12.38858`.  It stopped at the time
limit, so neither the incumbent nor that numerical bound is an optimality
certificate.

COPT's `.sol` writer emits binary floating-point artifacts.  Therefore
`helper_exactify_solution.py` rounded integer variables to integers and the 512
potential variables to the exact `1/100000` lattice established above, and
then `helper_validate_solution.py` reparsed the resulting file.  The largest
pre-rounding continuous error was only `43/10000000000` of one grid unit.  The
reparsed `13.98258` file has zero exact bound, integrality, and row violations.
The numerical solver output, exactification report, local and remote validation
reports, and hashes are archived under `analysis/helper_feasible_13.98258`.

| formal warm-start run | limit / threads | nodes | incumbent | solver bound | terminal evidence |
|---|---:|---:|---:|---:|---|
| COPT from strict `14.62129` | 900 s / 32 | 11,453 | `13.98258` | `12.38858` | status 8 / time limit; exact revalidation `valid=true`, same solution SHA-256 `e8faedb2...` |

The 900-second transcript, result JSON, and strict-validation summary are the
`copt-900s-*` files in that archive.  This longer run did not improve the
120-second incumbent or bound.

An `UNKNOWN` status or a time limit is recorded only as negative computational
evidence.  It is never reported as an infeasibility proof.

## Reproduction

Read-only Gurobi reconstruction:

```bash
python gurobi_structure_probe.py ns1905797.mps.gz gurobi-structure.json
python gurobi_forensics.py ns1905797.mps.gz gurobi-forensics.json
python decode_route_structure.py ns1905797.mps.gz route-structure.json
```

Exact full-model CP-SAT search:

```bash
CUDA_VISIBLE_DEVICES= python solve_exact_cpsat.py \
  --model ns1905797.mps.gz --outdir run \
  --time-limit 1200 --workers 16 --random-seed 7
```

LP assignment hint followed by an exact hinted search:

```bash
CUDA_VISIBLE_DEVICES= python make_copt_lp_hint.py \
  --model ns1905797.mps.gz --outdir lp-hint
CUDA_VISIBLE_DEVICES= python solve_exact_cpsat.py \
  --model ns1905797.mps.gz --outdir hinted-run \
  --assignment-hint lp-hint/assignment-hint.json \
  --time-limit 1200 --workers 16
```

Zero-tolerance validation of the serialized incumbent, using only the Python
standard library:

```bash
python experiments/helper_validate_solution.py \
  --model input/ns1905797.mps.gz \
  --solution solutions/ns1905797-feasible-13.98258.sol \
  --output strict-audit.json
```

Reproduce the COPT improvement and exact-file boundary (with the COPT 8 Python
module on `PYTHONPATH`):

```bash
CUDA_VISIBLE_DEVICES= python experiments/helper_copt_warmstart.py \
  --model input/ns1905797.mps.gz \
  --solution solutions/ns1905797-feasible-14.62129.sol \
  --outdir copt-run --time-limit 120 --threads 24
python experiments/helper_exactify_solution.py \
  --model input/ns1905797.mps.gz \
  --input-solution copt-run/incumbent.sol \
  --output-solution copt-run/incumbent-exact.sol \
  --report copt-run/exactify.json
python experiments/helper_validate_solution.py \
  --model input/ns1905797.mps.gz \
  --solution copt-run/incumbent-exact.sol \
  --output copt-run/strict-validation.json
```

## Evidence boundary

- The Gurobi dimensions, four-block decomposition, arc crosswalk, exact
  integerization argument, and original-row validator are structural facts.
- The reparsed solution file proves feasibility and the finite upper bound
  `13.98258`; it does not prove global optimality.
- A solver terminal status `INFEASIBLE` for the complete exact CP-SAT model
  would prove infeasibility; no such status has been obtained in this study.
- The COPT search bound `12.38858` and all time-limited solver searches are
  numerical/computational evidence only.
- The historical `Feasible` metadata is not itself a primal witness.  The new
  serialized vector, rather than that metadata, is the feasibility certificate
  reported here.
