#!/usr/bin/env bash
set -euo pipefail

# Run the exact fixed-assignment route blocks independently.  Block 1 was
# already exercised as a one-worker smoke test; BLOCKS can be overridden when
# reproducing only a subset, e.g. BLOCKS="2 3 4".
ROOT=${ROOT:-/home/huangyicheng/miplib_ns190}
BLOCKS=${BLOCKS:-"1 2 3 4"}
TIME_LIMIT=${TIME_LIMIT:-300}
WORKERS=${WORKERS:-4}
SEED_BASE=${SEED_BASE:-60}
HINT=${HINT:-runs/copt-lp-hint/assignment-hint.json}
TAG=${TAG:-lphint}
ORIGINAL_OBJECTIVE=${ORIGINAL_OBJECTIVE:-0}
PARTIAL_HINT=${PARTIAL_HINT:-}
PRESERVE_BASE_ORDER=${PRESERVE_BASE_ORDER:-0}

objective_args=()
if [[ "$ORIGINAL_OBJECTIVE" == 1 ]]; then
  objective_args+=(--original-objective)
fi
hint_args=()
if [[ -n "$PARTIAL_HINT" ]]; then
  hint_args+=(--partial-hint "$PARTIAL_HINT")
fi
if [[ "$PRESERVE_BASE_ORDER" == 1 ]]; then
  hint_args+=(--preserve-base-order)
fi

cd "$ROOT"
for block in $BLOCKS; do
  outdir="runs/block-${TAG}-b${block}-exact"
  mkdir -p "$outdir"
  nohup setsid env CUDA_VISIBLE_DEVICES='' PYTHONUNBUFFERED=1 \
    python3 helper_block_solver.py \
      --model ns1905797.mps.gz \
      --assignment-hint "$HINT" \
      --block "$block" \
      --outdir "$outdir" \
      --time-limit "$TIME_LIMIT" \
      --workers "$WORKERS" \
      --random-seed "$((SEED_BASE + block))" \
      "${objective_args[@]}" \
      "${hint_args[@]}" \
      --log-search \
      >"$outdir/run.log" 2>&1 </dev/null &
  printf '%s\n' "$!" >"$outdir/pid"
  printf 'block=%s pid=%s outdir=%s\n' "$block" "$!" "$outdir"
done
