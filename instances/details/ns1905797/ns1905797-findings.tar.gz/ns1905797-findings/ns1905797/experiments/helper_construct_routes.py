#!/usr/bin/env python3
"""Construct native VRPTW routes for ns1905797 and replay the MPS exactly.

This is an independent primal heuristic.  It decodes travel/service increments
from the MPS, inserts the five optional reset nodes and mandatory lunch node by
dynamic programming for any fixed customer order, then uses randomized greedy
insertion across the four routes.  Any reported candidate is checked against
every original row with Fraction arithmetic.
"""

from __future__ import annotations

import argparse
import collections
import gzip
import hashlib
import json
import math
import random
import time
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path

from helper_route_logic import parse


SCALE = 100_000
WORK_SCALE = 5
TASKS = set(range(1, 61))
RESETS = set(range(61, 66))
LUNCH = 66


def sint(x: Fraction) -> int:
    y = x * SCALE
    if y.denominator != 1:
        raise ValueError(f"not integral at scale {SCALE}: {x}")
    return y.numerator


@dataclass(frozen=True)
class Label:
    time: int
    cost: int
    load: int
    used_mask: int
    lunch_used: bool
    sequence: tuple[int, ...]
    node_times: tuple[tuple[int, int], ...]
    node_loads: tuple[tuple[int, int], ...]


class Data:
    def __init__(self, model: Path):
        (self.senses, self.row_order, self.variables, self.cols, self.rows,
         self.rhs, self.lb, self.ub, self.integer) = parse(model)
        self.position = {v: i for i, v in enumerate(self.variables)}
        self.binaries = {
            v for v in self.integer if self.lb[v] == 0 and self.ub[v] == 1
        }
        incidence = collections.defaultdict(list)
        for node in range(67):
            for block in range(4):
                row = f"R{16413 + 4 * node + block:04d}"
                for variable, coefficient in self.rows[row]:
                    if variable in self.binaries:
                        incidence[variable].append((node, coefficient))
        self.arc_var = {}
        self.var_arc = {}
        for variable in self.binaries:
            tail = [n for n, c in incidence[variable] if c == -1]
            head = [n for n, c in incidence[variable] if c == 1]
            if len(tail) == len(head) == 1:
                arc = (tail[0], head[0], self.position[variable] % 4)
                self.var_arc[variable] = arc
                self.arc_var[arc] = variable
        if len(self.arc_var) != 17676:
            raise ValueError(f"recovered {len(self.arc_var)} arcs")

        unknown_rows = set()
        for terms in self.cols.values():
            unknown_rows.update(set(terms) - set(self.senses))
        nonempty = [
            row for row in unknown_rows
            if any(self.cols[v].get(row, 0) for v in self.variables)
        ]
        if len(nonempty) != 1:
            raise ValueError(f"cannot identify objective row: {nonempty}")
        self.objective_row = nonempty[0]

        self.time_lb = {node: sint(self.lb[self.variables[4 * node]]) for node in range(67)}
        self.time_ub = {node: sint(self.ub[self.variables[4 * node]]) for node in range(67)}
        self.direct = {}
        self.lunch_pair = {}
        for row in self.row_order:
            terms = self.rows[row]
            triggers = [(v, c) for v, c in terms if v in self.var_arc and c == 50]
            continuous = [(v, c) for v, c in terms if v not in self.integer]
            time_terms = [(v, c) for v, c in continuous if self.position[v] // 4 < 67]
            if self.senses[row] != "L" or len(time_terms) != 2:
                continue
            if len(triggers) == 1:
                variable = triggers[0][0]
                tail, head, block = self.var_arc[variable]
                coef = {self.position[v] // 4: c for v, c in time_terms}
                if coef.get(tail) == 1 and coef.get(head) == -1:
                    self.direct[(tail, head, block)] = sint(50 - self.rhs.get(row, 0))
            elif len(triggers) == 2:
                trig_arcs = [self.var_arc[v] for v, _ in triggers]
                for incoming in trig_arcs:
                    for outgoing in trig_arcs:
                        if incoming[1] == LUNCH and outgoing[0] == LUNCH and incoming[2] == outgoing[2]:
                            pred, succ, block = incoming[0], outgoing[1], incoming[2]
                            coef = {self.position[v] // 4: c for v, c in time_terms}
                            if coef.get(pred) == 1 and coef.get(succ) == -1:
                                self.lunch_pair[(pred, succ, block)] = sint(100 - self.rhs.get(row, 0))

        self.cost = {}
        for arc, variable in self.arc_var.items():
            self.cost[arc] = sint(self.cols[variable].get(self.objective_row, 0))

        # Work demand of task j is the active lower increment on 0->j.
        self.demand = {}
        start_arc_task = {
            self.arc_var[(0, task, 0)]: task for task in TASKS
        }
        for row in self.row_order:
            terms = self.rows[row]
            triggers = [
                v for v, c in terms if c == 50 and v in start_arc_task
            ]
            if len(triggers) != 1:
                continue
            work_terms = [
                (v, c) for v, c in terms
                if v not in self.integer and self.position[v] // 4 >= 67
            ]
            if len(work_terms) == 1 and work_terms[0][1] == -1:
                task = start_arc_task[triggers[0]]
                demand = 50 - self.rhs.get(row, 0)
                scaled = demand * WORK_SCALE
                if scaled.denominator != 1:
                    raise ValueError(f"bad demand {task}: {demand}")
                self.demand[task] = scaled.numerator
        if len(self.demand) != 60:
            raise ValueError(f"recovered {len(self.demand)} demands")

    def has_arc(self, i, j):
        return (i, j, 0) in self.arc_var


def advance(data: Data, label: Label, path: tuple[int, ...]) -> Label | None:
    current = label.sequence[-1]
    current_time = label.time
    load = label.load
    cost = label.cost
    used_mask = label.used_mask
    lunch_used = label.lunch_used
    sequence = list(label.sequence)
    node_times = dict(label.node_times)
    node_loads = dict(label.node_loads)
    lunch_pred = None
    lunch_pred_time = None
    for dest in path:
        if not data.has_arc(current, dest):
            return None
        duration = data.direct.get((current, dest, 0))
        if duration is None:
            return None
        prior_time = current_time
        current_time = max(data.time_lb[dest], current_time + duration)
        if current == LUNCH and lunch_pred is not None:
            pair = data.lunch_pair.get((lunch_pred, dest, 0))
            if pair is None:
                return None
            current_time = max(current_time, lunch_pred_time + pair)
        if current_time > data.time_ub[dest]:
            return None
        cost += data.cost[(current, dest, 0)]
        if dest in TASKS:
            if current == 0 or current in RESETS:
                load = data.demand[dest]
            else:
                load += data.demand[dest]
            if load > 10 * WORK_SCALE:
                return None
            node_loads[dest] = load
        elif dest in RESETS:
            bit = 1 << (dest - 61)
            if used_mask & bit:
                return None
            used_mask |= bit
            load = 0
        elif dest == LUNCH:
            if lunch_used:
                return None
            lunch_used = True
            lunch_pred = current
            lunch_pred_time = prior_time
            node_loads[LUNCH] = load
        node_times[dest] = current_time
        sequence.append(dest)
        current = dest
    return Label(
        current_time, cost, load, used_mask, lunch_used, tuple(sequence),
        tuple(sorted(node_times.items())), tuple(sorted(node_loads.items())),
    )


def insert_paths(label: Label, first_task: bool):
    if first_task:
        return [()]
    paths = [()]
    unused = [node for node in RESETS if not (label.used_mask & (1 << (node - 61)))]
    paths.extend((node,) for node in unused)
    if not label.lunch_used:
        paths.append((LUNCH,))
        for node in unused:
            paths.append((node, LUNCH))
            paths.append((LUNCH, node))
    return paths


def schedule_order(data: Data, tasks: tuple[int, ...]) -> Label | None:
    if not tasks:
        return None
    labels = {
        (0, False, 0): Label(
            data.time_lb[0], 0, 0, 0, False, (0,), ((0, data.time_lb[0]),), (),
        )
    }
    for index, task in enumerate(tasks):
        next_labels = {}
        for label in labels.values():
            for middle in insert_paths(label, index == 0):
                candidate = advance(data, label, middle + (task,))
                if candidate is None:
                    continue
                key = (candidate.used_mask, candidate.lunch_used, candidate.load)
                incumbent = next_labels.get(key)
                if incumbent is None or (candidate.time, candidate.cost) < (incumbent.time, incumbent.cost):
                    next_labels[key] = candidate
        labels = next_labels
        if not labels:
            return None

    complete = []
    total_demand = sum(data.demand[t] for t in tasks)
    for label in labels.values():
        for terminal in (62, 65):
            if label.used_mask & (1 << (terminal - 61)):
                continue
            path = (terminal,) if label.lunch_used else (LUNCH, terminal)
            candidate = advance(data, label, path)
            if candidate is None:
                continue
            z = candidate.used_mask.bit_count()
            if total_demand > 10 * WORK_SCALE * z:
                continue
            if not data.has_arc(terminal, 0):
                continue
            complete.append(Label(
                candidate.time,
                candidate.cost + data.cost[(terminal, 0, 0)],
                0, candidate.used_mask, True,
                candidate.sequence + (0,), candidate.node_times, candidate.node_loads,
            ))
    return min(complete, key=lambda x: (x.time, x.cost)) if complete else None


def constructive_search(data: Data, seed: int, restarts: int, deadline: float):
    rng = random.Random(seed)
    cache = {}

    def evaluate(route):
        key = tuple(route)
        if key not in cache:
            cache[key] = schedule_order(data, key)
        return cache[key]

    task_key = lambda t: (data.time_ub[t], -data.demand[t], rng.random())
    for restart in range(restarts):
        if time.time() >= deadline:
            break
        ordered = sorted(TASKS, key=task_key)
        # Spread the four most mutually distant hard-window tasks as seeds.
        first = ordered.pop(0)
        seeds = [first]
        while len(seeds) < 4:
            pool = ordered[: max(12, len(seeds) * 5)]
            chosen = max(
                pool,
                key=lambda t: min(data.cost[(t, s, 0)] + data.cost[(s, t, 0)] for s in seeds)
                + rng.randrange(1000),
            )
            seeds.append(chosen)
            ordered.remove(chosen)
        routes = [[s] for s in seeds]
        schedules = [evaluate(route) for route in routes]
        if any(s is None for s in schedules):
            continue
        failed = False
        for task in ordered:
            candidates = []
            for r, route in enumerate(routes):
                if len(route) >= 19:
                    continue
                old = schedules[r]
                for pos in range(len(route) + 1):
                    trial = route[:pos] + [task] + route[pos:]
                    result = evaluate(trial)
                    if result is None:
                        continue
                    balance = 30_000 * max(0, len(trial) - 15) ** 2
                    delta = result.time - old.time + (result.cost - old.cost) // 10 + balance
                    candidates.append((delta, rng.random(), r, pos, result))
            if not candidates:
                failed = True
                break
            candidates.sort()
            width = min(len(candidates), 1 + restart % 5)
            _, _, r, pos, result = candidates[rng.randrange(width)]
            routes[r].insert(pos, task)
            schedules[r] = result
        if not failed and all(schedules):
            return routes, schedules, restart + 1, len(cache)
    return None, None, min(restarts, restart + 1), len(cache)


def exact_candidate(data: Data, schedules: list[Label]):
    values = {v: Fraction(0) for v in data.variables}
    selected_arcs = []
    route_records = []
    for block, schedule in enumerate(schedules):
        sequence = schedule.sequence
        for i, j in zip(sequence, sequence[1:]):
            variable = data.arc_var[(i, j, block)]
            values[variable] = Fraction(1)
            selected_arcs.append((i, j, block))
        times = dict(schedule.node_times)
        loads = dict(schedule.node_loads)
        for node in range(67):
            variable = data.variables[4 * node + block]
            values[variable] = Fraction(times.get(node, data.time_lb[node]), SCALE)
        for logical in range(61):
            node = logical + 1 if logical < 60 else LUNCH
            variable = data.variables[4 * (67 + logical) + block]
            values[variable] = Fraction(loads.get(node, 0), WORK_SCALE)
        zvar = data.variables[-4 + block]
        values[zvar] = Fraction(schedule.used_mask.bit_count())
        route_records.append({
            "block": block + 1,
            "sequence": list(sequence),
            "end_time": schedule.time / SCALE,
            "cost": schedule.cost / SCALE,
            "z": schedule.used_mask.bit_count(),
        })

    bound_violations = []
    integrality_violations = []
    for variable, value in values.items():
        if value < data.lb[variable] or value > data.ub[variable]:
            bound_violations.append([variable, str(value)])
        if variable in data.integer and value.denominator != 1:
            integrality_violations.append([variable, str(value)])
    row_violations = []
    worst = Fraction(0)
    for row in data.row_order:
        activity = sum(c * values[v] for v, c in data.rows[row])
        rhs = data.rhs.get(row, Fraction(0))
        sense = data.senses[row]
        violation = abs(activity - rhs) if sense == "E" else max(Fraction(0), activity - rhs) if sense == "L" else max(Fraction(0), rhs - activity)
        if violation:
            row_violations.append([row, str(activity), sense, str(rhs), str(violation)])
            worst = max(worst, violation)
    objective = sum(data.cols[v].get(data.objective_row, 0) * values[v] for v in data.variables)
    return values, route_records, {
        "valid": not bound_violations and not integrality_violations and not row_violations,
        "objective_fraction": str(objective),
        "objective_decimal": float(objective),
        "bound_violation_count": len(bound_violations),
        "integrality_violation_count": len(integrality_violations),
        "row_violation_count": len(row_violations),
        "maximum_exact_row_violation": str(worst),
        "bound_violations": bound_violations[:20],
        "integrality_violations": integrality_violations[:20],
        "row_violations": row_violations[:50],
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=Path, required=True)
    ap.add_argument("--outdir", type=Path, required=True)
    ap.add_argument("--time-limit", type=float, default=300)
    ap.add_argument("--restarts", type=int, default=100)
    ap.add_argument("--seed", type=int, default=41)
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    started = time.time()
    data = Data(args.model)
    routes, schedules, attempts, cache_size = constructive_search(
        data, args.seed, args.restarts, started + args.time_limit,
    )
    result = {
        "schema": "ns1905797-native-route-construction-v1",
        "input_sha256": hashlib.sha256(args.model.read_bytes()).hexdigest(),
        "parameters": {"time_limit": args.time_limit, "restarts": args.restarts, "seed": args.seed},
        "attempts": attempts,
        "evaluated_orders": cache_size,
        "wall_seconds": time.time() - started,
        "status": "NO_CONSTRUCTION",
    }
    if routes is not None:
        values, records, validation = exact_candidate(data, schedules)
        result.update({"status": "VALID_FEASIBLE" if validation["valid"] else "CONSTRUCTION_INVALID", "routes": records, "validation": validation})
        if validation["valid"]:
            with (args.outdir / "candidate.sol").open("w", encoding="ascii") as stream:
                stream.write(f"# Objective value = {validation['objective_decimal']:.17g}\n")
                for variable in data.variables:
                    if values[variable]:
                        stream.write(f"{variable} {float(values[variable]):.17g}\n")
    (args.outdir / "result.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
