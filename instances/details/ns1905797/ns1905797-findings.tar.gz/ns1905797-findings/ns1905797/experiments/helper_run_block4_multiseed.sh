#!/usr/bin/env bash
set -euo pipefail

ROOT=${ROOT:-/home/huangyicheng/miplib_ns190}
SEEDS=${SEEDS:-"101 102 103 104 105 106"}
TIME_LIMIT=${TIME_LIMIT:-300}
WORKERS=${WORKERS:-8}

cd "$ROOT"
for seed in $SEEDS; do
  outdir="runs/block-lphint-b4-seed${seed}"
  mkdir -p "$outdir"
  nohup setsid env CUDA_VISIBLE_DEVICES='' PYTHONUNBUFFERED=1 \
    python3 helper_block_solver.py \
      --model ns1905797.mps.gz \
      --assignment-hint runs/copt-lp-hint/assignment-hint.json \
      --block 4 \
      --outdir "$outdir" \
      --time-limit "$TIME_LIMIT" \
      --workers "$WORKERS" \
      --random-seed "$seed" \
      --log-search \
      >"$outdir/run.log" 2>&1 </dev/null &
  printf '%s\n' "$!" >"$outdir/pid"
  printf 'seed=%s pid=%s outdir=%s\n' "$seed" "$!" "$outdir"
done
