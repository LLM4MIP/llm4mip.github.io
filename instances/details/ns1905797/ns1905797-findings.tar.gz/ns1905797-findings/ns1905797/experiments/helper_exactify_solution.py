#!/usr/bin/env python3
"""Round a numerical solver solution to the proven exact ns1905797 lattice."""

from __future__ import annotations

import argparse
import json
from fractions import Fraction
from pathlib import Path

from helper_route_logic import parse


SCALE = 100000


def nearest_integer(value: Fraction) -> int:
    if value >= 0:
        return (2 * value.numerator + value.denominator) // (2 * value.denominator)
    positive = -value
    return -((2 * positive.numerator + positive.denominator) // (2 * positive.denominator))


def exact_decimal(value: Fraction) -> str:
    raw_value = value * SCALE
    if raw_value.denominator != 1:
        raise ValueError(f"off-lattice output value {value}")
    raw = raw_value.numerator
    sign = "-" if raw < 0 else ""
    whole, remainder = divmod(abs(raw), SCALE)
    if not remainder:
        return f"{sign}{whole}"
    return f"{sign}{whole}.{remainder:05d}".rstrip("0")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=Path, required=True)
    ap.add_argument("--input-solution", type=Path, required=True)
    ap.add_argument("--output-solution", type=Path, required=True)
    ap.add_argument("--report", type=Path, required=True)
    ap.add_argument("--max-grid-error", type=Fraction, default=Fraction(1, 1000),
                    help="maximum error measured in units of the target grid")
    args = ap.parse_args()

    senses, _, variables, columns, _, _, _, _, integer = parse(args.model)
    variable_set = set(variables)
    numerical = {}
    for line_number, line in enumerate(
        args.input_solution.read_text(encoding="ascii").splitlines(), 1
    ):
        pieces = line.split()
        if not pieces or pieces[0].startswith("#"):
            continue
        if len(pieces) != 2 or pieces[0] not in variable_set:
            raise ValueError(f"{args.input_solution}:{line_number}: malformed solution row")
        numerical[pieces[0]] = Fraction(pieces[1])

    normalized = {}
    maximum_grid_error = Fraction(0)
    for variable in variables:
        value = numerical.get(variable, Fraction(0))
        if variable in integer:
            rounded = nearest_integer(value)
            error = abs(value - rounded)
            if error > Fraction(1, 1_000_000):
                raise ValueError(f"integer {variable} is too far from integral: {value}")
            normalized[variable] = Fraction(rounded)
        else:
            grid_value = value * SCALE
            rounded = nearest_integer(grid_value)
            error = abs(grid_value - rounded)
            maximum_grid_error = max(maximum_grid_error, error)
            if error > args.max_grid_error:
                raise ValueError(f"continuous {variable} is too far from 1/{SCALE}: {value}")
            normalized[variable] = Fraction(rounded, SCALE)

    objective_rows = {
        row for terms in columns.values() for row, coefficient in terms.items()
        if row not in senses and coefficient
    }
    if len(objective_rows) != 1:
        raise ValueError(f"cannot identify objective: {objective_rows}")
    objective_row = next(iter(objective_rows))
    objective = sum(
        columns[variable].get(objective_row, 0) * normalized[variable]
        for variable in variables
    )
    args.output_solution.parent.mkdir(parents=True, exist_ok=True)
    with args.output_solution.open("w", encoding="ascii", newline="\n") as stream:
        stream.write(f"# Objective value = {exact_decimal(objective)}\n")
        for variable in variables:
            if normalized[variable]:
                stream.write(f"{variable} {exact_decimal(normalized[variable])}\n")
    report = {
        "schema": "ns1905797-numerical-solution-exactification-v1",
        "input_solution": str(args.input_solution),
        "output_solution": str(args.output_solution),
        "variables": len(variables),
        "integer_variables": len(integer),
        "continuous_variables": len(variables) - len(integer),
        "scale": SCALE,
        "maximum_grid_error": str(maximum_grid_error),
        "objective_fraction": str(objective),
        "objective_decimal": float(objective),
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
