#!/usr/bin/env bash
set -euo pipefail

# CPU-only comparison: optimize the original objective and pure feasibility in
# parallel.  The two independent runs use 64 of altman's 192 logical CPUs.
export CUDA_VISIBLE_DEVICES=""
export PYTHONPATH="/home/huangyicheng/copt80/lib/python/310"
export LD_LIBRARY_PATH="/home/huangyicheng/copt80/lib:/home/huangyicheng/copt80/lib/python/deps"

run_root="${1:-/home/huangyicheng/miplib_ns190}"
time_limit="${2:-1200}"
threads="${3:-32}"
cd "$run_root"
mkdir -p runs/aggressive runs/feasibility

python3 run_copt_baseline.py \
  --model ns1905797.mps.gz \
  --outdir runs/aggressive \
  --time-limit "$time_limit" \
  --threads "$threads" \
  --mode aggressive \
  > runs/aggressive/console.log 2>&1 &
pid_aggressive=$!

python3 run_copt_baseline.py \
  --model ns1905797.mps.gz \
  --outdir runs/feasibility \
  --time-limit "$time_limit" \
  --threads "$threads" \
  --mode feasibility \
  > runs/feasibility/console.log 2>&1 &
pid_feasibility=$!

printf 'aggressive_pid=%s\nfeasibility_pid=%s\n' "$pid_aggressive" "$pid_feasibility"
wait "$pid_aggressive"
wait "$pid_feasibility"
