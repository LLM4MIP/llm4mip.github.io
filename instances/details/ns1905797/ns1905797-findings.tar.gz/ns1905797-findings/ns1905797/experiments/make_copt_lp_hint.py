#!/usr/bin/env python3
"""Solve the LP relaxation and export block-assignment hints for CP-SAT."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import platform
import time
from pathlib import Path

import coptpy as cp


def master_row_variables(path: Path) -> tuple[list[str], dict[str, list[str]]]:
    """Read variable order and the 60 assignment rows without a solver API."""
    opener = gzip.open if path.suffix == ".gz" else open
    variable_order: list[str] = []
    seen: set[str] = set()
    master = {f"R{task:04d}": [] for task in range(1, 61)}
    section = ""
    with opener(path, "rt", encoding="ascii") as stream:
        for raw in stream:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            keyword = tokens[0].upper()
            if keyword in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = keyword
                continue
            if section != "COLUMNS":
                continue
            if len(tokens) >= 3 and tokens[1].strip("'").upper() == "MARKER":
                continue
            variable = tokens[0]
            if variable not in seen:
                seen.add(variable)
                variable_order.append(variable)
            for position in range(1, len(tokens), 2):
                row = tokens[position]
                if row in master and float(tokens[position + 1]) != 0.0:
                    master[row].append(variable)
    return variable_order, master


def get_attr(model, attribute, default=None):
    try:
        return model.getAttr(attribute)
    except Exception:
        return default


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--threads", type=int, default=16)
    parser.add_argument("--time-limit", type=float, default=300.0)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    variable_order, master = master_row_variables(args.model)
    position = {name: index for index, name in enumerate(variable_order)}

    environment = cp.Envr()
    model = environment.createModel("ns1905797-lp")
    model.read(str(args.model))
    model.setLogFile(str(args.outdir / "solver.log"))
    model.setParam(cp.COPT.Param.Threads, args.threads)
    model.setParam(cp.COPT.Param.TimeLimit, args.time_limit)
    model.setParam(cp.COPT.Param.GPUMode, 0)
    variables = model.getVars()
    by_name = {variable.name: variable for variable in variables}
    for variable in variables:
        variable.setType(cp.COPT.CONTINUOUS)

    started = time.time()
    model.solve()
    elapsed = time.time() - started
    values = model.getInfo(cp.COPT.Info.Value, variables)
    value_by_name = {variable.name: value for variable, value in zip(variables, values)}

    assignment_scores: list[list[float]] = []
    selected_blocks_raw: list[int] = []
    for task in range(1, 61):
        scores = []
        for block in range(4):
            scores.append(
                sum(
                    value_by_name[name]
                    for name in master[f"R{task:04d}"]
                    if position[name] % 4 == block
                )
            )
        assignment_scores.append(scores)
        selected_blocks_raw.append(max(range(4), key=scores.__getitem__) + 1)

    # CP-SAT uses a first-use partitioning orbitope.  Relabel the four
    # exchangeable LP blocks into that canonical order before exporting hints.
    relabel: dict[int, int] = {}
    selected_blocks: list[int] = []
    for block in selected_blocks_raw:
        if block not in relabel:
            relabel[block] = len(relabel) + 1
        selected_blocks.append(relabel[block])

    result = {
        "schema": "ns1905797-copt-lp-assignment-hint-v1",
        "input": str(args.model),
        "input_sha256": hashlib.sha256(args.model.read_bytes()).hexdigest(),
        "host": platform.node(),
        "solver": "COPT",
        "solver_version": [
            cp.COPT.VERSION_MAJOR,
            cp.COPT.VERSION_MINOR,
            cp.COPT.VERSION_TECHNICAL,
        ],
        "cpu_only": True,
        "wall_seconds": elapsed,
        "lp_status": get_attr(model, cp.COPT.Attr.LpStatus),
        "lp_objective": get_attr(model, cp.COPT.Attr.LpObjVal),
        "assignment_scores": assignment_scores,
        "selected_blocks_raw": selected_blocks_raw,
        "canonical_block_relabeling": relabel,
        "selected_blocks": selected_blocks,
    }
    (args.outdir / "assignment-hint.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print("RESULT_JSON=" + json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
