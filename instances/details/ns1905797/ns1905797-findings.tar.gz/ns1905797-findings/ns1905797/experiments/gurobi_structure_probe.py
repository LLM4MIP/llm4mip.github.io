#!/usr/bin/env python3
"""Read an MPS with Gurobi and emit a deterministic structural audit.

This program deliberately does not optimize the model.  It is used to make
the first-pass semantic inventory reproducible even on a size-limited Gurobi
license.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
from collections import Counter
from pathlib import Path

import gurobipy as gp


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def family(name: str) -> str:
    """Collapse numeric indices while retaining the readable name stem."""
    stem = re.split(r"(?=\d)|[\[(](?=\d)", name, maxsplit=1)[0]
    return stem or "<numeric>"


class DSU:
    def __init__(self, size: int):
        self.parent = list(range(size))
        self.weight = [1] * size

    def find(self, item: int) -> int:
        while self.parent[item] != item:
            self.parent[item] = self.parent[self.parent[item]]
            item = self.parent[item]
        return item

    def union(self, left: int, right: int) -> None:
        left, right = self.find(left), self.find(right)
        if left == right:
            return
        if self.weight[left] < self.weight[right]:
            left, right = right, left
        self.parent[right] = left
        self.weight[left] += self.weight[right]


def quantiles(values: list[int]) -> dict[str, float | int]:
    ordered = sorted(values)
    if not ordered:
        return {}
    def at(frac: float) -> int:
        return ordered[round(frac * (len(ordered) - 1))]
    return {
        "min": ordered[0],
        "q25": at(0.25),
        "median": at(0.5),
        "q75": at(0.75),
        "max": ordered[-1],
        "mean": sum(ordered) / len(ordered),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    model = gp.read(str(args.model))
    model.Params.OutputFlag = 0
    model.update()
    variables = model.getVars()
    constraints = model.getConstrs()
    dsu = DSU(len(variables) + len(constraints))
    matrix_hash = hashlib.sha256()
    row_sizes: list[int] = []
    row_signatures: Counter = Counter()
    coefficient_values: Counter = Counter()

    for row_index, constraint in enumerate(constraints):
        expression = model.getRow(constraint)
        row_sizes.append(expression.size())
        coefficients = []
        for position in range(expression.size()):
            variable = expression.getVar(position)
            coefficient = expression.getCoeff(position)
            coefficients.append(format(coefficient, ".17g"))
            coefficient_values[format(coefficient, ".12g")] += 1
            dsu.union(variable.index, len(variables) + row_index)
            matrix_hash.update(f"{row_index}:{variable.index}:{coefficient:.17g}\n".encode())
        pattern = tuple(sorted(Counter(coefficients).items()))
        row_signatures[(constraint.Sense, format(constraint.RHS, ".17g"), expression.size(), pattern)] += 1

    column_sizes: list[int] = []
    column_signatures: Counter = Counter()
    for variable in variables:
        column = model.getCol(variable)
        column_sizes.append(column.size())
        coefficient_pattern = tuple(
            sorted(Counter(format(column.getCoeff(i), ".12g") for i in range(column.size())).items())
        )
        column_signatures[(variable.VType, column.size(), format(variable.Obj, ".17g"), coefficient_pattern)] += 1

    component_sizes = Counter(dsu.find(i) for i in range(len(variables) + len(constraints)))
    gen_types = Counter(gc.GenConstrType for gc in model.getGenConstrs())
    indicator_samples = []
    for general in model.getGenConstrs():
        if general.GenConstrType != gp.GRB.GENCONSTR_INDICATOR:
            continue
        binary, value, expression, sense, rhs = model.getGenConstrIndicator(general)
        if len(indicator_samples) < 30:
            indicator_samples.append({
                "name": general.GenConstrName,
                "binary": binary.VarName,
                "binary_value": int(value),
                "sense": sense,
                "rhs": rhs,
                "nnz": expression.size(),
                "terms": [
                    [expression.getVar(i).VarName, expression.getCoeff(i)]
                    for i in range(min(expression.size(), 12))
                ],
            })

    report = {
        "schema": "gurobi-read-structure-v1",
        "gurobi_version": list(gp.gurobi.version()),
        "input": str(args.model),
        "input_sha256": sha256(args.model),
        "read_only": True,
        "optimization_attempted": False,
        "model": {
            "name": model.ModelName,
            "sense": "min" if model.ModelSense == gp.GRB.MINIMIZE else "max",
            "variables": model.NumVars,
            "linear_constraints": model.NumConstrs,
            "general_constraints": model.NumGenConstrs,
            "nonzeros": model.NumNZs,
            "variable_types": dict(Counter(v.VType for v in variables)),
            "constraint_senses": dict(Counter(c.Sense for c in constraints)),
            "general_constraint_types": {str(k): v for k, v in gen_types.items()},
            "objective_nonzeros": sum(v.Obj != 0 for v in variables),
            "objective_constant": model.ObjCon,
            "objective_patterns": Counter(format(v.Obj, ".12g") for v in variables).most_common(30),
            "bound_patterns": Counter(
                (v.VType, format(v.LB, ".12g"), format(v.UB, ".12g")) for v in variables
            ).most_common(30),
            "variable_name_families": Counter(family(v.VarName) for v in variables).most_common(50),
            "constraint_name_families": Counter(family(c.ConstrName) for c in constraints).most_common(50),
            "variable_samples": [v.VarName for v in variables[:60]],
            "constraint_samples": [c.ConstrName for c in constraints[:60]],
            "row_nnz": quantiles(row_sizes),
            "column_nnz": quantiles(column_sizes),
            "row_signatures_top": [
                {"sense": key[0], "rhs": key[1], "nnz": key[2], "coefficients": key[3], "count": count}
                for key, count in row_signatures.most_common(40)
            ],
            "column_signatures_top": [
                {"type": key[0], "nnz": key[1], "objective": key[2], "coefficients": key[3], "count": count}
                for key, count in column_signatures.most_common(40)
            ],
            "coefficient_values_top": coefficient_values.most_common(40),
            "bipartite_component_sizes": sorted(component_sizes.values(), reverse=True)[:100],
            "matrix_ordered_sha256": matrix_hash.hexdigest(),
            "indicator_samples": indicator_samples,
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "gurobi_version": report["gurobi_version"],
        "variables": model.NumVars,
        "linear_constraints": model.NumConstrs,
        "general_constraints": model.NumGenConstrs,
        "nonzeros": model.NumNZs,
        "variable_types": report["model"]["variable_types"],
        "components": report["model"]["bipartite_component_sizes"][:10],
    }, indent=2))


if __name__ == "__main__":
    main()
