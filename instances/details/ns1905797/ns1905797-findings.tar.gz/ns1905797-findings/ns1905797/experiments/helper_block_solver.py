#!/usr/bin/env python3
"""Solve one exact ns1905797 route block after fixing all 60 assignments.

Once a task-to-block vector is fixed, the only cross-block rows (R0001--R0060)
separate into four local outgoing-degree equations.  This script builds just one
4,548-variable route block, retains every local original row, adds equivalent
integer potentials at scale 100000, and strengthens it with native reified
big-M implications and a redundant Circuit constraint.

INFEASIBLE proves only that the supplied assignment is impossible for this
block; UNKNOWN is a timeout and makes no feasibility claim about it.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import platform
import time
from fractions import Fraction
from pathlib import Path

import ortools
from ortools.sat.python import cp_model

from solve_exact_cpsat import parse_mps, transpose_rows


def lcm(values):
    result = 1
    for value in values:
        result = math.lcm(result, int(value))
    return result


def scaled(value: Fraction, factor: int):
    product = value * factor
    if product.denominator != 1:
        raise ValueError(f"{value} is not integral at scale {factor}")
    return product.numerator


def recover_arcs(parsed, rows, block_variables, block):
    binaries = {
        v for v in block_variables
        if v in parsed.integer_variables and parsed.lower[v] == 0 and parsed.upper[v] == 1
    }
    incidence = {v: [] for v in binaries}
    for node in range(67):
        row = f"R{16413 + 4 * node + block:04d}"
        for variable, coefficient in rows[row]:
            if variable in incidence:
                incidence[variable].append((node, coefficient))
    arcs = {}
    for variable, entries in incidence.items():
        tail = [node for node, coefficient in entries if coefficient == -1]
        head = [node for node, coefficient in entries if coefficient == 1]
        if len(tail) == len(head) == 1:
            arcs[variable] = (tail[0], head[0])
    if len(arcs) != 4419:
        raise ValueError(f"expected 4419 block arcs, recovered {len(arcs)}")
    return arcs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=Path, required=True)
    ap.add_argument("--assignment-hint", type=Path, required=True)
    ap.add_argument("--block", type=int, choices=(1, 2, 3, 4), required=True)
    ap.add_argument("--outdir", type=Path, required=True)
    ap.add_argument("--time-limit", type=float, default=600)
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--random-seed", type=int, default=51)
    ap.add_argument("--log-search", action="store_true")
    ap.add_argument(
        "--original-objective",
        action="store_true",
        help="minimize the original rational arc cost to guide primal search",
    )
    ap.add_argument(
        "--partial-hint",
        type=Path,
        help="sparse NAME VALUE solution from a related assignment, used only as a CP hint",
    )
    ap.add_argument(
        "--preserve-base-order",
        action="store_true",
        help="with --partial-hint, restrict search to inserting new tasks/specials without reordering base nodes",
    )
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    block = args.block - 1
    started = time.time()

    parsed = parse_mps(args.model)
    rows = transpose_rows(parsed)
    position = {v: i for i, v in enumerate(parsed.variable_order)}
    block_variables = [v for v in parsed.variable_order if position[v] % 4 == block]
    block_set = set(block_variables)
    if len(block_variables) != 4548:
        raise ValueError(f"expected 4548 variables, got {len(block_variables)}")
    continuous = {v for v in block_variables if v not in parsed.integer_variables}
    denominators = []
    for variable in continuous:
        denominators.extend((parsed.lower[variable].denominator, parsed.upper[variable].denominator))
    for row in parsed.row_order:
        local_terms = [(v, c) for v, c in rows[row] if v in block_set]
        if any(v in continuous for v, _ in local_terms):
            denominators.append(parsed.rhs.get(row, Fraction(0)).denominator)
            denominators.extend(c.denominator for v, c in local_terms if v not in continuous)
    continuous_scale = lcm(denominators)
    if continuous_scale != 100000:
        raise ValueError(f"unexpected continuous scale {continuous_scale}")

    model = cp_model.CpModel()
    cpvars = {}
    for variable in block_variables:
        lower, upper = parsed.lower[variable], parsed.upper[variable]
        if variable in continuous:
            lo, hi = scaled(lower, continuous_scale), scaled(upper, continuous_scale)
        else:
            if lower.denominator != 1 or upper.denominator != 1:
                raise ValueError(f"nonintegral integer bounds on {variable}")
            lo, hi = lower.numerator, upper.numerator
        cpvars[variable] = model.new_int_var(lo, hi, variable)

    hint = json.loads(args.assignment_hint.read_text(encoding="utf-8"))
    selected = hint["selected_blocks"]
    if len(selected) != 60:
        raise ValueError("assignment hint must contain 60 tasks")
    assigned_tasks = {task for task in range(1, 61) if selected[task - 1] == args.block}

    local_rows = 0
    split_master_rows = 0
    reified_rows = 0
    for row in parsed.row_order:
        terms = [(v, c) for v, c in rows[row] if v in block_set]
        if not terms:
            continue
        foreign = [(v, c) for v, c in rows[row] if v not in block_set]
        if foreign:
            if not (1 <= int(row[1:]) <= 60):
                raise ValueError(f"unexpected cross-block row {row}")
            rhs = Fraction(int(int(row[1:]) in assigned_tasks))
            split_master_rows += 1
        else:
            rhs = parsed.rhs.get(row, Fraction(0))
            local_rows += 1
        has_cont = any(v in continuous for v, _ in terms)
        if has_cont:
            factor = continuous_scale
            int_terms = [
                (cpvars[v], c.numerator if v in continuous and c.denominator == 1 else scaled(c, factor))
                for v, c in terms
            ]
            int_rhs = scaled(rhs, factor)
        else:
            factor = lcm([rhs.denominator] + [c.denominator for _, c in terms])
            int_terms = [(cpvars[v], scaled(c, factor)) for v, c in terms]
            int_rhs = scaled(rhs, factor)
        expression = sum(c * v for v, c in int_terms)
        sense = parsed.row_sense[row]
        if sense == "E": model.add(expression == int_rhs)
        elif sense == "L": model.add(expression <= int_rhs)
        elif sense == "G": model.add(expression >= int_rhs)
        else: raise ValueError(sense)

        # Safe redundant enforcement strengthening; originals stay in the model.
        if sense == "L":
            cterms = [(v, c) for v, c in terms if v in continuous]
            dterms = [(v, c) for v, c in terms if v not in continuous]
            triggers = [v for v, c in dterms if c == 50 and parsed.lower[v] == 0 and parsed.upper[v] == 1]
            if cterms and len(triggers) in (1, 2) and len(triggers) == len(dterms):
                active_rhs = rhs - 50 * len(triggers)
                enforced = sum(c.numerator * cpvars[v] for v, c in cterms)
                model.add(enforced <= scaled(active_rhs, continuous_scale)).only_enforce_if(
                    [cpvars[v] for v in triggers]
                )
                reified_rows += 1

    arcs = recover_arcs(parsed, rows, block_variables, block)
    order_fixed_zero_arcs = 0
    base_sequence = None
    if args.preserve_base_order:
        if not args.partial_hint:
            raise ValueError("--preserve-base-order requires --partial-hint")
        sparse = {}
        for line in args.partial_hint.read_text(encoding="ascii").splitlines():
            stripped = line.strip()
            if stripped and not stripped.startswith("#"):
                variable, raw = stripped.split()
                sparse[variable] = Fraction(raw)
        successor = {
            tail: head for variable, (tail, head) in arcs.items()
            if sparse.get(variable, 0) == 1
        }
        base_sequence = [0]
        while len(base_sequence) <= 68:
            if base_sequence[-1] not in successor:
                raise ValueError(f"partial route has no successor for {base_sequence[-1]}")
            base_sequence.append(successor[base_sequence[-1]])
            if base_sequence[-1] == 0:
                break
        if base_sequence[-1] != 0:
            raise ValueError("partial route does not close at node 0")
        base_tasks = {node for node in base_sequence if 1 <= node <= 60}
        if not base_tasks <= assigned_tasks:
            raise ValueError("base partial contains tasks removed by the new assignment")
        insert_nodes = (assigned_tasks - base_tasks) | ({61, 62, 63, 64, 65} - set(base_sequence))
        allowed_pairs = set(zip(base_sequence, base_sequence[1:]))
        for tail, head in zip(base_sequence, base_sequence[1:]):
            for node in insert_nodes:
                allowed_pairs.add((tail, node))
                allowed_pairs.add((node, head))
        allowed_pairs.update(
            (left, right) for left in insert_nodes for right in insert_nodes if left != right
        )
        for variable, pair in arcs.items():
            if pair not in allowed_pairs:
                model.add(cpvars[variable] == 0)
                order_fixed_zero_arcs += 1
    circuit = [(i, j, cpvars[v]) for v, (i, j) in arcs.items()]
    for task in range(1, 61):
        circuit.append((task, task, model.new_constant(int(task not in assigned_tasks))))
    for node in range(61, 66):
        used = model.new_bool_var(f"used_special_{node}")
        circuit.append((node, node, used.Not()))
    model.add_circuit(circuit)

    objective_scale = None
    if args.original_objective:
        objective_coefficients = {
            variable: parsed.columns[variable].get(parsed.objective_row, Fraction(0))
            for variable in block_variables
        }
        objective_scale = lcm(coefficient.denominator for coefficient in objective_coefficients.values())
        model.minimize(sum(
            scaled(coefficient, objective_scale) * cpvars[variable]
            for variable, coefficient in objective_coefficients.items() if coefficient
        ))

    hinted_variables = 0
    if args.partial_hint:
        for line_number, line in enumerate(
            args.partial_hint.read_text(encoding="ascii").splitlines(), 1
        ):
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            pieces = stripped.split()
            if len(pieces) != 2:
                raise ValueError(f"{args.partial_hint}:{line_number}: expected NAME VALUE")
            variable, raw = pieces
            if variable not in block_set:
                continue
            value = Fraction(raw)
            if variable in continuous:
                scaled_value = value * continuous_scale
                hint_value = round(float(scaled_value))
                if abs(scaled_value - hint_value) > Fraction(1, 10000):
                    raise ValueError(f"off-lattice partial hint {variable}={value}")
            else:
                if value.denominator != 1:
                    raise ValueError(f"nonintegral partial hint {variable}={value}")
                hint_value = value.numerator
            model.add_hint(cpvars[variable], hint_value)
            hinted_variables += 1

    build_seconds = time.time() - started
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = args.time_limit
    solver.parameters.num_search_workers = args.workers
    solver.parameters.random_seed = args.random_seed
    solver.parameters.randomize_search = True
    solver.parameters.symmetry_level = 3
    solver.parameters.linearization_level = 2
    solver.parameters.log_search_progress = args.log_search
    solve_started = time.time()
    status = solver.solve(model)
    solve_seconds = time.time() - solve_started
    result = {
        "schema": "ns1905797-fixed-assignment-block-cpsat-v1",
        "input_sha256": hashlib.sha256(args.model.read_bytes()).hexdigest(),
        "host": platform.node(),
        "ortools_version": ortools.__version__,
        "cpu_only": True,
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES", ""),
        "block": args.block,
        "assigned_tasks": sorted(assigned_tasks),
        "assigned_task_count": len(assigned_tasks),
        "variables": len(block_variables),
        "continuous_variables": len(continuous),
        "original_local_rows": local_rows,
        "split_master_rows": split_master_rows,
        "reified_rows": reified_rows,
        "native_circuit_constraints": 1,
        "continuous_scale": continuous_scale,
        "parameters": {"time_limit": args.time_limit, "workers": args.workers, "random_seed": args.random_seed},
        "build_seconds": build_seconds,
        "solve_wall_seconds": solve_seconds,
        "status": solver.status_name(status),
        "num_conflicts": solver.num_conflicts,
        "num_branches": solver.num_branches,
        "response_stats": solver.response_stats(),
        "original_objective": args.original_objective,
        "objective_scale": objective_scale,
        "partial_hint": str(args.partial_hint) if args.partial_hint else None,
        "hinted_variables": hinted_variables,
        "preserve_base_order": args.preserve_base_order,
        "base_sequence": base_sequence,
        "order_fixed_zero_arcs": order_fixed_zero_arcs,
    }
    if args.original_objective and status in {cp_model.FEASIBLE, cp_model.OPTIMAL}:
        result["objective_scaled"] = solver.objective_value
        result["best_bound_scaled"] = solver.best_objective_bound
    if status in {cp_model.FEASIBLE, cp_model.OPTIMAL}:
        with (args.outdir / "partial.sol").open("w", encoding="ascii") as stream:
            for variable in block_variables:
                raw = solver.value(cpvars[variable])
                value = Fraction(raw, continuous_scale) if variable in continuous else Fraction(raw)
                if value:
                    stream.write(f"{variable} {float(value):.17g}\n")
    (args.outdir / "result.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print("RESULT_JSON=" + json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
