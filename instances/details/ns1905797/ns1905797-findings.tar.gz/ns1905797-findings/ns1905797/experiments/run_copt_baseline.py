#!/usr/bin/env python3
"""Run a reproducible CPU-only COPT baseline for ns1905797."""

from __future__ import annotations

import argparse
import json
import os
import platform
import time
from pathlib import Path

import coptpy as cp

from make_copt_lp_hint import master_row_variables


def get_attr(model, attribute, default=None):
    try:
        return model.getAttr(attribute)
    except Exception:
        return default


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--time-limit", type=float, default=1200.0)
    parser.add_argument("--threads", type=int, default=32)
    parser.add_argument(
        "--mode",
        choices=("default", "aggressive", "feasibility"),
        default="aggressive",
    )
    parser.add_argument("--assignment-hint", type=Path)
    parser.add_argument(
        "--fix-assignment-confidence",
        type=float,
        help="fix tasks whose maximum LP assignment score reaches this threshold",
    )
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    environment = cp.Envr()
    model = environment.createModel("ns1905797")
    model.read(args.model)
    fixed_assignment_tasks = 0
    fixed_arc_variables = 0
    if args.assignment_hint:
        variable_order, master = master_row_variables(Path(args.model))
        position = {name: index for index, name in enumerate(variable_order)}
        payload = json.loads(args.assignment_hint.read_text(encoding="utf-8"))
        selected_blocks = payload["selected_blocks"]
        scores = payload["assignment_scores"]
        if len(selected_blocks) != 60 or len(scores) != 60:
            raise ValueError("assignment hint must contain 60 tasks")
        by_name = {variable.name: variable for variable in model.getVars()}
        for task, selected in enumerate(selected_blocks, start=1):
            confidence = max(scores[task - 1])
            if (
                args.fix_assignment_confidence is not None
                and confidence < args.fix_assignment_confidence
            ):
                continue
            fixed_assignment_tasks += 1
            for name in master[f"R{task:04d}"]:
                if position[name] % 4 != selected - 1:
                    by_name[name].ub = 0.0
                    fixed_arc_variables += 1
    model.setLogFile(str(args.outdir / "solver.log"))
    model.setParam(cp.COPT.Param.Threads, args.threads)
    model.setParam(cp.COPT.Param.TimeLimit, args.time_limit)
    model.setParam(cp.COPT.Param.GPUMode, 0)

    parameters: dict[str, int | float] = {
        "Threads": args.threads,
        "TimeLimit": args.time_limit,
        "GPUMode": 0,
    }
    if args.mode in {"aggressive", "feasibility"}:
        settings = {
            cp.COPT.Param.HeurLevel: 3,
            cp.COPT.Param.PreRootHeurLevel: 3,
            cp.COPT.Param.RoundingHeurLevel: 3,
            cp.COPT.Param.DivingHeurLevel: 3,
            cp.COPT.Param.FAPHeurLevel: 4,
            cp.COPT.Param.SubMipHeurLevel: 3,
            cp.COPT.Param.MipRepair: 3,
        }
        for parameter, value in settings.items():
            model.setParam(parameter, value)
            parameters[str(parameter)] = value

    original_objective = [variable.obj for variable in model.getVars()]
    if args.mode == "feasibility":
        model.setObjective(0.0, cp.COPT.MINIMIZE)

    started = time.time()
    model.solve()
    elapsed = time.time() - started
    has_solution = bool(get_attr(model, cp.COPT.Attr.HasMipSol, False))
    result = {
        "schema": "ns1905797-copt-baseline-v1",
        "solver": "COPT",
        "solver_version": [
            cp.COPT.VERSION_MAJOR,
            cp.COPT.VERSION_MINOR,
            cp.COPT.VERSION_TECHNICAL,
        ],
        "host": platform.node(),
        "cpu_only": True,
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES", ""),
        "mode": args.mode,
        "parameters": parameters,
        "assignment_hint": str(args.assignment_hint) if args.assignment_hint else None,
        "fix_assignment_confidence": args.fix_assignment_confidence,
        "fixed_assignment_tasks": fixed_assignment_tasks,
        "fixed_arc_variables": fixed_arc_variables,
        "wall_seconds": elapsed,
        "mip_status": get_attr(model, cp.COPT.Attr.MipStatus),
        "node_count": get_attr(model, cp.COPT.Attr.NodeCnt),
        "has_mip_solution": has_solution,
        "best_bound_solver_objective": get_attr(model, cp.COPT.Attr.BestBnd),
        "best_objective_solver_objective": get_attr(model, cp.COPT.Attr.BestObj),
    }
    if has_solution:
        values = model.getInfo(cp.COPT.Info.Value, model.getVars())
        result["original_objective"] = sum(
            coefficient * value
            for coefficient, value in zip(original_objective, values)
        )
        model.writeSol(str(args.outdir / "best.sol"))
    (args.outdir / "result.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print("RESULT_JSON=" + json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
