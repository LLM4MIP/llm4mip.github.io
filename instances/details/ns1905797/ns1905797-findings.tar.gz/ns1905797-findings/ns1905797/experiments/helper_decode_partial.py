#!/usr/bin/env python3
"""Decode the selected route and potentials from a sparse block solution."""

from __future__ import annotations

import argparse
import json
from fractions import Fraction
from pathlib import Path

from helper_block_solver import recover_arcs
from solve_exact_cpsat import parse_mps, transpose_rows


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=Path, required=True)
    ap.add_argument("--partial", type=Path, required=True)
    ap.add_argument("--block", type=int, choices=(1, 2, 3, 4), required=True)
    args = ap.parse_args()
    parsed = parse_mps(args.model)
    rows = transpose_rows(parsed)
    position = {v: i for i, v in enumerate(parsed.variable_order)}
    block_variables = [v for v in parsed.variable_order if position[v] % 4 == args.block - 1]
    arcs = recover_arcs(parsed, rows, block_variables, args.block - 1)
    sparse = {}
    for line in args.partial.read_text(encoding="ascii").splitlines():
        if line.strip() and not line.lstrip().startswith("#"):
            variable, raw = line.split()
            sparse[variable] = Fraction(raw)
    successor = {
        tail: head for variable, (tail, head) in arcs.items()
        if sparse.get(variable, 0) == 1
    }
    sequence = [0]
    while len(sequence) <= 68:
        head = successor.get(sequence[-1])
        if head is None:
            raise ValueError(f"no selected successor for {sequence[-1]}")
        sequence.append(head)
        if head == 0:
            break
    if sequence[-1] != 0:
        raise ValueError("selected route did not close at depot")
    print(json.dumps({
        "block": args.block,
        "partial": str(args.partial),
        "sequence": sequence,
        "ordinary_tasks": [node for node in sequence if 1 <= node <= 60],
        "special_nodes": [node for node in sequence if 61 <= node <= 66],
    }, sort_keys=True))


if __name__ == "__main__":
    main()
