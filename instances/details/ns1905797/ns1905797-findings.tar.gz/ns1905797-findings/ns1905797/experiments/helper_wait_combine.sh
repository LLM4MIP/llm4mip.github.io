#!/usr/bin/env bash
set -euo pipefail

ROOT=${ROOT:-/home/huangyicheng/miplib_ns190}
MAX_WAIT=${MAX_WAIT:-650}
cd "$ROOT"
started=$(date +%s)

while (( $(date +%s) - started < MAX_WAIT )); do
  block2=''
  block3=''
  for candidate in runs/block-classbalanced15*-b2-exact/partial.sol; do
    if [[ -f "$candidate" ]]; then block2=$candidate; break; fi
  done
  for candidate in runs/block-classbalanced15*-b3-exact/partial.sol; do
    if [[ -f "$candidate" ]]; then block3=$candidate; break; fi
  done
  if [[ -n "$block2" && -n "$block3" ]]; then
    mkdir -p runs/classbalanced15-combined
    python3 helper_combine_blocks.py \
      --model ns1905797.mps.gz \
      --partials \
        runs/block-classbalanced15-objective-b1-exact/partial.sol \
        "$block2" \
        "$block3" \
        runs/block-classbalanced15-objective-b4-exact/partial.sol \
      --outdir runs/classbalanced15-combined \
      >runs/classbalanced15-combined/combine.log 2>&1
    printf 'combined block2=%s block3=%s\n' "$block2" "$block3"
    exit 0
  fi
  sleep 5
done
printf 'timeout: no compatible pair of block2/block3 partial solutions after %ss\n' "$MAX_WAIT"
exit 2
