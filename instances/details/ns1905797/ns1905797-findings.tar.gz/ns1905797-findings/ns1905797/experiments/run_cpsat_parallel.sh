#!/usr/bin/env bash
set -euo pipefail

export CUDA_VISIBLE_DEVICES=""
run_root="${1:-/home/huangyicheng/miplib_ns190}"
time_limit="${2:-1200}"
workers="${3:-16}"
cd "$run_root"
mkdir -p runs/cpsat-symmetry-seed1 runs/cpsat-free-seed2

python3 solve_exact_cpsat.py \
  --model ns1905797.mps.gz \
  --outdir runs/cpsat-symmetry-seed1 \
  --time-limit "$time_limit" \
  --workers "$workers" \
  --random-seed 1 \
  --log-search \
  > runs/cpsat-symmetry-seed1/console.log 2>&1 &
pid_symmetry=$!

python3 solve_exact_cpsat.py \
  --model ns1905797.mps.gz \
  --outdir runs/cpsat-free-seed2 \
  --time-limit "$time_limit" \
  --workers "$workers" \
  --random-seed 2 \
  --no-symmetry-break \
  --log-search \
  > runs/cpsat-free-seed2/console.log 2>&1 &
pid_free=$!

printf 'symmetry_pid=%s\nfree_pid=%s\n' "$pid_symmetry" "$pid_free"
wait "$pid_symmetry"
wait "$pid_free"
