#!/usr/bin/env python3
"""Decode the 4 exchangeable 67-node route blocks in ns1905797."""

from __future__ import annotations

import argparse
import collections
import json
from fractions import Fraction
from pathlib import Path

from solve_exact_cpsat import parse_mps, transpose_rows


def fstr(value: Fraction) -> str:
    return str(value.numerator) if value.denominator == 1 else str(value)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    parsed = parse_mps(args.model)
    rows = transpose_rows(parsed)
    binary_names = [
        variable
        for variable in parsed.variable_order
        if variable in parsed.integer_variables
        and parsed.lower[variable] == 0
        and parsed.upper[variable] == 1
    ]
    variable_position = {
        variable: position for position, variable in enumerate(parsed.variable_order)
    }

    block_arcs: dict[int, list[str]] = {}
    for block in range(4):
        block_arcs[block] = [
            variable
            for variable in binary_names
            if variable_position[variable] % 4 == block
        ]
        assert len(block_arcs[block]) == 4419

    # R16413..R16680 are 67 flow-balance rows interleaved by block.
    flow_rows = {
        (node, block): f"R{16413 + 4 * node + block:04d}"
        for node in range(67)
        for block in range(4)
    }
    arc_map: dict[str, tuple[int, int]] = {}
    for block in range(4):
        incidence: dict[str, list[tuple[int, Fraction]]] = collections.defaultdict(list)
        for node in range(67):
            for variable, coefficient in rows[flow_rows[node, block]]:
                if variable in parsed.integer_variables and parsed.upper[variable] == 1:
                    incidence[variable].append((node, coefficient))
        for variable in block_arcs[block]:
            entries = incidence[variable]
            negative = [node for node, coefficient in entries if coefficient == -1]
            positive = [node for node, coefficient in entries if coefficient == 1]
            if len(negative) != 1 or len(positive) != 1:
                raise ValueError(f"bad incidence for {variable}: {entries}")
            arc_map[variable] = (negative[0], positive[0])

    expected = {(i, j) for i in range(67) for j in range(67) if i != j}
    per_block_missing = {}
    for block in range(4):
        actual = {arc_map[variable] for variable in block_arcs[block]}
        per_block_missing[str(block + 1)] = [list(arc) for arc in sorted(expected - actual)]
        assert len(actual) == 4419

    node_records = []
    for node in range(67):
        time_variable = parsed.variable_order[4 * node]
        outgoing = sum(
            source == node for variable in block_arcs[0] for source, _ in [arc_map[variable]]
        )
        incoming = sum(
            target == node for variable in block_arcs[0] for _, target in [arc_map[variable]]
        )
        node_records.append(
            {
                "node": node,
                "time_variable_block1": time_variable,
                "time_lb": fstr(parsed.lower[time_variable]),
                "time_ub": fstr(parsed.upper[time_variable]),
                "outdegree_available": outgoing,
                "indegree_available": incoming,
                "flow_row_block1": flow_rows[node, 0],
            }
        )

    def binary_arc_terms(row: str, block: int = 0) -> list[dict[str, object]]:
        result = []
        for variable, coefficient in rows[row]:
            if variable not in arc_map or variable_position[variable] % 4 != block:
                continue
            result.append(
                {
                    "variable": variable,
                    "arc": list(arc_map[variable]),
                    "coefficient": fstr(coefficient),
                    "objective": fstr(
                        parsed.columns[variable].get(parsed.objective_row, Fraction(0))
                    ),
                }
            )
        return result

    special_rows = {}
    for row in [
        "R0061",
        "R16389",
        "R16393",
        "R16397",
        "R16401",
        "R16405",
        "R16409",
        "R16413",
        "R16657",
        "R16661",
        "R16665",
        "R16669",
        "R16673",
        "R16677",
    ]:
        special_rows[row] = {
            "sense": parsed.row_sense[row],
            "rhs": fstr(parsed.rhs.get(row, Fraction(0))),
            "arc_terms": binary_arc_terms(row),
            "non_arc_terms": [
                {
                    "variable": variable,
                    "coefficient": fstr(coefficient),
                    "lb": fstr(parsed.lower[variable]),
                    "ub": fstr(parsed.upper[variable]),
                }
                for variable, coefficient in rows[row]
                if variable not in arc_map
            ],
        }

    master_assignment = []
    for task in range(1, 61):
        row = f"R{task:04d}"
        arc_sets = []
        for block in range(4):
            arcs = binary_arc_terms(row, block)
            sources = sorted({entry["arc"][0] for entry in arcs})
            targets = sorted({entry["arc"][1] for entry in arcs})
            arc_sets.append(
                {
                    "block": block + 1,
                    "count": len(arcs),
                    "sources": sources,
                    "targets": targets,
                }
            )
        master_assignment.append({"row": row, "task": task, "sets": arc_sets})

    big_m_patterns: collections.Counter[tuple] = collections.Counter()
    big_m_examples: dict[tuple, dict[str, object]] = {}
    for row in parsed.row_order:
        continuous_terms = [
            (variable, coefficient)
            for variable, coefficient in rows[row]
            if variable not in parsed.integer_variables
        ]
        trigger_terms = [
            (variable, coefficient)
            for variable, coefficient in rows[row]
            if variable in arc_map and coefficient == 50
        ]
        if not continuous_terms or not trigger_terms:
            continue
        continuous_logical = []
        for variable, coefficient in continuous_terms:
            index = variable_position[variable]
            block = index % 4
            logical = index // 4
            continuous_logical.append(
                ("time" if logical < 67 else "work", logical if logical < 67 else logical - 67, block, fstr(coefficient))
            )
        trigger_arcs = [arc_map[variable] for variable, _ in trigger_terms]
        key = (
            len(continuous_terms),
            len(trigger_terms),
            tuple(kind for kind, *_ in continuous_logical),
            tuple(coefficient for *_, coefficient in continuous_logical),
        )
        big_m_patterns[key] += 1
        big_m_examples.setdefault(
            key,
            {
                "row": row,
                "rhs": fstr(parsed.rhs.get(row, Fraction(0))),
                "continuous": continuous_logical,
                "triggers": [list(arc) for arc in trigger_arcs],
            },
        )

    result = {
        "schema": "ns1905797-route-decoding-v1",
        "blocks": 4,
        "nodes_per_block": 67,
        "arcs_per_block": 4419,
        "complete_loopless_arcs": 4422,
        "missing_arcs_by_block": per_block_missing,
        "node_records": node_records,
        "master_assignment_summary": master_assignment,
        "special_rows": special_rows,
        "big_m_pattern_counts": [
            {
                "key": list(key),
                "count": count,
                "example": big_m_examples[key],
            }
            for key, count in sorted(big_m_patterns.items(), key=lambda item: -item[1])
        ],
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
