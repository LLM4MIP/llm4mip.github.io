#!/usr/bin/env bash
set -euo pipefail

ROOT=${ROOT:-/home/huangyicheng/miplib_ns190}
MAX_WAIT=${MAX_WAIT:-650}
cd "$ROOT"
started=$(date +%s)

while (( $(date +%s) - started < MAX_WAIT )); do
  transfer6_b2=''
  for candidate in \
      runs/block-transfer6-objective-b2-exact/partial.sol \
      runs/block-transfer6-b2-arclift-*-b2-exact/partial.sol; do
    if [[ -f "$candidate" ]]; then transfer6_b2=$candidate; break; fi
  done
  if [[ -n "$transfer6_b2" ]]; then
    mkdir -p runs/transfer6-combined
    python3 helper_combine_blocks.py \
      --model ns1905797.mps.gz \
      --partials \
        runs/block-lphint-b1-smoke/partial.sol \
        "$transfer6_b2" \
        runs/block-transfer6-objective-b3-exact/partial.sol \
        runs/block-transfer6-objective-b4-exact/partial.sol \
      --outdir runs/transfer6-combined \
      >runs/transfer6-combined/combine.log 2>&1
    printf 'combined transfer6 with block2=%s\n' "$transfer6_b2"
    exit 0
  fi

  transfer4_b4=''
  for candidate in runs/block-transfer4*-b4-exact/partial.sol; do
    if [[ -f "$candidate" ]]; then transfer4_b4=$candidate; break; fi
  done
  if [[ -n "$transfer4_b4" ]]; then
    mkdir -p runs/transfer4-combined
    python3 helper_combine_blocks.py \
      --model ns1905797.mps.gz \
      --partials \
        runs/block-lphint-b1-smoke/partial.sol \
        runs/block-transfer4-objective-b2-exact/partial.sol \
        runs/block-transfer4-objective-b3-exact/partial.sol \
        "$transfer4_b4" \
      --outdir runs/transfer4-combined \
      >runs/transfer4-combined/combine.log 2>&1
    printf 'combined transfer4 with block4=%s\n' "$transfer4_b4"
    exit 0
  fi

  for variant in A B; do
    split_b2="runs/block-transfer6split${variant}-b2-b2-exact/partial.sol"
    split_b3="runs/block-transfer6split${variant}-b3-b3-exact/partial.sol"
    if [[ -f "$split_b2" && -f "$split_b3" ]]; then
      outdir="runs/transfer6split${variant}-combined"
      mkdir -p "$outdir"
      python3 helper_combine_blocks.py \
        --model ns1905797.mps.gz \
        --partials \
          runs/block-lphint-b1-smoke/partial.sol \
          "$split_b2" \
          "$split_b3" \
          runs/block-transfer6-objective-b4-exact/partial.sol \
        --outdir "$outdir" \
        >"$outdir/combine.log" 2>&1
      printf 'combined transfer6split%s\n' "$variant"
      exit 0
    fi
  done
  sleep 5
done
printf 'timeout: neither transfer assignment supplied all four blocks after %ss\n' "$MAX_WAIT"
exit 2
