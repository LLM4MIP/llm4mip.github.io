#!/usr/bin/env bash
set -euo pipefail

cd /home/huangyicheng/miplib_ns190

launch() {
  local run_dir="$1"
  shift
  mkdir -p "$run_dir"
  nohup setsid env CUDA_VISIBLE_DEVICES='' OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 "$@" \
    >"$run_dir/console.log" 2>&1 </dev/null &
  local pid=$!
  printf '%s\n' "$pid" >"$run_dir/launcher.pid"
  printf '%s %s\n' "$pid" "$run_dir"
}

launch runs/copt-lphint-fixed-resume1 \
  env PYTHONPATH=/home/huangyicheng/copt80/lib/python/310 \
      LD_LIBRARY_PATH=/home/huangyicheng/copt80/lib:/home/huangyicheng/copt80/lib/python/deps \
  python3 run_copt_baseline.py \
    --model ns1905797.mps.gz \
    --outdir runs/copt-lphint-fixed-resume1 \
    --time-limit 600 --threads 16 --mode aggressive \
    --assignment-hint runs/copt-lp-hint/assignment-hint.json \
    --fix-assignment-confidence 0

launch runs/copt-lphint-confidence095-resume1 \
  env PYTHONPATH=/home/huangyicheng/copt80/lib/python/310 \
      LD_LIBRARY_PATH=/home/huangyicheng/copt80/lib:/home/huangyicheng/copt80/lib/python/deps \
  python3 run_copt_baseline.py \
    --model ns1905797.mps.gz \
    --outdir runs/copt-lphint-confidence095-resume1 \
    --time-limit 600 --threads 16 --mode aggressive \
    --assignment-hint runs/copt-lp-hint/assignment-hint.json \
    --fix-assignment-confidence 0.95

launch runs/cpsat-lphint-confidence095-seed11-resume1 \
  python3 solve_exact_cpsat.py \
    --model ns1905797.mps.gz \
    --outdir runs/cpsat-lphint-confidence095-seed11-resume1 \
    --time-limit 600 --workers 16 --random-seed 11 \
    --assignment-hint runs/copt-lp-hint/assignment-hint.json \
    --fix-assignment-confidence 0.95 --original-objective --log-search

launch runs/cpsat-circuit-seed31-resume1 \
  python3 helper_circuit_solver.py \
    --model ns1905797.mps.gz \
    --outdir runs/cpsat-circuit-seed31-resume1 \
    --time-limit 900 --workers 16 --random-seed 31 \
    --assignment-hint runs/copt-lp-hint/assignment-hint.json --log-search

sleep 2
for pid_file in runs/*-resume1/launcher.pid; do
  pid=$(cat "$pid_file")
  if kill -0 "$pid" 2>/dev/null; then
    printf 'RUNNING %s %s\n' "$pid" "${pid_file%/launcher.pid}"
  else
    printf 'EXITED %s %s\n' "$pid" "${pid_file%/launcher.pid}"
  fi
done
