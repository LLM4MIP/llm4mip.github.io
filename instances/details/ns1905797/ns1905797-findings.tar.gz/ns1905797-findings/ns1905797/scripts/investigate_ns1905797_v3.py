#!/usr/bin/env python3
"""
ns1905797 v3: CP-SAT discrete master plus exact lazy difference-logic cuts.

Gurobi is used only to read the original MPS and to obtain row objects for
independent validation. No Gurobi presolve or optimization is called.

The algorithm:
  1. Read the MPS and classify every row.
  2. Verify that every row containing continuous variables is a supported
     difference constraint: at most two continuous variables, coefficients
     +/-1, and opposite signs when there are two.
  3. Put every integer-only row into the CP-SAT master exactly.
  4. Add sound interval projections of the mixed rows to the master.
  5. Obtain a discrete candidate.
  6. Fix that candidate and solve the complete continuous subsystem by
     Bellman-Ford.
  7. If Bellman-Ford finds a negative cycle, sum the source inequalities
     around that cycle. The resulting necessary inequality in the discrete
     variables is added lazily to CP-SAT.
  8. Repeat until a complete validated solution, master infeasibility, a
     structural unsupported-row report, time exhaustion, or max-rounds.

A master INFEASIBLE result is a proof of infeasibility: all master
constraints are necessary for the original model, and every lazy cycle cut
is also necessary. A negative cycle only rejects the current discrete
candidate, not the whole model. A validated candidate proves feasibility.
"""

import argparse
import csv
import json
import math
import os
import time
from collections import Counter, defaultdict
from fractions import Fraction
from math import gcd

import gurobipy as gp


EPS = 1e-9


def close(a, b, tol=EPS):
    return abs(a - b) <= tol * max(1.0, abs(a), abs(b))


def finite(x):
    return math.isfinite(x) and abs(x) < 1e90


def qnum(x):
    if abs(x) < 5e-13:
        return Fraction(0)
    return Fraction(format(float(x), ".12g"))


def lcm(a, b):
    return abs(a // gcd(a, b) * b)


def common_scale(values):
    z = 1
    for x in values:
        z = lcm(z, qnum(x).denominator)
    return z


def vclass(v):
    if v.VType == "B":
        return "binary"
    if v.VType in ("I", "N") and close(v.LB, 0) and close(v.UB, 1):
        return "binary"
    if v.VType in ("I", "N"):
        return "integer"
    return "continuous"


def read_mps(path):
    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()
    model = gp.read(path, env=env)
    model.update()

    vs = model.getVars()
    cs = model.getConstrs()
    rows = []
    for c in cs:
        gr = model.getRow(c)
        t = []
        for k in range(gr.size()):
            t.append((gr.getVar(k).index, float(gr.getCoeff(k))))
        t.sort()
        rows.append(t)
    return model, vs, cs, rows


def row_kind(vs, c, terms):
    cont = [(i, a) for i, a in terms if vclass(vs[i]) == "continuous"]
    ints = [(i, a) for i, a in terms if vclass(vs[i]) != "continuous"]

    if (
        c.Sense == "=" and close(c.RHS, 1.0) and terms
        and all(vclass(vs[i]) == "binary" and close(a, 1)
                for i, a in terms)
    ):
        return "assignment"

    if not cont:
        if c.Sense == "=" and close(c.RHS, 0):
            return "integer_balance"
        if c.Sense == "=":
            return "integer_equality"
        return "integer_inequality"

    if len(cont) > 2:
        return "unsupported_continuous"

    if any(not close(abs(a), 1) for _, a in cont):
        return "unsupported_continuous"

    if len(cont) == 2 and cont[0][1] * cont[1][1] >= 0:
        return "unsupported_continuous"

    return "difference_logic"


def interval_continuous(vs, terms):
    lo = hi = 0.0
    for i, a in terms:
        if vclass(vs[i]) != "continuous":
            continue
        v = vs[i]
        if not finite(v.LB) or not finite(v.UB):
            return None
        lo += a * (v.LB if a >= 0 else v.UB)
        hi += a * (v.UB if a >= 0 else v.LB)
    return lo, hi


def add_scaled_inequality(cp, x, terms, rhs):
    """
    Add sum(a_i*x_i) <= rhs exactly after rational scaling.
    terms contains only integer variables.
    """
    scale = common_scale([rhs] + [a for _, a in terms])
    coeff = []
    for i, a in terms:
        z = qnum(a) * scale
        assert z.denominator == 1
        coeff.append((i, int(z)))
    b = qnum(rhs) * scale
    assert b.denominator == 1
    cp.add(sum(co * x[i] for i, co in coeff) <= int(b))
    return {
        "scale": scale,
        "integer_coefficients": {str(i): co for i, co in coeff},
        "integer_rhs": int(b),
    }


def build_master(vs, cs, rows, cuts):
    from ortools.sat.python import cp_model

    cp = cp_model.CpModel()
    ivars = [i for i, v in enumerate(vs) if vclass(v) != "continuous"]
    x = {}

    for i in ivars:
        v = vs[i]
        lb = math.ceil(v.LB - EPS)
        ub = math.floor(v.UB + EPS)
        x[i] = cp.new_int_var(lb, ub, f"x_{i:05d}")

    exact_rows = 0
    projected_rows = 0

    for ri, (c, terms) in enumerate(zip(cs, rows)):
        dt = [(i, a) for i, a in terms if vclass(vs[i]) != "continuous"]
        ct = [(i, a) for i, a in terms if vclass(vs[i]) == "continuous"]

        if not ct:
            z = add_scaled_inequality(cp, x, dt, c.RHS)
            if c.Sense == "=":
                # The first inequality was <=; add the reverse exactly.
                add_scaled_inequality(
                    cp, x, [(i, -a) for i, a in dt], -c.RHS
                )
            exact_rows += 1
            continue

        mm = interval_continuous(vs, terms)
        if mm is None:
            continue
        minc, maxc = mm

        # Necessary projection of a <= row:
        # discrete + minimum(continuous) <= rhs.
        add_scaled_inequality(cp, x, dt, c.RHS - minc)
        projected_rows += 1

        # Necessary projection of an equality in the other direction:
        # discrete + maximum(continuous) >= rhs.
        if c.Sense == "=":
            add_scaled_inequality(
                cp, x, [(i, -a) for i, a in dt],
                -c.RHS + maxc,
            )

    for cut in cuts:
        add_scaled_inequality(
            cp, x,
            [(int(i), float(a))
             for i, a in cut["discrete_coefficients"].items()],
            cut["rhs"],
        )

    return cp, x, {
        "integer_variables": len(ivars),
        "exact_integer_rows": exact_rows,
        "projected_difference_rows": projected_rows,
        "lazy_cuts": len(cuts),
    }


def make_edges(vs, cs, rows, discrete):
    """
    Convert all mixed rows and all continuous variable bounds into edges

        t[v] <= t[u] + weight

    The edge stores:
        weight = rhs - sum(discrete_coeff * fixed_discrete_value)
    """
    cont = [i for i, v in enumerate(vs) if vclass(v) == "continuous"]
    node = {i: k + 1 for k, i in enumerate(cont)}
    edges = []
    unsupported = []

    def edge(u, v, rhs, dcoeff, source, multiplier=1):
        edges.append({
            "u": u,
            "v": v,
            "rhs": float(rhs),
            "dcoeff": dict(dcoeff),
            "source_row": source,
            "multiplier": multiplier,
        })

    # Bounds are source inequalities too, though they have no discrete part.
    for i in cont:
        v = vs[i]
        if finite(v.UB):
            edge(0, node[i], v.UB, {}, "bound_ub:" + v.VarName)
        if finite(v.LB):
            edge(node[i], 0, -v.LB, {}, "bound_lb:" + v.VarName)

    for ri, (c, terms) in enumerate(zip(cs, rows)):
        ct = [(i, a) for i, a in terms if vclass(vs[i]) == "continuous"]
        dt = [(i, a) for i, a in terms if vclass(vs[i]) != "continuous"]

        if not ct:
            continue

        if len(ct) > 2 or any(not close(abs(a), 1) for _, a in ct):
            unsupported.append((ri, "continuous coefficient", ct))
            continue
        if len(ct) == 2 and ct[0][1] * ct[1][1] >= 0:
            unsupported.append((ri, "same-sign continuous pair", ct))
            continue

        rhs = c.RHS - math.fsum(a * discrete[i] for i, a in dt)
        dcoeff = {i: a for i, a in dt}

        def add_one(sign=1):
            # sign=+1 represents the row as written;
            # sign=-1 represents its negation for an equality.
            cc = [(i, sign * a) for i, a in ct]
            dd = {i: sign * a for i, a in dcoeff.items()}
            rr = sign * c.RHS
            # The fixed discrete contribution is deliberately not folded
            # into the certificate ledger; it is reconstructed from dd.
            if len(cc) == 1:
                i, a = cc[0]
                if close(a, 1):
                    edge(0, node[i], rr, dd, ri, sign)
                elif close(a, -1):
                    edge(node[i], 0, rr, dd, ri, sign)
                else:
                    unsupported.append((ri, "unary sign", cc))
            else:
                plus = [i for i, a in cc if close(a, 1)]
                minus = [i for i, a in cc if close(a, -1)]
                if len(plus) == 1 and len(minus) == 1:
                    edge(node[minus[0]], node[plus[0]], rr, dd, ri, sign)
                else:
                    unsupported.append((ri, "not a difference pair", cc))

        add_one(+1)
        if c.Sense == "=":
            add_one(-1)

    return edges, node, unsupported


def solve_difference(vs, cs, rows, discrete):
    edges, node, unsupported = make_edges(vs, cs, rows, discrete)
    if unsupported:
        return {
            "supported": False,
            "feasible": None,
            "unsupported": [
                {"row": a, "reason": b, "continuous_terms": c}
                for a, b, c in unsupported[:50]
            ],
        }, None, None

    n = len(node) + 1
    d = [0.0] * n
    pred = [None] * n
    changed = None

    for _ in range(n):
        changed = None
        for ei, e in enumerate(edges):
            w = e["rhs"] - math.fsum(
                a * discrete[i] for i, a in e["dcoeff"].items()
            )
            if d[e["v"]] > d[e["u"]] + w + 1e-10:
                d[e["v"]] = d[e["u"]] + w
                pred[e["v"]] = ei
                changed = e["v"]
        if changed is None:
            break

    if changed is not None:
        z = changed
        for _ in range(n):
            ei = pred[z]
            if ei is None:
                break
            z = edges[ei]["u"]

        cyc = []
        seen = {}
        while z not in seen and pred[z] is not None:
            seen[z] = len(cyc)
            ei = pred[z]
            e = edges[ei]
            cyc.append((ei, e))
            z = e["u"]

        if z in seen:
            cyc = cyc[seen[z]:]

        # Sum source inequalities. This is the exact lazy cut:
        # sum(discrete_coeff*x) <= sum(source_rhs).
        dc = defaultdict(float)
        rhs = 0.0
        ledger_edges = []

        for ei, e in cyc:
            mult = e["multiplier"]
            rhs += mult * e["rhs"]
            for i, a in e["dcoeff"].items():
                dc[i] += mult * a
            ledger_edges.append({
                "edge_index": ei,
                "source_row_index": e["source_row"],
                "source_row_name": (
                    cs[e["source_row"]].ConstrName
                    if isinstance(e["source_row"], int) else e["source_row"]
                ),
                "multiplier": mult,
                "rhs": e["rhs"],
                "discrete_coefficients": e["dcoeff"],
                "u": e["u"],
                "v": e["v"],
                "weight_at_candidate": e["rhs"] - math.fsum(
                    a * discrete[i] for i, a in e["dcoeff"].items()
                ),
            })

        dc = {i: a for i, a in dc.items() if abs(a) > 1e-10}
        scale = common_scale([rhs] + list(dc.values()))
        cut = {
            "source_edges": ledger_edges,
            "source_row_indices": sorted(set(
                e["source_row_index"] for e in ledger_edges
                if isinstance(e["source_row_index"], int)
            )),
            "discrete_coefficients": dc,
            "rhs": rhs,
            "scale": scale,
            "scaled_coefficients": {
                str(i): int(qnum(a) * scale) for i, a in dc.items()
            },
            "scaled_rhs": int(qnum(rhs) * scale),
            "cycle_weight_sum_at_candidate": math.fsum(
                e["weight_at_candidate"] for e in ledger_edges
            ),
        }
        return {
            "supported": True,
            "feasible": False,
            "negative_cycle": cut,
        }, None, cut

    values = {i: d[node[i]] - d[0] for i in node}
    return {
        "supported": True,
        "feasible": True,
        "edge_count": len(edges),
        "continuous_variables": len(node),
    }, values, None


def validate(model, vs, cs, values):
    bad = []
    max_bound = max_int = max_row = 0.0

    for i, v in enumerate(vs):
        z = values[i]
        bv = max(v.LB - z, z - v.UB, 0.0)
        max_bound = max(max_bound, bv)
        if vclass(v) != "continuous":
            max_int = max(max_int, abs(z - round(z)))

    for ri, c in enumerate(cs):
        r = model.getRow(c)
        act = 0.0
        for k in range(r.size()):
            act += r.getCoeff(k) * values[r.getVar(k).index]
        viol = abs(act - c.RHS) if c.Sense == "=" else max(act - c.RHS, 0)
        max_row = max(max_row, viol)
        if viol > 1e-7 and len(bad) < 30:
            bad.append({
                "row_index": ri,
                "row": c.ConstrName,
                "activity": act,
                "rhs": c.RHS,
                "sense": c.Sense,
                "violation": viol,
            })

    return {
        "valid": max_bound <= 1e-7 and max_int <= 1e-7 and max_row <= 1e-7,
        "max_bound_violation": max_bound,
        "max_integrality_violation": max_int,
        "max_row_violation": max_row,
        "bad_rows": bad,
    }


def components(vs, cs, rows, assignment):
    parent = list(range(len(vs)))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        a, b = find(a), find(b)
        if a != b:
            parent[b] = a

    aset = set(assignment)
    for ri, terms in enumerate(rows):
        if ri in aset or not terms:
            continue
        a = terms[0][0]
        for i, _ in terms[1:]:
            union(a, i)

    groups = defaultdict(list)
    for i in range(len(vs)):
        groups[find(i)].append(i)
    return sorted(groups.values(), key=lambda z: (-len(z), z[0]))


def dump(path, obj):
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mps", nargs="?", default="input/ns1905797.mps.gz")
    ap.add_argument("--time", type=float, default=600.0)
    ap.add_argument("--max-rounds", type=int, default=1000)
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--out", default="ns1905797_v3")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    start = time.monotonic()

    model, vs, cs, rows = read_mps(args.mps)
    kinds = [row_kind(vs, c, t) for c, t in zip(cs, rows)]
    unsupported = [
        {"row_index": i, "row": cs[i].ConstrName, "kind": kinds[i]}
        for i in range(len(cs))
        if kinds[i] == "unsupported_continuous"
    ]

    assignment = [i for i, k in enumerate(kinds) if k == "assignment"]
    mixed = [i for i, k in enumerate(kinds) if k == "difference_logic"]
    integer_rows = [
        i for i, k in enumerate(kinds)
        if k in ("assignment", "integer_balance",
                 "integer_equality", "integer_inequality")
    ]

    comps = components(vs, cs, rows, assignment)
    structural = {
        "variables": len(vs),
        "constraints": len(cs),
        "nonzeros": sum(map(len, rows)),
        "variable_classes": dict(Counter(vclass(v) for v in vs)),
        "row_classes": dict(Counter(kinds)),
        "assignment_count": len(assignment),
        "mixed_difference_row_count": len(mixed),
        "integer_only_row_count": len(integer_rows),
        "unsupported_continuous_count": len(unsupported),
        "components_without_assignment_rows": {
            "count": len(comps),
            "sizes": [len(x) for x in comps[:20]],
            "intervals": [
                [[min(x), max(x)]] if x else [] for x in comps[:20]
            ],
        },
    }
    dump(os.path.join(args.out, "structural.json"), structural)

    if unsupported:
        report = {
            "status": "UNSUPPORTED_STRUCTURE",
            "structural": structural,
            "unsupported_rows": unsupported,
            "conclusion": (
                "Stopped safely: not every continuous row is a supported "
                "difference constraint, so the exact lazy-cycle algorithm "
                "was not run."
            ),
        }
        dump(os.path.join(args.out, "report.json"), report)
        print(json.dumps(report, indent=2))
        return

    try:
        from ortools.sat.python import cp_model
    except ImportError:
        report = {
            "status": "MISSING_ORTOOLS",
            "structural": structural,
            "conclusion": "Install ortools and rerun.",
        }
        dump(os.path.join(args.out, "report.json"), report)
        print(json.dumps(report, indent=2))
        return

    cuts = []
    ledger = []
    final = None

    for rnd in range(args.max_rounds):
        remaining = args.time - (time.monotonic() - start)
        if remaining <= 0:
            final = {"status": "TIME_LIMIT", "round": rnd}
            break

        cp, x, master_stats = build_master(vs, cs, rows, cuts)
        solver = cp_model.CpSolver()
        solver.parameters.max_time_in_seconds = remaining
        solver.parameters.num_search_workers = args.workers
        solver.parameters.log_search_progress = True

        code = solver.solve(cp)
        status = solver.status_name(code)

        if code == cp_model.INFEASIBLE:
            final = {
                "status": "INFEASIBLE",
                "round": rnd,
                "master_stats": master_stats,
                "proof": (
                    "The exact integer-only rows, sound mixed-row "
                    "projections, and all lazy cycle inequalities are "
                    "necessary for every feasible original-MPS solution. "
                    "Their CP-SAT infeasibility therefore proves global "
                    "infeasibility."
                ),
            }
            break

        if code not in (cp_model.FEASIBLE, cp_model.OPTIMAL):
            final = {
                "status": status,
                "round": rnd,
                "master_stats": master_stats,
                "proof": "No feasibility conclusion follows from this status.",
            }
            break

        discrete = {
            i: solver.value(x[i])
            for i, v in enumerate(vs) if vclass(v) != "continuous"
        }

        diff, cont, cut = solve_difference(vs, cs, rows, discrete)

        if diff["feasible"]:
            values = [0.0] * len(vs)
            for i, z in discrete.items():
                values[i] = float(z)
            for i, z in cont.items():
                values[i] = float(z)

            check = validate(model, vs, cs, values)
            objective = model.ObjCon + math.fsum(
                v.Obj * values[i] for i, v in enumerate(vs)
            )
            check["objective"] = objective

            if check["valid"]:
                with open(os.path.join(args.out, "candidate.sol"), "w") as f:
                    f.write(f"# Objective value = {objective:.16g}\n")
                    for i, v in enumerate(vs):
                        f.write(f"{v.VarName} {values[i]:.16g}\n")
                dump(os.path.join(args.out, "validation.json"), check)
                final = {
                    "status": "FEASIBLE",
                    "round": rnd,
                    "objective": objective,
                    "validation": check,
                    "proof": (
                        "Every original bound, integrality condition, and "
                        "row was independently evaluated using Gurobi model "
                        "objects. candidate.sol is a valid original-MPS "
                        "feasible solution."
                    ),
                }
                break

            final = {
                "status": "INTERNAL_VALIDATION_FAILURE",
                "round": rnd,
                "validation": check,
                "proof": "The candidate was not accepted as feasible.",
            }
            break

        # A supported negative cycle produces one globally valid cut.
        cuts.append(cut)
        ledger.append({
            "cut_number": len(ledger),
            "round": rnd,
            "candidate_discrete_nonzero_count": sum(
                z != 0 for z in discrete.values()
            ),
            "certificate": cut,
            "meaning": (
                "Summing the listed source inequalities around the negative "
                "cycle yields this necessary discrete inequality. It is "
                "violated by the current candidate and valid for every "
                "extendable candidate."
            ),
        })
        dump(os.path.join(args.out, "cycle_ledger.json"), ledger)

        if rnd + 1 == args.max_rounds:
            final = {
                "status": "MAX_ROUNDS",
                "round": rnd + 1,
                "lazy_cuts": len(cuts),
                "proof": (
                    "No global conclusion: the search stopped after the "
                    "requested number of lazy cuts."
                ),
            }

    if final is None:
        final = {
            "status": "TIME_LIMIT",
            "round": args.max_rounds,
            "proof": "No global conclusion.",
        }

    final["structural"] = structural
    final["lazy_cut_count"] = len(cuts)
    final["elapsed_seconds"] = time.monotonic() - start
    final["files"] = {
        "structural": "structural.json",
        "cycle_ledger": "cycle_ledger.json",
        "candidate": "candidate.sol" if final["status"] == "FEASIBLE"
                      else None,
        "validation": "validation.json" if final["status"] == "FEASIBLE"
                      else None,
    }
    dump(os.path.join(args.out, "report.json"), final)
    print(json.dumps(final, indent=2))


if __name__ == "__main__":
    main()
