#!/usr/bin/env python3
"""
Incidence-derived structural analysis of MIPLIB ns1905797.

Gurobi is used only to read the MPS. No Gurobi presolve or optimize call.

Optional dependency for the constructive discrete projection:
    pip install ortools

Typical run:
    python investigate_ns1905797_v2.py input/ns1905797.mps.gz \
        --out ns1905797_v2 --cp-time 600 --workers 8

Important output meanings
-------------------------
assignment_rows.json:
    Rows detected algebraically as sum(binary variables) = 1.

partitions.json:
    Actual incidence components after removing selected row classes.
    In particular, "without_assignment_rows" establishes whether the
    72 assignment equations are the only couplers between four blocks.

repetition.json:
    Coefficient-aware refinement fingerprints and, where possible, explicit
    maps between components. An entry exact_verified=true proves equality of
    bounds, types, objectives, row senses/RHS values, and all coefficients
    under the reported variable/row permutation.

assignment_coupling.json:
    Describes how every assignment row intersects the discovered components.
    symmetric_under_verified_maps=true proves that each linking row has the
    same support and coefficients in corresponding repeated blocks.

discrete_core.json:
    Status and statistics for the integer projection. FEASIBLE proves only
    feasibility of that necessary projection, not of the MPS.

difference_logic.json:
    If feasible=true, gives continuous values satisfying all mixed rows after
    fixing the discrete candidate. If feasible=false and supported=true, the
    negative cycle proves only that this particular discrete candidate cannot
    be extended.

candidate.sol + validation.json:
    Produced only when a discrete candidate is extended to continuous values.
    validation.valid=true proves feasibility of the original MPS.
"""

import argparse
import csv
import hashlib
import json
import math
import os
from collections import Counter, defaultdict
from fractions import Fraction
from math import gcd

import gurobipy as gp


EPS = 1e-8
INF = 1e100


def close(a, b, tol=1e-9):
    return abs(a - b) <= tol * max(1.0, abs(a), abs(b))


def finite(x):
    return math.isfinite(x) and abs(x) < 1e90


def frac(x):
    if abs(x) < 5e-13:
        return Fraction(0)
    return Fraction(format(float(x), ".12g"))


def lcm(a, b):
    return abs(a // gcd(a, b) * b)


def lcmm(xs):
    z = 1
    for x in xs:
        z = lcm(z, x)
    return z


def digest(obj):
    return hashlib.sha256(repr(obj).encode()).hexdigest()[:24]


class DSU:
    def __init__(self, n):
        self.p = list(range(n))
        self.sz = [1] * n

    def find(self, x):
        while self.p[x] != x:
            self.p[x] = self.p[self.p[x]]
            x = self.p[x]
        return x

    def union(self, a, b):
        a, b = self.find(a), self.find(b)
        if a == b:
            return
        if self.sz[a] < self.sz[b]:
            a, b = b, a
        self.p[b] = a
        self.sz[a] += self.sz[b]


def vclass(v):
    if v.VType == "B":
        return "binary"
    if v.VType in ("I", "N") and close(v.LB, 0) and close(v.UB, 1):
        return "binary"
    if v.VType in ("I", "N"):
        return "integer"
    return "continuous"


def read_matrix(path):
    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()
    m = gp.read(path, env=env)
    m.update()

    vs = m.getVars()
    cs = m.getConstrs()
    rows = []
    cols = [[] for _ in vs]

    for ri, c in enumerate(cs):
        gr = m.getRow(c)
        terms = []
        for k in range(gr.size()):
            vi = gr.getVar(k).index
            a = float(gr.getCoeff(k))
            terms.append((vi, a))
            cols[vi].append((ri, a))
        terms.sort()
        rows.append(terms)

    return m, vs, cs, rows, cols


def assignment_rows(vs, cs, rows):
    vc = [vclass(v) for v in vs]
    ans = []
    for ri, (c, terms) in enumerate(zip(cs, rows)):
        if (
            c.Sense == "="
            and close(c.RHS, 1)
            and terms
            and all(close(a, 1) for _, a in terms)
            and all(vc[i] == "binary" for i, _ in terms)
        ):
            ans.append(ri)
    return ans


def row_basic_class(vs, c, terms, assignment=False):
    classes = [vclass(vs[i]) for i, _ in terms]
    coeffs = [a for _, a in terms]
    nc = classes.count("continuous")

    if assignment:
        return "assignment"
    if c.Sense == "=" and close(c.RHS, 0) and nc == 0 and all(
        close(abs(a), 1) for a in coeffs
    ):
        return "integer_balance"
    if c.Sense == "=" and nc == 0:
        return "integer_equality"
    if nc == 0:
        return "integer_inequality"
    if nc <= 2:
        ct = [a for (i, a), cl in zip(terms, classes) if cl == "continuous"]
        if all(close(abs(a), 1) for a in ct):
            if len(ct) < 2 or ct[0] * ct[1] < 0:
                return "difference_logic"
    return "mixed_continuous"


def component_partition(nvars, rows, included_rows):
    dsu = DSU(nvars)
    touched = [False] * nvars

    for ri in included_rows:
        support = [i for i, _ in rows[ri]]
        if not support:
            continue
        root = support[0]
        touched[root] = True
        for i in support[1:]:
            touched[i] = True
            dsu.union(root, i)

    groups = defaultdict(list)
    for i in range(nvars):
        if touched[i]:
            groups[dsu.find(i)].append(i)
        else:
            groups[("isolated", i)].append(i)

    comps = sorted(groups.values(), key=lambda z: (-len(z), z[0]))
    var_component = {}
    for ci, comp in enumerate(comps):
        for i in comp:
            var_component[i] = ci
    return comps, var_component


def intervals(indices):
    if not indices:
        return []
    z = sorted(indices)
    out = []
    a = b = z[0]
    for x in z[1:]:
        if x == b + 1:
            b = x
        else:
            out.append([a, b])
            a = b = x
    out.append([a, b])
    return out


def summarize_partition(name, comps, var_comp, cs, rows, included):
    included = set(included)
    row_counts = Counter()
    crossing_examples = []

    for ri, terms in enumerate(rows):
        touched = sorted({var_comp[i] for i, _ in terms})
        row_counts[len(touched)] += 1
        if len(touched) > 1 and len(crossing_examples) < 30:
            crossing_examples.append({
                "row_index": ri,
                "row": cs[ri].ConstrName,
                "included_in_partition_graph": ri in included,
                "degree": len(terms),
                "components": touched,
                "component_term_counts": dict(Counter(
                    var_comp[i] for i, _ in terms
                )),
            })

    summaries = []
    for ci, comp in enumerate(comps[:20]):
        summaries.append({
            "component": ci,
            "variables": len(comp),
            "min_index": min(comp),
            "max_index": max(comp),
            "interval_count": len(intervals(comp)),
            "first_intervals": intervals(comp)[:20],
            "residue_mod_4": dict(Counter(i % 4 for i in comp)),
            "variable_classes": dict(Counter()),  # filled by caller
        })

    return {
        "name": name,
        "component_count": len(comps),
        "largest_component_sizes": [len(c) for c in comps[:30]],
        "component_summaries": summaries,
        "row_component_span_histogram": dict(sorted(row_counts.items())),
        "crossing_examples": crossing_examples,
    }


def induced_rows(rows, comp_set):
    return [
        ri for ri, terms in enumerate(rows)
        if terms and all(i in comp_set for i, _ in terms)
    ]


def refinement(vs, cs, rows, component):
    """
    Coefficient-aware bipartite Weisfeiler-Lehman refinement.

    This is an isomorphism invariant, not by itself a complete canonical
    labeling. Explicit permutations constructed from its color classes are
    subsequently checked coefficient by coefficient.
    """
    vset = set(component)
    local_rows = induced_rows(rows, vset)

    vcolor = {}
    rcolor = {}

    for i in component:
        v = vs[i]
        vcolor[i] = digest((
            "V", vclass(v), v.VType,
            round(v.LB, 10), round(v.UB, 10), round(v.Obj, 10),
        ))

    for ri in local_rows:
        c = cs[ri]
        rcolor[ri] = digest((
            "R", c.Sense, round(c.RHS, 10), len(rows[ri]),
            tuple(sorted(round(a, 10) for _, a in rows[ri])),
        ))

    vinc = defaultdict(list)
    for ri in local_rows:
        for i, a in rows[ri]:
            vinc[i].append((ri, a))

    for _ in range(20):
        newv = {}
        newr = {}

        for i in component:
            neigh = sorted(
                (round(a, 10), rcolor[ri]) for ri, a in vinc[i]
            )
            newv[i] = digest((vcolor[i], tuple(neigh)))

        for ri in local_rows:
            neigh = sorted(
                (round(a, 10), vcolor[i]) for i, a in rows[ri]
            )
            newr[ri] = digest((rcolor[ri], tuple(neigh)))

        if newv == vcolor and newr == rcolor:
            break
        vcolor, rcolor = newv, newr

    fp = digest((
        tuple(sorted(Counter(vcolor.values()).items())),
        tuple(sorted(Counter(rcolor.values()).items())),
    ))

    return {
        "component": component,
        "rows": local_rows,
        "vcolor": vcolor,
        "rcolor": rcolor,
        "fingerprint": fp,
        "variable_color_sizes": sorted(
            Counter(vcolor.values()).values(), reverse=True
        )[:30],
        "row_color_sizes": sorted(
            Counter(rcolor.values()).values(), reverse=True
        )[:30],
    }


def proposed_map_by_colors(ref_a, ref_b):
    va = defaultdict(list)
    vb = defaultdict(list)
    ra = defaultdict(list)
    rb = defaultdict(list)

    for i, c in ref_a["vcolor"].items():
        va[c].append(i)
    for i, c in ref_b["vcolor"].items():
        vb[c].append(i)
    for i, c in ref_a["rcolor"].items():
        ra[c].append(i)
    for i, c in ref_b["rcolor"].items():
        rb[c].append(i)

    if set(va) != set(vb) or set(ra) != set(rb):
        return None, None, "different color sets"
    if any(len(va[c]) != len(vb[c]) for c in va):
        return None, None, "different variable color multiplicities"
    if any(len(ra[c]) != len(rb[c]) for c in ra):
        return None, None, "different row color multiplicities"

    # Sorting only proposes a permutation within unresolved color classes.
    # verify_map decides whether that permutation is an exact isomorphism.
    vm = {}
    rm = {}
    for c in va:
        for x, y in zip(sorted(va[c]), sorted(vb[c])):
            vm[x] = y
    for c in ra:
        for x, y in zip(sorted(ra[c]), sorted(rb[c])):
            rm[x] = y
    return vm, rm, None


def verify_map(vs, cs, rows, ref_a, ref_b, vm, rm):
    if vm is None or rm is None:
        return False, {"reason": "no proposed map"}

    for i, j in vm.items():
        a, b = vs[i], vs[j]
        if not (
            a.VType == b.VType
            and close(a.LB, b.LB)
            and close(a.UB, b.UB)
            and close(a.Obj, b.Obj)
        ):
            return False, {
                "reason": "variable attribute mismatch",
                "source": i, "target": j,
            }

    target_rows = set(ref_b["rows"])
    if set(rm.values()) != target_rows:
        return False, {"reason": "row map is not onto target rows"}

    for ri, rj in rm.items():
        ca, cb = cs[ri], cs[rj]
        if ca.Sense != cb.Sense or not close(ca.RHS, cb.RHS):
            return False, {
                "reason": "row attribute mismatch",
                "source": ri, "target": rj,
            }

        mapped = sorted((vm[i], round(a, 10)) for i, a in rows[ri])
        actual = sorted((i, round(a, 10)) for i, a in rows[rj])
        if mapped != actual:
            return False, {
                "reason": "coefficient mismatch",
                "source": ri, "target": rj,
                "mapped_sample": mapped[:20],
                "actual_sample": actual[:20],
            }

    return True, None


def analyze_repetition(vs, cs, rows, comps):
    refs = [refinement(vs, cs, rows, c) for c in comps]
    groups = defaultdict(list)
    for ci, ref in enumerate(refs):
        groups[ref["fingerprint"]].append(ci)

    report_groups = []
    verified_maps = {}

    for fp, ids in sorted(groups.items(), key=lambda z: (-len(z[1]), z[0])):
        entry = {
            "fingerprint": fp,
            "components": ids,
            "component_sizes": [len(comps[i]) for i in ids],
            "local_row_counts": [len(refs[i]["rows"]) for i in ids],
            "pair_maps_to_first": [],
        }

        if len(ids) >= 2:
            base = ids[0]
            for other in ids[1:]:
                vm, rm, error = proposed_map_by_colors(
                    refs[base], refs[other]
                )
                exact, mismatch = verify_map(
                    vs, cs, rows, refs[base], refs[other], vm, rm
                )
                entry["pair_maps_to_first"].append({
                    "source_component": base,
                    "target_component": other,
                    "map_constructed": vm is not None,
                    "exact_verified": exact,
                    "construction_error": error,
                    "verification_mismatch": mismatch,
                    "variable_map_sample": (
                        [[i, vm[i]] for i in sorted(vm)[:30]]
                        if vm else []
                    ),
                    "row_map_sample": (
                        [[i, rm[i]] for i in sorted(rm)[:30]]
                        if rm else []
                    ),
                })
                if exact:
                    verified_maps[(base, other)] = vm

        report_groups.append(entry)

    return refs, report_groups, verified_maps


def assignment_coupling(
    assignment, rows, comps, var_comp, verified_maps
):
    details = []

    for ri in assignment:
        by_comp = defaultdict(list)
        for i, a in rows[ri]:
            by_comp[var_comp[i]].append((i, a))

        details.append({
            "row_index": ri,
            "degree": len(rows[ri]),
            "components": sorted(by_comp),
            "term_counts": {
                str(c): len(t) for c, t in sorted(by_comp.items())
            },
            "index_intervals_by_component": {
                str(c): intervals([i for i, _ in t])[:20]
                for c, t in sorted(by_comp.items())
            },
        })

    # Test symmetry row by row using exact component maps from component 0.
    relevant_components = sorted({
        var_comp[i] for ri in assignment for i, _ in rows[ri]
    })

    symmetric = True
    failures = []

    if not relevant_components or relevant_components[0] != 0:
        symmetric = False
        failures.append("No component 0 assignment slice")
    else:
        for target in relevant_components[1:]:
            vm = verified_maps.get((0, target))
            if vm is None:
                symmetric = False
                failures.append(
                    f"No exact verified map from component 0 to {target}"
                )
                continue

            for ri in assignment:
                base = sorted(
                    (i, round(a, 10))
                    for i, a in rows[ri] if var_comp[i] == 0
                )
                actual = sorted(
                    (i, round(a, 10))
                    for i, a in rows[ri] if var_comp[i] == target
                )
                mapped = sorted(
                    (vm[i], a) for i, a in base if i in vm
                )
                if mapped != actual:
                    symmetric = False
                    if len(failures) < 30:
                        failures.append({
                            "row": ri,
                            "target_component": target,
                            "base_count": len(base),
                            "target_count": len(actual),
                            "mapped_sample": mapped[:20],
                            "actual_sample": actual[:20],
                        })

    return {
        "assignment_row_count": len(assignment),
        "components_touched": relevant_components,
        "symmetric_under_verified_maps": symmetric,
        "failures": failures,
        "rows": details,
    }


def minmax_continuous(vs, terms):
    lo = 0.0
    hi = 0.0
    for i, a in terms:
        if vclass(vs[i]) != "continuous":
            continue
        v = vs[i]
        if not finite(v.LB) or not finite(v.UB):
            return None
        lo += a * (v.LB if a >= 0 else v.UB)
        hi += a * (v.UB if a >= 0 else v.LB)
    return lo, hi


def solve_discrete_projection(vs, cs, rows, time_limit, workers):
    try:
        from ortools.sat.python import cp_model
    except ImportError:
        return {
            "available": False,
            "status": "NOT_RUN",
            "message": "Install ortools to run the discrete projection.",
        }, None

    integer_vars = [
        i for i, v in enumerate(vs) if vclass(v) != "continuous"
    ]
    model = cp_model.CpModel()
    x = {}

    for i in integer_vars:
        v = vs[i]
        lb = math.ceil(v.LB - EPS)
        ub = math.floor(v.UB + EPS)
        x[i] = model.new_int_var(lb, ub, f"x_{i}")

    exact_rows = 0
    projected_rows = 0
    skipped_rows = 0

    def add_rational_ineq(terms, rhs, equality=False):
        den = [frac(rhs).denominator]
        den.extend(frac(a).denominator for _, a in terms)
        scale = lcmm(den)
        icoeff = [int(frac(a) * scale) for _, a in terms]
        irhs = int(frac(rhs) * scale)
        expr = sum(co * x[i] for (i, _), co in zip(terms, icoeff))
        if equality:
            model.add(expr == irhs)
        else:
            model.add(expr <= irhs)

    for c, terms in zip(cs, rows):
        discrete = [
            (i, a) for i, a in terms if vclass(vs[i]) != "continuous"
        ]
        continuous = [
            (i, a) for i, a in terms if vclass(vs[i]) == "continuous"
        ]

        if not continuous:
            add_rational_ineq(
                discrete, c.RHS, equality=(c.Sense == "=")
            )
            exact_rows += 1
            continue

        mm = minmax_continuous(vs, terms)
        if mm is None:
            skipped_rows += 1
            continue

        minc, maxc = mm

        # Necessary projection of discrete + continuous <= rhs:
        # discrete + minimum_continuous <= rhs.
        add_rational_ineq(discrete, c.RHS - minc, equality=False)
        projected_rows += 1

        if c.Sense == "=":
            # Also require discrete + maximum_continuous >= rhs.
            add_rational_ineq(
                [(i, -a) for i, a in discrete],
                -c.RHS + maxc,
                equality=False,
            )

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = time_limit
    solver.parameters.num_search_workers = workers
    solver.parameters.log_search_progress = True

    status_code = solver.solve(model)
    status = solver.status_name(status_code)

    result = {
        "available": True,
        "status": status,
        "integer_variable_count": len(integer_vars),
        "exact_discrete_rows": exact_rows,
        "projected_mixed_rows": projected_rows,
        "skipped_mixed_rows": skipped_rows,
        "wall_time": solver.wall_time,
        "branches": solver.num_branches,
        "conflicts": solver.num_conflicts,
        "meaning": (
            "This is a necessary projection. FEASIBLE is not yet a full "
            "MPS feasibility result; INFEASIBLE proves the original MPS "
            "infeasible because every added constraint is necessary."
        ),
    }

    if status_code in (cp_model.FEASIBLE, cp_model.OPTIMAL):
        values = {i: solver.value(x[i]) for i in integer_vars}
        return result, values

    return result, None


def solve_difference_logic(vs, cs, rows, discrete_values):
    """
    Fix all discrete variables and convert the continuous system into
    difference constraints x_v <= x_u + c.

    Node 0 is a reference node. Continuous variable i is represented by
    node cont_node[i]. Values are recovered as d[node]-d[0].
    """
    cont = [i for i, v in enumerate(vs) if vclass(v) == "continuous"]
    node = {i: k + 1 for k, i in enumerate(cont)}
    n = len(cont) + 1
    edges = []
    unsupported = []

    def add_ineq(ri, cterms, rhs):
        if len(cterms) == 0:
            if 0.0 > rhs + EPS:
                edges.append((0, 0, rhs, ri))
            return

        if len(cterms) == 1:
            i, a = cterms[0]
            if close(a, 1):
                # x_i <= rhs
                edges.append((0, node[i], rhs, ri))
            elif close(a, -1):
                # -x_i <= rhs  <=> reference <= x_i + rhs
                edges.append((node[i], 0, rhs, ri))
            else:
                unsupported.append({
                    "row": ri,
                    "reason": "single continuous coefficient is not +/-1",
                    "terms": cterms,
                })
            return

        if len(cterms) == 2:
            plus = [i for i, a in cterms if close(a, 1)]
            minus = [i for i, a in cterms if close(a, -1)]
            if len(plus) == 1 and len(minus) == 1:
                # x_plus - x_minus <= rhs
                edges.append(
                    (node[minus[0]], node[plus[0]], rhs, ri)
                )
            else:
                unsupported.append({
                    "row": ri,
                    "reason": "not an opposite-sign difference pair",
                    "terms": cterms,
                })
            return

        unsupported.append({
            "row": ri,
            "reason": "more than two continuous variables",
            "terms": cterms,
        })

    # Explicit variable bounds.
    for i in cont:
        v = vs[i]
        if finite(v.UB):
            edges.append((0, node[i], v.UB, "upper_bound"))
        if finite(v.LB):
            edges.append((node[i], 0, -v.LB, "lower_bound"))

    for ri, (c, terms) in enumerate(zip(cs, rows)):
        fixed = math.fsum(
            a * discrete_values[i]
            for i, a in terms if i in discrete_values
        )
        ct = [
            (i, a) for i, a in terms
            if vclass(vs[i]) == "continuous"
        ]
        rhs = c.RHS - fixed
        add_ineq(ri, ct, rhs)
        if c.Sense == "=":
            add_ineq(ri, [(i, -a) for i, a in ct], -rhs)

    if unsupported:
        return {
            "supported": False,
            "feasible": None,
            "unsupported_count": len(unsupported),
            "unsupported_examples": unsupported[:30],
            "meaning": (
                "The fixed continuous subsystem is not entirely difference "
                "logic, so no extension decision was made."
            ),
        }, None

    # Bellman-Ford with every distance initially zero is equivalent to a
    # super-source connected to every node by a zero edge.
    d = [0.0] * n
    pred = [None] * n
    last = None

    for _ in range(n):
        last = None
        for u, v, w, origin in edges:
            if d[v] > d[u] + w + 1e-12:
                d[v] = d[u] + w
                pred[v] = (u, origin, w)
                last = v
        if last is None:
            break

    if last is not None:
        y = last
        for _ in range(n):
            if pred[y] is None:
                break
            y = pred[y][0]

        cycle = []
        seen = {}
        z = y
        while z not in seen and pred[z] is not None:
            seen[z] = len(cycle)
            u, origin, w = pred[z]
            cycle.append({
                "from_node": u,
                "to_node": z,
                "weight": w,
                "origin": origin,
            })
            z = u

        if z in seen:
            cycle = cycle[seen[z]:]

        return {
            "supported": True,
            "feasible": False,
            "negative_cycle": cycle,
            "meaning": (
                "This negative cycle proves that the particular fixed "
                "discrete candidate has no continuous extension. It does "
                "not prove global infeasibility."
            ),
        }, None

    shift = d[0]
    values = {i: d[node[i]] - shift for i in cont}
    return {
        "supported": True,
        "feasible": True,
        "edge_count": len(edges),
        "continuous_variable_count": len(cont),
        "meaning": (
            "The returned continuous values satisfy the complete fixed "
            "difference-logic subsystem."
        ),
    }, values


def validate(m, vs, cs, rows, values):
    max_bound = 0.0
    max_integrality = 0.0
    max_row = 0.0
    bad = []

    for i, v in enumerate(vs):
        z = values[i]
        max_bound = max(max_bound, v.LB - z, z - v.UB, 0.0)
        if vclass(v) != "continuous":
            max_integrality = max(
                max_integrality, abs(z - round(z))
            )

    for ri, (c, terms) in enumerate(zip(cs, rows)):
        act = math.fsum(a * values[i] for i, a in terms)
        viol = (
            abs(act - c.RHS)
            if c.Sense == "="
            else max(act - c.RHS, 0.0)
        )
        max_row = max(max_row, viol)
        if viol > 1e-7 and len(bad) < 30:
            bad.append({
                "row_index": ri,
                "row": c.ConstrName,
                "sense": c.Sense,
                "rhs": c.RHS,
                "activity": act,
                "violation": viol,
            })

    return {
        "valid": (
            max_bound <= 1e-7
            and max_integrality <= 1e-7
            and max_row <= 1e-7
        ),
        "max_bound_violation": max_bound,
        "max_integrality_violation": max_integrality,
        "max_row_violation": max_row,
        "bad_rows": bad,
    }


def dump_json(path, obj):
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "mps", nargs="?", default="input/ns1905797.mps.gz"
    )
    ap.add_argument("--out", default="ns1905797_v2")
    ap.add_argument("--cp-time", type=float, default=600.0)
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--no-cp", action="store_true")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    m, vs, cs, rows, cols = read_matrix(args.mps)
    n, nr = len(vs), len(cs)

    assignments = assignment_rows(vs, cs, rows)
    aset = set(assignments)

    assignment_report = {
        "count": len(assignments),
        "rows": [{
            "row_index": ri,
            "name": cs[ri].ConstrName,
            "degree": len(rows[ri]),
            "rhs": cs[ri].RHS,
            "min_variable_index": min(i for i, _ in rows[ri]),
            "max_variable_index": max(i for i, _ in rows[ri]),
            "support_intervals": intervals(
                [i for i, _ in rows[ri]]
            )[:30],
            "residue_mod_4": dict(Counter(
                i % 4 for i, _ in rows[ri]
            )),
        } for ri in assignments],
    }
    dump_json(
        os.path.join(args.out, "assignment_rows.json"),
        assignment_report,
    )

    row_classes = [
        row_basic_class(vs, cs[ri], rows[ri], ri in aset)
        for ri in range(nr)
    ]

    filters = {
        "full_matrix": list(range(nr)),
        "without_assignment_rows": [
            ri for ri in range(nr) if ri not in aset
        ],
        "rows_degree_at_most_4": [
            ri for ri in range(nr) if len(rows[ri]) <= 4
        ],
        "without_assignment_and_degree_at_most_8": [
            ri for ri in range(nr)
            if ri not in aset and len(rows[ri]) <= 8
        ],
        "without_all_integer_equalities": [
            ri for ri in range(nr)
            if row_classes[ri] not in (
                "assignment", "integer_balance", "integer_equality"
            )
        ],
    }

    partition_objects = {}
    partition_report = {}

    for name, included in filters.items():
        comps, var_comp = component_partition(n, rows, included)
        rep = summarize_partition(
            name, comps, var_comp, cs, rows, included
        )
        for summary in rep["component_summaries"]:
            ci = summary["component"]
            summary["variable_classes"] = dict(Counter(
                vclass(vs[i]) for i in comps[ci]
            ))
        partition_report[name] = rep
        partition_objects[name] = (comps, var_comp)

    dump_json(
        os.path.join(args.out, "partitions.json"),
        partition_report,
    )

    # Main structural partition: remove exactly the algebraically detected
    # assignment rows.
    comps, var_comp = partition_objects["without_assignment_rows"]

    with open(
        os.path.join(args.out, "variable_components.csv"),
        "w", newline=""
    ) as f:
        w = csv.writer(f)
        w.writerow([
            "variable_index", "name", "component", "class",
            "type", "lb", "ub", "objective",
        ])
        for i, v in enumerate(vs):
            w.writerow([
                i, v.VarName, var_comp[i], vclass(v),
                v.VType, v.LB, v.UB, v.Obj,
            ])

    refs, repetition_groups, verified_maps = analyze_repetition(
        vs, cs, rows, comps
    )
    repetition_report = {
        "partition": "without_assignment_rows",
        "component_count": len(comps),
        "groups": repetition_groups,
        "warning": (
            "Equal refinement fingerprints are strong isomorphism "
            "invariants but are not alone a proof. Only entries with "
            "exact_verified=true are coefficient-level proofs."
        ),
    }
    dump_json(
        os.path.join(args.out, "repetition.json"),
        repetition_report,
    )

    coupling = assignment_coupling(
        assignments, rows, comps, var_comp, verified_maps
    )
    dump_json(
        os.path.join(args.out, "assignment_coupling.json"),
        coupling,
    )

    discrete_result = {
        "status": "NOT_RUN",
        "message": "Disabled by --no-cp.",
    }
    discrete_values = None

    if not args.no_cp:
        discrete_result, discrete_values = solve_discrete_projection(
            vs, cs, rows, args.cp_time, args.workers
        )

    dump_json(
        os.path.join(args.out, "discrete_core.json"),
        discrete_result,
    )

    difference_result = {
        "supported": None,
        "feasible": None,
        "message": "No discrete candidate was available.",
    }
    continuous_values = None

    if discrete_values is not None:
        difference_result, continuous_values = solve_difference_logic(
            vs, cs, rows, discrete_values
        )

    dump_json(
        os.path.join(args.out, "difference_logic.json"),
        difference_result,
    )

    candidate_report = None
    if discrete_values is not None and continuous_values is not None:
        values = [0.0] * n
        for i, z in discrete_values.items():
            values[i] = float(z)
        for i, z in continuous_values.items():
            values[i] = float(z)

        check = validate(m, vs, cs, rows, values)
        objective = m.ObjCon + math.fsum(
            v.Obj * values[i] for i, v in enumerate(vs)
        )
        check["objective"] = objective
        dump_json(
            os.path.join(args.out, "validation.json"),
            check,
        )

        with open(os.path.join(args.out, "candidate.sol"), "w") as f:
            f.write(f"# Objective value = {objective:.12g}\n")
            for i, v in enumerate(vs):
                f.write(f"{v.VarName} {values[i]:.12g}\n")

        candidate_report = {
            "solution_file": "candidate.sol",
            "validation_file": "validation.json",
            "validation": check,
        }

    largest = partition_report[
        "without_assignment_rows"
    ]["largest_component_sizes"]

    report = {
        "source": args.mps,
        "counts": {
            "variables": n,
            "constraints": nr,
            "nonzeros": sum(map(len, rows)),
            "variable_classes": dict(Counter(vclass(v) for v in vs)),
            "row_classes": dict(Counter(row_classes)),
        },
        "assignment_rows": {
            "count": len(assignments),
            "file": "assignment_rows.json",
        },
        "incidence_after_removing_assignment_rows": {
            "component_count": len(comps),
            "largest_component_sizes": largest[:20],
            "file": "partitions.json",
        },
        "repetition": {
            "file": "repetition.json",
            "fingerprint_group_sizes": sorted(
                [len(g["components"]) for g in repetition_groups],
                reverse=True,
            ),
            "exact_verified_map_count": len(verified_maps),
        },
        "assignment_coupling": {
            "file": "assignment_coupling.json",
            "components_touched": coupling["components_touched"],
            "symmetric_under_verified_maps":
                coupling["symmetric_under_verified_maps"],
        },
        "discrete_projection": discrete_result,
        "difference_logic": difference_result,
        "candidate": candidate_report,
    }

    if candidate_report and candidate_report["validation"]["valid"]:
        report["conclusion"] = (
            "A complete candidate was independently validated against every "
            "original row and bound. This proves ns1905797 feasible."
        )
    elif discrete_result.get("status") == "INFEASIBLE":
        report["conclusion"] = (
            "The sound discrete projection is infeasible. Because every "
            "projected constraint is necessary, this proves the original "
            "MPS infeasible."
        )
    elif (
        len(assignments) == 72
        and len(comps) == 4
        and len(set(len(c) for c in comps)) == 1
        and len(verified_maps) >= 3
        and coupling["symmetric_under_verified_maps"]
    ):
        report["conclusion"] = (
            "The incidence matrix proves a four-block symmetric formulation "
            "coupled by exactly 72 assignment rows. The blocks are exact "
            "coefficient-level isomorphic copies under the maps in "
            "repetition.json. No global feasibility conclusion was obtained."
        )
    else:
        report["conclusion"] = (
            "The report gives incidence-derived components, repetition "
            "invariants, and any exact verified maps. No global feasibility "
            "conclusion was obtained."
        )

    dump_json(os.path.join(args.out, "report.json"), report)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
