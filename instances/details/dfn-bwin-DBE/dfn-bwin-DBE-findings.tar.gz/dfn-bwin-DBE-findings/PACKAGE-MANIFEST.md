# Package manifest: dfn-bwin-DBE

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 8
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/structure.json`
- `logs/tree-run-001.log`
- `logs/verify-dfn-exact.log`
- `scripts/dfn_tree_certificate.py`
- `scripts/verify_dfn_exact.py`
- `solutions/dfn-bwin-DBE-public.sol.gz`
- `solutions/dfn-bwin-DBE.dp-tree.sol`

## Excluded files

- `input/dfn-bwin-DBE.mps.gz (81186 bytes; raw benchmark input; sha256 df12d48c2244ecc743d1086f24e653fb11343cd2e253b05cbaf55d257d4af859)`
