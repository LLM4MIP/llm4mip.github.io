#!/usr/bin/env python3
import sys
import re
import gzip
import math
import shlex
import xml.etree.ElementTree as ET
from collections import defaultdict, deque

import gurobipy as gp
from gurobipy import GRB


X_RE = re.compile(
    r"^XHC\(LD_LD_([0-9]+(?:\.[0-9]+)?)__(.+)\)$"
)


def open_maybe_gzip(path, mode="rb"):
    if path.endswith(".gz"):
        return gzip.open(path, mode)
    return open(path, mode)


def parse_solution(path):
    """Read MIPLIB/CPLEX XML .sol or a two-column text .sol."""
    with open_maybe_gzip(path, "rb") as f:
        raw = f.read()

    values = {}
    stripped = raw.lstrip()

    if stripped.startswith(b"<"):
        root = ET.fromstring(raw)
        for elem in root.iter():
            if elem.tag.split("}")[-1] == "variable":
                name = elem.attrib.get("name")
                value = elem.attrib.get("value")
                if name is not None and value is not None:
                    values[name] = float(value)
        return values

    text = raw.decode("utf-8", errors="replace")
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("=") or line.lower().startswith("objective"):
            continue
        parts = shlex.split(line)
        if len(parts) >= 2:
            try:
                values[parts[0]] = float(parts[1])
            except ValueError:
                pass
    return values


def row_terms(model, constr):
    expr = model.getRow(constr)
    return [(expr.getVar(i), expr.getCoeff(i))
            for i in range(expr.size())]


def constraint_violation(sense, lhs, rhs):
    if sense == "<":
        return max(0.0, lhs - rhs)
    if sense == ">":
        return max(0.0, rhs - lhs)
    return abs(lhs - rhs)


def check_solution(model, values, label):
    max_bound = (0.0, None)
    max_integrality = (0.0, None)

    for v in model.getVars():
        x = values.get(v.VarName, 0.0)

        bv = max(0.0, v.LB - x)
        if not math.isinf(v.UB):
            bv = max(bv, x - v.UB)
        if bv > max_bound[0]:
            max_bound = (bv, v.VarName)

        if v.VType != GRB.CONTINUOUS:
            iv = abs(x - round(x))
            if iv > max_integrality[0]:
                max_integrality = (iv, v.VarName)

    max_row = (0.0, None, None, None)
    for c in model.getConstrs():
        lhs = sum(a * values.get(v.VarName, 0.0)
                  for v, a in row_terms(model, c))
        viol = constraint_violation(c.Sense, lhs, c.RHS)
        if viol > max_row[0]:
            max_row = (viol, c.ConstrName, lhs, c.RHS)

    objective = model.ObjCon + sum(
        v.Obj * values.get(v.VarName, 0.0) for v in model.getVars()
    )

    selected = [
        (v.VarName, values.get(v.VarName, 0.0))
        for v in model.getVars()
        if v.VarName.startswith("XHC(")
        and values.get(v.VarName, 0.0) > 0.5
    ]

    print(f"SOLUTION_CHECK {label}")
    print(f"  supplied_nonzeros_or_entries = {len(values)}")
    print(f"  objective                  = {objective:.12f}")
    print(f"  selected_design_variables  = {len(selected)}")
    print(f"  max_bound_violation        = {max_bound[0]:.12g}"
          f" at {max_bound[1]}")
    print(f"  max_integrality_violation  = {max_integrality[0]:.12g}"
          f" at {max_integrality[1]}")
    print(f"  max_row_violation          = {max_row[0]:.12g}"
          f" at {max_row[1]} lhs={max_row[2]} rhs={max_row[3]}")
    return objective, max_bound[0], max_integrality[0], max_row[0]


class DSU:
    def __init__(self, n):
        self.p = list(range(n))
        self.r = [0] * n

    def find(self, x):
        while self.p[x] != x:
            self.p[x] = self.p[self.p[x]]
            x = self.p[x]
        return x

    def union(self, a, b):
        a = self.find(a)
        b = self.find(b)
        if a == b:
            return False
        if self.r[a] < self.r[b]:
            a, b = b, a
        self.p[b] = a
        if self.r[a] == self.r[b]:
            self.r[a] += 1
        return True


def mst_cost(n, weighted_edges, excluded=None):
    dsu = DSU(n)
    cost = 0
    used = 0

    for w, u, v, key in sorted(weighted_edges):
        if key == excluded:
            continue
        if dsu.union(u, v):
            cost += w
            used += 1
            if used == n - 1:
                return cost
    return None


def main():
    if len(sys.argv) not in (2, 3):
        print("Usage:")
        print("  python dfn_tree_certificate.py "
              "dfn-bwin-DBE.mps.gz [public_solution.sol.gz]")
        return 2

    mps_path = sys.argv[1]
    public_sol_path = sys.argv[2] if len(sys.argv) == 3 else None

    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()
    model = gp.read(mps_path, env=env)

    # Explicitly do not call presolve() or optimize().
    variables = model.getVars()
    constraints = model.getConstrs()
    var_by_name = {v.VarName: v for v in variables}

    fc_rows = [c for c in constraints if c.ConstrName.startswith("FC(")]
    cap_rows = [c for c in constraints if c.ConstrName.startswith("CAP(")]
    hrc_rows = [c for c in constraints if c.ConstrName.startswith("HRC(")]
    xvars = [v for v in variables if v.VarName.startswith("XHC(")]
    efvars = [v for v in variables if v.VarName.startswith("EF(")]

    if (len(fc_rows), len(cap_rows), len(hrc_rows),
            len(xvars), len(efvars)) != (100, 90, 45, 2475, 810):
        raise RuntimeError("Unexpected formulation dimensions/families")

    # Parse FC rows into commodity group, node and supply.
    fc_data = {}
    groups = defaultdict(dict)
    nodes_set = set()

    for c in fc_rows:
        name = c.ConstrName
        if not (name.startswith("FC(") and name.endswith(")")):
            raise RuntimeError(f"Cannot parse FC row {name}")
        inner = name[3:-1]
        group, node = inner.rsplit("__", 1)
        fc_data[name] = (group, node)
        groups[group][node] = c.RHS
        nodes_set.add(node)

    nodes = sorted(nodes_set)
    n = len(nodes)
    node_index = {v: i for i, v in enumerate(nodes)}

    if n != 10 or len(groups) != 10:
        raise RuntimeError(
            f"Expected 10 nodes and 10 groups, got {n}, {len(groups)}"
        )

    # Infer each EF arc direction directly from FC coefficients:
    # the equations use outflow - inflow = RHS, so coefficient +1 is
    # the tail and coefficient -1 is the head.
    ef_occ = defaultdict(list)
    for c in fc_rows:
        group, node = fc_data[c.ConstrName]
        for v, a in row_terms(model, c):
            if v.VarName.startswith("EF("):
                ef_occ[v.VarName].append((group, node, a))

    arc_var = {}
    for v in efvars:
        occ = ef_occ[v.VarName]
        if len(occ) != 2:
            raise RuntimeError(
                f"{v.VarName} has {len(occ)} FC incidences, expected 2"
            )
        if occ[0][0] != occ[1][0]:
            raise RuntimeError(f"Commodity mismatch for {v.VarName}")

        group = occ[0][0]
        tail = None
        head = None
        for _, node, a in occ:
            if abs(a - 1.0) <= 1e-9:
                tail = node
            elif abs(a + 1.0) <= 1e-9:
                head = node
            else:
                raise RuntimeError(
                    f"Unexpected FC coefficient {a} for {v.VarName}"
                )
        if tail is None or head is None:
            raise RuntimeError(f"Could not orient {v.VarName}")
        key = (group, tail, head)
        if key in arc_var:
            raise RuntimeError(f"Duplicate arc variable for {key}")
        arc_var[key] = v.VarName

    # Extract source and destination demands for every commodity.
    source_of_group = {}
    demand_by_group = {}

    for group, balances in sorted(groups.items()):
        if set(balances) != set(nodes):
            raise RuntimeError(f"Incomplete FC rows for {group}")

        total = sum(balances.values())
        if abs(total) > 1e-7:
            raise RuntimeError(
                f"Commodity {group} balances do not sum to zero: {total}"
            )

        positive = [node for node, rhs in balances.items() if rhs > 1e-9]
        negative = [node for node, rhs in balances.items() if rhs < -1e-9]

        if len(positive) != 1 or len(negative) != n - 1:
            raise RuntimeError(
                f"{group}: expected one source and nine sinks"
            )

        source = positive[0]
        source_of_group[group] = source
        demand_by_group[group] = {
            node: -rhs for node, rhs in balances.items() if rhs < -1e-9
        }

    source_nodes = list(source_of_group.values())
    all_sources_distinct = len(set(source_nodes)) == n
    all_pair_positive = (
        all_sources_distinct
        and all(
            demand_by_group[g].get(t, 0.0) > 0.0
            for g in groups
            for t in nodes
            if t != source_of_group[g]
        )
    )

    print("STRUCTURE")
    print(f"  nodes                  = {nodes}")
    print(f"  commodities            = {len(groups)}")
    print(f"  distinct_source_nodes  = {all_sources_distinct}")
    print(f"  every_ordered_demand_positive = {all_pair_positive}")

    if not all_pair_positive:
        raise RuntimeError(
            "Cannot use the connectivity/tree proof because not all "
            "ordered source-destination demands are positive"
        )

    # Identify edge endpoints by matching X suffixes to node pairs.
    def endpoints_from_suffix(suffix):
        matches = []
        for i, a in enumerate(nodes):
            for j, b in enumerate(nodes):
                if i < j and (suffix == a + "_" + b
                              or suffix == b + "_" + a):
                    matches.append((i, j))
        if len(matches) != 1:
            raise RuntimeError(
                f"Could not uniquely parse edge suffix {suffix}: {matches}"
            )
        return matches[0]

    designs = defaultdict(list)
    x_meta = {}

    for v in xvars:
        match = X_RE.match(v.VarName)
        if not match:
            raise RuntimeError(f"Cannot parse X variable {v.VarName}")

        capacity_float = float(match.group(1))
        capacity = int(round(capacity_float))
        if abs(capacity_float - capacity) > 1e-7:
            raise RuntimeError(f"Nonintegral capacity in {v.VarName}")

        suffix = match.group(2)
        u, w = endpoints_from_suffix(suffix)
        edge = (u, w)

        cents = int(round(100.0 * v.Obj))
        if abs(v.Obj - cents / 100.0) > 1e-7:
            raise RuntimeError(
                f"Objective is not exact cents: {v.VarName} obj={v.Obj}"
            )

        designs[edge].append((capacity, cents, v.VarName))
        x_meta[v.VarName] = (edge, capacity, cents)

    if len(designs) != 45:
        raise RuntimeError(f"Expected 45 edges, got {len(designs)}")

    expected_caps = list(range(80000, 350001, 5000))
    for edge, opts in designs.items():
        opts.sort()
        caps = [x[0] for x in opts]
        if caps != expected_caps:
            raise RuntimeError(
                f"Unexpected capacity levels for edge {edge}: {caps}"
            )

    # Verify the HRC and CAP linking templates needed by the proof.
    hrc_seen = set()
    for c in hrc_rows:
        terms = row_terms(model, c)
        if c.Sense != ">" or abs(c.RHS + 1.0) > 1e-9:
            raise RuntimeError(f"Unexpected HRC sense/RHS: {c.ConstrName}")
        if len(terms) != 55:
            raise RuntimeError(f"Unexpected HRC degree: {c.ConstrName}")

        edge = None
        for v, a in terms:
            if v.VarName not in x_meta or abs(a + 1.0) > 1e-9:
                raise RuntimeError(f"Unexpected HRC term in {c.ConstrName}")
            this_edge = x_meta[v.VarName][0]
            edge = this_edge if edge is None else edge
            if this_edge != edge:
                raise RuntimeError(f"Mixed edges in {c.ConstrName}")
        hrc_seen.add(edge)

    if hrc_seen != set(designs):
        raise RuntimeError("HRC rows do not cover all physical edges")

    cap_count = defaultdict(int)
    ef_cap_count = defaultdict(int)

    for c in cap_rows:
        if c.Sense != "<" or abs(c.RHS) > 1e-9:
            raise RuntimeError(f"Unexpected CAP sense/RHS: {c.ConstrName}")

        x_terms = []
        flow_terms = []
        for v, a in row_terms(model, c):
            if v.VarName in x_meta:
                x_terms.append((v, a))
            elif v.VarName.startswith("EF("):
                flow_terms.append((v, a))
            else:
                raise RuntimeError(f"Unexpected CAP term in {c.ConstrName}")

        if len(x_terms) != 55 or len(flow_terms) != 9:
            raise RuntimeError(f"Unexpected CAP degree in {c.ConstrName}")

        edge = x_meta[x_terms[0][0].VarName][0]
        for v, a in x_terms:
            e, capacity, _ = x_meta[v.VarName]
            if e != edge or abs(a + capacity) > 1e-7:
                raise RuntimeError(f"Bad design coefficient in {c.ConstrName}")

        for v, a in flow_terms:
            if abs(a - 1.0) > 1e-9:
                raise RuntimeError(f"Bad flow coefficient in {c.ConstrName}")
            ef_cap_count[v.VarName] += 1

        cap_count[edge] += 1

    if any(cap_count[e] != 2 for e in designs):
        raise RuntimeError("Every physical edge must have two CAP rows")
    if any(ef_cap_count[v.VarName] != 1 for v in efvars):
        raise RuntimeError("Every EF variable must occur in one CAP row")

    print("  exact_HRC_CAP_templates = True")

    if public_sol_path is not None:
        public_values = parse_solution(public_sol_path)
        check_solution(model, public_values, "PUBLIC")

        print("PUBLIC_SELECTED_DESIGNS")
        for v in sorted(xvars, key=lambda z: z.VarName):
            val = public_values.get(v.VarName, 0.0)
            if val > 0.5:
                edge, capacity, cents = x_meta[v.VarName]
                print(
                    f"  {nodes[edge[0]]:12s} -- {nodes[edge[1]]:12s}"
                    f" cap={capacity:6d} cost={cents/100:.2f}"
                    f" value={val:.12g}"
                )

    # Minimum edge opening costs. These are valid for every design,
    # regardless of the actual required capacity.
    min_open_cost = {
        edge: min(cents for _, cents, _ in opts)
        for edge, opts in designs.items()
    }

    weighted_edges = [
        (min_open_cost[(u, v)], u, v, (u, v))
        for u, v in designs
    ]

    mst_open_lb = mst_cost(n, weighted_edges)

    ten_cheapest_lb = sum(
        sorted(min_open_cost.values())[:n]
    )

    # Exact minimum opening-cost connected graph with n edges.
    # Such a graph is unicyclic. Removing one cycle edge gives a
    # spanning tree. Enumerate which edge is the extra edge.
    connected_n_edge_lb = None
    connected_n_edge_witness = None

    for edge in designs:
        tree_cost = mst_cost(n, weighted_edges, excluded=edge)
        if tree_cost is None:
            continue
        value = tree_cost + min_open_cost[edge]
        if connected_n_edge_lb is None or value < connected_n_edge_lb:
            connected_n_edge_lb = value
            connected_n_edge_witness = edge

    print("OPENING_COST_LOWER_BOUNDS")
    print(f"  minimum_open_cost_MST       = {mst_open_lb/100:.2f}")
    print(f"  ten_globally_cheapest_edges = {ten_cheapest_lb/100:.2f}")
    print(f"  connected_10_edge_minimum   = "
          f"{connected_n_edge_lb/100:.2f}")
    if connected_n_edge_witness is not None:
        u, v = connected_n_edge_witness
        print(f"  connected_10_extra_witness  = "
              f"{nodes[u]} -- {nodes[v]}")

    # For each cut S, calculate traffic S -> complement and complement -> S.
    full = (1 << n) - 1
    cut_forward = [0] * (1 << n)
    cut_backward = [0] * (1 << n)
    cut_required = [0] * (1 << n)

    for mask in range(1, full):
        forward = 0
        backward = 0

        for group in groups:
            s = node_index[source_of_group[group]]
            s_in = bool(mask & (1 << s))

            for dest, demand_float in demand_by_group[group].items():
                demand = int(round(demand_float))
                if abs(demand_float - demand) > 1e-7:
                    raise RuntimeError("Nonintegral demand encountered")

                t = node_index[dest]
                t_in = bool(mask & (1 << t))

                if s_in and not t_in:
                    forward += demand
                elif not s_in and t_in:
                    backward += demand

        cut_forward[mask] = forward
        cut_backward[mask] = backward
        cut_required[mask] = max(forward, backward)

    def best_option(edge, mask):
        required = cut_required[mask]
        feasible = [
            (cents, capacity, name)
            for capacity, cents, name in designs[edge]
            if capacity >= required
        ]
        if not feasible:
            return None
        cents, capacity, name = min(feasible)
        return cents, capacity, name

    # Exact subset DP for all spanning trees.
    #
    # dp[S,r] is the minimum internal edge cost of a tree on S rooted at r.
    # If C is one child subtree of r, its connecting edge sees exactly the
    # global cut (C, V\C), so its required capacity depends only on C.
    INF = 10**30
    size = 1 << n
    dp = [[INF] * n for _ in range(size)]
    choice = {}

    for r in range(n):
        dp[1 << r][r] = 0

    for card in range(2, n + 1):
        for mask in range(1, size):
            if mask.bit_count() != card:
                continue

            for r in range(n):
                if not (mask & (1 << r)):
                    continue

                rest = mask & ~(1 << r)
                sub = rest
                best = INF
                best_choice = None

                while sub:
                    remainder = mask ^ sub
                    if dp[remainder][r] < INF:
                        bits = sub
                        while bits:
                            ubit = bits & -bits
                            u = ubit.bit_length() - 1
                            bits ^= ubit

                            if dp[sub][u] >= INF:
                                continue

                            edge = (min(r, u), max(r, u))
                            option = best_option(edge, sub)
                            if option is None:
                                continue

                            edge_cents = option[0]
                            value = (dp[remainder][r]
                                     + dp[sub][u]
                                     + edge_cents)
                            if value < best:
                                best = value
                                best_choice = (sub, u)

                    sub = (sub - 1) & rest

                dp[mask][r] = best
                if best_choice is not None:
                    choice[(mask, r)] = best_choice

    root_values = [dp[full][r] for r in range(n)]
    if any(x != root_values[0] for x in root_values):
        raise RuntimeError(
            f"Root-dependent tree optimum, indicating a DP error: "
            f"{root_values}"
        )

    tree_opt = root_values[0]
    root = 0

    def reconstruct(mask, r):
        if mask == (1 << r):
            return []
        sub, u = choice[(mask, r)]
        remainder = mask ^ sub
        return (reconstruct(remainder, r)
                + reconstruct(sub, u)
                + [(r, u, sub)])

    rooted_tree_edges = reconstruct(full, root)

    if len(rooted_tree_edges) != n - 1:
        raise RuntimeError("Reconstructed object is not a spanning tree")

    print("EXACT_TREE_OPTIMUM")
    print(f"  objective = {tree_opt/100:.2f}")
    print(f"  root      = {nodes[root]}")
    print("  edges:")

    selected_x = {}
    tree_simple_edges = []

    for parent, child, child_mask in rooted_tree_edges:
        edge = (min(parent, child), max(parent, child))
        option = best_option(edge, child_mask)
        if option is None:
            raise RuntimeError("Reconstructed infeasible tree edge")

        cents, capacity, xname = option
        selected_x[xname] = 1.0
        tree_simple_edges.append((parent, child))

        subset_names = [
            nodes[i] for i in range(n) if child_mask & (1 << i)
        ]
        print(
            f"  {nodes[parent]:12s} -- {nodes[child]:12s}"
            f" cut_side={{{','.join(subset_names)}}}"
            f" loads=({cut_forward[child_mask]},"
            f"{cut_backward[child_mask]})"
            f" cap={capacity} cost={cents/100:.2f}"
        )

    # Generate the unique tree routing for each commodity.
    adjacency = [[] for _ in range(n)]
    for u, v in tree_simple_edges:
        adjacency[u].append(v)
        adjacency[v].append(u)

    def path_between(source, target):
        parent = [-1] * n
        parent[source] = source
        q = deque([source])

        while q:
            u = q.popleft()
            if u == target:
                break
            for v in adjacency[u]:
                if parent[v] == -1:
                    parent[v] = u
                    q.append(v)

        if parent[target] == -1:
            raise RuntimeError("Reconstructed tree is disconnected")

        path = []
        x = target
        while x != source:
            path.append(x)
            x = parent[x]
        path.append(source)
        path.reverse()
        return path

    generated = dict(selected_x)

    for group in groups:
        source_name = source_of_group[group]
        source = node_index[source_name]

        for dest_name, demand_float in demand_by_group[group].items():
            demand = int(round(demand_float))
            target = node_index[dest_name]
            path = path_between(source, target)

            for a, b in zip(path, path[1:]):
                key = (group, nodes[a], nodes[b])
                if key not in arc_var:
                    raise RuntimeError(
                        f"Required directed arc variable is absent: {key}"
                    )
                name = arc_var[key]
                generated[name] = generated.get(name, 0.0) + demand

    generated_objective, bv, iv, rv = check_solution(
        model, generated, "GENERATED_DP_TREE"
    )

    if max(bv, iv, rv) > 1e-7:
        raise RuntimeError("Generated tree solution failed exact checking")

    if abs(generated_objective - tree_opt / 100.0) > 1e-6:
        raise RuntimeError(
            "Generated solution objective disagrees with tree DP"
        )

    output_sol = "dfn-bwin-DBE.dp-tree.sol"
    with open(output_sol, "w", encoding="utf-8") as f:
        f.write(f"# Objective value = {tree_opt/100:.2f}\n")
        for name in sorted(generated):
            value = generated[name]
            if abs(value) > 1e-12:
                f.write(f"{name} {value:.17g}\n")

    print(f"GENERATED_SOLUTION_FILE = {output_sol}")

    # Global proof:
    #
    # A feasible support is connected, hence has at least 9 edges.
    # Exactly 9 edges means a spanning tree, covered by the DP.
    # Every connected support with >=10 edges has opening cost at least
    # connected_n_edge_lb. Actual capacity choices can only cost more.
    proof = connected_n_edge_lb >= tree_opt

    print("GLOBAL_CERTIFICATE")
    print(f"  all_feasible_supports_connected = {all_pair_positive}")
    print(f"  best_9_edge_tree_cents          = {tree_opt}")
    print(f"  >=10_edge_lower_bound_cents     = "
          f"{connected_n_edge_lb}")
    print(f"  GLOBAL_PROOF                    = "
          f"{'YES' if proof else 'NO'}")

    if proof:
        print(f"  PROVEN_GLOBAL_OPTIMUM           = {tree_opt/100:.2f}")
    else:
        gap = (tree_opt - connected_n_edge_lb) / 100.0
        print(f"  unresolved_opening_bound_gap    = {gap:.2f}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
