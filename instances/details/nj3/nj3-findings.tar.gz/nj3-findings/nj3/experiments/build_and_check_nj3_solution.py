#!/usr/bin/env python3
"""Lift a connected district assignment to a complete nj3 MPS solution.

All nonzero values are constructed from integers and Decimal coefficients in
the original MPS.  Connectivity flows are routed on deterministic BFS trees.
Every original row, bound, and integer declaration is then checked with exact
Decimal arithmetic; any nonzero violation makes the process fail.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from decimal import Decimal
from pathlib import Path


THIS = Path(__file__).resolve()
NJ1_EXPERIMENTS = THIS.parents[2] / "nj1" / "experiments"
sys.path.insert(0, str(NJ1_EXPERIMENTS))
from nj_block_forensics import numeric_suffix, parse_mps, sha256  # noqa: E402


NODES = 595
DISTRICTS = 12
EDGES = 1574
LOWER_POPULATION = 696_025
UPPER_POPULATION = 769_290
EXPECTED_VARIABLES = 85_224
EXPECTED_ROWS = 118_986
ASSIGNMENT_BASE = 70_945
ROOT_BASE = 78_085


def cname(index: int) -> str:
    return f"C{index:04d}"


def rname(index: int) -> str:
    return f"R{index:04d}"


def row_violation(sense: str, lhs: Decimal, rhs: Decimal) -> Decimal:
    if sense == "E":
        return abs(lhs - rhs)
    if sense == "L":
        return max(Decimal(0), lhs - rhs)
    if sense == "G":
        return max(Decimal(0), rhs - lhs)
    raise ValueError(f"unsupported sense {sense}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("assignment_json", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("validation_json", type=Path)
    args = parser.parse_args()

    model = parse_mps(args.mps)
    if len(model["variables"]) != EXPECTED_VARIABLES or len(model["rows"]) - 1 != EXPECTED_ROWS:
        raise ValueError("input is not the audited official nj3 model")

    certificate = json.loads(args.assignment_json.read_text(encoding="utf-8"))
    assignment = list(certificate["assignment_zero_based_district"])
    if len(assignment) != NODES or set(assignment) - set(range(DISTRICTS)):
        raise ValueError("assignment must contain 595 district labels in 0..11")

    populations = []
    for node in range(NODES):
        row = rname(90_440 + DISTRICTS * node)
        variable = cname(ASSIGNMENT_BASE + DISTRICTS * node)
        coefficient = [
            value for candidate, value in model["rows"][row]["terms"]
            if candidate == variable
        ]
        populations.append(int(-coefficient[0]) if coefficient else 0)

    edges = []
    adjacency = [[] for _ in range(NODES)]
    for edge in range(EDGES):
        row = rname(596 + DISTRICTS * edge)
        endpoints = [
            (numeric_suffix(variable) - ASSIGNMENT_BASE) // DISTRICTS
            for variable, _ in model["rows"][row]["terms"]
            if ASSIGNMENT_BASE <= numeric_suffix(variable) < ASSIGNMENT_BASE + NODES * DISTRICTS
        ]
        if len(endpoints) != 2:
            raise ValueError(f"bad edge row {row}: {endpoints}")
        left, right = endpoints
        edges.append((left, right))
        adjacency[left].append(right)
        adjacency[right].append(left)

    # Directed flow columns are unchanged across nj1, nj2, and nj3.
    arcs = {}
    for index in range(26_029, 63_805):
        variable = cname(index)
        balance_terms = []
        for row, coefficient in model["variables"][variable]["rows"]:
            row_index = numeric_suffix(row)
            if 90_440 <= row_index <= 97_579:
                node = (row_index - 90_440) // DISTRICTS
                district = (row_index - 90_440) % DISTRICTS
                balance_terms.append((node, district, coefficient))
        if len(balance_terms) != 2 or {item[2] for item in balance_terms} != {Decimal(-1), Decimal(1)}:
            raise ValueError(f"bad flow incidence {variable}: {balance_terms}")
        tail = next(node for node, _, coefficient in balance_terms if coefficient == -1)
        head = next(node for node, _, coefficient in balance_terms if coefficient == 1)
        districts = {district for _, district, _ in balance_terms}
        if len(districts) != 1:
            raise ValueError(f"cross-district flow {variable}: {balance_terms}")
        arcs[(tail, head, districts.pop())] = variable

    values: dict[str, Decimal] = defaultdict(Decimal)
    for node, district in enumerate(assignment):
        values[cname(ASSIGNMENT_BASE + DISTRICTS * node + district)] = Decimal(1)

    district_populations = []
    district_sizes = []
    roots = []
    for district in range(DISTRICTS):
        selected = {node for node, label in enumerate(assignment) if label == district}
        if not selected:
            raise ValueError(f"empty district {district}")
        population = sum(populations[node] for node in selected)
        if not LOWER_POPULATION <= population <= UPPER_POPULATION:
            raise ValueError(f"district {district} population {population} outside bounds")
        district_populations.append(population)
        district_sizes.append(len(selected))

        root = min(selected)
        roots.append(root)
        values[cname(ROOT_BASE + DISTRICTS * root + district)] = Decimal(1)
        values[cname(18_889 + DISTRICTS * root + district)] = Decimal(population)

        parent = {root: None}
        order = [root]
        for node in order:
            for neighbor in sorted(adjacency[node]):
                if neighbor in selected and neighbor not in parent:
                    parent[neighbor] = node
                    order.append(neighbor)
        if set(parent) != selected:
            missing = sorted(selected - set(parent))
            raise ValueError(f"district {district} disconnected; missing {missing[:20]}")
        subtree = {node: populations[node] for node in selected}
        for node in reversed(order[1:]):
            predecessor = parent[node]
            assert predecessor is not None
            subtree[predecessor] += subtree[node]
            arc = arcs.get((predecessor, node, district))
            if arc is None:
                raise ValueError(f"missing directed arc {predecessor}->{node}, district {district}")
            values[arc] = Decimal(subtree[node])

        # q_(i,d)=1 exactly after the chosen minimum-index root.
        for node in range(root + 1, NODES):
            values[cname(63_805 + DISTRICTS * node + district)] = Decimal(1)

    for edge, (left, right) in enumerate(edges):
        if assignment[left] == assignment[right]:
            continue
        for district in (assignment[left], assignment[right]):
            values[cname(1 + DISTRICTS * edge + district)] = Decimal(1)

    objective_rows = [row for row, info in model["rows"].items() if info["sense"] == "N"]
    if len(objective_rows) != 1:
        raise ValueError(f"unexpected objective rows: {objective_rows}")
    objective_row = objective_rows[0]
    objective = sum(
        coefficient * values[variable]
        for variable, coefficient in model["rows"][objective_row]["terms"]
    )

    row_violations = []
    for row, info in model["rows"].items():
        if info["sense"] == "N":
            continue
        lhs = sum(coefficient * values[variable] for variable, coefficient in info["terms"])
        rhs = model["rhs"].get(row, Decimal(0))
        violation = row_violation(info["sense"], lhs, rhs)
        if violation:
            row_violations.append((violation, row, lhs, rhs, info["sense"]))

    bound_violations = []
    integrality_violations = []
    unknown_variables = sorted(set(values) - set(model["variables"]))
    for variable, info in model["variables"].items():
        value = values[variable]
        violation = max(Decimal(0), info["lower"] - value)
        if info["upper"] is not None:
            violation = max(violation, value - info["upper"])
        if violation:
            bound_violations.append((violation, variable, value))
        if info["integer"] and value != value.to_integral_value():
            integrality_violations.append((variable, value))
    row_violations.sort(reverse=True)
    bound_violations.sort(reverse=True)

    args.solution.parent.mkdir(parents=True, exist_ok=True)
    with args.solution.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write(f"=obj= {objective}\n")
        handle.write(f"# Objective value = {objective}\n")
        for variable in model["variables"]:
            if values[variable]:
                handle.write(f"{variable} {values[variable]}\n")

    result = {
        "evidence_level": "full original-MPS Decimal reconstruction and zero-tolerance row/bound/integrality check",
        "instance": "nj3",
        "source_mps_sha256": sha256(args.mps),
        "assignment_certificate_sha256": sha256(args.assignment_json),
        "solution_sha256": sha256(args.solution),
        "objective": str(objective),
        "nonzero_solution_values": sum(value != 0 for value in values.values()),
        "district_populations": district_populations,
        "district_node_counts": district_sizes,
        "minimum_index_roots_zero_based": roots,
        "node_zero_district_zero_based": assignment[0],
        "rows_checked": EXPECTED_ROWS,
        "exact_row_violation_count": len(row_violations),
        "maximum_exact_row_violation": str(row_violations[0][0] if row_violations else 0),
        "bound_violation_count": len(bound_violations),
        "integrality_violation_count": len(integrality_violations),
        "unknown_solution_variable_count": len(unknown_variables),
        "largest_row_violations": [
            {"violation": str(v), "row": row, "lhs": str(lhs), "rhs": str(rhs), "sense": sense}
            for v, row, lhs, rhs, sense in row_violations[:10]
        ],
        "strictly_feasible": not row_violations and not bound_violations
        and not integrality_violations and not unknown_variables,
    }
    args.validation_json.parent.mkdir(parents=True, exist_ok=True)
    args.validation_json.write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n"
    )
    print(json.dumps(result, indent=2))
    if not result["strictly_feasible"]:
        raise SystemExit("constructed solution failed exact original-MPS validation")


if __name__ == "__main__":
    main()
