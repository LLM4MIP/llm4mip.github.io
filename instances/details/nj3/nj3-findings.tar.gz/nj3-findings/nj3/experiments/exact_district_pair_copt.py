#!/usr/bin/env python3
"""Solve one nj adjacent-district repartition by exact cut MILP.

The binary model minimizes the exact, integer-scaled weight of edges cut
inside the union of two districts and enforces both population bounds.
Connectivity is imposed by a finite cutting-plane loop: whenever an integer
incumbent has multiple components on either side, a valid rooted connectivity
cut excludes that disconnected component.  If COPT proves the current relaxed
model optimal and its optimum is connected, that solution is also globally
optimal for the connected two-district subproblem.

This is a pair-local certificate only.  Any improving assignment still needs
lifting and a tolerance-zero check against each original MPS.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import platform
import sys
import time
from decimal import Decimal
from pathlib import Path


THIS = Path(__file__).resolve()
NJ1_EXPERIMENTS = Path(
    os.environ.get("NJ_HELPER_DIR", THIS.parents[2] / "nj1" / "experiments")
)
sys.path.insert(0, str(NJ1_EXPERIMENTS))
from connected_boundary_steepest_descent import (  # noqa: E402
    DISTRICTS,
    LOWER_POPULATION,
    NODES,
    UPPER_POPULATION,
    extract_graph,
    objective,
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def components(selected: set[int], adjacency: dict[int, list[int]]) -> list[set[int]]:
    unseen = set(selected)
    answer = []
    while unseen:
        seed = min(unseen)
        seen = {seed}
        queue = [seed]
        unseen.remove(seed)
        for node in queue:
            for neighbor in adjacency[node]:
                if neighbor in unseen:
                    unseen.remove(neighbor)
                    seen.add(neighbor)
                    queue.append(neighbor)
        answer.append(seen)
    return answer


def safe_attr(model, *names):
    for name in names:
        try:
            return getattr(model, name)
        except Exception:
            pass
    return None


def pair_rows(assignment, populations, edges):
    pairs = sorted({
        tuple(sorted((assignment[left], assignment[right])))
        for left, right, _ in edges
        if assignment[left] != assignment[right]
    })
    rows = []
    for first, second in pairs:
        node_set = {
            node for node, district in enumerate(assignment)
            if district in (first, second)
        }
        induced = [
            (left, right, cost) for left, right, cost in edges
            if left in node_set and right in node_set
        ]
        old_cut = sum(
            (cost for left, right, cost in induced
             if assignment[left] != assignment[right]),
            Decimal(0),
        )
        rows.append({
            "pair": [first, second],
            "nodes": len(node_set),
            "induced_edges": len(induced),
            "population": sum(populations[node] for node in node_set),
            "old_pair_cut_weight": str(old_cut),
            "old_full_objective_contribution": str(2 * old_cut),
        })
    return sorted(rows, key=lambda row: (-Decimal(row["old_pair_cut_weight"]), row["pair"]))


def solve_pair(args, populations, edges, assignment, first, second):
    try:
        import coptpy as cp
    except ImportError as error:
        raise SystemExit("coptpy is required unless --list-pairs is used") from error

    nodes = [
        node for node, district in enumerate(assignment)
        if district in (first, second)
    ]
    node_set = set(nodes)
    induced = [
        (left, right, cost) for left, right, cost in edges
        if left in node_set and right in node_set
    ]
    adjacency = {node: [] for node in nodes}
    for left, right, _ in induced:
        adjacency[left].append(right)
        adjacency[right].append(left)
    for neighbors in adjacency.values():
        neighbors.sort()
    if len(components(node_set, adjacency)) != 1:
        raise ValueError("the selected district union is disconnected")

    anchor = min(nodes)
    zero_label = assignment[anchor]
    one_label = second if zero_label == first else first
    current_x = {node: int(assignment[node] == one_label) for node in nodes}
    old_cut = sum(
        (cost for left, right, cost in induced if current_x[left] != current_x[right]),
        Decimal(0),
    )
    digits = max((max(0, -cost.as_tuple().exponent) for _, _, cost in induced), default=0)
    scale = 10 ** digits
    integer_costs = [int(cost * scale) for _, _, cost in induced]
    if any(Decimal(value) != cost * scale
           for value, (_, _, cost) in zip(integer_costs, induced)):
        raise RuntimeError("failed to scale edge weights exactly")
    divisor = 0
    for value in integer_costs:
        divisor = math.gcd(divisor, value)
    divisor = max(divisor, 1)
    integer_costs = [value // divisor for value in integer_costs]
    effective_scale = Decimal(scale) / Decimal(divisor)

    environment = cp.Envr()
    model = environment.createModel(f"nj-pair-{first}-{second}")
    x = {
        node: model.addVar(vtype=cp.COPT.BINARY, name=f"x_{node}")
        for node in nodes
    }
    root_one = {
        node: model.addVar(vtype=cp.COPT.BINARY, name=f"r1_{node}")
        for node in nodes
    }
    cut = {
        index: model.addVar(vtype=cp.COPT.BINARY, name=f"cut_{left}_{right}")
        for index, (left, right, _) in enumerate(induced)
    }
    model.addConstr(x[anchor] == 0, name="anchor_side_zero")
    model.addConstr(cp.quicksum(root_one.values()) == 1, name="one_root")
    for node in nodes:
        model.addConstr(root_one[node] <= x[node], name=f"root_selected_{node}")

    population_one = cp.quicksum(populations[node] * x[node] for node in nodes)
    total_population = sum(populations[node] for node in nodes)
    lower_one = max(LOWER_POPULATION, total_population - UPPER_POPULATION)
    upper_one = min(UPPER_POPULATION, total_population - LOWER_POPULATION)
    model.addConstr(population_one >= lower_one, name="population_one_lower")
    model.addConstr(population_one <= upper_one, name="population_one_upper")
    for index, (left, right, _) in enumerate(induced):
        model.addConstr(cut[index] >= x[left] - x[right], name=f"cut_lr_{index}")
        model.addConstr(cut[index] >= x[right] - x[left], name=f"cut_rl_{index}")
    model.setObjective(
        cp.quicksum(integer_costs[index] * cut[index] for index in range(len(induced))),
        cp.COPT.MINIMIZE,
    )

    variables = list(x.values()) + list(root_one.values()) + list(cut.values())
    root_node = min(node for node in nodes if current_x[node])
    mip_values = (
        [current_x[node] for node in nodes]
        + [int(node == root_node) for node in nodes]
        + [int(current_x[left] != current_x[right]) for left, right, _ in induced]
    )
    model.setMipStart(variables, mip_values)
    load_return = model.loadMipStart()
    if args.log is not None:
        args.log.parent.mkdir(parents=True, exist_ok=True)
        model.setLogFile(str(args.log))
    model.setParam(cp.COPT.Param.Threads, args.threads)
    model.setParam(cp.COPT.Param.RelGap, 0.0)
    model.setParam(cp.COPT.Param.GPUMode, 0)

    started = time.monotonic()
    rounds = []
    total_cuts = 0
    best_connected = None
    proof = False
    termination = None
    for round_number in range(1, args.max_rounds + 1):
        remaining = args.time_limit - (time.monotonic() - started)
        if remaining <= 0:
            termination = "total_time_limit"
            break
        model.setParam(cp.COPT.Param.TimeLimit, max(0.01, remaining))
        model.solve()
        has_solution = bool(safe_attr(model, "hasmipsol", "HasMipSol"))
        status = safe_attr(model, "status", "Status")
        record = {
            "round": round_number,
            "status": str(status),
            "has_mip_solution": has_solution,
            "numerical_objective_scaled": str(safe_attr(model, "objval", "ObjVal")),
            "numerical_best_bound_scaled": str(safe_attr(model, "bestbnd", "BestBnd")),
        }
        if not has_solution:
            rounds.append(record)
            termination = "no_mip_solution"
            break

        values = {node: int(round(x[node].x)) for node in nodes}
        selected_zero = {node for node in nodes if values[node] == 0}
        selected_one = node_set - selected_zero
        root = max(nodes, key=lambda node: root_one[node].x)
        zero_components = components(selected_zero, adjacency)
        one_components = components(selected_one, adjacency)
        exact_cut = sum(
            (cost for left, right, cost in induced if values[left] != values[right]),
            Decimal(0),
        )
        record.update({
            "exact_pair_cut_weight": str(exact_cut),
            "population_zero": sum(populations[node] for node in selected_zero),
            "population_one": sum(populations[node] for node in selected_one),
            "zero_components": [len(item) for item in zero_components],
            "one_components": [len(item) for item in one_components],
            "one_root_zero_based": root,
        })
        if len(zero_components) == 1 and len(one_components) == 1:
            trial = assignment.copy()
            for node in nodes:
                trial[node] = zero_label if values[node] == 0 else one_label
            full_value = objective(trial, edges)
            expected = objective(assignment, edges) + 2 * (exact_cut - old_cut)
            if full_value != expected:
                raise RuntimeError("pair-local and full exact objectives disagree")
            best_connected = {
                "pair_cut_weight": str(exact_cut),
                "full_objective": str(full_value),
                "objective_delta": str(full_value - objective(assignment, edges)),
                "assignment_zero_based_district": trial,
            }
            proof = status == cp.COPT.OPTIMAL
            record["connected"] = True
            rounds.append(record)
            termination = "connected_relaxation_optimum" if proof else "connected_incumbent"
            break

        record["connected"] = False
        cuts_this_round = 0
        anchor_component = next(item for item in zero_components if anchor in item)
        for item in zero_components:
            if item is anchor_component:
                continue
            boundary = sorted({
                neighbor for node in item for neighbor in adjacency[node]
                if neighbor not in item
            })
            representative = min(item)
            model.addConstr(
                cp.quicksum(1 - x[node] for node in boundary) >= 1 - x[representative],
                name=f"conn0_{round_number}_{representative}",
            )
            cuts_this_round += 1
        root_component = next(item for item in one_components if root in item)
        for item in one_components:
            if item is root_component:
                continue
            boundary = sorted({
                neighbor for node in item for neighbor in adjacency[node]
                if neighbor not in item
            })
            representative = min(item)
            model.addConstr(
                cp.quicksum(x[node] for node in boundary)
                >= x[representative] - cp.quicksum(root_one[node] for node in item),
                name=f"conn1_{round_number}_{representative}",
            )
            cuts_this_round += 1
        if cuts_this_round == 0:
            raise RuntimeError("disconnected solution generated no connectivity cut")
        record["connectivity_cuts_added"] = cuts_this_round
        rounds.append(record)
        total_cuts += cuts_this_round
    else:
        termination = "max_rounds"

    return {
        "pair_zero_based": [first, second],
        "nodes": len(nodes),
        "induced_edges": len(induced),
        "total_population": total_population,
        "side_one_population_interval": [lower_one, upper_one],
        "anchor_zero_based": anchor,
        "side_zero_label": zero_label,
        "side_one_label": one_label,
        "old_pair_cut_weight": str(old_cut),
        "decimal_digits": digits,
        "integer_objective_divisor": divisor,
        "effective_integer_scale": str(effective_scale),
        "load_mip_start_return": repr(load_return),
        "rounds": rounds,
        "connectivity_cuts_added": total_cuts,
        "termination": termination,
        "connected_pair_optimality_proved": proof,
        "best_connected": best_connected,
        "wall_seconds": time.monotonic() - started,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("graph_mps", type=Path)
    parser.add_argument("assignment", type=Path)
    parser.add_argument("output", type=Path, nargs="?")
    parser.add_argument("--pair", nargs=2, type=int, metavar=("A", "B"))
    parser.add_argument("--list-pairs", action="store_true")
    parser.add_argument("--time-limit", type=float, default=300.0)
    parser.add_argument("--threads", type=int, default=1)
    parser.add_argument("--max-rounds", type=int, default=500)
    parser.add_argument("--log", type=Path)
    args = parser.parse_args()

    populations, edges = extract_graph(args.graph_mps)
    source = json.loads(args.assignment.read_text(encoding="utf-8"))
    assignment = list(source["assignment_zero_based_district"])
    if len(assignment) != NODES or set(assignment) != set(range(DISTRICTS)):
        raise ValueError("assignment must contain all 595 nodes and districts 0..11")
    recorded = source.get("boundary_objective_original_units")
    initial_objective = objective(assignment, edges)
    if recorded is not None and Decimal(recorded) != initial_objective:
        raise ValueError(f"recorded objective {recorded} != exact {initial_objective}")
    rows = pair_rows(assignment, populations, edges)
    if args.list_pairs:
        print(json.dumps(rows, indent=2))
        return
    if args.output is None or args.pair is None:
        parser.error("OUTPUT and --pair A B are required unless --list-pairs is used")
    pair = sorted(args.pair)
    adjacent = {tuple(row["pair"]) for row in rows}
    if tuple(pair) not in adjacent:
        raise ValueError(f"district pair {pair} is not adjacent")

    result = {
        "schema": "nj-exact-district-pair-copt-v1",
        "evidence_level": (
            "integer-scaled exact pair objective and population arithmetic; "
            "rooted connectivity-cut separation; any full assignment requires "
            "an independent original-MPS zero-tolerance lift/check"
        ),
        "host": platform.node(),
        "solver": "COPT",
        "graph_mps": args.graph_mps.as_posix(),
        "graph_mps_sha256": sha256(args.graph_mps),
        "assignment": args.assignment.as_posix(),
        "assignment_sha256": sha256(args.assignment),
        "initial_full_objective": str(initial_objective),
        "time_limit": args.time_limit,
        "threads": args.threads,
        "result": solve_pair(args, populations, edges, assignment, pair[0], pair[1]),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
    print("RESULT=" + str(args.output), flush=True)


if __name__ == "__main__":
    main()
