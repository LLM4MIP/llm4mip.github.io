# COPT 8 full-model runs from 382.0606208032

Three separate aggressive COPT 8.0.4 runs were warm-started from the
strict `382.0606208032` solution, used 16 threads, and stopped at the
1,800-second time limit. None improved the warm start.

| instance | requested seed (unsupported) | incumbent | numerical best bound | nodes |
| --- | ---: | ---: | ---: | ---: |
| nj1 | 43 | 382.0606208032 | 74.54284297688875 | 63 |
| nj2 | 47 | 382.0606208032 | 4.440892098500626e-16 | 1 |
| nj3 | 41 | 382.0606208032 | 19.284562911019115 | 1 |

These best bounds are numerical solver output, not exact lower-bound
certificates. The incumbent was already independently checked at tolerance
zero against each original MPS before it was used as a warm start. Since no
run improved it, no new solution validation was needed.

COPT 8.0.4 rejected the requested `RandomSeed` parameter as unsupported, so
the seed numbers are retained only as run labels and were not solver settings.

[`manifest.json`](manifest.json), SHA-256
`3d5755f4e3fcfae5b543e41eaee0930ba349367419537e12391790d5aee142c2`,
records parameters, source hashes, terminal values, and artifact hashes.
[`SHA256SUMS`](SHA256SUMS), SHA-256
`f7b90931ff498feb6509b89a561f576b15e90da6d4153f319d7d46305760d345`,
covers the three result files and three solver logs.
