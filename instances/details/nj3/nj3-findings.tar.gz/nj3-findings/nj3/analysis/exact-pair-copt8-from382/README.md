# Exact adjacent-pair audit from 382.0606208032

This directory archives the COPT 8.0.4 audit of every adjacent district pair
in the strict `382.0606208032` assignment.  The batch used the exact common
`nj` graph decoded from the original `nj1.mps.gz`; its SHA-256 is
`72ae4e301408a5e9ffe3f96c18f2b37b4243a74dfdaee1480c13997fd01a6166`.
For routine replay, use the compact assignment certificate
[`../../../nj1/analysis/final-assignment-382.0606208032.json`](../../../nj1/analysis/final-assignment-382.0606208032.json),
SHA-256
`a13e58bd98050c830ca3436eb616410cb60fc64d3b2424f8bf5f29cac6ddeba5`.
The archived runs used the original full trace whose uncompressed SHA-256 is
`a75a5e242532453f377420c390ca6a7d377cd9dbcd0c2a6028eea871a1a57f8e`;
that trace is preserved as
[`../../../nj1/analysis/compound-kick-from383-382.0606208032.full.json.gz`](../../../nj1/analysis/compound-kick-from383-382.0606208032.full.json.gz).

For each pair, the model assigns every node in the two-district union to one
of two sides, enforces both exact integer population bounds, and minimizes the
integer-scaled exact weight of induced cut edges.  Rooted connectivity cuts
are available and are separated iteratively.  In this run every one of the 21
population-balanced cut models returned the current cut as its COPT-optimal
solution in the first round; that solution was connected on both sides.
Consequently no connectivity cut was needed, and each incumbent is optimal
even in the weaker model that omits connectivity.  Therefore none of the 21
connected adjacent-pair repartitions can improve the objective.

The claim boundary is pair-local.  It is not a global lower bound or an
optimality proof for `nj1`, `nj2`, or `nj3`.  COPT's MIP optimal status is a
numerical solver certificate, while objective scaling, populations,
connectivity, and reported deltas are recomputed exactly by the driver.

Summary:

- adjacent pairs: 21;
- completed: 21;
- COPT-optimal with a connected optimum: 21;
- timeouts or runs without proof: 0;
- improving pairs: 0;
- connectivity cuts added: 0;
- sum of recorded wall times: about 5.40 seconds, maximum 0.72 seconds;
- every exact full-objective delta: `0E-10`.

[`manifest.json`](manifest.json) records the ranking, source hashes, proof
counts, and one record per pair.  Every `pair-A-B.result.json` contains the
integer scale, populations, solver status, exact cut value, connected
assignment, and proof flag.  Matching `solver.log` and `launcher.log` files
preserve the COPT trace.  [`SHA256SUMS`](SHA256SUMS) covers the complete
archive.

Reproduce with:

```bash
python instances/nj3/experiments/run_exact_pair_batch.py \
  instances/nj1/input/nj1.mps.gz \
  instances/nj1/analysis/final-assignment-382.0606208032.json \
  exact-pair-run \
  --time-limit-per-pair 60 --threads 1 --max-rounds 500
```
