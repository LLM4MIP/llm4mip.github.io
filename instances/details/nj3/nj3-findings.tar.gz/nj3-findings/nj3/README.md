# nj3: strict incumbent 382.0606208032

## Result and claim boundary

This directory contains a **strictly feasible solution of the original `nj3`
MPS** with objective `382.0606208032`. The official MIPLIB page listed `nj3`
as `open`, `no_solution`, and without a primal objective when checked on
2026-09-08. This is a new public incumbent relative to that page.

It is **not** an optimality result. No global lower bound or global
optimality certificate is claimed. The exact neighborhood results below only
exclude their stated local move classes.

Primary artifacts:

- [`solutions/compound-kick-382.0606208032.sol`](solutions/compound-kick-382.0606208032.sol),
  sparse original-MPS solution, SHA-256
  `0bc55ce1f872b5b4f1f78e037fe862b9934b5ba78616fbea95eeb140f61de3e6`;
- [`../nj1/analysis/final-assignment-382.0606208032.json`](../nj1/analysis/final-assignment-382.0606208032.json),
  compact final assignment certificate, SHA-256
  `a13e58bd98050c830ca3436eb616410cb60fc64d3b2424f8bf5f29cac6ddeba5`;
- [`analysis/compound-kick-382.0606208032-validation.json`](analysis/compound-kick-382.0606208032-validation.json),
  constructive full-MPS Decimal validation, SHA-256
  `a0ee4db0cfd27c3332183d54a9349170f81402b6480da80ab79feab57bdfcc8b`;
- [`solutions/compound-kick-382.0606208032.independent-check.log`](solutions/compound-kick-382.0606208032.independent-check.log),
  repository-wide exact-MPS check, SHA-256
  `467242796931340e58ad92c33899acec7b5136d9f87aa04d06b2afcd30b0afe5`.

Both validators independently report zero violation at tolerance zero:

```text
objective=382.0606208032
rows=118986 exact_row_violations=0 row_violations_above_0=0 max_row_violation=0
bound_violations_above_0=0 exact_integrality_violations=0
```

The twelve district populations are

```text
734319 698622 709713 753854 745737 722380
752155 708458 765299 707970 762659 730728
```

all within `[696025, 769290]`; all twelve selected subgraphs are connected.

## Improvement chain

The audited incumbent history is:

```text
438.5907110388  nj2 assignment projected by an exact label swap
403.4107959378  connected large-neighborhood and kick descent
383.6229250390  11 accepted adjacent-pair tree recombinations
382.0606208032  compound kick followed by six exact small moves
```

The last improvement begins by transferring nodes `195,266,422` from
district 8 to district 7. That deliberately worsening kick raises the
objective to `389.6399349028`; six population-feasible connectivity-preserving
one/two-node moves then descend to `382.0606208032`. The complete deterministic
record is compressed in
[`../nj1/analysis/compound-kick-from383-382.0606208032.full.json.gz`](../nj1/analysis/compound-kick-from383-382.0606208032.full.json.gz).
Its uncompressed provenance SHA-256 is
`a75a5e242532453f377420c390ca6a7d377cd9dbcd0c2a6028eea871a1a57f8e`.
The earlier
`438.5907110388`, `403.4107959378`, and `383.6229250390` solutions remain in
this directory as reproducibility history, not as current records.

## Local optimality boundary

Several stronger searches found no further improvement from
`382.0606208032`:

- The compressed terminal scan
  [`../nj1/analysis/large-neighborhood-terminal-scan-382.0606208032.json.gz`](../nj1/analysis/large-neighborhood-terminal-scan-382.0606208032.json.gz)
  exhaustively evaluates 9,049 unique candidates in three stated compound
  move classes: connected triple transfer, connected two-for-one exchange,
  and three-district one-node cycle. It finds no improving feasible move.
- The compressed full continuation
  [`../nj1/analysis/compound-kick-terminal-from382.0606208032.full.json.gz`](../nj1/analysis/compound-kick-terminal-from382.0606208032.full.json.gz)
  applies exact small descent after all 2,133 feasible compound kicks from the
  preceding scan. Every trajectory returns an objective at least
  `382.0606208032`.
- Three deterministic seeded randomized-tree scans, archived as
  [`analysis/district-pair-recombination-from382.json`](analysis/district-pair-recombination-from382.json),
  [`analysis/district-pair-from382-seed20260912-r5000.json`](analysis/district-pair-from382-seed20260912-r5000.json),
  and
  [`analysis/district-pair-from382-seed20260913-r5000.json`](analysis/district-pair-from382-seed20260913-r5000.json),
  test 231,000 spanning trees and 214,930 population-feasible tree cuts in
  total, finding no improvement.
- The stronger exact adjacent-pair audit in
  [`analysis/exact-pair-copt8-from382/`](analysis/exact-pair-copt8-from382/)
  solves the population-balanced minimum-cut MILP for every one of the 21
  adjacent district pairs. All 21 finish COPT-optimal, the current connected
  partition attains every relaxed optimum, 0 time out, and 0 improve. See the
  [`manifest`](analysis/exact-pair-copt8-from382/manifest.json) and complete
  [`hash list`](analysis/exact-pair-copt8-from382/SHA256SUMS).
- The anchored three-district audit in
  [`analysis/exact-triple-copt8-from382/`](analysis/exact-triple-copt8-from382/)
  covers all 39 connected triples in the current district-adjacency graph.
  All 39 models finish COPT-optimal with 0 timeouts and 0 improvements; each
  current connected partition also attains the corresponding relaxation
  optimum before connectivity cuts. The directory's
  [`SHA256SUMS`](analysis/exact-triple-copt8-from382/SHA256SUMS) covers all
  119 batch, manifest, result, and log artifacts.
- The anchored four-district audit in
  [`analysis/exact-quad-copt8-from382/`](analysis/exact-quad-copt8-from382/)
  covers all 67 connected four-district subsets in the current
  district-adjacency graph. All 67 finish COPT-optimal with exact full-objective
  delta `0E-10`; one case needed a 600-second retry after its initial
  120-second limit. There are 0 unproved and 0 improving cases. The merged
  [`manifest`](analysis/exact-quad-copt8-from382/manifest.json) and
  [`hash list`](analysis/exact-quad-copt8-from382/SHA256SUMS) preserve all
  final and superseded attempts.

The compact cross-instance archive
[`../nj1/analysis/continuation-403-to-382.0606208032-archive.json`](../nj1/analysis/continuation-403-to-382.0606208032-archive.json)
records every compressed/uncompressed hash, move count, and validation path.

The pair, triple, and quad models are local subproblems, not a decomposition lower
bound. Pair models allow arbitrary reassignment only inside one fixed
two-district union while all other labels stay fixed. Triple models do the
same inside one three-district union and additionally fix one current anchor
per district. Quad models similarly fix all four current anchors. Thus the
larger models do not cover repartitions that place two current anchors in the
same new district.

Likewise, the 9,049/2,133 counts are
exhaustive only for the explicitly implemented finite move generators. These
facts do not establish global optimality. The pair/triple/quad conclusions are
solver-backed computational closures with exact assignment replay, not
portable solver-independent proof certificates.

## Gurobi 13 read-only structure audit and license boundary

The official MPS was read with Gurobi 13.0.1 without calling `optimize()` or
`presolve()`. The complete record is
[`analysis/nj3-gurobi13-structure.json`](analysis/nj3-gurobi13-structure.json),
with console trace in
[`analysis/nj3-gurobi13-structure.log`](analysis/nj3-gurobi13-structure.log).
Gurobi read:

- 85,224 variables, 118,986 linear rows, and 377,422 nonzeros;
- 70,944 continuous and 14,280 integral `[0,1]` variables;
- 52,056 `<=`, 7,747 equality, and 59,183 `>=` rows;
- 607 unit-coefficient partitioning equations;
- no quadratic, SOS, or general constraints;
- fingerprint `1645924113` in the read-only audit.

An attempted one-second Gurobi solve is preserved in
[`analysis/gurobi13-size-limited-smoke-result.json`](analysis/gurobi13-size-limited-smoke-result.json)
and [`logs/gurobi13-size-limited-smoke.log`](logs/gurobi13-size-limited-smoke.log).
It stopped before optimization with error 10010, "model too large for
size-limited license". It produced no incumbent, bound, or node work.
Accordingly no Gurobi search claim is made; the successful full-model runs use
COPT 8 and their bounds remain numerical rather than exact certificates.

The original input SHA-256 is
`0f5de48d991eff030b839ed624166c95d5f6e2271b8eb83d82e72abfa92369ab`;
all input hashes are in [`input/SHA256SUMS`](input/SHA256SUMS).

## Exact relationship to nj2

[`experiments/nj2_nj3_projection.py`](experiments/nj2_nj3_projection.py)
performs an exhaustive Decimal comparison of both official MPS files. It
establishes that all 118,975 `nj2` rows and all 85,224 variables occur
unchanged in `nj3`, with identical bounds, integrality, and objective. `nj3`
adds exactly 11 rows and 13,090 nonzeros.

For zero-based district `d=0,...,10`, added row `d` is

```text
-sum_n root[n,d] + sum_n (n+1)*root[n,d+1] >= 1.
```

Together with the existing one-root and minimum-index-root structure, the 11
rows require node 0 to have district label 0; they do not sort all twelve
roots. Swapping labels 0 and 11 in the earlier `nj2` partition therefore gave
the first strict `nj3` incumbent without changing geometry, populations,
connectivity, or objective. See
[`analysis/nj2-nj3-projection.json`](analysis/nj2-nj3-projection.json).

## Full-model COPT runs

Three separate 1,800-second COPT 8.0.4 runs, warm-started from the strict
`382.0606208032` solutions of `nj1`, `nj2`, and `nj3`, finished at the time
limit without improving the warm start. Their numerical terminal bounds were
`74.54284297688875`, approximately `0`, and `19.284562911019115`,
respectively. Complete result/log evidence and hashes are archived in
[`analysis/copt8-full-model-from382/`](analysis/copt8-full-model-from382/).
The requested random-seed parameter was unsupported and did not take effect;
this is recorded explicitly in the archive. Earlier exploratory 403/438-stage
runs likewise found no better incumbent. None of these floating-point bounds
is an exact global lower-bound certificate.

## Background and sources

MIPLIB describes `nj3` as an electoral district design instance with
symmetry-breaking constraints. Official metadata and inputs:

- <https://miplib.zib.de/instance_details_nj3.html>;
- <https://miplib.zib.de/WebData/instances/nj3.mps.gz>;
- <https://miplib.zib.de/WebData/decomps_orig/nj3.dec>.

Validi and Buchanan (2022) discuss the unresolved `nj1`--`nj3` family and
districting formulations, cuts, and symmetry techniques:
<https://doi.org/10.1007/s12532-022-00221-5>.

## Reproduce and validate

Build and independently check the current strict solution:

```bash
python instances/nj3/experiments/build_and_check_nj3_solution.py \
  instances/nj3/input/nj3.mps.gz \
  instances/nj1/analysis/final-assignment-382.0606208032.json \
  instances/nj3/solutions/compound-kick-382.0606208032.sol \
  instances/nj3/analysis/compound-kick-382.0606208032-validation.json

python common/exact_mps_solution_check.py \
  instances/nj3/input/nj3.mps.gz \
  instances/nj3/solutions/compound-kick-382.0606208032.sol \
  --tolerance 0
```

Reproduce the final kick/descent from 383 and its exhaustive terminal scan.
The large JSON records are stored compressed; expand them only to temporary
paths:

```bash
gzip -dc instances/nj1/analysis/large-neighborhood-scan-383.6229250390.json.gz \
  > /tmp/nj-large-from383.json
gzip -dc instances/nj1/analysis/compound-kick-from383-382.0606208032.full.json.gz \
  > /tmp/nj-compound-from383.json
gzip -dc instances/nj1/analysis/large-neighborhood-terminal-scan-382.0606208032.json.gz \
  > /tmp/nj-large-from382.json

python instances/nj1/experiments/compound_kick_descent.py \
  instances/nj1/input/nj1.mps.gz \
  instances/nj3/analysis/district-pair-recombination-post-two-node.json \
  /tmp/nj-large-from383.json \
  /tmp/nj-compound-from383-replay.json \
  --workers 16 --candidate-limit 1821

python instances/nj1/experiments/connected_large_neighborhood.py \
  instances/nj1/input/nj1.mps.gz \
  instances/nj1/analysis/final-assignment-382.0606208032.json \
  /tmp/nj-large-from382-replay.json

python instances/nj1/experiments/compound_kick_descent.py \
  instances/nj1/input/nj1.mps.gz \
  instances/nj1/analysis/final-assignment-382.0606208032.json \
  /tmp/nj-large-from382.json \
  /tmp/nj-compound-from382-replay.json \
  --workers 16 --candidate-limit 2133
```

Reproduce the exact 21-pair audit with COPT:

```bash
python instances/nj3/experiments/run_exact_pair_batch.py \
  instances/nj1/input/nj1.mps.gz \
  instances/nj1/analysis/final-assignment-382.0606208032.json \
  exact-pair-run \
  --time-limit-per-pair 60 --threads 1 --max-rounds 500
```

Reproduce the complete anchor-fixed 39-triple audit:

```bash
python instances/nj3/experiments/run_exact_triple_batch.py \
  instances/nj1/input/nj1.mps.gz \
  instances/nj1/analysis/final-assignment-382.0606208032.json \
  exact-triple-run \
  --top 39 --time-limit-per-triple 60 --threads 4 --max-rounds 1000
```

Rerun the complete anchor-fixed 67-quad audit sequentially (the archived run
used four rank-modulo shards plus one longer retry):

```bash
python instances/nj3/experiments/run_exact_quad_batch.py \
  instances/nj1/input/nj1.mps.gz \
  instances/nj1/analysis/final-assignment-382.0606208032.json \
  exact-quad-run \
  --top 67 --time-limit-per-quad 300 --threads 4 --max-rounds 1000
```

The exact four-shard, retry, and manifest-merge commands are in the
[`exact-quad archive README`](analysis/exact-quad-copt8-from382/README.md).
