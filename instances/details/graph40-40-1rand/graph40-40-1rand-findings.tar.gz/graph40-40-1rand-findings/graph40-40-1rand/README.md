# graph40-40-1rand — OPT = -9

## Result

**The original-MPS optimum is -9.**  The model packs pairwise edge-disjoint
nonempty graph cuts.  The official nine-cut witness has zero violation in all
360,900 original rows, while a checked LRAT refutation proves that ten cuts do
not exist.

The complete chain is:

1. audit all 102,600 original variables, 360,900 rows, and 1,260,900 nonzeros;
2. recover 300 oriented edge records representing 275 distinct undirected
   edges, including 25 reversed duplicate pairs;
3. rebuild the 3,510-variable, 25,519-clause ten-cut CNF byte-for-byte;
4. validate the known nine-cut witness against the same encoder;
5. check CaDiCaL's DRAT proof with `drat-trim`, convert it to LRAT, and
   independently replay 5,752 RUP lemmas and the final empty clause;
6. re-evaluate the official -9 solution against every original MPS row.

The proof package is under
[`experiments/sat-k10-20260907/`](experiments/sat-k10-20260907/), and the
one-command full-chain checker is
[`verify_graph40_40_optimality.py`](scripts/verify_graph40_40_optimality.py).
Gurobi is used only to read the original MPS; verification makes no optimizer
calls.

## Why the reduction is exact

For each active original block, four rows force every `y` variable to be the
XOR of the endpoint shore bits.  A block with `x=1` must cross at least one
edge, and every edge-record capacity row permits at most one active cut to
cross it.  Thus objective at most -10 would yield ten pairwise edge-disjoint
nonempty cuts.

Conversely, any ten such cuts populate ten original blocks; all other blocks
are zero and each edge slack is determined by whether that record is used.
Fixing vertex 0 outside every shore removes cut-complement symmetry, and
strictly sorting the distinct shore bit vectors removes cut-permutation
symmetry without losing a solution.  Reversed duplicate records impose the
same cut condition, so collapsing them to 275 unique edges preserves
feasibility.

## Reproduction

```sh
python scripts/verify_graph40_40_optimality.py \
  --proof-dir experiments/sat-k10-20260907 \
  --output optimality-replay.json
```

Python 3 and `gurobipy` are needed for original-MPS reading.  The LRAT checker
itself uses only the Python standard library and exact Boolean propagation.

## Key SHA-256 values

| File | SHA-256 |
|---|---|
| compressed MPS | `faf688f36bc47c807167d167dfb9e744a8afeb7d2aeec1d75eec6bb0ea9eea6e` |
| official solution | `e3ce93fb9606a264028c7ee59abeabae46d19e17f646b0bf51a66de2fc3b01d5` |
| canonical edge list | `bedbdab73007779c9212578fc4e3ad0091a8c21f1226f0afffcd1d733eefdabb` |
| ten-cut CNF | `c7d0060575a5947f16f96c615ff1a2b5f7d75851457a5f87e038f4da9457c1fd` |
| DRAT | `2b4679e9a0df0b3e955ffbae5d8eac1778895af1036d4b48ed506f2720a84f3d` |
| LRAT | `89387afef5755d00a01dc601999dc2ec7d9dfefa781e4ccbca96ce3f7caeaba7` |

The earlier rational clique certificate and timed-out MIP decision run remain
archived as historical intermediate results.  See the
[`full investigation report`](reports/graph40-40-1rand_investigation.md).
