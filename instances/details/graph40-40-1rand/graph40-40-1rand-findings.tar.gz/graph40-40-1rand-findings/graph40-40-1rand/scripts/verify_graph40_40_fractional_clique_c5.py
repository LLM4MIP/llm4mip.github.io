#!/usr/bin/env python3
"""Exact verifier for the graph40-40-1rand clique+C5 LP certificate.

All certificate arithmetic and all max-flow capacities are Python integers or
Fractions.  No optimizer is used.  The hypergraph cut function is reduced to
39 directed integer s-t min-cuts: for an object e, the gadget

    v -> e_in (infinity), e_in -> e_out (weight), e_out -> v (infinity)

for every v in e charges its weight exactly when e is split by the cut.
"""

from __future__ import annotations

import hashlib
import itertools
import json
import sys
from collections import deque
from fractions import Fraction
from math import gcd
from pathlib import Path


HERE = Path(__file__).resolve().parent
OUTPUT_DIR = HERE.parent / "artifacts"
EDGE_FILE = OUTPUT_DIR / "graph40-40-1rand_edges.tsv"
N = 40
FULL = (1 << N) - 1


def bits(mask):
    while mask:
        bit = mask & -mask
        yield bit.bit_length() - 1
        mask ^= bit


def popcount(mask):
    return bin(mask).count("1")


def lcm(a, b):
    return a // gcd(a, b) * b


def read_graph():
    adjacency = [0] * N
    canonical_lines = []
    with EDGE_FILE.open() as stream:
        assert next(stream).strip() == "u\tv"
        for line in stream:
            u, v = map(int, line.split())
            assert 0 <= u < v < N
            assert not (adjacency[u] & (1 << v))
            adjacency[u] |= 1 << v
            adjacency[v] |= 1 << u
            canonical_lines.append(f"{u}\t{v}\n")
    digest = hashlib.sha256("".join(canonical_lines).encode("ascii")).hexdigest()
    return adjacency, digest, len(canonical_lines)


def maximal_cliques(adjacency):
    answer = []

    def search(r, p, x):
        if not p and not x:
            answer.append(r)
            return

        def score(vertex):
            return popcount(p & adjacency[vertex])

        union = p | x
        pivot = max(bits(union), key=score) if union else 0
        candidates = p & ~adjacency[pivot]
        while candidates:
            bit = candidates & -candidates
            vertex = bit.bit_length() - 1
            search(r | bit, p & adjacency[vertex], x & adjacency[vertex])
            p ^= bit
            x |= bit
            candidates ^= bit

    search(0, FULL, 0)
    return set(answer)


def induced_five_cycles(adjacency):
    answer = set()
    for vertices in itertools.combinations(range(N), 5):
        mask = sum(1 << vertex for vertex in vertices)
        if all(popcount(adjacency[vertex] & mask) == 2 for vertex in vertices):
            answer.add(mask)
    return answer


class Dinic:
    def __init__(self, n):
        self.graph = [[] for _ in range(n)]

    def add_edge(self, source, target, capacity):
        forward = [target, len(self.graph[target]), capacity]
        reverse = [source, len(self.graph[source]), 0]
        self.graph[source].append(forward)
        self.graph[target].append(reverse)

    def max_flow(self, source, target):
        total = 0
        n = len(self.graph)
        while True:
            level = [-1] * n
            level[source] = 0
            queue = deque([source])
            while queue:
                vertex = queue.popleft()
                for neighbor, _, capacity in self.graph[vertex]:
                    if capacity and level[neighbor] < 0:
                        level[neighbor] = level[vertex] + 1
                        queue.append(neighbor)
            if level[target] < 0:
                return total
            cursor = [0] * n

            def augment(vertex, available):
                if vertex == target:
                    return available
                while cursor[vertex] < len(self.graph[vertex]):
                    edge = self.graph[vertex][cursor[vertex]]
                    neighbor, reverse_index, capacity = edge
                    if capacity and level[neighbor] == level[vertex] + 1:
                        pushed = augment(neighbor, min(available, capacity))
                        if pushed:
                            edge[2] -= pushed
                            self.graph[neighbor][reverse_index][2] += pushed
                            return pushed
                    cursor[vertex] += 1
                return 0

            while True:
                pushed = augment(source, 10**100)
                if not pushed:
                    break
                total += pushed


def hypergraph_st_mincut(objects, scaled_weights, source, target):
    node_count = N + 2 * len(objects)
    network = Dinic(node_count)
    infinity = sum(scaled_weights) + 1
    for index, (obj, weight) in enumerate(zip(objects, scaled_weights)):
        inner = N + 2 * index
        outer = inner + 1
        network.add_edge(inner, outer, weight)
        for vertex in bits(obj):
            network.add_edge(vertex, inner, infinity)
            network.add_edge(outer, vertex, infinity)
    return network.max_flow(source, target)


def as_fraction(item):
    return Fraction(item["numerator"], item["denominator"])


def main():
    strong_odd_cycle = "--strong" in sys.argv[1:]
    suffix = "_c5_odd" if strong_odd_cycle else "_c5"
    certificate_file = OUTPUT_DIR / f"graph40-40-1rand_fractional_clique{suffix}_certificate.json"
    audit_file = OUTPUT_DIR / f"graph40-40-1rand_fractional_clique{suffix}_exact_audit.json"
    adjacency, edge_sha256, edge_count = read_graph()
    cliques = maximal_cliques(adjacency)
    cycles = induced_five_cycles(adjacency)
    certificate = json.loads(certificate_file.read_text())

    assert edge_count == 275
    assert len(cliques) == certificate["maximal_cliques"] == 219
    assert len(cycles) == certificate["induced_five_cycles"] == 5205

    primal_objects = []
    primal_weights = []
    primal_capacities = []
    for item in certificate["nonzero_primal_objects"]:
        mask = sum(1 << vertex for vertex in item["vertices"])
        if item["kind"] == "maximal_clique":
            assert mask in cliques
            assert item["capacity"] == 1
        else:
            assert item["kind"] == "induced_C5"
            assert mask in cycles
            assert item["capacity"] == 2
        weight = as_fraction(item)
        assert weight > 0
        primal_objects.append(mask)
        primal_weights.append(weight)
        primal_capacities.append(item["capacity"])

    claimed_objective = as_fraction(certificate["objective"])
    primal_objective = sum(
        capacity * weight for capacity, weight in zip(primal_capacities, primal_weights)
    )
    assert primal_objective == claimed_objective == Fraction(551, 52)

    denominator = 1
    for weight in primal_weights:
        denominator = lcm(denominator, weight.denominator)
    scaled_weights = [weight.numerator * (denominator // weight.denominator) for weight in primal_weights]
    terminal_flows = {
        str(target): hypergraph_st_mincut(primal_objects, scaled_weights, 0, target)
        for target in range(1, N)
    }
    global_min_cut = min(terminal_flows.values())
    assert global_min_cut >= denominator

    dual_cuts = []
    dual_weights = []
    for item in certificate["nonzero_dual_cuts"]:
        mask = sum(1 << vertex for vertex in item["shore"])
        assert mask and mask != FULL
        weight = as_fraction(item)
        assert weight > 0
        dual_cuts.append(mask)
        dual_weights.append(weight)
    dual_objective = sum(dual_weights)
    assert dual_objective == claimed_objective

    max_clique_dual_load = Fraction(0)
    for obj in cliques:
        load = sum(
            weight
            for cut, weight in zip(dual_cuts, dual_weights)
            if obj & cut and obj & (FULL ^ cut)
        )
        assert load <= 1
        max_clique_dual_load = max(max_clique_dual_load, load)

    max_cycle_dual_load = Fraction(0)
    for obj in cycles:
        if strong_odd_cycle:
            vertices = list(bits(obj))
            edges = [
                (u, v)
                for index, u in enumerate(vertices)
                for v in vertices[index + 1:]
                if adjacency[u] & (1 << v)
            ]
            assert len(edges) == 5
            load = sum(
                Fraction(
                    sum(((cut >> u) & 1) != ((cut >> v) & 1) for u, v in edges),
                    2,
                ) * weight
                for cut, weight in zip(dual_cuts, dual_weights)
            )
        else:
            load = sum(
                weight
                for cut, weight in zip(dual_cuts, dual_weights)
                if obj & cut and obj & (FULL ^ cut)
            )
        assert load <= 2
        max_cycle_dual_load = max(max_cycle_dual_load, load)

    audit = {
        "status": "PASS",
        "arithmetic": "exact integer/Fraction arithmetic; no optimizer",
        "graph": {
            "vertices": N,
            "unique_edges": edge_count,
            "edge_list_sha256": edge_sha256,
            "maximal_cliques": len(cliques),
            "induced_C5s": len(cycles),
        },
        "primal": {
            "nonzero_objects": len(primal_objects),
            "nonzero_C5_objects": sum(capacity == 2 for capacity in primal_capacities),
            "objective": str(primal_objective),
            "integer_scale": denominator,
            "minimum_hypergraph_cut_scaled": global_min_cut,
            "minimum_hypergraph_cut": str(Fraction(global_min_cut, denominator)),
            "root_to_terminal_mincuts_scaled": terminal_flows,
        },
        "dual": {
            "nonzero_cuts": len(dual_cuts),
            "objective": str(dual_objective),
            "maximum_clique_load": str(max_clique_dual_load),
            "maximum_C5_load": str(max_cycle_dual_load),
            "C5_coefficient": "crossing_cycle_edges/2" if strong_odd_cycle else "split_indicator",
        },
        "conclusion": (
            "The clique+C5 relaxation has exact optimum 551/52.  It gives only "
            "the integer upper bound 10, so this certificate family cannot prove 9."
        ),
    }
    audit_file.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n")
    print(json.dumps(audit, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
