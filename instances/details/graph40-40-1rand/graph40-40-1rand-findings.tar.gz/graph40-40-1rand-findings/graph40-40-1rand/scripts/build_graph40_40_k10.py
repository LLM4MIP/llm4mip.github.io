#!/usr/bin/env python3
"""Build a structure-specific fixed-k cut-packing feasibility model.

The model uses the recovered 275-edge simple graph.  Reversed duplicate MPS
records are parallel copies of the same undirected edge and do not change
whether two cuts conflict.  Binary vertex-side variables force continuous XOR
variables to be integral.  Maximal-clique and odd-hole inequalities strengthen
the relaxation.  Continuous first-crossing-edge variables impose a complete
ordering of the ten otherwise interchangeable cut blocks.
"""

from __future__ import annotations

import importlib.util
import itertools
import json
import os
from collections import Counter
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
RECONSTRUCT = HERE / "reconstruct_graph40_40.py"
EDGE_FILE = ROOT / "artifacts" / "graph40-40-1rand_edges.tsv"
N = 40
K = int(os.environ.get("CUTPACK_K", "10"))
USE_ANCHORS = os.environ.get("CUTPACK_ANCHORS", "1") != "0"
USE_CLIQUES = os.environ.get("CUTPACK_CLIQUES", "1") != "0"
USE_ODDHOLES = os.environ.get("CUTPACK_ODDHOLES", "1") != "0"
FIX_OFFICIAL = os.environ.get("CUTPACK_FIX_OFFICIAL", "0") == "1"
variant = ""
if USE_CLIQUES:
    variant += "_clique"
if USE_ODDHOLES:
    variant += "_oddhole"
if USE_ANCHORS:
    variant += "_anchor"
if FIX_OFFICIAL:
    variant += "_fixedofficial"
if not variant:
    variant = "_bare"
LP_FILE = ROOT / "artifacts" / f"graph40-40-1rand_k{K}{variant}.lp"
META_FILE = ROOT / "artifacts" / f"graph40-40-1rand_k{K}{variant}_model.json"


def load_reconstruction_module():
    spec = importlib.util.spec_from_file_location("reconstruct", RECONSTRUCT)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def variable(prefix, *indices):
    return prefix + "_" + "_".join(map(str, indices))


def linear(terms):
    parts = []
    for coefficient, name in terms:
        if not parts:
            parts.append(("- " if coefficient < 0 else "") + ("" if abs(coefficient) == 1 else f"{abs(coefficient)} ") + name)
        else:
            parts.append((" - " if coefficient < 0 else " + ") + ("" if abs(coefficient) == 1 else f"{abs(coefficient)} ") + name)
    return "".join(parts) if parts else "0"


def main():
    edges = []
    with EDGE_FILE.open() as stream:
        next(stream)
        for row in stream:
            u, v = map(int, row.split())
            edges.append((u, v))
    adjacency = [0] * N
    for u, v in edges:
        adjacency[u] |= 1 << v
        adjacency[v] |= 1 << u

    reconstruction = load_reconstruction_module()
    cliques = sorted(
        reconstruction.maximal_cliques(adjacency),
        key=lambda mask: (-reconstruction.popcount(mask), tuple(reconstruction.bits(mask))),
    )

    # Enumerate induced odd holes.  In this graph no induced cycle can be longer
    # than nine without an enormous combinatorial search; C5 and C7 are the
    # useful dense-graph cases and are exact valid inequalities independently.
    edge_index = {edge: index for index, edge in enumerate(edges)}
    odd_holes = []
    for length in (5,):
        for subset in itertools.combinations(range(N), length):
            chosen = set(subset)
            induced_edges = []
            induced_degree = Counter()
            for i, u in enumerate(subset):
                for v in subset[i + 1 :]:
                    if adjacency[u] & (1 << v):
                        induced_edges.append((u, v))
                        induced_degree[u] += 1
                        induced_degree[v] += 1
            if len(induced_edges) == length and all(induced_degree[v] == 2 for v in chosen):
                odd_holes.append(tuple(sorted(edge_index[tuple(sorted(edge))] for edge in induced_edges)))
    odd_holes = sorted(set(odd_holes))

    constraints = []
    binaries = []
    bounds = []

    for c in range(K):
        for v in range(N):
            binaries.append(variable("u", c, v))
        constraints.append(f" root_{c}: {variable('u', c, 0)} = 0")

        y_names = []
        for e, (u, v) in enumerate(edges):
            y = variable("y", c, e)
            y_names.append(y)
            bounds.append(f" 0 <= {y} <= 1")
            constraints.append(f" xor_a_{c}_{e}: {linear([(1,y),(-1,variable('u',c,u)),(1,variable('u',c,v))])} >= 0")
            constraints.append(f" xor_b_{c}_{e}: {linear([(1,y),(1,variable('u',c,u)),(-1,variable('u',c,v))])} >= 0")
            constraints.append(f" xor_c_{c}_{e}: {linear([(1,y),(-1,variable('u',c,u)),(-1,variable('u',c,v))])} <= 0")
            constraints.append(f" xor_d_{c}_{e}: {linear([(1,y),(1,variable('u',c,u)),(1,variable('u',c,v))])} <= 2")
        constraints.append(f" nonempty_{c}: {linear([(1,name) for name in y_names])} >= 1")

        # a[c,e] is forced to one at the lexicographically first crossed edge
        # once u (and hence y) is integral, but a itself may stay continuous.
        if USE_ANCHORS:
            a_names = []
            prefix = []
            for e, y in enumerate(y_names):
                a = variable("a", c, e)
                a_names.append(a)
                prefix.append(a)
                bounds.append(f" 0 <= {a} <= 1")
                constraints.append(f" anchor_use_{c}_{e}: {a} - {y} <= 0")
                constraints.append(
                    f" anchor_first_{c}_{e}: "
                    f"{linear([(1, y)] + [(-1, name) for name in prefix])} <= 0"
                )
            constraints.append(f" anchor_one_{c}: {linear([(1,name) for name in a_names])} = 1")

    for e in range(len(edges)):
        constraints.append(f" capacity_{e}: {linear([(1,variable('y',c,e)) for c in range(K)])} <= 1")

    # Strictly order the first crossing edge.  Distinctness follows already
    # from edge capacities; the +1 turns the non-strict canonical ordering into
    # an explicit strict one.
    if USE_ANCHORS:
        for c in range(K - 1):
            left = [(e, variable("a", c, e)) for e in range(len(edges)) if e]
            right = [(-e, variable("a", c + 1, e)) for e in range(len(edges)) if e]
            constraints.append(f" anchor_order_{c}: {linear(left + right)} <= -1")

    if USE_CLIQUES:
        for q, clique in enumerate(cliques):
            cv = list(reconstruction.bits(clique))
            anchor = cv[0]
            z_names = []
            for c in range(K):
                z = variable("z", c, q)
                z_names.append(z)
                bounds.append(f" 0 <= {z} <= 1")
                for v in cv[1:]:
                    constraints.append(f" clique_a_{q}_{c}_{v}: {linear([(1,z),(-1,variable('u',c,v)),(1,variable('u',c,anchor))])} >= 0")
                    constraints.append(f" clique_b_{q}_{c}_{v}: {linear([(1,z),(1,variable('u',c,v)),(-1,variable('u',c,anchor))])} >= 0")
            constraints.append(f" clique_pack_{q}: {linear([(1,name) for name in z_names])} <= 1")

    if USE_ODDHOLES:
        for h, cycle_edges in enumerate(odd_holes):
            terms = [(1, variable("y", c, e)) for c in range(K) for e in cycle_edges]
            constraints.append(f" oddhole_{h}: {linear(terms)} <= {len(cycle_edges)-1}")

    if FIX_OFFICIAL:
        if K != 9:
            raise ValueError("CUTPACK_FIX_OFFICIAL requires CUTPACK_K=9")
        _, _, active, shores, _, _ = reconstruction.parse_solution()
        represented = [set(shores[block]) for block in active]
        represented.sort(
            key=lambda shore: min(
                index for index, (u, v) in enumerate(edges) if (u in shore) != (v in shore)
            )
        )
        for c, shore in enumerate(represented):
            for v in range(N):
                constraints.append(f" official_{c}_{v}: {variable('u',c,v)} = {int(v in shore)}")

    with LP_FILE.open("w", encoding="ascii") as stream:
        stream.write(f"\\ graph40-40-1rand: exact k={K} feasibility on unique-edge graph\n")
        # u_0_0 is fixed to zero, so this is a genuine zero objective without
        # the LP parser mistaking the token `0` for a variable name.
        stream.write("Minimize\n obj: u_0_0\nSubject To\n")
        stream.write("\n".join(constraints))
        stream.write("\nBounds\n")
        stream.write("\n".join(bounds))
        stream.write("\nBinary\n")
        for start in range(0, len(binaries), 12):
            stream.write(" " + " ".join(binaries[start : start + 12]) + "\n")
        stream.write("End\n")

    metadata = {
        "instance": "graph40-40-1rand",
        "decision_problem": f"existence of {K} pairwise edge-disjoint nonempty cuts",
        "vertices": N,
        "unique_edges": len(edges),
        "cut_blocks": K,
        "binary_variables": len(binaries),
        "continuous_y_variables": K * len(edges),
        "continuous_anchor_variables": K * len(edges) if USE_ANCHORS else 0,
        "continuous_clique_variables": K * len(cliques) if USE_CLIQUES else 0,
        "maximal_cliques": len(cliques),
        "maximal_clique_sizes": dict(sorted(Counter(map(reconstruction.popcount, cliques)).items())),
        "induced_odd_holes": dict(sorted(Counter(map(len, odd_holes)).items())),
        "constraints": len(constraints),
        "lp_file": str(LP_FILE),
        "symmetry_break": "strict ordering by each cut's first crossed edge" if USE_ANCHORS else None,
        "use_anchor_symmetry": USE_ANCHORS,
        "use_maximal_cliques": USE_CLIQUES,
        "use_induced_c5_inequalities": USE_ODDHOLES,
        "official_solution_fixed": FIX_OFFICIAL,
    }
    META_FILE.write_text(json.dumps(metadata, indent=2, sort_keys=True) + "\n")
    print(json.dumps(metadata, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
