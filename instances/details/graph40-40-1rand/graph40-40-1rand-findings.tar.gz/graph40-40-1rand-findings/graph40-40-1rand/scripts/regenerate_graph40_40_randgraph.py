#!/usr/bin/env python3
"""Reproduce the paper's documented Randgraph seed-1 construction candidates.

This is a literal Python transcription of RandomGraph.cxx's POSIX drand48 /
lrand48 calls for random_tree.  It records enough invariants to decide whether
the recovered MIPLIB graph can be that raw output, even after vertex relabeling.
"""

from __future__ import annotations

import gzip
import json
import re
from collections import Counter
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
MPS = ROOT / "input" / "graph40-40-1rand.mps.gz"
OUTPUT = ROOT / "artifacts" / "graph40-40-1rand_randgraph_seed1_audit.json"
N = 40


class Rand48:
    def __init__(self, seed):
        self.state = (seed << 16) + 0x330E

    def advance(self):
        self.state = (0x5DEECE66D * self.state + 0xB) & ((1 << 48) - 1)
        return self.state

    def lrand48(self):
        return self.advance() >> 17

    def drand48(self):
        return self.advance() / float(1 << 48)


def random_tree(seed, extra, consume_weight):
    rng = Rand48(seed)
    parent = list(range(N))

    def find(v):
        while parent[v] != v:
            parent[v] = parent[parent[v]]
            v = parent[v]
        return v

    def random_edge():
        u = rng.lrand48() % N
        v = rng.lrand48() % N
        while u == v:
            v = rng.lrand48() % N
        return u, v

    records = []
    while len(records) < N - 1:
        u, v = random_edge()
        ru, rv = find(u), find(v)
        if ru != rv:
            parent[rv] = ru
            records.append((u, v))
            if consume_weight:
                rng.drand48()
    for _ in range(extra):
        records.append(random_edge())
        if consume_weight:
            rng.drand48()
    return records


def invariants(records):
    oriented = set(records)
    simple = {tuple(sorted(edge)) for edge in records}
    degree = [0] * N
    for u, v in simple:
        degree[u] += 1
        degree[v] += 1
    return {
        "raw_records": len(records),
        "distinct_oriented_records": len(oriented),
        "unique_undirected_edges": len(simple),
        "sorted_degree_sequence": sorted(degree),
        "degree_histogram": dict(sorted(Counter(degree).items())),
    }, oriented, simple


def main():
    observed_records = []
    in_rows = False
    with gzip.open(MPS, "rt", encoding="latin-1") as stream:
        for line in stream:
            if line.strip() == "ROWS":
                in_rows = True
                continue
            if line.strip() == "COLUMNS":
                in_rows = False
            if not in_rows:
                continue
            match = re.search(r"m_once_;(\d+)_(\d+);", line)
            if match:
                observed_records.append(tuple(map(int, match.groups())))
    observed, observed_oriented, observed_simple = invariants(observed_records)

    candidates = []
    # Paper prescription: 39 tree edges + (40% * C(40,2) - 39) = 312.
    # The 300-record variant tests whether the MPS name's middle number was
    # passed directly as a target edge count instead.
    for extra, interpretation in ((273, "paper 40-percent prescription"), (261, "300 raw records")):
        for consume_weight, distribution in ((False, "unit weights"), (True, "default uniform weights")):
            records = random_tree(1, extra, consume_weight)
            data, oriented, simple = invariants(records)
            data.update(
                {
                    "seed": 1,
                    "extra_edges_argument": extra,
                    "interpretation": interpretation,
                    "weight_distribution": distribution,
                    "exact_oriented_record_set_match": oriented == observed_oriented,
                    "exact_simple_edge_set_match": simple == observed_simple,
                    "oriented_record_overlap": len(oriented & observed_oriented),
                    "simple_edge_overlap": len(simple & observed_simple),
                    "degree_sequence_match_up_to_relabeling": data["sorted_degree_sequence"]
                    == observed["sorted_degree_sequence"],
                }
            )
            candidates.append(data)

    report = {
        "instance": "graph40-40-1rand",
        "source_algorithm": "Randgraph RandomGraph.cxx random_tree",
        "source_url": "https://www.diag.uniroma1.it/~challenge9/code/Randgraph.tar.gz",
        "paper_seed": 1,
        "observed_mps": observed,
        "candidates": candidates,
        "conclusion": "No tested literal seed-1 Randgraph transcription matches, even up to a vertex relabeling (degree sequences differ).",
    }
    OUTPUT.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
