#!/usr/bin/env python3
"""Reconstruct and audit graph40-40-1rand from its official MPS/solution.

The script uses only the Python standard library and writes deterministic,
machine-checkable artifacts next to itself.  It deliberately does not invoke
an optimizer.
"""

from __future__ import annotations

import gzip
import hashlib
import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MPS = ROOT / "input" / "graph40-40-1rand.mps.gz"
SOL = ROOT / "solutions" / "official-9.sol.gz"
OUT = ROOT / "artifacts"
STEM = "graph40-40-1rand"
N = 40


def popcount(mask: int) -> int:
    return bin(mask).count("1")


def bits(mask: int):
    while mask:
        bit = mask & -mask
        yield bit.bit_length() - 1
        mask ^= bit


def parse_mps():
    section = None
    row_count = 0
    row_types = Counter()
    edge_records = []
    columns = set()
    objective = {}
    integer_columns = set()
    inside_integer_marker = False
    with gzip.open(MPS, "rt", encoding="latin-1") as stream:
        for raw in stream:
            line = raw.strip()
            if not line or line.startswith("*"):
                continue
            head = line.split()[0]
            if head in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = head
                continue
            fields = line.split()
            if section == "ROWS":
                row_count += 1
                row_types[fields[0]] += 1
                match = re.fullmatch(r"m_once_;(\d+)_(\d+);.*", fields[1])
                if match:
                    edge_records.append((int(match.group(1)), int(match.group(2))))
            elif section == "COLUMNS":
                if "'MARKER'" in fields:
                    if "'INTORG'" in fields:
                        inside_integer_marker = True
                    elif "'INTEND'" in fields:
                        inside_integer_marker = False
                    continue
                column = fields[0]
                columns.add(column)
                if inside_integer_marker:
                    integer_columns.add(column)
                for i in range(1, len(fields) - 1, 2):
                    if fields[i] == "profit":
                        objective[column] = float(fields[i + 1])
    return {
        "row_count_including_objective": row_count,
        "row_types": dict(row_types),
        "columns": columns,
        "integer_columns": integer_columns,
        "objective": objective,
        "edge_records": edge_records,
    }


def parse_solution():
    objective = None
    nonzero = {}
    active = []
    shores = defaultdict(set)
    active_y = defaultdict(set)
    nonzero_slacks = []
    with gzip.open(SOL, "rt", encoding="latin-1") as stream:
        for raw in stream:
            fields = raw.split()
            if not fields:
                continue
            if fields[0] == "=obj=":
                objective = float(fields[1])
                continue
            if len(fields) != 2:
                continue
            name, text_value = fields
            value = float(text_value)
            if abs(value) <= 1e-9:
                continue
            nonzero[name] = value
            match = re.fullmatch(r"x#(\d+)", name)
            if match and value > 0.5:
                active.append(int(match.group(1)))
                continue
            match = re.fullmatch(r"u#(\d+)#(\d+)", name)
            if match and value > 0.5:
                shores[int(match.group(1))].add(int(match.group(2)))
                continue
            match = re.fullmatch(r"y#(\d+)#(\d+)#(\d+)", name)
            if match and value > 0.5:
                active_y[int(match.group(1))].add((int(match.group(2)), int(match.group(3))))
                continue
            if name.startswith("slack"):
                nonzero_slacks.append((name, value))
    return objective, nonzero, sorted(active), shores, active_y, nonzero_slacks


def maximal_cliques(adjacency):
    result = []

    def bron_kerbosch(r, p, x):
        if not p and not x:
            result.append(r)
            return
        union = p | x
        if union:
            pivot = max(bits(union), key=lambda vertex: popcount(p & adjacency[vertex]))
            candidates = p & ~adjacency[pivot]
        else:
            candidates = p
        while candidates:
            bit = candidates & -candidates
            vertex = bit.bit_length() - 1
            bron_kerbosch(r | bit, p & adjacency[vertex], x & adjacency[vertex])
            p ^= bit
            x |= bit
            candidates ^= bit

    bron_kerbosch(0, (1 << N) - 1, 0)
    return result


def connected_clique_cover(cliques, limit=9, beam_width=250000):
    """Find <=limit cliques whose edge-union is connected and spans V.

    A connected clique family can be ordered from a clique containing vertex 0
    so each later clique intersects the current vertex union.  Future moves
    depend only on that union, so one path per union mask is sufficient.
    """
    full = (1 << N) - 1
    useful = sorted(
        {mask for mask in cliques if popcount(mask) >= 2},
        key=lambda mask: (-popcount(mask), tuple(bits(mask))),
    )
    omega = max(map(popcount, useful), default=1)
    cardinality_lower_bound = math.ceil((N - 1) / (omega - 1)) if omega > 1 else math.inf
    if cardinality_lower_bound > limit:
        return None, [
            {
                "skipped": True,
                "reason": "clique-size connected-span lower bound exceeds requested limit",
                "omega": omega,
                "lower_bound": cardinality_lower_bound,
                "limit": limit,
            }
        ], False
    states = {mask: [mask] for mask in useful if mask & 1}
    trace = [{"depth": 1, "states": len(states), "best_covered": max(map(popcount, states))}]
    for depth in range(1, limit + 1):
        if full in states:
            return states[full], trace, False
        if depth == limit:
            break
        next_states = {}
        for covered, path in states.items():
            for clique in useful:
                if not (clique & covered) or not (clique & ~covered):
                    continue
                enlarged = covered | clique
                if enlarged not in next_states:
                    next_states[enlarged] = path + [clique]
        truncated = len(next_states) > beam_width
        if truncated:
            ranked = sorted(
                next_states.items(),
                key=lambda item: (-popcount(item[0]), tuple(bits(item[0]))),
            )[:beam_width]
            next_states = dict(ranked)
        states = next_states
        trace.append(
            {
                "depth": depth + 1,
                "states": len(states),
                "best_covered": max(map(popcount, states), default=0),
                "beam_truncated": truncated,
            }
        )
    return None, trace, any(row.get("beam_truncated", False) for row in trace)


def main():
    mps = parse_mps()
    records = mps["edge_records"]
    canonical = [tuple(sorted(edge)) for edge in records]
    multiplicity = Counter(canonical)
    unique_edges = sorted(multiplicity)
    duplicates = [
        {
            "edge": list(edge),
            "multiplicity": multiplicity[edge],
            "oriented_records": [list(record) for record in records if tuple(sorted(record)) == edge],
        }
        for edge in unique_edges
        if multiplicity[edge] > 1
    ]

    adjacency = [0] * N
    degrees = [0] * N
    for u, v in unique_edges:
        adjacency[u] |= 1 << v
        adjacency[v] |= 1 << u
        degrees[u] += 1
        degrees[v] += 1

    cliques = maximal_cliques(adjacency)
    clique_sizes = Counter(map(popcount, cliques))
    omega = max(clique_sizes)
    complement = [((1 << N) - 1) ^ (1 << v) ^ adjacency[v] for v in range(N)]
    maximal_independent_sets = maximal_cliques(complement)
    independent_sizes = Counter(map(popcount, maximal_independent_sets))
    alpha = max(independent_sizes)
    maximum_independent_sets = [sorted(bits(mask)) for mask in maximal_independent_sets if popcount(mask) == alpha]

    cover, cover_trace, cover_truncated = connected_clique_cover(cliques)
    cover_vertices = [sorted(bits(mask)) for mask in cover] if cover else None
    cover_connected = False
    cover_spans = False
    if cover:
        union = 0
        cover_connected = True
        for index, clique in enumerate(cover):
            if index and not (union & clique):
                cover_connected = False
            union |= clique
        cover_spans = union == (1 << N) - 1

    sol_obj, nonzero, active, shores, active_y, nonzero_slacks = parse_solution()
    cut_records = {}
    cut_unique = {}
    cut_validation = []
    record_use = Counter()
    unique_use = Counter()
    for block in active:
        shore = shores[block]
        record_crossings = [record for record in records if (record[0] in shore) != (record[1] in shore)]
        unique_crossings = sorted({tuple(sorted(record)) for record in record_crossings})
        cut_records[block] = record_crossings
        cut_unique[block] = unique_crossings
        record_use.update((index,) for index, record in enumerate(records) if (record[0] in shore) != (record[1] in shore))
        unique_use.update(unique_crossings)
        # The converter names each y column with the reverse of the endpoint
        # order retained in the corresponding m_once row.
        expected_y = {(v, u) for u, v in record_crossings}
        stored_y = active_y.get(block, set())
        cut_validation.append(
            {
                "block": block,
                "shore": sorted(shore),
                "shore_size": len(shore),
                "record_cut_size": len(record_crossings),
                "unique_cut_size": len(unique_crossings),
                "stored_y_count": len(stored_y),
                "stored_y_matches_xor": stored_y == expected_y,
            }
        )

    objective_x = sum(value for name, value in nonzero.items() if name.startswith("x#"))
    objective_coeffs = mps["objective"]
    x_objective_coefficients = sorted({value for name, value in objective_coeffs.items() if name.startswith("x#")})
    non_x_objective = {name: value for name, value in objective_coeffs.items() if not name.startswith("x#")}
    edge_text = "".join(f"{u}\t{v}\n" for u, v in unique_edges)
    edge_hash = hashlib.sha256(edge_text.encode("ascii")).hexdigest()

    edge_clique_capacity = math.comb(omega, 2)
    edge_clique_cover_lb = math.ceil(len(unique_edges) / edge_clique_capacity)
    report = {
        "instance": STEM,
        "source_files": {"mps": str(MPS), "solution": str(SOL)},
        "mps": {
            "rows_excluding_objective": mps["row_count_including_objective"] - 1,
            "row_types_including_objective": mps["row_types"],
            "columns": len(mps["columns"]),
            "integer_columns": len(mps["integer_columns"]),
            "candidate_cut_blocks": len([name for name in mps["columns"] if re.fullmatch(r"x#\d+", name)]),
            "objective_sense": "minimize (MPS default; no OBJSENSE section)",
            "x_objective_coefficients": x_objective_coefficients,
            "non_x_objective_coefficients": non_x_objective,
        },
        "graph": {
            "vertices": N,
            "edge_records": len(records),
            "unique_undirected_edges": len(unique_edges),
            "duplicate_record_excess": len(records) - len(unique_edges),
            "duplicate_groups": duplicates,
            "density": len(unique_edges) / math.comb(N, 2),
            "degrees": degrees,
            "degree_histogram": dict(sorted(Counter(degrees).items())),
            "canonical_edge_list_sha256": edge_hash,
        },
        "combinatorics": {
            "maximal_cliques": len(cliques),
            "maximal_clique_size_histogram": dict(sorted(clique_sizes.items())),
            "clique_number": omega,
            "maximal_independent_sets": len(maximal_independent_sets),
            "maximal_independent_set_size_histogram": dict(sorted(independent_sizes.items())),
            "independence_number": alpha,
            "maximum_independent_sets": maximum_independent_sets,
            "edge_clique_cover_counting_lower_bound": edge_clique_cover_lb,
            "edge_clique_cover_counting_formula": f"ceil({len(unique_edges)}/C({omega},2))",
            "connected_spanning_clique_certificate": cover_vertices,
            "connected_spanning_clique_certificate_valid": bool(cover and cover_connected and cover_spans),
            "connected_spanning_clique_search_trace": cover_trace,
            "connected_spanning_clique_search_beam_truncated": cover_truncated,
        },
        "incumbent": {
            "reported_objective": sol_obj,
            "active_blocks": active,
            "number_active": len(active),
            "sum_active_x": objective_x,
            "decoded_cuts": cut_validation,
            "record_edge_disjoint": all(count <= 1 for count in record_use.values()),
            "unique_edge_disjoint": all(count <= 1 for count in unique_use.values()),
            "maximum_record_use": max(record_use.values(), default=0),
            "maximum_unique_edge_use": max(unique_use.values(), default=0),
            "nonzero_slacks": len(nonzero_slacks),
        },
    }

    (OUT / f"{STEM}_edges.tsv").write_text("u\tv\n" + edge_text, encoding="utf-8")
    (OUT / f"{STEM}_structural_audit.json").write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    decoded = {
        "instance": STEM,
        "objective": sol_obj,
        "meaning": f"{len(active)} nonempty pairwise edge-disjoint cuts",
        "cuts": cut_validation,
    }
    (OUT / f"{STEM}_decoded_incumbent.json").write_text(
        json.dumps(decoded, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
