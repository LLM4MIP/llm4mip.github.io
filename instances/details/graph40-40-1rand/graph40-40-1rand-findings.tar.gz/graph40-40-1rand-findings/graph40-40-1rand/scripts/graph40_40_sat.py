#!/usr/bin/env python3
"""Build and independently sanity-check the exact k-cut SAT formulation.

Each cut is represented by a shore bit u[c,v], with vertex zero fixed outside
to remove complement symmetry.  cross[c,e] is the XOR of the endpoint bits.
Every cut is nonempty, and each graph edge is crossed by at most one cut.
The cut shores are strictly lexicographically ordered to remove permutation
symmetry.  The encoder uses only the Python standard library.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from itertools import combinations
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EDGES = ROOT / "artifacts" / "graph40-40-1rand_edges.tsv"
INCUMBENT = ROOT / "artifacts" / "graph40-40-1rand_decoded_incumbent.json"
N = 40


class VariablePool:
    def __init__(self):
        self._ids = {}

    def id(self, key):
        if key not in self._ids:
            self._ids[key] = len(self._ids) + 1
        return self._ids[key]

    @property
    def top(self):
        return len(self._ids)


def read_edges(path=EDGES):
    rows = path.read_text(encoding="utf-8").splitlines()
    assert rows[0].split() == ["u", "v"]
    edges = [tuple(map(int, row.split())) for row in rows[1:]]
    assert len(edges) == 275
    assert edges == sorted(set(edges))
    assert all(0 <= u < v < N for u, v in edges)
    seen = {0}
    while True:
        extra = {v for u, v in edges if u in seen} | {u for u, v in edges if v in seen}
        if extra <= seen:
            break
        seen |= extra
    assert seen == set(range(N))
    return edges


def encode(k, edges):
    assert k >= 1
    pool = VariablePool()
    clauses = []
    shores = [[pool.id(("shore", c, v)) for v in range(N)] for c in range(k)]
    crosses = [[pool.id(("cross", c, e)) for e in range(len(edges))] for c in range(k)]

    for c in range(k):
        clauses.append([-shores[c][0]])
        for e, (a, b) in enumerate(edges):
            x, z, q = shores[c][a], shores[c][b], crosses[c][e]
            clauses.extend(([x, z, -q], [x, -z, q], [-x, z, q], [-x, -z, -q]))
        clauses.append(crosses[c][:])

    for e in range(len(edges)):
        for a, b in combinations(range(k), 2):
            clauses.append([-crosses[a][e], -crosses[b][e]])

    # Strict lexicographic order on bits 39,...,1.  prefix(c,v) is true iff
    # shores c and c+1 agree on every already processed higher-index bit.
    prefixes = {}
    for c in range(k - 1):
        prefix = pool.id(("prefix", c, N))
        prefixes[c, N] = prefix
        clauses.append([prefix])
        for v in range(N - 1, 0, -1):
            a, b = shores[c][v], shores[c + 1][v]
            nxt = pool.id(("prefix", c, v))
            prefixes[c, v] = nxt
            clauses.extend(
                (
                    [-prefix, -a, b],
                    [-nxt, prefix],
                    [-nxt, -a, b],
                    [-nxt, a, -b],
                    [-prefix, a, b, nxt],
                    [-prefix, -a, -b, nxt],
                )
            )
            prefix = nxt
        clauses.append([-prefix])
    return pool, clauses, shores, crosses, prefixes


def write_dimacs(path, variables, clauses):
    with path.open("w", encoding="ascii", newline="\n") as stream:
        stream.write(f"p cnf {variables} {len(clauses)}\n")
        for clause in clauses:
            stream.write(" ".join(map(str, clause)) + " 0\n")


def validate_nine_cut_fixture(edges):
    decoded = json.loads(INCUMBENT.read_text(encoding="utf-8"))
    shores = []
    for item in decoded["cuts"]:
        shore = set(map(int, item["shore"]))
        if 0 in shore:
            shore = set(range(N)) - shore
        shores.append(shore)
    assert len(shores) == 9
    shores.sort(key=lambda shore: tuple(int(v in shore) for v in range(N - 1, 0, -1)))

    pool, clauses, u, y, prefixes = encode(9, edges)
    truth = {}
    for c, shore in enumerate(shores):
        for v in range(N):
            truth[u[c][v]] = v in shore
        for e, (a, b) in enumerate(edges):
            truth[y[c][e]] = (a in shore) != (b in shore)
    for c in range(8):
        equal_so_far = True
        truth[prefixes[c, N]] = True
        for v in range(N - 1, 0, -1):
            equal_so_far = equal_so_far and ((v in shores[c]) == (v in shores[c + 1]))
            truth[prefixes[c, v]] = equal_so_far
    assert len(truth) == pool.top
    failed = [i for i, clause in enumerate(clauses) if not any((lit > 0) == truth[abs(lit)] for lit in clause)]
    assert not failed
    return {
        "verified": True,
        "cuts": 9,
        "variables": pool.top,
        "clauses": len(clauses),
        "all_clauses_satisfied": True,
        "canonical_shores": [sorted(shore) for shore in shores],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--k", type=int, default=10)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    edges = read_edges()
    fixture = validate_nine_cut_fixture(edges)
    pool, clauses, shores, crosses, prefixes = encode(args.k, edges)
    cnf_path = args.output_dir / f"{args.k}-cuts.cnf"
    write_dimacs(cnf_path, pool.top, clauses)
    cnf_sha = hashlib.sha256(cnf_path.read_bytes()).hexdigest()
    edge_sha = hashlib.sha256("".join(f"{u}\t{v}\n" for u, v in edges).encode("ascii")).hexdigest()
    metadata = {
        "instance": "graph40-40-1rand",
        "decision_problem": f"existence of {args.k} pairwise edge-disjoint nonempty cuts",
        "vertices": N,
        "unique_edges": len(edges),
        "variables": pool.top,
        "clauses": len(clauses),
        "shore_variables": args.k * N,
        "cross_variables": args.k * len(edges),
        "prefix_variables": len(prefixes),
        "canonical_edge_list_sha256": edge_sha,
        "cnf_sha256": cnf_sha,
        "known_nine_cut_fixture": fixture,
        "symmetry": {
            "cut_complement": "vertex 0 fixed outside every shore",
            "cut_permutation": "strict lexicographic order on shore bits 39,...,1",
            "justification": (
                "The graph is connected, so each nonempty cut has exactly one shore with vertex 0 outside. "
                "Edge-disjoint nonempty cuts are distinct and can therefore be strictly sorted."
            ),
        },
        "equivalence": (
            "cross variables are exact endpoint XORs; each cut has a crossed edge; pairwise binary clauses "
            "enforce at most one cut per unique edge. Reversed duplicate MPS edge records impose the same "
            "XOR/capacity condition and do not change feasibility."
        ),
        "u_variable_ids": shores,
        "cross_variable_ids": crosses,
    }
    meta_path = args.output_dir / f"{args.k}-cuts-encoding.json"
    meta_path.write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in metadata.items() if not key.endswith("_ids")}, indent=2))


if __name__ == "__main__":
    main()
