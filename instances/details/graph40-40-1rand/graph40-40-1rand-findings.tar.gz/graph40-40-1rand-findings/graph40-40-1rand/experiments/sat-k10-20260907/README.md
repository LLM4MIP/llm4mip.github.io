# Ten-cut UNSAT certificate

This directory closes the last one-unit gap for `graph40-40-1rand`.

- `10-cuts.cnf`: deterministic ten-cut decision encoding, 3,510 variables and
  25,519 clauses.
- `10-cuts.drat`: CaDiCaL refutation.
- `10-cuts.lrat`: core LRAT generated and checked by `drat-trim`.
- `lrat-independent-check.json`: independent Python replay of all positive
  LRAT hints; 5,752 lemmas and 106,117 propagation steps checked.
- `original-mps-audit.json`: full original matrix/template audit.
- `optimality-certificate.json`: combined original-MPS, incumbent, CNF, and
  LRAT verification record.

`cadical.log` and `drat-trim.log` retain the raw solver and proof-checker
transcripts.  CaDiCaL took about 0.19 seconds; proof generation speed is not
part of the mathematical claim.

Rebuild the CNF:

```sh
python ../../scripts/graph40_40_sat.py --k 10 --output-dir .
```

Replay the complete proof from the instance directory:

```sh
python scripts/verify_graph40_40_optimality.py \
  --proof-dir experiments/sat-k10-20260907 \
  --output optimality-replay.json
```
