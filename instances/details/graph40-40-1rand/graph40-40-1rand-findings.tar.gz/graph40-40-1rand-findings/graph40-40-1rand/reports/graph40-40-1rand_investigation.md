# Rank 12: `graph40-40-1rand`

Date: 2026-09-04

## Outcome

The instance is now **locally and independently certified optimal**:

\[
\gamma(G)=9,\qquad \operatorname{OPT}_{\mathrm{MPS}}=-9.
\]

The lower bound on cut packing is the official nine-cut witness, decoded and
checked with zero violation in the original MPS.  A deterministic ten-cut CNF
was proved UNSAT by CaDiCaL; `drat-trim` checked its complete DRAT derivation and
converted the core to LRAT, and a separate standard-library checker replayed
all 5,752 RUP lemmas and the final empty clause.  The final verifier also audits
every original row and rebuilds the CNF byte-for-byte, so the conclusion does
not rely on the identity of the graph used in the paper.

The earlier rational clique certificate (`gamma(G) <= 10`) and the corrected
590-second MIP timeout are retained below as intermediate results.

## Exact SAT/LRAT closure (2026-09-07)

The ten-cut encoding has 3,510 variables and 25,519 clauses.  Each of ten cuts
uses 40 shore bits and 275 exact XOR crossing bits.  Long clauses enforce
nonempty cuts, binary clauses enforce at most one cut crossing each unique
edge, vertex 0 fixes complement symmetry, and a strict lexicographic ordering
removes permutation symmetry.  The known nine-cut solution satisfies every
clause of the corresponding nine-cut fixture.

The full original-MPS audit verifies 102,600 binary variables, 360,900 rows,
and 1,260,900 nonzeros: 360,000 XOR rows, 300 root-fixing rows, 300
active-implies-nonempty rows, and 300 edge-record capacities.  The 300 oriented
records collapse to 275 unique edges with 25 reversed pairs, exactly matching
the frozen edge list.

CaDiCaL returned UNSAT and wrote DRAT.  `drat-trim` reported `s VERIFIED`, a
6,823-clause core, 5,752 core lemmas, and 106,117 resolution steps; no RAT
lemmas were needed.  The independent LRAT checker verified the same 5,752
lemmas with 106,117 unit-propagation steps and the final empty clause.  Key
hashes are listed in the instance README and combined certificate.

## Exact MPS reconstruction

The MPS is a minimization problem with 300 candidate cut blocks.  For block
`c`, binary variables have the following meaning:

- `x#c` counts the block and has objective coefficient `-1`;
- `u#c#v` selects the shore of vertex `v`, with one vertex fixed to break cut
  complement symmetry;
- `y#c#u#v` is forced by four XOR inequalities to equal one exactly when the
  edge endpoints lie on opposite shores;
- `x#c <= sum_e y#c#e` makes a counted cut nonempty;
- one packing row per edge record, with a binary slack, permits the record to
  be used by at most one cut.

The dimensions agree entry-for-entry:

\[
102600=300+300\cdot40+300\cdot300+300
\]

variables, and

\[
360900=4\cdot300\cdot300+300+300+300
\]

constraints.  All 102,600 variables are binary.  Thus objective `-9` means a
packing of nine nonempty pairwise edge-disjoint cuts.

The 300 edge rows contain 275 distinct undirected edges.  There are 25 reversed
duplicate pairs, each with multiplicity two:

`1-25, 1-26, 4-25, 4-36, 5-24, 5-29, 8-11, 11-16, 11-27, 11-33,
12-28, 12-38, 13-16, 13-31, 14-23, 16-18, 17-38, 21-32, 23-34,
25-29, 27-35, 27-38, 30-34, 31-35, 34-38`.

The paired rows use separately oriented `y` variables, but both variables are
forced by the same endpoint XOR.  Replacing all parallel copies by one simple
edge preserves cut nonemptiness and pairwise cut conflicts exactly.  The
canonical 275-edge list has SHA-256
`bedbdab73007779c9212578fc4e3ad0091a8c21f1226f0afffcd1d733eefdabb`
before the TSV header is added.

## Exact incumbent validation

The official solution activates blocks

`12, 58, 83, 109, 114, 265, 288, 298, 299`.

Eight represented shores are singletons and the ninth is the complement of
vertex 0.  Hence all nine cuts are singleton cuts for the independent set

\[
\{0,11,19,20,24,28,31,37,38\}.
\]

There is no graph edge inside this set.  Direct checks against the original
300 edge records and the 275-edge simple graph give maximum capacity use one;
all stored nonzero `y` variables equal the reconstructed endpoint XORs; and
the objective is exactly `-9`.

The independent checker also validates every strengthening used below:

- at most one of the nine cuts splits each of the 219 maximal cliques;
- every one of the 5,205 induced 5-cycle rows has at most four used cycle
  edges;
- the first crossed edge indices can be ordered strictly as
  `0,18,25,35,50,53,59,72,85`.

The fixed official assignment was loaded into the corrected 30,538-row `k=9`
model.  Gurobi presolved all rows and columns away and returned objective zero
in 0.07 seconds on one thread.

## Exact graph bounds

Standard-library bitset enumeration gives:

- 219 maximal cliques: 131 of size 3, 81 of size 4, and 7 of size 5;
- clique number `omega(G)=5`;
- 1,007 maximal independent sets, including 19 of maximum size 9;
- exact independence number `alpha(G)=9`.

The exact `alpha=9` confirms that the incumbent is a maximum packing among
singleton cuts, but it is not an upper bound on arbitrary cut packings because
in general `alpha(G) <= gamma(G) <= 2 alpha(G)-1`.

Two simple clique-cover shortcuts cannot prove 9:

1. An edge-clique cover needs at least
   `ceil(275 / binom(5,2)) = 28` cliques by counting.
2. If `q` cliques have connected edge-union, they cover at most
   `1+q(omega-1)` vertices.  Nine cliques cover at most 37 vertices, so a
   connected spanning nine-clique certificate is impossible.

The stronger fractional certificate was solved and then verified in exact
rational arithmetic.  Nonnegative weights on 38 maximal cliques have total
`551/52`; every nontrivial vertex cut splits clique weight at least one.  This
was checked without an optimizer by 39 integral root-to-terminal hypergraph
min-cuts, all of scaled value 52 at scale 52.  A matching rational dual on 39
cuts proves the relaxation value exactly.  Adding all 5,205 induced-C5 rows,
including the paper's stronger coefficient `|delta(S) intersect E(C)|/2`, does
not improve the value: every optimal C5 weight is zero.

Therefore this family rigorously proves only

\[
\gamma(G)\le\lfloor 551/52\rfloor=10.
\]

Lovasz theta on the original 40-vertex graph would bound `alpha(G)`, which is
already known exactly, not `gamma(G)`.  Theta becomes valid only on the
exponential conflict graph whose vertices are all nonempty cuts; no compact
SDP or separation oracle for that graph was identified.  Using theta of the
original graph as a cut-packing upper bound would be invalid (paths already
give counterexamples).

## Exact `k=10` decision experiment

The decision model uses the 275-edge simple graph and ten cut blocks:

- 400 binary shore variables `u[c,v]`;
- 2,750 continuous XOR variables, forced integral when `u` is integral;
- edge capacities and nonempty-cut rows;
- 219 maximal-clique packing inequalities;
- 5,205 induced-C5 odd-cycle inequalities;
- continuous first-crossing-edge selectors that order the ten interchangeable
  blocks.

The anchor ordering is without loss of generality: every nonempty cut has a
first crossed edge; edge-disjoint cuts have distinct first edges; permuting the
cuts orders these anchors.  At integer `u`, the prefix constraints force the
continuous anchor selector to be one-hot at that first edge.

An initial implementation incorrectly distributed a minus sign in one prefix
constraint and falsely declared both `k=9` and `k=10` infeasible. A tiny IIS
exposed the defect. Those invalid generated files were excluded from the
published repository and are explicitly not evidence. After correction, the
official `k=9` assignment is feasible as described above.

Regenerate the corrected model, then run it from the repository root:

```text
python3 instances/graph40-40-1rand/scripts/build_graph40_40_k10.py
gurobi_cl Threads=2 TimeLimit=590 MIPGap=0 MIPFocus=2 Symmetry=2 Cuts=3 Presolve=2 PreSparsify=1 LogFile=instances/graph40-40-1rand/logs/graph40-40-1rand_k10_exact_corrected.log ResultFile=instances/graph40-40-1rand/artifacts/graph40-40-1rand_k10_corrected_result.sol instances/graph40-40-1rand/artifacts/graph40-40-1rand_k10_clique_oddhole_anchor.lp
```

The generated LP is intentionally not checked in.

Corrected model fingerprint: `0x55b54138`.  Gurobi 13.0.2 explored 1,899 nodes
and 3,168,440 simplex iterations in 590.01 seconds using two threads.  It found
no solution, but stopped at the time limit with 34 open nodes.  Since this is
a pure feasibility model, the reported zero LP bound carries no cut-packing
upper-bound information.

## Paper and generator identity audit

The JEA paper states that random graphs use seed 1 unless otherwise stated.  It
defines `graph-n-d` as a random tree plus

\[
\max\{0,(d/100)\binom n2-n+1\}
\]

additional randomly selected edges.  For `n=40,d=40`, this prescribes 39 tree
edges plus 273 additional draws, or 312 raw records.  Figure 6 graphically
plots cut-packing value 9 for its `40-40` graph; Table I says all four
40-vertex random-density instances were solved to optimality.  The same plot's
exact-MIS point is approximately 6, whereas the recovered MIP graph has exact
independence number 9.

The public Randgraph `RandomGraph.cxx` accepts an explicit seed, uses
`srand48(seed)`, creates a union-find random tree, and then emits the requested
number of random edges without duplicate suppression.  Literal seed-1
reproductions were tested for both unit weights and the default uniform weights
(the latter consumes an extra random draw per accepted edge), and for both 312
and 300 raw records.  None matches the MPS edge set or even its sorted degree
sequence, so vertex relabeling cannot explain the discrepancy.

Accordingly:

- **published computation:** the paper reports/plots value 9 for its labeled
  `graph-40-40` experiment;
- **verified fact:** the MIPLIB MPS has the different invariants above and is
  still marked open with incumbent `-9`;
- **inference:** the names and matching value suggest a common lineage, but
  the exact graph identity is unproved and the available evidence points to a
  preprocessing, generator-version, or data mismatch;
- **consequence:** the paper result is not a portable certificate for this MPS.

## Completed proof route

The proposed Hamming-signature SAT route has now been completed.  Its actual
size after symmetry breaking is 3,510 variables and 25,519 clauses.  The
checked UNSAT certificate rules out `gamma(G) >= 10`, so no further feasibility
search is needed for this instance.

## Reproduction artifacts

- `reconstruct_graph40_40.py`
- `graph40-40-1rand_structural_audit.json`
- `graph40-40-1rand_edges.tsv`
- `graph40-40-1rand_decoded_incumbent.json`
- `validate_graph40_40_incumbent.py`
- `graph40-40-1rand_k9_independent_validation.json`
- `regenerate_graph40_40_randgraph.py`
- `graph40-40-1rand_randgraph_seed1_audit.json`
- `graph40-40-1rand_fractional_clique_c5_report.md`
- `graph40-40-1rand_fractional_clique_c5_odd_certificate.json`
- `verify_graph40_40_fractional_clique_c5.py`
- `graph40-40-1rand_fractional_clique_c5_odd_exact_audit.json`
- `build_graph40_40_k10.py`
- `graph40-40-1rand_k10_clique_oddhole_anchor.lp`
- `logs/graph40-40-1rand_k10_exact_corrected.log`

Key SHA-256 values:

- official MPS gzip: `faf688f36bc47c807167d167dfb9e744a8afeb7d2aeec1d75eec6bb0ea9eea6e`;
- official solution gzip: `e3ce93fb9606a264028c7ee59abeabae46d19e17f646b0bf51a66de2fc3b01d5`;
- corrected `k=10` LP: `3c617112c05b477676b4393ab8e5579b911f1060eafcd8fbd712d942f0c2d76b`;
- corrected solve log: `53950213445200d6921cba814fdab8b28232183ab877419e4c67a5229aa19036`;
- exact fractional certificate JSON: `b41faf4769d3815676ea722ef1ad6d246de7e7f5e871e49cfb539a9fc3866d93`.

Primary sources:

- https://miplib.zib.de/instance_details_graph40-40-1rand.html
- https://or.rwth-aachen.de/files/research/publications/jea2016-cutpacking.pdf
- https://www.diag.uniroma1.it/~challenge9/download.shtml
- https://www.diag.uniroma1.it/~challenge9/code/Randgraph.tar.gz

Epistemic status: exact original-MPS primal validation plus a byte-rebuilt CNF
and independently checked LRAT refutation; **OPT = -9**.  The paper comparison
is historical context only and is not used in the proof.
