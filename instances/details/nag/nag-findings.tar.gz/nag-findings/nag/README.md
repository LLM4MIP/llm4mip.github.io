# nag Experiment Archive

2026-09-14 independent dual-bound review: [adopted bound, proof chain, checks, and limitations](../../docs/dual-bound-audit-2026-09-14/cases/nag.zh.md). Reviewed lower bound: **approximately 550.5405405405405**. This review distinguishes exact, literature, and numerical evidence; historical statements below remain dated records.

This directory records a controlled MIPLIB experiment for the `nag` minimization instance.

## Archived Result

The strongest archived result is a tolerance-verified feasible solution with objective `930.0`. The best available dual bound is `550.5405405405405`, giving a combined relative gap of `0.40802092414995644`. This is a partial result, not a proof of optimality.

No run proved optimality or infeasibility. The ten archived runs ended with `TIMEOUT` (three COPT runs), `NODE_LIMIT` (one Gurobi run), or `TIME_LIMIT` (six Gurobi runs). These statuses must not be interpreted as either optimality or infeasibility.

The best incumbent was verified at tolerance `1e-9`. One Gurobi run produced an approximately `959.9999997117` incumbent that was not tolerance-verified and was excluded from the best verified primal bound.

See [final_report.md](final_report.md) for the complete termination table, bounds, verification details, reproducibility metadata, and recommended next experiment. Controller-generated ledgers remain in `experiments.json`, `experiments.md`, and `result.json` and were not modified.

Machine names, solver build versions, full parameter dictionaries, and random seeds were not exposed by the supplied archival summaries; the final report records them as unavailable rather than guessing.
