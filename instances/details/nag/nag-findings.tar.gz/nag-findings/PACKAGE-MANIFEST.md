# Package manifest: nag

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 80
Excluded source files: 1

## Included files

- `README.md`
- `experiments.json`
- `experiments.md`
- `final_report.md`
- `reporting_bundle.json`
- `result.json`
- `runs/copt-20260903-111158-6e25f505/best.sol`
- `runs/copt-20260903-111158-6e25f505/driver.stderr`
- `runs/copt-20260903-111158-6e25f505/driver.stdout`
- `runs/copt-20260903-111158-6e25f505/result.json`
- `runs/copt-20260903-111158-6e25f505/solver.log`
- `runs/copt-20260903-112858-40c812b1/best.sol`
- `runs/copt-20260903-112858-40c812b1/driver.stderr`
- `runs/copt-20260903-112858-40c812b1/driver.stdout`
- `runs/copt-20260903-112858-40c812b1/result.json`
- `runs/copt-20260903-112858-40c812b1/solver.log`
- `runs/copt-20260903-121622-e1760a2a/best.sol`
- `runs/copt-20260903-121622-e1760a2a/driver.stderr`
- `runs/copt-20260903-121622-e1760a2a/driver.stdout`
- `runs/copt-20260903-121622-e1760a2a/result.json`
- `runs/copt-20260903-121622-e1760a2a/solver.log`
- `runs/gurobi-20260903-110916-ae630e67/best.sol`
- `runs/gurobi-20260903-110916-ae630e67/driver.stderr`
- `runs/gurobi-20260903-110916-ae630e67/driver.stdout`
- `runs/gurobi-20260903-110916-ae630e67/result.json`
- `runs/gurobi-20260903-110916-ae630e67/solver.log`
- `runs/gurobi-20260903-111154-cfec0b79/best.sol`
- `runs/gurobi-20260903-111154-cfec0b79/driver.stderr`
- `runs/gurobi-20260903-111154-cfec0b79/driver.stdout`
- `runs/gurobi-20260903-111154-cfec0b79/result.json`
- `runs/gurobi-20260903-111154-cfec0b79/solver.log`
- `runs/gurobi-20260903-112855-1f6a264b/best.sol`
- `runs/gurobi-20260903-112855-1f6a264b/driver.stderr`
- `runs/gurobi-20260903-112855-1f6a264b/driver.stdout`
- `runs/gurobi-20260903-112855-1f6a264b/result.json`
- `runs/gurobi-20260903-112855-1f6a264b/solver.log`
- `runs/gurobi-20260903-121617-a3ec142b/best.sol`
- `runs/gurobi-20260903-121617-a3ec142b/driver.stderr`
- `runs/gurobi-20260903-121617-a3ec142b/driver.stdout`
- `runs/gurobi-20260903-121617-a3ec142b/result.json`
- `runs/gurobi-20260903-121617-a3ec142b/solver.log`
- `runs/gurobi-20260903-131802-fc559cc6/best.sol`
- `runs/gurobi-20260903-131802-fc559cc6/driver.stderr`
- `runs/gurobi-20260903-131802-fc559cc6/driver.stdout`
- `runs/gurobi-20260903-131802-fc559cc6/result.json`
- `runs/gurobi-20260903-131802-fc559cc6/solver.log`
- `runs/gurobi-20260903-135908-06dcd3f6/best.sol`
- `runs/gurobi-20260903-135908-06dcd3f6/driver.stderr`
- `runs/gurobi-20260903-135908-06dcd3f6/driver.stdout`
- `runs/gurobi-20260903-135908-06dcd3f6/result.json`
- `runs/gurobi-20260903-135908-06dcd3f6/solver.log`
- `runs/gurobi-20260903-150009-f288a77d/best.sol`
- `runs/gurobi-20260903-150009-f288a77d/driver.stderr`
- `runs/gurobi-20260903-150009-f288a77d/driver.stdout`
- `runs/gurobi-20260903-150009-f288a77d/result.json`
- `runs/gurobi-20260903-150009-f288a77d/solver.log`
- `solutions/public/nag-1.sol.gz`
- `solutions/public/nag-2.sol.gz`
- `structure-gurobi.log`
- `structure.json`
- `verification/copt-20260903-111158-6e25f505.exact-check.json`
- `verification/copt-20260903-111158-6e25f505.exact-check.txt`
- `verification/copt-20260903-112858-40c812b1.exact-check.json`
- `verification/copt-20260903-112858-40c812b1.exact-check.txt`
- `verification/copt-20260903-121622-e1760a2a.exact-check.json`
- `verification/copt-20260903-121622-e1760a2a.exact-check.txt`
- `verification/gurobi-20260903-110916-ae630e67.exact-check.json`
- `verification/gurobi-20260903-110916-ae630e67.exact-check.txt`
- `verification/gurobi-20260903-111154-cfec0b79.exact-check.json`
- `verification/gurobi-20260903-111154-cfec0b79.exact-check.txt`
- `verification/gurobi-20260903-112855-1f6a264b.exact-check.json`
- `verification/gurobi-20260903-112855-1f6a264b.exact-check.txt`
- `verification/gurobi-20260903-121617-a3ec142b.exact-check.json`
- `verification/gurobi-20260903-121617-a3ec142b.exact-check.txt`
- `verification/gurobi-20260903-131802-fc559cc6.exact-check.json`
- `verification/gurobi-20260903-131802-fc559cc6.exact-check.txt`
- `verification/gurobi-20260903-135908-06dcd3f6.exact-check.json`
- `verification/gurobi-20260903-135908-06dcd3f6.exact-check.txt`
- `verification/gurobi-20260903-150009-f288a77d.exact-check.json`
- `verification/gurobi-20260903-150009-f288a77d.exact-check.txt`

## Excluded files

- `input/nag.mps.gz (137612 bytes; raw benchmark input; sha256 8d3a451afaed8593ad1308d4799a41015ee30c64ef83279ab8cc14df256b6a15)`
