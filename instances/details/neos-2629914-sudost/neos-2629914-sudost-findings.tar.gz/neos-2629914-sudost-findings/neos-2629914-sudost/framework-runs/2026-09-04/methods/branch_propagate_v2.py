import argparse, gzip, json, math, os, time

INF=float('inf')
TOL=1e-8

def open_model(path):
    return gzip.open(path,'rt',errors='replace') if path.lower().endswith('.gz') else open(path,'r',errors='replace')

def parse_mps(path):
    sense='min'; section=None; expect_sense=False; objrow=None
    rowtype={}; cols={}; rhs={}; ranges={}; lo={}; up={}; integer=set(); names=[]; seen=set(); int_mode=False
    with open_model(path) as f:
        for raw in f:
            line=raw.strip()
            if not line or line.startswith('*'): continue
            tok=line.split(); key=tok[0].upper()
            if expect_sense:
                if key.startswith('MAX'): sense='max'
                elif key.startswith('MIN'): sense='min'
                expect_sense=False; continue
            if key=='OBJSENSE': expect_sense=True; continue
            if key in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','SOS','QSECTION','QUADOBJ'):
                section=key
                if key=='ENDATA': break
                continue
            if section=='ROWS' and len(tok)>=2:
                typ=tok[0].upper(); rn=tok[1]; rowtype[rn]=typ
                if typ=='N' and objrow is None: objrow=rn
            elif section=='COLUMNS':
                if any('MARKER' in x.upper() for x in tok):
                    z=' '.join(tok).upper(); int_mode=('INTORG' in z) if 'INTORG' in z or 'INTEND' in z else int_mode
                    if 'INTEND' in z: int_mode=False
                    continue
                if len(tok)<3: continue
                v=tok[0]
                if v not in seen: seen.add(v); names.append(v)
                if int_mode: integer.add(v)
                p=1
                while p+1<len(tok):
                    try: val=float(tok[p+1].replace('D','E').replace('d','e'))
                    except ValueError: p+=2; continue
                    cols.setdefault(v,[]).append((tok[p],val)); p+=2
            elif section in ('RHS','RANGES'):
                target=rhs if section=='RHS' else ranges; p=1
                while p+1<len(tok):
                    try: target[tok[p]]=float(tok[p+1].replace('D','E').replace('d','e'))
                    except ValueError: pass
                    p+=2
            elif section=='BOUNDS' and len(tok)>=3:
                typ=tok[0].upper(); v=tok[2]
                if v not in seen: seen.add(v); names.append(v)
                val=0.0
                if len(tok)>=4:
                    try: val=float(tok[3].replace('D','E').replace('d','e'))
                    except ValueError: val=0.0
                if typ=='LO': lo[v]=val
                elif typ=='UP': up[v]=val
                elif typ=='FX': lo[v]=val; up[v]=val
                elif typ=='FR': lo[v]=-INF; up[v]=INF
                elif typ=='MI': lo[v]=-INF
                elif typ=='PL': up[v]=INF
                elif typ=='BV': lo[v]=0.0; up[v]=1.0; integer.add(v)
                elif typ=='LI': lo[v]=val; integer.add(v)
                elif typ=='UI': up[v]=val; integer.add(v)
    idx={v:i for i,v in enumerate(names)}; n=len(names)
    lb=[lo.get(v,0.0) for v in names]; ub=[up.get(v,INF) for v in names]
    isint=[v in integer for v in names]; c=[0.0]*n; rows={r:[] for r,t in rowtype.items() if t!='N'}
    for v,entries in cols.items():
        j=idx[v]
        for r,a in entries:
            if r==objrow: c[j]+=a
            elif r in rows and a!=0: rows[r].append((j,a))
    cons=[]
    for r,terms in rows.items():
        typ=rowtype[r]; b=rhs.get(r,0.0); rg=ranges.get(r)
        if typ=='E': L=U=b
        elif typ=='L': L=-INF; U=b
        else: L=b; U=INF
        if rg is not None:
            q=abs(rg)
            if typ=='L': L=b-q
            elif typ=='G': U=b+q
            elif rg>=0: L=b; U=b+q
            else: L=b-q; U=b
        cons.append((r,terms,L,U))
    return sense,names,c,lb,ub,isint,cons

def ceil_int(x): return math.ceil(x-1e-9)
def floor_int(x): return math.floor(x+1e-9)

def propagate(lb,ub,isint,cons,max_rounds=40):
    updates=0
    for rnd in range(max_rounds):
        changed=False
        for rn,terms,L,U in cons:
            sfmin=sfmax=0.0; ninf=0; pinf=0; ends=[]
            for j,a in terms:
                mn=a*(lb[j] if a>=0 else ub[j]); mx=a*(ub[j] if a>=0 else lb[j])
                if math.isinf(mn): ninf+=1
                else: sfmin+=mn
                if math.isinf(mx): pinf+=1
                else: sfmax+=mx
                ends.append((j,a,mn,mx))
            rmin=-INF if ninf else sfmin; rmax=INF if pinf else sfmax
            if rmin>U+TOL or rmax<L-TOL: return False,updates,rnd+1
            for j,a,mn,mx in ends:
                omin=-INF if ninf-(1 if math.isinf(mn) else 0)>0 else sfmin-(0.0 if math.isinf(mn) else mn)
                omax=INF if pinf-(1 if math.isinf(mx) else 0)>0 else sfmax-(0.0 if math.isinf(mx) else mx)
                nl,nu=lb[j],ub[j]
                if a>0:
                    if math.isfinite(L) and math.isfinite(omax): nl=max(nl,(L-omax)/a)
                    if math.isfinite(U) and math.isfinite(omin): nu=min(nu,(U-omin)/a)
                else:
                    if math.isfinite(U) and math.isfinite(omin): nl=max(nl,(U-omin)/a)
                    if math.isfinite(L) and math.isfinite(omax): nu=min(nu,(L-omax)/a)
                if isint[j]:
                    if math.isfinite(nl): nl=float(ceil_int(nl))
                    if math.isfinite(nu): nu=float(floor_int(nu))
                if nl>nu+TOL: return False,updates,rnd+1
                if nl>lb[j]+TOL: lb[j]=nl; changed=True; updates+=1
                if nu<ub[j]-TOL: ub[j]=nu; changed=True; updates+=1
            if not changed: return True,updates,rnd+1
    return True,updates,max_rounds

def obj_bound(c,lb,ub,sense):
    s=0.0
    for a,l,u in zip(c,lb,ub):
        x=(l if a>=0 else u) if sense=='min' else (u if a>=0 else l)
        if math.isinf(x): return -INF if sense=='min' else INF
        s+=a*x
    return s

def feasible(x,cons,lb,ub,isint):
    for j,v in enumerate(x):
        if v<lb[j]-1e-6 or v>ub[j]+1e-6: return False
        if isint[j] and abs(v-round(v))>1e-6: return False
    for rn,terms,L,U in cons:
        z=sum(a*x[j] for j,a in terms)
        if z<L-1e-6 or z>U+1e-6: return False
    return True

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--model',required=True); ap.add_argument('--runtime',type=float,default=100); ap.add_argument('--seed',type=int,default=20260904); a=ap.parse_args()
    start=time.monotonic(); deadline=start+max(1.0,a.runtime)
    sense,names,c,rootl,rootu,isint,cons=parse_mps(a.model)
    ok,u0,r0=propagate(rootl,rootu,isint,cons)
    rootb=obj_bound(c,rootl,rootu,sense) if ok else (INF if sense=='min' else -INF)
    stack=[] if not ok else [(rootl,rootu,0)]; nodes=0; updates=u0; rounds=r0; incumbent=None; incobj=None; exhausted=True; maxdepth=0
    while stack:
        if time.monotonic()>=deadline: exhausted=False; break
        lb,ub,dep=stack.pop(); nodes+=1; maxdepth=max(maxdepth,dep)
        good,uu,rr=propagate(lb,ub,isint,cons); updates+=uu; rounds+=rr
        if not good: continue
        b=obj_bound(c,lb,ub,sense)
        if incobj is not None and ((sense=='min' and b>=incobj-1e-9) or (sense=='max' and b<=incobj+1e-9)): continue
        branch=-1; width=-1.0
        for j,q in enumerate(isint):
            if q and ub[j]-lb[j]>0.5 and math.isfinite(lb[j]) and math.isfinite(ub[j]):
                w=ub[j]-lb[j]
                if w>width: width=w; branch=j
        if branch<0:
            x=[]; finite=True
            for l,u,q in zip(lb,ub,isint):
                if not math.isfinite(l) or not math.isfinite(u): finite=False; break
                x.append(round(l) if q else 0.5*(l+u))
            if finite and feasible(x,cons,lb,ub,isint):
                z=sum(vv*cc for vv,cc in zip(x,c))
                if incobj is None or (sense=='min' and z<incobj-1e-8) or (sense=='max' and z>incobj+1e-8): incumbent=x; incobj=z
            continue
        mid=math.floor((lb[branch]+ub[branch])/2.0)
        l1=lb.copy(); u1=ub.copy(); u1[branch]=mid
        l2=lb.copy(); u2=ub.copy(); l2[branch]=mid+1
        # Push the less promising side first so the more promising objective side is explored next.
        b1=obj_bound(c,l1,u1,sense); b2=obj_bound(c,l2,u2,sense)
        children=[(l1,u1,dep+1,b1),(l2,u2,dep+1,b2)]
        children.sort(key=lambda q:q[3],reverse=(sense=='min'))
        for cl,cu,cd,cb in children: stack.append((cl,cu,cd))
    frontier=[]
    for l,u,d in stack: frontier.append(obj_bound(c,l,u,sense))
    if exhausted:
        dual=incobj if incumbent is not None else (INF if sense=='min' else -INF)
    elif frontier:
        dual=min(frontier) if sense=='min' else max(frontier)
        if incumbent is not None: dual=min(dual,incobj) if sense=='min' else max(dual,incobj)
    else: dual=rootb
    if incumbent is not None:
        with open('best.sol','w') as f:
            f.write('# Objective value = %.17g\n'%incobj)
            for n,v in zip(names,incumbent): f.write('%s %.17g\n'%(n,v))
    cert={'sense':sense,'variables':len(names),'integer_variables':sum(isint),'constraints':len(cons),'root_propagation_feasible':ok,'root_objective_bound':rootb if math.isfinite(rootb) else None,'frontier_objective_bound':dual if math.isfinite(dual) else None,'frontier_nodes':len(stack),'nodes_processed':nodes,'domain_updates':updates,'propagation_rounds':rounds,'tree_exhausted':exhausted,'maximum_depth':maxdepth,'incumbent_objective':incobj}
    with open('propagation_certificate.json','w') as f: json.dump(cert,f,indent=2,sort_keys=True)
    elapsed=time.monotonic()-start
    result={'status':'success','algorithm_family':'linear-interval propagation with integer branch-and-bound enumeration','algorithm_role':'dual_bound','hypothesis':'Index-safe row propagation plus explicit integer disjunctions can strengthen the globally valid objective bound or exhaust a substantial structured subtree.','work_units':max(1,nodes+updates),'work_unit_name':'processed_nodes_plus_domain_updates','termination_reason':'search_tree_exhausted' if exhausted else 'configured_runtime_reached','target_bound':'global objective dual bound (%s)'%('lower' if sense=='min' else 'upper'),'objective_sense':sense,'dual_bound':dual if math.isfinite(dual) else None,'root_bound':rootb if math.isfinite(rootb) else None,'objective':incobj,'solution_artifact':'best.sol' if incumbent is not None else None,'certificate_artifact':'propagation_certificate.json','seed':a.seed,'runtime_seconds':elapsed,'acceptance_criterion':'Accept only assignments independently checked against every parsed row, bound, and integrality condition; prune only by interval infeasibility or a valid objective interval bound.','pivot_condition':'Branch on the widest finite nonfixed integer domain after propagation; replace this method if parsing succeeds but no nodes or domain updates are generated.','nodes':nodes,'domain_updates':updates,'propagation_rounds':rounds,'tree_exhausted':exhausted}
    with open('method_result.json','w') as f: json.dump(result,f,indent=2,sort_keys=True)

if __name__=='__main__': main()
