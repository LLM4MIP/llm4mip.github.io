#!/usr/bin/env python3
import argparse, json, math, os, time
from collections import Counter, defaultdict


def atom(x):
    try:
        return float(x.replace('D','E').replace('d','e'))
    except Exception:
        raise ValueError('Invalid numeric MPS token: ' + repr(x))


def parse_mps(path):
    section = None
    row_type = {}
    objective_row = None
    columns = defaultdict(dict)
    rhs = defaultdict(float)
    lower = {}
    upper = {}
    integer_vars = set()
    all_vars = set()
    integer_mode = False
    objective_sense = 'minimize'
    work = 0
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for raw in f:
            if not raw.strip() or raw.lstrip().startswith('*'):
                continue
            p = raw.split()
            if not p:
                continue
            key = p[0].upper()
            if key in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE','OBJNAME'):
                section = key
                if key == 'ENDATA':
                    break
                continue
            if section == 'OBJSENSE':
                if key.startswith('MAX'):
                    objective_sense = 'maximize'
                elif key.startswith('MIN'):
                    objective_sense = 'minimize'
                continue
            if section == 'ROWS':
                if len(p) >= 2:
                    typ, name = p[0].upper(), p[1]
                    row_type[name] = typ
                    if typ == 'N' and objective_row is None:
                        objective_row = name
                    work += 1
                continue
            if section == 'COLUMNS':
                joined = ' '.join(p).upper()
                if 'MARKER' in joined:
                    if 'INTORG' in joined:
                        integer_mode = True
                    elif 'INTEND' in joined:
                        integer_mode = False
                    continue
                var = p[0]
                all_vars.add(var)
                if integer_mode:
                    integer_vars.add(var)
                pairs = p[1:]
                for i in range(0, len(pairs)-1, 2):
                    r, v = pairs[i], atom(pairs[i+1])
                    columns[var][r] = columns[var].get(r, 0.0) + v
                    work += 1
                continue
            if section == 'RHS':
                pairs = p[1:]
                for i in range(0, len(pairs)-1, 2):
                    rhs[pairs[i]] = atom(pairs[i+1])
                    work += 1
                continue
            if section == 'BOUNDS':
                if len(p) < 3:
                    continue
                typ = p[0].upper()
                var = p[2]
                val = atom(p[3]) if len(p) > 3 else 0.0
                all_vars.add(var)
                if typ in ('LO','LI'):
                    lower[var] = val
                elif typ in ('UP','UI'):
                    upper[var] = val
                elif typ == 'FX':
                    lower[var] = val; upper[var] = val
                elif typ == 'BV':
                    lower[var] = 0.0; upper[var] = 1.0; integer_vars.add(var)
                elif typ == 'FR':
                    lower[var] = -math.inf; upper[var] = math.inf
                elif typ == 'MI':
                    lower[var] = -math.inf
                elif typ == 'PL':
                    upper[var] = math.inf
                if typ in ('LI','UI'):
                    integer_vars.add(var)
                work += 1
    for v in all_vars:
        lower.setdefault(v, 0.0)
        upper.setdefault(v, math.inf)
    return objective_sense, objective_row, row_type, columns, rhs, lower, upper, integer_vars, work


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--seed', type=int, default=0)
    ap.add_argument('--target', default='public dual bound unknown')
    args = ap.parse_args()
    started = time.time()
    sense, objrow, rtype, cols, rhs, lo, up, ints, work = parse_mps(args.model)
    if sense != 'minimize':
        raise RuntimeError('This audit was designed for the measured minimization model.')
    if objrow is None:
        raise RuntimeError('No objective row was found.')

    objective = {v: ent.get(objrow, 0.0) for v, ent in cols.items() if ent.get(objrow, 0.0) != 0.0}
    bound = 0.0
    finite = True
    endpoint_terms = []
    for v, c in objective.items():
        endpoint = lo[v] if c >= 0 else up[v]
        if not math.isfinite(endpoint):
            finite = False
            continue
        term = c * endpoint
        bound += term
        endpoint_terms.append((c, endpoint, term))
        work += 1

    row_entries = defaultdict(list)
    for v, ent in cols.items():
        for r, a in ent.items():
            if r != objrow:
                row_entries[r].append((v, a))

    equality_signatures = Counter()
    assignment_like = []
    inequality_signatures = Counter()
    continuous = set(cols) - ints
    for r, typ in rtype.items():
        if typ == 'N':
            continue
        entries = row_entries.get(r, [])
        ni = sum(1 for v, a in entries if v in ints)
        nc = len(entries) - ni
        coeffs = tuple(sorted(Counter(round(a, 12) for v, a in entries).items()))
        if typ == 'E':
            equality_signatures[(len(entries), ni, nc, round(rhs.get(r,0.0),12), coeffs)] += 1
            if entries and nc == 0 and abs(rhs.get(r,0.0)-1.0) <= 1e-9 and all(abs(a-1.0)<=1e-9 for v,a in entries):
                assignment_like.append(set(v for v,a in entries))
        else:
            compact_coeff = tuple(sorted(Counter(round(a,9) for v,a in entries).items()))
            inequality_signatures[(typ, len(entries), ni, nc, round(rhs.get(r,0.0),9), compact_coeff)] += 1
        work += max(1, len(entries))

    membership = Counter()
    for s in assignment_like:
        for v in s:
            membership[v] += 1
    assignment_summary = {
        'candidate_rows': len(assignment_like),
        'candidate_row_sizes': dict(Counter(len(s) for s in assignment_like)),
        'distinct_integer_variables_covered': len(membership),
        'membership_multiplicity': dict(Counter(membership.values())),
        'exact_16x16_assignment_signature': bool(len(assignment_like)==32 and len(membership)==256 and all(len(s)==16 for s in assignment_like) and all(k==2 for k in membership.values()))
    }
    def sig_list(counter, limit=20):
        out=[]
        for sig,n in counter.most_common(limit):
            out.append({'count':n,'signature':repr(sig)})
        return out
    profile = {
        'objective_sense': sense,
        'variables': len(cols),
        'integer_variables': len(ints),
        'continuous_variables': len(continuous),
        'rows': len([r for r,t in rtype.items() if t!='N']),
        'objective_nonzeros': len(objective),
        'assignment_test': assignment_summary,
        'equality_signature_count': len(equality_signatures),
        'dominant_equality_signatures': sig_list(equality_signatures),
        'inequality_signature_count': len(inequality_signatures),
        'dominant_inequality_signatures': sig_list(inequality_signatures),
        'objective_rhs_token': rhs.get(objrow, 0.0)
    }
    cert = {
        'kind':'variable-domain objective lower bound',
        'sense':'minimize',
        'finite':finite,
        'candidate_lower_bound_excluding_any_objective_offset': bound if finite else None,
        'objective_rhs_token': rhs.get(objrow,0.0),
        'term_count':len(endpoint_terms),
        'justification':'For each linear objective term c*x, use c*lower_bound when c is nonnegative and c*upper_bound when c is negative. Summing these independent inequalities is globally valid. Any model objective offset must be handled by the independent verifier.',
        'independent_verification_required':True
    }
    with open('structural_profile.json','w') as f:
        json.dump(profile,f,indent=2,sort_keys=True)
    with open('bound_certificate.json','w') as f:
        json.dump(cert,f,indent=2,sort_keys=True)
    elapsed = time.time()-started
    result = {
        'status':'success',
        'algorithm_family':'solver-independent MPS domain relaxation and incidence-pattern audit',
        'algorithm_role':'dual_bound',
        'hypothesis':'The 32 equations define a 16 by 16 assignment master, and objective-variable domains provide a reproducible initial global lower bound.',
        'work_units':max(1,work),
        'work_unit_name':'parsed coefficients, bounds, and classified row incidences',
        'termination_reason':'Complete deterministic scan of the MPS and all reconstructed row incidences.',
        'target_bound':args.target,
        'candidate_dual_bound':bound if finite else None,
        'seed':args.seed,
        'runtime_seconds':elapsed,
        'acceptance_criterion':'Successful full parse, positive work count, complete row classification, and a finite endpoint for every objective term.',
        'accepted':bool(finite),
        'pivot_condition':'Use assignment-specific primal and matching methods only if exact_16x16_assignment_signature is true; otherwise infer a different equality decomposition.',
        'artifacts':['structural_profile.json','bound_certificate.json']
    }
    with open('method_result.json','w') as f:
        json.dump(result,f,indent=2,sort_keys=True)

if __name__ == '__main__':
    main()
