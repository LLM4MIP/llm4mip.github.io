import argparse, gzip, json, math, os, random, time


def open_model(path):
    with open(path, 'rb') as f:
        magic = f.read(2)
    if magic == b'\x1f\x8b':
        return gzip.open(path, 'rt', errors='replace')
    return open(path, 'rt', errors='replace')


def parse_mps(path):
    sense = 'min'
    section = None
    rows = {}
    row_order = []
    objrow = None
    cols = {}
    rhs = {}
    ranges = {}
    bounds = {}
    integer_mode = False
    first_rhs_name = None
    first_range_name = None
    first_bound_name = None
    with open_model(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('*'):
                continue
            tok = line.replace("'", '').split()
            if not tok:
                continue
            head = tok[0].upper()
            if head in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE','OBJNAME'):
                section = head
                if head == 'ENDATA':
                    break
                if head == 'OBJSENSE' and len(tok) > 1:
                    sense = 'max' if tok[1].upper().startswith('MAX') else 'min'
                continue
            if section == 'OBJSENSE':
                sense = 'max' if head.startswith('MAX') else 'min'
                continue
            if section == 'ROWS':
                if len(tok) >= 2:
                    typ, name = tok[0].upper(), tok[1]
                    rows[name] = typ
                    row_order.append(name)
                    if typ == 'N' and objrow is None:
                        objrow = name
                continue
            if section == 'COLUMNS':
                if any(x.upper() == 'MARKER' for x in tok):
                    integer_mode = any(x.upper() == 'INTORG' for x in tok)
                    if any(x.upper() == 'INTEND' for x in tok):
                        integer_mode = False
                    continue
                if len(tok) < 3:
                    continue
                var = tok[0]
                ent = cols.setdefault(var, {'a':{}, 'int':False})
                if integer_mode:
                    ent['int'] = True
                k = 1
                while k + 1 < len(tok):
                    r = tok[k]
                    try:
                        v = float(tok[k+1].replace('D','E').replace('d','e'))
                    except ValueError:
                        k += 2
                        continue
                    ent['a'][r] = ent['a'].get(r, 0.0) + v
                    k += 2
                continue
            if section == 'RHS':
                if len(tok) < 3:
                    continue
                setname = tok[0]
                if first_rhs_name is None:
                    first_rhs_name = setname
                if setname != first_rhs_name:
                    continue
                k = 1
                while k + 1 < len(tok):
                    try:
                        rhs[tok[k]] = float(tok[k+1].replace('D','E').replace('d','e'))
                    except ValueError:
                        pass
                    k += 2
                continue
            if section == 'RANGES':
                if len(tok) < 3:
                    continue
                setname = tok[0]
                if first_range_name is None:
                    first_range_name = setname
                if setname != first_range_name:
                    continue
                k = 1
                while k + 1 < len(tok):
                    try:
                        ranges[tok[k]] = float(tok[k+1].replace('D','E').replace('d','e'))
                    except ValueError:
                        pass
                    k += 2
                continue
            if section == 'BOUNDS':
                if len(tok) < 3:
                    continue
                bt = tok[0].upper()
                setname = tok[1]
                if first_bound_name is None:
                    first_bound_name = setname
                if setname != first_bound_name:
                    continue
                var = tok[2]
                val = 0.0
                if len(tok) > 3:
                    try:
                        val = float(tok[3].replace('D','E').replace('d','e'))
                    except ValueError:
                        val = 0.0
                b = bounds.setdefault(var, [0.0, math.inf, False])
                if bt == 'LO': b[0] = val
                elif bt == 'UP': b[1] = val
                elif bt == 'FX': b[0] = val; b[1] = val
                elif bt == 'FR': b[0] = -math.inf; b[1] = math.inf
                elif bt == 'MI': b[0] = -math.inf
                elif bt == 'PL': b[1] = math.inf
                elif bt == 'BV': b[0] = 0.0; b[1] = 1.0; b[2] = True
                elif bt == 'LI': b[0] = val; b[2] = True
                elif bt == 'UI': b[1] = val; b[2] = True
                continue
    if objrow is None:
        raise RuntimeError('No objective row found in MPS')
    variables = []
    name_to_idx = {}
    for name, ent in cols.items():
        b = bounds.get(name, [0.0, math.inf, False])
        isint = bool(ent['int'] or b[2])
        lb, ub = b[0], b[1]
        if isint:
            if math.isfinite(lb): lb = math.ceil(lb - 1e-10)
            if math.isfinite(ub): ub = math.floor(ub + 1e-10)
        c = ent['a'].get(objrow, 0.0)
        name_to_idx[name] = len(variables)
        variables.append({'name':name, 'lb':lb, 'ub':ub, 'int':isint, 'c':c, 'a':ent['a']})
    constraints = []
    def add_constraint(row, kind, bound, tag):
        # Canonical g(x)<=0, or equality g(x)=0. Each entry is (factor, constant).
        if kind == 'L':
            factor, const, eq = 1.0, -bound, False
        elif kind == 'G':
            factor, const, eq = -1.0, bound, False
        else:
            factor, const, eq = 1.0, -bound, True
        constraints.append({'name':tag, 'row':row, 'factor':factor, 'const':const, 'eq':eq, 'terms':[]})
    for r in row_order:
        typ = rows[r]
        if typ == 'N':
            continue
        b = rhs.get(r, 0.0)
        if r not in ranges:
            add_constraint(r, typ, b, r)
        else:
            rv = ranges[r]
            ar = abs(rv)
            if typ == 'L':
                add_constraint(r, 'L', b, r+'#upper')
                add_constraint(r, 'G', b-ar, r+'#lower')
            elif typ == 'G':
                add_constraint(r, 'G', b, r+'#lower')
                add_constraint(r, 'L', b+ar, r+'#upper')
            else:
                lo, hi = (b, b+rv) if rv >= 0 else (b+rv, b)
                add_constraint(r, 'G', lo, r+'#lower')
                add_constraint(r, 'L', hi, r+'#upper')
    row_to_cons = {}
    for j, con in enumerate(constraints):
        row_to_cons.setdefault(con['row'], []).append(j)
    for i, var in enumerate(variables):
        for r, a in var['a'].items():
            if r == objrow:
                continue
            for j in row_to_cons.get(r, []):
                con = constraints[j]
                con['terms'].append((i, con['factor'] * a))
    return sense, variables, constraints


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--seed', type=int, default=17)
    ap.add_argument('--runtime', type=float, default=105.0)
    ap.add_argument('--alpha', type=float, default=2.0)
    ap.add_argument('--report-every', type=int, default=100)
    args = ap.parse_args()
    random.seed(args.seed)
    wall0 = time.monotonic()
    sense, variables, cons = parse_mps(args.model)
    parse_seconds = time.monotonic() - wall0
    n, m = len(variables), len(cons)
    if n == 0 or m == 0:
        raise RuntimeError('Parsed model has no variables or no structural constraints')
    sign = 1.0 if sense == 'min' else -1.0
    c = [sign*v['c'] for v in variables]
    lb = [v['lb'] for v in variables]
    ub = [v['ub'] for v in variables]
    lam = [0.0] * m
    best_q = -math.inf
    best_lam = None
    best_iter = 0
    finite_evals = 0
    unbounded_evals = 0
    iterations = 0
    trajectory = []
    deadline = time.monotonic() + args.runtime
    # Full-row projected subgradient ascent. Every iteration evaluates all nonzeros.
    while time.monotonic() < deadline:
        iterations += 1
        red = c[:]
        constant = 0.0
        for j, con in enumerate(cons):
            lj = lam[j]
            if lj == 0.0:
                continue
            constant += lj * con['const']
            for i, a in con['terms']:
                red[i] += lj * a
        x = [0.0] * n
        q = constant
        finite = True
        for i in range(n):
            ri = red[i]
            if ri > 0.0:
                xi = lb[i]
            elif ri < 0.0:
                xi = ub[i]
            else:
                if math.isfinite(lb[i]): xi = lb[i]
                elif math.isfinite(ub[i]): xi = ub[i]
                else: xi = 0.0
            if not math.isfinite(xi):
                finite = False
                break
            x[i] = xi
            q += ri * xi
        if not finite or not math.isfinite(q):
            unbounded_evals += 1
            # A deterministic bounded surrogate supplies a direction toward dual feasibility.
            for i in range(n):
                if not math.isfinite(x[i]):
                    if math.isfinite(lb[i]): x[i] = lb[i]
                    elif math.isfinite(ub[i]): x[i] = ub[i]
                    else: x[i] = 0.0
        else:
            finite_evals += 1
            if q > best_q:
                best_q, best_lam, best_iter = q, lam[:], iterations
        grad = [con['const'] for con in cons]
        for j, con in enumerate(cons):
            s = grad[j]
            for i, a in con['terms']:
                s += a * x[i]
            grad[j] = s
        norm2 = sum(g*g for g in grad)
        if norm2 > 0.0 and math.isfinite(norm2):
            rms = math.sqrt(norm2 / max(1,m))
            step = args.alpha / (math.sqrt(iterations) * max(1.0, rms))
            for j, con in enumerate(cons):
                z = lam[j] + step * grad[j]
                lam[j] = z if con['eq'] else max(0.0, z)
        if iterations == 1 or iterations % args.report_every == 0:
            trajectory.append({'iteration':iterations, 'best_transformed_dual':best_q if math.isfinite(best_q) else None, 'finite_evaluations':finite_evals})
            if len(trajectory) > 200:
                trajectory = trajectory[-200:]
    runtime = time.monotonic() - (wall0 + parse_seconds)
    nnz = sum(len(con['terms']) for con in cons)
    tol = 1e-8 * (1.0 + abs(best_q) if math.isfinite(best_q) else 1.0)
    safe_min_dual = best_q - tol if math.isfinite(best_q) else None
    if safe_min_dual is None:
        reported = None
        bound_type = 'lower' if sense == 'min' else 'upper'
    elif sense == 'min':
        reported = safe_min_dual
        bound_type = 'lower'
    else:
        reported = -safe_min_dual
        bound_type = 'upper'
    cert = {
        'certificate_type':'linear_lagrangian_box_dual',
        'objective_sense':sense,
        'bound_type':bound_type,
        'reported_bound':reported,
        'raw_transformed_minimization_bound':best_q if math.isfinite(best_q) else None,
        'conservative_tolerance':tol,
        'best_iteration':best_iter,
        'constraint_names':[con['name'] for con in cons],
        'multipliers':best_lam,
        'explanation':'For minimization, nonnegative multipliers are used for canonical inequalities g(x)<=0 and free multipliers for equalities. Minimizing the resulting linear Lagrangian exactly over each declared variable box gives a global lower bound. Maximization models are negated, producing a global upper bound.'
    }
    with open('lagrangian_certificate.json','w') as f:
        json.dump(cert,f,indent=2)
    result = {
        'status':'success',
        'algorithm_family':'all-row Lagrangian relaxation with projected subgradient ascent',
        'algorithm_role':'dual_bound',
        'hypothesis':'Dualizing all structural rows and optimizing their multipliers yields a stronger globally valid bound than the previously exhausted assignment-only relaxation.',
        'work_units':max(1, iterations * max(1, nnz)),
        'work_unit_name':'nonzero coefficient evaluations',
        'termination_reason':'deterministic dry-run runtime reached after continuous full-relaxation iterations',
        'target_bound':bound_type + ' dual bound in the original objective sense',
        'best_bound':reported,
        'objective':None,
        'certificate_artifact':'lagrangian_certificate.json',
        'seed':args.seed,
        'runtime_seconds':runtime,
        'parse_seconds':parse_seconds,
        'acceptance_criterion':'Accept for scaling if at least one finite Lagrangian bound is produced and the best bound improves after iteration one.',
        'pivot_condition':'If no finite bound is produced or the trajectory is flat, replace projected subgradient ascent with a constraint-generation or combinatorial relaxation rather than tuning this implementation.',
        'iterations':iterations,
        'finite_bound_evaluations':finite_evals,
        'unbounded_evaluations':unbounded_evals,
        'variables':n,
        'constraints_after_range_expansion':m,
        'expanded_nonzeros':nnz,
        'best_iteration':best_iter,
        'trajectory':trajectory
    }
    with open('method_result.json','w') as f:
        json.dump(result,f,indent=2)

if __name__ == '__main__':
    main()
