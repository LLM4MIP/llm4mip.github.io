# Method Selection

## Structural diagnosis

The measured model is a minimization problem with a likely 16 by 16 assignment master: 256 bounded 0-1 integer variables and 32 equalities. Its 240 positive-cost continuous variables and 51,840 inequalities appear to encode a large extended cost or pairwise consistency system. This diagnosis must first be confirmed from row signatures and variable incidence.

## Candidate algorithms compared

### 1. Domain-bound and matrix-pattern audit — dual-bound role

Parse the MPS independently, reconstruct bounds and objective coefficients, identify assignment-like equality components, classify inequality supports, and compute the separable objective lower bound implied solely by variable domains. This bound is globally valid when all objective terms have the required finite endpoint. It is likely weak, but it provides a reproducible lower-bound baseline and the coefficient map needed by every later specialized method. It is selected as the first deterministic dry run because the formulation interpretation is currently the largest uncertainty.

### 2. Assignment construction with incremental inequality evaluation — primal role

If the equalities form a bipartite assignment system, construct permutations and evaluate the minimum compatible continuous variables directly from the inequality family. Use deterministic greedy insertion followed by swap, 2-cycle, and larger ejection-chain neighborhoods with incremental updates of only affected inequality blocks. Acceptance is strict objective improvement, with seeded diversification after local stagnation. This directly targets a feasible incumbent without embedding a generic MIP solve.

### 3. Lagrangian or surrogate relaxation of coupling inequalities — dual-bound role

Relax selected coupling inequalities while retaining the assignment core, aggregate multipliers by empirically detected row orbit, and solve the resulting assignment subproblem with a dedicated Hungarian or min-cost matching implementation. Subgradient or bundle-style multiplier updates yield valid lower bounds when signs and constants are checked. This is complementary to primal local search and is the principal planned scaled dual method.

### 4. Threshold feasibility encoding with lazy conflict generation — proof role

For a candidate objective threshold, exploit bounded assignment decisions and derive conflicts from violated continuous-variable envelopes. Encode the assignment core and accumulated conflicts into CNF, use CaDiCaL only if the encoding is mathematically validated, and request a DRAT proof for an UNSAT threshold. Verify any certificate with `drat-trim`. This can independently prove a lower bound or optimality, but only after the formulation is reduced to an exact finite threshold model. A custom assertion alone will not count as proof.

### 5. Exact branch-and-bound over assignment components with propagation — hybrid/proof role

Branch on the most constrained assignment component, propagate row and column all-different conditions, maintain lower envelopes for continuous costs, and prune using a matching relaxation. This is a solver-independent exact fallback if the structure is sufficiently separable. It differs materially from SAT encoding and from Lagrangian relaxation.

## Selected sequence

1. Run a short deterministic domain and matrix audit.
2. Use its measured component map to implement and dry-run the specialized primal constructor.
3. Implement and dry-run an orbit-aggregated Lagrangian/matching lower bound.
4. Implement and dry-run either threshold SAT with checkable proof or propagated exact enumeration, depending on whether the audit reveals an exact finite reduction.
5. Scale successful methods, including at least one 1,800-second run, until successful custom runtime totals at least 3,600 seconds.
6. Consider post-baseline direct solver time only after all custom gates are met and only when a precise residual proof or incumbent-validation hypothesis justifies it.

## Tool decision

Python and C++17 are sufficient for parsing, matching, local search, and custom enumeration. Configured CaDiCaL and `drat-trim` are reserved for an exact, independently checkable threshold proof if a sound Boolean reduction is derived. They are not used merely because they are available. No preferred structural optimization library is currently known to be available, so matching and incremental evaluation will be implemented directly. No unrestricted generic MIP solve will be hidden in custom code.

## Pivot conditions

- If the 32 equations do not decompose into two 16-way assignment partitions, abandon permutation-specific neighborhoods and infer the actual equality components before further computation.
- If continuous variables cannot be eliminated by rowwise envelopes for fixed integer decisions, retain them through a specialized feasibility or separation routine rather than using an invalid shortcut.
- If local-search evaluation dominates runtime, group inequalities by continuous variable and update only blocks touched by a move.
- If Lagrangian bounds remain at the trivial domain bound, change the relaxed row family or replace the method with exact propagated search.
- If a threshold CNF cannot preserve the continuous formulation exactly, do not claim a proof; use the exact branch-and-bound candidate instead.