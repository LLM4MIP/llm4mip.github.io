import argparse, gzip, json, math, os, time
from collections import defaultdict


def open_text(path):
    return gzip.open(path, 'rt', errors='replace') if path.lower().endswith('.gz') else open(path, 'r', errors='replace')


def finite_float(s):
    v = float(s.replace('D','E').replace('d','e'))
    if not math.isfinite(v):
        raise ValueError('non-finite numeric token')
    return v


def parse_mps(path):
    section = None
    row_type = {}
    rows = []
    objrow = None
    cols = defaultdict(list)
    costs = defaultdict(float)
    rhs = defaultdict(float)
    lo = defaultdict(lambda: 0.0)
    up = defaultdict(lambda: math.inf)
    vartype = defaultdict(lambda: 'C')
    int_mode = False
    sense = 'MIN'
    obj_const = 0.0
    with open_text(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('*'):
                continue
            tok = line.split()
            head = tok[0].upper()
            if head in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE','OBJNAME'):
                section = head
                if head == 'ENDATA':
                    break
                continue
            if section == 'OBJSENSE':
                if head.startswith('MAX'):
                    sense = 'MAX'
                elif head.startswith('MIN'):
                    sense = 'MIN'
                continue
            if section == 'ROWS':
                if len(tok) < 2:
                    continue
                typ, name = tok[0].upper(), tok[1]
                row_type[name] = typ
                if typ == 'N' and objrow is None:
                    objrow = name
                elif typ in ('L','G','E'):
                    rows.append(name)
                continue
            if section == 'COLUMNS':
                if any('MARKER' in x.upper() for x in tok):
                    joined = ' '.join(tok).upper()
                    if 'INTORG' in joined:
                        int_mode = True
                    elif 'INTEND' in joined:
                        int_mode = False
                    continue
                if len(tok) < 3:
                    continue
                var = tok[0]
                if int_mode:
                    vartype[var] = 'I'
                pairs = tok[1:]
                for k in range(0, len(pairs)-1, 2):
                    rn, val = pairs[k], finite_float(pairs[k+1])
                    if rn == objrow:
                        costs[var] += val
                    elif rn in row_type and row_type[rn] in ('L','G','E'):
                        cols[var].append((rn,val))
                continue
            if section == 'RHS':
                if len(tok) < 3:
                    continue
                pairs = tok[1:]
                for k in range(0, len(pairs)-1, 2):
                    rn, val = pairs[k], finite_float(pairs[k+1])
                    if rn == objrow:
                        obj_const = val
                    elif rn in row_type:
                        rhs[rn] = val
                continue
            if section == 'RANGES':
                raise ValueError('RANGES are not supported by this validity-preserving implementation')
            if section == 'BOUNDS':
                if len(tok) < 3:
                    continue
                bt, var = tok[0].upper(), tok[2]
                val = finite_float(tok[3]) if len(tok) > 3 else 0.0
                if bt == 'LO': lo[var] = val
                elif bt == 'UP': up[var] = val
                elif bt == 'FX': lo[var] = val; up[var] = val
                elif bt == 'FR': lo[var] = -math.inf; up[var] = math.inf
                elif bt == 'MI': lo[var] = -math.inf
                elif bt == 'PL': up[var] = math.inf
                elif bt == 'BV': lo[var] = 0.0; up[var] = 1.0; vartype[var] = 'B'
                elif bt == 'LI': lo[var] = val; vartype[var] = 'I'
                elif bt == 'UI': up[var] = val; vartype[var] = 'I'
                elif bt == 'SC': up[var] = val
                continue
    variables = sorted(set(costs) | set(cols) | set(lo) | set(up) | set(vartype))
    if not rows or not variables or objrow is None:
        raise ValueError('model does not appear to be a supported MPS instance')
    if sense == 'MAX':
        for v in variables:
            costs[v] = -costs[v]
        obj_const = -obj_const
    rid = {r:i for i,r in enumerate(rows)}
    sparse = []
    for v in variables:
        sparse.append([(rid[r],a) for r,a in cols[v]])
    return variables, rows, [row_type[r] for r in rows], [rhs[r] for r in rows], [costs[v] for v in variables], sparse, [lo[v] for v in variables], [up[v] for v in variables], [vartype[v] for v in variables], obj_const, sense


def clamp(v, limit=1e100):
    if not math.isfinite(v):
        return math.copysign(limit, v) if not math.isnan(v) else 0.0
    return max(-limit, min(limit, v))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--runtime', type=float, default=100.0)
    ap.add_argument('--seed', type=int, default=17)
    ap.add_argument('--eta', type=float, default=8.0)
    ap.add_argument('--target-bound', type=float, default=39621.99960377)
    args = ap.parse_args()
    started = time.monotonic()
    out = {'status':'error','algorithm_family':'all-row Lagrangian box relaxation with projected AdaGrad','algorithm_role':'dual_bound','hypothesis':'Dualizing every structural row leaves an exactly solvable variable-wise box relaxation, while guarded projected subgradient ascent can reproduce or strengthen the incumbent global lower bound without non-finite arithmetic.','work_units':1,'termination_reason':'initialization_error','target_bound':args.target_bound,'seed':args.seed,'requested_runtime_seconds':args.runtime,'acceptance_criterion':'accept only a finite Lagrangian value exceeding the previous best by at least 1e-8','pivot_condition':'after 250 nonimproving iterations reduce the step scale by 30 percent; stop scaling this method if the dry run has no finite bound or no multiplier movement'}
    trace = []
    try:
        variables, rows, typ, b, c, col, lower, upper, vtype, obj_const, original_sense = parse_mps(args.model)
        n, m = len(variables), len(rows)
        mult = [0.0]*m
        acc = [1e-18]*m
        best = -math.inf
        best_iter = 0
        iterations = 0
        coefficient_visits = 0
        multiplier_updates = 0
        plateau = 0
        eta = args.eta
        deadline = started + max(0.1,args.runtime)
        while time.monotonic() < deadline:
            iterations += 1
            rc = c[:]
            constant = obj_const
            for i in range(m):
                u = mult[i]
                if typ[i] == 'G':
                    constant += u*b[i]
                else:
                    constant -= u*b[i]
            activity = [0.0]*m
            value = constant
            unbounded = False
            for j in range(n):
                q = rc[j]
                for i,a in col[j]:
                    if typ[i] == 'G': q -= mult[i]*a
                    else: q += mult[i]*a
                    coefficient_visits += 1
                q = clamp(q)
                lj, uj = lower[j], upper[j]
                if q > 0.0:
                    if not math.isfinite(lj): unbounded = True; break
                    x = lj
                elif q < 0.0:
                    if not math.isfinite(uj): unbounded = True; break
                    x = uj
                else:
                    x = 0.0 if lj <= 0.0 <= uj else lj
                if vtype[j] in ('I','B'):
                    x = math.ceil(x-1e-12) if q > 0 else math.floor(x+1e-12) if q < 0 else round(x)
                value += q*x
                for i,a in col[j]:
                    activity[i] += a*x
            if unbounded or not math.isfinite(value):
                plateau += 1
            else:
                guarded = value - 1e-8*(1.0+abs(value))
                if guarded > best:
                    best = guarded; best_iter = iterations; plateau = 0
                else:
                    plateau += 1
                for i in range(m):
                    if typ[i] == 'G': g = b[i]-activity[i]
                    else: g = activity[i]-b[i]
                    g = clamp(g,1e50)
                    acc[i] = min(1e100, acc[i] + min(1e100,g*g))
                    step = eta*g/math.sqrt(acc[i])
                    old = mult[i]
                    nv = clamp(old+step,1e50)
                    if typ[i] in ('G','L') and nv < 0.0: nv = 0.0
                    mult[i] = nv
                    if nv != old: multiplier_updates += 1
            if plateau >= 250:
                eta = max(1e-6,eta*0.7); plateau = 0
            if iterations == 1 or iterations % 100 == 0:
                trace.append({'iteration':iterations,'best_bound':best if math.isfinite(best) else None,'eta':eta,'updates':multiplier_updates,'elapsed':time.monotonic()-started})
        elapsed = time.monotonic()-started
        if not math.isfinite(best):
            out.update(status='no_finite_bound',work_units=max(1,coefficient_visits),termination_reason='runtime_completed_but_every_box_subproblem_was_unbounded',iterations=iterations,multiplier_updates=multiplier_updates,variables=n,rows=m,elapsed_seconds=elapsed)
        else:
            reported = best if original_sense == 'MIN' else -best
            out.update(status='success',work_units=max(1,coefficient_visits),termination_reason='deterministic_runtime_budget_exhausted_after_domain_safe_updates',best_bound=reported,internal_minimization_bound=best,objective_sense=original_sense,iterations=iterations,best_iteration=best_iter,multiplier_updates=multiplier_updates,variables=n,rows=m,elapsed_seconds=elapsed,finite_arithmetic_guard=True)
    except Exception as e:
        out.update(status='error',work_units=max(1,out.get('work_units',1)),termination_reason='caught_parse_or_representation_error',diagnostic=type(e).__name__+': '+str(e),elapsed_seconds=time.monotonic()-started)
    with open('lagrangian_trace.json','w') as f: json.dump(trace,f,indent=2)
    with open('method_result.json','w') as f: json.dump(out,f,indent=2)

if __name__ == '__main__':
    main()
