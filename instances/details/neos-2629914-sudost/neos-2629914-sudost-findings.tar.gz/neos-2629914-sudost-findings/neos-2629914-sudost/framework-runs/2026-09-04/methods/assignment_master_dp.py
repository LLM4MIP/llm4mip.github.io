import argparse, json, math, os, time


def parse_mps(path):
    section = None
    sense = 'MIN'
    row_type = {}
    objrow = None
    rhs = {}
    coeff = {}
    obj = {}
    lb = {}
    ub = {}
    integer = set()
    columns = []
    seen_cols = set()
    int_mode = False
    with open(path, 'r', errors='replace') as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('*'):
                continue
            tok = line.split()
            head = tok[0].upper()
            if head in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE','OBJNAME'):
                section = head
                if head == 'ENDATA':
                    break
                continue
            if section == 'OBJSENSE':
                if head.startswith('MAX'):
                    sense = 'MAX'
                elif head.startswith('MIN'):
                    sense = 'MIN'
            elif section == 'ROWS':
                if len(tok) >= 2:
                    typ, name = tok[0].upper(), tok[1]
                    row_type[name] = typ
                    if typ == 'N' and objrow is None:
                        objrow = name
            elif section == 'COLUMNS':
                if len(tok) >= 2 and ('MARKER' in raw.upper() or tok[1].strip("'").upper() == 'MARKER'):
                    u = raw.upper()
                    if 'INTORG' in u:
                        int_mode = True
                    elif 'INTEND' in u:
                        int_mode = False
                    continue
                var = tok[0]
                if var not in seen_cols:
                    seen_cols.add(var); columns.append(var)
                if int_mode:
                    integer.add(var)
                pairs = tok[1:]
                for k in range(0, len(pairs)-1, 2):
                    r = pairs[k]
                    try: val = float(pairs[k+1].replace('D','E').replace('d','e'))
                    except Exception: continue
                    if r == objrow:
                        obj[var] = obj.get(var, 0.0) + val
                    else:
                        coeff.setdefault(r, {})[var] = coeff.setdefault(r, {}).get(var, 0.0) + val
            elif section == 'RHS':
                pairs = tok[1:]
                for k in range(0, len(pairs)-1, 2):
                    try: rhs[pairs[k]] = float(pairs[k+1].replace('D','E').replace('d','e'))
                    except Exception: pass
            elif section == 'RANGES':
                raise RuntimeError('RANGES are present; this dry implementation deliberately rejects them.')
            elif section == 'BOUNDS':
                if len(tok) < 3: continue
                typ = tok[0].upper(); var = tok[2]
                val = 0.0
                if len(tok) >= 4:
                    val = float(tok[3].replace('D','E').replace('d','e'))
                if typ == 'LO': lb[var] = val
                elif typ == 'UP': ub[var] = val
                elif typ == 'FX': lb[var] = val; ub[var] = val
                elif typ == 'FR': lb[var] = -math.inf; ub[var] = math.inf
                elif typ == 'MI': lb[var] = -math.inf
                elif typ == 'PL': ub[var] = math.inf
                elif typ == 'BV': lb[var] = 0.0; ub[var] = 1.0; integer.add(var)
                elif typ == 'LI': lb[var] = val; integer.add(var)
                elif typ == 'UI': ub[var] = val; integer.add(var)
    for v in columns:
        lb.setdefault(v, 0.0)
        ub.setdefault(v, math.inf)
    return sense, row_type, rhs, coeff, obj, lb, ub, integer, columns, objrow


def solve_dp(cost):
    n = len(cost)
    size = 1 << n
    inf = float('inf')
    dp = [inf] * size
    parent_mask = [-1] * size
    parent_col = [-1] * size
    dp[0] = 0.0
    transitions = 0
    for mask in range(size):
        i = mask.bit_count()
        if i >= n or not math.isfinite(dp[mask]):
            continue
        for j in range(n):
            if not (mask >> j) & 1 and math.isfinite(cost[i][j]):
                transitions += 1
                nm = mask | (1 << j)
                nv = dp[mask] + cost[i][j]
                if nv < dp[nm] - 1e-12:
                    dp[nm] = nv; parent_mask[nm] = mask; parent_col[nm] = j
    full = size - 1
    if not math.isfinite(dp[full]):
        return None, None, transitions
    chosen = []
    m = full
    while m:
        j = parent_col[m]; pm = parent_mask[m]
        i = pm.bit_count()
        chosen.append((i,j)); m = pm
    chosen.reverse()
    return dp[full], chosen, transitions


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--seed', type=int, default=0)
    ap.add_argument('--expected-size', type=int, default=16)
    args = ap.parse_args()
    started = time.time()
    status = 'failed'
    accepted = False
    termination = ''
    work = 1
    candidate = None
    cert = {'certificate_type':'exact subset-DP solution of a projected assignment relaxation'}
    try:
        sense, rtype, rhs, A, c_orig, lb, ub, integer, cols, objrow = parse_mps(args.model)
        sign = 1.0 if sense == 'MIN' else -1.0
        c = {v: sign*c_orig.get(v,0.0) for v in cols}
        if abs(rhs.get(objrow, 0.0)) > 1e-12:
            raise RuntimeError('Nonzero objective-row RHS offset is unsupported in this validation run.')
        eligible = []
        for r,t in rtype.items():
            if t != 'E' or abs(rhs.get(r,0.0)-1.0) > 1e-9 or r not in A:
                continue
            ok = True
            for v,a in A[r].items():
                if abs(a-1.0) > 1e-9 or v not in integer or abs(lb.get(v,0.0)) > 1e-9 or abs(ub.get(v,math.inf)-1.0) > 1e-9:
                    ok = False; break
            if ok and A[r]: eligible.append(r)
        eset = set(eligible)
        incid = {}
        for r in eligible:
            for v in A[r]: incid.setdefault(v, []).append(r)
        graph = {r:set() for r in eligible}
        edgevars = {}
        for v,rs in incid.items():
            if len(rs)==2 and rs[0] != rs[1]:
                a,b=rs; graph[a].add(b); graph[b].add(a); edgevars.setdefault(tuple(sorted((a,b))), []).append(v)
        comps=[]; unseen=set(eligible)
        while unseen:
            root=next(iter(unseen)); stack=[root]; unseen.remove(root); comp=[]
            while stack:
                x=stack.pop(); comp.append(x)
                for y in graph[x]:
                    if y in unseen: unseen.remove(y); stack.append(y)
            comps.append(comp)
        target = 2*args.expected_size
        candidates=[]
        for comp in comps:
            if len(comp)!=target: continue
            color={comp[0]:0}; stack=[comp[0]]; bip=True
            while stack and bip:
                x=stack.pop()
                for y in graph[x]:
                    if y not in set(comp): continue
                    if y not in color: color[y]=1-color[x]; stack.append(y)
                    elif color[y]==color[x]: bip=False; break
            left=sorted([r for r in comp if color.get(r)==0]); right=sorted([r for r in comp if color.get(r)==1])
            if bip and len(left)==args.expected_size and len(right)==args.expected_size:
                candidates.append((left,right))
        if len(candidates)!=1:
            raise RuntimeError('Expected exactly one unambiguous 16-by-16 bipartite assignment component; found %d.' % len(candidates))
        left,right=candidates[0]; li=set(left); ri=set(right)
        component=set(left+right)
        component_vars=set()
        for r in component: component_vars.update(A[r])
        for v in component_vars:
            rows=[r for r in incid.get(v,[]) if r in component]
            if len(rows)!=2 or not ((rows[0] in li and rows[1] in ri) or (rows[1] in li and rows[0] in ri)):
                raise RuntimeError('An assignment-row variable does not join exactly one row on each side: '+v)
        base=0.0
        for v in cols:
            if v in component_vars: continue
            cv=c.get(v,0.0); lo=lb[v]; hi=ub[v]
            if cv >= 0:
                if not math.isfinite(lo): raise RuntimeError('Finite domain infimum unavailable for '+v)
                base += cv*lo
            else:
                if not math.isfinite(hi): raise RuntimeError('Finite domain infimum unavailable for '+v)
                base += cv*hi
        n=len(left); matrix=[[math.inf]*n for _ in range(n)]; choice=[[None]*n for _ in range(n)]
        rpos={r:i for i,r in enumerate(right)}
        for i,lrow in enumerate(left):
            for v in A[lrow]:
                rs=incid[v]
                rr=rs[0] if rs[1]==lrow else rs[1]
                if rr not in rpos: continue
                j=rpos[rr]; cv=c.get(v,0.0)
                if cv < matrix[i][j]: matrix[i][j]=cv; choice[i][j]=v
        match_cost, pairs, transitions=solve_dp(matrix)
        work = max(1, transitions + sum(len(A[r]) for r in component))
        if match_cost is None: raise RuntimeError('Projected assignment graph has no perfect matching.')
        transformed=base+match_cost
        candidate=transformed if sense=='MIN' else -transformed
        selected=[]
        recompute=base
        for i,j in pairs:
            v=choice[i][j]; recompute += c.get(v,0.0)
            selected.append({'left_row':left[i],'right_row':right[j],'variable':v,'transformed_cost':c.get(v,0.0)})
        if abs(recompute-transformed) > 1e-7*max(1.0,abs(transformed)):
            raise RuntimeError('Certificate recomputation mismatch.')
        cert.update({'objective_sense':sense,'left_rows':left,'right_rows':right,'nonassignment_box_infimum_transformed':base,'matching_cost_transformed':match_cost,'candidate_global_dual_bound':candidate,'selected_edges':selected,'validation_conditions':{'all_assignment_rows_are_equalities_with_rhs_one':True,'all_assignment_coefficients_are_one':True,'all_assignment_variables_are_binary':True,'each_assignment_variable_joins_one_row_per_side':True,'perfect_matching_recomputed':True},'relaxation_statement':'All original constraints except the displayed assignment equations and variable domains are dropped. Therefore the optimum is a globally valid dual bound for the original model.'})
        accepted=True; status='success'; termination='Completed exact subset dynamic programming over all assignment states and reconstructed an optimal perfect matching certificate.'
    except Exception as e:
        termination='Validation rejected: '+str(e)
        cert['error']=str(e)
    with open('assignment_bound.json','w') as f: json.dump(cert,f,indent=2,sort_keys=True)
    result={'status':status,'accepted':accepted,'algorithm_family':'exact projected assignment-master relaxation by subset dynamic programming','algorithm_role':'dual_bound','hypothesis':'The audited 32 equations form one exact 16-by-16 bipartite assignment master whose integer optimum strengthens or independently validates the domain-only global bound.','target_bound':'Improve or independently substantiate the experiment candidate dual bound 39622.0; compare with the public dual target recorded in background.md.','candidate_dual_bound':candidate,'work_units':work,'work_unit_name':'DP transitions plus assignment incidences validated','termination_reason':termination,'seed':args.seed,'requested_runtime_seconds':120,'runtime_seconds':time.time()-started,'acceptance_criterion':'Accept only one unambiguous 16-by-16 binary assignment component, finite residual box infimum, a complete perfect matching, and exact certificate recomputation.','pivot_condition':'If the assignment objective is flat or the signature is rejected, pivot to constraint-aware Lagrangian relaxation rather than enlarging this exact but weak projection.','artifacts':['assignment_bound.json']}
    with open('method_result.json','w') as f: json.dump(result,f,indent=2,sort_keys=True)

if __name__=='__main__': main()
