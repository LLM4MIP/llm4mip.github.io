# Final report: neos-2629914-sudost

## Outcome

This experiment ended with **unknown status** and is therefore a partial, bound-oriented result rather than a solution of the instance.

- Objective sense: minimization.
- Verified primal bound: none.
- Best reported dual value: `39621.99960377`.
- Verification state of that dual value: **not checked**.
- Relative gap: unavailable because there is no verified incumbent.
- Strict optimality proof: none.
- Strict infeasibility proof: none.
- Independently checked certificate: none.

The value `39621.99960377` was reported by two custom-Python runs. It must not be described as an independently certified global dual bound: the controller ledger marks verification as `not checked`, and a custom method's assertion alone is not a proof. No run returned strict solver status proving optimality or infeasibility.

## Public-target and baseline comparison

The background material available for this archive did not establish a safely usable, sourced numeric public primal or public dual comparator. Consequently:

- no improvement to a public primal bound is claimed;
- no improvement to a sourced public dual bound is claimed;
- no public-record claim is made;
- no public gap reduction can be quantified;
- a public dual record is specifically **not inferred** in the absence of a documented prior public dual value.

The final experiment ledger contains no successful generic Gurobi or COPT run and no generic-solver primal or dual baseline. Its `solvers_used` list contains only `custom-python`. Thus the custom dual value cannot be compared numerically with a short internal generic-solver baseline. It is the only numerical bound reported during the recorded experiment, but, because it is unchecked and lacks a numeric baseline comparator, this report classifies the outcome as **no demonstrated numerical improvement against a verified or sourced target**. It is nevertheless useful experiment-internal dual information for a future checked run.

## Problem classification and decisive structure

The supplied model is a linear mixed-integer minimization problem with:

- 496 variables;
- 256 bounded integer variables, all with bounds `[0,1]` and zero objective coefficients;
- 240 continuous variables with finite positive lower bounds;
- 51,872 linear constraints, comprising 32 equalities and 51,840 greater-than inequalities;
- 209,792 matrix nonzeros;
- no quadratic, SOS, or general constraints;
- nonzero objective coefficients only on the 240 continuous variables, ranging from 11 to 19;
- integral matrix coefficients ranging from -224 to 213.

The decisive feature is the separation between a moderate zero-cost binary decision block and an objective-bearing continuous block, coupled through a very large inequality family. That structure motivates decomposition, projection, relaxation-based dual bounding, and specialized feasibility recovery more strongly than blind parameter tuning.

Model identity recorded in `background.md`:

- model fingerprint: `-1863754863`;
- uncompressed model SHA-256: `9ecc76582a0fd3e28bd5c0064ec91edc9daa00ae13b3a92130cfeaa1575cf8d9`.

## Methods considered

The algorithm-design comparison considered the following standard approaches:

1. Generic branch-and-cut as a short diagnostic baseline.
2. LP/continuous-relaxation and decomposition-style dual bounding exploiting the binary/continuous block structure.
3. Problem-specific primal construction or repair for the 256 bounded integer decisions followed by continuous completion.
4. A proof-oriented route in which a candidate combinatorial conclusion would need an independently checkable SAT/DRAT or strict MIP-solver certificate.

The final ledger records only custom-Python executions. It does not record a completed direct generic-solver run, a feasible solution, or an independently checked certificate. The observed pivot was therefore from quick structural/prototype executions to approximately 100-second custom bound/proof-oriented runs. Two of those longer runs reproduced the same candidate dual value; a later scaled run completed without reporting a bound.

## Execution ledger

| Run | Status | Runtime (s) | Primal | Dual | Verification |
|---|---:|---:|---:|---:|---|
| `custom-20260904-232141-664bb9fd` | success | 1.436697 | — | — | not checked |
| `custom-20260904-232323-148ad30a` | failed | 0.730626 | — | — | not checked |
| `custom-20260904-232439-aa4d53c6` | success | 0.831063 | — | — | not checked |
| `custom-20260904-232622-a41f4c5c` | success | 106.001661 | — | 39621.99960377 | not checked |
| `custom-20260904-233001-f15114db` | ERROR | 0.730222 | — | — | not checked |
| `custom-20260904-233504-8f8ac766` | success | 100.103341 | — | 39621.99960377 | not checked |
| `custom-20260904-233734-a82777f0` | ERROR | 0.730218 | — | — | not checked |
| `custom-20260904-233904-f695e493` | ERROR | 0.680137 | — | — | not checked |
| `custom-20260904-234040-cca275d4` | success | 105.103804 | — | — | not checked |

Termination totals:

- 9 custom executions;
- 5 with status `success`;
- 1 with status `failed`;
- 3 with status `ERROR`;
- 0 strict optimal runs;
- 0 strict infeasible runs.

A `success` status here means that the custom program completed according to its own run protocol. It does not prove feasibility, optimality, infeasibility, or validity of a bound.

## Algorithm revisions, negative results, and pivots

The two initial sub-two-second successes produced no numerical bound. The intervening short failed run also produced no result. The first scaled run then reported the candidate dual value `39621.99960377`. A subsequent immediate experiment ended with `ERROR`, after which another scaled execution reproduced the same dual value. Two more short executions ended with `ERROR`. The final scaled execution succeeded operationally but produced neither a primal nor a dual value.

The compressed reporting summary does not contain exception messages, so it would be speculative to assign a more specific cause to the failed and `ERROR` runs. The safe diagnosis is that these executions supplied no usable numerical output. Repetition of the dual value is useful evidence of implementation stability, but it is not independent certification when both values come from the same custom-method environment.

The most informative negative result is that none of the specialized executions constructed a tolerance-verified incumbent, and the proof-oriented work did not produce a checkable certificate. Therefore no gap could be opened or closed around the candidate dual value.

## Runtime accounting

Recorded custom-algorithm runtime totals:

`1.4366965293884277 + 0.730625629425049 + 0.831063032150269 + 106.001661062241 + 0.730222463607788 + 100.103341341019 + 0.730217933654785 + 0.680137157440186 + 105.103804349899 = 316.3477694988255 seconds`.

Rounded accounting:

- custom-algorithm runtime: **316.348 seconds**;
- direct Gurobi/COPT runtime recorded in the final ledger: **0 seconds**;
- total recorded experimental compute: **316.348 seconds**;
- custom share: **100.0%**;
- direct-solver share: **0.0%**;
- longest successful scaled custom run: **106.002 seconds**.

There were at least three approximately 100-second scaled executions, all operationally successful. The ledger provides five successful executions overall. The compressed reporting material does not expose a normalized distinct-method identifier, so the number of genuinely distinct algorithm implementations cannot be established without inventing metadata; it is recorded conservatively as **not confirmed**, rather than equating every revision with a distinct method. For the same reason, not every algorithm-first gate can be certified from the reporting summary. The scaled-runtime and custom-first aspects are visibly met, while the distinct-method gate is **not confirmed**.

## Machines, software, parameters, and reproducibility

- Execution type: controller-managed, CPU-only custom sandbox.
- Custom implementation language: Python.
- Direct solvers appearing in the final ledger: none.
- Trusted tools configured for the environment: CaDiCaL and `drat-trim`; no independently checked certificate from either tool is recorded.
- Host machine model, CPU model, operating-system build, Python version, CaDiCaL version, and `drat-trim` version: not supplied in the compressed reporting bundle and therefore not invented here.
- Custom source filenames: not exposed by the compressed reporting bundle or `experiments.md`; authoritative run manifests and controller artifacts should be retained with the archive. No filename is invented in this report.
- Recorded parameter dictionaries: empty for the listed custom runs.
- Random seeds: none reported.
- Threads: controller-enforced; numeric limit not reported in the compressed summary.
- Sandbox limits: CPU-only, no network, read-only mounted model/source/tool inputs, private writable output, and controller-enforced runtime, memory, file-size, and thread limits. Numeric memory/file-size limits were not present in the compressed reporting material.

These omissions limit exact external reproduction and should be remedied in a follow-up by preserving the source-path, Python-version, machine, seed, and resource-limit fields directly in each method result.

## Correct interpretation of status

No time-limited, failed, or error run is interpreted as infeasible. No custom success is interpreted as optimal. No solver-accepted solution exists to compare with tolerance-based independent verification. The final status remains `unknown`.

## Recommended next experiment

The next permitted research cycle should prioritize a checked primal/dual pairing rather than another unchecked repetition:

1. Preserve and isolate the dual construction that produced `39621.99960377`.
2. Emit its mathematical multipliers or equivalent witness and verify all sign, normalization, and residual conditions independently using exact rational arithmetic or directed rounding.
3. In parallel, exploit the 256 bounded zero-cost integer variables with a dedicated feasibility/repair search, then solve or analytically complete the 240 continuous variables.
4. If a candidate incumbent is found, verify every original constraint and integrality condition using the controller's tolerance-independent checker.
5. If a combinatorial proof is encoded to SAT, emit a DRAT certificate and check it with `drat-trim`; otherwise require strict status from a controlled MIP solver.

Until one of those checks succeeds, `39621.99960377` should remain labeled an uncertified experiment-internal dual result.