import argparse, json, math, os, random, time

INF = float('inf')

def fnum(s):
    return float(s.replace('D','E').replace('d','e'))

def parse_mps(path):
    section = None
    sense = 'MIN'
    row_type = {}
    objrow = None
    cols = {}
    rhs = {}
    ranges = {}
    bounds = {}
    integer = set()
    int_mode = False
    with open(path, 'r', errors='replace') as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line.startswith('*'):
                continue
            t = line.split()
            key = t[0].upper()
            if key in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE','OBJNAME'):
                section = key
                if key == 'ENDATA': break
                continue
            if section == 'OBJSENSE':
                sense = key
            elif section == 'ROWS':
                if len(t) < 2: continue
                typ, name = t[0].upper(), t[1]
                row_type[name] = typ
                if typ == 'N' and objrow is None: objrow = name
            elif section == 'COLUMNS':
                if len(t) >= 3 and t[1].strip("'").upper() == 'MARKER':
                    mark = t[2].strip("'").upper()
                    int_mode = (mark == 'INTORG')
                    continue
                v = t[0]
                if int_mode: integer.add(v)
                d = cols.setdefault(v, {})
                k = 1
                while k + 1 < len(t):
                    r, val = t[k], fnum(t[k+1])
                    d[r] = d.get(r, 0.0) + val
                    k += 2
            elif section == 'RHS':
                k = 1
                while k + 1 < len(t):
                    rhs[t[k]] = fnum(t[k+1]); k += 2
            elif section == 'RANGES':
                k = 1
                while k + 1 < len(t):
                    ranges[t[k]] = fnum(t[k+1]); k += 2
            elif section == 'BOUNDS':
                if len(t) < 3: continue
                typ, v = t[0].upper(), t[2]
                val = fnum(t[3]) if len(t) > 3 else 0.0
                lo, up = bounds.get(v, (0.0, INF))
                if typ == 'LO': lo = val
                elif typ == 'UP': up = val
                elif typ == 'FX': lo = up = val
                elif typ == 'FR': lo, up = -INF, INF
                elif typ == 'MI': lo = -INF
                elif typ == 'PL': up = INF
                elif typ == 'BV': lo, up = 0.0, 1.0; integer.add(v)
                elif typ == 'LI': lo = val; integer.add(v)
                elif typ == 'UI': up = val; integer.add(v)
                bounds[v] = (lo, up)
    if sense.startswith('MAX'):
        raise ValueError('This implementation targets the measured minimization instance')
    names = list(cols.keys())
    idx = {v:i for i,v in enumerate(names)}
    n = len(names)
    c = [0.0]*n
    lo = [0.0]*n
    up = [INF]*n
    isint = [False]*n
    rowcoef = {r:{} for r,t in row_type.items() if t != 'N'}
    for v, entries in cols.items():
        j = idx[v]
        if objrow in entries: c[j] = entries[objrow]
        if v in bounds: lo[j], up[j] = bounds[v]
        isint[j] = v in integer
        for r,a in entries.items():
            if r in rowcoef and a != 0.0: rowcoef[r][j] = a
    constraints = []
    for r, a in rowcoef.items():
        typ = row_type[r]
        b = rhs.get(r, 0.0)
        rg = ranges.get(r)
        if rg is None:
            constraints.append((typ, a, b, r))
        elif typ == 'L':
            constraints.append(('L',a,b,r+':upper'))
            constraints.append(('G',a,b-abs(rg),r+':lower'))
        elif typ == 'G':
            constraints.append(('G',a,b,r+':lower'))
            constraints.append(('L',a,b+abs(rg),r+':upper'))
        elif typ == 'E':
            if rg >= 0:
                constraints.append(('G',a,b,r+':lower')); constraints.append(('L',a,b+rg,r+':upper'))
            else:
                constraints.append(('G',a,b+rg,r+':lower')); constraints.append(('L',a,b,r+':upper'))
    return names,c,lo,up,isint,constraints

def propagate(lo, up, isint, cons, passes=40):
    changes = 0
    inequalities = []
    for typ,a,b,name in cons:
        if typ in ('L','E'): inequalities.append((a,b,name))
        if typ in ('G','E'): inequalities.append(({j:-v for j,v in a.items()},-b,name))
    for _ in range(passes):
        changed = False
        for a,b,name in inequalities:
            min_terms = {}
            finite_sum = 0.0
            bad = 0
            for j,v in a.items():
                endpoint = lo[j] if v >= 0 else up[j]
                if math.isfinite(endpoint):
                    z = v*endpoint; min_terms[j]=z; finite_sum += z
                else:
                    min_terms[j]=None; bad += 1
            for j,v in a.items():
                other_bad = bad - (1 if min_terms[j] is None else 0)
                if other_bad: continue
                other = finite_sum - (min_terms[j] if min_terms[j] is not None else 0.0)
                val = (b-other)/v
                if v > 0 and val < up[j]-1e-10:
                    if isint[j]: val = math.floor(val+1e-10)
                    up[j]=val; changed=True; changes += 1
                elif v < 0 and val > lo[j]+1e-10:
                    if isint[j]: val = math.ceil(val-1e-10)
                    lo[j]=val; changed=True; changes += 1
        if not changed: break
    for j in range(len(lo)):
        if lo[j] > up[j] + 1e-8:
            raise ValueError('Safe propagation detected inconsistent variable bounds')
    return changes

def oracle(c,lo,up,isint,cons,mult):
    n=len(c); d=c[:]; const=0.0
    for i,(typ,a,b,name) in enumerate(cons):
        y=mult[i]
        if typ=='L': s=1.0
        elif typ=='G': s=-1.0
        else: s=1.0
        const -= y*s*b
        for j,v in a.items(): d[j] += y*s*v
    x=[0.0]*n; val=const
    scale=max(1.0,max((abs(z) for z in d),default=1.0))
    tol=2e-11*scale
    for j,z in enumerate(d):
        l,u=lo[j],up[j]
        if isint[j]:
            if math.isfinite(l): l=math.ceil(l-1e-10)
            if math.isfinite(u): u=math.floor(u+1e-10)
        if z > tol:
            if not math.isfinite(l): return None
            xx=l
        elif z < -tol:
            if not math.isfinite(u): return None
            xx=u
        else:
            if math.isfinite(l) and math.isfinite(u): xx=min(max(0.0,l),u)
            elif math.isfinite(l): xx=l
            elif math.isfinite(u): xx=u
            else: xx=0.0
        x[j]=xx; val += z*xx
    g=[]
    for typ,a,b,name in cons:
        act=sum(v*x[j] for j,v in a.items())
        if typ=='L': g.append(act-b)
        elif typ=='G': g.append(b-act)
        else: g.append(act-b)
    return val,x,g,d

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--model',required=True)
    ap.add_argument('--seed',type=int,default=17)
    ap.add_argument('--run-seconds',type=float,default=1820.0)
    ap.add_argument('--target',type=float,default=39622.0)
    args=ap.parse_args()
    rng=random.Random(args.seed)
    names,c,lo,up,isint,cons=parse_mps(args.model)
    propagation_changes=propagate(lo,up,isint,cons)
    m=len(cons)
    mult=[0.0]*m
    current=oracle(c,lo,up,isint,cons,mult)
    # If zero multipliers do not bound the relaxation, seek a reduced-cost-feasible point
    # by deterministic small projected trials; no invalid value is ever accepted.
    phase_trials=0
    if current is None:
        for scale in (1e-6,1e-5,1e-4,1e-3,1e-2,1e-1,1.0,10.0,100.0):
            for _ in range(2000):
                phase_trials += 1
                trial=[]
                for typ,a,b,name in cons:
                    z=(rng.random()*scale)
                    if typ=='E': z=(2*rng.random()-1)*scale
                    trial.append(z)
                q=oracle(c,lo,up,isint,cons,trial)
                if q is not None:
                    mult=trial; current=q; break
            if current is not None: break
    if current is None:
        result={'status':'unsupported','algorithm_family':'domain-safe Lagrangian relaxation','algorithm_role':'dual_bound','hypothesis':'Reduced-cost feasibility can replace invalid finite box truncation.','work_units':max(1,phase_trials),'termination_reason':'no reduced-cost-feasible multiplier found in deterministic phase I','target_bound':args.target,'seed':args.seed,'runtime_seconds':0.0,'acceptance_criterion':'accept only bounded separable relaxations','pivot_condition':'phase-I multiplier search after unbounded oracle'}
        json.dump(result,open('method_result.json','w'),indent=2); return
    start=time.monotonic(); deadline=start+args.run_seconds
    best=current[0]; best_mult=mult[:]; accepted=0; rejected=0; it=0; stalls=0
    trace=[]
    while time.monotonic() < deadline:
        it += 1
        q,x,g,d=current
        if q > best:
            best=q; best_mult=mult[:]; stalls=0
        else: stalls += 1
        norm=sum(z*z for z in g)
        if norm <= 1e-30:
            break
        alpha=max(0.015,1.7/math.sqrt(1.0+it/2500.0))
        numerator=max(1.0,args.target-q)
        step=min(10.0,alpha*numerator/norm)
        if stalls>25000: step*=0.15
        direction=g[:]
        if stalls>8000 and it%97==0:
            for k in range(m): direction[k] += (rng.random()-0.5)*0.02*max(1.0,abs(g[k]))
        found=None
        local_step=step
        for bt in range(45):
            trial=[]
            for k,(typ,a,b,name) in enumerate(cons):
                z=mult[k]+local_step*direction[k]
                if typ!='E' and z<0.0: z=0.0
                trial.append(z)
            cand=oracle(c,lo,up,isint,cons,trial)
            if cand is not None:
                found=(trial,cand); break
            local_step*=0.5
        if found is None:
            rejected += 1
            # A coordinate pivot can move along the boundary when the full subgradient cannot.
            order=sorted(range(m),key=lambda k:abs(g[k]),reverse=True)[:min(32,m)]
            for k in order:
                trial=mult[:]
                trial[k]+=step*g[k]
                if cons[k][0]!='E' and trial[k]<0: trial[k]=0.0
                cand=oracle(c,lo,up,isint,cons,trial)
                if cand is not None: found=(trial,cand); break
        if found is not None:
            mult,current=found; accepted += 1
        if it%20000==0:
            trace.append({'iteration':it,'elapsed':time.monotonic()-start,'best_dual':best,'current_dual':current[0],'accepted':accepted,'rejected':rejected})
            trace=trace[-200:]
    runtime=time.monotonic()-start
    conservative=best-1e-7*max(1.0,abs(best))
    with open('dual_trace.json','w') as f:
        json.dump({'best_raw_dual':best,'best_conservative_dual':conservative,'iterations':it,'accepted':accepted,'rejected':rejected,'propagation_changes':propagation_changes,'phase_trials':phase_trials,'finite_upper_bounds':sum(math.isfinite(v) for v in up),'finite_lower_bounds':sum(math.isfinite(v) for v in lo),'variables':len(names),'constraints':m,'trace':trace},f,indent=2)
    result={'status':'success','algorithm_family':'domain-safe Lagrangian dual ascent with interval propagation and reduced-cost backtracking','algorithm_role':'dual_bound','hypothesis':'The previous box-relaxation failure is repaired by preserving original semi-infinite domains and enforcing reduced-cost boundedness for every accepted multiplier.','work_units':it+phase_trials,'termination_reason':'stationary relaxation reached' if time.monotonic()<deadline else 'time budget reached','target_bound':args.target,'best_bound':conservative,'raw_best_bound':best,'seed':args.seed,'runtime_seconds':runtime,'acceptance_criterion':'A multiplier is accepted only if its separable Lagrangian minimization is bounded on every propagated original variable domain.','pivot_condition':'After full-step reduced-cost infeasibility, halve the step; after persistent boundary rejection, pivot on a largest-violation constraint.','certificate_artifact':'dual_trace.json','numerical_note':'Reported bound is shifted downward by 1e-7 times its objective scale; it is algorithmic dual evidence, not a strict exact certificate.'}
    with open('method_result.json','w') as f: json.dump(result,f,indent=2)

if __name__=='__main__': main()
