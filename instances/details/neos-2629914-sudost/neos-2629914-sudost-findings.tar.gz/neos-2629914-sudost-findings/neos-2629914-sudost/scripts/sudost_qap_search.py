#!/usr/bin/env python3
"""Single-core QAP search and exact validator for neos-2629914-sudost.

The MPS hides a symmetric 16 x 16 quadratic assignment problem behind 240
continuous variables and two redundant families of linearization constraints.
This script extracts the two QAP matrices directly from the MPS, performs
deterministic multi-start 2-swap local search, writes a full Gurobi .sol file,
and checks it against every original MPS row using exact decimal arithmetic.
"""

from __future__ import annotations

import argparse
import gzip
import random
import time
from collections import defaultdict
from decimal import Decimal
from pathlib import Path


N = 16
N_AUX = N * (N - 1)
FIRST_BINARY = N_AUX + 1
TARGET = 48_180


def open_text(path: Path, encoding: str):
    """Open an ordinary or gzip-compressed text file."""
    if path.suffix.lower() == ".gz":
        return gzip.open(path, "rt", encoding=encoding)
    return path.open("r", encoding=encoding)


def number(text: str) -> Decimal:
    """Parse ordinary or Fortran-style MPS numbers exactly."""
    return Decimal(text.replace("D", "E").replace("d", "e"))


def variable_index(name: str) -> int:
    if not (name.startswith("C") and name[1:].isdigit()):
        raise ValueError(f"Unexpected variable name: {name}")
    return int(name[1:])


def row_index(name: str) -> int:
    if not (name.startswith("R") and name[1:].isdigit()):
        raise ValueError(f"Unexpected row name: {name}")
    return int(name[1:])


def ordered_pairs() -> list[tuple[int, int]]:
    return [(i, j) for i in range(N) for j in range(N) if i != j]


def extract_qap(mps_path: Path) -> tuple[list[list[int]], list[list[int]]]:
    """Return symmetric flow and distance matrices encoded by the MPS."""
    section = ""
    objective_row = ""
    objective: dict[str, int] = {}
    group2: dict[str, list[tuple[str, int]]] = defaultdict(list)
    rhs: dict[str, int] = {}

    with open_text(mps_path, "latin-1") as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if tokens[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = tokens[0]
                continue

            if section == "ROWS":
                if tokens[0] == "N":
                    objective_row = tokens[1]
            elif section == "COLUMNS":
                if "'MARKER'" in tokens:
                    continue
                var = tokens[0]
                for row, value_text in zip(tokens[1::2], tokens[2::2]):
                    value = int(number(value_text))
                    if row == objective_row:
                        objective[var] = objective.get(var, 0) + value
                    elif row.startswith("R") and 33 <= row_index(row) <= 232:
                        group2[row].append((var, value))
            elif section == "RHS":
                for row, value_text in zip(tokens[1::2], tokens[2::2]):
                    rhs[row] = rhs.get(row, 0) + int(number(value_text))

    pairs = ordered_pairs()
    flow = [[0] * N for _ in range(N)]
    for k, (i, j) in enumerate(pairs, start=1):
        name = f"C{k:04d}"
        if name not in objective:
            raise ValueError(f"Missing objective coefficient for {name}")
        flow[i][j] = objective[name]

    distance = [[0 if p == q else 11 for q in range(N)] for p in range(N)]
    for rid in range(33, 233):
        row = f"R{rid:04d}"
        d = -rhs[row]
        positions: dict[int, int] = {}
        for var, coefficient in group2[row]:
            idx = variable_index(var)
            if idx < FIRST_BINARY:
                continue
            grid_index = idx - FIRST_BINARY
            grid_row, position = divmod(grid_index, N)
            if coefficient != -d:
                raise ValueError(f"Unexpected coefficient in {row}: {var} {coefficient}")
            positions[grid_row] = position
        if set(positions) != {0, 1}:
            raise ValueError(f"Could not decode distance entry from {row}")
        distance[positions[0]][positions[1]] = d

    if any(flow[i][j] != flow[j][i] for i in range(N) for j in range(N)):
        raise ValueError("Extracted flow matrix is not symmetric")
    if any(distance[i][j] != distance[j][i] for i in range(N) for j in range(N)):
        raise ValueError("Extracted distance matrix is not symmetric")
    return flow, distance


def score(permutation: list[int], flow: list[list[int]], distance: list[list[int]]) -> int:
    return 2 * sum(
        flow[i][j] * distance[permutation[i]][permutation[j]]
        for i in range(N)
        for j in range(i + 1, N)
    )


def swap_delta(
    permutation: list[int], a: int, b: int, flow: list[list[int]], distance: list[list[int]]
) -> int:
    pa, pb = permutation[a], permutation[b]
    delta = 0
    for k in range(N):
        if k == a or k == b:
            continue
        pk = permutation[k]
        delta += 2 * (
            flow[a][k] * (distance[pb][pk] - distance[pa][pk])
            + flow[b][k] * (distance[pa][pk] - distance[pb][pk])
        )
    return delta


def steepest_descent(
    start: list[int], flow: list[list[int]], distance: list[list[int]]
) -> tuple[list[int], int]:
    permutation = start.copy()
    value = score(permutation, flow, distance)
    while True:
        best_delta = 0
        best_swap: tuple[int, int] | None = None
        for a in range(N):
            for b in range(a + 1, N):
                delta = swap_delta(permutation, a, b, flow, distance)
                if delta < best_delta:
                    best_delta = delta
                    best_swap = (a, b)
        if best_swap is None:
            return permutation, value
        a, b = best_swap
        permutation[a], permutation[b] = permutation[b], permutation[a]
        value += best_delta


def read_solution(path: Path) -> dict[str, Decimal]:
    values: dict[str, Decimal] = {}
    with path.open(encoding="utf-8") as handle:
        for raw in handle:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            tokens = line.split()
            if len(tokens) >= 2:
                values[tokens[0]] = number(tokens[1])
    return values


def permutation_from_solution(path: Path) -> list[int]:
    values = read_solution(path)
    permutation: list[int] = []
    for i in range(N):
        selected = [
            p
            for p in range(N)
            if values.get(f"C{FIRST_BINARY + N * i + p:04d}", Decimal(0)) == 1
        ]
        if len(selected) != 1:
            raise ValueError(f"Solution does not select exactly one column in assignment row {i + 1}")
        permutation.append(selected[0])
    if len(set(permutation)) != N:
        raise ValueError("Solution assignment is not a permutation")
    return permutation


def search(
    flow: list[list[int]],
    distance: list[list[int]],
    seconds: float,
    seed: int,
    initial: list[int] | None,
    target: int,
) -> tuple[list[int], int, int]:
    rng = random.Random(seed)
    deadline = time.monotonic() + seconds
    starts: list[list[int]] = []
    if initial is not None:
        starts.append(initial)
    starts.append(list(range(N)))

    best_permutation: list[int] | None = None
    best_value: int | None = None
    restarts = 0
    while time.monotonic() < deadline or not restarts:
        if starts:
            candidate = starts.pop(0)
        else:
            candidate = list(range(N))
            rng.shuffle(candidate)
        local_permutation, local_value = steepest_descent(candidate, flow, distance)
        restarts += 1
        if best_value is None or local_value < best_value:
            best_permutation, best_value = local_permutation, local_value
            print(
                f"restart {restarts}: objective {best_value}, "
                f"permutation {[p + 1 for p in best_permutation]}"
            )
        if best_value <= target:
            break

    assert best_permutation is not None and best_value is not None
    return best_permutation, best_value, restarts


def solution_values(permutation: list[int], distance: list[list[int]]) -> dict[str, int]:
    values: dict[str, int] = {}
    for k, (i, j) in enumerate(ordered_pairs(), start=1):
        values[f"C{k:04d}"] = distance[permutation[i]][permutation[j]]
    for i in range(N):
        for p in range(N):
            values[f"C{FIRST_BINARY + N * i + p:04d}"] = int(permutation[i] == p)
    return values


def write_solution(path: Path, model_name: str, objective: int, values: dict[str, int]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        handle.write(f"# Solution for model {model_name}\n")
        handle.write(f"# Objective value = {objective}\n")
        for var in sorted(values, key=variable_index):
            handle.write(f"{var} {values[var]}\n")


def qap_variable(i: int, p: int) -> str:
    return f"x_{i + 1:02d}_{p + 1:02d}"


def write_qap_lp(
    path: Path, flow: list[list[int]], distance: list[list[int]]
) -> int:
    """Write the compact, constant-shifted 16 x 16 QAP in Gurobi LP format."""
    offset = 22 * sum(flow[i][j] for i in range(N) for j in range(i + 1, N))
    with path.open("w", encoding="utf-8") as handle:
        handle.write("\\ neos-2629914-sudost QAP extracted from the original MPS\n")
        handle.write(f"\\ Add the constant offset {offset} to recover the MPS objective\n")
        handle.write("Minimize\n qap: [\n")
        # The LP quadratic expression is divided by two.  The desired coefficient
        # is 2*F[i,j]*(D[p,q]-11), hence the printed coefficient is twice that.
        for i in range(N):
            for j in range(i + 1, N):
                for p in range(N):
                    for q in range(N):
                        shifted_distance = distance[p][q] - 11 if p != q else 0
                        coefficient = 4 * flow[i][j] * shifted_distance
                        if coefficient:
                            handle.write(
                                f" + {coefficient} {qap_variable(i, p)} * {qap_variable(j, q)}\n"
                            )
        handle.write(" ] / 2\nSubject To\n")
        for i in range(N):
            terms = " + ".join(qap_variable(i, p) for p in range(N))
            handle.write(f" facility_{i + 1:02d}: {terms} = 1\n")
        for p in range(N):
            terms = " + ".join(qap_variable(i, p) for i in range(N))
            handle.write(f" location_{p + 1:02d}: {terms} = 1\n")
        handle.write("Binaries\n")
        for i in range(N):
            handle.write(" " + " ".join(qap_variable(i, p) for p in range(N)) + "\n")
        handle.write("End\n")
    return offset


def write_qap_mst(path: Path, permutation: list[int]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        handle.write("# MIP start for the extracted sudost QAP\n")
        for i in range(N):
            for p in range(N):
                handle.write(f"{qap_variable(i, p)} {int(permutation[i] == p)}\n")


def validate_solution(mps_path: Path, values: dict[str, Decimal]) -> dict[str, Decimal | int]:
    """Check every row, bound, integrality condition, and objective exactly."""
    section = ""
    row_types: dict[str, str] = {}
    rhs: dict[str, Decimal] = defaultdict(Decimal)
    variables: set[str] = set()
    integer_variables: set[str] = set()
    bound_records: list[list[str]] = []
    integer_mode = False

    with open_text(mps_path, "latin-1") as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if tokens[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = tokens[0]
                continue
            if section == "ROWS":
                row_types[tokens[1]] = tokens[0]
            elif section == "COLUMNS":
                if "'MARKER'" in tokens:
                    if "'INTORG'" in tokens:
                        integer_mode = True
                    elif "'INTEND'" in tokens:
                        integer_mode = False
                    continue
                variables.add(tokens[0])
                if integer_mode:
                    integer_variables.add(tokens[0])
            elif section == "RHS":
                for row, value_text in zip(tokens[1::2], tokens[2::2]):
                    rhs[row] += number(value_text)
            elif section == "BOUNDS":
                bound_records.append(tokens)

    lower = {var: Decimal(0) for var in variables}
    upper: dict[str, Decimal | None] = {var: None for var in variables}
    for tokens in bound_records:
        kind, var = tokens[0], tokens[2]
        value = number(tokens[3]) if len(tokens) > 3 else Decimal(0)
        if kind == "LO":
            lower[var] = value
        elif kind == "UP":
            upper[var] = value
        elif kind == "FX":
            lower[var] = upper[var] = value
        elif kind == "FR":
            lower[var], upper[var] = Decimal("-Infinity"), None
        elif kind == "MI":
            lower[var] = Decimal("-Infinity")
        elif kind == "PL":
            upper[var] = None
        elif kind == "BV":
            lower[var], upper[var] = Decimal(0), Decimal(1)
            integer_variables.add(var)
        elif kind == "LI":
            lower[var] = value
            integer_variables.add(var)
        elif kind == "UI":
            upper[var] = value
            integer_variables.add(var)
        else:
            raise ValueError(f"Unsupported MPS bound type {kind}")

    activity: dict[str, Decimal] = defaultdict(Decimal)
    objective = Decimal(0)
    objective_rows = {row for row, kind in row_types.items() if kind == "N"}
    section = ""
    with open_text(mps_path, "latin-1") as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if tokens[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = tokens[0]
                continue
            if section != "COLUMNS" or "'MARKER'" in tokens:
                continue
            var = tokens[0]
            x = values.get(var, Decimal(0))
            for row, coefficient_text in zip(tokens[1::2], tokens[2::2]):
                term = number(coefficient_text) * x
                if row in objective_rows:
                    objective += term
                else:
                    activity[row] += term

    constraint_violations = 0
    max_constraint_violation = Decimal(0)
    for row, kind in row_types.items():
        if kind == "N":
            continue
        lhs, row_rhs = activity[row], rhs[row]
        if kind == "E":
            violation = abs(lhs - row_rhs)
        elif kind == "L":
            violation = max(Decimal(0), lhs - row_rhs)
        elif kind == "G":
            violation = max(Decimal(0), row_rhs - lhs)
        else:
            raise ValueError(f"Unsupported MPS row type {kind}")
        if violation:
            constraint_violations += 1
            max_constraint_violation = max(max_constraint_violation, violation)

    bound_violations = 0
    max_bound_violation = Decimal(0)
    for var in variables:
        x = values.get(var, Decimal(0))
        violation = max(Decimal(0), lower[var] - x)
        if upper[var] is not None:
            violation = max(violation, x - upper[var])
        if violation:
            bound_violations += 1
            max_bound_violation = max(max_bound_violation, violation)

    integrality_violations = sum(values.get(var, Decimal(0)) % 1 != 0 for var in integer_variables)
    return {
        "objective": objective,
        "constraints": len(row_types) - len(objective_rows),
        "constraint_violations": constraint_violations,
        "max_constraint_violation": max_constraint_violation,
        "bound_violations": bound_violations,
        "max_bound_violation": max_bound_violation,
        "integrality_violations": integrality_violations,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "mps",
        nargs="?",
        type=Path,
        default=Path("input/neos-2629914-sudost.mps.gz"),
    )
    parser.add_argument("--seconds", type=float, default=5.0, help="single-core search limit")
    parser.add_argument("--seed", type=int, default=2_629_914)
    parser.add_argument("--target", type=int, default=TARGET)
    parser.add_argument("--initial-sol", type=Path, help="optional incumbent used as the first start")
    parser.add_argument(
        "--output", type=Path, default=Path("solutions/sudost_48180.sol")
    )
    parser.add_argument("--qap-lp", type=Path, help="also write the extracted QAP model")
    parser.add_argument("--qap-mst", type=Path, help="also write a QAP warm start")
    args = parser.parse_args()

    flow, distance = extract_qap(args.mps)
    initial = permutation_from_solution(args.initial_sol) if args.initial_sol else None
    permutation, objective, restarts = search(
        flow, distance, args.seconds, args.seed, initial, args.target
    )
    values = solution_values(permutation, distance)
    write_solution(args.output, args.mps.stem, objective, values)
    if args.qap_lp:
        offset = write_qap_lp(args.qap_lp, flow, distance)
        print(f"wrote {args.qap_lp} (MPS objective offset {offset})")
    if args.qap_mst:
        write_qap_mst(args.qap_mst, permutation)
        print(f"wrote {args.qap_mst}")

    exact_values = {name: Decimal(value) for name, value in values.items()}
    report = validate_solution(args.mps, exact_values)
    print(f"searched {restarts} restart(s) on one Python thread")
    print(f"wrote {args.output}")
    print(
        "exact validation: "
        f"objective={report['objective']}, "
        f"constraint violations={report['constraint_violations']}/{report['constraints']}, "
        f"bound violations={report['bound_violations']}, "
        f"integrality violations={report['integrality_violations']}"
    )
    if objective != report["objective"]:
        raise SystemExit("ERROR: QAP objective and exact MPS objective differ")
    if any(
        report[key]
        for key in ("constraint_violations", "bound_violations", "integrality_violations")
    ):
        raise SystemExit("ERROR: generated solution is not feasible")


if __name__ == "__main__":
    main()
