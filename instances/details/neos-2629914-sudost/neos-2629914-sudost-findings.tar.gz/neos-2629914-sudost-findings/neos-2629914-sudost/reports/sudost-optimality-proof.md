# Exact optimum of `neos-2629914-sudost`

The minimum objective value is

\[
\boxed{48180}.
\]

The feasible solution is [`sudost_48180.sol`](../solutions/sudost_48180.sol).
The exact verifier is
[`sudost_optimality_certificate.py`](../scripts/sudost_optimality_certificate.py);
it uses one Python thread, integer arithmetic, and the standard library.  The
archived Mac run took about 5 seconds; the independent Windows rerun recorded
in this repository took about 7.5 seconds.

## 1. Bridge from the original MPS to a QAP

The verifier parses the MPS and checks the following facts directly.

- The 256 binary variables form a 16 by 16 permutation matrix: there are 16
  row-sum equations and 16 column-sum equations.
- The 240 continuous variables correspond lexicographically to the ordered
  facility pairs `(i,j)`, `i != j`.
- All 48,000 product lower-bound rows are present.  Together with the lower
  bound 11 on each continuous variable, they imply
  `C[i,j] >= D[pi(i),pi(j)]` for every permutation `pi`.
- The objective has only the 240 continuous variables, with the positive
  symmetric coefficient matrix `F` extracted by the script.

Consequently every feasible solution of the original MPS has objective at
least

\[
2\sum_{i<j}F_{ij}D_{\pi(i),\pi(j)}.
\]

The saved incumbent is also checked against all 51,872 original rows, all
bounds, and all integrality declarations, with no tolerance or floating-point
arithmetic.

## 2. Manhattan cut decomposition

In MPS location order, the script verifies exactly that

\[
D_{pq}=10+\lVert g_p-g_q\rVert_1\qquad(p\ne q),
\]

where

```text
(0,0), (1,0), (2,0), (1,1),
(2,1), (3,1), (2,2), (2,3),
(2,-1), (3,2), (3,3), (4,3),
(4,4), (4,5), (3,4), (3,5).
```

Since `sum(i<j) F[i,j] = 1801`, every permutation has objective

\[
36020+2(C_x+C_y),
\]

where `Cx` and `Cy` are sums of weighted cut values along the nested coordinate
threshold subsets.  The X threshold subset sizes are `(1,3,8,13)` and the Y
threshold subset sizes are `(1,4,7,9,12,14)`.

## 3. Exact exhaustive lower bound

Exact nested-subset dynamic programming gives

```text
min Cx = 2254
min Cy = 3793
```

A solution below 48,180 would therefore have `Cx+Cy <= 6079`, so it would have
to satisfy both

```text
Cx <= 2286
Cy <= 3825.
```

The verifier exhaustively enumerates all chains under these caps:

```text
32,367 X chains
 8,147 Y chains
```

For each Y chain, it enumerates all 1,728 bijections allowed by the 16-point
grid.  Thus it checks exactly

```text
8,147 * 1,728 = 14,078,016
```

grid-compatible assignments.  There are 118,161 matches with the enumerated X
chains, and their minimum is

```text
Cx + Cy = 6080.
```

Therefore every original feasible solution has objective at least

\[
36020+2\cdot6080=48180.
\]

The saved feasible permutation is

```text
[4, 15, 14, 2, 13, 7, 5, 6, 1, 12, 8, 11, 16, 10, 9, 3]
```

and has `Cx=2273`, `Cy=3807`, hence it attains this lower bound.

## Reproduction

From the instance directory, run:

```sh
python -B scripts/sudost_optimality_certificate.py \
  input/neos-2629914-sudost.mps.gz \
  --solution solutions/sudost_48180.sol
```

The last line must be:

```text
CERTIFIED OPTIMUM: 48180 (lower bound 36020 + 2*6080)
```

This is an exact, independently rerunnable computational proof.  It is not a
proof-assistant formalization.
