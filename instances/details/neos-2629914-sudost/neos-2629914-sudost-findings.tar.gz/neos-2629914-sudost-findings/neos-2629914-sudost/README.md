# `neos-2629914-sudost`

## Result

The known objective **48,180 is globally optimal**:

```text
OPT = 48180.
```

This is certified independently of a floating-point solver gap.  The original
MIP is checked exactly against a 16-by-16 quadratic assignment problem (QAP),
and an exhaustive nested-cut dynamic program proves the matching lower bound.
The saved solution passes all 51,872 original MPS rows, bounds, and integrality
conditions with zero tolerance.

## Input and provenance

- Compressed MPS SHA-256: `D13E000B9CBFF6EBC6C6426CDFAEA2E44501714A5BE294C669E9E8E9D57D60E5`
- Uncompressed MPS SHA-256: `9ECC76582A0FD3E28BD5C0064EC91EDC9DAA00AE13B3A92130CFEAA1575CF8D9`
- Optimal solution SHA-256: `2DEA845A10682A864BED1C9BC035487B336736DEB6B530941AA6BF03B4D590C8`
- [MIPLIB instance page](https://miplib.zib.de/instance_details_neos-2629914-sudost.html)

MIPLIB currently lists 496 variables, 51,872 constraints, 209,792 nonzeros,
and the incumbent 48,180, while retaining the `open` status.

## Exact reduction and proof

The verifier mechanically checks the following bridge from the full MPS:

- 256 binary variables form a 16-by-16 permutation matrix;
- 240 continuous variables represent ordered facility-pair costs;
- 48,000 product lower-bound rows imply the extracted QAP cost for every
  permutation; and
- the saved incumbent satisfies all 51,872 original rows exactly.

The extracted location distance matrix has the exact form

```text
D[p,q] = 10 + ManhattanDistance(grid[p], grid[q])  for p != q.
```

Decomposing Manhattan distance into nested coordinate cuts gives every QAP
objective as

```text
36020 + 2 * (Cx + Cy).
```

Independent dynamic programs give `min Cx=2254` and `min Cy=3793`.  Any strict
improvement over 48,180 would therefore lie among 32,367 capped X chains and
8,147 capped Y chains.  The exact verifier checks all
`8,147 * 1,728 = 14,078,016` grid-compatible assignments.  Their minimum is
`Cx+Cy=6080`, proving the lower bound `36020 + 2*6080 = 48180`.  The saved
permutation attains the same value with `Cx=2273` and `Cy=3807`.

This is an independently rerunnable computational proof using integer
arithmetic and the Python standard library; it is not a proof-assistant
formalization.

## Archived experiments

The original workspace also contained the direct Gurobi probe, compact QAP
model, QAP warm start, three-minute QAP run, and their solution/log files.  They
are preserved under [`logs/`](logs/), [`solutions/`](solutions/), and
[`artifacts/`](artifacts/).  License identifiers and private machine paths were
redacted.  The optimality conclusion relies on the exact certificate, not on
these time-limited solver runs.

## Reproduction

Run from this instance directory:

```powershell
python -B .\scripts\sudost_optimality_certificate.py `
  .\input\neos-2629914-sudost.mps.gz `
  --solution .\solutions\sudost_48180.sol
```

The final line must contain:

```text
CERTIFIED OPTIMUM: 48180 (lower bound 36020 + 2*6080)
```

An independent original-MPS check can be run from the repository root:

```powershell
python .\common\exact_mps_solution_check.py `
  .\instances\neos-2629914-sudost\input\neos-2629914-sudost.mps.gz `
  .\instances\neos-2629914-sudost\solutions\sudost_48180.sol `
  --tolerance 0
```

See the [full proof](reports/sudost-optimality-proof.md) and the
[recorded certificate run](artifacts/certificate-run.txt).
