#  Neos - 4360552 - Sangro research records

Authorization from the MIPLIB instance page
< https://miplib.zib.de/instance_details_neos-4360552-sangro.html >. The instance is still labeled as open, group
`neos-pseudoapplication-62` is an anonymous NEOS submitted collection, and the webpage clearly has no bibliographic information.
The objective of the currently known exact feasible solution is -8, but there is no optimality guarantee.

This round has completed the authorized download of the original MPS, official -8 solution and original decomposition with SHA256 consolidation.
The original scale is 10,272 variable, 46,012 constraint, 302,184 non-zero, all-integer variable, where 9,696 binary and
576 general integer ∙ constraint classification and 12 -block decomposition imply a strong repeating block structure, so this round starts with
MPS coefficients and indexes restore block-to-block coupling, objective variable family and integer variable meanings, without directly linking the 46,012 line to the original model
Repeated solving with parameter adjustments.

Gurobi 13.0.1 read-only audit is complete with the size of the page.
`w:58×48=2784`, `x:6×12×48=3456`, `y:6×12×48=3456`, `s/e:6×48=288`, and each group;
The bounds of `w/x/y` are `[0,1]`, and those of `s/e` are `[0,12]`. Only w variables appear in the objective, all with coefficient -1, so the problem is equivalent
A binary matching base for maximizing a structural compatibility constraint. `w_difk/w_difn` is a two-sided matching line;
`twtone_n` connects each n's matching state to the 72 x; 72 bar cover spans all the n's of the 48; 33,408 bar wS
couples one w variable to the 6 y variables with the same n. The remaining rows construct 6×12 binary sequences and integer start/end positions. The official 12-block
decomposition cannot be simply explained by j-vices, nor can the anonymous application name be considered a known fact.

###  Solver does not have an exact audit

Added `analysis/independent_audit.py`, using only the Python standard library with `Decimal`, directly parse MPS, official
solution and DEC. The script runs on local Windows Python and euler4 system Python, respectively, and is output word-for-word except for the barcode.
Both audits received:

-  The official solution objective is recalculated by the MPS objective coefficients to -8, consistent with the solution file report value complete;
-  The maximum violation of the constraint of 46,012 is 0, with variable bound violation, non-integer values and unknown variables both empty;
-  The DEC declares a block 12, which includes the 45,335 line, and the master receives the 677 line; each line of the model happens to be assigned once,
There are no missing or unknown passages in the DEC;
-  The master exact decomposition is given by 48 to `w_difn`, 48 to `twtone`, 576 to `aggri`, 4 to `w_difk` and
1 column `wS`; variable scope statistics for 6,246 appear simultaneously in block/master; 3,450 across multiple blocks;
576 is only within a single block, so it is not possible to directly refer to 12 as an independent subproblem.

The current strict conclusion is fixed: **-8 is a feasible primal bound with independent exact verification, but not yet proof of the optimal value**.
Prioritize the projection/detection of the 6 × 12 sequence feasible domain induced by a single `w(k,n)=1`, construct a conflict relationship of candidate matching, and then try
Matching/covering main problems are separated from exact subproblems; solvers are only called as controlled subroutines when structural experiments are needed.

###  Exact minus the first strict lower bound

After summing up the coefficients w in `wS_k_n_j` one by one, the 58 is given as a non-intersecting rectangular graph, with the coefficients of each rectangular graph being equal.
12. Conjugating the histogram yields exactly all 58 partitions of integer 12 into at most six parts; the true combinatorial role of k has therefore been
identified as unordered partition indices for six interval lengths. For an active layer n, `twtone` gives `sum x=12`, while `x_es/y` gives
`sum y=sum x`, and the corresponding 12 column wS's left-hand coefficient is also 12, so each wS must be the same.
Delete wS, and only retain layer n to select a rectangular graph equation that does not repeatedly divide the graph.

Additionally, each orbit from 0 to 12, with adjacent layers either overlapping at the top or overlapping a grid. If the number of active layers is A, the total range is
The length is 12 A, while the non-overlapping capacity of the six orbits is 72, so the total overlapping is exactly `12A-72`.
The orbit produces six inbound overlays, and the first positive interval of each orbit cannot overlap, so the total overlap is as much as `6A-6`.
`12A-72≤6A-6`, derived from **A≤ 11**, which is the original objective strict lower bound **-11**.

`analysis/reduced_interval_cpsat.py` keep 6 × 48 an integer stop and 6 × 12 × 48 an interval unit variable, using
The exactly-one constraint over 12 labels reconstructs `aggri`; the 58 partition histograms then replace 33,408 wS rows. For target=8,
Verification runs on euler4 4.78 seconds back to OPTIMAL, where it represents meeting a given feasibility objective.
Activity n with split number.

55.62 seconds, 85,738 conflicts and 903,454 branches are returned after the strict feasibility test of 11
**INFEASIBLE**. Combined with a simple two-way equivalence, which excludes the original model objective less than the probability of equal to -11, the strict calculation
The lower bound is upgraded to -10. The complete result/log has been archived to `runs/20260906-reduced-target11-1200s/`.
The 48 layer's target=10 run expires 1,200.32 seconds is still UNKNOWN; this run was only used as a failed save search and was not used.
Any final boundary.

###  Remove the quotient model of the vacuum layer with the optimality proof

Further on, we compared the `aggri` coefficients of n of 48 and found that their 6 × 12 label sequence is the same as the 58 of wS.
The vertical graph is also not related to n. If a layer is inactive, the label equation forces its x to be 0, thus `e=s`;
`e_n≤e_(n+1)` and `e_n-1≤s_(n+1)≤e_n`, where the vacuum layer can only keep six endpoints unchanged, are strictly constant transfers.

1.  An A activity layer solution of an arbitrary original model, where the chain of activity of length A is obtained after removing all the empty layers;
2.  An activity chain of any length A can be placed in the first A layer of the original model, and the empty layer of 12 can be added to the 48 layer at the endpoint;
3.  The same local tag matrix guarantees that removing or inserting layers will not change any activity layer constraint.

This gives a two-way equivalent of `analysis/compressed_active_layers_cpsat.py`. It presses the 48 layer to the exclusion A layer:

|  Run |  Status | Wall clock time |  Conclusion |
|---|---:|---:|---|
|  `compressed-A8-validation`  |  OPTIMAL/feasible  |  1.3157 s  | Eight-level witness recovery |
|  `compressed-A10-1200s`  |  INFEASIBLE  |  2.4593 s  |  exclusion A= 10 |
|  `compressed-A9-1200s`  |  INFEASIBLE  |  5.0967 s  |  exclusion A= 9 |
|  `compressed-A9-repeat-relax`  |  INFEASIBLE  |  5.5245 s  | Exclusion A = 9 even if it is allowed to re-divide |

The last line is the strict relaxation of the original model primal bound problem: every up to six parts of the integer 12 divide into ks of 58.
Therefore, any original solution can still be displayed in the model after the split is allowed to be repeated. The relaxation A = 9 is infeasible, so the original model has up to eight activity layers.
The objective lower bound is -8. On the other hand, the A=8 witness generated by the compressed model is
`analysis/expand_compressed_solution.py` was expanded to `solutions/compressed-A8-expanded.sol`; then to complete
An independent decimal MPS audit checks the 46,012 line, objective is -8, maximum row violation, bound violation and integrality violation
0 corresponds to the upper lower bound, and ultimately:

**The optimal objective value of neos-4360552-sangro is -8.**

Key SHA256: Compressed script
`b544a61bbcb6a5c650b48e58d4ddef91de7632775402eb3e755db3553fc32052`; A = 10 Results
`ed1a37f1924a763295be08bf32c1c6fbaa8c7150de26ca5f7c63e9633e059215`; A = 9 Results
`8a886dd6c045da8cf34fe6bf671c3d2dc0f400d46a873e5d32b2f76d45c5934b`; A= 9 Repeated decomposition of relaxation results
`34b4e512df4704e6c494f14fc91aea345fe1162eb8fc5526abcf6c4fed4343f5` ;  expanded solution
`df9d4fe96d1eeb6286a5054e3af4299baaf4801558f0c56c9f2f5faf3e1a4476`; independently audited
`2e002d7bb78b36ab420a2398cdfda9de40c67e3e319fb887db063ae4832327a8`。
