"""Read-only Gurobi audit for neos-4360552-sangro; never optimizes."""
import argparse
import hashlib
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

import gurobipy as gp


def family(name):
    if "(" in name:
        return name.split("(", 1)[0]
    return re.sub(r"_\d.*$", "", name)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mps", type=Path)
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    model = gp.read(str(args.mps))
    variables = model.getVars()
    constraints = model.getConstrs()

    variable_families = defaultdict(lambda: {"count": 0, "types": Counter(), "objective_nonzero": 0,
                                             "lb": Counter(), "ub": Counter()})
    for var in variables:
        data = variable_families[family(var.VarName)]
        data["count"] += 1
        data["types"][var.VType] += 1
        data["objective_nonzero"] += var.Obj != 0
        data["lb"][str(var.LB)] += 1
        data["ub"][str(var.UB)] += 1

    row_families = defaultdict(lambda: {"count": 0, "senses": Counter(), "degrees": Counter(),
                                        "rhs": Counter(), "coefficient_signs": Counter(), "samples": []})
    row_degrees = Counter()
    for constraint in constraints:
        row = model.getRow(constraint)
        data = row_families[family(constraint.ConstrName)]
        data["count"] += 1
        data["senses"][constraint.Sense] += 1
        data["degrees"][row.size()] += 1
        data["rhs"][str(constraint.RHS)] += 1
        row_degrees[row.size()] += 1
        for k in range(row.size()):
            value = row.getCoeff(k)
            data["coefficient_signs"]["positive" if value > 0 else "negative" if value < 0 else "zero"] += 1
        if len(data["samples"]) < 3:
            data["samples"].append({
                "row": constraint.ConstrName,
                "sense": constraint.Sense,
                "rhs": constraint.RHS,
                "terms": [[row.getVar(k).VarName, row.getCoeff(k)] for k in range(row.size())],
            })

    def clean(groups):
        return {name: {key: dict(value) if isinstance(value, Counter) else value
                       for key, value in data.items()}
                for name, data in sorted(groups.items())}

    objective = [(var.VarName, var.Obj) for var in variables if var.Obj != 0]
    payload = {
        "method": "Gurobi read-only structure audit (optimize never called)",
        "gurobi_version": ".".join(map(str, gp.gurobi.version())),
        "mps_sha256": hashlib.sha256(args.mps.read_bytes()).hexdigest(),
        "model_name": model.ModelName,
        "sense": "min" if model.ModelSense == 1 else "max",
        "variables": model.NumVars,
        "constraints": model.NumConstrs,
        "nonzeros": model.NumNZs,
        "binary": model.NumBinVars,
        "integer": model.NumIntVars,
        "continuous": model.NumVars - model.NumIntVars,
        "row_senses": dict(Counter(c.Sense for c in constraints)),
        "row_degrees": dict(row_degrees),
        "objective_nonzero": len(objective),
        "objective_terms": objective,
        "variable_families": clean(variable_families),
        "row_families": clean(row_families),
    }
    args.output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload), flush=True)


if __name__ == "__main__":
    main()
