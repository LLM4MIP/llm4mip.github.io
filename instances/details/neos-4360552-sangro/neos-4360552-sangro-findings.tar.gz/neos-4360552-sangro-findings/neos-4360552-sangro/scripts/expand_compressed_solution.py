"""Expand a compressed active-layer witness into an original MPS .sol file."""
import argparse
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("compressed_result", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = json.loads(args.compressed_result.read_text(encoding="utf-8"))
    assert result["status"] in {"FEASIBLE", "OPTIMAL"}
    layers = result["layers"]
    active = len(layers)
    assert active == result["active_layers"]

    values = {}
    for layer in layers:
        n = layer["t"]
        values[f"w({n},{layer['partition_id']})"] = 1
        for offset, (start, end, duration) in enumerate(
                zip(layer["starts"], layer["ends"], layer["durations"]), start=1):
            assert end - start == duration
            values[f"s({offset},{n})"] = start
            values[f"e({offset},{n})"] = end
            for j in range(start + 1, end + 1):
                values[f"x({offset},{j},{n})"] = 1
            for j in range(1, duration + 1):
                values[f"y({offset},{n},{j})"] = 1

    # Trailing deleted layers are the identity at endpoint 12.
    for n in range(active + 1, 49):
        for i in range(1, 7):
            values[f"s({i},{n})"] = 12
            values[f"e({i},{n})"] = 12

    lines = [f"=obj= {-active}"]
    lines.extend(f"{name} {value}" for name, value in sorted(values.items()) if value)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(lines) + "\n", encoding="ascii")
    print(json.dumps({"active_layers": active, "nonzero_entries": len(lines) - 1,
                      "output": str(args.output)}))


if __name__ == "__main__":
    main()
