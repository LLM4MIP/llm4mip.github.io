"""Solver-independent exact MPS, solution, and decomposition audit for sangro."""
import argparse
import gzip
import hashlib
import json
import re
from collections import Counter, defaultdict
from decimal import Decimal
from pathlib import Path


SECTIONS = {"NAME", "ROWS", "COLUMNS", "RHS", "BOUNDS", "RANGES", "ENDATA",
            "OBJSENSE", "OBJNAME"}


def family(name):
    if "(" in name:
        return name.split("(", 1)[0]
    return re.sub(r"_\d.*$", "", name)


def open_text(path):
    return gzip.open(path, "rt", encoding="ascii") if path.suffix == ".gz" else open(path, "rt", encoding="ascii")


def read_mps(path):
    rows = {}
    order = []
    matrix = defaultdict(dict)
    rhs = defaultdict(lambda: Decimal(0))
    objective = defaultdict(lambda: Decimal(0))
    bounds = {}
    integral = set()
    variables = set()
    section = None
    objrow = None
    intmode = False
    sense = "min"
    with open_text(path) as stream:
        for raw in stream:
            fields = raw.split()
            if not fields or fields[0].startswith("*"):
                continue
            if not raw[0].isspace() and fields[0].upper() in SECTIONS:
                section = fields[0].upper()
                continue
            if section == "OBJSENSE":
                sense = fields[0].lower()
            elif section == "ROWS":
                row_sense, name = fields[:2]
                if row_sense == "N":
                    objrow = name
                else:
                    rows[name] = row_sense
                    order.append(name)
            elif section == "COLUMNS":
                upper = [field.strip("'").upper() for field in fields]
                if "MARKER" in upper:
                    if "INTORG" in upper:
                        intmode = True
                    elif "INTEND" in upper:
                        intmode = False
                    continue
                variable = fields[0]
                variables.add(variable)
                if intmode:
                    integral.add(variable)
                for position in range(1, len(fields), 2):
                    row, value = fields[position], Decimal(fields[position + 1].replace("D", "E"))
                    if row == objrow:
                        objective[variable] += value
                    else:
                        matrix[row][variable] = matrix[row].get(variable, Decimal(0)) + value
            elif section == "RHS":
                for position in range(1, len(fields), 2):
                    rhs[fields[position]] = Decimal(fields[position + 1].replace("D", "E"))
            elif section == "BOUNDS":
                kind, variable = fields[0].upper(), fields[2]
                value = Decimal(fields[3].replace("D", "E")) if len(fields) > 3 else Decimal(0)
                variables.add(variable)
                lo, hi = bounds.get(variable, (Decimal(0), None))
                if kind == "FR": lo, hi = None, None
                elif kind == "MI": lo = None
                elif kind == "PL": hi = None
                elif kind == "LO": lo = value
                elif kind == "UP": hi = value
                elif kind == "FX": lo = hi = value
                elif kind == "BV": lo, hi = Decimal(0), Decimal(1); integral.add(variable)
                elif kind == "LI": lo = value; integral.add(variable)
                elif kind == "UI": hi = value; integral.add(variable)
                else: raise ValueError(f"unsupported bound {kind}")
                bounds[variable] = (lo, hi)
    for variable in variables:
        bounds.setdefault(variable, (Decimal(0), None))
    return sense, rows, order, matrix, rhs, dict(objective), bounds, integral, variables


def read_solution(path):
    values = defaultdict(lambda: Decimal(0))
    reported = None
    with open_text(path) as stream:
        for raw in stream:
            fields = raw.split()
            if len(fields) < 2 or fields[0].startswith("#"):
                continue
            if fields[0].lower() in {"=obj=", "objective"}:
                reported = Decimal(fields[1])
            else:
                values[fields[0]] = Decimal(fields[1])
    return values, reported


def read_dec(path):
    block_rows = defaultdict(list)
    master_rows = []
    mode = None
    blocks = None
    lines = path.read_text(encoding="ascii").splitlines()
    position = 0
    while position < len(lines):
        line = lines[position].strip()
        if not line or line.startswith("\\"):
            position += 1
            continue
        if line == "NBLOCKS":
            blocks = int(lines[position + 1].strip())
            position += 2
            continue
        if line.startswith("BLOCK "):
            mode = int(line.split()[1])
        elif line == "MASTERCONSS":
            mode = "master"
        elif isinstance(mode, int):
            block_rows[mode].append(line)
        elif mode == "master":
            master_rows.append(line)
        position += 1
    assert blocks == len(block_rows)
    return blocks, block_rows, master_rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mps", type=Path)
    ap.add_argument("solution", type=Path)
    ap.add_argument("dec", type=Path)
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    sense, rows, order, matrix, rhs, objective, bounds, integral, variables = read_mps(args.mps)
    values, reported = read_solution(args.solution)

    violations = []
    for row in order:
        activity = sum((coefficient * values[variable] for variable, coefficient in matrix[row].items()), Decimal(0))
        violation = (max(Decimal(0), activity - rhs[row]) if rows[row] == "L" else
                     max(Decimal(0), rhs[row] - activity) if rows[row] == "G" else
                     abs(activity - rhs[row]))
        if violation:
            violations.append((violation, row, activity, rhs[row], rows[row]))
    bound_violations = []
    nonintegral = []
    for variable in variables:
        value = values[variable]
        lo, hi = bounds[variable]
        if lo is not None and value < lo:
            bound_violations.append((variable, str(value), "lower", str(lo)))
        if hi is not None and value > hi:
            bound_violations.append((variable, str(value), "upper", str(hi)))
        if variable in integral and value != value.to_integral_value():
            nonintegral.append((variable, str(value)))
    computed = sum((objective.get(variable, Decimal(0)) * values[variable] for variable in variables), Decimal(0))
    unknown_solution_names = sorted(set(values) - variables)

    variable_families = defaultdict(lambda: {"count": 0, "integer": 0, "binary_by_bounds": 0,
                                             "objective_nonzero": 0, "lower_bounds": Counter(),
                                             "upper_bounds": Counter()})
    for variable in variables:
        data = variable_families[family(variable)]
        data["count"] += 1
        data["integer"] += variable in integral
        data["binary_by_bounds"] += variable in integral and bounds[variable] == (Decimal(0), Decimal(1))
        data["objective_nonzero"] += objective.get(variable, Decimal(0)) != 0
        data["lower_bounds"][str(bounds[variable][0])] += 1
        data["upper_bounds"][str(bounds[variable][1])] += 1

    row_families = defaultdict(lambda: {"count": 0, "senses": Counter(), "degrees": Counter(), "rhs": Counter()})
    for row in order:
        data = row_families[family(row)]
        data["count"] += 1
        data["senses"][rows[row]] += 1
        data["degrees"][len(matrix[row])] += 1
        data["rhs"][str(rhs[row])] += 1

    blocks, block_rows, master_rows = read_dec(args.dec)
    dec_rows = {row for rows_in_block in block_rows.values() for row in rows_in_block} | set(master_rows)
    variable_scopes = defaultdict(set)
    for block, rows_in_block in block_rows.items():
        for row in rows_in_block:
            for variable in matrix[row]:
                variable_scopes[variable].add(f"B{block}")
    for row in master_rows:
        for variable in matrix[row]:
            variable_scopes[variable].add("M")
    scope_classes = Counter()
    for variable in variables:
        scopes = variable_scopes[variable]
        if scopes == {"M"}:
            scope_classes["master_only"] += 1
        elif "M" in scopes:
            scope_classes["block_and_master"] += 1
        elif len(scopes) == 1:
            scope_classes["one_block_only"] += 1
        elif len(scopes) > 1:
            scope_classes["multiple_blocks"] += 1
        else:
            scope_classes["unassigned"] += 1

    def clean(groups):
        return {name: {key: dict(value) if isinstance(value, Counter) else value
                       for key, value in data.items()}
                for name, data in sorted(groups.items())}

    payload = {
        "method": "solver-independent Decimal MPS/solution/DEC audit",
        "mps_sha256": hashlib.sha256(args.mps.read_bytes()).hexdigest(),
        "solution_sha256": hashlib.sha256(args.solution.read_bytes()).hexdigest(),
        "dec_sha256": hashlib.sha256(args.dec.read_bytes()).hexdigest(),
        "model": {"sense": sense, "variables": len(variables), "constraints": len(rows),
                  "nonzeros": sum(len(matrix[row]) for row in order),
                  "integral": len(integral),
                  "binary_by_bounds": sum(bounds[v] == (Decimal(0), Decimal(1)) for v in integral),
                  "row_senses": dict(Counter(rows.values()))},
        "solution": {"reported_objective": str(reported), "computed_objective": str(computed),
                     "objective_match": reported == computed,
                     "violated_rows": len(violations),
                     "maximum_row_violation": str(max((v[0] for v in violations), default=Decimal(0))),
                     "largest_row_violations": [
                         {"row": row, "sense": row_sense, "activity": str(activity),
                          "rhs": str(row_rhs), "violation": str(violation)}
                         for violation, row, activity, row_rhs, row_sense in sorted(violations, reverse=True)[:20]],
                     "bound_violations": bound_violations, "nonintegral": nonintegral,
                     "unknown_solution_names": unknown_solution_names,
                     "nonzero_entries": sum(value != 0 for value in values.values())},
        "variable_families": clean(variable_families),
        "row_families": clean(row_families),
        "decomposition": {"blocks": blocks,
                          "block_row_counts": {str(block): len(block_rows[block]) for block in sorted(block_rows)},
                          "master_rows": len(master_rows),
                          "all_model_rows_assigned_exactly_once": len(dec_rows) == len(rows) and dec_rows == set(rows),
                          "missing_model_rows": sorted(set(rows) - dec_rows),
                          "unknown_dec_rows": sorted(dec_rows - set(rows)),
                          "variable_scope_classes": dict(scope_classes),
                          "block_row_family_counts": {
                              str(block): dict(Counter(family(row) for row in block_rows[block]))
                              for block in sorted(block_rows)},
                          "master_row_family_counts": dict(Counter(family(row) for row in master_rows))},
    }
    args.output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload), flush=True)


if __name__ == "__main__":
    main()
