"""Exact structure-reduced CP-SAT model for neos-4360552-sangro.

This is not a transcription of the original MIP.  It eliminates all w and y
variables and all 33,408 wS rows by proving that an active n chooses one of the
58 distinct integer partitions of 12.  It also drops the redundant cover rows.
"""
import argparse
import json
import sys
import time
from collections import defaultdict
from pathlib import Path

from ortools.sat.python import cp_model

sys.path.insert(0, str(Path(__file__).resolve().parent))
from independent_audit import family, read_mps  # noqa: E402


def extract(mps):
    _, rows, order, matrix, _, _, _, _, _ = read_mps(mps)

    # label_position[n][i][ell] is the unique j whose x(i,j,n) occurs in
    # aggri_n_ell.  For fixed (n,i), ell -> j must be a permutation of 1..12.
    label_position = {n: {i: {} for i in range(1, 7)} for n in range(1, 49)}
    for row in order:
        if family(row) != "aggri":
            continue
        _, n_text, ell_text = row.split("_")
        n, ell = int(n_text), int(ell_text)
        xs = [v for v in matrix[row] if v.startswith("x(")]
        assert len(xs) == 6
        for variable in xs:
            i, j, n_again = map(int, variable[2:-1].split(","))
            assert n_again == n
            label_position[n][i][ell] = j
    for n in range(1, 49):
        for i in range(1, 7):
            assert set(label_position[n][i]) == set(range(12))
            assert set(label_position[n][i].values()) == set(range(1, 13))

    # wS_k_n_j is c[k,j] w(n,k) <= sum_i y(i,n,j).  Zero coefficients are
    # omitted from the sparse matrix, hence lookup with a zero default.
    profiles = {k: [0] * 12 for k in range(1, 59)}
    for row in order:
        if family(row) != "wS":
            continue
        _, k_text, n_text, j_text = row.split("_")
        k, n, j = int(k_text), int(n_text), int(j_text)
        coefficient = int(matrix[row].get(f"w({n},{k})", 0))
        if n == 1:
            profiles[k][j - 1] = coefficient
        else:
            assert profiles[k][j - 1] == coefficient
    profile_tuples = [tuple(profiles[k]) for k in range(1, 59)]
    assert len(set(profile_tuples)) == 58
    assert all(sum(profile) == 12 for profile in profile_tuples)
    assert all(all(profile[j] >= profile[j + 1] for j in range(11))
               for profile in profile_tuples)

    # c_j is the number of parts at least j, so conjugating c recovers the six
    # (zero-padded) interval lengths associated with partition k.
    partitions = {}
    for k, profile in profiles.items():
        parts = tuple(sum(c >= j for c in profile) for j in range(1, 7))
        parts = tuple(sorted((part for part in parts if part), reverse=True))
        assert sum(parts) == 12 and len(parts) == profile[0]
        partitions[k] = parts + (0,) * (6 - len(parts))
    assert len(set(partitions.values())) == 58
    return label_position, profiles, partitions


def read_solution(path):
    import gzip
    opener = gzip.open if path.suffix == ".gz" else open
    values = {}
    with opener(path, "rt") as stream:
        for raw in stream:
            fields = raw.split()
            if len(fields) >= 2 and not fields[0].startswith("="):
                values[fields[0]] = int(float(fields[1]))
    return values


def build_model(label_position, profiles, partitions, target, hint_values=None):
    model = cp_model.CpModel()
    ns, machines, periods = range(1, 49), range(1, 7), range(1, 13)
    s = {(i, n): model.NewIntVar(0, 12, f"s({i},{n})") for i in machines for n in ns}
    e = {(i, n): model.NewIntVar(0, 12, f"e({i},{n})") for i in machines for n in ns}
    d = {(i, n): model.NewIntVar(0, 12, f"d({i},{n})") for i in machines for n in ns}
    x = {(i, j, n): model.NewBoolVar(f"x({i},{j},{n})")
         for i in machines for j in periods for n in ns}
    y = {(i, n, j): model.NewBoolVar(f"y({i},{n},{j})")
         for i in machines for n in ns for j in periods}
    z = {n: model.NewBoolVar(f"z({n})") for n in ns}
    code = {n: model.NewIntVar(0, 58, f"partition({n})") for n in ns}
    choose = {(n, k): model.NewBoolVar(f"choose({n},{k})")
              for n in ns for k in range(1, 59)}
    overlap = {(i, n): model.NewBoolVar(f"overlap({i},{n})")
               for i in machines for n in range(2, 49)}

    for i in machines:
        model.Add(s[i, 1] == 0)
        model.Add(e[i, 48] == 12)
        for n in ns:
            model.Add(d[i, n] == e[i, n] - s[i, n])
            model.Add(sum(x[i, j, n] for j in periods) == d[i, n])
            for j in periods:
                # Together with the cardinality equality these implications
                # make x exactly the discrete interval {s+1,...,e}.
                model.Add(s[i, n] <= j - 1).OnlyEnforceIf(x[i, j, n])
                model.Add(e[i, n] >= j).OnlyEnforceIf(x[i, j, n])
                model.Add(d[i, n] >= j).OnlyEnforceIf(y[i, n, j])
                model.Add(d[i, n] <= j - 1).OnlyEnforceIf(y[i, n, j].Not())
            if n < 48:
                model.Add(e[i, n + 1] >= e[i, n])
                model.Add(s[i, n + 1] >= e[i, n] - 1)
                model.Add(s[i, n + 1] <= e[i, n])
                model.Add(overlap[i, n + 1] == e[i, n] - s[i, n + 1])
                model.Add(overlap[i, n + 1] <= y[i, n + 1, 1])

    # An active layer selects exactly one cell carrying each of its 12 labels.
    for n in ns:
        for ell in range(12):
            model.Add(sum(x[i, label_position[n][i][ell], n] for i in machines) == z[n])

    # Select a duration partition.  The 12 histogram equalities are the exact
    # projection of all wS rows: profile[k,j] equals the number of the six
    # durations that are at least j.  Unlike a generic allowed-assignment
    # table, this compact encoding stays close to the proved combinatorics.
    for n in ns:
        model.Add(sum(choose[n, k] for k in range(1, 59)) == z[n])
        model.Add(code[n] == sum(k * choose[n, k] for k in range(1, 59)))
        for j in periods:
            model.Add(sum(y[i, n, j] for i in machines) ==
                      sum(profiles[k][j - 1] * choose[n, k] for k in range(1, 59)))
    for k in range(1, 59):
        model.Add(sum(choose[n, k] for n in ns) <= 1)

    # Telescoping the ordered interval endpoints gives this exact identity.
    # Since every one of the six tracks has a first positive interval that
    # cannot overlap its predecessor, it also yields the structural bound 11.
    model.Add(sum(overlap.values()) == 12 * sum(z.values()) - 72)
    model.Add(sum(overlap.values()) <=
              sum(profiles[k][0] * choose[n, k]
                  for n in ns for k in range(1, 59)) - 6)
    model.Add(sum(z.values()) <= 11)
    model.Add(sum(z.values()) >= target)

    if hint_values:
        for variables in (s, e, x, y):
            for key, variable in variables.items():
                name = variable.Name().replace("d(", "d(")
                if name in hint_values:
                    model.AddHint(variable, hint_values[name])
        active_n = set()
        for name, value in hint_values.items():
            if value and name.startswith("w("):
                active_n.add(int(name[2:-1].split(",")[0]))
        for n in ns:
            model.AddHint(z[n], int(n in active_n))

    return model, (s, e, d, x, y, z, code, choose, overlap)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("--solution", type=Path)
    parser.add_argument("--target", type=int, default=9)
    parser.add_argument("--time-limit", type=float, default=3600)
    parser.add_argument("--workers", type=int, default=16)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    started = time.time()
    labels, profiles, partitions = extract(args.mps)
    hints = read_solution(args.solution) if args.solution else None
    model, variables = build_model(labels, profiles, partitions, args.target, hints)
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = args.time_limit
    solver.parameters.num_search_workers = args.workers
    solver.parameters.log_search_progress = True
    solver.parameters.cp_model_presolve = True
    status = solver.Solve(model)
    s, e, d, x, y, z, code, choose, overlap = variables
    payload = {
        "method": "exact interval/partition reduction solved by CP-SAT",
        "target": args.target,
        "status": solver.StatusName(status),
        "wall_time_seconds": solver.WallTime(),
        "elapsed_seconds": time.time() - started,
        "conflicts": solver.NumConflicts(),
        "branches": solver.NumBranches(),
        "profiles": len(profiles),
        "objective_bound": solver.BestObjectiveBound(),
    }
    if status in (cp_model.FEASIBLE, cp_model.OPTIMAL):
        payload["active_count"] = sum(solver.Value(z[n]) for n in range(1, 49))
        payload["active_layers"] = [
            {"n": n, "partition_id": solver.Value(code[n]),
             "durations": [solver.Value(d[i, n]) for i in range(1, 7)],
             "starts": [solver.Value(s[i, n]) for i in range(1, 7)],
             "ends": [solver.Value(e[i, n]) for i in range(1, 7)]}
            for n in range(1, 49) if solver.Value(z[n])
        ]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print("RESULT_JSON " + json.dumps(payload), flush=True)


if __name__ == "__main__":
    main()
