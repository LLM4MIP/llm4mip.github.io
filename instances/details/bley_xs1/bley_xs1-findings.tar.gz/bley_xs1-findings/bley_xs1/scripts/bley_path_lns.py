#!/usr/bin/env python3
"""Set-partitioning-group LNS for the bley_xs1 network design model."""

from __future__ import annotations

import argparse
import random
from pathlib import Path

import gurobipy as gp

from solve_with_miplib_start import read_miplib_solution


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--seconds", type=float, default=45.0)
    parser.add_argument("--threads", type=int, default=24)
    parser.add_argument("--iterations", type=int, default=5)
    parser.add_argument("--seed", type=int, default=20260901)
    parser.add_argument("--result", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    args = parser.parse_args()

    rng = random.Random(args.seed)
    model = gp.read(str(args.mps))
    model.update()
    expected, supplied = read_miplib_solution(args.solution)
    incumbent = {variable.VarName: supplied.get(variable.VarName, 0.0) for variable in model.getVars()}
    incumbent_objective = sum(variable.Obj * incumbent[variable.VarName] for variable in model.getVars())

    groups: list[list[gp.Var]] = []
    grouped_names: set[str] = set()
    for constraint in model.getConstrs():
        if constraint.Sense != gp.GRB.EQUAL or abs(constraint.RHS - 1.0) > 1e-9:
            continue
        row = model.getRow(constraint)
        members = [row.getVar(term) for term in range(row.size())]
        if len(members) < 2:
            continue
        if all(
            member.VType != gp.GRB.CONTINUOUS
            and member.UB <= 1.0 + 1e-9
            and abs(row.getCoeff(term) - 1.0) <= 1e-9
            for term, member in enumerate(members)
        ):
            groups.append(members)
            grouped_names.update(member.VarName for member in members)

    all_binary = [
        variable
        for variable in model.getVars()
        if variable.VType != gp.GRB.CONTINUOUS and variable.UB <= 1.0 + 1e-9
    ]
    general_integer = [
        variable
        for variable in model.getVars()
        if variable.VType != gp.GRB.CONTINUOUS and variable.UB > 1.0 + 1e-9
    ]
    print(
        f"expected={expected} computed={incumbent_objective:.15g} "
        f"set_partition_groups={len(groups)} grouped_binary={len(grouped_names)} "
        f"all_binary={len(all_binary)} general_integer={len(general_integer)}"
    )
    print(
        f"group_size_min={min(map(len, groups))} group_size_max={max(map(len, groups))} "
        f"group_size_mean={sum(map(len, groups))/len(groups):.3f}"
    )

    original_bounds = {variable.VarName: (variable.LB, variable.UB) for variable in all_binary}
    model.Params.LogFile = str(args.log)
    model.Params.Threads = args.threads
    model.Params.MIPFocus = 1
    model.Params.NumericFocus = 3
    model.Params.NoRelHeurTime = min(8.0, args.seconds / 4)
    model.Params.Cuts = 2

    sizes = [20, 40, 80, 120, len(groups)]
    for iteration in range(args.iterations):
        for variable in all_binary:
            variable.LB, variable.UB = original_bounds[variable.VarName]

        target = min(sizes[iteration % len(sizes)], len(groups))
        group_indices = list(range(len(groups)))
        rng.shuffle(group_indices)
        released_groups = set(group_indices[:target])
        released_names = {
            variable.VarName
            for group_index in released_groups
            for variable in groups[group_index]
        }

        fixed = 0
        # Fix only path-choice binaries.  Capacity/module variables that do not
        # belong to a partitioning group remain free and are reoptimized.
        for variable in all_binary:
            if variable.VarName not in grouped_names or variable.VarName in released_names:
                continue
            value = round(incumbent[variable.VarName])
            variable.LB = value
            variable.UB = value
            fixed += 1

        model.reset(0)
        for variable in model.getVars():
            variable.Start = incumbent[variable.VarName]
        model.Params.TimeLimit = args.seconds
        model.Params.BestObjStop = incumbent_objective - 0.005
        print(
            f"iteration={iteration + 1} released_groups={target} "
            f"released_path_vars={len(released_names)} fixed_path_vars={fixed}"
        )
        model.optimize()
        if model.SolCount and model.ObjVal < incumbent_objective - 1e-4:
            incumbent_objective = model.ObjVal
            incumbent = {variable.VarName: variable.X for variable in model.getVars()}
            model.write(str(args.result))
            print(f"IMPROVED objective={incumbent_objective:.15g}")
        else:
            print(
                f"NO_IMPROVEMENT status={model.Status} solutions={model.SolCount} "
                f"bound={model.ObjBound:.15g}"
            )

    print(f"FINAL objective={incumbent_objective:.15g}")


if __name__ == "__main__":
    main()
