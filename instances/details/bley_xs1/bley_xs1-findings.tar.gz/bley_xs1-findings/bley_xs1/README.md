# `bley_xs1`

## Result

The best strictly verified objective is **3,855,895.86**; the best global lower bound obtained is **3,532,608.740610**. Global optimality remains open.

The model is an unsplittable-routing/network-expansion problem with 3,243 variables, 3,290 rows and coefficients as large as `1e20`. A path-group LNS produced an apparent objective improvement of about 0.099, but exact inspection found two integer deviations and four row residuals of approximately `9.63e-7`. Strictly rounding the integer variables restored exact feasibility and objective 3,855,895.86. The rounded solution may differ from the public solution, but it does not improve its objective.

## Input

- SHA-256: `02A0EBA05AD39EAADE8B266555FE2EB981954452990FBE0AC42BC727378256E8`
- MIPLIB metadata: [instance page](https://miplib.zib.de/instance_details_bley_xs1.html)

## Files

- [strictly rounded LNS solution](solutions/bley_xs1-lns-rounded.sol)
- [public solution](solutions/bley_xs1-known3855896.sol)
- [path-group LNS](scripts/bley_path_lns.py)
- [LNS log](logs/bley_xs1-path-lns.log)

This instance is a useful warning that solver-tolerance incumbents in very large-coefficient models must be rechecked after strict integrality rounding.
