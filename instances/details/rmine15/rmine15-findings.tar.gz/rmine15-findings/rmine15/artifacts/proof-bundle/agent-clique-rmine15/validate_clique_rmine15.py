#!/usr/bin/env python3
"""Independent exact validator for the rmine15 clique-cut bundle."""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import sys
from fractions import Fraction
from pathlib import Path

sys.dont_write_bytecode = True
from clique_experiment_rmine15 import family_seed_records  # noqa: E402

SHARED = Path(__file__).resolve().parent.parent / "agent-clique"
sys.path.insert(0, str(SHARED))
from clique_experiment import (  # noqa: E402
    build_exact_graph,
    closures_for_period,
    conflict_witness,
    discover,
    graph_digest,
    parse_mps,
)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("original_mps")
    parser.add_argument("seed_pair_result")
    parser.add_argument("seed_pair_mps")
    parser.add_argument("clique_result")
    parser.add_argument("enhanced_mps")
    parser.add_argument("--output")
    args = parser.parse_args()

    original = parse_mps(args.original_mps)
    catalog = discover(original)
    seed_payload = json.loads(Path(args.seed_pair_result).read_text(encoding="utf-8"))
    result = json.loads(Path(args.clique_result).read_text(encoding="utf-8"))
    pairs = family_seed_records(seed_payload)
    if seed_payload["model"]["original_sha256"] != original.sha256:
        raise ValueError("seed result/original hash mismatch")
    if result["original"]["sha256"] != original.sha256:
        raise ValueError("clique result/original hash mismatch")
    seed_model = parse_mps(args.seed_pair_mps)
    enhanced = parse_mps(args.enhanced_mps)
    if hashlib.sha256(Path(args.seed_pair_mps).read_bytes()).hexdigest() != result["seed_pair_mps_sha256"]:
        raise ValueError("seed MPS hash mismatch")
    if set(original.variables) != set(seed_model.variables) or original.objective != seed_model.objective:
        raise ValueError("seed MPS changed variables/objective")
    if set(original.arcs) != set(seed_model.arcs):
        raise ValueError("seed MPS changed precedence arcs")
    if set(seed_model.variables) != set(enhanced.variables) or seed_model.objective != enhanced.objective:
        raise ValueError("enhanced MPS changed variables/objective")
    if set(seed_model.arcs) != set(enhanced.arcs):
        raise ValueError("enhanced MPS changed precedence arcs")

    closure_cache = {}

    def closures(period: int):
        if period not in closure_cache:
            closure_cache[period] = closures_for_period(original, catalog, period)
        return closure_cache[period]

    for index, record in enumerate(pairs):
        period = int(record["period"])
        left, right = record["variables"]
        if conflict_witness(catalog, period, closures(period), left, right) is None:
            raise ValueError(f"seed pair {index} lacks exact overload")
        row = f"certified_family_pair_{index}"
        if seed_model.side_rhs.get(row) != 1:
            raise ValueError(f"missing seed pair row {row}")
        if seed_model.side_columns[row] != {left: Fraction(1), right: Fraction(1)}:
            raise ValueError(f"bad seed pair row {row}")

    graph_by_period = {}
    graph_edges = 0
    for graph_record in result["conflict_graphs"]:
        period = int(graph_record["period"])
        graph, witnesses = build_exact_graph(
            catalog, period, closures(period), graph_record["candidates"]
        )
        if graph_digest(graph) != graph_record["graph_sha256"]:
            raise ValueError(f"candidate graph hash mismatch at period {period}")
        if graph.number_of_edges() != graph_record["edges"]:
            raise ValueError(f"candidate graph edge count mismatch at period {period}")
        graph_by_period[period] = graph
        graph_edges += graph.number_of_edges()

    minimum_margin = None
    for index, record in enumerate(result["clique_cuts"]):
        period = int(record["period"])
        clique = record["variables"]
        if len(clique) < 3 or len(clique) != len(set(clique)):
            raise ValueError(f"malformed clique {index}")
        graph = graph_by_period[period]
        for left, right in itertools.combinations(clique, 2):
            if not graph.has_edge(left, right):
                raise ValueError(f"clique {index} contains nonedge")
            witness = conflict_witness(catalog, period, closures(period), left, right)
            if witness is None:
                raise ValueError(f"clique {index} pair lacks exact overload")
            margin = Fraction(witness["exact_overload_margin"])
            minimum_margin = margin if minimum_margin is None else min(minimum_margin, margin)
        row = f"certified_clique15_{index}"
        expected = {var: Fraction(1) for var in clique}
        if enhanced.side_rhs.get(row) != 1 or enhanced.side_columns.get(row) != expected:
            raise ValueError(f"bad enhanced row {row}")

    expected_side = set(seed_model.side_rows) | {
        f"certified_clique15_{index}" for index in range(len(result["clique_cuts"]))
    }
    if set(enhanced.side_rows) != expected_side:
        raise ValueError("enhanced MPS has missing/extra side rows")
    enhanced_sha = hashlib.sha256(Path(args.enhanced_mps).read_bytes()).hexdigest()
    if enhanced_sha != result["enhanced_mps_sha256"]:
        raise ValueError("enhanced MPS hash mismatch")
    payload = {
        "verified": True,
        "model": original.name,
        "official_mps_sha256": original.sha256,
        "seed_pairs_exactly_verified": len(pairs),
        "candidate_graph_edges_exactly_verified": graph_edges,
        "clique_cuts_exactly_verified": len(result["clique_cuts"]),
        "minimum_pair_overload_margin_across_cliques": str(minimum_margin) if minimum_margin else None,
        "enhanced_mps_sha256": enhanced_sha,
        "enhanced_mps_rows_exactly_verified": True,
    }
    rendered = json.dumps(payload, indent=2) + "\n"
    if args.output:
        Path(args.output).write_text(rendered, encoding="utf-8")
    print(rendered, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
