# rmine15 — improved strict primal and exact strengthened lower bound

Official MIPLIB page: <https://miplib.zib.de/instance_details_rmine15.html>

Official MPS: [download `rmine15.mps.gz`](https://miplib.zib.de/WebData/instances/rmine15.mps.gz)

## Result

An exact three-period rescheduling neighborhood found a new strictly feasible
incumbent:

```text
public objective, Decimal replay  -5018.819991000000004879
new objective                     -5018.823005000000004879
improvement                           0.003014000000000000
```

This is a primal improvement, **not** a proof of global optimality.  The current
bounds are deliberately separated by evidence level:

| bound | value | evidence status |
|---|---:|---|
| strict feasible UB | `-5018.823005000000004879` | exact original-MPS replay |
| strongest recorded numerical LB | `-5026.70481` | COPT 10-hour floating-point bound; no portable proof trace |
| portable exact global LB | `-5042.036233392018593` | rational closure certificate after validated pair/clique cuts |

Thus the exact-certified interval is
`-5042.036233392018593 <= OPT <= -5018.823005000000004879`, with width
`23.213228392018588121` (`0.462523%`).  The numerical COPT gap is smaller,
`7.881805` (`0.157045%`), but is not promoted to an exact theorem.

## Recovered structure

The model has 42,438 binary variables, 358,395 rows and 879,732 nonzeros.  Its
variables are the cumulative extraction states of 3,375 mine blocks over 15
periods.  The rows split into 319,302 spatial precedence constraints, 39,063
temporal precedence constraints, and only 30 capacity constraints: two
resources in each period.

This structure motivated exact time-window reoptimization rather than another
generic parameter sweep.  The decisive `[7,9]` window jointly moved 34 blocks
and changed 35 cumulative binaries.  Period extraction counts changed from
`(222,205,225)` to `(220,208,224)`.

## Evidence

- [`rmine15-improved-5018.823005.sol`](solutions/rmine15-improved-5018.823005.sol)
  is the new incumbent; SHA-256 is
  `3a20ccd9aa85b26f3def0911dc092ef0797f20fbdf2c490e8f3a954388824493` for
  the repository's LF-normalized text file.
- [`new-incumbent-audit.json`](artifacts/new-incumbent-audit.json) checks all
  358,395 original rows with the Gurobi model API.
- [`new-incumbent-exact-decimal-audit.json`](artifacts/new-incumbent-exact-decimal-audit.json)
  independently parses the MPS with 50-digit `Decimal`, without using Gurobi;
  row, bound and integrality violations are exactly zero.
- Sixty formal window experiments were run: 49 closed to zero gap and 11 hit
  the time limit.  The new point is optimal for every consecutive three-period
  neighborhood under the fixed outside schedule/final-pit scope.  This is a
  local statement only.
- The initial capacity-only Lagrangian maximum-closure experiment produced no
  improved primal or stronger numerical dual bound and is retained as a
  negative result.
- A later exact cut study validated 121 precedence-induced pair conflicts and
  61 clique inequalities (2,271 exact conflict-graph edges).  The resulting
  rational flow/cut certificate proves the global LB
  `-5042.036233392018593`.
- A finite genuine triple-cover follow-up checked 131,205 LP-eligible triples
  in period 0 and part of period 8, but found no additional cut.  Periods 9 and
  10 were not covered, so this is only a bounded negative result.

The complete derivation and claim boundaries are in
[`deep-study-2026-09-08.zh.md`](reports/deep-study-2026-09-08.zh.md).
The exact pair/clique bound and triple-cover screen are documented in
[`exact-pair-clique-bound.md`](reports/exact-pair-clique-bound.md) and
[`triple-cover-screen.md`](reports/triple-cover-screen.md).

## Exact lower-bound evidence

The exact certificate is
[`artifacts/exact-bound/exact-lb-cert.json.gz`](artifacts/exact-bound/exact-lb-cert.json.gz).
It is tied to the validated enhanced MPS at
[`artifacts/proof-bundle/agent-clique-rmine15/run/rmine15-pairs-plus-cliques.mps.gz`](artifacts/proof-bundle/agent-clique-rmine15/run/rmine15-pairs-plus-cliques.mps.gz).
The complete original-MPS-to-enhanced-MPS validity chain is retained under
[`artifacts/proof-bundle/`](artifacts/proof-bundle/), including the pair and
clique result JSONs, exact validators, and recorded validation outputs.

## Reproduction

The solver-free exact audit is:

```sh
python scripts/exact_decimal_audit.py \
  --mps input/rmine15.mps.gz \
  --solution solutions/rmine15-improved-5018.823005.sol \
  --out /tmp/rmine15-exact-audit.json
```

Replay the exact lower-bound witness without Gurobi:

```sh
python scripts/exact_lagrangian_certificate.py verify \
  artifacts/proof-bundle/agent-clique-rmine15/run/rmine15-pairs-plus-cliques.mps.gz \
  artifacts/exact-bound/exact-lb-cert.json.gz
```

The original downloaded files are identified in
[`input/SHA256SUMS`](input/SHA256SUMS).
