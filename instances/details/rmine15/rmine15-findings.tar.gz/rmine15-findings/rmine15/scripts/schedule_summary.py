import argparse
import gzip
import json
import re
from collections import defaultdict
from pathlib import Path

import gurobipy as gp


VAR_RE = re.compile(r"^x_B(\d+)_t(\d+)$")
GPREC_RE = re.compile(r"^gprec_B(\d+)_B(\d+)_t(\d+)$")
TCAP_RE = re.compile(r"^tcap_c(\d+)_t(\d+)$")


def read_solution(path):
    opener = gzip.open if path.endswith(".gz") else open
    values = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
        for raw in handle:
            pieces = raw.split()
            if len(pieces) >= 2 and not raw.startswith(("#", "=obj=")):
                values[pieces[0]] = float(pieces[1])
    return values


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", required=True)
    parser.add_argument("--solution", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    model = gp.read(args.mps)
    model.Params.OutputFlag = 0
    values = read_solution(args.solution)

    entries = defaultdict(list)
    for variable in model.getVars():
        match = VAR_RE.match(variable.VarName)
        if match:
            entries[int(match.group(1))].append((int(match.group(2)), variable))
    extraction = {}
    extraction_cost = {}
    ultimate_cost = {}
    for block, pairs in entries.items():
        pairs.sort()
        extraction[block] = min(
            (t for t, v in pairs if values.get(v.VarName, 0) > 0.5),
            default=15,
        )
        extraction_cost[block] = {
            p: sum(v.Obj for t, v in pairs if t >= p)
            for p in range(min(t for t, _ in pairs), 15)
        }
        ultimate_cost[block] = extraction_cost[block].get(14)

    arcs = set()
    capacity = []
    for row in model.getConstrs():
        gmatch = GPREC_RE.match(row.ConstrName)
        if gmatch:
            arcs.add((int(gmatch.group(2)), int(gmatch.group(1))))
            continue
        tmatch = TCAP_RE.match(row.ConstrName)
        if tmatch:
            expression = model.getRow(row)
            activity = sum(
                expression.getCoeff(j) * values.get(expression.getVar(j).VarName, 0.0)
                for j in range(expression.size())
            )
            capacity.append({
                "resource": int(tmatch.group(1)),
                "period": int(tmatch.group(2)),
                "rhs": row.RHS,
                "activity": activity,
                "slack": row.RHS - activity,
                "utilization": activity / row.RHS,
            })

    extracted_by_period = defaultdict(list)
    for block, period in extraction.items():
        extracted_by_period[period].append(block)
    per_period = []
    for period in range(16):
        blocks = extracted_by_period[period]
        per_period.append({
            "period": period,
            "block_count": len(blocks),
            "objective_contribution": sum(
                extraction_cost[b].get(period, 0.0) for b in blocks
            ) if period < 15 else 0.0,
        })

    output = {
        "instance": model.ModelName,
        "semantics": {
            "x_Bb_t": "1 iff block b has been extracted by the end of period t",
            "gprec": "x_block,t <= x_predecessor,t, so the predecessor is extracted no later",
            "tprec": "x_block,t <= x_block,t+1",
            "tcap": "resource weight times x_t-x_t-1, hence per-period extraction capacity",
        },
        "blocks": len(entries),
        "unique_spatial_precedence_arcs": len(arcs),
        "mined_blocks": sum(p < 15 for p in extraction.values()),
        "unmined_blocks": sum(p == 15 for p in extraction.values()),
        "period_schedule": per_period,
        "capacity_rows": sorted(capacity, key=lambda r: (r["period"], r["resource"])),
        "capacity_slack": {
            "minimum": min(r["slack"] for r in capacity),
            "maximum": max(r["slack"] for r in capacity),
            "rows_below_1_unit": sum(r["slack"] < 1 for r in capacity),
            "rows_below_10_units": sum(r["slack"] < 10 for r in capacity),
            "rows_below_100_units": sum(r["slack"] < 100 for r in capacity),
        },
        "unmined_block_terminal_costs": sorted(
            ({"block": b, "terminal_objective_coefficient": ultimate_cost[b]}
             for b, p in extraction.items() if p == 15),
            key=lambda r: r["terminal_objective_coefficient"],
        ),
    }
    Path(args.out).write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps({
        "arcs": output["unique_spatial_precedence_arcs"],
        "mined": output["mined_blocks"],
        "unmined": output["unmined_blocks"],
        "slack": output["capacity_slack"],
        "schedule": output["period_schedule"],
    }, indent=2))


if __name__ == "__main__":
    main()
