import argparse
import gzip
import json
from decimal import Decimal, getcontext
from pathlib import Path


getcontext().prec = 50


def open_text(path):
    return gzip.open(path, "rt", encoding="utf-8", errors="strict") if path.endswith(".gz") else open(path, "rt", encoding="utf-8", errors="strict")


def read_solution(path):
    values = {}
    with open_text(path) as handle:
        for raw in handle:
            pieces = raw.split()
            if len(pieces) >= 2 and not raw.startswith(("#", "=obj=")):
                values[pieces[0]] = Decimal(pieces[1])
    return values


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", required=True)
    parser.add_argument("--solution", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    values = read_solution(args.solution)
    senses = {}
    activity = {}
    rhs = {}
    objective_row = None
    objective = Decimal(0)
    variable_names = set()
    bounds = {}
    section = None

    with open_text(args.mps) as handle:
        for raw in handle:
            pieces = raw.split()
            if not pieces:
                continue
            key = pieces[0]
            if key in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = key
                continue
            if section == "ROWS":
                sense, name = pieces[:2]
                if sense == "N":
                    objective_row = name
                else:
                    senses[name] = sense
                    activity[name] = Decimal(0)
                    rhs[name] = Decimal(0)
            elif section == "COLUMNS":
                if "MARKER" in raw:
                    continue
                variable = pieces[0]
                variable_names.add(variable)
                value = values.get(variable, Decimal(0))
                for j in range(1, len(pieces), 2):
                    row = pieces[j]
                    coefficient = Decimal(pieces[j + 1])
                    if row == objective_row:
                        objective += value * coefficient
                    else:
                        activity[row] += value * coefficient
            elif section == "RHS":
                for j in range(1, len(pieces), 2):
                    row = pieces[j]
                    if row in rhs:
                        rhs[row] = Decimal(pieces[j + 1])
            elif section == "BOUNDS":
                bound_type = pieces[0]
                variable = pieces[2]
                bound_value = Decimal(pieces[3]) if len(pieces) > 3 else None
                lb, ub = bounds.get(variable, (Decimal(0), Decimal("Infinity")))
                if bound_type in {"UP", "UI"}:
                    ub = bound_value
                elif bound_type in {"LO", "LI"}:
                    lb = bound_value
                elif bound_type == "FX":
                    lb = ub = bound_value
                elif bound_type == "BV":
                    lb, ub = Decimal(0), Decimal(1)
                bounds[variable] = (lb, ub)

    violations = []
    for row, sense in senses.items():
        if sense == "L":
            violation = max(Decimal(0), activity[row] - rhs[row])
        elif sense == "G":
            violation = max(Decimal(0), rhs[row] - activity[row])
        else:
            violation = abs(activity[row] - rhs[row])
        if violation:
            violations.append((violation, row, activity[row], sense, rhs[row]))
    violations.sort(reverse=True)
    bound_violations = []
    integrality_violations = []
    for variable in variable_names:
        value = values.get(variable, Decimal(0))
        lb, ub = bounds.get(variable, (Decimal(0), Decimal("Infinity")))
        violation = max(Decimal(0), lb - value, value - ub)
        if violation:
            bound_violations.append((violation, variable, value, lb, ub))
        if value != value.to_integral_value():
            integrality_violations.append((abs(value - value.to_integral_value()), variable, value))

    output = {
        "arithmetic": "Python Decimal, precision 50; finite-decimal MPS tokens parsed directly without Gurobi",
        "objective_exact_decimal": str(objective),
        "model_variable_count": len(variable_names),
        "solution_listed_count": len(values),
        "row_count": len(senses),
        "unknown_solution_names": sorted(set(values) - variable_names),
        "missing_solution_names_assumed_zero": len(variable_names - set(values)),
        "max_row_violation_exact": str(max((x[0] for x in violations), default=Decimal(0))),
        "violating_row_count": len(violations),
        "max_bound_violation_exact": str(max((x[0] for x in bound_violations), default=Decimal(0))),
        "bound_violation_count": len(bound_violations),
        "max_integrality_violation_exact": str(max((x[0] for x in integrality_violations), default=Decimal(0))),
        "integrality_violation_count": len(integrality_violations),
        "feasible_exact_decimal": not violations and not bound_violations and not integrality_violations,
        "worst_rows": [[str(a), b, str(c), d, str(e)] for a, b, c, d, e in violations[:20]],
    }
    Path(args.out).write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
