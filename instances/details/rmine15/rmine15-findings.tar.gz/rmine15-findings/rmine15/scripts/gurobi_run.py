import argparse
import gzip
import json
import math
import time
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def read_solution(path):
    opener = gzip.open if path.endswith(".gz") else open
    values = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
        for raw in handle:
            line = raw.strip()
            if not line or line.startswith("#") or line.startswith("=obj="):
                continue
            parts = line.split()
            if len(parts) >= 2:
                values[parts[0]] = float(parts[1])
    return values


def status_name(status):
    return {
        GRB.OPTIMAL: "OPTIMAL",
        GRB.TIME_LIMIT: "TIME_LIMIT",
        GRB.INFEASIBLE: "INFEASIBLE",
        GRB.INF_OR_UNBD: "INF_OR_UNBD",
        GRB.UNBOUNDED: "UNBOUNDED",
        GRB.INTERRUPTED: "INTERRUPTED",
        GRB.SUBOPTIMAL: "SUBOPTIMAL",
        GRB.USER_OBJ_LIMIT: "USER_OBJ_LIMIT",
        GRB.WORK_LIMIT: "WORK_LIMIT",
        GRB.MEM_LIMIT: "MEM_LIMIT",
    }.get(status, f"STATUS_{status}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", required=True)
    parser.add_argument("--start", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--sol", required=True)
    parser.add_argument("--log", required=True)
    parser.add_argument("--seconds", type=float, default=600)
    parser.add_argument("--threads", type=int, default=3)
    parser.add_argument("--strategy", choices=["primal", "balanced", "dual"], default="primal")
    args = parser.parse_args()

    start_wall = time.monotonic()
    model = gp.read(args.mps)
    starts = read_solution(args.start)
    for variable in model.getVars():
        variable.Start = starts.get(variable.VarName, 0.0)

    model.Params.LogFile = args.log
    model.Params.TimeLimit = args.seconds
    model.Params.Threads = args.threads
    model.Params.Seed = 15092026
    model.Params.FeasibilityTol = 1e-8
    model.Params.IntFeasTol = 1e-8
    model.Params.NumericFocus = 2
    model.Params.Presolve = 2
    model.Params.Cuts = 3
    model.Params.Symmetry = 2
    model.Params.ConcurrentMIP = 1
    if args.strategy == "primal":
        model.Params.MIPFocus = 1
        model.Params.Heuristics = 0.5
        model.Params.NoRelHeurTime = min(180.0, max(0.0, args.seconds * 0.3))
        model.Params.RINS = 50
        model.Params.PumpPasses = 50
        model.Params.ImproveStartTime = min(240.0, args.seconds * 0.45)
    elif args.strategy == "dual":
        model.Params.MIPFocus = 3
        model.Params.Heuristics = 0.02
        model.Params.NodeMethod = 1
        model.Params.VarBranch = 1
    else:
        model.Params.MIPFocus = 2
        model.Params.Heuristics = 0.1

    events = []

    def callback(cb_model, where):
        if where == GRB.Callback.MIPSOL:
            events.append({
                "elapsed": time.monotonic() - start_wall,
                "objective": cb_model.cbGet(GRB.Callback.MIPSOL_OBJ),
                "bound": cb_model.cbGet(GRB.Callback.MIPSOL_OBJBND),
                "nodes": cb_model.cbGet(GRB.Callback.MIPSOL_NODCNT),
            })

    model.optimize(callback)
    if model.SolCount:
        model.write(args.sol)

    result = {
        "instance": model.ModelName,
        "strategy": args.strategy,
        "elapsed_seconds": time.monotonic() - start_wall,
        "solver_runtime": model.Runtime,
        "status_code": model.Status,
        "status": status_name(model.Status),
        "solution_count": model.SolCount,
        "objective": model.ObjVal if model.SolCount else None,
        "bound": model.ObjBound if math.isfinite(model.ObjBound) else None,
        "gap": model.MIPGap if model.SolCount and math.isfinite(model.MIPGap) else None,
        "nodes": model.NodeCount,
        "iterations": model.IterCount,
        "events": events,
        "optimality_claim": model.Status == GRB.OPTIMAL,
    }
    Path(args.out).write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
