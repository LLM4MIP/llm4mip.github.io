import argparse
import gzip
import json
import re
from collections import defaultdict
from pathlib import Path

import gurobipy as gp


VAR_RE = re.compile(r"^x_B(\d+)_t(\d+)$")


def read_solution(path):
    opener = gzip.open if path.endswith(".gz") else open
    values = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
        for raw in handle:
            pieces = raw.split()
            if len(pieces) >= 2 and not raw.startswith(("#", "=obj=")):
                values[pieces[0]] = float(pieces[1])
    return values


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", required=True)
    parser.add_argument("--a", required=True)
    parser.add_argument("--b", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    model = gp.read(args.mps)
    model.Params.OutputFlag = 0
    va = read_solution(args.a)
    vb = read_solution(args.b)
    by_block = defaultdict(list)
    objective_a = model.ObjCon
    objective_b = model.ObjCon
    differing_variables = []
    for variable in model.getVars():
        match = VAR_RE.match(variable.VarName)
        if match:
            by_block[int(match.group(1))].append((int(match.group(2)), variable))
        xa = va.get(variable.VarName, 0.0)
        xb = vb.get(variable.VarName, 0.0)
        objective_a += variable.Obj * xa
        objective_b += variable.Obj * xb
        if abs(xa - xb) > 0.5:
            differing_variables.append(variable.VarName)
    moved = []
    for block, entries in by_block.items():
        entries.sort()
        pa = min((t for t, v in entries if va.get(v.VarName, 0) > 0.5), default=15)
        pb = min((t for t, v in entries if vb.get(v.VarName, 0) > 0.5), default=15)
        if pa != pb:
            ca = sum(v.Obj for t, v in entries if t >= pa) if pa < 15 else 0.0
            cb = sum(v.Obj for t, v in entries if t >= pb) if pb < 15 else 0.0
            moved.append({
                "block": block,
                "period_a": pa,
                "period_b": pb,
                "objective_a": ca,
                "objective_b": cb,
                "objective_delta": cb - ca,
            })
    output = {
        "objective_a": objective_a,
        "objective_b": objective_b,
        "improvement_a_minus_b": objective_a - objective_b,
        "differing_variable_count": len(differing_variables),
        "moved_block_count": len(moved),
        "moved_blocks": sorted(moved, key=lambda r: r["block"]),
    }
    Path(args.out).write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
