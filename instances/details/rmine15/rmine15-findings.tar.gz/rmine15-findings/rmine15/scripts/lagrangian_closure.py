import argparse
import json
import math
import time
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--log", required=True)
    parser.add_argument("--seconds", type=float, default=600)
    parser.add_argument("--upper-bound", type=float, required=True)
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()

    wall_started = time.monotonic()
    original = gp.read(args.mps)
    original.Params.OutputFlag = 0
    original.update()
    original_vars = original.getVars()
    capacity_rows = [c for c in original.getConstrs() if c.ConstrName.startswith("tcap_")]
    resources = []
    for row in capacity_rows:
        expression = original.getRow(row)
        resources.append({
            "name": row.ConstrName,
            "rhs": row.RHS,
            "indices": [expression.getVar(j).index for j in range(expression.size())],
            "coefficients": [expression.getCoeff(j) for j in range(expression.size())],
        })

    closure = original.copy()
    closure.Params.OutputFlag = 0
    closure.Params.LogFile = args.log
    closure.Params.Threads = args.threads
    closure.Params.Method = 1
    closure.Params.Presolve = 1
    closure.Params.FeasibilityTol = 1e-8
    closure.Params.OptimalityTol = 1e-8
    closure.remove([c for c in closure.getConstrs() if c.ConstrName.startswith("tcap_")])
    for variable in closure.getVars():
        variable.VType = GRB.CONTINUOUS
    closure.update()
    variables = closure.getVars()
    base_objective = [v.Obj for v in original_vars]
    lambdas = [0.0] * len(resources)
    best_bound = -math.inf
    best_record = None
    history = []
    scale = 1.8
    nonimproving = 0

    for iteration in range(1, 101):
        remaining = args.seconds - (time.monotonic() - wall_started)
        if remaining <= 1.0:
            break
        modified = base_objective.copy()
        constant = original.ObjCon
        for multiplier, resource in zip(lambdas, resources):
            constant -= multiplier * resource["rhs"]
            if multiplier:
                for index, coefficient in zip(resource["indices"], resource["coefficients"]):
                    modified[index] += multiplier * coefficient
        closure.ObjCon = constant
        for variable, coefficient in zip(variables, modified):
            variable.Obj = coefficient
        closure.Params.TimeLimit = remaining
        closure.update()
        solve_started = time.monotonic()
        closure.optimize()
        solve_seconds = time.monotonic() - solve_started
        if closure.Status != GRB.OPTIMAL:
            history.append({
                "iteration": iteration,
                "status": closure.Status,
                "solve_seconds": solve_seconds,
                "reason": "closure LP not solved to optimality; no bound recorded",
            })
            break
        values = [v.X for v in variables]
        q = closure.ObjVal
        activities = []
        subgradient = []
        for resource in resources:
            activity = sum(values[i] * a for i, a in zip(resource["indices"], resource["coefficients"]))
            activities.append(activity)
            subgradient.append(activity - resource["rhs"])
        fractionality = max((abs(x - round(x)) for x in values), default=0.0)
        feasible = all(g <= 1e-7 for g in subgradient)
        primal_objective = original.ObjCon + sum(c * x for c, x in zip(base_objective, values))
        improved = q > best_bound + 1e-8
        if improved:
            best_bound = q
            best_record = {
                "iteration": iteration,
                "numerical_global_lower_bound": q,
                "multipliers": lambdas.copy(),
                "resource_activities": activities,
                "maximum_fractionality": fractionality,
            }
            nonimproving = 0
        else:
            nonimproving += 1
            if nonimproving >= 5:
                scale *= 0.6
                nonimproving = 0
        norm2 = sum(g * g for g in subgradient)
        polyak_gap = max(0.0, args.upper_bound - q)
        step = scale * polyak_gap / norm2 if norm2 > 1e-20 else 0.0
        history.append({
            "iteration": iteration,
            "solve_seconds": solve_seconds,
            "bound": q,
            "best_bound": best_bound,
            "raw_closure_original_objective": primal_objective,
            "raw_closure_resource_feasible": feasible,
            "maximum_capacity_excess": max(subgradient),
            "minimum_capacity_slack": min(-g for g in subgradient),
            "maximum_fractionality": fractionality,
            "subgradient_norm2": norm2,
            "polyak_step": step,
            "scale": scale,
        })
        Path(args.out).write_text(json.dumps({
            "method": "projected_polyak_subgradient_lagrangian_maximum_closure",
            "classification": "NUMERICAL_GLOBAL_LOWER_BOUND",
            "elapsed_seconds": time.monotonic() - wall_started,
            "upper_bound_used_only_for_step_size": args.upper_bound,
            "resource_rows_dualized": len(resources),
            "precedence_rows_retained": closure.NumConstrs,
            "best": best_record,
            "history": history,
            "exact_certificate": False,
            "global_optimality_claim": False,
            "caveat": "Each value is a valid Lagrangian lower bound in exact arithmetic. Gurobi and multipliers use floating point, so values are numerical evidence, not a rational certificate.",
        }, indent=2), encoding="utf-8")
        if step == 0.0:
            break
        lambdas = [max(0.0, value + step * gradient) for value, gradient in zip(lambdas, subgradient)]

    print(Path(args.out).read_text(encoding="utf-8"))
    closure.dispose()
    original.dispose()


if __name__ == "__main__":
    main()
