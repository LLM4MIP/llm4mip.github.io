#  rmine15 precedence-clique cut experiment

## Conclusion

In `agent-dual-family/rmine15/rmine15-prefix-pairs.mps.gz`, the 121 clause has verification pair cuts for fixed baselines, with three rounds of finite clique separation:

|  Project |  Numerical |
|---|---:|
| 121 -pair Baseline root LP |  -5042.229627238623  |
| Add the root LP after clicking |  -5042.036233392005  |
| Additional improvements to the root LP |  0.193393846618  |
| Added size>= 3 clique cuts |  61  |
| Maximum clique has been added | 12 single node |
| Separation When used |  139.49 s  |

Each round of continuous LP:

|  Round | New cuts |  root LP  | Relative paired baseline increases |
|---:|---:|---:|---:|
| 1 | 40 | -5042.040480485482 | 0.189146753141 |
| 2 | 20 | -5042.036466230039 | 0.193161008584 |
| 3 | 1 | -5042.036233392005 | 0.193393846618 |

The exact max-flow/min-cut certificate for the pair baseline and the final model is produced with LP row dual, respectively, by:

```text
121-pair strict LB
  = -25211148136193234027920119679 / 5000000000000000000000000
  = -5042.229627238646806

pair + clique strict LB
  = -5042036233392018593064500651 / 1000000000000000000000000
  = -5042.036233392018593

strict improvement = 0.193393846628213
```

This indicates that the clique improvement is not root-LP numerical noise. However, it is still lower than the numerical dual `-5026.70481` h of the work area COPT 10; the experiment answers that the clique improves structured root relaxation without claiming to update the COPT 10 h global lower bound.

##  Finite candidate chart

The script reads the 121 row seed pair from the family result, with only the period `0,8,9,10` in which it appears charted. Each period retains all seed endpoints and adds a maximum of 60 with a high LP value fractional, 60 with a high closure-pressure fractional and 30 with a high pressure integral candidate. All pairs return to the official MPS, using exact rational numerical weighting cycles with precedence closure union and cumulative resource capacity.

|  period  |  seed nodes  |  candidate nodes  |  exact edges  |  size>=3 maximal cliques  | The largest candidate clique | enumeration Disconnected |
|---:|---:|---:|---:|---:|---:|---|
| 0 | 5 | 145 | 685 | 915 | 7 | false |
| 8 | 56 | 156 | 1016 | 1983 | 12 | false |
| 9 | 22 | 152 | 537 | 462 | 7 | false |
| 10 | 16 | 150 | 33 | 0 | 2 | false |

In addition to 2,271 article candidate-graph edges, the four-phase maximal-clique enumeration is complete without touching the 100,000 upper limit for each period. The maximal here is only relative to the finite candidate graph that is clearly recorded, not the complete 42,438 variable conflict graph.

The new clique is distributed:

-  period 8: 1 bar size- 4, 16 bar size- 11, 4 bar size- 12;
-  period 9: 2 bar size- 3, 4 bar size- 4, 14 bar size- 5, 3 bar size- 6, 17 bar size- 7;
-  0, 10 No violation of size>= 3 clique

The clique violation at separation is approximately `0.05363` to `1.75164`.

## exact verification

`validate_clique_rmine15.py` independently reads official MPS and verification:

1.  121 / 121 seed pairs are all introduced by the strict cumulative capacity excess of the original with the same cycle closure union;
2.  The four candidate graphs are reconstructed in full, along the 2,271 / 2,271 bar and graph hash;
3.  Each pair of nodes in the 61 / 61 bar clique is an exact conflict;
4.  The `certified_family_pair_*` rows of seed MPS are consistent with family results;
5.  Finally, MPS does not change the variable, objective or precedence arcs;
6.  The new `certified_clique15_*` row coefficients are 1, RHS is 1, and there are no additional rows.

The minimum exact excess of all clique pairs that have been added is:

```text
13007841 / 1000000 = 13.007841
```

official MPS SHA- 256 : 

```text
7ec66fb34e25652563e276739f579cc2968807edccf40322b6b3f9b7acd522c7
```

121-pair MPS SHA-256：

```text
4a9fa814e0eb0f36ecb819737a9cbe6bad3710787546a08ab7f10f236cd7fadc
```

pair+clique MPS SHA-256：

```text
1fdcf3c988f8719588766f576c77311bd88012878fcf893d47564d03538ecdae
```

The strict lower bound also requires two layers of evidence: validator first proof 121 pair + 61 clique valid for the official model; flow=cut certificate further proof reinforces the model's lower bound validity.

## file

-  `../artifacts/proof-bundle/agent-clique-rmine15/clique_experiment_rmine15.py`: finite candidate chart, maximum/maximum-weight clique separation;
-  `../artifacts/proof-bundle/agent-clique-rmine15/validate_clique_rmine15.py`: independent original - MPS cut/graph/model validator;
-  `../artifacts/proof-bundle/agent-clique-rmine15/run/result.json`: complete candidate nodes, graph hashes, round-by-round and clique pair witnesses;
-  `../artifacts/proof-bundle/agent-clique-rmine15/run/validation.json`: results of independent cut verification;
-  `../artifacts/proof-bundle/agent-clique-rmine15/run/rmine15-pairs-plus-cliques.mps.gz`: 121 pair + 61 clique model;
- `../artifacts/exact-bound/exact-lb-lambda.json`、
`../artifacts/exact-bound/exact-lb-cert.json.gz` and
`../artifacts/exact-bound/exact-lb-verification.json`: Final strict certificate and verification results.

To avoid repetition, the release package does not retain a pair-only flow/cut file that has been governed by the final certificate;
cuts itself, pair-enhanced MPS and validator are both retained in full.
`../artifacts/proof-bundle/README.md`。

## scope

-  Finite candidate graphs were constructed in only four seed periods without complete conflict-graph separation.
-  Add only the size>= 3 clique and the gain is not due to the new size-2 pair rows;
-  The different sides of the clique can be proven by different resource proof conflicts; the non-coexistence is already enough to introduce `sum_{i in Q}x_i<=1`;
-  Complete only solution, continuous LP, finite chart enumeration and closure min-cut, without launching long original MIP;
-  The total run was significantly below the 15 minute budget.
