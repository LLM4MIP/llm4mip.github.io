#  rmine15 background information ((checked at 2026 -09 -08))

This document only records the official instance pages, author papers or pre-printed papers that were actually used in this study. The MIPLIB page of `rmine15` itself notes that there is no exclusive bibliographic information, so the instance background needs to be cross-confirmed from similar model papers that the submitter participated in.

1.  **MIPLIB official instance page**
   https://miplib.zib.de/instance_details_rmine15.html  
Purpose: confirm the open status, submitter Daniel Espinoza, the `rmine` group, the public objective `-5018.819990999996`, and the official description of a cubic ore body with multiple periods and two knapsack constraints per period. The page also records that Gurobi 9.1 NoRel heuristic found the public solution on 2020-11-25.

2. **MIPLIB official original MPS**
   https://miplib.zib.de/WebData/instances/rmine15.mps.gz  
Purpose: All structural recovery, solve and feasibility audits are available here.

3. **MIPLIB official public solution (solution 2 )**
   https://miplib.zib.de/downloads/solutions/rmine15/2/rmine15.sol.gz  
   Purpose: public-incumbent warm start and independent variable-by-variable and row-by-row verification.

4. **Chicoisne, Espinoza, Goycoolea, Moreno, Rubio (2012), _A New Algorithm for the Open-Pit Mine Production Scheduling Problem_, Operations Research 60(3):517–528.**  
   DOI: https://doi.org/10.1287/opre.1120.1050  
   Official journal page: https://pubsonline.informs.org/doi/abs/10.1287/opre.1120.1050
Purpose: to confirm the cumulative variable explanation, gradient precedence, phased capacity, and discounted net present value context; the paper proposes single capacity LP decomposition, topological sequencing, and local search. This directly supports the study in prioritizing the period exact rearrangement window arrays, rather than just running anonymous MIP parameters.

5. **Bienstock and Zuckerberg (2009), _A New LP Algorithm for Precedence Constrained Production Scheduling_.**  
Published by https://optimization-online.org/wp-content/uploads/2009/08/2380.pdf
Use: The paper describes the mining scheduling as maximum-weight closure/min-cut plus minor side constraints; this coincides with the 358,365 article precedence line in this instance, only the 30 article capacity line complete. Its conclusion explains why Lagrangian/min-cut and decomposition are natural global lower bound route.

6. **Boland, Froyland, Fricke (2007/2009), _A strengthened formulation and cutting planes for the open pit mine production scheduling problem_.**  
   Optimization Online：https://optimization-online.org/2007/03/1624/  
Usage: The author combines precedence with production capacity as a precedence-constrained knapsack, and uses the cover/clique class inequality to enhance the LP; this Gurobi experiment thus opens up aggressive cover/MIR/flow-cover cuts, and further induced-cover separation is listed as a major follow-up direction.

7. **Rivera Letelier, Espinoza, Goycoolea, Moreno, Muñoz (2020), _Production Scheduling for Strategic Open Pit Mine Planning: A Mixed-Integer Programming Approach_, Operations Research 68(5):1425–1444.**  
   DOI: https://doi.org/10.1287/opre.2019.1965  
Purpose: Identify that modern large-scale methods rely on preprocessing, production cuts, heuristics, and branch-and-bound customization; and that strict closure gaps in large instances are often far more difficult than finding a high-quality feasible solution.

##  Direct structural compatibility with this instance

-  `x_Bb_t=1`: Mining of `b` was completed before the end of the period `t`.
-  `tprec_Bb_t`: `x[b,t] <= x[b,t+1]`, which guarantees cumulative state harmonics.
-  `gprec_Bb_Bp_t`: `x[b,t] <= x[p,t]`, before mining the lower layer of the block, the front slope of the drive must be excavated.
-  `tcap_c{0,1}_t`: The two types of resources are the incremental capacity primal bound of `x[b,t]-x[b,t-1]`.
-  The objective coefficients on the same block of mines vary according to the 0.9 ratio over time, corresponding to the discounted net present value; hence, when capacity and slope constraints permit, blocks of value tend to advance, and blocks of cost tend to delay.
