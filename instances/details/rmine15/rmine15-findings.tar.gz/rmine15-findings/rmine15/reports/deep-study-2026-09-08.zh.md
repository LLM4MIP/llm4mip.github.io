#  `rmine15` in-depth research report

Date of study: 2026 -09 -08 (Asia/Shanghai)
The study was carried out in the following areas: 00: 10: 28 00: 52: 11
The actual time of the wall clock: 2,502.96 seconds (41 minutes 42.96 seconds)
Minimum search time required by the user: 2,400 seconds, satisfied.

##  Conclusions

This round finds a new primal solution **strictly feasible**:

-  MIPLIB public objective (recalculation of decimal coefficients directly according to the original MPS): `-5018.819991000000004879`
-  New objective: `-5018.823005000000004879`
- Improvement: `0.003014000000000000`
-  New solution file: [ `results/rmine15-improved-5018.823005.sol` ](../solutions/rmine15-improved-5018.823005.sol)
- SHA-256：`98EE687E2B4CDA23C78944EA438A6A5A72EA1F7B045BDDF82C0DC6FFD67B9C75`

This is not a false improvement due to floating-point tolerance: the new solution is first recalculated by Gurobi on the 358,395 line of the original MPS, and then by an independent MPS/solution parser that does not call Gurobi using the 50 bit `Decimal` per verification variable boundary, integrality and own; the biggest violation is the exact `0`.

However, this round **has no proof global optimal**. The existing global lower bound remains distant from the new primal; all zero-gap inferences apply only to the fixed local neighborhoods specified in the report.

##  1. Data sources and model background

Both MPS and public solution are downloaded directly from the official MIPLIB page, and the hash files are as follows:

|  file |  SHA-256  |
|---|---|
| `rmine15.mps.gz` | `7EC66FB34E25652563E276739F579CC2968807EDCCF40322B6B3F9B7ACD522C7` |
| `rmine15-public.sol.gz` | `7C4AF284B2DCB16BAF897AD5D76241DDD02E4E9503BCFFD2876502143471E399` |

MIPLIB describes it as: multi-period open pit mining on a cubic mineral body, with two knapsack capacity constraints for each period. The public incumbent is Edward Rothberg, who found 2020 -11 -25 using the Gurobi 9.1 NoRel heuristic.

The paper suggests that the core of this type of problem is: determining which blocks are mined; when to mined; maximizing discounted net present value under slope stability precedence and phase-by-phase resource capacity. If a small amount of capacity marginal constraint is removed, the model is maximum-weight closure, which can be reduced to a minimum `s-t` cut; the paper also recommends the use of topological chambers, local search, production/cover cuts, and customized branch-and-bound.

For a full handful of references and the use of the data in this study, see [`sources.md` ](SOURCES.md)].

##  2. Gurobi Structure Reading results

First, read the original MPS without assuming problem semantics. Gurobi 13.0.2 reports:

|  Project |  Count |
|---|---:|
|  Variables |  42,438  |
| `0 <= x <= 1` is an integer variable |  42,438  |
|  continuous variables |  0  |
|  constraint |  358,395  |
| Non-zero coefficients |  879,732  |
|  Mining blocks |  3,375  |
|  Period |  15(`t=0,...,14`)  |

Line names, coefficients and variable names can be undisputedly recovered:

| constraint people |  Count |  Meaning |
|---|---:|---|
|  `gprec_*`  |  319,302  | Space slope precedence for the same period: `x[b,t] <= x[p,t]` |
|  `tprec_*`  |  39,063  | Intermediate cumulative monotony: `x[b,t] <= x[b,t+1]` |
|  `tcap_*`  |  30  | 15 increase capacity of resources of the 2 class for each period |

After deduplication there are 25,886 spatial precedence arcs between mining blocks. Cumulative variable `x_Bb_t=1` means block `b` has been mined by the end of period `t`. Capacity rows measure `x[b,t]-x[b,t-1]`, so they constrain newly mined volume in each period.

The structure is very special: the 358,365 line maintains a closed/network structure, only the 30 line capacity destroys it.

Structure and public solution audit original records:[ `results/structure-public-audit.json` ](../artifacts/structure-public-audit.json).

##  3. public solution features

The public solution extracts 3,303 mining blocks and leaves 72 unmined. Extraction by period is:

`234, 229, 228, 220, 221, 220, 214, 222, 205, 225, 229, 217, 225, 217, 197`。

The capacity utilization rate is very high: in the 30 line of capacity, the 20 line slack is smaller than 10, and the 27 line is smaller than 100; the minimum slack is only `0.134039`. Therefore, simply pre-loading high-value blocks is usually infeasible, and several blocks must be delayed simultaneously or over multiple periods to form a resource balance exchange.

Another useful fact is that the individual objective coefficients of the 72 unmined blocks in the final phase are positive. Adding them to the final pit itself adds to the minimization objective; changing the final mining set can only be advantageous if the precedence/benefit portfolio of a set of blocks can offset these costs.

For more details on output and capacity activities see [`results/public-schedule-summary.json` ](../artifacts/public-schedule-summary.json)].

##  4 . solve route and results

###  4.1 General Gurobi strong primal baseline

Warm-started from the public solution, with aggressive cuts, a higher heuristic fraction, RINS, feasibility pump and 180 seconds of NoRel; total runtime was approximately 600 seconds.

The result: no better solution than the public solution was found, and no root node was completed. This result indicates that the marginal value of the continued stack of general parameters is not high. The barrier to root relaxation was given a numerical point of about `-5042.48297`, but the crossover was not completed within the time limit, so this report does not register it as a new completed lower bound result.

Evidence: `results/gurobi-primal-600s.json` ](../artifacts/gurobi-primal-600s.json) and `logs/gurobi-primal-600s.log` ](../logs/gurobi-primal-600s.log).

###  4.2 instance exclusive period window

All of the minerals in the `[a,b]` in the sequential window are located in the period of extraction in the seed schedule:

1.  The total cumulative variable of the out-of-window blocks is fixed as seed;
2.  Mining blocks within the window can be arbitrarily and jointly redistributed in the window;
3.  All original precedence and two categories of capacity constraints are retained;
4.  Use the original MPS objective to set `MIPGap=0`, `MIPGapAbs=0`;
5.  Only solver objective and bound closure are marked as local zero gaps.

This is not a block-by-block greedy move. Hundreds to thousands of blocks of minerals can be grouped and exchanged in a single window.

####  Round one: public solution for seed

-  14 neighbouring binary period windows are all zero gaps, with no improvement.
-  13 three consecutive period windows are all zero gaps.
-  The only improvement occurred was the `[7,9]`, which received `-5018.823005`.

The two-period neighborhood did not see this improvement, because the new layout required three periods to form a joint capacity balance cycle, containing a two-phase movement of the `7 -> 9`.

Evidence:

- [`results/pair-windows-exact-30s.json`](../artifacts/pair-windows-exact-30s.json)
- [`results/triple-windows-exact-60s.json`](../artifacts/triple-windows-exact-60s.json)

Note: The `pair-windows-30s.json` is a pilot that was found to have retained the default relative gap after returning `OPTIMAL` prematurely, and cannot serve as proof of a zero gap; the `pair-windows-exact-30s.json` above is the official result of correction.

#### Second round: use the new solution as the seed

Resolving all three consecutive period windows for 13, 13 all return to the same new objective below zero gap.

>  The new solution is a locally optimal solution of the combined rearrangement neighborhood of three consecutive periods.

This is not a globally optimal proof, as adjustments across four or more periods can still be improved.

The evidence:[ `results/triple-windows-iteration2.json` ](../artifacts/triple-windows-iteration2.json).

####  Greater windows

| Neighborhood group | Number of trials | Zero gap |  Time limit  | New improvements |
|---|---:|---:|---:|---:|
| Four consecutive periods |  12  |  6  |  6  |  0  |
| Selected neighborhood (with 72 unexcavated block) |  4  |  3  |  1  |  0  |
| Focus five periods `[5,9]` , `[6,10]` , `[7,11]` |  3  |  0  |  3  |  0  |
|  Five periods `[8,12]` |  1  |  0  |  1  |  0  |

The windows that completed the proof in the four period were `[1,4]` , `[2,5]` , `[3,6]` , `[4,7]` , `[8,11]` , `[11,14]`; the other four period windows can only be described as 90 in seconds without finding any improvement.

Later selected neighborhoods will simultaneously release blocks that have been mined and all 72 unmined blocks in the window, thus changing the final pit membership. `[13,14]`, `[12,14]`, `[11,14]` have zero gap and no improvement; `[10,14]` has no closure time limit in 120 seconds.

All five period experiments are time limits and cannot be written as locally optimal proof.

Evidence:

- [`results/four-windows-exact-90s.json`](../artifacts/four-windows-exact-90s.json)
- [`results/late-selection-windows-120s.json`](../artifacts/late-selection-windows-120s.json)
- [`results/focused-five-windows-180s.json`](../artifacts/focused-five-windows-180s.json)
- [`results/focused-five-right-120s.json`](../artifacts/focused-five-right-120s.json)

The official test window has a total of 60, of which 49 has zero gap completion, 11 time limit.

###  4.3 Lagrangian maximum closed lower bound

The 30 line capacity is dualized to a nonnegative multiple, retaining the 358,365 line precedence line. Each Lagrangian subproblem is a linear optimization on a closed multi-dimensional object; the maximum fractionality of the 100 oracle solution in the experiment is 0.

The projected Polyak subgradient:

-  The first closure LP/oracle is approximately 262.6 seconds;
-  0.4 aluminum 0.8 seconds after most heat switches are activated;
-  525 completes the 100 oracle in seconds;
-  Best numerical Lagrangian lower bound: `-5053.960722050726` (95)

This structurally valid but weak numerical lower bound does not exceed `-5026.70481` from the existing 10-hour COPT run in the workspace. Thus this round **claims no dual-bound improvement**. Naive subgradient updates oscillated strongly in the 30-dimensional capacity multipliers; future proof work should use Bienstock-Zuckerberg-style restricted-master/bundle stabilization instead of merely adding subgradient iterations.

Evidence:[ `results/lagrangian-closure-600s.json` ](../artifacts/lagrangian-closure-600s.json). The lower bound uses floating-point Gurobi and floating-point multiples, belonging to the numerical bound and not to the rational certificate.

##  5. How to improve the new solution

The final set of mined blocks is unchanged: 3,303 mined and 72 unmined. The mining periods of 34 blocks changed, with 35 cumulative binary variables flipped:

|  Move | Mining blocks |
|---|---:|
| `7 -> 8` | 13 |
| `8 -> 7` | 12 |
| `9 -> 8` | 5 |
| `8 -> 9` | 3 |
| `7 -> 9` | 1 |

The number of quarries per period varies accordingly:

-  7 period: 222 → 220
-  8 period: 205 → 208
-  9 period: 225 → 224

The objective contribution changes to:

-  7 period: `+0.017541` (difference)
-  8 period: `-0.063467` (improved)
-  9 period: `+0.042912` (difference)
-  Total: `-0.003014` (net improvement)

This illustrates the typical feature of the problem: the improvement is not to advance the best blocks of a single nickel, but to allow a group of mineral blocks to complete cross-period exchanges under the almost identical capacity and precedence of the two types of nickel. The 8 term resource slack from the public solution `(1.747079, 12.310514)` is narrowed down to `(0.799249, 6.712778)`; the 9 term releases some capacity.

Changes by block: [`results/public-vs-new.json`](../artifacts/public-vs-new.json).

## 6 . strict verification

###  6.1 original MPS + Gurobi independent recalculation

Re-read `.sol` as a numerical vector and calculate the bounds, integrality and coefficients for each row directly from the original MPS:

|  Metric |  result |
|---|---:|
| Recalculating Objective |  `-5018.823005`  |
| Maximum bound violation |  0  |
| The biggest violation of integrity |  0  |
| Maximum row violation |  0  |
| `>1e-9` violation of the law |  0  |

The evidence:[ `results/new-incumbent-audit.json` ](../artifacts/new-incumbent-audit.json).

###  6.2 does not rely on Gurobi's decimal verification

The independent script directly parse the ROWS/COLUMNS/RHS/BOUNDS sections of the MPS and `.sol`, plus the 879,732 coefficient with the 50 bit `Decimal`:

|  Metric |  Public solution |  New solution |
|---|---:|---:|
| Exact decimal objective |  `-5018.819991000000004879`  |  `-5018.823005000000004879`  |
|  row violation |  0  |  0  |
|  bound violation |  0  |  0  |
| integer violated |  0  |  0  |

Evidence:

- [`results/public-exact-decimal-audit.json`](../artifacts/public-exact-decimal-audit.json)
- [`results/new-incumbent-exact-decimal-audit.json`](../artifacts/new-incumbent-exact-decimal-audit.json)

##  7. Why can't we say optimal yet?

The existing 10-hour COPT experiment in the workspace records numerical dual bound `-5026.70481`. The remaining interval with the new primal bound is:

-  The absolute gap: `7.881805`
-  Relative gap: about `0.157045%`

The COPT value is simply the numerical output of a solver run, not the independent certificate generated by this round, and the MIPLIB instance page does not list the official dual. Therefore, even if the primal has been strictly verified, `rmine15` cannot be labeled as optimal.

The local proof bars in this report also have strict boundaries: they are Gurobi's numerical branch-and-cut results for fixed neighborhoods under `MIPGap=0`, with no global certificate output that can be replayed independently by a third-party proof checker.

##  8. Experience summarized with the next step

1.  **three period is the smallest effective exchange scale of the instance.** double period is all locally optimal, but three period immediately finds improvement, indicating that the capacity exchange needs to run through at least three phases of closure.
2.  **public solution is already very strong. The combined rearrangement of** 34 blocks only improved `0.003014`, and the new solution was subsequently reviewed through all three period windows.
3.  **'s late local change in pit membership is not easy. After ** releases all of 72's unexcavated blocks, the 11 aluminum 14 period neighborhood remains unimproved by exact proof.
4.  **with NoRel is less efficient than structural neighborhoods.** 600 second General Gurobi has not improved, while the 16 second `[7,9]` exact subproblem has found a new solution.
5.  **The simple Lagrangian subgradient is not enough to advance dual.** should be a stabilized bundle/restricted master and add precedence-induced cover/clique cuts.
6.  **'s most valuable primary route ** is to save/restore the five-period time-limit model from `[6,10]`, `[7,11]`, etc. to branch-and-bound, or to cross-interface the window by spatial precedence cluster after re-division.
7.  **If objective is the official global proof**, complete closure to the new primal, or output independently verifiable branch/cut, OPB/VeriPB, etc. certificates are required; existing documents do not meet this criterion.

##  9. Index of files

-  The following is a summary of the machine:[ `SUMMARY.json` ](../artifacts/summary.json)
- Background source: [`sources.md`](SOURCES.md)
-  The new solution: [ `results/rmine15-improved-5018.823005.sol` ](../solutions/rmine15-improved-5018.823005.sol)
-  Structure and public solution audit:[ `results/structure-public-audit.json` ](../artifacts/structure-public-audit.json)
-  New solution Gurobi audit:[ `results/new-incumbent-audit.json` ](../artifacts/new-incumbent-audit.json)
-  The new solution Decimal audit:[ `results/new-incumbent-exact-decimal-audit.json` ](../artifacts/new-incumbent-exact-decimal-audit.json)
-  Changes to the sequence:[ `results/public-vs-new.json` ](../artifacts/public-vs-new.json)
-  All study scripts:[ `scripts/` ](../scripts/)
-  Gurobi Diary:[ `logs/` ](../logs/)

##  10. Classification of evidence

-  **New strict primal: yes.**
-  **primal compared to MIPLIB improved: yes, improved `0.003014`.**
-  **New global dual bound: no.**
-  **Local zero gap proof: yes, range see section 4.**
-  **global optimal: no.**
-  **independent global certificate: no.**

