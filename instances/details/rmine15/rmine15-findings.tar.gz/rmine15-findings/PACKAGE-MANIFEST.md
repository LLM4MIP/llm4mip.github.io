# Package manifest: rmine15

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 55
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/exact-bound/SHA256SUMS`
- `artifacts/exact-bound/exact-lb-cert.json.gz`
- `artifacts/exact-bound/exact-lb-lambda.json`
- `artifacts/exact-bound/exact-lb-verification.json`
- `artifacts/focused-five-right-120s.json`
- `artifacts/focused-five-windows-180s.json`
- `artifacts/four-windows-exact-90s.json`
- `artifacts/gurobi-primal-600s.json`
- `artifacts/lagrangian-closure-600s.json`
- `artifacts/late-selection-windows-120s.json`
- `artifacts/new-incumbent-audit.json`
- `artifacts/new-incumbent-exact-decimal-audit.json`
- `artifacts/new-incumbent-schedule-summary.json`
- `artifacts/pair-windows-exact-30s.json`
- `artifacts/proof-bundle/README.md`
- `artifacts/proof-bundle/agent-clique-rmine15/clique_experiment_rmine15.py`
- `artifacts/proof-bundle/agent-clique-rmine15/run/result.json`
- `artifacts/proof-bundle/agent-clique-rmine15/run/rmine15-pairs-plus-cliques.mps.gz`
- `artifacts/proof-bundle/agent-clique-rmine15/run/validation.json`
- `artifacts/proof-bundle/agent-clique-rmine15/validate_clique_rmine15.py`
- `artifacts/proof-bundle/agent-clique/clique_experiment.py`
- `artifacts/proof-bundle/agent-dual-family/family_prefix_pair_experiment.py`
- `artifacts/proof-bundle/agent-dual-family/rmine15/result.json`
- `artifacts/proof-bundle/agent-dual-family/rmine15/rmine15-pairs.mps.gz`
- `artifacts/proof-bundle/agent-dual-family/rmine15/verification.json`
- `artifacts/proof-bundle/agent-dual-family/verify_family_result.py`
- `artifacts/proof-bundle/agent-dual/exact_lagrangian_certificate.py`
- `artifacts/public-exact-decimal-audit.json`
- `artifacts/public-schedule-summary.json`
- `artifacts/public-vs-new.json`
- `artifacts/replay-after-publication-copy.json`
- `artifacts/structure-public-audit.json`
- `artifacts/summary.json`
- `artifacts/triple-cover-screen-summary.json`
- `artifacts/triple-cover-screen-validation.json`
- `artifacts/triple-windows-exact-60s.json`
- `artifacts/triple-windows-iteration2.json`
- `input/SHA256SUMS`
- `input/rmine15-public.sol.gz`
- `logs/gurobi-primal-600s.log`
- `logs/triple-window-7-9.log`
- `reports/SOURCES.md`
- `reports/deep-study-2026-09-08.zh.md`
- `reports/exact-pair-clique-bound.md`
- `reports/triple-cover-screen.md`
- `scripts/analyze_structure.py`
- `scripts/compare_schedules.py`
- `scripts/exact_decimal_audit.py`
- `scripts/exact_lagrangian_certificate.py`
- `scripts/gurobi_run.py`
- `scripts/lagrangian_closure.py`
- `scripts/schedule_summary.py`
- `scripts/window_exact.py`
- `solutions/rmine15-improved-5018.823005.sol`

## Excluded files

- `input/rmine15.mps.gz (5175444 bytes; raw benchmark input; sha256 7ec66fb34e25652563e276739f579cc2968807edccf40322b6b3f9b7acd522c7)`
