#!/usr/bin/env python3
"""Validate and normalize the signed-postman structure in neos-3594536-henty."""

import argparse
import collections
import json
import os

from henty_cycle_reducer import (
    audit_vector,
    finite_lb,
    finite_ub,
    graph_analysis,
    identify_network,
    load_and_classify,
    read_solution,
    write_plain_solution,
)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mps")
    ap.add_argument("--solution", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    model, data = load_and_classify(args.mps)
    net = identify_network(data)
    if not net["confirmed"]:
        raise ValueError("The equality matrix is not a directed incidence matrix")

    grouped = collections.defaultdict(list)
    for row, u, v in data["covers"]:
        grouped[tuple(sorted((u, v)))].append(row)

    duplicate_bad = []
    antiparallel_bad = []
    attribute_bad = []
    endpoint_mult = collections.Counter()
    required_edges = []
    cover_variables = set()
    pairs = []
    for pair, rows in sorted(grouped.items()):
        u, v = pair
        cover_variables.update(pair)
        if len(rows) != 2:
            duplicate_bad.append({"pair": pair, "row_count": len(rows)})
        if not (
            net["tails"][u] == net["heads"][v]
            and net["heads"][u] == net["tails"][v]
        ):
            antiparallel_bad.append(
                {
                    "variables": [data["var_names"][u], data["var_names"][v]],
                    "arcs": [
                        [net["tails"][u], net["heads"][u]],
                        [net["tails"][v], net["heads"][v]],
                    ],
                }
            )
        free = all(
            not finite_lb(data["lb"][j]) and not finite_ub(data["ub"][j])
            for j in pair
        )
        equal_positive_cost = data["obj"][u] == data["obj"][v] > 0
        if not free or not equal_positive_cost:
            attribute_bad.append(
                {
                    "variables": [data["var_names"][u], data["var_names"][v]],
                    "free": free,
                    "costs": [data["obj"][u], data["obj"][v]],
                }
            )
        endpoints = tuple(sorted((net["tails"][u], net["heads"][u])))
        endpoint_mult[endpoints] += 1
        required_edges.append(endpoints)
        pairs.append((u, v))

    directed = [j for j in range(len(data["var_names"])) if j not in cover_variables]
    directed_bad = []
    directed_lb_hist = collections.Counter()
    directed_cost_hist = collections.Counter()
    directed_lower_objective = 0
    directed_augmentation_objective = 0
    directed_positive_augmentation_count = 0
    for j in directed:
        if not finite_lb(data["lb"][j]) or finite_ub(data["ub"][j]):
            directed_bad.append(
                {
                    "var": data["var_names"][j],
                    "lb": data["lb"][j],
                    "ub": data["ub"][j],
                }
            )
        else:
            directed_lb_hist[int(round(data["lb"][j]))] += 1
            directed_lower_objective += int(round(data["lb"][j])) * data["obj"][j]
        directed_cost_hist[data["obj"][j]] += 1

    supplied = read_solution(args.solution)
    values = {name: int(supplied.get(name, 0)) for name in data["var_names"]}
    for j in directed:
        augmentation = values[data["var_names"][j]] - int(round(data["lb"][j]))
        directed_augmentation_objective += augmentation * data["obj"][j]
        directed_positive_augmentation_count += int(augmentation > 0)
    original_audit = audit_vector(data, values)
    normalized = dict(values)
    s_hist = collections.Counter()
    target_hist = collections.Counter()
    negative_pair_variables = 0
    physical_violations = 0
    parity_violations = 0
    improvement = 0
    changed_pairs = 0
    max_abs_d = 0
    pair_examples = []
    pair_mandatory_objective = 0
    pair_even_surcharge_objective = 0
    for u, v in pairs:
        un, vn = data["var_names"][u], data["var_names"][v]
        x, y = values[un], values[vn]
        s, d = x + y, x - y
        target = 1 if s % 2 else 2
        pair_mandatory_objective += data["obj"][u]
        pair_even_surcharge_objective += (target - 1) * data["obj"][u]
        if (s - d) % 2:
            parity_violations += 1
        s_hist[s] += 1
        target_hist[target] += 1
        negative_pair_variables += int(x < 0) + int(y < 0)
        physical_violations += int(abs(d) > s)
        max_abs_d = max(max_abs_d, abs(d))
        if s > target:
            shift = (s - target) // 2
            normalized[un] = x - shift
            normalized[vn] = y - shift
            delta = 2 * shift * data["obj"][u]
            improvement += delta
            changed_pairs += 1
            if len(pair_examples) < 25:
                pair_examples.append(
                    {
                        "variables": [un, vn],
                        "before": [x, y],
                        "after": [normalized[un], normalized[vn]],
                        "sum_before": s,
                        "sum_after": target,
                        "objective_improvement": delta,
                    }
                )

    normalized_audit = audit_vector(data, normalized)
    normalized_path = os.path.join(args.out, "normalized.sol")
    write_plain_solution(
        normalized_path, normalized, normalized_audit["objective"]
    )

    report = {
        "instance": model.ModelName,
        "validated_signed_postman": not (
            duplicate_bad or antiparallel_bad or attribute_bad or directed_bad
        ),
        "required_undirected_pairs": len(pairs),
        "cover_rows": len(data["covers"]),
        "cover_variables": len(cover_variables),
        "directed_variables": len(directed),
        "duplicate_cover_check": {
            "bad_count": len(duplicate_bad),
            "examples": duplicate_bad[:25],
        },
        "antiparallel_check": {
            "bad_count": len(antiparallel_bad),
            "examples": antiparallel_bad[:25],
        },
        "pair_attribute_check": {
            "bad_count": len(attribute_bad),
            "examples": attribute_bad[:25],
        },
        "underlying_required_graph": {
            "distinct_endpoint_pairs": len(endpoint_mult),
            "parallel_multiplicity_histogram": dict(
                sorted(collections.Counter(endpoint_mult.values()).items())
            ),
            "loops": sum(1 for (u, v) in endpoint_mult if u == v),
            "graph_analysis": graph_analysis(len(net["eq_rows"]), required_edges),
        },
        "directed_arcs": {
            "bad_bound_count": len(directed_bad),
            "bad_bound_examples": directed_bad[:25],
            "lower_bound_histogram": dict(sorted(directed_lb_hist.items())),
            "negative_cost_count": sum(v for k, v in directed_cost_hist.items() if k < 0),
            "zero_cost_count": directed_cost_hist.get(0, 0),
            "positive_cost_count": sum(v for k, v in directed_cost_hist.items() if k > 0),
            "mandatory_lower_bound_objective": directed_lower_objective,
            "incumbent_positive_augmentation_count": directed_positive_augmentation_count,
            "incumbent_augmentation_objective": directed_augmentation_objective,
        },
        "incumbent": {
            "original_audit": original_audit,
            "pair_sum_histogram": dict(sorted(s_hist.items())),
            "canonical_target_histogram": dict(sorted(target_hist.items())),
            "negative_pair_variable_count": negative_pair_variables,
            "physical_inequality_violation_count": physical_violations,
            "parity_violation_count": parity_violations,
            "max_absolute_signed_flow": max_abs_d,
            "mandatory_one_per_pair_objective": pair_mandatory_objective,
            "even_pair_surcharge_objective": pair_even_surcharge_objective,
            "elementary_objective_lower_bound": (
                directed_lower_objective + pair_mandatory_objective + data["objcon"]
            ),
            "changed_pair_count": changed_pairs,
            "exact_objective_improvement": improvement,
            "normalized_audit": normalized_audit,
            "normalized_solution": normalized_path,
            "changed_pair_examples": pair_examples,
        },
    }
    report_path = os.path.join(args.out, "signed_postman_report.json")
    with open(report_path, "wt", encoding="utf-8") as f:
        json.dump(report, f, indent=2, sort_keys=True)
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
