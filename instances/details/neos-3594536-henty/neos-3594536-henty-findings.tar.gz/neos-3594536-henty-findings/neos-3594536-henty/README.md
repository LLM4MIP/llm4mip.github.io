# neos-3594536-henty

2026-09-14 independent dual-bound review: [adopted bound, proof chain, checks, and limitations](../../docs/dual-bound-audit-2026-09-14/cases/neos-3594536-henty.zh.md). Reviewed lower bound: **approximately 401092**. This review distinguishes exact, literature, and numerical evidence; historical statements below remain dated records.

Status: **computationally solved at 401,092** by an exact structural reduction
and a zero-gap MILP run. The full original-space solution is independently
audited. The lower-bound side is a floating-point branch-and-bound computation,
not a portable exact proof certificate.

The new value improves the MIPLIB incumbent 401,223 by **131** objective units.

[MIPLIB instance page](https://miplib.zib.de/instance_details_neos-3594536-henty.html)

## Recovered structure

The original MPS has 22,924 general integer variables and 21,280 rows. Its
11,348 homogeneous equalities are a directed node-arc incidence system. The
other 9,932 rows are two copies of each of 4,966 pair-cover constraints. Each
pair consists of free antiparallel integer variables with the same positive
cost. The remaining 12,992 directed variables have finite integer lower bounds
and positive costs.

For a required antiparallel pair `(x,y)`, subtracting one from both variables
preserves every balance equation and reduces the objective. Therefore some
optimum has `x+y` in `{1,2}`. Write

```text
r = x+y-1 in {0,1},  k = x-1,
x = k+1,              y = r-k.
```

Here `r` says whether the required edge is duplicated, while `k` is an
unbounded signed flow. For a directed variable at lower bound `l`, write
`x=l+q` with `q>=0` integer. One mandatory copy of every required edge plus all
directed lower bounds costs exactly **347,717**, so the remaining objective is

```text
347717 + sum(c_j q_j) + sum(w_i r_i).
```

## Eliminating all signed flows

The required-edge graph has 6,676 connected components. The 4,966 free `k`
variables can be removed completely. The exact optimum-preserving model keeps
only:

- 12,992 nonnegative integer directed augmentations `q`;
- 4,966 binary required-edge duplications `r`;
- 6,676 component-balance equations; and
- 11,348 node-parity equations, represented with integer quotient variables.

Necessity follows by summing the original balances over every required-edge
component and reducing each node equation modulo two. For sufficiency, the
remaining signed-flow residual is even at every node and has zero sum in every
connected component. After division by two it is an integral zero-sum vector;
the incidence lattice of a connected graph spans every such vector. The
omitted `k` values are therefore reconstructed exactly on a spanning forest.

This is substantially stronger than the earlier signed-postman formulation:
the previous 1,800-second run left `[396954,401154]`, whereas the new model
closed at **401,092** in 188.34 seconds and 64,057 nodes with Gurobi 13.0.1.
At the optimum, the 53,375 units above the fixed base split into 40,468 of
directed augmentation and 12,907 of required-edge duplication; 2,591 directed
augmentations are positive and 1,758 required edges are duplicated.

## Original-model verification

[`solutions/neos-3594536-henty-401092.sol`](solutions/neos-3594536-henty-401092.sol)
contains all 22,924 original variables. Direct evaluation of the original MPS
gives:

- objective: 401,092 exactly;
- bound violations: 0;
- incidence-equality violations: 0;
- pair-cover violations: 0; and
- minimum pair-cover slack: 0.

[`scripts/henty_component_parity.py`](scripts/henty_component_parity.py)
recovers the structure from the MPS, builds the reduced model, maps a reduced
solution back through a spanning forest, and audits the resulting original
vector. [`scripts/henty_copt_recheck.py`](scripts/henty_copt_recheck.py) runs
the same generated MPS with zero relative gap in COPT. Detailed logs and
machine-readable reports are in
[`experiments/component-parity-optimal-20260907/`](experiments/component-parity-optimal-20260907/).

## Evidence boundary

The algebraic reduction and primal audit use integer identities. The archived
Gurobi log reports equal incumbent and global bound with `MIPGap=0`; the COPT
rerun is an independent numerical cross-check. Neither solver emits a DRAT,
LRAT, VIPR, or other independently replayable exact lower-bound certificate.
Accordingly, 401,092 is recorded as a computational global optimum, with the
solver-based proof boundary stated explicitly.

SHA-256:

- MPS: `60A07357C9A195BDC23C6FC67A8AA72598DF5AA699C3B480ADA8013D42C3D74A`
- prior public solution: `9AF8CB27D97EA1B9A363BF29FDCC18F6CF1822037B6F504D2F5ACE5EA9E25CF4`
- prior 401,154 solution: `94AE01517C31B59C3278B892EEF0782DED57700A9BAA2C506864567694A29253`
- new 401,092 solution: `CB7CC7EFDA11F21B62E9D00F993A0923CB3D3E5B341E661FB6ABC87CE340607E`
