#!/usr/bin/env python3
"""Recover the anonymous combinatorial structure of neos-4355351-swalm."""

from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict, deque
from decimal import Decimal
from pathlib import Path

from analyze_structure import compact_decimal, parse_mps


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("--solution", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--quiet", action="store_true", help="write JSON without echoing it")
    args = parser.parse_args()

    model = parse_mps(args.mps)
    variables = model["variable_order"]
    integers = model["integer_variables"]
    binaries = {
        v
        for v in integers
        if model["lower"][v] == 0 and model["upper"][v] == 1
    }
    continuous = set(variables) - integers
    entries = model["row_entries"]
    equality_rows = [r for r in model["row_order"] if model["row_types"][r] == "E"]
    greater_rows = [r for r in model["row_order"] if model["row_types"][r] == "G"]
    less_rows = [r for r in model["row_order"] if model["row_types"][r] == "L"]

    variable_equalities: dict[str, list[tuple[str, Decimal]]] = defaultdict(list)
    for row in equality_rows:
        for variable, coefficient in entries[row]:
            variable_equalities[variable].append((row, coefficient))

    equality_rhs = Counter(compact_decimal(model["rhs"][r]) for r in equality_rows)
    equality_sizes = Counter(len(entries[r]) for r in equality_rows)
    equality_signatures = Counter(
        (
            len(entries[r]),
            compact_decimal(model["rhs"][r]),
            tuple(sorted(Counter(compact_decimal(a) for _, a in entries[r]).items())),
        )
        for r in equality_rows
    )
    equality_fingerprints: dict[tuple, list[str]] = defaultdict(list)
    for row in equality_rows:
        fingerprint = (
            tuple(sorted((v, compact_decimal(a)) for v, a in entries[row])),
            compact_decimal(model["rhs"][row]),
        )
        equality_fingerprints[fingerprint].append(row)
    duplicate_equality_groups = sorted(
        (rows for rows in equality_fingerprints.values() if len(rows) > 1),
        key=lambda rows: rows[0],
    )

    incidence_signatures = Counter(
        tuple(sorted(compact_decimal(a) for _, a in variable_equalities[v]))
        for v in continuous
    )

    # Link each continuous variable to its paired binary variable.
    links: dict[str, str] = {}
    link_signatures = Counter()
    for row in greater_rows:
        terms = entries[row]
        bterms = [(v, a) for v, a in terms if v in binaries]
        cterms = [(v, a) for v, a in terms if v in continuous]
        link_signatures[
            (
                tuple(compact_decimal(a) for _, a in bterms),
                tuple(compact_decimal(a) for _, a in cterms),
                compact_decimal(model["rhs"][row]),
            )
        ] += 1
        if len(bterms) == len(cterms) == 1:
            links[cterms[0][0]] = bterms[0][0]

    # Every L row is expected to encode a star of pairwise conflicts:
    # degree(v) y_v + sum_{u in N(v)} y_u <= degree(v).
    centers: dict[str, set[str]] = {}
    malformed_conflict_rows = []
    for row in less_rows:
        row_terms = entries[row]
        rhs = model["rhs"][row]
        center = [(v, a) for v, a in row_terms if a == rhs]
        neighbors = [(v, a) for v, a in row_terms if a == 1]
        valid = (
            rhs == len(row_terms) - 1
            and len(center) == 1
            and len(neighbors) == len(row_terms) - 1
            and all(v in binaries for v, _ in row_terms)
        )
        if not valid:
            malformed_conflict_rows.append(row)
            continue
        centers[center[0][0]] = {v for v, _ in neighbors}

    directed_pairs = {(v, u) for v, neighbors in centers.items() for u in neighbors}
    undirected_pairs = {tuple(sorted((v, u))) for v, u in directed_pairs}
    asymmetric_pairs = sorted((v, u) for v, u in directed_pairs if (u, v) not in directed_pairs)

    # The first 280 equality rows are the unique node balances; the next 275
    # are exact duplicates for nonterminals.  This lets us interpret conflicts
    # between activated directed arcs.
    first_balance_rows = set(model["row_order"][:280])
    binary_arcs = {}
    for flow, binary in links.items():
        incidence = [(r, a) for r, a in variable_equalities[flow] if r in first_balance_rows]
        positive = [r for r, a in incidence if a == 1]
        negative = [r for r, a in incidence if a == -1]
        if len(positive) == len(negative) == 1:
            binary_arcs[binary] = (positive[0], negative[0])
    conflict_relation_counts = Counter()
    physical_conflict_orientations: dict[tuple, int] = Counter()
    for left, right in undirected_pairs:
        if left not in binary_arcs or right not in binary_arcs:
            conflict_relation_counts["unparsed"] += 1
            continue
        lt, lh = binary_arcs[left]
        rt, rh = binary_arcs[right]
        if {lt, lh} == {rt, rh}:
            relation = "same_physical_edge"
        elif lh == rt:
            relation = "left_then_right"
        elif rh == lt:
            relation = "right_then_left"
        elif lt == rt:
            relation = "same_tail"
        elif lh == rh:
            relation = "same_head"
        elif len({lt, lh, rt, rh}) == 3:
            relation = "other_shared_endpoint"
        else:
            relation = "disjoint_endpoints"
        conflict_relation_counts[relation] += 1
        physical_pair = tuple(sorted((tuple(sorted((lt, lh))), tuple(sorted((rt, rh))))))
        if physical_pair[0] != physical_pair[1]:
            physical_conflict_orientations[physical_pair] += 1

    # Connected components of the equality-row hypergraph.  A continuous
    # variable joins all equality rows in which it occurs.
    adjacency: dict[str, set[str]] = {r: set() for r in equality_rows}
    for variable in continuous:
        rows = [r for r, _ in variable_equalities[variable]]
        for row in rows[1:]:
            adjacency[rows[0]].add(row)
            adjacency[row].add(rows[0])
    components = []
    unseen = set(equality_rows)
    while unseen:
        seed = min(unseen)
        queue = deque([seed])
        unseen.remove(seed)
        component = []
        while queue:
            row = queue.popleft()
            component.append(row)
            for neighbor in adjacency[row]:
                if neighbor in unseen:
                    unseen.remove(neighbor)
                    queue.append(neighbor)
        components.append(sorted(component))
    components.sort(key=lambda c: (-len(c), c[0]))

    variable_samples = []
    for variable in variables:
        if variable not in continuous:
            continue
        variable_samples.append(
            {
                "variable": variable,
                "equalities": [
                    [row, compact_decimal(coefficient)]
                    for row, coefficient in variable_equalities[variable]
                ],
                "linked_binary": links.get(variable),
                "objective": compact_decimal(
                    model["objective"].get(links.get(variable, ""), Decimal(0))
                ),
            }
        )

    solution_summary = None
    if args.solution:
        values: dict[str, Decimal] = {}
        objective_line = None
        for line in args.solution.read_text(encoding="utf-8").splitlines():
            tokens = line.split()
            if not tokens:
                continue
            if tokens[0].startswith("=obj="):
                objective_line = tokens[-1]
            elif len(tokens) >= 2:
                values[tokens[0]] = Decimal(tokens[1])
        selected = [v for v in variables if v in binaries and values.get(v, Decimal(0)) > Decimal("0.5")]
        nonzero_continuous = [
            v for v in variables if v in continuous and abs(values.get(v, Decimal(0))) > Decimal("1e-8")
        ]
        selected_conflicts = [
            [v, u]
            for v, u in sorted(undirected_pairs)
            if values.get(v, Decimal(0)) > Decimal("0.5")
            and values.get(u, Decimal(0)) > Decimal("0.5")
        ]
        binary_to_continuous = {binary: variable for variable, binary in links.items()}
        solution_summary = {
            "objective_line": objective_line,
            "selected_binary_count": len(selected),
            "selected_binary_objective_counts": dict(
                Counter(compact_decimal(model["objective"].get(v, Decimal(0))) for v in selected)
            ),
            "selected_binary_head": selected[:100],
            "selected_binary_details": [
                {
                    "binary": binary,
                    "continuous": binary_to_continuous.get(binary),
                    "flow": compact_decimal(
                        values.get(binary_to_continuous.get(binary, ""), Decimal(0))
                    ),
                    "cost": compact_decimal(model["objective"].get(binary, Decimal(0))),
                    "equalities": [
                        [row, compact_decimal(coefficient)]
                        for row, coefficient in variable_equalities.get(
                            binary_to_continuous.get(binary, ""), []
                        )
                    ],
                    "outgoing_conflict_degree": len(centers.get(binary, set())),
                }
                for binary in selected
            ],
            "nonzero_continuous_count_above_1e-8": len(nonzero_continuous),
            "nonzero_continuous_head": [
                [v, compact_decimal(values[v])] for v in nonzero_continuous[:100]
            ],
            "selected_conflict_count": len(selected_conflicts),
            "selected_conflicts_head": selected_conflicts[:20],
        }

    report = {
        "equality_rows": len(equality_rows),
        "equality_rhs_counts": dict(equality_rhs),
        "equality_size_counts": dict(sorted(equality_sizes.items())),
        "top_equality_signatures": [
            {
                "count": count,
                "nz": signature[0],
                "rhs": signature[1],
                "coefficient_counts": dict(signature[2]),
            }
            for signature, count in equality_signatures.most_common(30)
        ],
        "continuous_equality_incidence_signatures": {
            str(signature): count for signature, count in incidence_signatures.most_common()
        },
        "equality_components": [
            {"size": len(component), "first": component[0], "last": component[-1]}
            for component in components
        ],
        "duplicate_equality_group_count": len(duplicate_equality_groups),
        "duplicate_equality_row_count": sum(
            len(group) - 1 for group in duplicate_equality_groups
        ),
        "duplicate_equality_groups_head": duplicate_equality_groups[:30],
        "equality_row_samples": [
            {
                "row": row,
                "rhs": compact_decimal(model["rhs"][row]),
                "terms": [[v, compact_decimal(a)] for v, a in entries[row][:100]],
            }
            for row in equality_rows[:12] + equality_rows[-12:]
        ],
        "link_rows": len(greater_rows),
        "link_map_size": len(links),
        "unlinked_continuous_variables": sorted(continuous - set(links)),
        "link_signatures": {str(signature): count for signature, count in link_signatures.items()},
        "continuous_variable_samples": variable_samples[:30] + variable_samples[-30:],
        "conflict_rows": len(less_rows),
        "valid_conflict_star_rows": len(centers),
        "malformed_conflict_rows": malformed_conflict_rows,
        "missing_conflict_centers": sorted(binaries - set(centers)),
        "directed_conflict_pairs": len(directed_pairs),
        "undirected_conflict_pairs": len(undirected_pairs),
        "asymmetric_directed_pairs": len(asymmetric_pairs),
        "asymmetric_directed_pairs_head": asymmetric_pairs[:30],
        "parsed_binary_arcs": len(binary_arcs),
        "conflict_relation_counts": dict(conflict_relation_counts),
        "physical_conflict_orientation_count_histogram": dict(
            Counter(physical_conflict_orientations.values())
        ),
        "conflict_degree_counts": dict(Counter(len(n) for n in centers.values())),
        "solution": solution_summary,
    }
    payload = json.dumps(report, indent=2, sort_keys=True) + "\n"
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(payload, encoding="utf-8")
    if not args.quiet:
        print(payload, end="")


if __name__ == "__main__":
    main()
