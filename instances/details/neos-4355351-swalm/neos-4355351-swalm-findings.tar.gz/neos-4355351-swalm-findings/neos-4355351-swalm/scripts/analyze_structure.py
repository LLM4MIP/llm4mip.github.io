#!/usr/bin/env python3
"""Recover coefficient, block, and binary--continuous linkage structure."""

from __future__ import annotations

import argparse
import gzip
import json
from collections import Counter, defaultdict
from decimal import Decimal
from pathlib import Path


def number(value: str) -> Decimal:
    return Decimal(value.replace("D", "E").replace("d", "e"))


def open_text(path: Path):
    if path.suffix.lower() == ".gz":
        return gzip.open(path, "rt", encoding="latin-1")
    return path.open(encoding="latin-1")


def compact_decimal(value: Decimal) -> str:
    return str(value.normalize()) if value else "0"


def parse_mps(path: Path):
    section = ""
    row_types: dict[str, str] = {}
    row_order: list[str] = []
    columns: dict[str, list[tuple[str, Decimal]]] = defaultdict(list)
    variable_order: list[str] = []
    seen_variables: set[str] = set()
    objective_rows: set[str] = set()
    rhs: dict[str, Decimal] = defaultdict(Decimal)
    bounds: list[list[str]] = []
    integer_variables: set[str] = set()
    integer_mode = False

    with open_text(path) as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if (
                not raw[0].isspace()
                and tokens[0]
                in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}
            ):
                section = tokens[0]
                if section == "RANGES":
                    raise ValueError("RANGES are not supported")
                continue
            if section == "ROWS":
                kind, row = tokens[0], tokens[1]
                row_types[row] = kind
                if kind == "N":
                    objective_rows.add(row)
                else:
                    row_order.append(row)
            elif section == "COLUMNS":
                if "'MARKER'" in tokens:
                    integer_mode = "'INTORG'" in tokens
                    continue
                variable = tokens[0]
                if variable not in seen_variables:
                    seen_variables.add(variable)
                    variable_order.append(variable)
                if integer_mode:
                    integer_variables.add(variable)
                for row, coefficient in zip(tokens[1::2], tokens[2::2]):
                    columns[variable].append((row, number(coefficient)))
            elif section == "RHS":
                for row, value in zip(tokens[1::2], tokens[2::2]):
                    rhs[row] += number(value)
            elif section == "BOUNDS":
                bounds.append(tokens)

    lower = {variable: Decimal(0) for variable in variable_order}
    upper: dict[str, Decimal | None] = {variable: None for variable in variable_order}
    for tokens in bounds:
        kind, variable = tokens[0], tokens[2]
        value = number(tokens[3]) if len(tokens) > 3 else Decimal(0)
        if kind == "LO":
            lower[variable] = value
        elif kind == "UP":
            upper[variable] = value
        elif kind == "FX":
            lower[variable] = upper[variable] = value
        elif kind == "FR":
            lower[variable], upper[variable] = Decimal("-Infinity"), None
        elif kind == "MI":
            lower[variable] = Decimal("-Infinity")
        elif kind == "PL":
            upper[variable] = None
        elif kind == "BV":
            lower[variable], upper[variable] = Decimal(0), Decimal(1)
            integer_variables.add(variable)
        elif kind == "LI":
            lower[variable] = value
            integer_variables.add(variable)
        elif kind == "UI":
            upper[variable] = value
            integer_variables.add(variable)
        else:
            raise ValueError(f"unsupported bound type {kind}")

    row_entries: dict[str, list[tuple[str, Decimal]]] = defaultdict(list)
    objective: dict[str, Decimal] = defaultdict(Decimal)
    for variable in variable_order:
        for row, coefficient in columns[variable]:
            if row in objective_rows:
                objective[variable] += coefficient
            else:
                row_entries[row].append((variable, coefficient))
    return {
        "row_types": row_types,
        "row_order": row_order,
        "row_entries": row_entries,
        "rhs": rhs,
        "variable_order": variable_order,
        "integer_variables": integer_variables,
        "lower": lower,
        "upper": upper,
        "objective": objective,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("--json", type=Path)
    parser.add_argument("--quiet", action="store_true", help="write JSON without echoing it")
    args = parser.parse_args()
    model = parse_mps(args.mps)
    variable_order = model["variable_order"]
    integer_variables = model["integer_variables"]
    binary_variables = {
        variable
        for variable in integer_variables
        if model["lower"][variable] == 0 and model["upper"][variable] == 1
    }
    continuous_variables = set(variable_order) - integer_variables
    row_entries = model["row_entries"]

    row_summaries = []
    signature_counts: Counter[tuple] = Counter()
    for index, row in enumerate(model["row_order"]):
        entries = row_entries[row]
        binary = [(v, a) for v, a in entries if v in binary_variables]
        continuous = [(v, a) for v, a in entries if v in continuous_variables]
        coefficient_counts = Counter(compact_decimal(a) for _, a in entries)
        signature = (
            model["row_types"][row],
            len(binary),
            len(continuous),
            len(entries),
            compact_decimal(model["rhs"][row]),
            tuple(sorted(coefficient_counts.items())),
        )
        signature_counts[signature] += 1
        row_summaries.append(
            {
                "index": index + 1,
                "name": row,
                "sense": model["row_types"][row],
                "rhs": compact_decimal(model["rhs"][row]),
                "binary_nz": len(binary),
                "continuous_nz": len(continuous),
                "nz": len(entries),
                "coefficient_counts": dict(sorted(coefficient_counts.items())),
            }
        )

    # Consecutive ranges with the same coarse support signature reveal the
    # anonymous row blocks left by model export.
    blocks = []
    for summary in row_summaries:
        coarse = (
            summary["sense"],
            summary["binary_nz"],
            summary["continuous_nz"],
            summary["nz"],
        )
        if blocks and blocks[-1]["signature"] == coarse:
            blocks[-1]["end"] = summary["index"]
            blocks[-1]["count"] += 1
        else:
            blocks.append(
                {
                    "start": summary["index"],
                    "end": summary["index"],
                    "count": 1,
                    "signature": coarse,
                }
            )

    variable_degrees = Counter()
    binary_degrees = Counter()
    continuous_degrees = Counter()
    for row, entries in row_entries.items():
        del row
        for variable, _ in entries:
            variable_degrees[variable] += 1
    for variable, degree in variable_degrees.items():
        (binary_degrees if variable in binary_variables else continuous_degrees)[degree] += 1

    variable_bound_rows = []
    for summary in row_summaries:
        if summary["binary_nz"] == 1 and summary["continuous_nz"] == 1:
            entries = row_entries[summary["name"]]
            variable_bound_rows.append(
                {
                    **summary,
                    "terms": [
                        {"variable": variable, "coefficient": compact_decimal(coefficient)}
                        for variable, coefficient in entries
                    ],
                }
            )

    objective_terms = sorted(
        (
            {
                "variable": variable,
                "type": "binary" if variable in binary_variables else "continuous",
                "coefficient": compact_decimal(coefficient),
            }
            for variable, coefficient in model["objective"].items()
            if coefficient
        ),
        key=lambda item: variable_order.index(item["variable"]),
    )
    report = {
        "rows": len(model["row_order"]),
        "variables": len(variable_order),
        "binary_variables": len(binary_variables),
        "other_integer_variables": len(integer_variables - binary_variables),
        "continuous_variables": len(continuous_variables),
        "nonzeros": sum(len(entries) for entries in row_entries.values()),
        "row_senses": dict(Counter(model["row_types"][r] for r in model["row_order"])),
        "objective_nonzeros": len(objective_terms),
        "objective_type_counts": dict(Counter(item["type"] for item in objective_terms)),
        "objective_coefficient_counts": dict(
            Counter(item["coefficient"] for item in objective_terms)
        ),
        "binary_degree_histogram": dict(sorted(binary_degrees.items())),
        "continuous_degree_histogram": dict(sorted(continuous_degrees.items())),
        "variable_bound_row_count": len(variable_bound_rows),
        "row_blocks": blocks,
        "top_row_signatures": [
            {
                "count": count,
                "sense": signature[0],
                "binary_nz": signature[1],
                "continuous_nz": signature[2],
                "nz": signature[3],
                "rhs": signature[4],
                "coefficient_counts": dict(signature[5]),
            }
            for signature, count in signature_counts.most_common(30)
        ],
        "objective_terms_head": objective_terms[:50],
        "variable_bound_rows_head": variable_bound_rows[:30],
        "row_summaries_head": row_summaries[:30],
    }
    payload = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(payload, encoding="utf-8")
    if not args.quiet:
        print(payload, end="")


if __name__ == "__main__":
    main()
