#!/usr/bin/env python3
"""Solve a state-expanded directed Steiner relaxation with forbidden turns."""

from __future__ import annotations

import argparse
import heapq
import json
from collections import Counter, defaultdict, deque
from decimal import Decimal
from pathlib import Path

from analyze_structure import compact_decimal, parse_mps


SCALE = 100_000
INF = 10**30


def scaled(value: Decimal) -> int:
    result = value * SCALE
    if result != result.to_integral_value():
        raise ValueError(value)
    return int(result)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--solution", type=Path, required=True)
    args = parser.parse_args()

    model = parse_mps(args.mps)
    variables = model["variable_order"]
    integers = model["integer_variables"]
    binaries = {
        v for v in integers if model["lower"][v] == 0 and model["upper"][v] == 1
    }
    continuous = set(variables) - integers
    entries = model["row_entries"]
    equality_rows = [r for r in model["row_order"] if model["row_types"][r] == "E"]
    variable_equalities: dict[str, list[tuple[str, Decimal]]] = defaultdict(list)
    for row in equality_rows:
        for variable, coefficient in entries[row]:
            variable_equalities[variable].append((row, coefficient))
    fingerprints: dict[tuple, list[str]] = defaultdict(list)
    for row in equality_rows:
        fingerprints[tuple(sorted((v, a) for v, a in entries[row]))].append(row)
    physical_nodes = sorted(rows[0] for rows in fingerprints.values())
    physical_set = set(physical_nodes)

    links: dict[str, str] = {}
    conflict_pairs: set[tuple[str, str]] = set()
    for row in model["row_order"]:
        sense = model["row_types"][row]
        if sense == "G":
            bterms = [(v, a) for v, a in entries[row] if v in binaries]
            cterms = [(v, a) for v, a in entries[row] if v in continuous]
            if len(bterms) == len(cterms) == 1:
                links[cterms[0][0]] = bterms[0][0]
        elif sense == "L":
            rhs = model["rhs"][row]
            center = [v for v, a in entries[row] if a == rhs]
            neighbors = [v for v, a in entries[row] if a == 1]
            for neighbor in neighbors:
                conflict_pairs.add(tuple(sorted((center[0], neighbor))))

    arc_data: dict[str, dict] = {}
    physical_outgoing: dict[str, list[str]] = defaultdict(list)
    physical_incoming: dict[str, list[str]] = defaultdict(list)
    for flow, binary in links.items():
        incidence = [(r, a) for r, a in variable_equalities[flow] if r in physical_set]
        positive = [r for r, a in incidence if a == 1]
        negative = [r for r, a in incidence if a == -1]
        if len(positive) != 1 or len(negative) != 1:
            raise ValueError((flow, incidence))
        tail, head = positive[0], negative[0]
        arc_data[binary] = {
            "tail": tail,
            "head": head,
            "flow": flow,
            "cost": scaled(model["objective"][binary]),
        }
        physical_outgoing[tail].append(binary)
        physical_incoming[head].append(binary)

    boundary = []
    for variable in sorted(continuous - set(links)):
        incidence = [(r, a) for r, a in variable_equalities[variable] if r in physical_set]
        row, coefficient = incidence[0]
        boundary.append((variable, row, coefficient, model["lower"][variable]))
    source = next(row for _, row, coefficient, _ in boundary if coefficient < 0)
    sinks = sorted(row for _, row, coefficient, _ in boundary if coefficient > 0)

    # State zero is the artificial root.  Every other state is identified by
    # the last directed physical arc used to reach its head node.
    state_binaries = [None] + sorted(arc_data)
    state_index = {binary: index for index, binary in enumerate(state_binaries) if binary}
    state_count = len(state_binaries)
    reverse_adjacency: list[list[tuple[int, int]]] = [[] for _ in range(state_count)]
    transition_count = 0
    root_index = 0
    for binary in physical_outgoing[source]:
        state = state_index[binary]
        reverse_adjacency[state].append((root_index, arc_data[binary]["cost"]))
        transition_count += 1
    for incoming_binary, incoming_data in arc_data.items():
        from_state = state_index[incoming_binary]
        for outgoing_binary in physical_outgoing[incoming_data["head"]]:
            if tuple(sorted((incoming_binary, outgoing_binary))) in conflict_pairs:
                continue
            to_state = state_index[outgoing_binary]
            reverse_adjacency[to_state].append(
                (from_state, arc_data[outgoing_binary]["cost"])
            )
            transition_count += 1

    masks = 1 << len(sinks)
    dp = [[INF] * state_count for _ in range(masks)]
    predecessor: list[list[tuple | None]] = [[None] * state_count for _ in range(masks)]

    def reverse_closure(mask: int, initial: list[tuple | None]) -> None:
        predecessor[mask] = initial
        heap = [(distance, state) for state, distance in enumerate(dp[mask]) if distance < INF]
        heapq.heapify(heap)
        while heap:
            distance, state = heapq.heappop(heap)
            if distance != dp[mask][state]:
                continue
            for previous, cost in reverse_adjacency[state]:
                candidate = distance + cost
                if candidate < dp[mask][previous]:
                    dp[mask][previous] = candidate
                    predecessor[mask][previous] = ("transition", state)
                    heapq.heappush(heap, (candidate, previous))

    for bit, sink in enumerate(sinks):
        mask = 1 << bit
        for binary in physical_incoming[sink]:
            dp[mask][state_index[binary]] = 0
        reverse_closure(mask, [None] * state_count)

    for mask in range(1, masks):
        if mask & (mask - 1) == 0:
            continue
        initial: list[tuple | None] = [None] * state_count
        lowbit = mask & -mask
        submask = (mask - 1) & mask
        while submask:
            other = mask ^ submask
            if other and submask & lowbit:
                for state in range(state_count):
                    candidate = dp[submask][state] + dp[other][state]
                    if candidate < dp[mask][state]:
                        dp[mask][state] = candidate
                        initial[state] = ("split", submask, other)
            submask = (submask - 1) & mask
        reverse_closure(mask, initial)

    full = masks - 1
    optimum = dp[full][root_index]
    selected_states: set[int] = set()
    seen_states: set[tuple[int, int]] = set()

    def recover(mask: int, state: int) -> None:
        key = mask, state
        if key in seen_states:
            return
        seen_states.add(key)
        step = predecessor[mask][state]
        if step is None:
            if state:
                selected_states.add(state)
            return
        if step[0] == "transition":
            next_state = step[1]
            if next_state:
                selected_states.add(next_state)
            recover(mask, next_state)
        else:
            _, left, right = step
            if state:
                selected_states.add(state)
            recover(left, state)
            recover(right, state)

    recover(full, root_index)
    selected = {state_binaries[state] for state in selected_states}
    union_cost = sum(arc_data[binary]["cost"] for binary in selected)
    selected_conflicts = sorted(
        pair for pair in conflict_pairs if pair[0] in selected and pair[1] in selected
    )

    # Determine whether the mapped physical support is an arborescence, then
    # generate the exact four-unit flow and audit the original anonymous MPS.
    indegree = Counter(arc_data[b]["head"] for b in selected)
    duplicate_physical_arrivals = {node: degree for node, degree in indegree.items() if degree > 1}
    selected_outgoing: dict[str, list[tuple[str, str]]] = defaultdict(list)
    for binary in selected:
        data = arc_data[binary]
        selected_outgoing[data["tail"]].append((data["head"], binary))
    parent = {source: None}
    parent_binary: dict[str, str] = {}
    order = [source]
    for node in order:
        for head, binary in sorted(selected_outgoing.get(node, [])):
            if head in parent:
                continue
            parent[head] = node
            parent_binary[head] = binary
            order.append(head)
    connects_sinks = all(sink in parent for sink in sinks)
    used_nodes = set()
    for sink in sinks:
        current = sink
        while current in parent and current is not None:
            used_nodes.add(current)
            current = parent[current]
    used = {parent_binary[node] for node in used_nodes if node != source}

    subtree = {node: int(node in set(sinks)) for node in reversed(order)}
    for node in reversed(order[1:]):
        if node in used_nodes:
            subtree[parent[node]] += subtree[node]
    values = {v: Decimal(0) for v in variables}
    for variable, _row, _coefficient, lower in boundary:
        values[variable] = lower
    oriented_edges = []
    for child in order[1:]:
        if child not in used_nodes:
            continue
        binary = parent_binary[child]
        data = arc_data[binary]
        values[binary] = Decimal(1)
        values[data["flow"]] = Decimal(subtree[child])
        oriented_edges.append(
            {
                "tail": data["tail"],
                "head": data["head"],
                "binary_variable": binary,
                "flow_variable": data["flow"],
                "flow": subtree[child],
                "cost": data["cost"] / SCALE,
            }
        )

    violated_rows = []
    max_violation = Decimal(0)
    for row in model["row_order"]:
        activity = sum(a * values[v] for v, a in entries[row])
        rhs = model["rhs"][row]
        sense = model["row_types"][row]
        if sense == "E":
            violation = abs(activity - rhs)
        elif sense == "G":
            violation = max(Decimal(0), rhs - activity)
        else:
            violation = max(Decimal(0), activity - rhs)
        max_violation = max(max_violation, violation)
        if violation:
            violated_rows.append(row)
    exact_objective = sum(model["objective"].get(v, Decimal(0)) * values[v] for v in variables)
    full_feasible = connects_sinks and not violated_rows

    args.solution.parent.mkdir(parents=True, exist_ok=True)
    with args.solution.open("w", encoding="utf-8") as handle:
        handle.write(f"=obj= {exact_objective}\n")
        for variable in variables:
            if values[variable]:
                handle.write(f"{variable} {values[variable]}\n")

    report = {
        "algorithm": "state-expanded directed Steiner DP",
        "physical_nodes": len(physical_nodes),
        "directed_arcs": len(arc_data),
        "state_nodes": state_count,
        "allowed_state_transitions": transition_count,
        "source": source,
        "sinks": sinks,
        "state_relaxation_value_scaled": optimum,
        "state_relaxation_value": optimum / SCALE,
        "recovered_union_cost_scaled": union_cost,
        "recovered_union_cost": union_cost / SCALE,
        "selected_arc_count": len(selected),
        "used_arc_count": len(used),
        "selected_binaries": sorted(selected),
        "selected_conflicts": selected_conflicts,
        "duplicate_physical_arrivals": duplicate_physical_arrivals,
        "connects_all_sinks": connects_sinks,
        "oriented_edges": oriented_edges,
        "exact_objective_from_mps": compact_decimal(exact_objective),
        "max_exact_row_violation": compact_decimal(max_violation),
        "violated_row_count": len(violated_rows),
        "violated_rows_head": violated_rows[:30],
        "full_mip_feasible": full_feasible,
        "proves_optimal": full_feasible and scaled(exact_objective) == optimum,
    }
    payload = json.dumps(report, indent=2, sort_keys=True) + "\n"
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(payload, encoding="utf-8")
    print(payload, end="")


if __name__ == "__main__":
    main()
