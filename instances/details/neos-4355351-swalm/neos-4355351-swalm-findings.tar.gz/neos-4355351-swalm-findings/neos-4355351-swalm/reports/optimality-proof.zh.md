# `neos-4355351-swalm` optimality proof

## Conclusion

The strict optimal value of the original MPS is **33.45763**.

The original model looks like there's a 21,065 variable and a 21,609 bar constraint, but the anonymous matrix is actually one.
The four terminals for which the ribbon prohibits rotation have been extended to the Steiner tree model.
relaxation gives the lower bound 33.45763; the same state solution can also be displayed back to the original MPS without damage, and decimated by row by row
The exact verification, therefore, is equal to the lower bound.

##  Retrieved from Anonymous Matrix

1.  In the 555 line equation, the 275 line is the same repetition line as the complete, and then the 280 node is returned.
It's a balancing act.
2.  10,530 is a non-negative continuous variable and 10,530 is an integer enabled variable.
`y_a - 0.25 f_a >= 0`, i.e. each enabled arc carries the maximum 4 unit flow.
3.  Additional 5 continuous variables give one 4 unit source point `R0132` and four 1 unit convergence points
   `R0014, R0140, R0141, R0271`。
4.  The rest of the 10,524 constraint can be written as
`d_a y_a + sum_{b in F(a)} y_b <= d_a`. On an integer point, it is equivalent to several
`y_a+y_b<=1`. Weighing 292,664 to conflict, where 5,208 to prohibit the same physical side
Both directions are enabled simultaneously and the rest of the 287,456 is forbidden to rotate between adjacent arcs; none
In this case, it is possible to see the difference between the two.

##  Why the state model gives a strict lower bound

Any original model feasible flow can be decomposition into four source convergence paths and several rings.
And after a surplus arc, you can get a vertical tree that reaches all four junctions; removing the arc will not destroy the conflict.
It's not a constraint, and it doesn't add to the positive cost.

A state is established for each arc. If `a=(u,v)`, `b=(v,w)` and the original MPS are not prohibited this time
In turn, to establish the status transfer `a -> b`, pay the cost of the arc `b` when entering `b`.
The arc emitted by the source point of connection. So any original model feasible tree corresponding to the same cost status graph has to be
The Steiner tree, so the state graph optimum is not greater than the original MPS optimum, is a legitimate lower bound.

10,531 states are shared in the status graph; the 125,453 clause allows for transfer.
The script uses subset dynamic programming and reverse shortest path closure exact solve; all costs are multiplied by 100,000.
For an integer, get the exact lower bound `3,345,763 / 100,000 = 33.45763`.

##  feasible primal bound and nuclear testing

dynamic programming The restored state tree does not re-enter the physical node and is directly reflected back to the 15 line.
Assign each arc a flow equal to the number of sinks in its subtree, giving integer flows from 1–4. For the original compressed MPS
Item-by-item `Decimal` evaluation gives zero error on all 21,609 constraints, variable bounds, and integrality conditions,
The objective is 33.45763. Thus the feasible primal bound is equal to the state lower bound.

The MIPLIB page currently displays an integer error in the objective `33.45757454008309` correspondence table
`7.7e-6`'s candidate solution, and that number is not on the `1e-5` objective lattice of the original model.
The best proof value should be 33.45763.
