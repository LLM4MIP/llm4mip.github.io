# Package manifest: mining

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 23
Excluded source files: 1

## Included files

- `.gitattributes`
- `.gitignore`
- `README.md`
- `analysis/bounds.json`
- `analysis/gurobi-read-euler4.log`
- `analysis/mining-gurobi-structure.json`
- `analysis/structure.json`
- `analysis/threshold-dag-edges.json`
- `artifacts/forensics.json.gz`
- `artifacts/lagrangian.json`
- `artifacts/structure.compact.json`
- `experiments/check_lagrangian_certificate.py`
- `experiments/check_lagrangian_from_mps.py`
- `experiments/lagrangian-refine2-6000-from-mps-replay.json`
- `experiments/lagrangian-refine2-6000-trace.jsonl.gz`
- `experiments/lagrangian-refine2-6000.json`
- `experiments/lagrangian_chain_dp.py`
- `experiments/reconstruct_threshold_dag.py`
- `input/mining-public-4.sol.gz`
- `logs/lagrangian-first-attempt.log`
- `scripts/mining_forensics.py`
- `scripts/mining_lagrangian.py`
- `solutions/official-best.sol.gz`

## Excluded files

- `input/mining.mps.gz (24531243 bytes; raw benchmark input; sha256 b460c0f02b2bd0262d2a53c677705cdceffca77db61623730c5260e703b76a57)`
