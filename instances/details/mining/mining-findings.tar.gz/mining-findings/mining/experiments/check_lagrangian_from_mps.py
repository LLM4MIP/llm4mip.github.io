#!/usr/bin/env python3
"""Verify a mining Lagrangian lower bound from only the original MPS and JSON certificate.

The verifier deliberately does not read the generated threshold-model or edge
files used by the multiplier search.  It independently parses the original MPS,
proves the 21-state/path reduction coefficient by coefficient, and recomputes
the Lagrangian inner minimum using exact ``Decimal`` arithmetic.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from array import array
from collections import Counter, defaultdict
from decimal import Decimal, getcontext
from pathlib import Path


getcontext().prec = 80
SECTIONS = {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}
PERIODS = 20
BINARY_VARIABLES = 348_920
BLOCKS = BINARY_VARIABLES // PERIODS
VARIABLES = BINARY_VARIABLES + 1
VERTICAL_ROWS = BLOCKS * (PERIODS - 1)
MIXED_FIRST = VERTICAL_ROWS + 1
MIXED_LAST = MIXED_FIRST + 78 - 1
HORIZONTAL_FIRST = MIXED_LAST + 1
HORIZONTAL_GADGETS = 16_479
HORIZONTAL_ROWS = HORIZONTAL_GADGETS * PERIODS
HORIZONTAL_LAST = HORIZONTAL_FIRST + HORIZONTAL_ROWS - 1
FIXED_ROW = HORIZONTAL_LAST + 1


def number(text: str) -> Decimal:
    return Decimal(text.replace("D", "E").replace("d", "e"))


def open_text(path: Path):
    return gzip.open(path, "rt", encoding="latin-1") if path.suffix == ".gz" else path.open(encoding="latin-1")


def index(name: str, prefix: str) -> int:
    suffix = name[len(prefix) :] if name.startswith(prefix) else ""
    if not suffix.isdigit():
        raise ValueError(f"unexpected name {name!r}; expected {prefix}<integer>")
    return int(suffix)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("certificate", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    source_hash = hashlib.sha256(args.mps.read_bytes()).hexdigest()
    cert = json.loads(args.certificate.read_text(encoding="utf-8"))
    lam1 = [Decimal(value) for value in cert["multipliers_first_resource"]]
    lam2 = [Decimal(value) for value in cert["multipliers_second_resource"]]
    multiplier_check = (
        len(lam1) == PERIODS
        and len(lam2) == PERIODS
        and all(value.is_finite() and value >= 0 for value in lam1 + lam2)
    )
    if not multiplier_check:
        raise ValueError("certificate must contain 40 nonnegative finite-decimal multipliers")

    row_types: dict[int, str] = {}
    row_records = 0
    rhs: defaultdict[int, Decimal] = defaultdict(Decimal)
    ranges_seen = 0
    integer_columns = bytearray(VARIABLES)
    seen_columns = bytearray(VARIABLES)
    upper_one = bytearray(BINARY_VARIABLES)
    constant_upper_two = False
    unexpected_bounds: list[list[str | int]] = []
    vertical_masks = bytearray(BINARY_VARIABLES)
    vertical_entries = 0
    vertical_errors: list[list[str | int]] = []
    mixed_nonbinary_entries = 0
    fixed_entries: list[tuple[int, Decimal]] = []

    horizontal_pos = array("i", [-1]) * HORIZONTAL_ROWS
    horizontal_neg1 = array("i", [-1]) * HORIZONTAL_ROWS
    horizontal_neg2 = array("i", [-1]) * HORIZONTAL_ROWS
    horizontal_counts = bytearray(HORIZONTAL_ROWS)
    horizontal_errors: list[list[str | int]] = []

    costs: list[list[Decimal]] = []
    weights1: list[list[Decimal]] = []
    weights2: list[list[Decimal]] = []
    difference_state_count = 0
    difference_state_positive_examples: list[list[str | int]] = []
    capacity_pattern_examples: list[list[str | int]] = []
    current_block = -1
    block_objective = [Decimal(0)] * PERIODS
    block_mixed: list[defaultdict[int, Decimal]] = [defaultdict(Decimal) for _ in range(PERIODS)]
    constant_objective = Decimal(0)

    def flush_block(block: int) -> None:
        nonlocal block_objective, block_mixed, difference_state_count
        if block < 0:
            return
        if block != len(costs):
            raise ValueError(f"nonconsecutive block order: flushing {block}, expected {len(costs)}")
        running_objective = Decimal(0)
        running_mixed: defaultdict[int, Decimal] = defaultdict(Decimal)
        state_cost = [Decimal(0)] * (PERIODS + 1)
        state_w1 = [Decimal(0)] * (PERIODS + 1)
        state_w2 = [Decimal(0)] * (PERIODS + 1)
        for state in range(PERIODS - 1, -1, -1):
            running_objective += block_objective[state]
            for row_offset, coefficient in block_mixed[state].items():
                running_mixed[row_offset] += coefficient
                if not running_mixed[row_offset]:
                    del running_mixed[row_offset]
            state_cost[state] = running_objective
            for row_offset, value in running_mixed.items():
                if 0 <= row_offset <= 18 or 39 <= row_offset <= 57:
                    difference_state_count += 1
                    if value > 0 and len(difference_state_positive_examples) < 20:
                        difference_state_positive_examples.append([block, state, row_offset, str(value)])
                elif 19 <= row_offset <= 38:
                    if row_offset != 19 + state:
                        if len(capacity_pattern_examples) < 20:
                            capacity_pattern_examples.append([block, state, row_offset, str(value)])
                    else:
                        state_w1[state] += value
                elif 58 <= row_offset <= 77:
                    if row_offset != 58 + state:
                        if len(capacity_pattern_examples) < 20:
                            capacity_pattern_examples.append([block, state, row_offset, str(value)])
                    else:
                        state_w2[state] += value
                else:
                    raise AssertionError("mixed row offset outside 0..77")
        costs.append(state_cost)
        weights1.append(state_w1)
        weights2.append(state_w2)
        block_objective = [Decimal(0)] * PERIODS
        block_mixed = [defaultdict(Decimal) for _ in range(PERIODS)]

    section = ""
    integer_mode = False
    previous_variable = 0
    with open_text(args.mps) as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if not raw[0].isspace() and tokens[0] in SECTIONS:
                section = tokens[0]
                continue
            if section == "ROWS":
                if len(tokens) != 2:
                    raise ValueError(f"malformed ROWS record: {tokens}")
                if tokens[1] != "obj":
                    row = index(tokens[1], "c")
                    row_records += 1
                    if row in row_types:
                        raise ValueError(f"duplicate row c{row}")
                    row_types[row] = tokens[0]
            elif section == "COLUMNS":
                if "'MARKER'" in tokens:
                    integer_mode = "'INTORG'" in tokens
                    continue
                variable = index(tokens[0], "x")
                if not 1 <= variable <= VARIABLES:
                    raise ValueError(f"column x{variable} outside expected range")
                if variable < previous_variable:
                    raise ValueError("MPS columns are not nondecreasing")
                previous_variable = variable
                seen_columns[variable - 1] = 1
                if integer_mode:
                    integer_columns[variable - 1] = 1
                if variable <= BINARY_VARIABLES:
                    block = (variable - 1) // PERIODS
                    period = (variable - 1) % PERIODS
                    if block != current_block:
                        flush_block(current_block)
                        current_block = block
                else:
                    flush_block(current_block)
                    current_block = -2
                    period = -1
                for row_name, coefficient_text in zip(tokens[1::2], tokens[2::2]):
                    coefficient = number(coefficient_text)
                    if row_name == "obj":
                        if variable <= BINARY_VARIABLES:
                            block_objective[period] += coefficient
                        else:
                            constant_objective += coefficient
                        continue
                    row = index(row_name, "c")
                    if row <= VERTICAL_ROWS:
                        vertical_entries += 1
                        if variable > BINARY_VARIABLES:
                            valid, bit = False, 0
                        else:
                            block = (variable - 1) // PERIODS
                            period = (variable - 1) % PERIODS
                            base = block * (PERIODS - 1)
                            if period < PERIODS - 1 and row == base + period + 1 and coefficient == 1:
                                valid, bit = True, 1
                            elif period > 0 and row == base + period and coefficient == -1:
                                valid, bit = True, 2
                            else:
                                valid, bit = False, 0
                        if not valid or vertical_masks[variable - 1] & bit:
                            if len(vertical_errors) < 20:
                                vertical_errors.append([variable, row, str(coefficient)])
                        elif bit:
                            vertical_masks[variable - 1] |= bit
                    elif MIXED_FIRST <= row <= MIXED_LAST:
                        if variable > BINARY_VARIABLES:
                            mixed_nonbinary_entries += 1
                        else:
                            block_mixed[period][row - MIXED_FIRST] += coefficient
                    elif HORIZONTAL_FIRST <= row <= HORIZONTAL_LAST:
                        offset = row - HORIZONTAL_FIRST
                        horizontal_counts[offset] += 1
                        if variable > BINARY_VARIABLES:
                            valid = False
                        elif coefficient == 1 and horizontal_pos[offset] < 0:
                            horizontal_pos[offset] = variable
                            valid = True
                        elif coefficient == -1 and horizontal_neg1[offset] < 0:
                            horizontal_neg1[offset] = variable
                            valid = True
                        elif coefficient == -1 and horizontal_neg2[offset] < 0:
                            horizontal_neg2[offset] = variable
                            valid = True
                        else:
                            valid = False
                        if not valid and len(horizontal_errors) < 20:
                            horizontal_errors.append([variable, row, str(coefficient)])
                    elif row == FIXED_ROW:
                        fixed_entries.append((variable, coefficient))
                    else:
                        raise ValueError(f"matrix entry references unexpected row c{row}")
            elif section == "RHS":
                for row_name, value_text in zip(tokens[1::2], tokens[2::2]):
                    rhs[index(row_name, "c")] += number(value_text)
            elif section == "RANGES":
                ranges_seen += 1
            elif section == "BOUNDS":
                kind = tokens[0]
                variable = index(tokens[2], "x")
                value = number(tokens[3]) if len(tokens) > 3 else Decimal(0)
                if kind in {"UP", "UI"} and variable <= BINARY_VARIABLES and value == 1:
                    upper_one[variable - 1] = 1
                elif kind == "BV" and variable <= BINARY_VARIABLES:
                    upper_one[variable - 1] = 1
                    integer_columns[variable - 1] = 1
                elif kind in {"UP", "UI"} and variable == VARIABLES and value == 2:
                    constant_upper_two = True
                elif kind in {"LO", "LI"} and value == 0:
                    pass
                elif kind == "PL":
                    pass
                elif len(unexpected_bounds) < 20:
                    unexpected_bounds.append([kind, variable, str(value)])
    flush_block(current_block)

    expected_masks = bytearray(1 if variable % PERIODS == 0 else 2 if variable % PERIODS == PERIODS - 1 else 3 for variable in range(BINARY_VARIABLES))
    vertical_complete = vertical_masks == expected_masks
    row_type_counts = Counter(row_types.values())
    row_layout = (
        row_records == FIXED_ROW
        and len(row_types) == FIXED_ROW
        and min(row_types, default=0) == 1
        and max(row_types, default=0) == FIXED_ROW
        and row_type_counts == Counter({"L": FIXED_ROW - 1, "E": 1})
        and row_types.get(FIXED_ROW) == "E"
    )

    edges: list[tuple[int, int]] = []
    template_examples: list[dict[str, object]] = []
    for gadget in range(HORIZONTAL_GADGETS):
        left = right = -1
        for period in range(PERIODS):
            offset = gadget * PERIODS + period
            positive = horizontal_pos[offset]
            negatives = [entry for entry in (horizontal_neg1[offset], horizontal_neg2[offset]) if entry >= 0]
            if period == 0 and positive > 0 and len(negatives) == 1:
                right = (positive - 1) // PERIODS
                left = (negatives[0] - 1) // PERIODS
                valid = (
                    horizontal_counts[offset] == 2
                    and (positive - 1) % PERIODS == 0
                    and (negatives[0] - 1) % PERIODS == 0
                )
            elif period > 0 and positive > 0 and len(negatives) == 2:
                valid = (
                    horizontal_counts[offset] == 3
                    and positive == right * PERIODS + period + 1
                    and sorted(negatives)
                    == sorted([right * PERIODS + period, left * PERIODS + period + 1])
                )
            else:
                valid = False
            if not valid and len(template_examples) < 20:
                template_examples.append(
                    {"row": HORIZONTAL_FIRST + offset, "positive": positive, "negatives": negatives}
                )
        edges.append((left, right))

    successor = [-1] * BLOCKS
    predecessor = [-1] * BLOCKS
    path_errors: list[tuple[int, int]] = []
    for left, right in edges:
        if not (0 <= left < BLOCKS and 0 <= right < BLOCKS) or left == right:
            path_errors.append((left, right))
            continue
        if successor[left] >= 0 or predecessor[right] >= 0:
            path_errors.append((left, right))
            continue
        successor[left] = right
        predecessor[right] = left
    paths: list[list[int]] = []
    seen: set[int] = set()
    for source in range(BLOCKS):
        if predecessor[source] >= 0:
            continue
        path: list[int] = []
        node = source
        while node >= 0 and node not in seen:
            seen.add(node)
            path.append(node)
            node = successor[node]
        if node >= 0:
            path_errors.append((node, node))
        paths.append(path)

    caps1 = [rhs[MIXED_FIRST + 19 + period] for period in range(PERIODS)]
    caps2 = [rhs[MIXED_FIRST + 58 + period] for period in range(PERIODS)]
    difference_rows = list(range(MIXED_FIRST, MIXED_FIRST + 19)) + list(
        range(MIXED_FIRST + 39, MIXED_FIRST + 58)
    )
    capacity_rows = list(range(MIXED_FIRST + 19, MIXED_FIRST + 39)) + list(
        range(MIXED_FIRST + 58, MIXED_FIRST + 78)
    )

    fixed_value = rhs[FIXED_ROW]
    fixed_structure = fixed_entries == [(VARIABLES, Decimal(1))] and fixed_value == 1
    constant = constant_objective * fixed_value

    def adjusted(node: int, state: int) -> Decimal:
        value = costs[node][state]
        if state < PERIODS:
            value += lam1[state] * weights1[node][state] + lam2[state] * weights2[node][state]
        return value

    exact_minimum = constant
    exact_minimum -= sum(value * capacity for value, capacity in zip(lam1, caps1))
    exact_minimum -= sum(value * capacity for value, capacity in zip(lam2, caps2))
    for path in paths:
        next_dp = [Decimal(0)] * (PERIODS + 1)
        for node in reversed(path):
            current = [Decimal(0)] * (PERIODS + 1)
            for minimum_state in range(PERIODS + 1):
                current[minimum_state] = min(
                    adjusted(node, state) + next_dp[state] for state in range(minimum_state, PERIODS + 1)
                )
            next_dp = current
        exact_minimum += next_dp[0]

    witness = cert["inner_minimizer_thresholds_zero_based_or_20_never"]
    witness_valid = (
        len(witness) == BLOCKS
        and all(isinstance(state, int) and 0 <= state <= PERIODS for state in witness)
        and all(witness[left] <= witness[right] for left, right in edges)
    )
    witness_value = constant
    witness_value -= sum(value * capacity for value, capacity in zip(lam1, caps1))
    witness_value -= sum(value * capacity for value, capacity in zip(lam2, caps2))
    witness_usage1 = [Decimal(0)] * PERIODS
    witness_usage2 = [Decimal(0)] * PERIODS
    if len(witness) == BLOCKS:
        for node, state in enumerate(witness):
            if isinstance(state, int) and 0 <= state <= PERIODS:
                witness_value += adjusted(node, state)
                if state < PERIODS:
                    witness_usage1[state] += weights1[node][state]
                    witness_usage2[state] += weights2[node][state]

    expected_dual_rows = [MIXED_FIRST + 19 + p for p in range(PERIODS)] + [
        MIXED_FIRST + 58 + p for p in range(PERIODS)
    ]
    checks = {
        "source_sha256_matches_certificate": source_hash == cert.get("source_mps_sha256"),
        "row_names_senses_and_layout_exact": row_layout,
        "no_ranges": ranges_seen == 0,
        "all_expected_columns_seen": all(seen_columns),
        "integer_columns_exactly_x1_through_x348920": all(integer_columns[:BINARY_VARIABLES])
        and not integer_columns[BINARY_VARIABLES],
        "binary_bounds_zero_one_and_constant_bound_zero_two": all(upper_one)
        and constant_upper_two
        and not unexpected_bounds,
        "vertical_suffix_constraints_exact": vertical_entries == 2 * VERTICAL_ROWS
        and vertical_complete
        and not vertical_errors,
        "mixed_entries_use_only_binary_columns": mixed_nonbinary_entries == 0,
        "difference_rows_are_le_zero_with_zero_rhs": all(row_types[row] == "L" and rhs[row] == 0 for row in difference_rows),
        "every_difference_row_block_state_contribution_nonpositive": not difference_state_positive_examples,
        "capacity_rows_are_le_constraints": all(row_types[row] == "L" for row in capacity_rows),
        "capacity_activity_has_exact_single_period_pattern": not capacity_pattern_examples,
        "horizontal_gadgets_exactly_encode_threshold_edges": not horizontal_errors and not template_examples,
        "threshold_graph_is_disjoint_path_forest": not path_errors and len(seen) == BLOCKS,
        "fixed_continuous_variable_and_objective_constant_exact": fixed_structure,
        "certificate_dualizes_exact_capacity_rows": cert.get("dualized_original_row_numbers") == expected_dual_rows,
        "multipliers_are_nonnegative_finite_decimals": multiplier_check,
        "certificate_witness_is_monotone": witness_valid,
        "certificate_witness_attains_dp_minimum": witness_value == exact_minimum,
        "certificate_resource_usage_matches_mps": [str(value) for value in witness_usage1]
        == cert.get("inner_minimizer_resource_usage_first")
        and [str(value) for value in witness_usage2] == cert.get("inner_minimizer_resource_usage_second"),
        "stored_bound_equals_exact_mps_recomputation": Decimal(cert["exact_decimal_lower_bound"]) == exact_minimum,
    }
    report = {
        "kind": "independent_exact_mps_reconstruction_of_mining_lagrangian_lower_bound",
        "inputs": {
            "mps": str(args.mps),
            "mps_sha256": source_hash,
            "certificate": str(args.certificate),
        },
        "checks": checks,
        "all_checks_passed": all(checks.values()),
        "recomputed_exact_decimal_lower_bound": str(exact_minimum),
        "recomputed_witness_lagrangian_value": str(witness_value),
        "objective_constant_from_fixed_x348921": str(constant),
        "blocks": len(costs),
        "threshold_edges": len(edges),
        "path_components": len(paths),
        "difference_state_contributions_checked": difference_state_count,
        "diagnostics": {
            "unexpected_bounds": unexpected_bounds,
            "vertical_errors": vertical_errors,
            "positive_difference_state_examples": difference_state_positive_examples,
            "capacity_pattern_examples": capacity_pattern_examples,
            "horizontal_matrix_errors": horizontal_errors,
            "horizontal_template_errors": template_examples,
            "path_errors": path_errors[:20],
        },
        "proof_scope": "global lower bound for the original integer minimization model",
    }
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["all_checks_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
