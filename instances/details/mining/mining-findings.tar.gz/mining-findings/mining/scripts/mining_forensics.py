#!/usr/bin/env python3
import argparse
import gzip
import hashlib
import json
import math
import os
import re
import struct
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from decimal import Decimal, getcontext

import gurobipy as gp
from gurobipy import GRB

getcontext().prec = 80
TOL = 1e-7
INF = float("inf")


def dec(x):
    """Exact decimal representation of the binary64 value exposed by Gurobi."""
    return Decimal(repr(float(x)))


def ds(x):
    if isinstance(x, Decimal):
        return format(x, "f")
    if math.isinf(float(x)):
        return "inf" if x > 0 else "-inf"
    return format(dec(x), "f")


def is_binary01(v):
    return v.VType in (GRB.BINARY, GRB.INTEGER) and v.LB == 0.0 and v.UB == 1.0


def terms_of(model, con):
    row = model.getRow(con)
    return [(row.getVar(i).index, row.getCoeff(i)) for i in range(row.size())]


def coeff_map(terms):
    d = defaultdict(float)
    for j, a in terms:
        d[j] += a
    return {j: a for j, a in d.items() if a != 0.0}


def exact_template(con, cm, pos, neg):
    return (
        con.Sense == GRB.LESS_EQUAL
        and con.RHS == 0.0
        and len(cm) == len(pos) + len(neg)
        and all(cm.get(j) == 1.0 for j in pos)
        and all(cm.get(j) == -1.0 for j in neg)
    )


def canonical_hash(cm):
    items = sorted(cm.items())
    sign = 1.0
    for _, a in items:
        if a:
            sign = 1.0 if a > 0 else -1.0
            break
    h = hashlib.sha256()
    for j, a in items:
        h.update(struct.pack(">q", j))
        h.update(float(sign * a).hex().encode("ascii"))
        h.update(b";")
    return h.hexdigest(), sign


def coefficient_summary(cm):
    vals = list(cm.values())
    av = [abs(x) for x in vals]
    return {
        "min": ds(min(vals)),
        "max": ds(max(vals)),
        "min_abs": ds(min(av)),
        "max_abs": ds(max(av)),
        "positive": sum(x > 0 for x in vals),
        "negative": sum(x < 0 for x in vals),
        "zero_after_aggregation": 0,
        "sum": ds(sum(dec(x) for x in vals)),
        "sum_abs": ds(sum(dec(abs(x)) for x in vals)),
    }


def parse_solution(path, name_to_index, n):
    values = [0.0] * n
    specified = set()

    opener = gzip.open if path.endswith(".gz") else open
    with opener(path, "rt", encoding="utf-8", errors="replace") as f:
        head = f.read(4096)

    if "<variable" in head or head.lstrip().startswith("<?xml"):
        with opener(path, "rt", encoding="utf-8", errors="replace") as f:
            root = ET.parse(f).getroot()
        for elem in root.iter():
            if elem.tag.rsplit("}", 1)[-1] != "variable":
                continue
            name, value = elem.attrib.get("name"), elem.attrib.get("value")
            if name in name_to_index and value is not None:
                j = name_to_index[name]
                values[j] = float(value)
                specified.add(j)
    else:
        with opener(path, "rt", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                fields = line.split()
                if len(fields) < 2 or fields[0] not in name_to_index:
                    continue
                try:
                    value = float(fields[1])
                except ValueError:
                    continue
                j = name_to_index[fields[0]]
                values[j] = value
                specified.add(j)

    return values, specified


def violation(sense, activity, rhs):
    if sense == GRB.LESS_EQUAL:
        return max(0.0, activity - rhs)
    if sense == GRB.GREATER_EQUAL:
        return max(0.0, rhs - activity)
    return abs(activity - rhs)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mps", required=True)
    ap.add_argument("--sol", action="append", default=[])
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()
    model = gp.read(args.mps, env=env)  # Read only: no optimize or presolve.

    vars_ = model.getVars()
    cons = model.getConstrs()
    n, m = len(vars_), len(cons)

    report = {
        "input": os.path.abspath(args.mps),
        "gurobi_version": list(gp.gurobi.version()),
        "model": {
            "name": model.ModelName,
            "sense": "min" if model.ModelSense == GRB.MINIMIZE else "max",
            "variables": n,
            "constraints": m,
            "objective_offset": ds(model.ObjCon),
        },
        "tolerance": TOL,
        "errors": [],
    }
    errors = report["errors"]

    # Matrix-supported ordering hypothesis: all 0/1 integer variables in model
    # order, partitioned into blocks only if every proposed vertical row exists.
    grid_vars = [v for v in vars_ if is_binary01(v)]
    nongrid = [v for v in vars_ if not is_binary01(v)]
    if len(grid_vars) % 20:
        errors.append("Number of [0,1] integer variables is not divisible by 20.")
    B = len(grid_vars) // 20
    if len(grid_vars) != 20 * B:
        B = 0

    grid_index = {v.index: (p // 20, p % 20) for p, v in enumerate(grid_vars)}
    expected_vertical = {
        (grid_vars[20 * b + t].index, grid_vars[20 * b + t + 1].index)
        for b in range(B) for t in range(19)
    }

    vertical_rows = defaultdict(list)
    boundary_rows = defaultdict(list)
    triple_rows = defaultdict(lambda: defaultdict(list))
    remainder = []
    malformed_local = []
    degree_counts = Counter()

    # A row is classified locally only by its exact coefficients, RHS, sense,
    # and its positions in the proposed chains.
    for con in cons:
        cm = coeff_map(terms_of(model, con))
        degree_counts[len(cm)] += 1
        classified = False

        if len(cm) == 2:
            pos = [j for j, a in cm.items() if a == 1.0]
            neg = [j for j, a in cm.items() if a == -1.0]
            if len(pos) == len(neg) == 1 and exact_template(con, cm, pos, neg):
                p, q = pos[0], neg[0]  # x_p <= x_q
                if (p, q) in expected_vertical:
                    vertical_rows[(p, q)].append(con.ConstrName)
                    classified = True
                elif p in grid_index and q in grid_index:
                    bp, tp = grid_index[p]
                    bq, tq = grid_index[q]
                    if tp == tq == 0 and bp != bq:
                        boundary_rows[(bq, bp)].append(con.ConstrName)
                        classified = True

        elif len(cm) == 3:
            pos = [j for j, a in cm.items() if a == 1.0]
            neg = [j for j, a in cm.items() if a == -1.0]
            if len(pos) == 1 and len(neg) == 2 and exact_template(con, cm, pos, neg):
                y = pos[0]
                if y in grid_index:
                    by, t = grid_index[y]
                    prev = grid_vars[20 * by + t - 1].index if t > 0 else None
                    if prev in neg:
                        other = neg[0] if neg[1] == prev else neg[1]
                        if other in grid_index:
                            bx, tx = grid_index[other]
                            if bx != by and tx == t:
                                triple_rows[(bx, by)][t].append(con.ConstrName)
                                classified = True

        if not classified:
            if len(cm) in (2, 3) and all(j in grid_index for j in cm):
                malformed_local.append(con.ConstrName)
            remainder.append((con, cm))

    missing_vertical = [e for e in expected_vertical if len(vertical_rows[e]) != 1]
    valid_edges, invalid_edges = [], []
    candidate_edges = set(boundary_rows) | set(triple_rows)

    for edge in sorted(candidate_edges):
        source, target = edge
        boundary = boundary_rows.get(edge, [])
        levels = triple_rows.get(edge, {})
        valid = (
            len(boundary) == 1
            and set(levels) == set(range(1, 20))
            and all(len(levels[t]) == 1 for t in range(1, 20))
        )
        item = {
            "source_chain": source,
            "target_chain": target,
            "boundary_row": boundary[0] if len(boundary) == 1 else boundary,
        }
        if valid:
            valid_edges.append(item)
        else:
            item["triple_level_multiplicity"] = {
                str(t): len(levels.get(t, [])) for t in range(1, 20)
                if len(levels.get(t, [])) != 1
            }
            invalid_edges.append(item)

    report["grid"] = {
        "levels": 20,
        "chains": B,
        "binary_variables": len(grid_vars),
        "construction": (
            "Model-order [0,1] integer variables partitioned into consecutive "
            "blocks of 20; accepted only through exact vertical-row verification."
        ),
        "vertical_pattern": "x(chain,t) - x(chain,t+1) <= 0",
        "expected_vertical_rows": 19 * B,
        "verified_vertical_rows": sum(len(x) == 1 for x in vertical_rows.values()),
        "missing_or_duplicate_vertical_rows": len(missing_vertical),
        "malformed_local_rows": malformed_local[:100],
        "malformed_local_rows_truncated": len(malformed_local) > 100,
    }
    report["local_edges"] = {
        "pattern": {
            "level_0": "x(target,0) - x(source,0) <= 0",
            "level_t": "x(target,t) - x(source,t) - x(target,t-1) <= 0",
            "inferred_threshold_direction": "threshold(source) <= threshold(target)",
        },
        "verified_count": len(valid_edges),
        "invalid_count": len(invalid_edges),
        "edges": valid_edges,
        "invalid_edges": invalid_edges[:100],
        "invalid_edges_truncated": len(invalid_edges) > 100,
    }

    if missing_vertical:
        errors.append(f"{len(missing_vertical)} vertical arcs are missing or duplicated.")
    if invalid_edges:
        errors.append(f"{len(invalid_edges)} candidate local edge blocks are incomplete.")
    if len(valid_edges) != 16479:
        errors.append(f"Expected 16479 local edge blocks, found {len(valid_edges)}.")
    if len(remainder) != 78:
        errors.append(f"Expected 78 remaining rows, found {len(remainder)}.")

    # Canonicalize opposite dense rows. For canonical expression z=a*x,
    # <= rows yield upper bounds and their negations yield lower bounds.
    groups = defaultdict(list)
    dense_records = []
    for con, cm in remainder:
        sig, orientation = canonical_hash(cm)
        lower, upper = -INF, INF
        rhs = con.RHS
        if con.Sense == GRB.LESS_EQUAL:
            if orientation > 0:
                upper = rhs
            else:
                lower = -rhs
        elif con.Sense == GRB.GREATER_EQUAL:
            if orientation > 0:
                lower = rhs
            else:
                upper = -rhs
        else:
            value = rhs if orientation > 0 else -rhs
            lower = upper = value

        touched = Counter()
        chains = set()
        nongrid_terms = []
        for j in cm:
            if j in grid_index:
                b, t = grid_index[j]
                touched[t] += 1
                chains.add(b)
            else:
                nongrid_terms.append(vars_[j].VarName)

        rec = {
            "row": con.ConstrName,
            "sense": con.Sense,
            "rhs": ds(rhs),
            "nnz": len(cm),
            "canonical_signature": sig,
            "canonical_orientation": 1 if orientation > 0 else -1,
            "native_canonical_lower": ds(lower),
            "native_canonical_upper": ds(upper),
            "coefficient_summary": coefficient_summary(cm),
            "chain_levels": sorted(touched),
            "terms_per_level": {str(k): touched[k] for k in sorted(touched)},
            "chains_touched": len(chains),
            "nongrid_variables": nongrid_terms,
        }
        dense_records.append(rec)
        groups[sig].append((rec, lower, upper))

    range_groups = []
    for sig, members in sorted(groups.items()):
        lower = max(x[1] for x in members)
        upper = min(x[2] for x in members)
        rows = [x[0]["row"] for x in members]
        group = {
            "canonical_signature": sig,
            "rows": rows,
            "lower": ds(lower),
            "upper": ds(upper),
            "paired_opposite_rows": (
                any(x[0]["canonical_orientation"] > 0 for x in members)
                and any(x[0]["canonical_orientation"] < 0 for x in members)
            ),
        }
        range_groups.append(group)
        for rec, _, _ in members:
            rec["range_group_lower"] = ds(lower)
            rec["range_group_upper"] = ds(upper)
            rec["range_group_rows"] = rows

    report["remaining_rows"] = {
        "count": len(remainder),
        "interpretation": (
            "Bounds are reconstructed from the row senses exposed by Gurobi; "
            "exact opposite coefficient vectors are combined into canonical intervals."
        ),
        "rows": dense_records,
        "range_groups": range_groups,
    }

    # Objective decomposition. Threshold k=0..19 means levels k..19 are one;
    # k=20 means the entire chain is zero.
    fixed_constant = dec(model.ObjCon)
    fixed_terms = []
    for v in vars_:
        if v.LB == v.UB and v.LB != 0.0:
            contribution = dec(v.Obj) * dec(v.LB)
            fixed_constant += contribution
            fixed_terms.append({
                "variable": v.VarName,
                "value": ds(v.LB),
                "objective_coefficient": ds(v.Obj),
                "contribution": ds(contribution),
            })

    threshold_costs = []
    for b in range(B):
        inc = [dec(grid_vars[20 * b + t].Obj) for t in range(20)]
        suffix = [Decimal(0)] * 21
        for t in range(19, -1, -1):
            suffix[t] = suffix[t + 1] + inc[t]
        threshold_costs.append({
            "chain": b,
            "variables": [grid_vars[20 * b + t].VarName for t in range(20)],
            "incremental_level_cost": [ds(x) for x in inc],
            "threshold_suffix_cost": [ds(x) for x in suffix],
        })

    report["objective_decomposition"] = {
        "fixed_nonzero_terms": fixed_terms,
        "exact_fixed_constant_from_gurobi_binary64_values": ds(fixed_constant),
        "threshold_convention": "k=0..19 selects levels k..19; k=20 selects none",
        "chains": threshold_costs,
    }

    # Parse all supplied solutions, then audit all of them in one matrix pass.
    name_to_index = {v.VarName: v.index for v in vars_}
    audits = []
    solution_data = []
    for path in args.sol:
        values, specified = parse_solution(path, name_to_index, n)
        objective = dec(model.ObjCon)
        bound_count = int_count = 0
        max_bound = max_int = 0.0
        worst_bound = worst_int = None

        for v in vars_:
            x = values[v.index]
            objective += dec(v.Obj) * dec(x)
            bv = max(0.0, v.LB - x, x - v.UB)
            if bv > TOL:
                bound_count += 1
            if bv > max_bound:
                max_bound, worst_bound = bv, v.VarName
            if v.VType in (GRB.BINARY, GRB.INTEGER):
                iv = abs(x - round(x))
                if iv > TOL:
                    int_count += 1
                if iv > max_int:
                    max_int, worst_int = iv, v.VarName

        audit = {
            "file": os.path.abspath(path),
            "specified_variables": len(specified),
            "unspecified_assumed_zero": n - len(specified),
            "recomputed_objective": ds(objective),
            "bound_violations": bound_count,
            "max_bound_violation": max_bound,
            "worst_bound_variable": worst_bound,
            "integrality_violations": int_count,
            "max_integrality_violation": max_int,
            "worst_integrality_variable": worst_int,
            "row_violations": 0,
            "max_row_violation": 0.0,
            "worst_row": None,
        }
        audits.append(audit)
        solution_data.append(values)

    if solution_data:
        for con in cons:
            row = model.getRow(con)
            for k, values in enumerate(solution_data):
                activity = math.fsum(
                    row.getCoeff(i) * values[row.getVar(i).index]
                    for i in range(row.size())
                )
                rv = violation(con.Sense, activity, con.RHS)
                if rv > TOL:
                    audits[k]["row_violations"] += 1
                if rv > audits[k]["max_row_violation"]:
                    audits[k]["max_row_violation"] = rv
                    audits[k]["worst_row"] = con.ConstrName

        for audit in audits:
            audit["feasible_at_tolerance"] = (
                audit["bound_violations"] == 0
                and audit["integrality_violations"] == 0
                and audit["row_violations"] == 0
            )

    report["solutions"] = audits
    report["degree_counts"] = {str(k): v for k, v in sorted(degree_counts.items())}
    report["structure_ok"] = not errors

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, sort_keys=False, allow_nan=False)
        f.write("\n")

    model.dispose()
    env.dispose()


if __name__ == "__main__":
    main()
