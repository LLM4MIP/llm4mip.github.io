#!/usr/bin/env python3
import argparse
import gzip
import hashlib
import json
import math
import os
import random
import time
from collections import defaultdict
from decimal import Decimal, getcontext

import gurobipy as gp
from gurobipy import GRB
from ortools.graph.python import max_flow

getcontext().prec = 80
T = 20
GTOL = 1e-7
I64_SAFE = (1 << 61) - 1


def D(x):
    return x if isinstance(x, Decimal) else Decimal(repr(float(x)))


def dstr(x):
    if x is None:
        return None
    if isinstance(x, float) and math.isinf(x):
        return "inf" if x > 0 else "-inf"
    return format(D(x), "f")


def open_text(path):
    return gzip.open(path, "rt", encoding="utf-8", errors="replace") \
        if path.endswith(".gz") else open(path, "rt", encoding="utf-8", errors="replace")


def row_map(model, con):
    row = model.getRow(con)
    out = defaultdict(float)
    for i in range(row.size()):
        out[row.getVar(i).index] += row.getCoeff(i)
    return {j: a for j, a in out.items() if a != 0.0}


def vector_signature(cm):
    items = sorted(cm.items())
    sign = 1 if items[0][1] > 0 else -1
    h = hashlib.sha256()
    for j, a in items:
        h.update(str(j).encode())
        h.update(b":")
        h.update(float(sign * a).hex().encode())
        h.update(b";")
    return h.hexdigest(), sign


def parse_solution(path, name_to_idx, n):
    x = [0.0] * n
    specified = set()
    with open_text(path) as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith("#") or s.startswith("<"):
                continue
            p = s.split()
            if len(p) >= 2 and p[0] in name_to_idx:
                try:
                    x[name_to_idx[p[0]]] = float(p[1])
                    specified.add(name_to_idx[p[0]])
                except ValueError:
                    pass
    return x, specified


def audit_solution(model, x, tol=GTOL):
    vars_ = model.getVars()
    objective = D(model.ObjCon)
    max_bound = max_int = max_row = 0.0
    nbound = nint = nrow = 0
    worst_bound = worst_int = worst_row = None

    for v in vars_:
        z = x[v.index]
        objective += D(v.Obj) * D(z)
        bv = max(0.0, v.LB - z, z - v.UB)
        if bv > tol:
            nbound += 1
        if bv > max_bound:
            max_bound, worst_bound = bv, v.VarName
        if v.VType in (GRB.BINARY, GRB.INTEGER):
            iv = abs(z - round(z))
            if iv > tol:
                nint += 1
            if iv > max_int:
                max_int, worst_int = iv, v.VarName

    for con in model.getConstrs():
        row = model.getRow(con)
        act = math.fsum(row.getCoeff(i) * x[row.getVar(i).index]
                        for i in range(row.size()))
        if con.Sense == GRB.LESS_EQUAL:
            rv = max(0.0, act - con.RHS)
        elif con.Sense == GRB.GREATER_EQUAL:
            rv = max(0.0, con.RHS - act)
        else:
            rv = abs(act - con.RHS)
        if rv > tol:
            nrow += 1
        if rv > max_row:
            max_row, worst_row = rv, con.ConstrName

    return {
        "objective_gurobi_binary64_recomputation": dstr(objective),
        "bound_violations": nbound,
        "integrality_violations": nint,
        "row_violations": nrow,
        "max_bound_violation": max_bound,
        "max_integrality_violation": max_int,
        "max_row_violation": max_row,
        "worst_bound_variable": worst_bound,
        "worst_integrality_variable": worst_int,
        "worst_row": worst_row,
        "feasible": nbound == 0 and nint == 0 and nrow == 0,
    }


def parse_raw_mps(path, wanted_rows, wanted_vars):
    """Read exact decimal tokens for selected rows and the objective."""
    row_types = {}
    obj_row = None
    coeff = {r: defaultdict(Decimal) for r in wanted_rows}
    obj = defaultdict(Decimal)
    rhs = defaultdict(Decimal)
    ranges = defaultdict(Decimal)
    section = None

    with open_text(path) as f:
        for raw in f:
            if not raw.strip() or raw.lstrip().startswith("*"):
                continue
            p = raw.split()
            if not p:
                continue
            head = p[0].upper()
            if head in ("NAME", "ROWS", "COLUMNS", "RHS", "RANGES",
                        "BOUNDS", "ENDATA", "OBJSENSE", "OBJNAME"):
                section = head
                if head == "ENDATA":
                    break
                continue

            if section == "ROWS" and len(p) >= 2:
                row_types[p[1]] = p[0].upper()
                if p[0].upper() == "N" and obj_row is None:
                    obj_row = p[1]

            elif section == "COLUMNS":
                if len(p) >= 3 and ("MARKER" not in raw.upper()):
                    var = p[0]
                    for k in range(1, len(p) - 1, 2):
                        r = p[k]
                        try:
                            val = Decimal(p[k + 1])
                        except Exception:
                            continue
                        if r == obj_row and (not wanted_vars or var in wanted_vars):
                            obj[var] += val
                        if r in wanted_rows:
                            coeff[r][var] += val

            elif section in ("RHS", "RANGES") and len(p) >= 3:
                target = rhs if section == "RHS" else ranges
                for k in range(1, len(p) - 1, 2):
                    r = p[k]
                    if r in wanted_rows or r == obj_row:
                        target[r] += Decimal(p[k + 1])

    coeff = {r: {v: a for v, a in cm.items() if a}
             for r, cm in coeff.items()}
    return {
        "row_types": row_types,
        "objective_row": obj_row,
        "coeff": coeff,
        "objective": dict(obj),
        "rhs": dict(rhs),
        "ranges": dict(ranges),
    }


def decimal_places(x):
    return max(0, -x.as_tuple().exponent)


def to_scaled(x, scale):
    y = x * scale
    if y != y.to_integral_value():
        raise ValueError("nonintegral decimal scaling")
    return int(y)


def thresholds_to_x(tau, grid, n, fixed_idx):
    x = [0.0] * n
    for b, k in enumerate(tau):
        for t in range(k, T):
            x[grid[T * b + t].index] = 1.0
    x[fixed_idx] = 1.0
    return x


def closure_valid(tau, edges):
    return all(tau[u] <= tau[v] for u, v in edges)


def logical_activities(tau, unary):
    ans = []
    for table in unary:
        ans.append(sum(table.get(b, ZERO21)[tau[b]] for b in table))
    return ans


ZERO21 = tuple([0] * 21)


def feasible_logical(acts, logical):
    for a, r in zip(acts, logical):
        if r["lower"] is not None and a < r["lower"]:
            return False
        if r["upper"] is not None and a > r["upper"]:
            return False
    return True


def violation_score(acts, logical):
    score = 0.0
    for a, r in zip(acts, logical):
        span = max(1, abs(r["scale_hint"]))
        if r["lower"] is not None and a < r["lower"]:
            score += float(r["lower"] - a) / span
        if r["upper"] is not None and a > r["upper"]:
            score += float(a - r["upper"]) / span
    return score


def propagate_move(tau, start, newk, out_edges, in_edges):
    """Return a closure-preserving threshold vector after one forced move."""
    z = list(tau)
    if newk == z[start]:
        return z
    stack = [(start, newk)]
    while stack:
        v, k = stack.pop()
        k = max(0, min(20, k))
        if k == z[v]:
            continue
        old = z[v]
        z[v] = k
        if k < old:                 # predecessors must be <= new threshold
            for u in in_edges[v]:
                if z[u] > k:
                    stack.append((u, k))
        else:                       # successors must be >= new threshold
            for w in out_edges[v]:
                if z[w] < k:
                    stack.append((w, k))
    return z


def build_inequalities(logical):
    """Each inequality is A*x <= b in common exact integer scaling."""
    inequalities = []
    for r, item in enumerate(logical):
        if item["upper"] is not None:
            inequalities.append({
                "logical": r, "kind": "upper", "sign": 1,
                "bound": item["upper"]
            })
        if item["lower"] is not None:
            inequalities.append({
                "logical": r, "kind": "lower", "sign": -1,
                "bound": -item["lower"]
            })
    return inequalities


def inequality_activity(logical_activity, inequality):
    return inequality["sign"] * logical_activity[inequality["logical"]]


def max_closure_oracle(base_cost, logical_coeff, inequalities, q, qden,
                       implications):
    """
    Exact rational modified costs have numerator
      n_i = qden*c_i + sum_j q_j*A_ji.
    Capacities use rounded n_i/divisor. A rigorous lower correction is retained.
    """
    n = len(base_cost)
    numer = [qden * c for c in base_cost]
    constant_adjust = 0

    for j, mult in enumerate(q):
        if not mult:
            continue
        iq = inequalities[j]
        r, s = iq["logical"], iq["sign"]
        constant_adjust -= mult * iq["bound"]
        cm = logical_coeff[r]
        sm = mult * s
        for i, a in cm.items():
            numer[i] += sm * a

    total_abs = sum(abs(v) for v in numer)
    divisor = max(1, (total_abs + I64_SAFE - 1) // I64_SAFE)
    rounded = []
    rounding_error = 0
    for v in numer:
        if v >= 0:
            z = (v + divisor // 2) // divisor
        else:
            z = -((-v + divisor // 2) // divisor)
        rounded.append(z)
        rounding_error += abs(v - divisor * z)

    weights = [-z for z in rounded]  # maximize -modified cost
    positive_sum = sum(w for w in weights if w > 0)
    finite_sum = sum(abs(w) for w in weights)
    infcap = finite_sum + 1
    if infcap > I64_SAFE:
        raise OverflowError("safe implication capacity exceeds int64 budget")

    source, sink = n, n + 1
    mf = max_flow.SimpleMaxFlow()
    for i, w in enumerate(weights):
        if w > 0:
            mf.add_arc_with_capacity(source, i, int(w))
        elif w < 0:
            mf.add_arc_with_capacity(i, sink, int(-w))
    for u, v in implications:
        mf.add_arc_with_capacity(u, v, int(infcap))

    status = mf.solve(source, sink)
    if status != mf.OPTIMAL:
        raise RuntimeError(f"SimpleMaxFlow status {status}")

    selected = set(mf.get_source_side_min_cut())
    selected.discard(source)
    selected.discard(sink)
    cut_value = int(mf.optimal_flow())
    quantized_min = cut_value - positive_sum

    # For every subset S:
    # sum n_i x_i >= divisor*sum rounded_i*x_i - total rounding error.
    lower_numerator = (constant_adjust + divisor * quantized_min
                       - rounding_error)

    implication_cut = sum(1 for u, v in implications
                          if u in selected and v not in selected)
    h = hashlib.sha256()
    for i in sorted(selected):
        h.update(i.to_bytes(4, "little", signed=False))

    return {
        "selected": selected,
        "lower_numerator": lower_numerator,
        "qden": qden,
        "divisor": divisor,
        "rounding_error": rounding_error,
        "cut_value": cut_value,
        "positive_weight_sum": positive_sum,
        "quantized_min": quantized_min,
        "implication_cut_count": implication_cut,
        "selected_hash": h.hexdigest(),
        "selected_count": len(selected),
        "exact_capacity_oracle": divisor == 1 and rounding_error == 0,
    }


def selected_to_tau(selected, B):
    tau = [20] * B
    for b in range(B):
        for t in range(T):
            if T * b + t in selected:
                tau[b] = t
                break
    return tau


def exact_objective(tau, obj_unary, constant):
    return constant + sum(obj_unary[b][tau[b]] for b in range(len(tau)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mps", required=True)
    ap.add_argument("--sol", action="append", default=[])
    ap.add_argument("--out", required=True)
    ap.add_argument("--time", type=float, default=600.0)
    ap.add_argument("--iterations", type=int, default=100)
    ap.add_argument("--seed", type=int, default=1)
    args = ap.parse_args()

    started = time.monotonic()
    deadline = started + args.time
    rng = random.Random(args.seed)

    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()
    model = gp.read(args.mps, env=env)  # Never optimize or presolve.
    vars_ = model.getVars()
    cons = model.getConstrs()
    n = len(vars_)

    report = {
        "input": os.path.abspath(args.mps),
        "seed": args.seed,
        "time_limit": args.time,
        "iteration_limit": args.iterations,
        "errors": [],
        "progress": [],
    }

    grid = [v for v in vars_
            if v.VType in (GRB.BINARY, GRB.INTEGER)
            and v.LB == 0.0 and v.UB == 1.0]
    if len(grid) != 348920:
        raise RuntimeError(f"expected 348920 grid variables, got {len(grid)}")
    B = len(grid) // T
    pos = {v.index: (k // T, k % T) for k, v in enumerate(grid)}

    expected_vertical = {
        (grid[T * b + t].index, grid[T * b + t + 1].index)
        for b in range(B) for t in range(19)
    }
    vertical = defaultdict(list)
    boundary = defaultdict(list)
    triples = defaultdict(lambda: defaultdict(list))
    singleton = None
    remainder = []

    for con in cons:
        cm = row_map(model, con)
        classified = False
        if (len(cm) == 2 and con.Sense == GRB.LESS_EQUAL and con.RHS == 0.0
                and sorted(cm.values()) == [-1.0, 1.0]):
            p = next(j for j, a in cm.items() if a == 1.0)
            qv = next(j for j, a in cm.items() if a == -1.0)
            if (p, qv) in expected_vertical:
                vertical[(p, qv)].append(con.ConstrName)
                classified = True
            elif p in pos and qv in pos:
                bp, tp = pos[p]
                bq, tq = pos[qv]
                if tp == tq == 0 and bp != bq:
                    boundary[(bq, bp)].append(con.ConstrName)
                    classified = True

        elif (len(cm) == 3 and con.Sense == GRB.LESS_EQUAL and con.RHS == 0.0
              and sorted(cm.values()) == [-1.0, -1.0, 1.0]):
            y = next(j for j, a in cm.items() if a == 1.0)
            if y in pos:
                by, t = pos[y]
                if t > 0:
                    prev = grid[T * by + t - 1].index
                    neg = [j for j, a in cm.items() if a == -1.0]
                    if prev in neg:
                        other = neg[0] if neg[1] == prev else neg[1]
                        if other in pos:
                            bx, tx = pos[other]
                            if bx != by and tx == t:
                                triples[(bx, by)][t].append(con.ConstrName)
                                classified = True

        if not classified:
            if (len(cm) == 1 and con.Sense == GRB.EQUAL
                    and con.RHS == 1.0):
                j, a = next(iter(cm.items()))
                if vars_[j].VarName == "x348921" and a == 1.0:
                    singleton = (con, j)
                    classified = True
            if not classified:
                remainder.append((con, cm))

    missing_vertical = sum(len(vertical[e]) != 1 for e in expected_vertical)
    candidate_edges = set(boundary) | set(triples)
    edges = []
    bad_edges = []
    for e in sorted(candidate_edges):
        ok = (len(boundary.get(e, [])) == 1
              and set(triples.get(e, {})) == set(range(1, 20))
              and all(len(triples[e][t]) == 1 for t in range(1, 20)))
        (edges if ok else bad_edges).append(e)

    if missing_vertical or bad_edges or len(edges) != 16479:
        raise RuntimeError("local structure audit failed")
    if singleton is None:
        raise RuntimeError("x348921 singleton equality not found")
    if len(remainder) != 78:
        raise RuntimeError(f"expected 78 dense rows, got {len(remainder)}")

    fixed_con, fixed_idx = singleton
    fixed_var = vars_[fixed_idx]
    if any(fixed_idx in cm for _, cm in remainder):
        raise RuntimeError("fixed variable occurs in dense rows")

    groups = defaultdict(list)
    for con, cm in remainder:
        sig, orientation = vector_signature(cm)
        groups[sig].append((con, cm, orientation))
    if sorted(len(g) for g in groups.values()) != [1, 1] + [2] * 38:
        raise RuntimeError("dense rows do not form 38 pairs plus two singletons")

    wanted_rows = {c.ConstrName for c, _ in remainder}
    wanted_rows.add(fixed_con.ConstrName)
    wanted_vars = {v.VarName for v in grid}
    wanted_vars.add(fixed_var.VarName)
    raw = parse_raw_mps(args.mps, wanted_rows, wanted_vars)

    all_decimals = [D(model.ObjCon)]
    all_decimals.extend(raw["objective"].values())
    all_decimals.extend(raw["rhs"].values())
    for cm in raw["coeff"].values():
        all_decimals.extend(cm.values())
    scale = Decimal(10) ** max(decimal_places(x) for x in all_decimals)
    scale_i = int(scale)

    name_to_grid = {v.VarName: k for k, v in enumerate(grid)}
    obj_coeff = [0] * len(grid)
    for name, value in raw["objective"].items():
        if name in name_to_grid:
            obj_coeff[name_to_grid[name]] = to_scaled(value, scale)

    fixed_obj = raw["objective"].get(fixed_var.VarName, D(fixed_var.Obj))
    objective_constant = to_scaled(D(model.ObjCon) + fixed_obj, scale)

    logical = []
    logical_coeff = []
    pairing_report = []

    for sig, members in sorted(groups.items()):
        canonical_maps = []
        lower = upper = None
        row_names = []
        for con, _, orientation in members:
            rn = con.ConstrName
            row_names.append(rn)
            raw_cm = raw["coeff"].get(rn, {})
            im = {}
            for vn, a in raw_cm.items():
                if vn not in name_to_grid:
                    raise RuntimeError(f"nongrid term {vn} in dense row {rn}")
                im[name_to_grid[vn]] = orientation * to_scaled(a, scale)
            canonical_maps.append(im)

            rrhs = to_scaled(raw["rhs"].get(rn, D(con.RHS)), scale)
            rrhs *= orientation
            if con.Sense == GRB.LESS_EQUAL:
                if orientation > 0:
                    upper = rrhs if upper is None else min(upper, rrhs)
                else:
                    lower = rrhs if lower is None else max(lower, rrhs)
            elif con.Sense == GRB.GREATER_EQUAL:
                if orientation > 0:
                    lower = rrhs if lower is None else max(lower, rrhs)
                else:
                    upper = rrhs if upper is None else min(upper, rrhs)
            else:
                lower = upper = rrhs

        base = canonical_maps[0]
        for cm in canonical_maps[1:]:
            if cm != base:
                raise RuntimeError(f"raw exact opposite-vector audit failed: {row_names}")

        idx = len(logical)
        logical_coeff.append(base)
        hint = max([1] + [abs(a) for a in base.values()])
        logical.append({
            "rows": row_names,
            "lower": lower,
            "upper": upper,
            "scale_hint": hint,
        })
        pairing_report.append({
            "logical": idx,
            "rows": row_names,
            "lower_scaled": lower,
            "upper_scaled": upper,
            "nnz": len(base),
            "raw_range_entries": {
                r: dstr(raw["ranges"][r]) for r in row_names
                if r in raw["ranges"]
            },
        })

    if len(logical) != 40:
        raise RuntimeError("logical side count is not 40")

    # Unary side tables and objective suffix tables.
    obj_unary = []
    for b in range(B):
        s = [0] * 21
        for t in range(19, -1, -1):
            s[t] = s[t + 1] + obj_coeff[T * b + t]
        obj_unary.append(tuple(s))

    unary = []
    for cm in logical_coeff:
        by_chain = defaultdict(lambda: [0] * 20)
        for i, a in cm.items():
            b, t = divmod(i, 20)
            by_chain[b][t] += a
        table = {}
        for b, levels in by_chain.items():
            s = [0] * 21
            for t in range(19, -1, -1):
                s[t] = s[t + 1] + levels[t]
            table[b] = tuple(s)
        unary.append(table)

    out_edges = [[] for _ in range(B)]
    in_edges = [[] for _ in range(B)]
    for u, v in edges:
        out_edges[u].append(v)
        in_edges[v].append(u)

    implications = []
    for b in range(B):
        for t in range(19):
            implications.append((T * b + t, T * b + t + 1))
    for u, v in edges:
        for t in range(20):
            implications.append((T * v + t, T * u + t))

    inequalities = build_inequalities(logical)
    if len(inequalities) != 78:
        raise RuntimeError(f"expected 78 finite side inequalities, got {len(inequalities)}")

    name_to_idx = {v.VarName: v.index for v in vars_}
    incumbent_tau = None
    incumbent_obj = None
    incumbent_x = None
    supplied_audits = []

    for path in args.sol:
        x, specified = parse_solution(path, name_to_idx, n)
        audit = audit_solution(model, x)
        audit["file"] = os.path.abspath(path)
        audit["specified_variables"] = len(specified)
        supplied_audits.append(audit)
        if not audit["feasible"]:
            continue
        tau = [20] * B
        suffix_ok = True
        for b in range(B):
            vals = [round(x[grid[T * b + t].index]) for t in range(20)]
            ones = [t for t, z in enumerate(vals) if z]
            k = min(ones) if ones else 20
            if vals != [int(t >= k) for t in range(20)]:
                suffix_ok = False
                break
            tau[b] = k
        if not suffix_ok or not closure_valid(tau, edges):
            continue
        acts = logical_activities(tau, unary)
        if not feasible_logical(acts, logical):
            continue
        val = exact_objective(tau, obj_unary, objective_constant)
        if incumbent_obj is None or val < incumbent_obj:
            incumbent_tau, incumbent_obj, incumbent_x = tau, val, x

    if incumbent_tau is None:
        raise RuntimeError("at least one supplied solution must be feasible")

    base_cost = list(obj_coeff)
    qden = 1_000_000
    q = [0] * len(inequalities)
    best_lb_num = None
    best_cert = None
    improved = False

    def consider(tau, origin):
        nonlocal incumbent_tau, incumbent_obj, incumbent_x, improved
        if not closure_valid(tau, edges):
            return False
        acts = logical_activities(tau, unary)
        if not feasible_logical(acts, logical):
            return False
        val = exact_objective(tau, obj_unary, objective_constant)
        if val >= incumbent_obj:
            return False
        x = thresholds_to_x(tau, grid, n, fixed_idx)
        audit = audit_solution(model, x)
        if not audit["feasible"]:
            return False
        incumbent_tau, incumbent_obj, incumbent_x = list(tau), val, x
        improved = True
        report["progress"].append({
            "event": "incumbent", "origin": origin,
            "objective_scaled": val,
            "objective": dstr(Decimal(val) / scale),
            "audit": audit,
        })
        return True

    for it in range(args.iterations):
        if time.monotonic() >= deadline:
            break

        oracle = max_closure_oracle(
            base_cost, logical_coeff, inequalities, q, qden, implications)
        tau = selected_to_tau(oracle["selected"], B)
        if not closure_valid(tau, edges):
            raise RuntimeError("min-cut returned a nonclosed assignment")

        # Add the fixed objective constant to the oracle's Lagrangian bound.
        lb_num = qden * objective_constant + oracle["lower_numerator"]
        if best_lb_num is None or lb_num > best_lb_num:
            best_lb_num = lb_num
            best_cert = {
                "iteration": it,
                "multipliers_numerator": list(q),
                "multipliers_denominator": qden,
                "capacity_divisor": oracle["divisor"],
                "rounding_error_numerator": oracle["rounding_error"],
                "cut_value": oracle["cut_value"],
                "positive_weight_sum": oracle["positive_weight_sum"],
                "quantized_min": oracle["quantized_min"],
                "selected_hash": oracle["selected_hash"],
                "selected_count": oracle["selected_count"],
                "implication_cut_count": oracle["implication_cut_count"],
                "exact_capacity_oracle": oracle["exact_capacity_oracle"],
                "certified_lower_bound_numerator": lb_num,
                "certified_lower_bound_denominator": qden * scale_i,
                "certified_lower_bound":
                    dstr(Decimal(lb_num) / Decimal(qden * scale_i)),
                "thresholds": tau,
            }

        acts = logical_activities(tau, unary)
        consider(tau, f"lagrangian-{it}")

        # Closure lattice combinations with the incumbent.
        consider([min(a, b) for a, b in zip(tau, incumbent_tau)],
                 f"union-{it}")
        consider([max(a, b) for a, b in zip(tau, incumbent_tau)],
                 f"intersection-{it}")

        # Deterministic closure-preserving repair toward logical feasibility.
        repaired = list(tau)
        repaired_acts = acts
        for step_no in range(40):
            if time.monotonic() >= deadline:
                break
            old_score = violation_score(repaired_acts, logical)
            if old_score == 0:
                consider(repaired, f"repair-{it}")
                break
            candidates = set(rng.sample(range(B), min(160, B)))
            candidates.update(
                b for b in range(B) if repaired[b] != incumbent_tau[b]
                and rng.random() < 0.02
            )
            best = None
            for b in sorted(candidates):
                targets = set()
                if repaired[b] > 0:
                    targets.add(repaired[b] - 1)
                if repaired[b] < 20:
                    targets.add(repaired[b] + 1)
                targets.add(incumbent_tau[b])
                for k in sorted(targets):
                    z = propagate_move(repaired, b, k, out_edges, in_edges)
                    if z == repaired:
                        continue
                    za = logical_activities(z, unary)
                    sc = violation_score(za, logical)
                    obj = exact_objective(z, obj_unary, objective_constant)
                    key = (sc, obj, b, k)
                    if best is None or key < best[0]:
                        best = (key, z, za)
            if best is None or best[0][0] >= old_score:
                break
            repaired, repaired_acts = best[1], best[2]
        if feasible_logical(repaired_acts, logical):
            consider(repaired, f"repair-final-{it}")

        # Stabilized projected subgradient update using exact integer activities.
        gradients = []
        norm2 = 0.0
        for iq in inequalities:
            # inequality_activity selects the relevant logical row itself.
            # Passing one scalar here made it subscript an int after the first
            # expensive closure-oracle call.
            g = inequality_activity(acts, iq) - iq["bound"]
            gradients.append(g)
            norm2 += float(g) * float(g)

        lb_float = float(Decimal(lb_num) / Decimal(qden * scale_i))
        ub_float = float(Decimal(incumbent_obj) / scale)
        if norm2 > 0:
            theta = 1.5 / math.sqrt(it + 1.0)
            step = theta * max(1.0, ub_float - lb_float) / norm2
            for j, g in enumerate(gradients):
                lam = q[j] / qden + step * float(g) / scale_i
                q[j] = max(0, int(round(lam * qden)))

        report["progress"].append({
            "event": "iteration",
            "iteration": it,
            "certified_lb": dstr(Decimal(lb_num) /
                                 Decimal(qden * scale_i)),
            "best_incumbent": dstr(Decimal(incumbent_obj) / scale),
            "logical_violation_score": violation_score(acts, logical),
            "nonzero_multipliers": sum(v != 0 for v in q),
            "capacity_divisor": oracle["divisor"],
            "exact_capacity_oracle": oracle["exact_capacity_oracle"],
        })

    final_audit = audit_solution(model, incumbent_x)
    exact_acts = logical_activities(incumbent_tau, unary)

    report.update({
        "structure": {
            "chains": B,
            "levels": T,
            "vertical_rows": len(expected_vertical),
            "missing_or_duplicate_vertical": missing_vertical,
            "spatial_edge_blocks": len(edges),
            "dense_row_objects": len(remainder),
            "logical_side_constraints": len(logical),
            "finite_side_inequalities": len(inequalities),
            "singleton": {
                "row": fixed_con.ConstrName,
                "variable": fixed_var.VarName,
                "rhs": dstr(fixed_con.RHS),
                "objective_coefficient_exact_token": dstr(fixed_obj),
                "fixed_by_row_not_bounds": fixed_var.LB != fixed_var.UB,
            },
        },
        "decimal_scale": scale_i,
        "range_pairing": pairing_report,
        "supplied_solutions": supplied_audits,
        "best_primal": {
            "strictly_improved": improved,
            "objective_scaled": incumbent_obj,
            "objective": dstr(Decimal(incumbent_obj) / scale),
            "thresholds": incumbent_tau,
            "logical_activities_scaled": exact_acts,
            "original_model_audit": final_audit,
        },
        "best_dual_certificate": best_cert,
        "certificate_note": (
            "The reported lower bound is rigorous for the exact decimal-scaled "
            "reduced model. If capacity division was needed, the bound subtracts "
            "the sum of all exact coefficient-rounding errors. A divisor of one "
            "with zero rounding error is an exact integral min-cut oracle."
        ),
        "elapsed_seconds": time.monotonic() - started,
    })

    out_json = args.out if args.out.endswith(".json") else args.out + ".json"
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, allow_nan=False)
        f.write("\n")

    if improved:
        sol_path = args.out[:-5] + ".sol" if args.out.endswith(".json") \
            else args.out + ".sol"
        with open(sol_path, "w", encoding="utf-8") as f:
            f.write(f"# objective {dstr(Decimal(incumbent_obj) / scale)}\n")
            for v in vars_:
                z = incumbent_x[v.index]
                if abs(z) > GTOL:
                    f.write(f"{v.VarName} {int(round(z)) if abs(z-round(z)) < GTOL else repr(z)}\n")

    model.dispose()
    env.dispose()


if __name__ == "__main__":
    main()
