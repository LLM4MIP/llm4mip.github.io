# Package manifest: fhnw-schedule-pairb200

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 29
Excluded source files: 2

## Included files

- `README.md`
- `artifacts/common-deadline-master/common-deadline-master-result.json`
- `artifacts/common-deadline-master/common-deadline-master.log`
- `artifacts/common-deadline-master/common-deadline-master.mps.gz`
- `artifacts/common-deadline-master/semantic-audit.json`
- `artifacts/energy-cuts-original-mps-audit.json`
- `artifacts/energy-cuts-proof-proof.mps.gz`
- `artifacts/paira-cross-formulation-direct-audit.json`
- `artifacts/proof-model-independent-run.json`
- `artifacts/proof-semantic-audit.json`
- `artifacts/structure-public-audit.json`
- `artifacts/summary.json`
- `experiments/baseline-with-new-incumbent-600s.json`
- `experiments/baseline-with-new-incumbent-600s.log`
- `experiments/energy-cuts-proof.json`
- `experiments/energy-cuts-proof.log`
- `experiments/proof-model-independent-run.log`
- `input/SHA256SUMS`
- `input/fhnw-schedule-pairb200-public.sol.gz`
- `reports/SOURCES.md`
- `reports/deep-study-2026-09-08.zh.md`
- `scripts/audit_common_deadline_master.py`
- `scripts/paira_reconstruct.py`
- `scripts/pairb_common_deadline_master.py`
- `scripts/pairb_energy_solver.py`
- `scripts/pairb_proof_audit.py`
- `scripts/pairb_reconstruct.py`
- `solutions/new-optimal-candidate.sol`
- `solutions/paira-cross-formulation-direct.sol`

## Excluded files

- `input/fhnw-schedule-paira200.mps.gz (720605 bytes; raw benchmark input; sha256 7885f1890b486001d9ce113c02de48c12c54bb6bcd22b10db985cf74208e13d2)`
- `input/fhnw-schedule-pairb200.mps.gz (1470041 bytes; raw benchmark input; sha256 eae693ba9b5fcf49330a1dc939a435772778718419e4550a39a8466bf6b99b70)`
