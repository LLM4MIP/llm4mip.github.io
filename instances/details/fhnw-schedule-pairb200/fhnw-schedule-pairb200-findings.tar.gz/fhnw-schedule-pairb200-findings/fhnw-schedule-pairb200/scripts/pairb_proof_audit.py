from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path

import gurobipy as gp


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def pair_offset(n: int, i: int, j: int) -> int:
    return i * (2 * n - i - 1) // 2 + j - i - 1


def coefficients(model: gp.Model, constraint: gp.Constr) -> dict[int, float]:
    row = model.getRow(constraint)
    return {row.getVar(k).index: row.getCoeff(k) for k in range(row.size())}


def expected_energy(a: float, b: float, release: list[float], duration: list[float], deadline: list[float]) -> dict[int, float]:
    result = {}
    for i in range(len(release)):
        value = max(0.0, duration[i] - max(0.0, a - release[i]) - max(0.0, deadline[i] - b))
        if value > 1e-12:
            result[i] = value
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("original", type=Path)
    parser.add_argument("proof_model", type=Path)
    parser.add_argument("proof_json", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    n = 200
    original = gp.read(str(args.original))
    proof = gp.read(str(args.proof_model))
    variables = original.getVars()
    rows = original.getConstrs()
    pair_count = n * (n - 1) // 2
    assert original.NumVars == 2 * n + 2 * pair_count
    assert original.NumConstrs == 54 + 5 * pair_count
    release = [variables[n + i].LB for i in range(n)]
    latest = [variables[n + i].UB for i in range(n)]
    duration = [0.0] * n
    for i in range(n - 1):
        duration[i] = 2.0 - rows[54 + 5 * pair_offset(n, i, i + 1) + 3].RHS
    duration[-1] = 4.0 - rows[54 + 5 * pair_offset(n, n - 2, n - 1) + 4].RHS
    deadline = [latest[i] + duration[i] for i in range(n)]

    max_rhs_error = 0.0
    coefficient_failures = 0
    for i in range(n):
        for j in range(i + 1, n):
            off = pair_offset(n, i, j)
            base = 54 + 5 * off
            active = 2 * n + 2 * off
            order = active + 1
            expected = [
                ({i: -1.0, j: -1.0, active: 1.0}, ">", -1.0),
                ({i: -1.0, active: 1.0}, "<", 0.0),
                ({j: -1.0, active: 1.0}, "<", 0.0),
                ({n + i: 1.0, n + j: -1.0, active: 2.0, order: -2.0}, "<", 2.0 - duration[i]),
                ({n + i: -1.0, n + j: 1.0, active: 2.0, order: 2.0}, "<", 4.0 - duration[j]),
            ]
            for offset, (want_coeff, want_sense, want_rhs) in enumerate(expected):
                constraint = rows[base + offset]
                if coefficients(original, constraint) != want_coeff or constraint.Sense != want_sense:
                    coefficient_failures += 1
                max_rhs_error = max(max_rhs_error, abs(constraint.RHS - want_rhs))

    data = json.loads(args.proof_json.read_text(encoding="utf-8"))
    intervals = data["energy_cut_intervals"]
    proof_by_name = {constraint.ConstrName: constraint for constraint in proof.getConstrs()}
    max_energy_coefficient_error = 0.0
    max_energy_rhs_error = 0.0
    bad_energy_support = 0
    for index, record in enumerate(intervals):
        constraint = proof_by_name[f"energy_{index}"]
        actual = coefficients(proof, constraint)
        expected = expected_energy(record["a"], record["b"], release, duration, deadline)
        if set(actual) != set(expected):
            bad_energy_support += 1
        for variable_index in set(actual) | set(expected):
            max_energy_coefficient_error = max(max_energy_coefficient_error, abs(actual.get(variable_index, 0.0) - expected.get(variable_index, 0.0)))
        max_energy_rhs_error = max(max_energy_rhs_error, abs(constraint.RHS - ((record["b"] - record["a"]) + 1e-11)))

    conflict_rows = [constraint for constraint in proof.getConstrs() if constraint.ConstrName.startswith("pair_conflict_")]
    bad_conflicts = 0
    for constraint in conflict_rows:
        _, _, i_text, j_text = constraint.ConstrName.split("_")
        i, j = int(i_text), int(j_text)
        before_ij = max(release[j], release[i] + duration[i]) + duration[j] <= deadline[j] + 1e-12
        before_ji = max(release[i], release[j] + duration[j]) + duration[i] <= deadline[i] + 1e-12
        if before_ij or before_ji or coefficients(proof, constraint) != {i: 1.0, j: 1.0} or abs(constraint.RHS - 1.0) > 1e-12:
            bad_conflicts += 1

    report = {
        "original_sha256": sha256(args.original),
        "proof_model_sha256": sha256(args.proof_model),
        "pair_rows_checked": 5 * pair_count,
        "pair_row_coefficient_failures": coefficient_failures,
        "pair_row_max_rhs_error": max_rhs_error,
        "recovered_jobs": n,
        "fixed_singleton_rows": 54,
        "energy_rows_checked": len(intervals),
        "energy_bad_support": bad_energy_support,
        "energy_max_coefficient_error": max_energy_coefficient_error,
        "energy_max_rhs_error": max_energy_rhs_error,
        "conflict_rows_checked": len(conflict_rows),
        "bad_conflict_rows": bad_conflicts,
        "semantic_audit_passed": coefficient_failures == 0 and max_rhs_error <= 1e-12 and bad_energy_support == 0 and max_energy_coefficient_error <= 1e-12 and max_energy_rhs_error <= 1e-12 and bad_conflicts == 0,
        "validity_note": "Each pair conflict excludes a pair for which neither two-job order fits its release/deadline windows. Each energetic row is the standard mandatory-overlap inequality sum e_i(a,b) z_i <= b-a, with a conservative +1e-11 RHS allowance.",
    }
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
