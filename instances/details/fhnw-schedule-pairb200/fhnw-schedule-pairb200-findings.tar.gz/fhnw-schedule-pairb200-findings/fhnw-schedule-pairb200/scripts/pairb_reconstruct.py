from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def pair_offset(n: int, i: int, j: int) -> int:
    return i * (2 * n - i - 1) // 2 + j - i - 1


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("master_json", type=Path)
    parser.add_argument("solution_out", type=Path)
    parser.add_argument("audit_out", type=Path)
    args = parser.parse_args()

    model = gp.read(str(args.mps))
    variables = model.getVars()
    data = json.loads(args.master_json.read_text(encoding="utf-8"))
    n = 200
    selected = set(data["best_feasible_selection"])
    schedule = {int(key): float(value) for key, value in data["best_feasible_schedule"].items()}
    values = [0.0] * len(variables)
    for i in range(n):
        values[i] = float(i in selected)
        values[n + i] = schedule.get(i, variables[n + i].LB)
    for i in range(n):
        for j in range(i + 1, n):
            offset = pair_offset(n, i, j)
            active_index = 2 * n + 2 * offset
            order_index = active_index + 1
            active = i in selected and j in selected
            values[active_index] = float(active)
            if active:
                values[order_index] = float(schedule[j] < schedule[i])

    max_bound = max_integer = max_row = 0.0
    bound_count = integer_count = row_count = 0
    for variable, value in zip(variables, values):
        violation = max(variable.LB - value, value - variable.UB, 0.0)
        max_bound = max(max_bound, violation)
        bound_count += violation > 1e-9
        if variable.VType in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT):
            violation = abs(value - round(value))
            max_integer = max(max_integer, violation)
            integer_count += violation > 1e-9
    worst = []
    for constraint in model.getConstrs():
        row = model.getRow(constraint)
        activity = math.fsum(row.getCoeff(k) * values[row.getVar(k).index] for k in range(row.size()))
        if constraint.Sense == GRB.LESS_EQUAL:
            violation = max(activity - constraint.RHS, 0.0)
        elif constraint.Sense == GRB.GREATER_EQUAL:
            violation = max(constraint.RHS - activity, 0.0)
        else:
            violation = abs(activity - constraint.RHS)
        max_row = max(max_row, violation)
        row_count += violation > 1e-9
        if violation > 0:
            worst.append((violation, constraint.ConstrName, activity, constraint.Sense, constraint.RHS))
    objective = model.ObjCon + math.fsum(variable.Obj * values[variable.index] for variable in variables)
    report = {
        "instance": "fhnw-schedule-pairb200",
        "objective": objective,
        "selected_jobs": len(selected),
        "max_bound_violation": max_bound,
        "max_integrality_violation": max_integer,
        "max_row_violation": max_row,
        "bound_violations_over_1e_9": bound_count,
        "integrality_violations_over_1e_9": integer_count,
        "row_violations_over_1e_9": row_count,
        "worst_rows": sorted(worst, reverse=True)[:20],
        "strictly_feasible_1e_9": max(max_bound, max_integer, max_row) <= 1e-9,
    }
    if not report["strictly_feasible_1e_9"]:
        raise RuntimeError(json.dumps(report, indent=2))
    with args.solution_out.open("wt", encoding="utf-8", newline="\n") as handle:
        handle.write(f"# Objective value = {objective:.17g}\n")
        for variable, value in zip(variables, values):
            if abs(value) > 1e-14:
                handle.write(f"{variable.VarName} {value:.17g}\n")
    args.audit_out.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
