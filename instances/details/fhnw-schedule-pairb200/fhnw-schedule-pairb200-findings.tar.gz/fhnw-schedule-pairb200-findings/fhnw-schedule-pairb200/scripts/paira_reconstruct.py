from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def pair_offset(n: int, i: int, j: int) -> int:
    return i * (2 * n - i - 1) // 2 + j - i - 1


def recover_durations(model: gp.Model, n: int) -> list[float]:
    variables = model.getVars()
    durations: list[float | None] = [None] * n
    for i in range(n):
        j = i + 1 if i + 1 < n else i - 1
        left, right = (i, j) if i < j else (j, i)
        order = variables[2 * n + pair_offset(n, left, right)]
        column = model.getCol(order)
        for k in range(column.size()):
            constraint = column.getConstr(k)
            coefficient = column.getCoeff(k)
            if i < n - 1 and coefficient < 0:
                durations[i] = -constraint.RHS
            elif i == n - 1 and coefficient > 0:
                durations[i] = 200.0 - constraint.RHS
    if any(value is None for value in durations):
        raise RuntimeError("could not recover Pair-A durations")
    return [float(value) for value in durations]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("master_json", type=Path)
    parser.add_argument("solution_out", type=Path)
    parser.add_argument("audit_out", type=Path)
    args = parser.parse_args()
    model = gp.read(str(args.mps))
    variables = model.getVars()
    n = 200
    data = json.loads(args.master_json.read_text(encoding="utf-8"))
    selected = set(data["best_feasible_selection"])
    selected_starts = {int(key): float(value) for key, value in data["best_feasible_schedule"].items()}
    durations = recover_durations(model, n)
    selected_order = sorted(selected, key=lambda job: (selected_starts[job], job))
    unselected = sorted(set(range(n)) - selected, key=lambda job: (variables[n + job].LB, job))
    order = selected_order + unselected
    rank = {job: position for position, job in enumerate(order)}
    values = [0.0] * len(variables)
    starts = dict(selected_starts)
    current = max((starts[i] + durations[i] for i in selected), default=0.0)
    for i in unselected:
        current = max(current, variables[n + i].LB)
        starts[i] = current
        current += durations[i]
    for i in range(n):
        values[i] = float(i in selected)
        values[n + i] = starts[i]
    cursor = 2 * n
    for i in range(n):
        for j in range(i + 1, n):
            values[cursor] = 0.0 if rank[i] < rank[j] else 1.0
            cursor += 1

    max_bound = max_integer = max_row = 0.0
    row_count = 0
    for variable, value in zip(variables, values):
        max_bound = max(max_bound, variable.LB - value, value - variable.UB, 0.0)
        if variable.VType in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT):
            max_integer = max(max_integer, abs(value - round(value)))
    worst = []
    for constraint in model.getConstrs():
        row = model.getRow(constraint)
        activity = math.fsum(row.getCoeff(k) * values[row.getVar(k).index] for k in range(row.size()))
        if constraint.Sense == GRB.LESS_EQUAL:
            violation = max(activity - constraint.RHS, 0.0)
        elif constraint.Sense == GRB.GREATER_EQUAL:
            violation = max(constraint.RHS - activity, 0.0)
        else:
            violation = abs(activity - constraint.RHS)
        max_row = max(max_row, violation)
        row_count += violation > 1e-9
        if violation > 0:
            worst.append((violation, constraint.ConstrName, activity, constraint.Sense, constraint.RHS))
    objective = model.ObjCon + math.fsum(variable.Obj * values[variable.index] for variable in variables)
    report = {"instance": "fhnw-schedule-paira200", "objective": objective, "selected_jobs": len(selected), "max_bound_violation": max_bound, "max_integrality_violation": max_integer, "max_row_violation": max_row, "row_violations_over_1e_9": row_count, "worst_rows": sorted(worst, reverse=True)[:20], "strictly_feasible_1e_9": max(max_bound, max_integer, max_row) <= 1e-9}
    if not report["strictly_feasible_1e_9"]:
        raise RuntimeError(json.dumps(report, indent=2))
    with args.solution_out.open("wt", encoding="utf-8", newline="\n") as handle:
        handle.write(f"# Objective value = {objective:.17g}\n")
        for variable, value in zip(variables, values):
            if abs(value) > 1e-14:
                handle.write(f"{variable.VarName} {value:.17g}\n")
    args.audit_out.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
