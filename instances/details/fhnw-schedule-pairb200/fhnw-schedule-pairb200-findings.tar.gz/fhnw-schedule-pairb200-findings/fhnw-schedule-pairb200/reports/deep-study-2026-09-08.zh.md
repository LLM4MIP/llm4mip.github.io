# fhnw-schedule-pairb200 detailed study report (2026-09-08)

## Conclusion

This round obtained a new, strictly feasible solution, and after adding a mathematically effective conflict inequality with the energy inequality of the interval, Gurobi changed his proof to globally optimal:

```text
New optimum objective value -19.3699612046452058100
MIPLIB publishes objective value -19.240943842597080
Improved quantity 0.129017362048127 (minimization problem)
```

Compared to the strict benchmark `-19.240943297855996`, which was obtained after the close integer value in the MIPLIB published solution was strictly subtracted and retrieved for continuous variables, the improvement was `0.129017906789211`.

The proof here is reproducible globally optimal proof in the experimental sense: the original MPS plus the valid inequality of explanation and audit is given by Gurobi as primal=dual, gap=0; the same proof MPS solves independently again with different random seeds and parameters at the root node closure. It is not a DRAT/LRAT formalised certificate proof, so it should be accurately expressed as **solver-verified global optimum**.

##  1. Gurobi structure read

-  The original model: 40,200 variable, 99,554 constraint, 298,554 nonzero entries.
-  40,000 is a binary variable and 200 is a continuous variable.
-  constraint: 54 is an equation; 19,900 is greater than constraint; 79,600 is less than constraint.
-  The objective function is a non-zero binary variable with only the previous 200.
-  After the structure is restored, the previous 200 binary variable is the project/operation selection variable `z_i`, followed by the 200 continuous variable is the start time, with the remaining variable giving two pairs of active/post-sequence pairs to each unordered operation.
-  A single operation 200 produces a single operation `C(200,2)=19,900` pair; each pair corresponds exactly to the 5 rule of reciprocity and time constraint, matching the row count complete read.

MIPLIB describes it as a continuous time project selection/scheduling problem with project earnings, release dates and deadlines; Pair A, Pair B, Slot are different models of the same problem. The restored structure further demonstrates that the core is the selectable task schedule on a single machine: the selected task must be in its own time window, and the two selected tasks cannot overlap.

##  2. Published solution strictly

The objective value of the MIPLIB published solution is `-19.240943842597083`, but in which 100 is an integer variable deviating from the nearest integer is about `7.5e-7`; the maximum row violation on the original MPS is about `2.98e-6`. This is acceptable under the default tolerance of MIPLIB/Gurobi, but cannot be directly considered as a strict certificate.

We put all 40,000's integer variables into fixed, and then optimize for 200's continuous start time to get a strict benchmark:

- objective value `-19.240943297855996` ; 
-  the maximum level of default of the `0`;
-  the maximum integrality of the default of the `0`;
-  The maximum row violation is `2.44e-14`.

##  3. Why is the original model difficult?

To return the new incumbent to the original Pair B model, Gurobi runs 600 seconds and still processes only one node of the 30, with dual bound for `-52.84948950967261`, gap for `172.84%`.

##  4. Method One: Definition conflict is unequal

For arbitrary operations on `(i,j)`, check whether `i` is possible before `j` and `j` before `i`, using processing time, release date and deadline respectively. If both sequences cannot meet the time window, the two cannot be selected simultaneously and can be added:

```text
z_i + z_j <= 1
```

This instance collectively identifies and adds this inequality to the 4,368 clause. Each of the clauses is retrieved from the original MPS time window and processing time directly verification, without exclusion.

## 5. Method two: interval energy inequalities

For a time interval `[a,b]`, operating `i`, even if all the parts that can be placed outside the interval are removed, a part of the processing must remain within the interval:

```text
e_i(a,b) = max(0,
               p_i - max(0,a-r_i) - max(0,d_i-b))
```

The single provides the maximum processing capability of the `b-a` within the `[a,b]`, so any feasible option must satisfy:

```text
sum_i e_i(a,b) z_i <= b-a
```

From the release/deadline endpoint, the 31,481 individual candidate range is generated, and the strongest 1,500 effective energy inequality is selected to be added to the model. They express many pairwise constraints, which are the key to this closure.

##  6. New solution with global proof

The enhanced model includes:

-  the original 99,554 constraint;
-  4,368 article pair conflict cuts;
-  1,500 articles energetic cuts;
-  Added 105,422 bar constraint, 40,200 variable, 596,666 nonzero entries.

Gurobi gets it from the root node:

```text
primal = -19.369961204645204
dual   = -19.369961204645204
gap    = 0
nodes  = 1
```

The solution selects the 30 operation. The saved solution is reloaded to unmodified Pair B original MPS: maximum boundary violation of `0`; maximum integrality violation of `0`; maximum row violation `4.44e-16`; no row violation greater than `1e-9`.

##  7. Independent verification

In order to prevent typing errors, the solver still requests the wrong model to be optimized and performs four layers of verification:

1.  **original Pair B verification**: replacing the new solution directly with the original MPS, recalculating the objective, variable boundary, integrality and all 99,554 constraint.
2.  **proof model Re-run**: Save the enhanced `energy-cuts-proof-proof.mps.gz`, reread with different seed/parameters and solve independently, still getting the same primal/dual and zero gap at each node of 1.
3.  **semantic audit**: check the 99,500 bar pairwise line of the original model step by step structure 4,368 bar conflict unequal 1,500 bar energy unequal variable support, coefficients and right edges, all passed; the original MPS proof MPS has also been recorded with SHA-256.
4.  **Cross-formulation Verification**: Based on the selection set of the same 30 operation, the direct reconstruction time sequence variable in the official Pair A MPS gets the same objective value; the largest row violation on Pair A is `2.84e-14`, not greater than the default of `1e-9`.

During the debugging process, the first version of the selection master omitted the 54 single variable in the original model to force constraint, which had produced a seemingly better ineffective candidate; immediately detected the `R1` row violation when the candidate reconstruction returned to the original MPS, without entering the final result.

##  8. Key files

-  New optimal solution: `../solutions/new-optimal-candidate.sol`
- original MPS feasibility audit :  `../artifacts/energy-cuts-original-mps-audit.json`
- proof MPS：`../artifacts/energy-cuts-proof-proof.mps.gz`
-  The first global closure: `../experiments/energy-cuts-proof.json`
-  Independent weightlifting: `../artifacts/proof-model-independent-run.json`
-  Unbalanced semantic audit: `../artifacts/proof-semantic-audit.json`
-  Pair A cross audit: `../artifacts/paira-cross-formulation-direct-audit.json`
-  Original model 600 Baseline of seconds: `../experiments/baseline-with-new-incumbent-600s.json`
-  Production and verification code: `../scripts/pairb_energy_solver.py`, `../scripts/pairb_proof_audit.py`, `../scripts/paira_reconstruct.py`

##  9. Summary of experience

-  For this type of model, restore the semantics of the + time window + single non-overlapping vertices, which is much more effective than the blindly adjusted Gurobi parameter.
-  The dual bound of the original two-dimensional big-M formulation is very weak; the interval energy constraint manifests the high-level resource conflict, and the model continues to have a huge gap from 600 seconds to root node closure.
-  MIPLIB publishes solutions that can use default tolerance. It claims that before improving or optimizing, a strict integer solution should be constructed and the final solution replaced with the original MPS, rather than only the modified model that was audited.
-  Another formulation is a very valuable independent check: it can detect systemic errors in variable mapping, constraint restoration, or cutting of plane implementations.

