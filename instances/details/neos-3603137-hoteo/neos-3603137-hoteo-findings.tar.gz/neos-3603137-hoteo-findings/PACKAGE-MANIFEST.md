# Package manifest: neos-3603137-hoteo

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 1
Excluded source files: 1

## Included files

- `README.md`

## Excluded files

- `input/neos-3603137-hoteo.mps.gz (219937 bytes; raw benchmark input; sha256 6d60ec875102722f4b2474a295fd5a23493ace4647b50ad12ed8ed13074d5d49)`
