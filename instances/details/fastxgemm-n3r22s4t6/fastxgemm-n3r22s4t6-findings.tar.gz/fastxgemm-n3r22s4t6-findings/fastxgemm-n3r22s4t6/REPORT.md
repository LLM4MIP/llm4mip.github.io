#  `fastxgemm-n3r22s4t6` follow-up report

Date of release: 2026 -09 -09

##  Strict conclusions

This round at the same time strict improved to lower bound:

```text
87,1171: The original project area:
New strict range:[90,1150]
```

The lower bound 90 is a new project proof covering the entire feasible region of the official integer MIP. The upper bound 1150 comes from an external
BILR 2018's `S_Lader-Z3` rank- 23 decomposition: removed from its two singleton fixed A items
Any construct, i.e. obtained from R22, S4T6 of `E=1,K=50`. It must be marked as
**external-derived**, included in this project primal improvements based on external outcomes (((2026 -09 -16 update calibre); it is named Laurent Sorber 2017
The author prior 1171 strict reduced the 21.

## external-derived UB 1150

The input parent is a strictly complementary BILR construct on the official R23 MPS.
The POS/NEG integer and the exact voltage are unfolded to get

```text
R=23, E=0, K=51, full support=153, objective=153.
```

parent has five fixed symmetry elements and six three-loop orbits. After removing support for the fixed A vector of `q`,
The error is the cube that was deleted, so

```text
E=q^3,  K=51-q,  objective=1000*q^3+3*(51-q).
```

The exact enumeration of the five deleted items is:

| Original A column |  q  |  E  |  K  |  objective  |
|---:|---:|---:|---:|---:|
| 0 | 1 | 1 | 50 | **1150** |
| 1 | 1 | 1 | 50 | **1150** |
| 2 | 3 | 27 | 48 | 27144 |
| 3 | 2 | 8 | 49 | 8147 |
| 4 | 2 | 8 | 49 | 8147 |

The two 1150 candidates only omitted `(4,4,4)` and `(8,8,8)` respectively.
R22 MPS ((19,539 variables, 229,742 rows, 752,274 nonzeros) is fixed on all 396
After the POS/NEG integer, Gurobi returns `OPTIMAL`, the objective 1150.
The exact-decimal, exact-integer and the exact tensor audit are both zero defaulted, all of which fill in the whole variable.
The maximum distance is zero.

## global LB 90

For exact decomposition, the target slice of the corresponding nine factor rows is rank 3, so each row is the same.
degree is at least 3. degree is exactly 3's tight rows cannot share rank in the same mode
old proof using `8*3>22` exclusion `K<=28`; this round further exclusion `K=29` is the only remaining
`(4,4,3^7)` type.

Seven tight rows each represent a position of 21, and the three tight-row coordinates are the same, so the three modules are unique.
Uncovered occurrence must come from the same underlying vector.

-  If it is A, then another 21 is a coordinate-singleton; the remaining A support at least 8, whose cube
There are at least one non-zero 512, of which at least one 485 is outside the objective 27 coordinates, and one 21 is a singleton.
At least eliminate a 21 coordinate, which is contradictory.
-  If it is in B/C/D orbit, the outer orbit of 19 is covered by all three modules, so it is singleton;tight
The row/column intersection gives the orbit three vector support at most `1,3,3`, so that
`K<=19+1+3+3=26` is a contradiction.

So exact must have `K>=30`. For any integer feasible point, ABS_ALT linking is only guaranteed.
`sum(ABS_ALT)>=3K` (does not assume that the continuous auxiliary variable is taken as a minimum); error for inexact points, real integer
At least 1, RESIDUAL linking guarantees the residual sum of at least 1, then official linking has been available
`sum(ABS_ALT)>=84`. This gives the global integer an effective cut.

```text
sum(ABS_ALT) + 6*sum(RESIDUAL) >= 90.
```

Numerical verification of Gurobi 13.0.2: Original LP is 84, after cut LP is 90, after cut root
bound is 90. The cut contains 1,323 as a non-zero; 594 as a coefficient 1; 729 as a coefficient 6), in the original MPS.
`_C229556` has been verified on a case-by-case basis as `sum(ABS_ALT)>=84`.

##  Continued search around the two new cores

The following finite neighbourhoods are complete, exact and unimproved with both cores:

-  Hamming coefficient radius 1 / 2: each core is a candidate for 396 and 78,012 respectively;
-  Substitute a single complete vector: all of the 22 underlying vectors, for each enumeration `3^9`, total
433,026 candidate;
-  One by one support exchange: `50*148*2=14,800` candidate

The stronger official MPS fixed-support model allows the original 50 location to be arbitrarily deleted/altered, prohibiting activation.
148 with a prime zero position and `objective<=1149` added. Both models returned `INFEASIBLE` in full.
(275 and 2,084 nodes) This is just a certificate of their respective fixed support neighborhoods and cannot be excluded.

Allowing the crankshaft support to change arbitrarily + activate a new position of the crankshaft to two models running 600 per second with no solution, but
The state is `TIME_LIMIT`; the nodes are 16,186 and 14,328, best bound respectively.
1096.009 and 1096.021. They are just a range of clear negative search evidence, not an infeasible proof.

##  The exact K=30 boundary

Proof is also introduced: if exact `K=30` exists, its row-degree multiset can only be used for

```text
(4,4,4,3,3,3,3,3,3).
```

The corresponding complete branching probe reached `TIME_LIMIT` after 183.167 seconds, with root 1 and solution 0. Therefore it cannot
Claims that the exact rank 22 does not exist and cannot raise the exact support lower bound to 31.

##  It's not about the content that can be claimed.

It can be claimed that the strict interval for the official integer MIP is `[90,1150]`; exactly there must be `K>=30`;
Two external-derived solutions of 1150 have been approved by the official MPS for the full set of strict audits; two fixed
Support neighborhoods do not have objective≤ 1149 points.

Can't claim: The external mother construct of 1150 is project/GPT original; there is no exact rank- 22; exact K= 30 infeasible;
Global does not exist `E=1,K<=49`; or at-most-one-new-support TIME_LIMIT is proof.
