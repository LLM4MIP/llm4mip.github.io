# A global lower bound of 90 for `fastxgemm-n3r22s4t6`

This note concerns only the integer-feasible points of the official MIPLIB
model `fastxgemm-n3r22s4t6`: ternary factors, `R=22`, and the cyclic
parametrization `S=4,T=6`.  It is not a rank lower bound for unrestricted
3-by-3 matrix multiplication.

## Notation

Write

```text
U = [A B C D],   V = [A D B C],   W = [A C D B],
```

where `A` has four columns and `B,C,D` have six columns each.  Let `K` be
the number of nonzeros in `[A B C D]`.  The three displayed factors are
block permutations, so each has support `K` and the complete raw factor
support is `3K`.

Index a factor row by `(n,q) in {0,1,2}^2`.  The target tensor has ones at

```text
((n,q),(q,m),(m,n)),   m,n,q in {0,1,2},
```

and zeros elsewhere.

## Lemma 1: every row has degree at least three

Fix row `i=(n,q)` of `U`.  Its target slice is a 9-by-9 matrix of rank
three.  In an exact decomposition it is the sum of the rank-one matrices

```text
U[i,r] V[:,r] W[:,r]^T
```

over rank positions with `U[i,r] != 0`.  Thus its degree `d_i` is at least
three.  The block permutations imply the same degree sequence in all three
modes, and `sum_i d_i = K`.

## Lemma 2: tight rows have disjoint rank positions

Call a row tight when `d_i=3`.  Equality in the slice-rank bound forces the
three participating `V` vectors to span exactly the slice column space and
the three participating `W` vectors to span exactly its row space.  Hence,
for a tight `U` row `(n,q)`, every participating position satisfies

```text
supp(V[:,r]) subset {(q,m): m=0,1,2},
supp(W[:,r]) subset {(m,n): m=0,1,2}.
```

Two distinct tight rows cannot share a rank position: one of these required
coordinate spaces is then disjoint, making the corresponding opposite
factor vector zero and leaving at most two nonzero rank-one matrices for a
rank-three slice.  Therefore the three rank positions used by distinct
tight rows are pairwise disjoint.  The statement applies independently in
all three modes.

A second consequence will be used below.  If a rank position is used by a
tight row in every mode, each of its factor vectors is restricted by one
grid-row space and one grid-column space coming from the other two modes.
Their intersection has support at most one.  Thus that rank-one term is
coordinate-singleton (or zero).

## Proposition: exact reconstruction implies `K >= 30`

The previously published `K>=29` argument excludes `K<=28`: at least eight
of the nine rows would be tight, requiring `8*3=24` distinct rank positions,
but `R=22`.

Suppose now that `K=29`.  Since all nine degrees are at least three, only
two degree multisets are possible:

```text
(5,3,3,3,3,3,3,3,3),
(4,4,3,3,3,3,3,3,3).
```

The first again has eight tight rows and is impossible by `24>22`.  In the
second, the seven tight rows use exactly 21 distinct rank positions in each
mode.  Exactly one position is not used by a tight row in each mode.  The
set of tight row coordinates is the same in `U,V,W`, because their row
degrees are identical.

There are two cases for the unique uncovered position.

### Case A: it is an `A` position

An `A` vector occurs at the same rank position in all three factors, so this
same position is uncovered in all modes.  Each of the other 21 positions is
covered by a tight row in all modes and is therefore coordinate-singleton.

Those 21 positions contribute at most 21 nonzeros to the support of `U`.
Since `K=29`, the remaining `A` vector has support at least eight.  Its cube
`a tensor a tensor a` has at least `8^3=512` nonzero tensor coordinates.
At least `512-27=485` of these cube coordinates are outside the 27-coordinate
target support and therefore must be cancelled.  A sum of 21
coordinate-singleton terms can cancel values on at most 21 coordinates.  Such
terms cannot turn that cube into the target, a contradiction.

### Case B: it is in a `(B_t,C_t,D_t)` orbit

At the three aligned rank positions the factors are

| rank position | `U` | `V` | `W` |
|---|---|---|---|
| `B_t` position | `B_t` | `D_t` | `C_t` |
| `C_t` position | `C_t` | `B_t` | `D_t` |
| `D_t` position | `D_t` | `C_t` | `B_t` |

The tight-row coordinate set is the same in all three modes.  Every underlying
vector occurs once in each mode (at the same position for an `A` vector and at
the three rotated positions shown above for a `B/C/D` vector).  Therefore, if
an underlying vector is zero on the common tight-row set, its occurrence is
uncovered in every mode.  Conversely, a vector nonzero on that set covers its
occurrence in every mode.  Since each mode has exactly one uncovered position,
all three uncovered occurrences must come from one and the same underlying
vector; no second underlying vector can vanish on the tight-row set.

After cyclic relabelling, call this unique vector `B_t`.  The uncovered
positions in `U,V,W` are respectively the `B_t`, `C_t`, and `D_t` aligned
positions.  Every underlying vector outside this orbit is nonzero on the
common tight-row set, so all 19 rank positions outside the orbit are covered
in all three modes.  Their factor vectors therefore have support at most one.

Both `C_t` and `D_t` occur as primary vectors of tight `U` slices.  Tightness
at the `C_t` position restricts `B_t` to one grid-row space and `D_t` to one
grid-column space.  Tightness at the `D_t` position restricts `C_t` to one
grid-row space and `B_t` to one grid-column space.  Consequently

```text
|supp(B_t)| <= 1,   |supp(C_t)| <= 3,   |supp(D_t)| <= 3.
```

Thus the complete one-factor support is at most `19+1+3+3=26`, contradicting
`K=29`.

Both cases are impossible, proving `K>=30` for every exact reconstruction.

### Additional exact-branch narrowing at `K=30`

The same reasoning gives a useful boundary for subsequent exact searches.
At `K=30`, the possible degree multisets are

```text
(6,3,3,3,3,3,3,3,3),
(5,4,3,3,3,3,3,3,3),
(4,4,4,3,3,3,3,3,3).
```

The first has eight tight rows and is impossible by `24>22`.  The second has
seven tight rows and therefore the same unique-uncovered-position split as
above.  In its `A` case the uncovered vector now has support at least nine,
making the cube contradiction stronger; its B/C/D case still gives the
upper bound 26.  Consequently, if an exact `K=30` decomposition exists, its
degree multiset must be exactly

```text
(4,4,4,3,3,3,3,3,3).
```

Equivalently, it has six tight rows using 18 distinct rank positions and
three non-tight rows of degree four.  This is only a necessary structural
condition for the unresolved `K=30` branch, not an existence claim and not
an exclusion of exact rank 22.

## Globally valid inequality and objective bound

At an integer factor pattern, every reconstructed tensor coordinate is an
integer.  Let `E_actual` be the integer L1 discrepancy reconstructed directly
from the factors, and let `R_aux=sum(RESIDUAL)` be the sum of the model's
continuous residual auxiliaries.  The residual linking rows give
`R_aux>=E_actual`; this argument does not assume that a non-optimal feasible
point has chosen its residual auxiliaries minimally.

- If the reconstruction is exact, the proposition gives full factor support
  `3K>=90`.  The model's absolute-value linking rows imply
  `sum(ABS_ALT)>=3K`, even when the continuous auxiliaries are not chosen
  minimally.
- If it is inexact, `E_actual>=1`, hence `R_aux>=1`, while the original model
  already enforces `sum(ABS_ALT)>=84`.

The inexact calculation is uniform for every `E_actual>=1`, not only the
boundary case: `sum(ABS_ALT)+6*R_aux >= 84+6*E_actual >= 90`.

Hence every integer-feasible point satisfies

```text
sum(ABS_ALT_U,ABS_ALT_V,ABS_ALT_W) + 6*sum(RESIDUAL) >= 90.   (CUT-90)
```

This is an integer-valid inequality; its proof does not claim validity for
arbitrary fractional points of the original LP relaxation.  Since the model
objective is

```text
1000*sum(RESIDUAL) + sum(ABS_ALT) + 0.001*sum(ABS_DIFF)
```

with nonnegative terms, `(CUT-90)` proves the global integer objective lower
bound 90.

The accompanying script adds exactly this row to the official MPS and uses
Gurobi to check the original and augmented continuous relaxations and the
augmented root node.  Those numerical probes confirm the implementation of
the cut; the global validity comes from the proof above.
