# External-derived strict upper bound 1150

## Attribution and classification

The parent factorization is the `S_Lader-Z3` decomposition of Grey Ballard,
Christian Ikenmeyer, J. M. Landsberg, and Nick Ryder, *The geometry of rank
decompositions of matrix multiplication II: 3x3 matrices*, Appendix B,
equations (77)--(84).  The exact factor pattern is therefore external.  The
R22 candidates below are obtained by the mechanical deletion of one published
fixed term and are classified **external-derived**.  They do **not** count as a
project/GPT primal contribution.

The input parent is the already audited official-MPS completion
`external_audit/ballard-laderman-z3-strict-153.sol`, SHA-256
`e91e7dbd3bae5d941221b702cc89cc151231ca6e3337c4dc782600e6979cf0e3`.
Reading only its 414 POS/NEG integer variables and expanding the tensor over
the integers gives

```text
R=23, S=5, T=6, E=0, K=51, full support=153, objective=153.
```

## Exact deletion argument

The parent has five fixed symmetric terms `a_s tensor a_s tensor a_s` and six
length-three B/C/D orbits.  Delete one fixed A column and reindex the other
four.  This changes `(R,S,T)=(23,5,6)` to the target `(22,4,6)` while leaving
all B/C/D columns unchanged.

Because the parent is exact, the child's complete error tensor is exactly the
deleted cube.  For a ternary A vector of support `q`,

```text
E_child = ||a tensor a tensor a||_1 = q^3,
K_child = 51-q,
objective = 1000*q^3 + 3*(51-q).
```

The complete five-way enumeration is:

| deleted original A column | vector support `q` | `E` | `K` | objective |
|---:|---:|---:|---:|---:|
| 0 | 1 | 1 | 50 | **1150** |
| 1 | 1 | 1 | 50 | **1150** |
| 2 | 3 | 27 | 48 | 27144 |
| 3 | 2 | 8 | 49 | 8147 |
| 4 | 2 | 8 | 49 | 8147 |

Deletion 0 omits the singleton at tensor coordinate `(4,4,4)`; deletion 1
omits the singleton at `(8,8,8)`.  In each case the expansion equals the
target at the other 728 coordinates.

## Official R22 MPS completion

Both objective-1150 integer patterns were independently fixed into every one
of the 396 official R22 POS/NEG variables.  Gurobi 13.0.2 then completed all
19,539 model variables on the unmodified official MPS (229,742 rows, 752,274
nonzeros).  Both fixed-pattern problems returned `OPTIMAL` and objective 1150;
presolve removed all rows and columns.

For each completed solution, the archived audit checks:

- exact binary reconstruction gives `E=1`, `K=50`, full support 150, and
  objective 1150;
- floating, exact-decimal, and exact-integer audits of all official MPS rows
  and bounds have zero violations;
- every completed variable is integral (maximum distance zero).

The two strict solutions are:

```text
external-bilr-delete-a0-strict-1150.sol
SHA-256 4d5cb3c7a1f0740a5654121eefba47dc7fb16cbb9c22024abd7e13b5ec6ff852

external-bilr-delete-a1-strict-1150.sol
SHA-256 52cef250d53e95e91cc38b629cf0017c0092c2690db8f419ff6171573ee17481
```

Thus 1150 is a strict feasible upper bound for the official
`fastxgemm-n3r22s4t6` MIP, improving the previous author prior 1171 by 21.
This is a feasibility statement, not an optimality proof.

## Scoped improvement searches around both cores

For each of the two 1150 cores, exact exhaustive scans found no strict
improvement in either of these finite neighborhoods:

- all ternary coefficient-Hamming moves of radius one or two: 396 radius-one
  moves and 78,012 distinct-coordinate radius-two moves per core;
- replacing each of all 22 underlying A/B/C/D vectors by every vector in
  `{-1,0,1}^9`: `22*19,683=433,026` candidates per core.

On the official MPS, the objective-cap-1149 fixed-support models also returned
`INFEASIBLE` for both cores.  This permits arbitrary deletions and sign changes
inside the respective 50 old support locations while forbidding activation of
the 148 zero locations.  It is a complete certificate only for each stated
fixed-support neighborhood; it is not a global lower bound and is not
transferred to other support patterns.

The optional models allowing arbitrary old-support edits and at most one new
location both ended at `TIME_LIMIT` after 600 seconds, with no incumbent.  For
deletions 0 and 1 respectively they explored 16,186 and 14,328 nodes and ended
with bounds 1096.009 and 1096.021.  These are negative search observations
only, not neighborhood infeasibility certificates.
