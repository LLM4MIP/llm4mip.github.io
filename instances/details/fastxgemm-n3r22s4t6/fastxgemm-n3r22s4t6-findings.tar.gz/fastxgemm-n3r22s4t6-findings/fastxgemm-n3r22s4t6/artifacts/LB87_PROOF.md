#  The global lower bound 87 of `fastxgemm-n3r22s4t6` is divided by the effective

>  **is historically valid but has been reinforced.** The LB87 proof in this article is still valid, but has been removed from the same directory.
>  `LB90_PROOF.md`'s global lower bound 90 strictly governed. The current strict range is `[90,1150]`;
>  It is only preserved as an early proof chain.

This article only discusses specific models of the MIPLIB instance `fastxgemm-n3r22s4t6`: factor derivatives belong to
`{-1,0,1}`, with rank `R=22` and cyclic parameterization `S=4,T=6`. This is not a result for general
`3×3` matrix multiplied by the tensor rank of the 22 scale lower bound proof.

##  1. Signed

The model sets

```text
U = [A B C D],  V = [A D B C],  W = [A C D B],
```

where `A` has 4 columns and `B,C,D` each have 6. Let `K` be the number of nonzero entries in `[A B C D]`.
The block substitution ensures that `U,V,W` has `K`'s nonzero entries, so the integral factor in objective
support is equal to `3K`.

Denote a factor-matrix row by `(n,q)∈{0,1,2}²`. The ones in the matrix-multiplication tensor are located at

```text
((n,q),(q,m),(m,n)),  m,n,q∈{0,1,2}.
```

##  2. Each row uses at least three rank columns

Fix row `i=(n,q)` of `U`. The corresponding `9×9` slice of the objective tensor, at
There are three 1s on `((q,m),(m,n))`, so the matrix rank is 3.

An exact decomposition will write the slice down.

```text
sum_{r: U[i,r] != 0} U[i,r] V[:,r] W[:,r]^T.
```

The rank of each matrix is at most 1. Therefore, if `d_i` is a nonzero number on the `U` line `i`
`d_i≥3`. `K=sum_i d_i≥27` is the sum of the nine lines.

##  3. Two or three rows cannot share a rank column

Call a row with `d_i=3` a tight row. If a rank-3 slice is the sum of exactly three rank-one matrices,
The three `V` vectors must be extended to the column space of the slice, and the three `W` vectors must be extended to their line space.
So, for each column `r` used for the tight row `i=(n,q)`, there are

```text
V[:,r] support can only be located in {(q,m):m=0,1,2 },
W[:,r] support can only be found in {(m,n):m=0,1,2 }.
```

If two different tight rows `(n,q)` and `(n',q')` share a column:

-  When `q!=q'`, the two allowed `V` coordinate spaces do not intersect, forcing `V[:,r]=0`;
-  When `q=q'` must have `n!=n'`, the two allowed `W` coordinate spaces do not intersect, forcing
  `W[:,r]=0`。

In both cases, rank-one items in a shared column are zero; thus the tight slice actually remains as much as possible.
Two non-zero rank-one entries cannot be ranked 3. Thus, three separate tight rows are used.
This conclusion does not require additional reference to non-zero constraints in each column.

##  4 . exact reconstruction must have `K≥29`

Suppose `K≤28`. The nine line scales are at least 3, and the sum is at most 28, so at least eight acts.
tight row. The previous paragraph indicates that they need at least a different rank column `8×3=24`, but the model
There is only one 22, which is contradictory.

```text
K >= 29,
full factor support = 3K >= 87.
```

##  5. Effective division of the whole integer model

The original model already has `sum(ABS_ALT)≥84`. In the integer factor pattern, product gadget reconstruction
Each tensor coordinate is an integer.

-  If reconstruction is exact, the previous paragraph gives `sum(ABS_ALT)≥87`;
-  If reconstruction is not exact, the absolute error value of at least one integer coordinate is not less than 1, i.e.
`sum(RESIDUAL)≥1`, combined with the original support lower bound, also reached 87.

So all integer feasible points are satisfied

```text
sum(ABS_ALT) + 3 sum(RESIDUAL) >= 87.                 (CUT-87)
```

This is a mixed-integer-valid cut; proof uses the integrality of the factor pattern and does not claim
It automatically generates the original LP polytope after deleting the integer condition.

```text
1000 sum(RESIDUAL) + sum(ABS_ALT) + 0.001 sum(ABS_DIFF),
```

Each is nonnegative, so `(CUT-87)` at the same time proof global integer objective lower bound is 87.

##  6. Calculating the nuclear test

`scripts/build_and_probe_lb87.py` adds `(CUT-87)` to the official MPS and solve the original model respectively.
And the continuous relaxation of the enhanced model:

```text
The original LP relaxation: 84.00000000000045
Added CUT-87 after: 87.00000000000045
```

The result is preserved in the `artifacts/lb87_probe.json`; the enhanced model is
`artifacts/fastxgemm-n3r22s4t6-lb87.mps.gz`。
