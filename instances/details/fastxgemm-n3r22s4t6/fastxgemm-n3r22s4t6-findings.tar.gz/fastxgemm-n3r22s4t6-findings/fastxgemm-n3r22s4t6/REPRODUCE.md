# Reproduction

Run from this instance directory with Python, NumPy/SciPy, and `gurobipy`.
The archived runs used Gurobi 13.0.2.

## External-derived UB 1150

Enumerate all five fixed-A deletions from the audited external R23 solution:

```powershell
python .\scripts\enumerate_external_r23_deletions.py `
  ..\fastxgemm-n3r23s5t6\solutions\external-bilr2018-strict-153.sol `
  --output-dir .\artifacts\external-bilr-deletions `
  --report .\artifacts\external-bilr-deletion-audit.json
```

Expected objectives in A-column order: `1150,1150,27144,8147,8147`.

Complete and audit one improving core on the official MPS; repeat with `a1`
and label `A1` for the second:

```powershell
python .\scripts\strict_pattern_completion.py `
  .\input\fastxgemm-n3r22s4t6.mps.gz `
  .\artifacts\external-bilr-deletions\external-bilr-delete-a0-core.sol `
  --label "external-derived BILR delete A0" --expected-objective 1150 `
  --output-solution .\artifacts\external-bilr-delete-a0-strict-1150.sol `
  --output-json .\artifacts\external-bilr-delete-a0-strict-1150.json `
  --log .\logs\external-bilr-delete-a0-strict-1150.log
```

Expected: `OPTIMAL`, exact `E=1,K=50`, and zero violations in the floating,
exact-decimal, exact-integer, and semantic audits.

## Complete local scans around a 1150 core

Replace `a0` by `a1` to repeat every scan around the second core.

```powershell
python .\scripts\coefficient_radius2_scan.py `
  .\artifacts\external-bilr-delete-a0-strict-1150.sol `
  --json .\artifacts\external-bilr-delete-a0-radius2.json

python .\scripts\one_vector_scan.py `
  .\artifacts\external-bilr-delete-a0-strict-1150.sol `
  --json .\artifacts\external-bilr-delete-a0-one-vector.json --batch-size 256

python .\scripts\one_support_exchange_scan.py `
  .\artifacts\external-bilr-delete-a0-strict-1150.sol `
  --json .\artifacts\external-bilr-delete-a0-one-support-exchange.json
```

Expected: no objective below 1150 in 396 radius-one and 78,012 radius-two
moves; no improvement in 433,026 complete-vector replacements or 14,800
one-for-one support exchanges.

Official-MPS fixed-support certificate:

```powershell
python .\scripts\bounded_support_improvement.py `
  .\input\fastxgemm-n3r22s4t6.mps.gz `
  .\artifacts\external-bilr-delete-a0-strict-1150.sol `
  --max-new 0 --objective-cap 1149 --time-limit 600 --threads 8 `
  --json .\artifacts\external-bilr-delete-a0-fixed-support-cap1149.json `
  --log .\logs\external-bilr-delete-a0-fixed-support-cap1149.log `
  --write-model .\artifacts\external-bilr-delete-a0-fixed-support-cap1149.mps.gz
```

Expected: `INFEASIBLE`. With `--max-new 1` and corresponding output names,
the archived 600-second run is `TIME_LIMIT`, not a proof.

## Finite LB90 proof-case audit

```powershell
python .\scripts\verify_lb90_combinatorics.py `
  --json .\artifacts\lb90_combinatorial_audit.json
```

Expected: 45 K29 degree vectors, 22 uncovered-vector cases, 31,752 BCD
line-geometry cases, and `all_checks_pass=true`.

## Build and probe the LB90 model

```powershell
python .\scripts\build_and_probe_lb90.py `
  .\input\fastxgemm-n3r22s4t6.mps.gz `
  --solution .\solutions\author-2017-strict-1171.sol `
  --output-model .\artifacts\fastxgemm-n3r22s4t6-lb90.mps.gz `
  --json .\artifacts\lb90_probe.json `
  --original-lp-log .\logs\original_lp.log `
  --augmented-lp-log .\logs\augmented_lb90_lp.log `
  --root-log .\logs\augmented_lb90_root.log `
  --time-limit 120 --threads 8
```

Expected LP objectives: 84 and 90. The `NODE_LIMIT` root status is
intentional and only verifies bound 90 plus retention of the supplied start.

## Exact K30 unresolved probe

```powershell
python .\scripts\probe_exact_k30.py `
  .\input\fastxgemm-n3r22s4t6.mps.gz `
  --json .\artifacts\exact_k30_probe.json `
  --log .\logs\exact_k30_probe.log `
  --output-model .\artifacts\fastxgemm-n3r22s4t6-exact-k30.mps.gz `
  --solution .\artifacts\exact_k30_candidate.sol `
  --time-limit 180 --threads 8
```

Archived outcome: `TIME_LIMIT`, zero solutions, one root node. This is not an
infeasibility proof.

## Syntax and JSON checks

```powershell
Get-ChildItem .\scripts\*.py | ForEach-Object { python -m py_compile $_.FullName }
python -c "import json,pathlib; files=list(pathlib.Path('artifacts').glob('*.json')); [json.loads(p.read_text(encoding='utf-8')) for p in files]; print('JSON_OK',len(files))"
```
