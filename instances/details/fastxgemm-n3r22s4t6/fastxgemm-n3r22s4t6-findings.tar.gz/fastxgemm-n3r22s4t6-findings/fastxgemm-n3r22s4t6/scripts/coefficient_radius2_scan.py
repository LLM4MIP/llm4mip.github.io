#!/usr/bin/env python3
"""Exhaust every ternary coefficient pattern within Hamming radius two."""

from __future__ import annotations

import argparse
import importlib.util
import itertools
import json
import time
from pathlib import Path

import numpy as np


def load_semantic():
    path = Path(__file__).with_name("r22_semantic_audit.py")
    spec = importlib.util.spec_from_file_location("r22_semantic", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


sem = load_semantic()


def target_tensor() -> np.ndarray:
    target = np.zeros((9, 9, 9), dtype=np.int16)
    for i, j, k in itertools.product(range(9), repeat=3):
        target[i, j, k] = sem.semantic.target_value(i, j, k)
    return target


def cyclic_group(b: np.ndarray, c: np.ndarray, d: np.ndarray) -> np.ndarray:
    return (
        np.einsum("i,j,k->ijk", b, d, c, dtype=np.int16)
        + np.einsum("i,j,k->ijk", c, b, d, dtype=np.int16)
        + np.einsum("i,j,k->ijk", d, c, b, dtype=np.int16)
    )


def component_key(letter: str, column: int):
    return ("A", column) if letter == "A" else ("G", column)


def component_tensor(blocks, key):
    kind, column = key
    if kind == "A":
        vector = blocks["A"][:, column]
        return np.einsum("i,j,k->ijk", vector, vector, vector, dtype=np.int16)
    return cyclic_group(blocks["B"][:, column], blocks["C"][:, column], blocks["D"][:, column])


def full_tensor(blocks):
    tensor = np.zeros((9, 9, 9), dtype=np.int16)
    for column in range(4):
        tensor += component_tensor(blocks, ("A", column))
    for column in range(6):
        tensor += component_tensor(blocks, ("G", column))
    return tensor


def structurally_valid(blocks, support):
    if support < 28:
        return False
    if np.any(sum(np.count_nonzero(blocks[x], axis=1) for x in "ABCD") < 1):
        return False
    return all(not np.any(np.count_nonzero(blocks[x], axis=0) < 1) for x in "ABCD")


def score(tensor, target, support):
    difference = target - tensor
    if int(np.max(np.abs(difference))) > 1:
        return None
    e_value = int(np.abs(difference).sum())
    return e_value, 1000 * e_value + 3 * support


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()
    started = time.perf_counter()
    values, _ = sem.read_solution_with_implicit_zero(args.solution)
    raw = sem.semantic.reconstruct_blocks(values, tolerance=0)
    blocks = {letter: np.asarray(raw[letter], dtype=np.int8) for letter in "ABCD"}
    target = target_tensor()
    incumbent_tensor = full_tensor(blocks)
    incumbent_support = int(sum(np.count_nonzero(blocks[x]) for x in "ABCD"))
    incumbent_e, incumbent_obj = score(incumbent_tensor, target, incumbent_support)

    keys = [("A", c) for c in range(4)] + [("G", c) for c in range(6)]
    old_components = {key: component_tensor(blocks, key) for key in keys}
    moves = []
    coefficient_id = 0
    for letter in "ABCD":
        for column in range(sem.semantic.BLOCK_WIDTHS[letter]):
            for row in range(9):
                old = int(blocks[letter][row, column])
                for new in (-1, 0, 1):
                    if new == old:
                        continue
                    modified = {x: blocks[x].copy() for x in "ABCD"}
                    modified[letter][row, column] = new
                    key = component_key(letter, column)
                    moves.append(
                        {
                            "coefficient_id": coefficient_id,
                            "letter": letter,
                            "row": row,
                            "column": column,
                            "old": old,
                            "new": new,
                            "key": key,
                            "support_delta": int(new != 0) - int(old != 0),
                            "tensor_delta": component_tensor(modified, key) - old_components[key],
                        }
                    )
                coefficient_id += 1

    counts = {
        "1": {"nominal": len(moves), "structurally_valid": 0, "model_feasible": 0},
        "2": {"nominal": 0, "structurally_valid": 0, "model_feasible": 0},
    }
    best = {"radius": 0, "E": incumbent_e, "K": incumbent_support, "objective": incumbent_obj, "moves": []}
    improvements = []

    def evaluate(selected, radius):
        nonlocal best
        modified = {x: blocks[x].copy() for x in "ABCD"}
        support = incumbent_support
        touched = set()
        for move in selected:
            modified[move["letter"]][move["row"], move["column"]] = move["new"]
            support += move["support_delta"]
            touched.add(tuple(move["key"]))
        if not structurally_valid(modified, support):
            return
        counts[str(radius)]["structurally_valid"] += 1
        tensor = incumbent_tensor.copy()
        for key in touched:
            tensor += component_tensor(modified, key) - old_components[key]
        scored = score(tensor, target, support)
        if scored is None:
            return
        counts[str(radius)]["model_feasible"] += 1
        e_value, objective = scored
        description = [{k: m[k] for k in ("letter", "row", "column", "old", "new")} for m in selected]
        candidate = {"radius": radius, "E": e_value, "K": support, "objective": objective, "moves": description}
        if objective < best["objective"]:
            best = candidate
        if objective < incumbent_obj:
            improvements.append(candidate)

    for move in moves:
        evaluate((move,), 1)
    for left in range(len(moves)):
        for right in range(left + 1, len(moves)):
            if moves[left]["coefficient_id"] == moves[right]["coefficient_id"]:
                continue
            counts["2"]["nominal"] += 1
            evaluate((moves[left], moves[right]), 2)

    result = {
        "instance": "fastxgemm-n3r22s4t6",
        "method": "exact exhaustive ternary coefficient-Hamming scan",
        "coefficient_count": coefficient_id,
        "incumbent": {"E": incumbent_e, "K": incumbent_support, "objective": incumbent_obj},
        "radius_counts": counts,
        "best": best,
        "strict_improvement_found": bool(improvements),
        "strict_improvements": improvements[:100],
        "elapsed_seconds": time.perf_counter() - started,
    }
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
