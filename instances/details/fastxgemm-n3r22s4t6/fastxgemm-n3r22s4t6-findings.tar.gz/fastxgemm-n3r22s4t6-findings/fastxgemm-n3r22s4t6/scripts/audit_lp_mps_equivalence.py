#!/usr/bin/env python3
"""Compare the author's R22 LP and the official MIPLIB MPS coefficient by coefficient."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from collections import Counter
from pathlib import Path

import gurobipy as gp
import numpy as np


def sha256(path: Path, decompress: bool = False) -> str:
    digest = hashlib.sha256()
    opener = gzip.open if decompress and path.suffix == ".gz" else open
    with opener(path, "rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("author_lp", type=Path)
    parser.add_argument("official_mps", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--source-commit", required=True)
    parser.add_argument("--source-file-commit", required=True)
    args = parser.parse_args()

    lp = gp.read(str(args.author_lp))
    mps = gp.read(str(args.official_mps))
    left_vars, right_vars = lp.getVars(), mps.getVars()
    left_rows, right_rows = lp.getConstrs(), mps.getConstrs()
    delta = lp.getA() - mps.getA()

    checks = {
        "dimensions_equal": (lp.NumVars, lp.NumConstrs, lp.NumNZs)
        == (mps.NumVars, mps.NumConstrs, mps.NumNZs),
        "variable_names_and_order_equal": [v.VarName for v in left_vars]
        == [v.VarName for v in right_vars],
        "constraint_names_and_order_equal": [c.ConstrName for c in left_rows]
        == [c.ConstrName for c in right_rows],
        "bounds_equal": np.array_equal(np.array(lp.getAttr("LB")), np.array(mps.getAttr("LB")))
        and np.array_equal(np.array(lp.getAttr("UB")), np.array(mps.getAttr("UB"))),
        "objective_equal": np.array_equal(np.array(lp.getAttr("Obj")), np.array(mps.getAttr("Obj")))
        and lp.ObjCon == mps.ObjCon
        and lp.ModelSense == mps.ModelSense,
        "rhs_equal": np.array_equal(np.array(lp.getAttr("RHS")), np.array(mps.getAttr("RHS"))),
        "senses_equal": [c.Sense for c in left_rows] == [c.Sense for c in right_rows],
        "matrix_equal": delta.nnz == 0,
    }
    type_differences = []
    domains_equivalent = True
    for left, right in zip(left_vars, right_vars):
        if left.VType == right.VType:
            continue
        equivalent = (
            {left.VType, right.VType} == {gp.GRB.BINARY, gp.GRB.INTEGER}
            and left.LB == right.LB == 0
            and left.UB == right.UB == 1
        )
        domains_equivalent &= equivalent
        if len(type_differences) < 20:
            type_differences.append(
                {
                    "variable": left.VarName,
                    "author_type": left.VType,
                    "mps_type": right.VType,
                    "domain_equivalent": equivalent,
                }
            )
    checks["variable_domains_equivalent"] = domains_equivalent
    equivalent = all(checks.values())
    if not equivalent:
        raise RuntimeError(f"LP/MPS semantic mismatch: {checks}")

    report = {
        "instance": "fastxgemm-n3r22s4t6",
        "gurobi_version": ".".join(map(str, gp.gurobi.version())),
        "source": {
            "snapshot_commit": args.source_commit,
            "file_introduction_commit": args.source_file_commit,
        },
        "sha256": {
            "author_lp": sha256(args.author_lp),
            "official_mps_gzip": sha256(args.official_mps),
            "official_mps_decompressed": sha256(args.official_mps, True),
        },
        "dimensions": {
            "variables": mps.NumVars,
            "constraints": mps.NumConstrs,
            "nonzeros": mps.NumNZs,
        },
        "checks": checks
        | {
            "matrix_difference_nonzeros": delta.nnz,
            "matrix_max_absolute_difference": float(max(np.abs(delta.data), default=0)),
        },
        "type_serialization": {
            "author_counts": dict(Counter(v.VType for v in left_vars)),
            "mps_counts": dict(Counter(v.VType for v in right_vars)),
            "different_label_count": sum(a.VType != b.VType for a, b in zip(left_vars, right_vars)),
            "examples": type_differences,
        },
        "semantically_equivalent": equivalent,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
