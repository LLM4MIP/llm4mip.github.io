#!/usr/bin/env python3
"""Add the R22 integer-valid LB90 cut and probe it with Gurobi."""

from __future__ import annotations

import argparse
import gzip
import json
import math
from pathlib import Path

import gurobipy as gp


CUT_NAME = "VALID_R22_LB90_SUPPORT_PLUS_6E"


def read_solution(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix == ".gz" else open
    values: dict[str, float] = {}
    with opener(path, "rt", encoding="utf-8") as stream:
        for raw in stream:
            fields = raw.strip().split()
            if len(fields) >= 2 and not fields[0].startswith(("#", "=")):
                values[fields[0]] = float(fields[1])
    return values


def finite(value: float) -> float | None:
    return float(value) if math.isfinite(float(value)) else None


def configure(probe: gp.Model, seconds: float, threads: int, log: Path) -> None:
    probe.Params.TimeLimit = seconds
    probe.Params.Threads = threads
    probe.Params.Presolve = 2
    probe.Params.NumericFocus = 2
    probe.Params.FeasibilityTol = 1e-9
    probe.Params.OptimalityTol = 1e-9
    probe.Params.LogFile = str(log)


def solve_lp(model: gp.Model, seconds: float, threads: int, log: Path) -> dict:
    probe = model.relax()
    configure(probe, seconds, threads, log)
    probe.Params.Method = 1
    probe.optimize()
    return {
        "status": int(probe.Status),
        "status_name": "OPTIMAL" if probe.Status == gp.GRB.OPTIMAL else str(probe.Status),
        "objective": finite(probe.ObjVal) if probe.SolCount else None,
        "runtime_seconds": float(probe.Runtime),
        "simplex_iterations": float(probe.IterCount),
        "solution_count": int(probe.SolCount),
        "dimensions": {
            "variables": probe.NumVars,
            "constraints": probe.NumConstrs,
            "nonzeros": probe.NumNZs,
        },
    }


def solve_root(
    model: gp.Model,
    start: Path,
    seconds: float,
    threads: int,
    log: Path,
) -> dict:
    probe = model.copy()
    probe.read(str(start))
    configure(probe, seconds, threads, log)
    probe.Params.NodeLimit = 0
    probe.Params.MIPFocus = 3
    probe.Params.Symmetry = 2
    probe.optimize()
    status_names = {
        gp.GRB.OPTIMAL: "OPTIMAL",
        gp.GRB.NODE_LIMIT: "NODE_LIMIT",
        gp.GRB.TIME_LIMIT: "TIME_LIMIT",
    }
    return {
        "status": int(probe.Status),
        "status_name": status_names.get(probe.Status, str(probe.Status)),
        "objective": finite(probe.ObjVal) if probe.SolCount else None,
        "objective_bound": finite(probe.ObjBound),
        "runtime_seconds": float(probe.Runtime),
        "node_count": float(probe.NodeCount),
        "simplex_iterations": float(probe.IterCount),
        "solution_count": int(probe.SolCount),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--output-model", type=Path, required=True)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--original-lp-log", type=Path, required=True)
    parser.add_argument("--augmented-lp-log", type=Path, required=True)
    parser.add_argument("--root-log", type=Path, required=True)
    parser.add_argument("--time-limit", type=float, default=120.0)
    parser.add_argument("--threads", type=int, default=8)
    args = parser.parse_args()
    for path in (
        args.output_model,
        args.json,
        args.original_lp_log,
        args.augmented_lp_log,
        args.root_log,
    ):
        path.parent.mkdir(parents=True, exist_ok=True)

    model = gp.read(str(args.mps))
    original_dimensions = {
        "variables": model.NumVars,
        "constraints": model.NumConstrs,
        "nonzeros": model.NumNZs,
        "integer_variables": sum(
            v.VType in {gp.GRB.BINARY, gp.GRB.INTEGER} for v in model.getVars()
        ),
    }
    support = [v for v in model.getVars() if v.VarName.startswith("ABS_ALT_")]
    residual = [v for v in model.getVars() if v.VarName.startswith("RESIDUAL_")]
    if len(support) != 594 or len(residual) != 729:
        raise RuntimeError(
            f"unexpected R22 families: support={len(support)}, residual={len(residual)}"
        )
    support_names = {variable.VarName for variable in support}
    original_support_rows = []
    for constraint in model.getConstrs():
        if constraint.Sense != ">" or abs(constraint.RHS - 84.0) > 1e-12:
            continue
        candidate = model.getRow(constraint)
        if candidate.size() != len(support):
            continue
        names = {candidate.getVar(index).VarName for index in range(candidate.size())}
        coefficients = {
            candidate.getCoeff(index) for index in range(candidate.size())
        }
        if names == support_names and coefficients == {1.0}:
            original_support_rows.append(constraint.ConstrName)
    if len(original_support_rows) != 1:
        raise RuntimeError(
            "could not uniquely verify the original sum(ABS_ALT)>=84 row: "
            f"{original_support_rows}"
        )

    original_lp = solve_lp(
        model, args.time_limit, args.threads, args.original_lp_log
    )
    model.addConstr(
        gp.quicksum(support) + 6 * gp.quicksum(residual) >= 90,
        name=CUT_NAME,
    )
    model.update()
    model.write(str(args.output_model))

    cut = model.getConstrByName(CUT_NAME)
    row = model.getRow(cut)
    coefficient_counts: dict[str, int] = {}
    for index in range(row.size()):
        key = format(row.getCoeff(index), ".12g")
        coefficient_counts[key] = coefficient_counts.get(key, 0) + 1

    incumbent = read_solution(args.solution)
    missing = [v.VarName for v in support + residual if v.VarName not in incumbent]
    if missing:
        raise RuntimeError(f"solution is missing {len(missing)} cut variables")
    incumbent_support = sum(incumbent[v.VarName] for v in support)
    incumbent_error = sum(incumbent[v.VarName] for v in residual)
    incumbent_lhs = incumbent_support + 6 * incumbent_error

    report = {
        "instance": "fastxgemm-n3r22s4t6",
        "gurobi_version": ".".join(map(str, gp.gurobi.version())),
        "claim": {
            "previous_project_global_lb": 87,
            "new_project_global_lb": 90,
            "strict_improvement": True,
            "author_prior_upper_bound_unchanged": 1171,
            "global_optimality_proved": False,
        },
        "proof": {
            "exact_branch": "E=0 implies K>=30, hence full factor support>=90",
            "inexact_branch": "E>=1 and the original full-support bound 84 imply support+6E>=90",
            "scope": "official ternary cyclic S=4,T=6,R=22 integer model only",
            "integer_valid_not_plain_lp_valid": True,
            "verified_original_abs_alt_support_bound_rows": original_support_rows,
        },
        "cut": {
            "name": CUT_NAME,
            "formula": "sum(ABS_ALT_U,V,W) + 6*sum(RESIDUAL) >= 90",
            "sense": cut.Sense,
            "rhs": float(cut.RHS),
            "nonzeros": row.size(),
            "coefficient_counts": coefficient_counts,
            "support_variable_count": len(support),
            "residual_variable_count": len(residual),
        },
        "dimensions": {
            "original": original_dimensions,
            "augmented": {
                "variables": model.NumVars,
                "constraints": model.NumConstrs,
                "nonzeros": model.NumNZs,
                "integer_variables": sum(
                    v.VType in {gp.GRB.BINARY, gp.GRB.INTEGER}
                    for v in model.getVars()
                ),
            },
        },
        "author_prior_solution_cut_check": {
            "solution": str(args.solution),
            "full_factor_support": incumbent_support,
            "E": incumbent_error,
            "cut_lhs": incumbent_lhs,
            "cut_slack": incumbent_lhs - 90,
        },
        "original_lp_relaxation": original_lp,
        "augmented_lp_relaxation": solve_lp(
            model, args.time_limit, args.threads, args.augmented_lp_log
        ),
        "augmented_root_probe": solve_root(
            model, args.solution, args.time_limit, args.threads, args.root_log
        ),
        "output_model": str(args.output_model),
    }
    args.json.write_text(
        json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(report, indent=2, sort_keys=True, allow_nan=False))


if __name__ == "__main__":
    main()
