#!/usr/bin/env python3
"""Exact tensor/support audit for the N=3,R=22,S=4,T=6 cyclic model."""

from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path


INSTANCES_DIR = Path(__file__).resolve().parents[2]
BASE = INSTANCES_DIR / "fastxgemm-n3r21s3t6" / "scripts" / "exact_semantic_audit.py"
SPEC = importlib.util.spec_from_file_location("fastx_semantic_base", BASE)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError(f"cannot load semantic audit helper: {BASE}")
semantic = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(semantic)

semantic.N = 3
semantic.R = 22
semantic.S = 4
semantic.T = 6
semantic.BLOCK_WIDTHS = {"A": 4, "B": 6, "C": 6, "D": 6}

_read_sparse = semantic.read_solution


def read_solution_with_implicit_zero(path: Path):
    values, stated = _read_sparse(path)
    for letter, width in semantic.BLOCK_WIDTHS.items():
        for row in range(9):
            for column in range(width):
                values.setdefault(f"POS_{letter}_{row}_{column}", 0.0)
                values.setdefault(f"NEG_{letter}_{row}_{column}", 0.0)
    return values, stated


semantic.read_solution = read_solution_with_implicit_zero


def audit(path: Path, tolerance: float = 1e-6):
    result = semantic.audit(path, tolerance)
    result["instance"] = "fastxgemm-n3r22s4t6"
    result["interpretation"].update({"N": 3, "R": 22, "S": 4, "T": 6})
    exact = result["exact_from_binary_pattern"]
    exact.pop("strictly_below_4111", None)
    exact["strictly_below_3102"] = exact["objective_1000E_plus_3K"] < 3102
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--json", type=Path)
    parser.add_argument("--tolerance", type=float, default=1e-6)
    args = parser.parse_args()
    result = audit(args.solution, args.tolerance)
    rendered = json.dumps(result, indent=2, sort_keys=False, allow_nan=False)
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)


if __name__ == "__main__":
    main()
