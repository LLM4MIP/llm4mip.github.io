#!/usr/bin/env python3
"""Search/prove strict improvement while forbidding new support locations."""

from __future__ import annotations

import argparse
import importlib.util
import json
import math
import time
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def load_semantic():
    path = Path(__file__).with_name("r22_semantic_audit.py")
    spec = importlib.util.spec_from_file_location("r22_semantic", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


semantic = load_semantic()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path)
    parser.add_argument("start", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--time-limit", type=float, default=300.0)
    args = parser.parse_args()
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.log.parent.mkdir(parents=True, exist_ok=True)

    started = time.perf_counter()
    start_values, _ = semantic.read_solution_with_implicit_zero(args.start)
    model = gp.read(str(args.model))
    model.Params.LogFile = str(args.log)
    model.Params.Threads = 4
    model.Params.TimeLimit = args.time_limit
    model.Params.FeasibilityTol = 1e-9
    model.Params.IntFeasTol = 1e-9
    model.Params.OptimalityTol = 1e-9
    model.Params.NumericFocus = 3
    model.Params.Presolve = 2
    model.Params.MIPFocus = 1

    fixed_zero_locations = 0
    free_locations = 0
    for letter, width in semantic.semantic.BLOCK_WIDTHS.items():
        for row in range(9):
            for column in range(width):
                pos_name = f"POS_{letter}_{row}_{column}"
                neg_name = f"NEG_{letter}_{row}_{column}"
                if round(start_values[pos_name]) == 0 and round(start_values[neg_name]) == 0:
                    model.getVarByName(pos_name).UB = 0
                    model.getVarByName(neg_name).UB = 0
                    fixed_zero_locations += 1
                else:
                    free_locations += 1

    diagonal = []
    for i in range(9):
        for j in range(9):
            for k in range(9):
                residual = model.getVarByName(f"RESIDUAL_{i}_{j}_{k}")
                if i == j == k:
                    diagonal.append(residual)
                else:
                    residual.UB = 0
    model.addConstr(gp.quicksum(diagonal) <= 1, name="IMPROVE_E_LE_ONE_DIAGONAL")
    model.addConstr(model.getObjective() <= 1168, name="STRICT_IMPROVEMENT_LATTICE_CAP")
    model.update()
    model.read(str(args.start))
    model.optimize()

    status_name = {
        GRB.OPTIMAL: "OPTIMAL",
        GRB.INFEASIBLE: "INFEASIBLE",
        GRB.TIME_LIMIT: "TIME_LIMIT",
        GRB.INTERRUPTED: "INTERRUPTED",
    }.get(model.Status, str(model.Status))
    result = {
        "instance": "fastxgemm-n3r22s4t6",
        "scope": "author's 57 support locations only; arbitrary deletion and sign changes",
        "logic": "strict improvement over 1171 requires E=0, or E=1 and K<=56; cyclic errors with E<=1 are diagonal",
        "fixed_zero_underlying_locations": fixed_zero_locations,
        "free_underlying_locations": free_locations,
        "objective_cap": 1168,
        "status_code": int(model.Status),
        "status": status_name,
        "solution_count": int(model.SolCount),
        "runtime_seconds": float(model.Runtime),
        "wall_seconds": time.perf_counter() - started,
        "node_count": float(model.NodeCount),
        "best_bound": float(model.ObjBound) if model.IsMIP and math.isfinite(float(model.ObjBound)) else None,
        "best_objective": float(model.ObjVal) if model.SolCount else None,
        "proof_scope_note": (
            "INFEASIBLE proves only that no strict improvement exists without activating a previously zero A/B/C/D coefficient. "
            "TIME_LIMIT would not be a proof."
        ),
    }
    args.json.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
