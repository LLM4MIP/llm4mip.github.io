#!/usr/bin/env python3
"""Add the integer-valid LB87 cut and compare continuous root relaxations."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import gurobipy as gp


def solve_relaxation(model: gp.Model) -> dict:
    relaxed = model.relax()
    relaxed.Params.OutputFlag = 0
    relaxed.Params.Method = 1
    relaxed.Params.FeasibilityTol = 1e-9
    relaxed.Params.OptimalityTol = 1e-9
    relaxed.optimize()
    return {
        "status": int(relaxed.Status),
        "objective": float(relaxed.ObjVal) if relaxed.SolCount else None,
        "runtime_seconds": float(relaxed.Runtime),
        "iterations": float(relaxed.IterCount),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("--output-model", type=Path, required=True)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()
    args.output_model.parent.mkdir(parents=True, exist_ok=True)
    args.json.parent.mkdir(parents=True, exist_ok=True)

    model = gp.read(str(args.mps))
    model.Params.OutputFlag = 0
    before = solve_relaxation(model)
    support = [v for v in model.getVars() if v.VarName.startswith(("ABS_ALT_U_", "ABS_ALT_V_", "ABS_ALT_W_"))]
    residual = [v for v in model.getVars() if v.VarName.startswith("RESIDUAL_")]
    if len(support) != 594 or len(residual) != 729:
        raise RuntimeError(f"unexpected variable counts: support={len(support)} residual={len(residual)}")
    model.addConstr(gp.quicksum(support) + 3 * gp.quicksum(residual) >= 87, name="VALID_INTEGER_LB87")
    model.update()
    model.write(str(args.output_model))
    after = solve_relaxation(model)

    result = {
        "instance": "fastxgemm-n3r22s4t6",
        "cut": "sum(ABS_ALT_U,V,W) + 3*sum(RESIDUAL) >= 87",
        "validity": (
            "At integer factor patterns: if E=0, nine rank-3 slices and R=22 force K>=29, hence full support>=87; "
            "if E>=1, the original model gives full support>=84 and adding 3E reaches 87."
        ),
        "integer_valid_not_plain_lp_valid": True,
        "original_lp_relaxation": before,
        "augmented_lp_relaxation": after,
        "output_model": str(args.output_model),
    }
    args.json.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
