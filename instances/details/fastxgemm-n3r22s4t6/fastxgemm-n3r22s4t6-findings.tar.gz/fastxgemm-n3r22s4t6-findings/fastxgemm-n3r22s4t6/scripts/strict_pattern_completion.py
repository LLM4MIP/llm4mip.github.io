#!/usr/bin/env python3
"""Fix a source solution's integer pattern, recompute auxiliaries, and audit exactly."""

from __future__ import annotations

import argparse
import importlib.util
import json
import math
from pathlib import Path

import gurobipy as gp
import numpy as np


INSTANCES_DIR = Path(__file__).resolve().parents[2]
BASE_SCRIPTS = INSTANCES_DIR / "fastxgemm-n3r21s3t6" / "scripts"


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


common = load_module("fastx_common_audit", BASE_SCRIPTS / "repair_and_audit_incumbent.py")
semantic = load_module("r22_semantic", Path(__file__).with_name("r22_semantic_audit.py"))


def parse_sparse(path: Path) -> tuple[float | None, dict[str, float]]:
    lines = path.read_text(encoding="utf-8").splitlines(keepends=True)
    return common.parse_values(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("source_solution", type=Path)
    parser.add_argument("--label", required=True)
    parser.add_argument("--expected-objective", type=int, required=True)
    parser.add_argument("--output-solution", type=Path, required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    args = parser.parse_args()
    for path in (args.output_solution, args.output_json, args.log):
        path.parent.mkdir(parents=True, exist_ok=True)

    declared, sparse = parse_sparse(args.source_solution)
    original = gp.read(str(args.mps))
    original.Params.OutputFlag = 0
    variables = original.getVars()
    names = {v.VarName for v in variables}
    unknown = sorted(set(sparse) - names)
    if unknown:
        raise RuntimeError(f"unknown source variables: {unknown[:10]}")
    source_values = {v.VarName: sparse.get(v.VarName, 0.0) for v in variables}
    source_float_audit = common.audit(original, source_values)

    model = gp.read(str(args.mps))
    model.read(str(args.source_solution))
    fixed_count = 0
    rounded_changes = []
    for variable in model.getVars():
        if variable.VType in {gp.GRB.BINARY, gp.GRB.INTEGER}:
            raw = source_values[variable.VarName]
            value = round(raw)
            if abs(raw - value) > 1e-12:
                rounded_changes.append({"variable": variable.VarName, "source": raw, "fixed": value})
            variable.LB = value
            variable.UB = value
            fixed_count += 1
    model.update()
    model.Params.FeasibilityTol = 1e-9
    model.Params.IntFeasTol = 1e-9
    model.Params.OptimalityTol = 1e-9
    model.Params.NumericFocus = 3
    model.Params.Presolve = 2
    model.Params.Method = 1
    model.Params.Threads = 4
    model.Params.LogFile = str(args.log)
    model.optimize()
    if model.Status != gp.GRB.OPTIMAL or model.SolCount < 1:
        raise RuntimeError(f"fixed-pattern completion failed: status={model.Status}")

    x = np.array([v.X for v in model.getVars()], dtype=float)
    rounded = np.rint(x).astype(np.int64)
    max_distance = float(np.max(np.abs(x - rounded)))
    if max_distance > 1e-8:
        raise RuntimeError(f"completed values are not integral: max distance {max_distance}")

    output_lines = [
        f"=obj= {args.expected_objective}",
        f"# Strict full integer solution from fixed-pattern completion of {args.label}.",
    ]
    output_lines.extend(f"{v.VarName} {int(rounded[i])}" for i, v in enumerate(model.getVars()))
    args.output_solution.write_text("\n".join(output_lines) + "\n", encoding="utf-8")

    out_lines = args.output_solution.read_text(encoding="utf-8").splitlines(keepends=True)
    _, exact_values = common.parse_values(out_lines)
    tokens = common.parse_value_tokens(out_lines)
    strict_float = common.audit(original, exact_values)
    strict_decimal = common.exact_decimal_audit(original, tokens)
    strict_integer = common.exact_integer_audit(original, exact_values)
    semantic_result = semantic.audit(args.output_solution, 0.0)
    exact_objective = semantic_result["exact_from_binary_pattern"]["objective_1000E_plus_3K"]
    if (
        exact_objective != args.expected_objective
        or abs(strict_float["recomputed_objective_float"] - args.expected_objective) > 1e-9
        or strict_decimal["violated_constraint_count"]
        or strict_decimal["violated_bound_count"]
        or strict_integer["violated_constraint_count"]
        or strict_integer["violated_bound_count"]
    ):
        raise RuntimeError("strict exact audit failed")

    report = {
        "instance": "fastxgemm-n3r22s4t6",
        "label": args.label,
        "source_declared_objective": declared,
        "source_supplied_variables": len(sparse),
        "source_implicit_zero_variables": len(variables) - len(sparse),
        "source_float_audit": source_float_audit,
        "fixed_integer_count": fixed_count,
        "integer_rounding_changes": rounded_changes,
        "solve": {
            "status": "OPTIMAL",
            "status_scope": "fixed_integer_pattern_completion_only",
            "runtime_seconds": model.Runtime,
            "objective": model.ObjVal,
            "max_distance_to_integer_all_completed_values": max_distance,
        },
        "strict_solution": {
            "path": str(args.output_solution),
            "float_audit": strict_float,
            "exact_decimal_audit": strict_decimal,
            "exact_integer_audit": strict_integer,
            "semantic_audit": semantic_result,
            "sha256": common.sha256(args.output_solution),
        },
    }
    args.output_json.write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({"label": args.label, "objective": exact_objective, "E": semantic_result["exact_from_binary_pattern"]["E_tensor_l1_error"], "K": semantic_result["exact_from_binary_pattern"]["K_underlying_ABCD_support"], "runtime": model.Runtime}, indent=2))


if __name__ == "__main__":
    main()
