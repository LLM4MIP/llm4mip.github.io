#!/usr/bin/env python3
"""Finite audit of every combinatorial case used in the R22 LB90 proof.

This is not an exhaustive enumeration of ternary factorizations.  It checks
the complete finite case split after the slice-rank and tight-row lemmas:
all nine-row degree vectors with d_i>=3 and sum d_i=29, every possible pair
of non-tight grid rows, every possible unique uncovered A/B/C/D vector, and
all tight-row choices that yield the line-support bounds in a B/C/D orbit.
"""

from __future__ import annotations

import argparse
import itertools
import json
from collections import Counter
from fractions import Fraction
from pathlib import Path


N = 3
R = 22
S = 4
T = 6
GRID = tuple((i // N, i % N) for i in range(N * N))


def target_value(i: int, j: int, k: int) -> int:
    n, q = GRID[i]
    q2, m = GRID[j]
    m2, n2 = GRID[k]
    return int(q == q2 and m == m2 and n == n2)


def exact_rank(matrix: list[list[int]]) -> int:
    work = [[Fraction(value) for value in row] for row in matrix]
    rows = len(work)
    columns = len(work[0])
    rank = 0
    for column in range(columns):
        pivot = next((row for row in range(rank, rows) if work[row][column]), None)
        if pivot is None:
            continue
        work[rank], work[pivot] = work[pivot], work[rank]
        scale = work[rank][column]
        work[rank] = [value / scale for value in work[rank]]
        for row in range(rows):
            if row == rank or not work[row][column]:
                continue
            multiplier = work[row][column]
            work[row] = [
                value - multiplier * pivot_value
                for value, pivot_value in zip(work[row], work[rank])
            ]
        rank += 1
        if rank == rows:
            break
    return rank


def audit_target_slices() -> dict:
    tensor = [
        [[target_value(i, j, k) for k in range(9)] for j in range(9)]
        for i in range(9)
    ]
    support = sum(tensor[i][j][k] for i in range(9) for j in range(9) for k in range(9))
    cyclic = all(
        tensor[i][j][k] == tensor[j][k][i] == tensor[k][i][j]
        for i in range(9)
        for j in range(9)
        for k in range(9)
    )
    ranks: dict[str, list[int]] = {}
    nonzero_counts: dict[str, list[int]] = {}
    for mode in range(3):
        mode_ranks = []
        mode_counts = []
        for fixed in range(9):
            matrix = []
            for left in range(9):
                row = []
                for right in range(9):
                    coordinate = [left, left, right]
                    coordinate[mode] = fixed
                    if mode == 0:
                        coordinate = [fixed, left, right]
                    elif mode == 1:
                        coordinate = [left, fixed, right]
                    else:
                        coordinate = [left, right, fixed]
                    row.append(tensor[coordinate[0]][coordinate[1]][coordinate[2]])
                matrix.append(row)
            mode_ranks.append(exact_rank(matrix))
            mode_counts.append(sum(sum(row) for row in matrix))
        ranks["UVW"[mode]] = mode_ranks
        nonzero_counts["UVW"[mode]] = mode_counts
    all_rank_three = all(value == 3 for values in ranks.values() for value in values)
    all_three_nonzeros = all(
        value == 3 for values in nonzero_counts.values() for value in values
    )
    if support != 27 or not cyclic or not all_rank_three or not all_three_nonzeros:
        raise AssertionError((support, cyclic, ranks, nonzero_counts))
    return {
        "target_support": support,
        "cyclically_invariant": cyclic,
        "exact_slice_ranks": ranks,
        "slice_nonzero_counts": nonzero_counts,
        "all_27_mode_slices_have_rank_three": all_rank_three,
    }


def degree_vectors(total: int) -> list[tuple[int, ...]]:
    """All ordered d>=3 with the requested total."""
    excess = total - 27
    vectors = []
    for allocation in itertools.product(range(excess + 1), repeat=9):
        if sum(allocation) == excess:
            vectors.append(tuple(3 + value for value in allocation))
    return vectors


def labels() -> tuple[str, ...]:
    return tuple(
        [f"A{column}" for column in range(S)]
        + [f"{letter}{column}" for letter in "BCD" for column in range(T)]
    )


def factor_at_position(mode: str, position: str) -> str:
    """Underlying vector occurring at a fixed rank position in one mode."""
    letter, column = position[0], position[1:]
    maps = {
        "U": {"A": "A", "B": "B", "C": "C", "D": "D"},
        "V": {"A": "A", "B": "D", "C": "B", "D": "C"},
        "W": {"A": "A", "B": "C", "C": "D", "D": "B"},
    }
    return f"{maps[mode][letter]}{column}"


def uncovered_position(mode: str, vector: str) -> str:
    matches = [position for position in labels() if factor_at_position(mode, position) == vector]
    if len(matches) != 1:
        raise AssertionError((mode, vector, matches))
    return matches[0]


def u_tight_opposite_lines(row_index: int) -> tuple[set[int], set[int]]:
    """Allowed V and W supports from a tight U row (n,q)."""
    n, q = GRID[row_index]
    v_line = {N * q + m for m in range(N)}
    w_line = {N * m + n for m in range(N)}
    return v_line, w_line


def audit_degrees() -> dict:
    vectors = degree_vectors(29)
    if len(vectors) != 45:
        raise AssertionError(len(vectors))
    histogram = Counter(sum(value == 3 for value in vector) for vector in vectors)
    if histogram != Counter({7: 36, 8: 9}):
        raise AssertionError(histogram)
    eight_tight = [vector for vector in vectors if vector.count(3) == 8]
    seven_tight = [vector for vector in vectors if vector.count(3) == 7]
    return {
        "ordered_degree_vectors": len(vectors),
        "degree_multiset_counts": {
            "(5,3^8)": len(eight_tight),
            "(4,4,3^7)": len(seven_tight),
        },
        "eight_tight_required_positions": 8 * 3,
        "available_rank_positions": R,
        "eight_tight_capacity_contradiction": 8 * 3 > R,
        "seven_tight_cases_for_unique_uncovered_audit": len(seven_tight),
    }


def audit_k30_boundary() -> dict:
    vectors = degree_vectors(30)
    if len(vectors) != 165:
        raise AssertionError(len(vectors))
    histogram = Counter(sum(value == 3 for value in vector) for vector in vectors)
    expected = Counter({6: 84, 7: 72, 8: 9})
    if histogram != expected:
        raise AssertionError((histogram, expected))
    eight_tight_excluded = 8 * 3 > R
    # Seven tight rows leave the same one uncovered position per mode as K=29.
    # The A case has support >=30-21=9; the BCD case remains bounded by 19+7.
    seven_tight_a_excluded = 9**3 - 27 > 21
    seven_tight_bcd_excluded = 19 + 1 + 3 + 3 < 30
    surviving = [vector for vector in vectors if vector.count(3) == 6]
    surviving_multisets = {
        tuple(sorted(vector, reverse=True)) for vector in surviving
    }
    if surviving_multisets != {(4, 4, 4, 3, 3, 3, 3, 3, 3)}:
        raise AssertionError(surviving_multisets)
    return {
        "ordered_degree_vectors": len(vectors),
        "degree_multiset_counts": {
            "(6,3^8)": histogram[8],
            "(5,4,3^7)": histogram[7],
            "(4,4,4,3^6)": histogram[6],
        },
        "eight_tight_cases_excluded_by_24_gt_22": eight_tight_excluded,
        "seven_tight_A_cases_excluded_by_cube_support": seven_tight_a_excluded,
        "seven_tight_BCD_cases_excluded_by_support_upper_bound_26": seven_tight_bcd_excluded,
        "surviving_ordered_degree_vectors": len(surviving),
        "only_surviving_degree_multiset": [4, 4, 4, 3, 3, 3, 3, 3, 3],
        "interpretation": (
            "An exact K=30 point, if one exists, must have six tight rows and "
            "three degree-four rows; this does not prove existence or infeasibility."
        ),
    }


def audit_cyclic_mapping() -> dict:
    all_labels = labels()
    mapping_rows = []
    a_cases = 0
    orbit_cases = 0
    for vector in all_labels:
        uncovered = {mode: uncovered_position(mode, vector) for mode in "UVW"}
        common_covered = set(all_labels) - set(uncovered.values())
        if vector.startswith("A"):
            a_cases += 1
            if len(set(uncovered.values())) != 1 or len(common_covered) != 21:
                raise AssertionError((vector, uncovered, len(common_covered)))
            kind = "A-fixed"
        else:
            orbit_cases += 1
            if len(set(uncovered.values())) != 3 or len(common_covered) != 19:
                raise AssertionError((vector, uncovered, len(common_covered)))
            columns = {position[1:] for position in uncovered.values()}
            letters = {position[0] for position in uncovered.values()}
            if len(columns) != 1 or letters != set("BCD"):
                raise AssertionError((vector, uncovered))
            kind = "BCD-rotating"
        mapping_rows.append(
            {
                "uncovered_underlying_vector": vector,
                "case": kind,
                "uncovered_rank_position_by_mode": uncovered,
                "positions_covered_in_all_modes": len(common_covered),
            }
        )
    return {
        "underlying_vectors": len(all_labels),
        "A_fixed_cases": a_cases,
        "BCD_rotating_cases": orbit_cases,
        "all_cases_classified": a_cases == S and orbit_cases == 3 * T,
        "cases": mapping_rows,
    }


def audit_a_case() -> dict:
    # Other 21 positions are singleton (or zero).  K=29 therefore forces the
    # uncovered A vector to have support at least eight.
    checks = []
    exhaustive_case_count = 0
    for non_tight in itertools.combinations(range(9), 2):
        for vector in (f"A{column}" for column in range(S)):
            for support in (8, 9):
                cube_support = support**3
                minimum_support_needed_from_other_terms = cube_support - 27
                exhaustive_case_count += 1
                if len(checks) < 8:
                    checks.append(
                        {
                            "non_tight_rows": list(non_tight),
                            "uncovered_A_vector": vector,
                            "A_support": support,
                            "cube_support": cube_support,
                            "target_support": 27,
                            "singleton_terms_available": 21,
                            "minimum_coordinates_cube_minus_target": minimum_support_needed_from_other_terms,
                            "contradiction": minimum_support_needed_from_other_terms > 21,
                        }
                    )
                if minimum_support_needed_from_other_terms <= 21:
                    raise AssertionError((non_tight, vector, support))
    if not all(item["contradiction"] for item in checks):
        raise AssertionError(checks)
    return {
        "other_U_support_upper_bound": 21,
        "K_assumption": 29,
        "uncovered_A_support_lower_bound": 8,
        "exhaustive_degree_A_support_cases": exhaustive_case_count,
        "saved_examples": checks,
        "all_A_cases_contradict_exact_target": True,
    }


def audit_bcd_lines() -> dict:
    checks = 0
    min_intersection = 10
    max_intersection = -1
    examples = []
    # Every (4,4,3^7) degree vector chooses two non-tight rows.  If B is the
    # uncovered underlying vector, covered primary C and D positions select
    # some tight U rows.  Tight C restricts B through V to a grid row; tight D
    # restricts B through W to a grid column.  Enumerate all such choices.
    bcd_vectors = tuple(
        f"{letter}{column}" for letter in "BCD" for column in range(T)
    )
    for non_tight in itertools.combinations(range(9), 2):
        tight = tuple(row for row in range(9) if row not in non_tight)
        for uncovered_vector in bcd_vectors:
            induced = {
                mode: uncovered_position(mode, uncovered_vector) for mode in "UVW"
            }
            for c_primary_row in tight:
                b_v_line, d_w_line = u_tight_opposite_lines(c_primary_row)
                for d_primary_row in tight:
                    c_v_line, b_w_line = u_tight_opposite_lines(d_primary_row)
                    intersection = b_v_line & b_w_line
                    checks += 1
                    min_intersection = min(min_intersection, len(intersection))
                    max_intersection = max(max_intersection, len(intersection))
                    if len(examples) < 5:
                        examples.append(
                            {
                                "non_tight_rows": list(non_tight),
                                "uncovered_vector": uncovered_vector,
                                "uncovered_rank_position_by_mode": induced,
                                "C_primary_tight_row": c_primary_row,
                                "D_primary_tight_row": d_primary_row,
                                "B_row_line": sorted(b_v_line),
                                "B_column_line": sorted(b_w_line),
                                "B_intersection": sorted(intersection),
                                "C_line_size": len(c_v_line),
                                "D_line_size": len(d_w_line),
                            }
                        )
                    if len(intersection) > 1 or len(c_v_line) > 3 or len(d_w_line) > 3:
                        raise AssertionError(examples[-1])
    expected = math_comb(9, 2) * len(bcd_vectors) * 7 * 7
    if checks != expected:
        raise AssertionError((checks, expected))
    orbit_support_upper_bound = 1 + 3 + 3
    total_k_upper_bound = 19 + orbit_support_upper_bound
    return {
        "non_tight_row_pairs": math_comb(9, 2),
        "uncovered_BCD_vector_cases_per_degree_case": len(bcd_vectors),
        "tight_primary_row_pairs_per_case": 7 * 7,
        "line_geometry_checks": checks,
        "B_row_column_intersection_min": min_intersection,
        "B_row_column_intersection_max": max_intersection,
        "orbit_support_upper_bound": orbit_support_upper_bound,
        "common_singleton_position_count": 19,
        "K_upper_bound": total_k_upper_bound,
        "contradicts_K_29": total_k_upper_bound < 29,
        "examples": examples,
    }


def math_comb(n: int, k: int) -> int:
    # Avoid importing another module solely for a small exact integer.
    numerator = 1
    denominator = 1
    for value in range(1, k + 1):
        numerator *= n - value + 1
        denominator *= value
    return numerator // denominator


def audit_cut() -> dict:
    checks = []
    # The exact branch uses actual support >=90.  For every inexact integer
    # pattern, a nonzero integral tensor discrepancy forces residual sum >=1;
    # enumerate a conservative complete range for the *actual integer* L1
    # discrepancy at its minimal model support 84.  Each tensor expansion is
    # a sum of R ternary products, hence lies in [-R,R]; a target entry is 0
    # or 1, so every coordinate discrepancy is at most R+1 and
    # E_actual <= 9^3*(R+1).  Continuous residual auxiliaries may be still
    # larger or fractional, but the cut left side is monotone in them and its
    # minimum for a fixed actual error occurs at R_aux=E_actual.
    conservative_actual_error_max = (N ** 6) * (R + 1)
    for actual_error in range(1, conservative_actual_error_max + 1):
        lhs = 84 + 6 * actual_error
        checks.append(lhs >= 90)
    return {
        "exact_branch_minimum_lhs": 90,
        "inexact_branch_original_support_lower_bound": 84,
        "inexact_branch_residual_sum_lower_bound": 1,
        "inexact_branch_minimum_lhs": 84 + 6,
        "conservative_actual_integer_error_upper_bound": conservative_actual_error_max,
        "enumerated_actual_integer_error_range": [1, conservative_actual_error_max],
        "monotone_for_all_larger_or_fractional_residual_auxiliary_sums": True,
        "all_inexact_cases_satisfy_cut": all(checks),
        "note": (
            "Residual auxiliaries need not be minimal or integral at an arbitrary "
            "feasible point. The model links them above the absolute discrepancy; "
            "an inexact integer factor pattern has an integral discrepancy of "
            "magnitude at least one, hence residual sum at least one."
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()
    result = {
        "instance": "fastxgemm-n3r22s4t6",
        "scope": (
            "finite audit of the post-lemma K=29 case split; not exhaustive "
            "enumeration of all ternary factor assignments"
        ),
        "parameters": {"N": N, "R": R, "S": S, "T": T},
        "target_tensor_audit": audit_target_slices(),
        "degree_case_audit": audit_degrees(),
        "exact_K30_boundary_audit": audit_k30_boundary(),
        "cyclic_uncovered_mapping_audit": audit_cyclic_mapping(),
        "A_uncovered_support_audit": audit_a_case(),
        "BCD_uncovered_line_geometry_audit": audit_bcd_lines(),
        "global_cut_case_audit": audit_cut(),
    }
    result["all_checks_pass"] = all(
        (
            result["degree_case_audit"]["eight_tight_capacity_contradiction"],
            result["target_tensor_audit"]["all_27_mode_slices_have_rank_three"],
            result["exact_K30_boundary_audit"]["eight_tight_cases_excluded_by_24_gt_22"],
            result["exact_K30_boundary_audit"]["seven_tight_A_cases_excluded_by_cube_support"],
            result["exact_K30_boundary_audit"]["seven_tight_BCD_cases_excluded_by_support_upper_bound_26"],
            result["cyclic_uncovered_mapping_audit"]["all_cases_classified"],
            result["A_uncovered_support_audit"]["all_A_cases_contradict_exact_target"],
            result["BCD_uncovered_line_geometry_audit"]["contradicts_K_29"],
            result["global_cut_case_audit"]["all_inexact_cases_satisfy_cut"],
        )
    )
    if not result["all_checks_pass"]:
        raise RuntimeError("LB90 finite audit failed")
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(
        json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "all_checks_pass": True,
                "degree_vectors": result["degree_case_audit"]["ordered_degree_vectors"],
                "K30_surviving_degree_vectors": result["exact_K30_boundary_audit"]["surviving_ordered_degree_vectors"],
                "uncovered_vector_cases": result["cyclic_uncovered_mapping_audit"]["underlying_vectors"],
                "line_geometry_checks": result["BCD_uncovered_line_geometry_audit"]["line_geometry_checks"],
                "cut_inexact_minimum_lhs": result["global_cut_case_audit"]["inexact_branch_minimum_lhs"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
