#!/usr/bin/env python3
"""Run the reusable exhaustive one-vector scanner with R22 constants."""

from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path


INSTANCES_DIR = Path(__file__).resolve().parents[2]
R22_PATH = Path(__file__).with_name("r22_semantic_audit.py")
BASE_SCAN = INSTANCES_DIR / "fastxgemm-n3r21s3t6" / "scripts" / "one_vector_scan.py"


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


r22 = load("r22_semantic", R22_PATH)
sys.modules["exact_semantic_audit"] = r22.semantic
scanner = load("fastx_one_vector_base", BASE_SCAN)
scanner.__doc__ = (
    "Exhaustively replace each of the 22 underlying ternary vectors for the "
    "N=3,R=22,S=4,T=6 instance."
)


if __name__ == "__main__":
    output = None
    if "--json" in sys.argv:
        output = Path(sys.argv[sys.argv.index("--json") + 1])
    scanner.main()
    if output is not None:
        result = json.loads(output.read_text(encoding="utf-8"))
        result["instance"] = "fastxgemm-n3r22s4t6"
        result["vectors_scanned"] = 22
        result["total_candidates"] = 22 * result["candidates_per_vector"]
        output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
