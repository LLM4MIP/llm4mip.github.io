#!/usr/bin/env python3
"""Independently verify the scpk4 domination reduction and reduced MPS."""

import argparse
import json
from pathlib import Path

from setcover_structure import parse_mps


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("certificate", type=Path)
    parser.add_argument("reduced_model", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    senses, rhs, costs, columns = parse_mps(args.model)
    reduced_senses, reduced_rhs, reduced_costs, reduced_columns = parse_mps(
        args.reduced_model
    )
    certificate = json.loads(args.certificate.read_text(encoding="utf-8"))
    dominated = certificate["dominated"]

    assert all(sense == "G" and rhs[row] == 1 for row, sense in senses.items())
    assert set(dominated) <= set(columns)
    for target, replacements in dominated.items():
        assert replacements
        assert len(replacements) == len(set(replacements))
        assert all(variable in columns for variable in replacements)
        replacement_cost = sum(costs[variable] for variable in replacements)
        replacement_cover = set().union(
            *(set(columns[variable]) for variable in replacements)
        )
        assert replacement_cost <= costs[target]
        assert set(columns[target]) <= replacement_cover

    expected_retained = [name for name in columns if name not in dominated]
    assert certificate["original_columns"] == len(columns)
    assert certificate["dominated_columns"] == len(dominated)
    assert certificate["retained_columns"] == len(expected_retained)

    # Link the domination certificate to the exact reduced MPS used by the
    # branch-and-bound proof, rather than trusting a separately supplied file.
    assert reduced_senses == senses
    assert reduced_rhs == rhs
    assert list(reduced_columns) == expected_retained
    for name in expected_retained:
        assert reduced_costs[name] == costs[name]
        assert reduced_columns[name] == columns[name]

    report = {
        "verified": True,
        "original_columns": len(columns),
        "dominated_columns": len(dominated),
        "retained_columns": len(expected_retained),
        "reduced_model_matches_retained_original_columns": True,
    }
    if args.output:
        args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
