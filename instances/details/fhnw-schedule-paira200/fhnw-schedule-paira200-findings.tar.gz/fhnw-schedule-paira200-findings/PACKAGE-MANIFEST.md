# Package manifest: fhnw-schedule-paira200

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 24
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/independent-proof-rerun.json`
- `artifacts/original-solution-audit.json`
- `artifacts/paira-energy-proof.json`
- `artifacts/paira-energy-proof.mps.gz`
- `artifacts/paira-pairb-data-crosscheck.json`
- `artifacts/semantic-audit.json`
- `artifacts/structure.json`
- `artifacts/summary.json`
- `experiments/independent-proof-rerun.log`
- `experiments/original-baseline.json`
- `experiments/original-baseline.log`
- `experiments/paira-energy-proof.log`
- `input/SHA256SUMS`
- `input/fhnw-schedule-paira200-public.sol.gz`
- `reports/deep-study-2026-09-08.zh.md`
- `scripts/audit_original_solution.py`
- `scripts/inspect_structure.py`
- `scripts/paira_common.py`
- `scripts/paira_energy_solver.py`
- `scripts/rerun_proof.py`
- `scripts/run_original_baseline.py`
- `scripts/semantic_audit.py`
- `solutions/global-optimal.sol`

## Excluded files

- `input/fhnw-schedule-paira200.mps.gz (720605 bytes; raw benchmark input; sha256 7885f1890b486001d9ce113c02de48c12c54bb6bcd22b10db985cf74208e13d2)`
