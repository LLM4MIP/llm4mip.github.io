# fhnw-schedule-paira200 — solver-verified OPT = -19.369961204645204

2026-09-14 independent dual-bound review: [adopted bound, proof chain, checks, and limitations](../../docs/dual-bound-audit-2026-09-14/cases/fhnw-schedule-paira200.zh.md). Reviewed lower bound: **-19.36996120464520581**. Use this exact certified decimal; superseded floating-point headline digits below are historical. This review distinguishes exact, literature, and numerical evidence; historical statements below remain dated records.

Official MIPLIB page: <https://miplib.zib.de/instance_details_fhnw-schedule-paira200.html>

## Result

```text
MIPLIB primal       -19.2298568218154
new strict optimum  -19.369961204645204
improvement           0.140104382829804
selected jobs        30
```

The result is a **solver-verified global conclusion**, not a DRAT/LRAT or
exact-rational proof. The official Pair-A MPS plus globally valid structural
inequalities is solved to identical primal and dual bounds in two independent
runs; the final solution is also checked directly against every row of the
untouched official MPS.

## Structure and proof

The model contains 20,300 variables and 40,000 rows: 200 selection binaries,
200 continuous start times and 19,900 pair-order binaries. Fifty-four jobs are
fixed to zero and 146 are eligible. Pair-A and Pair-B independently recover the
same releases, processing times and completion deadlines, up to the last-bit
decimal effects recorded in the cross-check.

The proof model adds 708 nonredundant pair conflicts and 1,500 interval-energy
inequalities. The first run closes in 10.521 seconds and one node. A one-thread
reread with Seed 71, different cut settings and heuristics disabled closes in
47.725 seconds and 1,232 nodes at the same objective and bound. By contrast,
the unstrengthened original model still has bound `-53.63840367317024` after
120 seconds even when loaded with the optimal witness.

The semantic audit finds no changed original row, invalid added row or
unexplained extra row. Direct Decimal evaluation of the final solution gives
objective `-19.3699612046452061500`, zero bound and integrality violation,
maximum original-row violation `2.842e-14`, and no violation above `1e-9`.

## Evidence and reproduction

- [`summary.json`](artifacts/summary.json) gives the result and hashes.
- [`paira-energy-proof.mps.gz`](artifacts/paira-energy-proof.mps.gz) is the
  frozen proof model.
- [`semantic-audit.json`](artifacts/semantic-audit.json) and
  [`original-solution-audit.json`](artifacts/original-solution-audit.json)
  record the independent checks.
- [`independent-proof-rerun.json`](artifacts/independent-proof-rerun.json)
  records the second solver path.
- [`global-optimal.sol`](solutions/global-optimal.sol) is the final witness.
- [`deep-study-2026-09-08.zh.md`](reports/deep-study-2026-09-08.zh.md) is the
  detailed Chinese report.

The scripts require Gurobi. A fresh proof-model build may use the archived
optimal solution as the MIP start:

```sh
python scripts/paira_energy_solver.py \
  input/fhnw-schedule-paira200.mps.gz \
  solutions/global-optimal.sol /tmp/paira200-proof

python scripts/semantic_audit.py \
  input/fhnw-schedule-paira200.mps.gz \
  artifacts/paira-energy-proof.mps.gz \
  artifacts/paira-energy-proof.json /tmp/paira200-semantic-audit.json
```

Hashes of the official input, proof model and final witness are in
[`input/SHA256SUMS`](input/SHA256SUMS).
