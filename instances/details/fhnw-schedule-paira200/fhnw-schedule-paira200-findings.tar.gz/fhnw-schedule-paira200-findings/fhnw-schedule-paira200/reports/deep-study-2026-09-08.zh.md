#  fhnw-schedule-paira200: reporting conflict constraint and energy constraint proof between

Date of release: 2026 -09 -08

## Conclusion

This experiment restored the scheduling semantics on the unmodified official Pair A MPS, adding two classes of inequalities that are effective only for the original integer feasible solution, and Gurobi independently obtained the same globally optimal value twice:

```text
New optimum -19.369961204645204
MIPLIB current public primal -19.2298568218154
0.140104382829804 was improved
```

First run at root node closure; after preserving proof MPS, re-read solve using different seed, single thread, and different solve parameters, and also get the same primal, dual, and zero gap. It should therefore be expressed as **solver-verified global optimum**. This is not DRAT/LRAT or a rational formalised proof certificate.

##  1. Gurobi Structure Reading and Semantic Recovery

The original model included:

-  20,300 variable: 20,100 is a binary variable and 200 is a continuous variable;
-  40,000 article constraint, 119,746 nonzero entries;
-  Formerly 200 a binary variable `z_i` is an operational choice variable;
-  The next 200 continuous variable `s_i` is the start time;
-  The remainder of the 19,900 binary variable corresponds to the previous order of the `C(200,2)` operating pair.

For each `i<j`, the original MPS had two non-overlapping constraints:

```text
s_i - s_j - 200 y_ij <= -p_i
-s_i + s_j + 200 y_ij <= 200-p_j
```

All variable support, coefficients, and right-end elements of the 39,800 bar pair rows are verified in this semantic step-by-step, with 0 as the number of failures.

The lower bound gives the release time `r_i` for each task. 146 has an activation row:

```text
200 z_i + s_i <= 200 + latest_start_i
```

Therefore, when `z_i=1` is completed, `s_i<=latest_start_i` must be met; the actual completion deadline is

```text
d_i = latest_start_i + p_i
```

rather than treating `latest_start_i` directly as the deadline. The recovered completion deadlines of all 146 optional jobs are approximately 1 (numerical error at most `1.42e-14`). A further 54 jobs are fixed directly to `z_i=0` by singleton rows.

The recovery processing time ranges from `0.0005362652184326902` to `0.8985983014865992`, with the total processing time being `48.32872394118571`. For 146 optional operations, Pair A and Pair B independently restored release time complete, with the maximum processing time being `1.11e-16` and the maximum deadline being `1.42e-14`.

##  2. Added a valid inequality

###  2.1 Definition of the pair-conflict constraint

For two optional functions `i,j`, check whether `i` can meet release time, processing time and completion deadline respectively before `j` and before `j` before `i`.

```text
z_i + z_j <= 1
```

In Pair A, the non-recursive conflict constraint of 708 was added. The Pair B experiment reported 4,368; the difference from the previous one excluding the 54, which had been fixed to 0 by the original MPS, is that the conflict constraint itself is redundant.

###  2.2 Distance energy constraint

For interval `[a,b]`, the minimum processing volume of job `i` that must fall inside it under any schedule is:

```text
e_i(a,b) = max(0,
               p_i - max(0,a-r_i) - max(0,d_i-b))
```

The unit has only the capacity of `b-a` in this range, so all the original problems are satisfied by the integer feasible solution:

```text
sum_i e_i(a,b) z_i <= b-a
```

The release/deadline endpoint of a 146 optional function generates a 23,158 candidate region, and on the LP solution selects the strongest violating inequality of the 1,500 clause. To avoid floating-point interference in deleting the boundary feasible solution, loosen the right end of the `1e-11` when writing the model.

## 3 . globally optimal closure

The enhanced Pair A model includes:

-  the original 40,000 constraint;
-  708 is not a redundant pair-conflict constraint;
-  1,500 article energetic constraint;
-  Added 42,208 article constraint, 338,015 nonzero entries.

The complete 20,300 variable feasible solution is loaded as a MIP start. First run using the 2 thread, seed 23, `MIPFocus=3`, `Cuts=3`:

```text
status     OPTIMAL
primal     -19.369961204645204
dual       -19.369961204645204
gap        0
nodes      1
runtime    10.521 s
```

Then save the enhanced model to `paira-energy-proof.mps.gz`, use single threads, seed 71, `MIPFocus=2`, `Cuts=2`, close the heuristic and re-read solve:

```text
status     OPTIMAL
primal     -19.369961204645204
dual       -19.369961204645204
gap        0
nodes      1232
runtime    47.725 s
```

Different algorithm paths get the same closure result.

##  4. Why effective inequalities are key

After sending the same complete optimal solution to the original Pair A MPS without enhancement, Gurobi stays at the root node after 120 seconds:

```text
status     TIME_LIMIT
primal     -19.369961204645204
dual       -53.63840367317024
gap        176.9154%
nodes      1
```

So the difficulty is not to find the feasible solution, but the LP relaxation of the original pairwise big-M formulation is too weak.

##  5. Independent audit

###  5.1 Proof model Semantic audit

-  In the proof MPS, the original 40,000 row by row comparison, support, coefficients, senses, and RHS differences with the official MPS are 0;
-  708 article conflict constraint Re-checking sequence by sequence for both sequences is impossible and the error number is 0;
-  1,500 bar energy constraint Recalculate support, coefficients and RHS in independent formulas, the difference being 0;
-  proof MPS does not contain any other non-explanatory add-ons;
-  The results of the semantic audit: `semantic_audit_passed = true`.

###  5.2 Optimal solution Replacing the original Pair A

The final 20,300 variable value is directly returned to the unenhanced official Pair A MPS and the entire 40,000 line is checked in a high-precision decimal aggregate:

```text
Objective value (decimal weighting) -19.3699612046452061500
Select the number of jobs 30
Maximum variable bound violation 0
Maximum integrality violation of the 0
The maximum original constraint violates the 2.842170943040401e-14
0 violates the constraints that exceed 1e-9
Maximum selected deadline for violation of 4.884981308350689e-15
Maximum selected overlap 1.6653345369377348e-16
```

The strict `1e-9` tolerance audit was passed.

##  6. Files with hash

Key evidence:

-  [`../artifacts/structure.json` ](../artifacts/structure.json): semantic audit of the original structure and the 39,800 article pair rows;
-  [`../artifacts/paira-energy-proof.mps.gz` ](../artifacts/paira-energy-proof.mps.gz): after enhanced proof MPS;
-  [`../experiments/paira-energy-proof.log` ](../experiments/paira-energy-proof.log): first closure log;
-  `../artifacts/paira-energy-proof.json` ](../artifacts/paira-energy-proof.json): First closure result with full energy range;
-  `../solutions/global-optimal.sol` ](../solutions/global-optimal.sol): the complete optimal solution;
-  [`../artifacts/semantic-audit.json` ](../artifacts/semantic-audit.json): validly unequal with the original linear semantic audit;
-  [`../artifacts/original-solution-audit.json` ](../artifacts/original-solution-audit.json): final solution independent audit on the original MPS;
-  `../artifacts/independent-proof-rerun.json` ](../artifacts/independent-proof-rerun.json): single thread with different parameters;
-  [`../experiments/original-baseline.json` ](../experiments/original-baseline.json): 120 second controls without enhanced models.]

SHA-256：

```text
Official Pair A MPS   7885f1890b486001d9ce113c02de48c12c54bb6bcd22b10db985cf74208e13d2
proof MPS         d39f95aa9d5a0a31bc9cd7f788a39477df78e21193b2801cfe8f82d8d4a2f202
The final solution is b89dba78c1bb4b8c8df54d7dcc787ac6e03919f0b46e1c958cea61ac3753e630.
```

##  7. Accurate external expression

It can be expressed as:

>  For `fhnw-schedule-paira200`, after adding the conflict constraint and the interval energy effectively unequal to the conflict constraint from the official MPS recovery unit, Gurobi is given `primal=dual=-19.369961204645204` twice independently. The final solution on the unmodified original Pair A MPS is through full constraint, boundary and integrality checks, thus achieving solver-verified global optimum.

It must not be stated that a 120-second original-model run alone proved optimality: that run ended at `TIME_LIMIT`. This is also not an independent formal certificate, since it still relies on Gurobi's branch-and-cut proof for the strengthened MIP.

## References

- MIPLIB instance page: https://miplib.zib.de/instance_details_fhnw-schedule-paira200.html
-  MIPLIB describes the instance as a continuous time project selection/scheduling problem with a value, deadline and earliest start date, and explains that Pair A, Pair B, Slot are three formulations of the same problem.
