from __future__ import annotations

import argparse
import json
import math
from decimal import Decimal, getcontext
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB

from paira_common import N_JOBS, read_solution, recover_paira_data, sha256


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("original", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    getcontext().prec = 50

    model = gp.read(str(args.original))
    variables = model.getVars()
    data = recover_paira_data(model)
    sparse = read_solution(args.solution)
    values = [sparse.get(variable.VarName, 0.0) for variable in variables]
    decimal_values = [Decimal(str(value)) for value in values]

    max_bound = max_integer = max_row = 0.0
    violations_over = 0
    worst_rows = []
    for variable, value in zip(variables, values):
        max_bound = max(max_bound, variable.LB - value, value - variable.UB, 0.0)
        if variable.VType in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT):
            max_integer = max(max_integer, abs(value - round(value)))
    for constraint in model.getConstrs():
        row = model.getRow(constraint)
        activity_decimal = sum(
            (Decimal(str(row.getCoeff(k))) * decimal_values[row.getVar(k).index] for k in range(row.size())),
            Decimal(0),
        )
        activity = float(activity_decimal)
        rhs = constraint.RHS
        if constraint.Sense == GRB.LESS_EQUAL:
            violation = max(activity - rhs, 0.0)
        elif constraint.Sense == GRB.GREATER_EQUAL:
            violation = max(rhs - activity, 0.0)
        else:
            violation = abs(activity - rhs)
        max_row = max(max_row, violation)
        violations_over += int(violation > 1e-9)
        if violation > 0.0:
            worst_rows.append((violation, constraint.ConstrName, activity, constraint.Sense, rhs))

    objective_decimal = Decimal(str(model.ObjCon)) + sum(
        (Decimal(str(variable.Obj)) * decimal_values[variable.index] for variable in variables),
        Decimal(0),
    )
    selected = [i for i in range(N_JOBS) if values[i] > 0.5]
    selected_by_start = sorted(selected, key=lambda i: (values[N_JOBS + i], i))
    max_release_violation = max(
        (data.releases[i] - values[N_JOBS + i] for i in selected), default=0.0
    )
    max_deadline_violation = max(
        (
            values[N_JOBS + i] + data.durations[i] - data.deadlines[i]
            for i in selected
            if data.deadlines[i] is not None
        ),
        default=0.0,
    )
    max_selected_overlap = 0.0
    for left, right in zip(selected_by_start, selected_by_start[1:]):
        max_selected_overlap = max(
            max_selected_overlap,
            values[N_JOBS + left] + data.durations[left] - values[N_JOBS + right],
        )

    passed = max(max_bound, max_integer, max_row) <= 1e-9
    report = {
        "instance": "fhnw-schedule-paira200",
        "original_sha256": sha256(args.original),
        "solution_sha256": sha256(args.solution),
        "solution_values_explicit": len(sparse),
        "solution_values_implicit_zero": model.NumVars - len(sparse),
        "objective_decimal": str(objective_decimal),
        "objective_float": float(objective_decimal),
        "selected_jobs": len(selected),
        "selected_job_indices": selected,
        "max_bound_violation": max_bound,
        "max_integrality_violation": max_integer,
        "max_original_row_violation": max_row,
        "original_row_violations_over_1e_9": violations_over,
        "max_selected_release_violation": max(0.0, max_release_violation),
        "max_selected_deadline_violation": max(0.0, max_deadline_violation),
        "max_selected_pair_overlap": max(0.0, max_selected_overlap),
        "worst_rows": sorted(worst_rows, reverse=True)[:20],
        "strictly_feasible_1e_9": passed,
    }
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))
    if not passed:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
