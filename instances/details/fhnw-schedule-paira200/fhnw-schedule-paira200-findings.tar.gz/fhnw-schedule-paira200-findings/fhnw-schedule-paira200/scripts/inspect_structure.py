from __future__ import annotations

import argparse
import json
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB

from paira_common import BIG_M, N_JOBS, PAIR_COUNT, PAIR_ROWS, pair_offset, recover_paira_data, row_coefficients, sha256


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    model = gp.read(str(args.mps))
    variables = model.getVars()
    constraints = model.getConstrs()
    data = recover_paira_data(model)

    pair_failures = []
    max_rhs_error = 0.0
    for i in range(N_JOBS):
        for j in range(i + 1, N_JOBS):
            off = pair_offset(i, j)
            order = 2 * N_JOBS + off
            expected = [
                ({N_JOBS + i: 1.0, N_JOBS + j: -1.0, order: -BIG_M}, GRB.LESS_EQUAL, -data.durations[i]),
                ({N_JOBS + i: -1.0, N_JOBS + j: 1.0, order: BIG_M}, GRB.LESS_EQUAL, BIG_M - data.durations[j]),
            ]
            for local, (want_coeff, want_sense, want_rhs) in enumerate(expected):
                row = constraints[2 * off + local]
                if row_coefficients(model, row) != want_coeff or row.Sense != want_sense:
                    pair_failures.append(row.ConstrName)
                max_rhs_error = max(max_rhs_error, abs(row.RHS - want_rhs))

    selectable = [i for i in range(N_JOBS) if i not in set(data.forced_zero)]
    report = {
        "instance": "fhnw-schedule-paira200",
        "input": str(args.mps.resolve()),
        "input_sha256": sha256(args.mps),
        "model": {
            "variables": model.NumVars,
            "constraints": model.NumConstrs,
            "nonzeros": model.NumNZs,
            "binary_variables": sum(v.VType == GRB.BINARY for v in variables),
            "continuous_variables": sum(v.VType == GRB.CONTINUOUS for v in variables),
            "minimize": model.ModelSense == GRB.MINIMIZE,
            "objective_nonzeros": sum(abs(v.Obj) > 0.0 for v in variables),
        },
        "recovered": {
            "jobs": N_JOBS,
            "pair_order_variables": PAIR_COUNT,
            "pair_rows": PAIR_ROWS,
            "selectable_jobs": len(selectable),
            "forced_zero_jobs": len(data.forced_zero),
            "forced_zero_indices": data.forced_zero,
            "release_min": min(data.releases),
            "release_max": max(data.releases),
            "duration_min": min(data.durations),
            "duration_max": max(data.durations),
            "duration_sum": sum(data.durations),
            "deadline_min_selectable": min(data.deadlines[i] for i in selectable),
            "deadline_max_selectable": max(data.deadlines[i] for i in selectable),
        },
        "pair_semantic_rows_checked": PAIR_ROWS,
        "pair_semantic_failures": len(pair_failures),
        "first_pair_failures": pair_failures[:20],
        "pair_max_rhs_error": max_rhs_error,
        "structure_audit_passed": not pair_failures and max_rhs_error <= 1e-12,
        "formulation": "optional single-machine scheduling; every job has a start time and global pairwise order, while z_i=1 activates its latest-start/deadline requirement",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
