#!/usr/bin/env python3
"""Decimal-arithmetic feasibility and algebra audit for supportcase39."""

from __future__ import annotations

import gzip
import json
import sys
from collections import defaultdict
from decimal import Decimal, getcontext
from pathlib import Path


getcontext().prec = 80


def open_text(path: Path):
    return gzip.open(path, "rt", encoding="latin-1") if path.suffix == ".gz" else open(path, "rt", encoding="latin-1")


def main() -> None:
    model, solution = map(Path, sys.argv[1:3])
    values: dict[str, Decimal] = defaultdict(Decimal)
    with open_text(solution) as fh:
        for line in fh:
            fields = line.split()
            if len(fields) == 2 and fields[0].startswith("x"):
                values[fields[0]] = Decimal(fields[1])

    section = None
    row_lhs: dict[str, Decimal] = defaultdict(Decimal)
    rhs: dict[str, Decimal] = defaultdict(Decimal)
    objective = Decimal(0)
    column_sums: dict[str, Decimal] = defaultdict(Decimal)
    objective_coefs: dict[str, Decimal] = defaultdict(Decimal)
    lower: dict[str, Decimal] = defaultdict(Decimal)
    upper: dict[str, Decimal] = defaultdict(lambda: Decimal("Infinity"))
    with open_text(model) as fh:
        for raw in fh:
            fields = raw.split()
            if not fields or fields[0].startswith("*"):
                continue
            if fields[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "BOUNDS", "ENDATA"}:
                section = fields[0]
                continue
            if section == "COLUMNS":
                if len(fields) >= 3 and fields[1].strip("'") == "MARKER":
                    continue
                var = fields[0]
                for k in range(1, len(fields), 2):
                    row, coef = fields[k], Decimal(fields[k + 1])
                    if row == "obj":
                        objective_coefs[var] += coef
                        objective += coef * values[var]
                    else:
                        row_lhs[row] += coef * values[var]
                        column_sums[var] += coef
            elif section == "RHS":
                for k in range(1, len(fields), 2):
                    rhs[fields[k]] += Decimal(fields[k + 1])
            elif section == "BOUNDS":
                kind, _bound_name, var = fields[:3]
                value = Decimal(fields[3]) if len(fields) == 4 else None
                if kind == "UP":
                    upper[var] = value
                elif kind == "LO":
                    lower[var] = value
                elif kind == "FX":
                    lower[var] = upper[var] = value

    slacks = [row_lhs[f"c{i}"] - rhs[f"c{i}"] for i in range(1, 16385)]
    vars_ = [f"x{i}" for i in range(1, 1026)]
    payload = {
        "objective_decimal": str(objective),
        "minimum_constraint_slack_decimal": str(min(slacks)),
        "constraint_violations": sum(s < 0 for s in slacks),
        "bound_violations": sum(not (lower[v] <= values[v] <= upper[v]) for v in vars_),
        "integrality_violations_x1_x1024": sum(values[v] != values[v].to_integral_value() for v in vars_[:-1]),
        "sum_constraint_slacks_decimal": str(sum(slacks)),
        "objective_plus_sum_slacks_decimal": str(objective + sum(slacks)),
        "max_abs_objective_plus_column_sum_decimal": str(
            max(abs(objective_coefs[v] + column_sums[v]) for v in vars_[:-1])
        ),
        "sum_rhs_decimal": str(sum(rhs.values())),
    }
    print(json.dumps(payload, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
