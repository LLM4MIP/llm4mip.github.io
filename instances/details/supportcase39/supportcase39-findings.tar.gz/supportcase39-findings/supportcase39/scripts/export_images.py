#!/usr/bin/env python3
"""Export the hidden supportcase39 grids as portable graymaps.

This is an audit/visualization helper, not a solver.  It uses the row order for
the 128x128 observation grid and identifies each 32x32 control's position by
the location of its largest-magnitude Gaussian coefficient.
"""

from __future__ import annotations

import gzip
import sys
from pathlib import Path

from supportcase39_reconstruct import parse_mps


def write_pgm(path: Path, width: int, height: int, pixels: list[int]) -> None:
    if len(pixels) != width * height:
        raise ValueError("wrong pixel count")
    path.write_bytes(
        f"P5\n{width} {height}\n255\n".encode("ascii") + bytes(pixels)
    )


def read_solution(path: Path) -> dict[str, int]:
    opener = gzip.open if path.suffix == ".gz" else open
    values: dict[str, int] = {}
    with opener(path, "rt", encoding="utf-8") as fh:
        for line in fh:
            fields = line.split()
            if len(fields) == 2 and fields[0].startswith("x"):
                values[fields[0]] = round(float(fields[1]))
    return values


def main() -> None:
    model, solution, output_dir = map(Path, sys.argv[1:4])
    output_dir.mkdir(parents=True, exist_ok=True)
    _row_type, columns, rhs, _bounds = parse_mps(model)
    sol = read_solution(solution)

    target = [255 if rhs[f"c{i}"] == 30 else 0 for i in range(1, 16385)]
    write_pgm(output_dir / "supportcase39_target_128x128.pgm", 128, 128, target)

    controls = [0] * 1024
    control_by_var: dict[str, tuple[int, int]] = {}
    for i in range(1, 1025):
        var = f"x{i}"
        row, _coef = max(
            ((int(r[1:]) - 1, abs(a)) for r, a in columns[var].items() if r != "obj"),
            key=lambda t: t[1],
        )
        y, x = divmod(row, 128)
        if y % 4 or x % 4:
            raise ValueError(f"unexpected control center {(y, x)}")
        controls[(y // 4) * 32 + x // 4] = sol.get(var, 0)
        control_by_var[var] = (y, x)
    write_pgm(output_dir / "supportcase39_incumbent_controls_32x32.pgm", 32, 32, controls)

    blurred = [0.0] * 16384
    for i in range(1, 1025):
        var = f"x{i}"
        value = sol.get(var, 0)
        for row, coef in columns[var].items():
            if row != "obj":
                # Remove the target-label sign to recover the nonnegative blur.
                blurred[int(row[1:]) - 1] += value * abs(coef)
    write_pgm(
        output_dir / "supportcase39_incumbent_blurred_128x128.pgm",
        128,
        128,
        [min(255, max(0, round(z))) for z in blurred],
    )


if __name__ == "__main__":
    main()
