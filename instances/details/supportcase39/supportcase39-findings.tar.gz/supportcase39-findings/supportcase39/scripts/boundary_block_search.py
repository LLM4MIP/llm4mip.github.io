#!/usr/bin/env python3
"""Sliding geometric block search for the supportcase39 projector mask.

All controls outside one small 2-D window are fixed to the incumbent.  The
commercial solver is therefore used only as an exact oracle for a deliberately
constructed local neighborhood, not as a parameter-tuned full-model run.
"""

from __future__ import annotations

import argparse
import gzip
import json
import time
from collections import defaultdict
from decimal import Decimal, getcontext
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


getcontext().prec = 60


def open_text(path: Path):
    return gzip.open(path, "rt", encoding="latin-1") if path.suffix == ".gz" else path.open("rt", encoding="latin-1")


def read_solution(path: Path):
    values = defaultdict(Decimal)
    with open_text(path) as fh:
        for raw in fh:
            f = raw.split()
            if len(f) == 2 and f[0].startswith("x"):
                values[f[0]] = Decimal(f[1])
    return values


def exact_data(path: Path):
    section = None
    rhs = defaultdict(Decimal)
    obj = defaultdict(Decimal)
    columns = defaultdict(dict)
    with open_text(path) as fh:
        for raw in fh:
            f = raw.split()
            if not f or f[0].startswith("*"):
                continue
            if f[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "BOUNDS", "ENDATA"}:
                section = f[0]
                continue
            if section == "COLUMNS":
                if len(f) >= 3 and f[1].strip("'") == "MARKER":
                    continue
                for k in range(1, len(f), 2):
                    coef = Decimal(f[k + 1])
                    if f[k] == "obj":
                        obj[f[0]] += coef
                    else:
                        columns[f[0]][f[k]] = coef
            elif section == "RHS":
                for k in range(1, len(f), 2):
                    rhs[f[k]] += Decimal(f[k + 1])
    return rhs, obj, columns


def exact_validate(values, rhs, obj, columns):
    lhs = defaultdict(Decimal)
    objective = Decimal(0)
    for var, value in values.items():
        objective += obj[var] * value
        for row, coef in columns[var].items():
            lhs[row] += coef * value
    slacks = [lhs[row] - value for row, value in rhs.items()]
    return objective, min(slacks), sum(s < 0 for s in slacks)


def write_solution(path: Path, values, objective):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="ascii", newline="\n") as fh:
        fh.write(f"=obj= {objective}\n# Exact-validated geometric block-search solution\n")
        for i in range(1, 1026):
            fh.write(f"x{i} {values[f'x{i}']}\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("model", type=Path)
    ap.add_argument("start", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--block", type=int, default=5)
    ap.add_argument("--per-block-seconds", type=float, default=2.0)
    ap.add_argument("--total-seconds", type=float, default=300.0)
    ap.add_argument("--max-blocks", type=int, default=250)
    ap.add_argument("--summary", type=Path)
    args = ap.parse_args()

    values = read_solution(args.start)
    rhs, obj_exact, columns_exact = exact_data(args.model)
    incumbent_exact, slack, violations = exact_validate(values, rhs, obj_exact, columns_exact)
    if violations:
        raise AssertionError("infeasible start")

    model = gp.read(str(args.model))
    variables = {v.VarName: v for v in model.getVars()}
    # Recover the 32x32 projector coordinates from the Gaussian peak row.
    coords = {}
    for i in range(1, 1025):
        name = f"x{i}"
        peak_row = max(columns_exact[name], key=lambda r: abs(columns_exact[name][r]))
        p = int(peak_row[1:]) - 1
        coords[name] = (p // 128 // 4, p % 128 // 4)
    grid_var = {coord: name for name, coord in coords.items()}
    if len(grid_var) != 1024:
        raise AssertionError("coordinate reconstruction is not one-to-one")

    half = args.block // 2
    centers = [coords[f"x{i}"] for i in range(1, 1025) if 0 < values[f"x{i}"] < 255]
    windows = []
    seen = set()
    for r, c in centers:
        r0 = min(max(r - half, 0), 32 - args.block)
        c0 = min(max(c - half, 0), 32 - args.block)
        key = (r0, c0)
        if key not in seen:
            seen.add(key)
            windows.append(key)
    # Prioritize windows with the most nonsaturated controls.
    windows.sort(
        key=lambda rc: -sum(
            0 < values[grid_var[(r, c)]] < 255
            for r in range(rc[0], rc[0] + args.block)
            for c in range(rc[1], rc[1] + args.block)
        )
    )
    windows = windows[: args.max_blocks]

    model.Params.OutputFlag = 0
    model.Params.Threads = 1
    model.Params.TimeLimit = args.per_block_seconds
    model.Params.MIPGap = 0
    history = []
    started = time.monotonic()
    for number, (r0, c0) in enumerate(windows, 1):
        if time.monotonic() - started >= args.total_seconds:
            break
        free = {
            grid_var[(r, c)]
            for r in range(r0, r0 + args.block)
            for c in range(c0, c0 + args.block)
        }
        for i in range(1, 1025):
            name = f"x{i}"
            var = variables[name]
            if name in free:
                var.LB, var.UB = 0, 255
            else:
                fixed = float(values[name])
                var.LB = var.UB = fixed
            var.Start = float(values[name])
        model.reset(0)
        model.optimize()
        record = {
            "number": number,
            "window": [r0, c0, args.block, args.block],
            "status": int(model.Status),
            "runtime": model.Runtime,
            "node_count": model.NodeCount,
        }
        if model.SolCount:
            candidate = dict(values)
            for name in free:
                candidate[name] = Decimal(round(variables[name].X))
            candidate_exact, candidate_slack, candidate_violations = exact_validate(
                candidate, rhs, obj_exact, columns_exact
            )
            record.update({
                "candidate_objective": str(candidate_exact),
                "candidate_min_slack": str(candidate_slack),
                "candidate_violations": candidate_violations,
            })
            if candidate_violations == 0 and candidate_exact < incumbent_exact:
                record["accepted_improvement"] = str(incumbent_exact - candidate_exact)
                values = candidate
                incumbent_exact = candidate_exact
        history.append(record)
        if number % 25 == 0:
            print(f"blocks={number} objective={incumbent_exact} elapsed={time.monotonic()-started:.2f}")

    final_objective, final_slack, final_violations = exact_validate(values, rhs, obj_exact, columns_exact)
    write_solution(args.output, values, final_objective)
    summary = {
        "algorithm": "sliding geometric block search with outside controls fixed",
        "block_size": args.block,
        "candidate_windows": len(windows),
        "processed_windows": len(history),
        "optimal_subproblems": sum(h["status"] == GRB.OPTIMAL for h in history),
        "improving_windows": sum("accepted_improvement" in h for h in history),
        "initial_objective": str(exact_validate(read_solution(args.start), rhs, obj_exact, columns_exact)[0]),
        "final_objective": str(final_objective),
        "final_min_slack": str(final_slack),
        "final_violations": final_violations,
        "solver_seconds_sum": sum(h["runtime"] for h in history),
        "wall_seconds": time.monotonic() - started,
        "history": history,
    }
    destination = args.summary or args.output.with_suffix(".json")
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in summary.items() if k != "history"}, indent=2))


if __name__ == "__main__":
    main()
