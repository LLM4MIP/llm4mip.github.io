# Package manifest: supportcase39

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 21
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/block11-pass2.json`
- `artifacts/block11-search.json`
- `artifacts/block13-search.json`
- `artifacts/block5-search.json`
- `artifacts/block7-search.json`
- `artifacts/block9-search.json`
- `artifacts/pair-exchange-official.json`
- `artifacts/supportcase39_incumbent_blurred_128x128.png`
- `artifacts/supportcase39_incumbent_controls_32x32.png`
- `artifacts/supportcase39_target_128x128.png`
- `logs/gurobi-root-10s.log`
- `reports/structural-investigation.md`
- `scripts/boundary_block_search.py`
- `scripts/exact_validate.py`
- `scripts/export_images.py`
- `scripts/integer_coordinate_descent.py`
- `scripts/pair_exchange_search.py`
- `scripts/reconstruct.py`
- `solutions/improved-1085083.856820570460.sol`
- `solutions/official.sol.gz`

## Excluded files

- `input/supportcase39.mps.gz (2139789 bytes; raw benchmark input; sha256 f81ed6f54424a444aa176045b4dcf921f100d696f9d995fba7a2cca9279af406)`
