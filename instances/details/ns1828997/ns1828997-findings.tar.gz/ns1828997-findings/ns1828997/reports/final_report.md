# `ns1828997`: direct structural investigation

## Result

The original MIPLIB incumbent of **8 is independently validated**, but this
investigation does **not** yet provide a checkable lower-bound certificate of
8. Therefore the rigorous status remains **open**, with validated primal upper
bound 8.

No generic MIP optimization was used. The main exact attempt was an algebraic
compression followed by a weighted PB/SAT decision model for objective at most
7. A bare SAT-solver result is not treated as a proof unless a proof trace is
obtained and independently checked.

## Authoritative background

The official MIPLIB page is
https://miplib.zib.de/instance_details_ns1828997.html. It labels the instance
open, reports a best value of 8, and identifies it as an unknown NEOS
pseudo-application imported from MIPLIB 2010. The page credits one value-8
solution to Local-MIP and another to COPT 6.5.

The Local-MIP method is described by Lin et al., "New Characterizations and
Efficient Local Search for General Integer Linear Programming,"
https://arxiv.org/abs/2305.00188, with source at
https://github.com/shaowei-cai-group/Local-MIP. These sources motivate the
association-aware primal route; no instance-specific claim was accepted from
them without checking the original MPS.

## Original-MPS audit

Gurobi 13.0.2 read the official MPS without calling `optimize()` or
`presolve()`. The exact dimensions are 27,275 binary variables, 81,725 rows,
and 190,670 nonzeros. Every matrix coefficient is +1 or -1. The five exact row
templates are:

| Count | Algebraic role |
|---:|---|
| 15 | 25-term equality with right-hand side 5 |
| 375 | two-variable implication `x <= z` |
| 710 | core packing exclusion `x_a + x_b <= 1` |
| 26,875 | lower half of product linearization `x_a+x_b-y <= 1` |
| 53,750 | two upper halves `y <= x_a`, `y <= x_b` |

The official Local-MIP solution ID4 contains exact integer values. With omitted
entries interpreted as zero, it has zero bound, integrality, and row violation
on all original rows; its recomputed objective is exactly 8. The official COPT
solution ID5 also recomputes to `7.99999999999967`; its largest printed-value
row residual is `5.70e-13`, far below `1e-9`.

## Exact compression

The 15 cardinality rows partition 375 core variables into 15 blocks of 25 and
require exactly five selections in each block. The remaining structure is
recovered algebraically, not from column order:

- 25 zero-cost `z` variables only receive implications `x <= z`; they are
  existentially redundant and may all be set to one. They are not assumed
  equal to `x`.
- 26,875 variables are exact binary products, because each has
  `y >= x_a+x_b-1`, `y <= x_a`, and `y <= x_b`.
- 24,817 product variables have zero objective and can be eliminated.
- The retained 2,058 products have positive integer costs: 588 cost 1, 882
  cost 2, and 588 cost 3. No core or `z` variable has objective cost.

The exporter in `scripts/extract_exact_core.py` fails closed unless every
original row and variable is recognized. Its successful artifact
`artifacts/exact_core.json` is bound to the original MPS SHA-256 and records all
375 core names, 15 groups, 710 conflicts, and 2,058 retained cost products.
This establishes an exact existential projection of the original model.

## Problem interpretation and additional structure

This is a structured quadratic five-label-per-block selection problem. At the
15-block level, 42 soft interaction pairs each have exactly 49 positive product
terms and one constant edge weight. Those terms follow a same/adjacent directed
label pattern on the 25-position line. Eleven further block pairs carry hard
distance exclusions: counts 48, 94, and 138 correspond to forbidding label
distance 1, 1--2, and 1--3, respectively. The union graph has 53 edges, and a
deterministic greedy min-fill elimination gives width at most 7. Small
separator scans on this 15-node graph did not expose a small balanced split.

The exact incumbent chooses 75 core variables, five per block, has no hard
conflict, and its recomputed compact quadratic cost is 8. Full selections and
per-pair costs are recorded in `artifacts/core_pattern_analysis.json`.

## Direct API work

Two stateful `gpt-5.6-sol` segments used 25,271 tokens in total:

1. 9,465 tokens classified the compact problem and ranked PB/SAT cutoff,
   five-subset block search, separator DP, association-aware Local-MIP
   neighborhoods, component lower bounds, and Benders/dual decomposition.
2. 15,806 tokens received actual execution feedback and produced corrected,
   proof-aware exporter and PySAT designs. It explicitly distinguished
   `x<=z` from `z=x`, handled sparse MIPLIB solutions, eliminated zero-cost
   products, and warned that UNSAT without an obtainable trace is not an
   independently checkable certificate.

The first generated audit implementation was deliberately stopped after it
attempted separator enumeration of size up to three on the 375-node conflict
graph. That is an implementation error, not evidence about the instance. It
was corrected to use bounded statistics for that graph and then rerun: all
81,725 rows were recognized, all 27,275 variables received exactly one role,
all 43 product block pairs had 625 products, compact/original objectives both
equaled 8, and every audit flag passed. Exhaustive separator work in the
separate pattern script is restricted to 15 block vertices.

## Exact cutoff experiment

For a minimization problem with integer costs and a feasible solution of value
8, proving optimality is equivalent to proving that objective at most 7 is
infeasible. The cutoff encoding contains:

- sequential exact-five encodings for all 15 blocks;
- 710 hard binary conflict clauses;
- one forced cost literal for each of 2,058 positive products;
- weighted copies totaling 4,116 literals and a sequential at-most-7 counter.

The emitted cutoff-7 CNF has **36,254 variables and 74,512 clauses**. The
product encoding is an exact existential projection for a positive cutoff:
when both endpoints are selected the cost literal is forced true, and otherwise
it can be set false.

The cutoff-7 backend outcomes were kept separate:

- **CaDiCaL195:** approximately 20 minutes of CPU/search were invested. The
  run produced neither a conclusive status file nor a proof trace, so its only
  valid classification is `UNKNOWN`.
- **Kissat:** a subsequent attempt stalled with effectively zero CPU in the
  local backend/runtime layer and was terminated. This is infrastructure
  `UNKNOWN`, not evidence about feasibility.
- **Glucose4:** this backend was used only on the cutoff-8 positive-direction
  check described below; free search timed out after 60.06 seconds and returned
  `UNKNOWN`.

As a positive-direction cross-check, an independently generated cutoff-8 CNF
has 40,355 variables and 82,712 clauses. Free Glucose4 search returned
`UNKNOWN` after 60 seconds. When all 375 core variables were fixed to the
independently audited public incumbent, CaDiCaL195 found the same CNF SAT
immediately. The fixed assignment has all block sums 5, zero packing conflicts,
and recomputed compact cost 8. This confirms that the encoding does not exclude
the known boundary solution; it says nothing about the cutoff-7 lower bound.

Three backend outcomes are kept separate:

- **CaDiCaL195, cutoff 7:** the exact decision run consumed approximately 20
  minutes of CPU/wall time. It produced neither a final SAT/UNSAT record nor a
  proof artifact, so its only admissible outcome is `UNKNOWN`.
- **Glucose4, cutoff 8:** an unconstrained run reached its explicit 60.1-second
  limit and returned `UNKNOWN`. The separate all-core-fixed incumbent check
  with CaDiCaL195 returned SAT immediately.
- **Kissat, cutoff 7:** a follow-up backend process accumulated effectively no
  solver CPU and remained in a wait state. It was terminated as an
  infrastructure stall and is recorded as `UNKNOWN`, not search evidence.

No cutoff backend returned UNSAT, and no proof trace was produced.

## What is and is not established

Established independently:

- original-MPS feasible objective 8;
- exact reduction from 27,275 variables to 375 core selections plus positive
  pair costs;
- exact, hash-bound cutoff-7 CNF semantics;
- the known value-8 core assignment satisfies the cutoff-8 encoding.

Not established:

- UNSAT of the cutoff-7 formula by a retained, independently checked proof;
- a combinatorial lower bound of 8;
- strict optimality of the public incumbent.

All research processes were stopped at closure. The investigation ran from
03:49:08 to 05:16:13 Asia/Shanghai, approximately 87 minutes. Generic MIP
optimization time was zero. Direct API usage was 25,271 total tokens. SAT
runtimes are recorded separately in `../effort_ledger.md`.

## Recommended continuation

The most valuable continuation is proof-producing SAT on the existing
cutoff-7 CNF, followed by DRAT/LRAT verification against the stored hash-bound
formula. A smaller alternative encoding is weighted partial MaxSAT: each
positive product becomes the soft clause `not x_a or not x_b` with its edge
weight, removing all 2,058 product literals and the large PB counter. That route
may locate the optimum or generate useful unsatisfiable cores, but its optimum
status still needs a checkable certificate. A structure-native fallback is a
frontier or tree-decomposition search using the 15-block graph and the observed
label-distance relations, with every pruned branch recorded for replay.
