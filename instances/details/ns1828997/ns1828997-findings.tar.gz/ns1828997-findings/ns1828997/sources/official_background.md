# Official background and sources

Checked on 2026-09-09.

## MIPLIB

- Instance page: https://miplib.zib.de/instance_details_ns1828997.html
- Official original MPS: https://miplib.zib.de/WebData/instances/ns1828997.mps.gz
- Status: open; minimization; best public objective: 8 (exact entry).
- Group/application: `neos-pseudoapplication-13`; unknown pseudo-application
  submitted through NEOS and imported from the MIPLIB 2010 collection.
- Original dimensions reported by MIPLIB: 27,275 binary variables, 81,725
  constraints, and 190,670 nonzeros.
- MIPLIB row classification: 54,125 precedence, 26,875 invariant-knapsack,
  710 variable-bound, and 15 cardinality constraints.
- Public solution history: objectives 20, 16, 9, and two solutions of value 8.
  The value-8 submissions credit Local-MIP and COPT 6.5, respectively.

## Structure-specific algorithm reference

- Shaowei Cai group, Local-MIP source code:
  https://github.com/shaowei-cai-group/Local-MIP
- X. Lin et al., "New Characterizations and Efficient Local Search for
  General Integer Linear Programming," arXiv:2305.00188:
  https://arxiv.org/abs/2305.00188
  - The authors describe Search, Improve, and Restore modes, together with
    tight-move and lift-move operators. The method is primal/local search and
    does not itself provide the missing lower-bound certificate.

The paper and source are relevant because MIPLIB credits Local-MIP with one of
the incumbent-8 submissions. They establish algorithmic background only; all
instance-specific claims and candidate solutions are rechecked locally against
the original MPS.
