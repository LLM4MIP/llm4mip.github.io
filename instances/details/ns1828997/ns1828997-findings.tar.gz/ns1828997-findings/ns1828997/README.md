# `ns1828997`

## Result

Status: **open; incumbent independently validated**.

Both official value-8 solutions were checked against the original MPS. The
Local-MIP solution is exactly feasible at objective **8**; the COPT solution
recomputes to `7.99999999999967` with maximum printed-value residual
`5.70e-13`. This establishes the primal bound `OPT <= 8` (and, from objective
nonnegativity, the trivial interval `0 <= OPT <= 8`). It does **not** establish
a lower bound of 8 or prove optimality.

[MIPLIB instance page](https://miplib.zib.de/instance_details_ns1828997.html)

## Exact reduction and attempted proof

Read-only Gurobi parsing recovered 27,275 binaries and 81,725 rows. An exact,
hash-bound exporter reduces the formulation to 375 core selections arranged
as fifteen blocks of 25, exactly five selections per block, 710 hard conflicts,
and 2,058 positive pair-product costs. The remaining 24,817 product variables
and 25 existentially redundant zero-cost variables can be eliminated.

Proving the value 8 optimal requires showing that the exact cutoff-7 problem is
infeasible. CaDiCaL consumed about 20 minutes without a final status or proof;
Kissat stalled in the local runtime layer. Both outcomes are `UNKNOWN`. A
separate cutoff-8 encoding becomes SAT immediately when fixed to the audited
incumbent, which is an encoding sanity check only.

No generic MIP optimization was used.

## Evidence

- [`artifacts/exact_core.json`](artifacts/exact_core.json) is the exact compact
  projection bound to the original MPS hash.
- [`artifacts/audit_public_id4.json`](artifacts/audit_public_id4.json) and
  [`artifacts/audit_public_id5.json`](artifacts/audit_public_id5.json) validate
  the two incumbents.
- [`artifacts/core_pattern_analysis.json`](artifacts/core_pattern_analysis.json)
  records the recovered 15-block interaction graph.
- [`artifacts/cutoff8_incumbent_validation.json`](artifacts/cutoff8_incumbent_validation.json)
  records the positive-direction CNF check.
- [`reports/final_report.md`](reports/final_report.md) and
  [`logs/reproducibility.md`](logs/reproducibility.md) state all limitations.

The cutoff CNFs are regenerable from the retained exact core and scripts and
are intentionally omitted. No SAT `UNKNOWN` status is presented as a proof.

SHA-256:

- MPS: `FD75A2046132B9A7CDAC326B4FCAF2F953B5F59934EE80B3F120A6082CD1CA90`
- Local-MIP solution: `EAC722C8C90815D902F59AA71392815865DE99E82F345BFA859B90FB8AA14055`
- COPT solution: `0F95BB2CE3CFF78E2BE6666677BE34AAB98C6AF072CA2F8CC534E2412D369075`
