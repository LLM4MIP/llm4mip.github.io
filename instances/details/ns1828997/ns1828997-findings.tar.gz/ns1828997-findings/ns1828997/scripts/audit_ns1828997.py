#!/usr/bin/env python3
"""
Structural audit for MIPLIB ns1828997.

Usage:
    python audit_ns1828997.py --mps ns1828997.mps.gz --sol solution.sol.gz

Requires:
    gurobipy

No optimize() or presolve() is called.
"""

import argparse
import collections
import gzip
import hashlib
import itertools
import json
import math
import os
from pathlib import Path

import gurobipy as gp


TOL = 1e-8


def close(a, b, tol=TOL):
    return abs(float(a) - float(b)) <= tol


def canon_terms(model, constr):
    row = model.getRow(constr)
    d = collections.defaultdict(float)
    for k in range(row.size()):
        d[row.getVar(k).VarName] += row.getCoeff(k)
    out = []
    for name, coef in sorted(d.items()):
        if abs(coef) > TOL:
            out.append((name, round(float(coef), 12)))
    return out


def signed_pattern(terms):
    return sorted(round(c, 8) for _, c in terms)


def role_histogram(vals):
    if not vals:
        return {}
    a = sorted(vals)
    return {
        "count": len(a),
        "min": a[0],
        "max": a[-1],
        "mean": sum(a) / len(a),
        "nonzero": sum(abs(x) > TOL for x in a),
    }


def digest_json(obj):
    raw = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(raw).hexdigest()


def read_solution(path):
    """
    Reads the usual Gurobi .sol text format, including .sol.gz.
    Lines beginning with # are ignored. The first two whitespace-separated
    fields are interpreted as variable name and value.
    """
    opener = gzip.open if path.endswith(".gz") else open
    vals = {}
    metadata = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as f:
        for line in f:
            s = line.strip()
            if not s:
                continue
            if s.startswith("#"):
                if "=" in s:
                    k, v = s[1:].split("=", 1)
                    metadata[k.strip()] = v.strip()
                continue
            p = s.split()
            if len(p) < 2:
                continue
            try:
                vals[p[0]] = float(p[1])
            except ValueError:
                continue
    return vals, metadata


def connected_components(nodes, adj, removed=None):
    removed = set() if removed is None else set(removed)
    unseen = set(nodes) - removed
    comps = []
    while unseen:
        root = min(unseen)
        stack = [root]
        unseen.remove(root)
        comp = []
        while stack:
            v = stack.pop()
            comp.append(v)
            for w in adj.get(v, ()):
                if w in unseen and w not in removed:
                    unseen.remove(w)
                    stack.append(w)
        comps.append(sorted(comp))
    return sorted(comps, key=lambda x: (len(x), x))


def graph_stats(nodes, edges):
    nodes = sorted(nodes)
    adj = {v: set() for v in nodes}
    for a, b in edges:
        if a == b:
            continue
        adj[a].add(b)
        adj[b].add(a)

    deg = [len(adj[v]) for v in nodes]
    comps = connected_components(nodes, adj)

    # Deterministic greedy elimination widths.
    def eliminate(mode):
        A = {v: set(adj[v]) for v in nodes}
        remaining = set(nodes)
        order = []
        widths = []
        fill_count = 0
        while remaining:
            candidates = []
            for v in remaining:
                nb = sorted(A[v] & remaining)
                missing = sum(
                    1 for i in range(len(nb))
                    for j in range(i + 1, len(nb))
                    if nb[j] not in A[nb[i]]
                )
                key = (missing, len(nb), v) if mode == "fill" else (len(nb), missing, v)
                candidates.append((key, v, nb, missing))
            _, v, nb, missing = min(candidates)
            widths.append(len(nb))
            fill_count += missing
            for i in range(len(nb)):
                for j in range(i + 1, len(nb)):
                    x, y = nb[i], nb[j]
                    A[x].add(y)
                    A[y].add(x)
            remaining.remove(v)
            order.append(v)
        return {
            "width": max(widths, default=0),
            "order": order,
            "fill_edges_added": fill_count,
        }

    # Small exact balanced vertex separators, searching sizes 0..3.
    best_sep = None
    n = len(nodes)
    for k in range(min(3, n) + 1):
        candidates = []
        for S in itertools.combinations(nodes, k):
            cc = connected_components(nodes, adj, S)
            largest = max((len(c) for c in cc), default=0)
            # Minimize separator size first, then largest remaining component.
            candidates.append((largest, tuple(S), [len(c) for c in cc]))
        if candidates:
            best = min(candidates)
            best_sep = {
                "size": k,
                "vertices": list(best[1]),
                "component_sizes": sorted(best[2]),
                "largest_component": best[0],
            }
            # Report the first feasible size, which is the smallest size tested.
            break

    # A more informative balanced separator among all sets of size <= 3.
    balanced = None
    target = math.ceil(max(1, n - 1) / 2)
    for k in range(min(3, n) + 1):
        for S in itertools.combinations(nodes, k):
            cc = connected_components(nodes, adj, S)
            largest = max((len(c) for c in cc), default=0)
            if largest <= target:
                cand = (k, largest, tuple(S), sorted(len(c) for c in cc))
                if balanced is None or cand < balanced:
                    balanced = cand
    balanced_out = None
    if balanced is not None:
        balanced_out = {
            "size": balanced[0],
            "largest_component": balanced[1],
            "vertices": list(balanced[2]),
            "component_sizes": balanced[3],
        }

    return {
        "nodes": n,
        "edges": len(edges),
        "degree": role_histogram(deg),
        "components": [len(c) for c in comps],
        "greedy_min_fill_treewidth_upper": eliminate("fill"),
        "greedy_min_degree_treewidth_upper": eliminate("degree"),
        "smallest_separator_tested": best_sep,
        "balanced_separator_up_to_size_3": balanced_out,
    }


def basic_graph_stats(nodes, edges):
    """Bounded statistics for a larger graph; no fill or separator search."""
    nodes = sorted(nodes)
    adjacency = {v: set() for v in nodes}
    for a, b in edges:
        if a != b:
            adjacency[a].add(b)
            adjacency[b].add(a)
    degrees = [len(adjacency[v]) for v in nodes]
    comps = connected_components(nodes, adjacency)
    return {
        "nodes": len(nodes),
        "edges": len(edges),
        "degree": role_histogram(degrees),
        "components": [len(c) for c in comps],
        "bounded_note": "Fill and separator enumeration deliberately skipped on this graph.",
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mps", required=True)
    ap.add_argument("--sol", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    model = gp.read(args.mps)
    vars_all = list(model.getVars())
    cons_all = list(model.getConstrs())

    by_name = {v.VarName: v for v in vars_all}
    names = set(by_name)

    rows_by_type = collections.defaultdict(list)
    row_errors = []
    row_records = []

    cardinality_rows = []
    link_rows = []
    conflict_rows = []
    product_rows = []
    and_rows = []
    unknown_rows = []

    for c in cons_all:
        terms = canon_terms(model, c)
        sense = c.Sense
        rhs = float(c.RHS)
        pat = signed_pattern(terms)
        rec = {
            "name": c.ConstrName,
            "sense": sense,
            "rhs": rhs,
            "terms": terms,
        }

        typ = "unknown"

        if (
            sense == "=" and close(rhs, 5) and
            len(terms) == 25 and
            all(close(coef, 1) for _, coef in terms)
        ):
            typ = "cardinality"
            cardinality_rows.append(rec)

        elif (
            sense == "<" and close(rhs, 0) and
            len(terms) == 2 and
            sorted(round(coef, 8) for _, coef in terms) == [-1, 1]
        ):
            typ = "link"
            link_rows.append(rec)

        elif (
            sense == "<" and close(rhs, 1) and
            len(terms) == 2 and
            all(close(coef, 1) for _, coef in terms)
        ):
            typ = "conflict"
            conflict_rows.append(rec)

        elif (
            sense == "<" and close(rhs, 1) and
            len(terms) == 3 and
            sorted(round(coef, 8) for _, coef in terms) == [-1, 1, 1]
        ):
            typ = "product"
            product_rows.append(rec)

        elif (
            sense == ">" and close(rhs, 0) and
            len(terms) == 2 and
            sorted(round(coef, 8) for _, coef in terms) == [-1, 1]
        ):
            typ = "and_lower"
            and_rows.append(rec)

        if typ == "unknown":
            unknown_rows.append(rec)
        rows_by_type[typ].append(rec)
        row_records.append(rec)

    # Primary variables: variables in cardinality equations.
    block_var_sets = []
    for r in cardinality_rows:
        block_var_sets.append(set(v for v, coef in r["terms"]))

    primary = set().union(*block_var_sets) if block_var_sets else set()
    block_of = {}
    block_order = []
    for i, S in enumerate(sorted(block_var_sets, key=lambda x: tuple(sorted(x)))):
        block_order.append(sorted(S))
        for v in S:
            if v in block_of:
                row_errors.append("primary variable occurs in multiple cardinality rows: " + v)
            block_of[v] = i

    # Deterministic label indices.
    label_of = {}
    for b, S in enumerate(block_order):
        for ell, v in enumerate(sorted(S)):
            label_of[v] = ell

    # Links: identify z and verify x-z orientation.
    z_of_x = {}
    bad_links = []
    for r in link_rows:
        pos = [v for v, c in r["terms"] if close(c, 1)]
        neg = [v for v, c in r["terms"] if close(c, -1)]
        if len(pos) != 1 or len(neg) != 1 or pos[0] not in primary:
            bad_links.append(r["name"])
            continue
        x, z = pos[0], neg[0]
        if x in z_of_x and z_of_x[x] != z:
            row_errors.append("multiple z variables for " + x)
        z_of_x[x] = z

    zvars = set(z_of_x.values())

    # Product rows and AND lower rows.
    product_by_y = {}
    bad_products = []
    for r in product_rows:
        neg = [v for v, c in r["terms"] if close(c, -1)]
        pos = [v for v, c in r["terms"] if close(c, 1)]
        if len(neg) != 1 or len(pos) != 2 or any(v not in primary for v in pos):
            bad_products.append(r["name"])
            continue
        y = neg[0]
        endpoints = tuple(sorted(pos))
        if y in product_by_y and product_by_y[y] != endpoints:
            row_errors.append("multiple product definitions for " + y)
        product_by_y[y] = endpoints

    and_by_y = collections.defaultdict(list)
    for r in and_rows:
        pos = [v for v, c in r["terms"] if close(c, 1)]
        neg = [v for v, c in r["terms"] if close(c, -1)]
        if len(pos) != 1 or len(neg) != 1 or pos[0] not in primary:
            row_errors.append("malformed AND lower row: " + r["name"])
            continue
        x, y = pos[0], neg[0]
        and_by_y[y].append(x)

    product_vars = set(product_by_y)
    bad_and = []
    for y, endpoints in product_by_y.items():
        got = sorted(and_by_y.get(y, []))
        if got != sorted(endpoints):
            bad_and.append(y)
    for y in and_by_y:
        if y not in product_by_y:
            bad_and.append(y)

    # Variable-role audit.
    recognized = primary | zvars | product_vars
    unrecognized = sorted(names - recognized)

    # Objective audit and compact cost reconstruction.
    unary = collections.defaultdict(float)
    pair_cost = collections.defaultdict(float)
    objective_by_role = collections.Counter()
    objective_unrecognized = []

    for v in vars_all:
        c = float(v.Obj)
        if abs(c) <= TOL:
            continue
        if v.VarName in primary:
            objective_by_role["primary"] += 1
            b = block_of[v.VarName]
            ell = label_of[v.VarName]
            unary[(b, ell)] += c
        elif v.VarName in zvars:
            objective_by_role["z"] += 1
            x = next((xx for xx, zz in z_of_x.items() if zz == v.VarName), None)
            if x is None:
                objective_unrecognized.append(v.VarName)
            else:
                unary[(block_of[x], label_of[x])] += c
        elif v.VarName in product_vars:
            objective_by_role["product"] += 1
            a, b = product_by_y[v.VarName]
            ba, bb = block_of.get(a), block_of.get(b)
            if ba is None or bb is None:
                objective_unrecognized.append(v.VarName)
            else:
                if ba > bb:
                    a, b = b, a
                    ba, bb = bb, ba
                pair_cost[(ba, bb, label_of[a], label_of[b])] += c
        else:
            objective_by_role["unrecognized"] += 1
            objective_unrecognized.append(v.VarName)

    # Interaction graph from product definitions.
    interaction_edges = set()
    product_edge_multiplicity = collections.Counter()
    for y, (a, b) in product_by_y.items():
        if a not in block_of or b not in block_of:
            continue
        ba, bb = block_of[a], block_of[b]
        e = tuple(sorted((ba, bb)))
        interaction_edges.add(e)
        product_edge_multiplicity[e] += 1

    # Conflict graph on primary variables.
    conflict_edges = []
    bad_conflicts = []
    for r in conflict_rows:
        vv = [v for v, c in r["terms"]]
        if len(vv) != 2 or any(v not in primary for v in vv):
            bad_conflicts.append(r["name"])
        else:
            conflict_edges.append(tuple(sorted(vv)))

    # Public solution audit.
    sparse_sol, solmeta = read_solution(args.sol)
    # MIPLIB solution files use the standard sparse convention: omitted
    # variables are zero.  All original variables have bounds [0,1].
    extra = sorted(set(sparse_sol) - names)
    sol = {name: sparse_sol.get(name, 0.0) for name in names}
    missing = []

    max_violation = 0.0
    violated_rows = []
    if not missing:
        for r in row_records:
            lhs = sum(sol[v] * c for v, c in r["terms"])
            if r["sense"] == "=":
                viol = abs(lhs - r["rhs"])
            elif r["sense"] == "<":
                viol = max(0.0, lhs - r["rhs"])
            elif r["sense"] == ">":
                viol = max(0.0, r["rhs"] - lhs)
            else:
                viol = float("nan")
            if viol > max_violation:
                max_violation = viol
            if viol > 1e-7:
                violated_rows.append((r["name"], viol))
    incumbent_obj = None
    if not missing:
        incumbent_obj = float(model.ObjCon) + sum(float(v.Obj) * sol[v.VarName] for v in vars_all)

    compact_obj = None
    compact_violations = []
    if not missing:
        compact_obj = 0.0
        for (b, ell), c in unary.items():
            compact_obj += c * sol[block_order[b][ell]]
        for (b, c, ell, m), q in pair_cost.items():
            xb = sol[block_order[b][ell]]
            xc = sol[block_order[c][m]]
            compact_obj += q * xb * xc

        for b, S in enumerate(block_order):
            s = sum(sol[v] for v in S)
            if abs(s - 5) > 1e-7:
                compact_violations.append(("cardinality", b, s))
        for a, b in conflict_edges:
            if sol[a] + sol[b] > 1.0 + 1e-7:
                compact_violations.append(("conflict", a, b))
        for y, (a, b) in product_by_y.items():
            if abs(sol[y] - sol[a] * sol[b]) > 1e-7:
                compact_violations.append(("product", y, a, b))

    # Compact objective equality is a symbolic equality if all objective
    # variables were recognized and every product has a valid definition.
    objective_equivalence = (
        len(objective_unrecognized) == 0 and
        abs(float(model.ObjCon)) <= TOL and
        len(unrecognized) == 0
    )

    # Graph statistics.
    block_nodes = list(range(len(block_order)))
    interaction_stats = graph_stats(block_nodes, interaction_edges)

    conflict_nodes = sorted(primary)
    conflict_stats = basic_graph_stats(conflict_nodes, conflict_edges)

    # Bounded cost-table summaries and deterministic digest.
    pair_items = [
        [b, c, ell, m, round(q, 12)]
        for (b, c, ell, m), q in sorted(pair_cost.items())
    ]
    unary_items = [
        [b, ell, round(q, 12)]
        for (b, ell), q in sorted(unary.items())
    ]

    out = {
        "instance": os.path.basename(args.mps),
        "model_dimensions": {
            "variables": len(vars_all),
            "constraints": len(cons_all),
            "nonzeros": sum(len(canon_terms(model, c)) for c in cons_all),
            "objective_constant": float(model.ObjCon),
        },
        "variable_types": collections.Counter(str(v.VType) for v in vars_all),
        "row_template_counts": {
            "cardinality": len(cardinality_rows),
            "link_x_le_z": len(link_rows),
            "conflict": len(conflict_rows),
            "product_upper": len(product_rows),
            "and_lower": len(and_rows),
            "unknown": len(unknown_rows),
        },
        "role_counts": {
            "primary_selection": len(primary),
            "z": len(zvars),
            "product": len(product_vars),
            "recognized_total": len(recognized),
            "unrecognized": len(unrecognized),
        },
        "equivalence_audit": {
            "all_rows_recognized": len(unknown_rows) == 0,
            "all_cardinality_rows_valid": all(len(S) == 25 for S in block_var_sets)
                and len(block_order) == 15,
            "all_links_valid": len(bad_links) == 0
                and len(z_of_x) == len(primary),
            "all_products_valid": len(bad_products) == 0
                and len(bad_and) == 0
                and len(product_by_y) == 26875,
            "all_conflicts_on_primary": len(bad_conflicts) == 0,
            "objective_symbolically_eliminable": objective_equivalence,
            "interaction_edge_count": len(interaction_edges),
            "product_multiplicity_histogram":
                collections.Counter(product_edge_multiplicity.values()),
            "errors_count": len(row_errors) + len(bad_links) +
                len(bad_products) + len(bad_and) + len(bad_conflicts),
        },
        "objective_support": dict(objective_by_role),
        "objective_coefficient_histograms": {
            "primary": role_histogram(
                [float(v.Obj) for v in vars_all if v.VarName in primary and abs(v.Obj) > TOL]
            ),
            "z": role_histogram(
                [float(v.Obj) for v in vars_all if v.VarName in zvars and abs(v.Obj) > TOL]
            ),
            "product": role_histogram(
                [float(v.Obj) for v in vars_all if v.VarName in product_vars and abs(v.Obj) > TOL]
            ),
        },
        "cost_tables": {
            "unary_nonzero_entries": len(unary_items),
            "pair_nonzero_entries": len(pair_items),
            "unary_digest": digest_json(unary_items),
            "pair_digest": digest_json(pair_items),
            "unary_sample": unary_items[:20],
            "pair_sample": pair_items[:20],
        },
        "interaction_graph": interaction_stats,
        "conflict_graph": conflict_stats,
        "public_solution": {
            "metadata": solmeta,
            "entries": len(sol),
            "missing_variables": len(missing),
            "extra_variables": len(extra),
            "max_original_row_violation": max_violation if not missing else None,
            "violated_original_rows": len(violated_rows),
            "original_objective": incumbent_obj,
            "compact_objective": compact_obj,
            "objective_difference":
                None if incumbent_obj is None or compact_obj is None
                else incumbent_obj - compact_obj,
            "compact_violations": len(compact_violations),
            "validated_original_feasible":
                len(missing) == 0 and len(violated_rows) == 0,
            "validated_compact_feasible":
                len(missing) == 0 and len(compact_violations) == 0,
        },
        "samples": {
            "blocks": [
                {
                    "block": b,
                    "variables": S[:5],
                    "size": len(S),
                }
                for b, S in enumerate(block_order[:3])
            ],
            "interaction_edges": [list(e) for e in sorted(interaction_edges)[:20]],
            "conflict_edges": [list(e) for e in sorted(conflict_edges)[:20]],
        },
        "bounded_error_details": {
            "unrecognized_variables_sample": unrecognized[:20],
            "row_errors_sample": row_errors[:20],
            "bad_link_rows_sample": bad_links[:20],
            "bad_product_rows_sample": bad_products[:20],
            "bad_and_variables_sample": bad_and[:20],
            "bad_conflict_rows_sample": bad_conflicts[:20],
            "missing_solution_variables_sample": missing[:20],
            "violated_original_rows_sample": violated_rows[:20],
            "compact_violation_sample": compact_violations[:20],
        },
    }

    Path(args.out).write_text(
        json.dumps(out, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    print(json.dumps({
        "output": args.out,
        "templates": out["row_template_counts"],
        "roles": out["role_counts"],
        "equivalence": out["equivalence_audit"],
        "public_solution": out["public_solution"],
    }, sort_keys=True, allow_nan=False))


if __name__ == "__main__":
    main()
