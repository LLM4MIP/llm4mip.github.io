"""Analyze the audited 375-variable core without calling any optimizer."""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from itertools import combinations
import gzip
import json
from pathlib import Path


def parse_sparse_solution(path: Path) -> dict[str, int]:
    opener = gzip.open if path.suffix == ".gz" else open
    values: dict[str, int] = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as stream:
        for line in stream:
            fields = line.split()
            if len(fields) < 2 or fields[0].startswith("#"):
                continue
            try:
                value = float(fields[1])
            except ValueError:
                continue
            values[fields[0]] = int(round(value))
    return values


def block_label(index: int) -> tuple[int, int]:
    assert 1 <= index <= 375
    return (index - 1) // 25, (index - 1) % 25


def greedy_width(nodes: list[int], edges: set[tuple[int, int]]) -> dict:
    adjacency = {v: set() for v in nodes}
    for a, b in edges:
        adjacency[a].add(b)
        adjacency[b].add(a)
    remaining = set(nodes)
    order, widths = [], []
    while remaining:
        scored = []
        for v in remaining:
            neighbors = adjacency[v] & remaining
            missing = sum(
                b not in adjacency[a]
                for a, b in combinations(sorted(neighbors), 2)
            )
            scored.append(((missing, len(neighbors), v), v, sorted(neighbors)))
        _, vertex, neighbors = min(scored)
        widths.append(len(neighbors))
        order.append(vertex)
        for a, b in combinations(neighbors, 2):
            adjacency[a].add(b)
            adjacency[b].add(a)
        remaining.remove(vertex)
    return {"upper_bound": max(widths, default=0), "order": order}


def components(nodes: set[int], edges: set[tuple[int, int]], removed: set[int]) -> list[list[int]]:
    adjacency = {v: set() for v in nodes - removed}
    for a, b in edges:
        if a not in removed and b not in removed:
            adjacency[a].add(b)
            adjacency[b].add(a)
    unseen = set(adjacency)
    answer = []
    while unseen:
        root = min(unseen)
        unseen.remove(root)
        stack, comp = [root], []
        while stack:
            vertex = stack.pop()
            comp.append(vertex)
            fresh = adjacency[vertex] & unseen
            unseen -= fresh
            stack.extend(sorted(fresh, reverse=True))
        answer.append(sorted(comp))
    return sorted(answer, key=lambda c: (-len(c), c))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("core", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    data = json.loads(args.core.read_text(encoding="utf-8"))
    solution = parse_sparse_solution(args.solution)
    core_names = data["core_names"]
    assert len(core_names) == 375
    selected = {
        i + 1 for i, name in enumerate(core_names) if solution.get(name, 0) == 1
    }

    costs_by_pair: dict[tuple[int, int], list[tuple[int, int, int]]] = defaultdict(list)
    for term in data["cost_terms"]:
        ba, la = block_label(term["a"])
        bb, lb = block_label(term["b"])
        assert ba != bb
        if ba > bb:
            ba, bb, la, lb = bb, ba, lb, la
        costs_by_pair[(ba, bb)].append((la, lb, int(term["cost"])))

    hard_by_pair: dict[tuple[int, int], list[tuple[int, int]]] = defaultdict(list)
    for a, b in data["packing"]:
        ba, la = block_label(a)
        bb, lb = block_label(b)
        assert ba != bb
        if ba > bb:
            ba, bb, la, lb = bb, ba, lb, la
        hard_by_pair[(ba, bb)].append((la, lb))

    all_edges = set(costs_by_pair) | set(hard_by_pair)
    pair_summaries = []
    incurred_total = 0
    for pair in sorted(all_edges):
        costs = costs_by_pair.get(pair, [])
        hard = hard_by_pair.get(pair, [])
        difference_cost = Counter((lb - la, c) for la, lb, c in costs)
        difference_hard = Counter(lb - la for la, lb in hard)
        incurred = sum(
            c
            for la, lb, c in costs
            if pair[0] * 25 + la + 1 in selected
            and pair[1] * 25 + lb + 1 in selected
        )
        hard_hits = sum(
            pair[0] * 25 + la + 1 in selected
            and pair[1] * 25 + lb + 1 in selected
            for la, lb in hard
        )
        incurred_total += incurred
        pair_summaries.append({
            "blocks": list(pair),
            "positive_cost_terms": len(costs),
            "cost_histogram": dict(sorted(Counter(c for _, _, c in costs).items())),
            "signed_label_difference_cost_histogram": {
                f"{d}:{c}": n for (d, c), n in sorted(difference_cost.items())
            },
            "hard_conflicts": len(hard),
            "signed_label_difference_hard_histogram": dict(sorted(difference_hard.items())),
            "incumbent_cost": incurred,
            "incumbent_hard_hits": hard_hits,
        })

    selected_by_block = []
    for block in range(15):
        labels = sorted(i - block * 25 for i in selected if block_label(i)[0] == block)
        selected_by_block.append(labels)

    # Exhaustive balanced-separator scan is tiny and safe only on this 15-node graph.
    separators = []
    nodes = set(range(15))
    for size in range(5):
        best = None
        for cut in combinations(sorted(nodes), size):
            comps = components(nodes, all_edges, set(cut))
            largest = max(map(len, comps), default=0)
            candidate = (largest, cut, [len(c) for c in comps])
            if best is None or candidate < best:
                best = candidate
        if best is not None:
            separators.append({
                "size": size,
                "vertices": list(best[1]),
                "largest_component": best[0],
                "component_sizes": best[2],
            })

    report = {
        "core_counts": {
            "selected": len(selected),
            "blocks": len(data["groups"]),
            "hard_conflicts": len(data["packing"]),
            "positive_cost_terms": len(data["cost_terms"]),
            "block_pair_edges": len(all_edges),
            "positive_cost_block_pairs": len(costs_by_pair),
            "hard_conflict_block_pairs": len(hard_by_pair),
        },
        "incumbent": {
            "selected_labels_one_based": selected_by_block,
            "selected_per_block": [len(x) for x in selected_by_block],
            "recomputed_compact_objective": incurred_total,
        },
        "block_graph": {
            "edges": [list(e) for e in sorted(all_edges)],
            "degree_histogram": dict(sorted(Counter(
                sum(v in e for e in all_edges) for v in nodes
            ).items())),
            "greedy_min_fill_width": greedy_width(sorted(nodes), all_edges),
            "best_separators_by_size_0_to_4": separators,
        },
        "pair_summaries": pair_summaries,
    }
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "output": str(args.output),
        "core_counts": report["core_counts"],
        "incumbent": report["incumbent"],
        "block_graph": report["block_graph"],
    }, indent=2))


if __name__ == "__main__":
    main()
