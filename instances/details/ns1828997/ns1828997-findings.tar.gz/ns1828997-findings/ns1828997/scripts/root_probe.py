"""Read-only structural probe for ns1828997.

This script never calls optimize or presolve.  It identifies the variables in
the 15 cardinality rows, classifies every row by its exact signed pattern, and
summarizes how objective variables are connected to the 375 core choices.
"""

from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict, deque

import gurobipy as gp


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps")
    parser.add_argument("--extras-only", action="store_true")
    args = parser.parse_args()

    model = gp.read(args.mps)
    variables = model.getVars()

    cardinality_rows = []
    core = set()
    row_records = []
    for row in model.getConstrs():
        expression = model.getRow(row)
        terms = [(expression.getVar(k).VarName, expression.getCoeff(k)) for k in range(expression.size())]
        row_records.append((row.ConstrName, row.Sense, row.RHS, terms))
        if row.Sense == "=" and row.RHS == 5 and len(terms) == 25 and all(coef == 1 for _, coef in terms):
            names = [name for name, _ in terms]
            cardinality_rows.append(names)
            core.update(names)

    objective = {var.VarName: var.Obj for var in variables if var.Obj != 0}
    objective_histogram = Counter(objective.values())

    # Directed implications u -> v recovered from rows v-u >= 0 or u-v <= 0.
    implications = defaultdict(set)
    reverse_implications = defaultdict(set)
    implication_rows = 0
    invariant_rows = []
    packing_rows = []
    for row_name, sense, rhs, terms in row_records:
        if len(terms) == 2 and rhs == 0:
            coeff = {name: value for name, value in terms}
            positives = [name for name, value in terms if value == 1]
            negatives = [name for name, value in terms if value == -1]
            if len(positives) == 1 and len(negatives) == 1:
                if sense == ">":
                    source, target = negatives[0], positives[0]
                elif sense == "<":
                    source, target = positives[0], negatives[0]
                else:
                    continue
                implications[source].add(target)
                reverse_implications[target].add(source)
                implication_rows += 1
        elif len(terms) == 3 and sense == "<" and rhs == 1:
            positives = [name for name, value in terms if value == 1]
            negatives = [name for name, value in terms if value == -1]
            if len(positives) == 2 and len(negatives) == 1:
                invariant_rows.append((positives[0], positives[1], negatives[0]))
        elif len(terms) == 2 and sense == "<" and rhs == 1 and all(value == 1 for _, value in terms):
            packing_rows.append((terms[0][0], terms[1][0]))

    # For each objective variable, find which core variables can reach it and
    # which core variables it can reach through implication arcs.  Search is
    # restricted to the actual implication graph and remains purely structural.
    def reachable_core(start: str, graph: dict[str, set[str]]) -> list[str]:
        seen = {start}
        queue = deque([start])
        hits = set()
        while queue:
            node = queue.popleft()
            if node in core:
                hits.add(node)
            for nxt in graph.get(node, ()):
                if nxt not in seen:
                    seen.add(nxt)
                    queue.append(nxt)
        return sorted(hits)

    objective_link_patterns = Counter()
    objective_examples = []
    for name, cost in objective.items():
        ancestors = reachable_core(name, reverse_implications)
        descendants = reachable_core(name, implications)
        signature = (cost, len(ancestors), len(descendants))
        objective_link_patterns[signature] += 1
        if len(objective_examples) < 30:
            objective_examples.append(
                {
                    "name": name,
                    "cost": cost,
                    "core_ancestors": ancestors[:30],
                    "core_descendants": descendants[:30],
                }
            )

    core_positions = {}
    for group, names in enumerate(cardinality_rows):
        for position, name in enumerate(names):
            core_positions[name] = [group, position]

    product_variables = {product for _, _, product in invariant_rows}
    extra_variables = sorted({var.VarName for var in variables} - core - product_variables)
    extra_implications = []
    for source, targets in implications.items():
        for target in targets:
            if source in extra_variables or target in extra_variables:
                extra_implications.append((source, target))

    report = {
        "counts": {
            "variables": len(variables),
            "rows": len(row_records),
            "cardinality_rows": len(cardinality_rows),
            "core_variables": len(core),
            "objective_variables": len(objective),
            "product_variables": len(product_variables),
            "extra_variables": len(extra_variables),
            "implication_rows": implication_rows,
            "invariant_rows": len(invariant_rows),
            "packing_rows": len(packing_rows),
        },
        "objective_histogram": {str(key): value for key, value in sorted(objective_histogram.items())},
        "cardinality_groups": cardinality_rows,
        "core_positions": core_positions,
        "objective_implication_link_patterns": {
            str(key): value for key, value in sorted(objective_link_patterns.items())
        },
        "objective_examples": objective_examples,
        "first_invariant_rows": invariant_rows[:40],
        "first_packing_rows": packing_rows[:40],
        "extra_variable_names": extra_variables,
        "extra_variable_objectives": {name: objective.get(name, 0) for name in extra_variables},
        "extra_implications": extra_implications,
    }
    if args.extras_only:
        report = {
            "counts": report["counts"],
            "extra_variable_names": report["extra_variable_names"],
            "extra_variable_objectives": report["extra_variable_objectives"],
            "extra_implications": report["extra_implications"],
        }
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
