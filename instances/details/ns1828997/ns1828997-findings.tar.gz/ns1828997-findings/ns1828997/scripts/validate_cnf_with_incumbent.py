"""Validate a cutoff CNF under the independently audited public core values."""

from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path

from pysat.formula import CNF
from pysat.solvers import Solver


def read_solution(path: Path) -> dict[str, int]:
    opener = gzip.open if path.suffix == ".gz" else open
    values: dict[str, int] = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as stream:
        for line in stream:
            fields = line.split()
            if len(fields) < 2 or fields[0].startswith("#"):
                continue
            try:
                values[fields[0]] = int(round(float(fields[1])))
            except ValueError:
                pass
    return values


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("core", type=Path)
    parser.add_argument("cnf", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--solver", default="cadical195")
    args = parser.parse_args()

    data = json.loads(args.core.read_text(encoding="utf-8"))
    sparse = read_solution(args.solution)
    core_names = data["core_names"]
    assert len(core_names) == 375
    values = {name: int(sparse.get(name, 0)) for name in core_names}
    assumptions = [
        index if values[name] else -index
        for index, name in enumerate(core_names, start=1)
    ]

    group_sums = [sum(values[core_names[index - 1]] for index in group)
                  for group in data["groups"]]
    packing_hits = [
        [a, b] for a, b in data["packing"]
        if values[core_names[a - 1]] + values[core_names[b - 1]] > 1
    ]
    objective = sum(
        int(term["cost"])
        * values[core_names[int(term["a"]) - 1]]
        * values[core_names[int(term["b"]) - 1]]
        for term in data["cost_terms"]
    )

    formula = CNF(from_file=str(args.cnf))
    with Solver(name=args.solver, bootstrap_with=formula.clauses) as solver:
        sat = solver.solve(assumptions=assumptions)

    report = {
        "solver": args.solver,
        "cnf": str(args.cnf),
        "cnf_variables": formula.nv,
        "cnf_clauses": len(formula.clauses),
        "all_375_core_values_fixed": len(assumptions) == 375,
        "group_sums": group_sums,
        "packing_hits": packing_hits,
        "recomputed_compact_objective": objective,
        "cnf_satisfiable_under_public_incumbent": bool(sat),
    }
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
