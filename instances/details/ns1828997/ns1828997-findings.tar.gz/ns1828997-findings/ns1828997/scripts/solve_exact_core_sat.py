"""Solve the exact ns1828997 objective cutoff on the audited 375-var core."""

from __future__ import annotations

import argparse
import json
import threading
import time

from pysat.card import CardEnc, EncType
from pysat.formula import CNF, IDPool
from pysat.solvers import Solver


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("core_json")
    parser.add_argument("--cutoff", type=int, default=7)
    parser.add_argument("--solver", default="cadical195")
    parser.add_argument("--seconds", type=float, default=900)
    parser.add_argument("--cnf")
    parser.add_argument("--proof")
    parser.add_argument("--result", required=True)
    args = parser.parse_args()

    with open(args.core_json, "r", encoding="utf-8") as stream:
        core = json.load(stream)
    assert core["format"] == "ns1828997-exact-core-v1"
    assert core["proof_of_equivalence"]["recognized_rows"] == 81725

    pool = IDPool(start_from=376)
    formula = CNF()

    for group in core["groups"]:
        assert len(group) == 25
        encoded = CardEnc.equals(
            lits=group,
            bound=5,
            vpool=pool,
            encoding=EncType.seqcounter,
        )
        formula.extend(encoded.clauses)

    for a, b in core["packing"]:
        formula.append([-a, -b])

    weighted_literals = []
    product_sat_variables = {}
    for term in core["cost_terms"]:
        a, b, cost = term["a"], term["b"], term["cost"]
        product = pool.id(f"product:{term['product']}")
        product_sat_variables[term["product"]] = product

        # If both core factors are selected, their exact product must count.
        # The reverse implications are unnecessary in the existential cutoff
        # projection: a non-forced product can always be assigned zero.
        formula.append([-a, -b, product])
        weighted_literals.append(product)

        for copy in range(1, cost):
            alias = pool.id(f"copy:{term['product']}:{copy}")
            formula.append([-alias, product])
            formula.append([-product, alias])
            weighted_literals.append(alias)

    assert len(weighted_literals) == 4116
    objective = CardEnc.atmost(
        lits=weighted_literals,
        bound=args.cutoff,
        vpool=pool,
        encoding=EncType.seqcounter,
    )
    formula.extend(objective.clauses)

    if args.cnf:
        formula.to_file(args.cnf, comments=[
            "c exact projection of ns1828997",
            f"c source_sha256 {core['source_sha256']}",
            f"c objective_cutoff {args.cutoff}",
        ])

    started = time.monotonic()
    timed_out = threading.Event()
    stop_watcher = threading.Event()
    proof_requested = bool(args.proof)
    outcome = None
    model = None
    proof_lines = None

    with Solver(
        name=args.solver,
        bootstrap_with=formula.clauses,
        with_proof=proof_requested,
        use_timer=True,
    ) as solver:
        def interrupt_at_deadline() -> None:
            if not stop_watcher.wait(args.seconds):
                timed_out.set()
                solver.interrupt()

        watcher = threading.Thread(target=interrupt_at_deadline, daemon=True)
        watcher.start()
        outcome = solver.solve_limited(expect_interrupt=True)
        stop_watcher.set()
        watcher.join(timeout=1)
        if outcome is True:
            model = solver.get_model()
        elif outcome is False and proof_requested:
            proof_lines = solver.get_proof()
        solver_time = solver.time_accum()

    if proof_lines is not None and args.proof:
        with open(args.proof, "w", encoding="ascii", newline="\n") as stream:
            for line in proof_lines:
                stream.write(line.rstrip() + "\n")

    selected_core = []
    exact_objective = None
    if outcome is True and model is not None:
        positive = {literal for literal in model if literal > 0}
        selected_core = [index for index in range(1, 376) if index in positive]
        selected = set(selected_core)
        exact_objective = sum(
            term["cost"]
            for term in core["cost_terms"]
            if term["a"] in selected and term["b"] in selected
        )
        assert exact_objective <= args.cutoff
        assert all(sum(lit in selected for lit in group) == 5 for group in core["groups"])
        assert all(not (a in selected and b in selected) for a, b in core["packing"])

    result = {
        "format": "ns1828997-core-sat-result-v1",
        "source_sha256": core["source_sha256"],
        "cutoff": args.cutoff,
        "solver": args.solver,
        "status": "SAT" if outcome is True else "UNSAT" if outcome is False else "UNKNOWN",
        "timed_out": timed_out.is_set(),
        "wall_seconds": time.monotonic() - started,
        "solver_seconds": solver_time,
        "cnf_variables": formula.nv,
        "cnf_clauses": len(formula.clauses),
        "core_variables": 375,
        "positive_cost_products": len(core["cost_terms"]),
        "weighted_literal_count": len(weighted_literals),
        "selected_core_ids": selected_core,
        "selected_core_names": [core["core_names"][index - 1] for index in selected_core],
        "recomputed_exact_objective": exact_objective,
        "proof_requested": proof_requested,
        "proof_lines": None if proof_lines is None else len(proof_lines),
        "proof_path": args.proof if proof_lines is not None else None,
    }
    with open(args.result, "w", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
