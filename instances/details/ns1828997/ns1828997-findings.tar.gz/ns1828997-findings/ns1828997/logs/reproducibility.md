# Reproducibility log

All paths below are relative to the `ns1828997` research directory. No API
secret is present in this file. The API client loaded the secret from the
pre-existing local secret file into the process environment and never printed
it.

## Inputs and hashes

| File | SHA-256 |
|---|---|
| `input/ns1828997.mps.gz` | `fd75a2046132b9a7cdac326b4fcaf2f953b5f59934ee80b3f120a6082cd1ca90` |
| `solutions/public_id4_localmip.sol.gz` | `eac722c8c90815d902f59aa71392815865de99e82f345bfa859b90fb8aa14055` |
| `solutions/public_id5_copt.sol.gz` | `0f95bb2ce3cff78e2be6666677be34aab98c6af072ca2f8cc534e2412d369075` |
| `artifacts/exact_core.json` | `185567547a87316f7ed2f8901b757421f01cab350a2a47ca58832d99d8ca7a8f` |
| `artifacts/objective_le_7.cnf` | `420d4312e3c5c9a326170afe724cfe87cd43e5d29ed55620d077992ec01d4198` |
| `artifacts/agent_objective_le_8.cnf` | `576ee0a03c02bc136a1eadeebcc72148fbe4c9965cf4a0527bf8362805e31f47` |

The two CNFs in this table were generated during the study but are omitted
from the publication copy because they are fully regenerable from
`artifacts/exact_core.json` and the retained scripts. Their hashes are kept to
identify the formulas used for the recorded runs.

The local Windows TLS stack failed against the MIPLIB host. The three official
files were therefore downloaded on the already configured `euler4` host and
copied back with `scp`; hashes were computed on both sides and matched.

## Commands

Structure-only Gurobi parse (no optimization or presolve):

```powershell
python '.\scripts\root_probe.py' `
  '.\input\ns1828997.mps.gz' --extras-only
```

Independent original-MPS audits:

```powershell
python '.\scripts\audit_ns1828997.py' --mps '.\input\ns1828997.mps.gz' `
  --sol '.\solutions\public_id4_localmip.sol.gz' `
  --out '.\artifacts\audit_public_id4.recheck.json'
python '.\scripts\audit_ns1828997.py' --mps '.\input\ns1828997.mps.gz' `
  --sol '.\solutions\public_id5_copt.sol.gz' `
  --out '.\artifacts\audit_public_id5.recheck.json'
```

Exact core extraction and the cutoff encoding:

```powershell
python '.\scripts\extract_exact_core.py' '.\input\ns1828997.mps.gz' `
  '.\artifacts\exact_core.recheck.json'
python '.\scripts\solve_exact_core_sat.py' '.\artifacts\exact_core.json' `
  --cutoff 7 --solver cadical195 --seconds 1200 `
  --cnf 'artifacts\objective_le_7.cnf' --result '<run-specific result path>'
```

Independent positive-direction check:

```powershell
python '.\scripts\solve_exact_core_sat.py' '.\artifacts\exact_core.json' `
  --cutoff 8 --solver glucose4 --seconds 60 `
  --cnf 'artifacts\agent_objective_le_8.cnf' `
  --result 'artifacts\agent_cutoff8_glucose_result.json'
python '.\scripts\validate_cnf_with_incumbent.py' '.\artifacts\exact_core.json' `
  'artifacts\agent_objective_le_8.cnf' `
  'solutions\public_id4_localmip.sol.gz' `
  'artifacts\agent_cutoff8_incumbent_validation.json' --solver cadical195
```

The free Glucose cutoff-8 search timed out and returned `UNKNOWN`; under all
375 independently audited public incumbent assignments, the same CNF is SAT
immediately. The latter is an encoding sanity check, not a lower bound.
