"""Independently check the saved rational dual using integer arithmetic."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path

import gurobipy as gp


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("original_mps", type=Path)
    parser.add_argument("reduction_dir", type=Path)
    parser.add_argument("certificate", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    mapping = json.loads((args.reduction_dir / "mapping.json").read_text(encoding="utf-8"))
    cert = json.loads(args.certificate.read_text(encoding="utf-8"))
    active = mapping["active_columns"]
    names = [record["original"] for record in active]
    costs = [int(record["cost"]) for record in active]
    column_index = {name: j for j, name in enumerate(names)}
    rows = mapping["active_rows"]
    row_index = {name: r for r, name in enumerate(rows)}
    scale = int(cert["scale"])
    prices_by_name = {name: int(value) for name, value in cert["positive_row_prices"].items()}
    assert set(prices_by_name) <= set(rows)
    prices = [prices_by_name.get(name, 0) for name in rows]
    assert all(value >= 0 for value in prices)

    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()
    original = gp.read(str(args.original_mps), env)
    column_rows = [set() for _ in names]
    for constraint in original.getConstrs():
        r = row_index.get(constraint.ConstrName)
        if r is None:
            continue
        expression = original.getRow(constraint)
        for position in range(expression.size()):
            j = column_index.get(expression.getVar(position).VarName)
            if j is not None:
                column_rows[j].add(r)

    digest = hashlib.sha256()
    for j, incident_rows in enumerate(column_rows):
        digest.update(f"{names[j]}:{costs[j]}:".encode())
        digest.update(",".join(map(str, sorted(incident_rows))).encode())
        digest.update(b"\n")
    assert digest.hexdigest() == cert["incidence_sha256"]

    loads = [sum(prices[r] for r in incident_rows) for incident_rows in column_rows]
    violations = [
        {"column": names[j], "load": load, "capacity": costs[j] * scale}
        for j, load in enumerate(loads)
        if load > costs[j] * scale
    ]
    numerator = int(cert["forced_offset"]) * scale + sum(prices)
    result = {
        "valid": not violations,
        "incidence_sha256_matches": True,
        "violations": violations,
        "full_dual_numerator": numerator,
        "scale": scale,
        "full_dual_value": numerator / scale,
        "integer_lower_bound": math.ceil(numerator / scale),
        "checked_rows": len(rows),
        "checked_columns": len(names),
    }
    assert result["valid"]
    assert numerator == int(cert["full_dual_numerator"])
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
