"""Exhaustive five-column disjunction for the strict 1061 cutoff.

The chosen columns are incumbent columns owning the most uniquely covered
residual rows.  The 32 leaves are exhaustive in those five binaries.  Each
leaf retains every residual column; no candidate-set restriction is made.
"""
from __future__ import annotations

import argparse
import gzip
import itertools
import json
from pathlib import Path
import time

import gurobipy as gp


def atomic_json(path: Path, value: object) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("original_mps", type=Path)
    parser.add_argument("reduction_dir", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--columns", type=int, default=5)
    parser.add_argument("--leaf-seconds", type=float, default=12.0)
    args = parser.parse_args()

    reduction = json.loads((args.reduction_dir / "reduction_report.json").read_text(encoding="utf-8"))
    mapping = json.loads((args.reduction_dir / "mapping.json").read_text(encoding="utf-8"))
    active = mapping["active_columns"]
    names = [record["original"] for record in active]
    costs = [int(record["cost"]) for record in active]
    name_to_index = {name: j for j, name in enumerate(names)}
    rows = mapping["active_rows"]
    row_to_index = {name: r for r, name in enumerate(rows)}
    forced = set(mapping["forced_columns"])
    offset = int(reduction["reductions"]["forced_cost"])
    incumbent_names = set(reduction["incumbent"]["mapped_original_columns"])
    incumbent = {name_to_index[name] for name in incumbent_names if name in name_to_index}

    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()
    original = gp.read(str(args.original_mps), env)
    members = [set() for _ in rows]
    for constraint in original.getConstrs():
        r = row_to_index.get(constraint.ConstrName)
        if r is None:
            continue
        expression = original.getRow(constraint)
        for position in range(expression.size()):
            j = name_to_index.get(expression.getVar(position).VarName)
            if j is not None:
                members[r].add(j)

    cover_count = [sum(j in incumbent for j in row) for row in members]
    assert min(cover_count) >= 1
    unique_owned = {j: 0 for j in incumbent}
    for r, row in enumerate(members):
        if cover_count[r] == 1:
            owner = next(j for j in row if j in incumbent)
            unique_owned[owner] += 1
    branch = sorted(incumbent, key=lambda j: (-unique_owned[j], -costs[j], names[j]))[: args.columns]

    base = gp.Model("core4284-strict-cutoff-disjunction", env=env)
    base.Params.OutputFlag = 0
    base.Params.Threads = 2
    base.Params.Seed = 11
    base.Params.MIPGap = 0.0
    variables = base.addVars(len(names), vtype=gp.GRB.BINARY, name="x")
    residual_objective = gp.quicksum(costs[j] * variables[j] for j in range(len(names)))
    base.setObjective(residual_objective, gp.GRB.MINIMIZE)
    for r, row in enumerate(members):
        base.addConstr(gp.quicksum(variables[j] for j in row) >= 1, name=rows[r])
    base.addConstr(residual_objective <= 1035, name="strict_full_cutoff_1061")
    base.update()

    output = {
        "experiment": "exhaustive five-column critical-owner disjunction",
        "reduced_instance": {"rows": len(rows), "columns": len(names), "forced_offset": offset},
        "cutoff": {"residual": 1035, "full": 1061},
        "branch_columns": [
            {"index": j, "name": names[j], "cost": costs[j], "unique_owned_rows": unique_owned[j]}
            for j in branch
        ],
        "leaf_time_limit_seconds": args.leaf_seconds,
        "leaves": [],
        "found_cutoff_witness": False,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    total_solver_time = 0.0

    for leaf_number, bits in enumerate(itertools.product((0, 1), repeat=len(branch))):
        model = base.copy()
        model.Params.OutputFlag = 0
        model.Params.Threads = 2
        model.Params.Seed = 11 + leaf_number
        model.Params.TimeLimit = args.leaf_seconds
        leaf_variables = model.getVars()
        assignments = {}
        for j, bit in zip(branch, bits):
            leaf_variables[j].LB = bit
            leaf_variables[j].UB = bit
            assignments[names[j]] = bit
        model.optimize()
        total_solver_time += model.Runtime
        has_solution = model.SolCount > 0
        record = {
            "leaf": leaf_number,
            "assignment": assignments,
            "status": int(model.Status),
            "status_name": {
                gp.GRB.OPTIMAL: "OPTIMAL",
                gp.GRB.INFEASIBLE: "INFEASIBLE",
                gp.GRB.TIME_LIMIT: "TIME_LIMIT",
            }.get(model.Status, str(model.Status)),
            "runtime": model.Runtime,
            "nodes": model.NodeCount,
            "objective": model.ObjVal + offset if has_solution else None,
            "bound": model.ObjBound + offset,
            "solutions": model.SolCount,
        }
        output["leaves"].append(record)

        if has_solution and model.ObjVal <= 1035.0000001:
            selected = forced | {names[j] for j, variable in enumerate(leaf_variables) if variable.X > 0.5}
            values = {name: 1.0 for name in selected}
            objective = original.ObjCon + sum(v.Obj * values.get(v.VarName, 0.0) for v in original.getVars())
            max_violation = 0.0
            for constraint in original.getConstrs():
                expression = original.getRow(constraint)
                lhs = sum(
                    expression.getCoeff(p) * values.get(expression.getVar(p).VarName, 0.0)
                    for p in range(expression.size())
                )
                if constraint.Sense == ">":
                    violation = max(constraint.RHS - lhs, 0.0)
                elif constraint.Sense == "<":
                    violation = max(lhs - constraint.RHS, 0.0)
                else:
                    violation = abs(lhs - constraint.RHS)
                max_violation = max(max_violation, violation)
            assert max_violation <= 1e-9 and objective <= 1061.0000001
            args.solution.parent.mkdir(parents=True, exist_ok=True)
            with gzip.open(args.solution, "wt", encoding="utf-8", newline="\n") as handle:
                handle.write(f"=obj= {objective:.12g}\n")
                for name in sorted(selected):
                    handle.write(f"{name} 1\n")
            output["found_cutoff_witness"] = True
            output["witness_audit"] = {
                "full_objective": objective,
                "selected_columns": len(selected),
                "max_original_row_violation": max_violation,
            }
            atomic_json(args.output, output)
            break

        atomic_json(args.output, output)

    output["total_solver_runtime_seconds"] = total_solver_time
    output["wall_seconds"] = time.perf_counter() - started
    output["closed_infeasible_leaves"] = sum(
        leaf["status_name"] == "INFEASIBLE" for leaf in output["leaves"]
    )
    output["unresolved_leaves"] = sum(
        leaf["status_name"] not in {"INFEASIBLE", "OPTIMAL"} for leaf in output["leaves"]
    )
    output["all_cutoff_leaves_closed"] = bool(
        len(output["leaves"]) == 2 ** len(branch)
        and all(leaf["status_name"] == "INFEASIBLE" for leaf in output["leaves"])
    )
    atomic_json(args.output, output)
    print(json.dumps({
        "found_cutoff_witness": output["found_cutoff_witness"],
        "closed_infeasible_leaves": output["closed_infeasible_leaves"],
        "unresolved_leaves": output["unresolved_leaves"],
        "solver_runtime": total_solver_time,
        "wall_seconds": output["wall_seconds"],
    }))


if __name__ == "__main__":
    main()
