"""Export and exactly check a rational row-price certificate for LB 1055."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path

import gurobipy as gp


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("original_mps", type=Path)
    parser.add_argument("reduction_dir", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    report = json.loads((args.reduction_dir / "reduction_report.json").read_text(encoding="utf-8"))
    mapping = json.loads((args.reduction_dir / "mapping.json").read_text(encoding="utf-8"))
    columns = mapping["active_columns"]
    names = [record["original"] for record in columns]
    costs = [int(record["cost"]) for record in columns]
    column_index = {name: j for j, name in enumerate(names)}
    rows = mapping["active_rows"]
    row_index = {name: r for r, name in enumerate(rows)}
    offset = int(report["reductions"]["forced_cost"])

    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()
    original = gp.read(str(args.original_mps), env)
    row_members = [set() for _ in rows]
    column_rows = [set() for _ in names]
    for constraint in original.getConstrs():
        r = row_index.get(constraint.ConstrName)
        if r is None:
            continue
        expression = original.getRow(constraint)
        for position in range(expression.size()):
            j = column_index.get(expression.getVar(position).VarName)
            if j is not None:
                row_members[r].add(j)
                column_rows[j].add(r)

    lp = gp.Model("pure-cover-lp-dual-certificate", env=env)
    x = lp.addVars(len(names), lb=0.0, ub=gp.GRB.INFINITY, vtype=gp.GRB.CONTINUOUS, name="x")
    lp.setObjective(gp.quicksum(costs[j] * x[j] for j in range(len(names))), gp.GRB.MINIMIZE)
    constraints = [
        lp.addConstr(gp.quicksum(x[j] for j in members) >= 1, name=rows[r])
        for r, members in enumerate(row_members)
    ]
    lp.Params.OutputFlag = 0
    lp.optimize()
    assert lp.Status == gp.GRB.OPTIMAL

    scale = 1_000_000_000
    shrink = 0.9999999
    numerators = [math.floor(max(constraint.Pi, 0.0) * shrink * scale) for constraint in constraints]

    # This is the independent exact-arithmetic check: every dual column load
    # is an integer numerator and must not exceed integer cost*scale.
    loads = [sum(numerators[r] for r in incident_rows) for incident_rows in column_rows]
    violations = [j for j, load in enumerate(loads) if load > costs[j] * scale]
    assert not violations
    numerator_sum = sum(numerators)
    full_numerator = offset * scale + numerator_sum
    assert full_numerator > 1054 * scale

    incidence_digest = hashlib.sha256()
    for j, incident_rows in enumerate(column_rows):
        incidence_digest.update(f"{names[j]}:{costs[j]}:".encode())
        incidence_digest.update(",".join(map(str, sorted(incident_rows))).encode())
        incidence_digest.update(b"\n")

    certificate = {
        "type": "exact rational feasible dual of residual set-cover LP",
        "proof": "For every column j, sum_{r in R_j} y_r <= c_j; hence every residual integer cover costs at least sum_r y_r.",
        "scale": scale,
        "forced_offset": offset,
        "residual_lp_float_objective": lp.ObjVal,
        "residual_dual_numerator_sum": numerator_sum,
        "residual_dual_value": numerator_sum / scale,
        "full_dual_numerator": full_numerator,
        "full_dual_value": full_numerator / scale,
        "integer_lower_bound": math.ceil(full_numerator / scale),
        "all_column_inequalities_exactly_valid": True,
        "maximum_column_load_numerator_minus_capacity": max(
            load - costs[j] * scale for j, load in enumerate(loads)
        ),
        "positive_row_prices": {
            rows[r]: value for r, value in enumerate(numerators) if value > 0
        },
        "dimensions": {"rows": len(rows), "columns": len(names)},
        "incidence_sha256": incidence_digest.hexdigest(),
        "solver_runtime_seconds": lp.Runtime,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(certificate, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "residual_dual_value": certificate["residual_dual_value"],
        "full_dual_value": certificate["full_dual_value"],
        "integer_lower_bound": certificate["integer_lower_bound"],
        "positive_rows": len(certificate["positive_row_prices"]),
        "max_exact_slack": certificate["maximum_column_load_numerator_minus_capacity"],
        "runtime": lp.Runtime,
    }))


if __name__ == "__main__":
    main()
