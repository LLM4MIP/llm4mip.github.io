"""Critical-owner ruin/recreate and Lagrangian diagnostics for core4284-1064."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import gzip
import json
import math
from pathlib import Path
import random
import time

import gurobipy as gp
import numpy as np
from scipy.sparse import csc_matrix, csr_matrix


def write_solution(path: Path, objective: int, names: list[str]) -> None:
    with gzip.open(path, "wt", encoding="utf-8", newline="\n") as f:
        f.write(f"=obj= {objective}\n")
        for name in sorted(names):
            f.write(f"{name} 1\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("reduction_dir", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--max-repairs", type=int, default=400)
    parser.add_argument("--start-block", type=int, default=0)
    parser.add_argument("--repair-time", type=float, default=1.0)
    parser.add_argument("--candidate-cap", type=int, default=2500)
    parser.add_argument("--solver-budget", type=float, default=600.0)
    parser.add_argument("--seed", type=int, default=42841064)
    args = parser.parse_args()
    rng = random.Random(args.seed)
    started = time.perf_counter()

    reduction = json.loads((args.reduction_dir / "reduction_report.json").read_text(encoding="utf-8"))
    mapping = json.loads((args.reduction_dir / "mapping.json").read_text(encoding="utf-8"))
    active_col_records = mapping["active_columns"]
    active_names = [record["original"] for record in active_col_records]
    costs = np.asarray([record["cost"] for record in active_col_records], dtype=np.int8)
    col_by_name = {name: j for j, name in enumerate(active_names)}
    active_row_names = mapping["active_rows"]
    row_by_name = {name: r for r, name in enumerate(active_row_names)}
    forced_names = set(mapping["forced_columns"])
    mapped_support = set(reduction["incumbent"]["mapped_original_columns"])
    support = {col_by_name[name] for name in mapped_support if name in col_by_name}
    assert sum(int(costs[j]) for j in support) == reduction["incumbent"]["mapped_cost"] - reduction["reductions"]["forced_cost"] == 1036

    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()
    original = gp.read(str(args.model), env)
    variables = original.getVars()
    var_by_name = {v.VarName: v for v in variables}
    rows: list[set[int]] = [set() for _ in active_row_names]
    cols: list[set[int]] = [set() for _ in active_names]
    for con in original.getConstrs():
        if con.ConstrName not in row_by_name:
            continue
        r = row_by_name[con.ConstrName]
        expr = original.getRow(con)
        for p in range(expr.size()):
            v = expr.getVar(p)
            if v.VarName in col_by_name:
                assert abs(expr.getCoeff(p) - 1.0) < 1e-12
                j = col_by_name[v.VarName]
                rows[r].add(j)
                cols[j].add(r)
        assert rows[r]

    cover_count = np.asarray([len(row & support) for row in rows], dtype=int)
    assert np.all(cover_count >= 1)
    critical = {r for r, count in enumerate(cover_count) if count == 1}
    owner = {r: next(iter(rows[r] & support)) for r in critical}
    owned: dict[int, set[int]] = defaultdict(set)
    for r, j in owner.items():
        owned[j].add(r)

    non_support = set(range(len(cols))) - support
    owner_sets: dict[int, frozenset[int]] = {}
    critical_gain = {}
    for j in non_support:
        touched = cols[j] & critical
        owner_sets[j] = frozenset(owner[r] for r in touched)
        critical_gain[j] = len(touched)

    # Sparse matrix for rigorous Lagrangian values and prices.
    rr = []
    cc = []
    for r, members in enumerate(rows):
        for j in members:
            rr.append(r)
            cc.append(j)
    A = csr_matrix((np.ones(len(rr), dtype=np.float64), (rr, cc)), shape=(len(rows), len(cols)))
    AT = csc_matrix(A.T)
    lam = np.where(cover_count == 1, 1.0, np.where(cover_count == 2, 0.05, 0.0))
    best_lagrangian = -math.inf
    best_lam = lam.copy()
    lag_trace = []
    ub = 1036.0
    for iteration in range(240):
        priced_sum = np.asarray(AT @ lam).ravel()
        reduced_cost = costs.astype(float) - priced_sum
        xlag = (reduced_cost < 0).astype(float)
        L = float(lam.sum() + np.minimum(reduced_cost, 0.0).sum())
        assert L <= ub + 1e-6
        if L > best_lagrangian:
            best_lagrangian = L
            best_lam = lam.copy()
        grad = 1.0 - np.asarray(A @ xlag).ravel()
        norm2 = float(grad @ grad)
        if norm2 == 0:
            break
        theta = 1.5 if iteration < 20 else 0.75 if iteration < 60 else 0.25
        step = theta * max(ub - L, 0.0) / norm2
        lam = np.maximum(0.0, lam + step * grad)
        if iteration % 10 == 0:
            lag_trace.append({"iteration": iteration, "bound": L, "step": step})
    priced_sum = np.asarray(AT @ best_lam).ravel()
    reduced_cost = costs.astype(float) - priced_sum

    seeds = [j for j in non_support if len(owner_sets[j]) >= 2]
    seeds.sort(key=lambda j: (
        -(4.0 * sum(best_lam[r] for r in cols[j] & critical) + 2.0 * len(owner_sets[j]) - reduced_cost[j]) / int(costs[j]),
        -critical_gain[j],
        j,
    ))

    blocks: list[frozenset[int]] = []
    seen_blocks = set()
    def add_block(block) -> None:
        block = frozenset(block)
        if not block or block in seen_blocks:
            return
        if sum(int(costs[j]) for j in block) < 2:
            return
        seen_blocks.add(block)
        blocks.append(block)

    for seed in seeds[: min(500, len(seeds))]:
        add_block(owner_sets[seed])
    # Connected two-seed unions generate coordinated blocks of moderate size.
    for a in range(min(250, len(seeds))):
        ja = seeds[a]
        partners = [j for j in seeds[:500] if j != ja and owner_sets[ja] & owner_sets[j]]
        partners.sort(key=lambda j: (-len(owner_sets[ja] | owner_sets[j]), j))
        for jb in partners[:2]:
            union = owner_sets[ja] | owner_sets[jb]
            if len(union) <= 30:
                add_block(union)
    # Deterministic randomized owner clusters provide larger ruin neighborhoods.
    owner_list = sorted(owned)
    for size in (8, 12, 20, 30, 50):
        for _ in range(20):
            add_block(rng.sample(owner_list, min(size, len(owner_list))))

    repair_env = gp.Env(empty=True)
    repair_env.setParam("OutputFlag", 0)
    repair_env.start()
    repair_records = []
    total_solver_runtime = 0.0
    found_support = None
    best_repair_delta = 0

    stop_block = min(len(blocks), args.start_block + args.max_repairs)
    for block_index in range(args.start_block, stop_block):
        D = blocks[block_index]
        if total_solver_runtime >= args.solver_budget:
            break
        survivors = support - set(D)
        uncovered = [r for r, members in enumerate(rows) if not (members & survivors)]
        destroyed_cost = sum(int(costs[j]) for j in D)
        possible = set(D)
        for r in uncovered:
            possible.update(rows[r])
        scores = {}
        uncovered_set = set(uncovered)
        for j in possible:
            hit = cols[j] & uncovered_set
            scores[j] = (
                4.0 * sum(best_lam[r] for r in hit)
                + 2.0 * len({owner[r] for r in hit if r in owner})
                + len(hit)
                - 0.25 * int(costs[j])
            ) / int(costs[j])
        ranked = sorted(possible, key=lambda j: (-scores[j], int(costs[j]), j))
        candidate = set(D)
        candidate.update(ranked[: args.candidate_cap])
        # Guarantee at least one candidate for every repair row after capping.
        for r in uncovered:
            if not (rows[r] & candidate):
                candidate.add(min(rows[r], key=lambda j: (int(costs[j]), -scores.get(j, 0), j)))
        candidate_sorted = sorted(candidate)

        m = gp.Model(f"critical_repair_{block_index}", env=repair_env)
        m.Params.OutputFlag = 0
        m.Params.Threads = 1
        m.Params.TimeLimit = min(args.repair_time, args.solver_budget - total_solver_runtime)
        m.Params.MIPGap = 0.0
        y = {j: m.addVar(vtype=gp.GRB.BINARY, obj=int(costs[j]), name=f"x_{j}") for j in candidate_sorted}
        for r in uncovered:
            available = rows[r] & candidate
            m.addConstr(gp.quicksum(y[j] for j in available) >= 1)
        m.addConstr(gp.quicksum(int(costs[j]) * y[j] for j in candidate_sorted) <= destroyed_cost - 1)
        m.ModelSense = gp.GRB.MINIMIZE
        m.optimize()
        total_solver_runtime += m.Runtime
        feasible = m.SolCount > 0
        rec = {
            "block": block_index,
            "destroyed_columns": len(D),
            "destroyed_cost": destroyed_cost,
            "uncovered_rows": len(uncovered),
            "critical_owners": len({owner[r] for r in uncovered if r in owner}),
            "candidate_columns": len(candidate),
            "status": int(m.Status),
            "runtime": m.Runtime,
            "node_count": m.NodeCount,
            "feasible": feasible,
            "best_objective": m.ObjVal if feasible else None,
            "best_bound": m.ObjBound if m.Status in (gp.GRB.OPTIMAL, gp.GRB.TIME_LIMIT) else None,
        }
        repair_records.append(rec)
        if feasible:
            added = {j for j in candidate_sorted if y[j].X > 0.5}
            trial = survivors | added
            # Reverse-delete redundant selected columns, expensive first.
            for j in sorted(trial, key=lambda q: (-int(costs[q]), len(cols[q]), q)):
                tentative = trial - {j}
                if all(rows[r] & tentative for r in range(len(rows))):
                    trial = tentative
            assert all(rows[r] & trial for r in range(len(rows)))
            trial_cost = sum(int(costs[j]) for j in trial)
            best_repair_delta = min(best_repair_delta, trial_cost - 1036)
            if trial_cost <= 1035:
                found_support = trial
                break

    result = {
        "residual": {
            "rows": len(rows),
            "columns": len(cols),
            "incumbent_cost": 1036,
            "incumbent_columns": len(support),
            "critical_rows": len(critical),
            "owner_columns": len(owned),
            "critical_owner_histogram": dict(Counter(len(v) for v in owned.values())),
        },
        "lagrangian": {
            "iterations": 240,
            "best_valid_lower_bound": best_lagrangian,
            "integer_ceiling": math.ceil(best_lagrangian - 1e-9),
            "trace": lag_trace,
            "top_priced_rows": [
                {"row": active_row_names[r], "price": float(best_lam[r])}
                for r in np.argsort(-best_lam)[:30]
            ],
            "top_negative_reduced_cost_columns": [
                {"column": active_names[j], "reduced_cost": float(reduced_cost[j]), "cost": int(costs[j])}
                for j in np.argsort(reduced_cost)[:30]
            ],
        },
        "exchange_search": {
            "blocks_generated": len(blocks),
            "repairs_run": len(repair_records),
            "solver_runtime_seconds": total_solver_runtime,
            "feasible_improving_repairs": sum(r["feasible"] for r in repair_records),
            "best_delta": best_repair_delta,
            "records": repair_records,
        },
        "found_improvement": found_support is not None,
        "wall_seconds": time.perf_counter() - started,
    }

    if found_support is not None:
        full_names = forced_names | {active_names[j] for j in found_support}
        full_cost = sum(int(var_by_name[name].Obj) for name in full_names)
        assert full_cost <= 1061
        values = {name: 1.0 for name in full_names}
        max_violation = 0.0
        worst = None
        for con in original.getConstrs():
            expr = original.getRow(con)
            lhs = sum(expr.getCoeff(p) * values.get(expr.getVar(p).VarName, 0.0) for p in range(expr.size()))
            violation = max(con.RHS - lhs, 0.0) if con.Sense == ">" else max(lhs - con.RHS, 0.0) if con.Sense == "<" else abs(lhs - con.RHS)
            if violation > max_violation:
                max_violation, worst = violation, con.ConstrName
        assert max_violation <= 1e-9
        write_solution(args.solution, full_cost, list(full_names))
        result["improved_solution"] = {
            "objective": full_cost,
            "selected_columns": len(full_names),
            "max_original_row_violation": max_violation,
            "worst_original_row": worst,
            "solution": str(args.solution),
        }

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "critical_rows": len(critical),
        "lagrangian_bound": best_lagrangian,
        "repairs": len(repair_records),
        "solver_seconds": total_solver_runtime,
        "found": found_support is not None,
        "wall_seconds": result["wall_seconds"],
    }))


if __name__ == "__main__":
    main()
