# Effort ledger — `core4284-1064`

Research window: **2026-09-09 02:17:36–03:25:07 Asia/Shanghai**
(67 minutes 31 seconds). The required 60-minute minimum was satisfied.

| Start | End | Activity | General-purpose solver time | Evidence |
|---|---|---|---:|---|
| 02:17:36 | 02:24 | Downloaded and hashed official MPS/incumbent; extracted read-only Gurobi structure; researched MIPLIB and railway SCP sources | 0 s | `input/`, `structure/`, `sources/sources.md` |
| 02:24 | 02:30 | Deep matrix audit and independent original-witness validation | 0 s | `scripts/inspect_core.py`, `structure/deep_structure.json` |
| 02:31 | 02:42 | Direct-API structural classification and exact-reduction design; empty gateway replies were rejected without conversation commits | 0 s | `prompts/01_research_design.md`, `responses/01_research_design.json`, `logs/api_failures.md` |
| 02:42 | 02:48 | Implemented and checked fixed-point forcing, row dominance, and column dominance; emitted a strict-cutoff OPB | 0 s (Gurobi parser only) | `scripts/reduce_core.py`, `artifacts/reduction/` |
| 02:48 | 02:53 | Direct-API feedback; implemented CFT-style row pricing and critical-owner ruin/recreate | 1.815 s | `responses/02_reduction_feedback.json`, `scripts/critical_exchange.py`, `artifacts/critical_exchange*.json` |
| 02:47 | 02:58 | Reduced-model calibration baseline: exact LP plus one bounded MIP run | 603.050 s | `scripts/solve_reduced_baseline.py`, `logs/reduced_gurobi_600s.log`, `artifacts/reduced_baseline.json` |
| 02:58 | 03:11 | Direct-API measured-result review. The proposed integer row-packing certificate was rejected after checking it against the LP optimum; the API acknowledged the error and proposed a disjunction | 0 s | `responses/03_measured_feedback.json`, `responses/04_dual_correction.json` |
| 03:12 | 03:21 | Exhaustive 32-leaf disjunction over five high-impact incumbent columns; every full leaf retained all residual columns | 388.510 s | `scripts/disjunctive_core.py`, `artifacts/disjunctive_core.json` |
| 03:22 | 03:25 | Exported a rational LP-dual vector and independently checked all 15,272 column inequalities in exact integer arithmetic | 0.980 s (LP only) | `scripts/export_lp_dual_certificate.py`, `scripts/check_lp_dual_certificate.py`, `artifacts/lp_dual_certificate*.json` |

Total optimizer runtime counted: **994.355 seconds**, below the 1,800-second
per-instance cap. The remaining work was parsing, research, API reasoning,
structural algorithms, exact audits, and report preparation.

Successful direct-API usage: **28,367 total tokens** (10,991 input; 17,376
output, including 3,831 reasoning tokens). Empty responses were not committed
and are not counted as successful research output.
