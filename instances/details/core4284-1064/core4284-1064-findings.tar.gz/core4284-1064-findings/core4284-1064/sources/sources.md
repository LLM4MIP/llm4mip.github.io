# Sources for `core4284-1064`

Research start: 2026-09-09T02:17:36+08:00

## Authoritative instance sources

- MIPLIB page: https://miplib.zib.de/instance_details_core4284-1064.html
  - Status: open; best public solution: 1062.
  - Submitters: Alberto Caprara, Matteo Fischetti, Paolo Toth.
  - Description: set-covering instance from Italian railway models, imported
    from the MIPLIB 2010 submissions.
  - Size: 21,714 variables, 4,287 constraints, 245,121 nonzeros; 21,705
    binaries and 9 continuous variables.
  - The 1062 solution was submitted by Mars Davletshin on 2023-12-02 and is
    described as obtained with Huawei OptVerse's neural heuristic.
- Official MPS: https://miplib.zib.de/WebData/instances/core4284-1064.mps.gz
  - Local SHA-256: `16e642ebc5eb6b1d0cc4e4974e98d59043463237b5ec0daf625021173bd53f39`.
- Official solution ID 4:
  https://miplib.zib.de/downloads/solutions/core4284-1064/4/core4284-1064.sol.gz
  - Local SHA-256: `a3159f53eab418f495db05bdbbc623c1ab24956865f4777b0d614cee905ca6d3`.

## Application and algorithm background

- Caprara, A.; Fischetti, M.; Toth, P. (1999), "A Heuristic Method for
  the Set Covering Problem," *Operations Research* 47(5), 730–743.
  https://doi.org/10.1287/opre.47.5.730
  - The publisher abstract says the algorithm was designed for very large set
    covering instances from crew scheduling at the Italian Railway Company,
    up to 5,000 rows and 1,000,000 columns.
  - It combines a Lagrangian-style heuristic with a refining procedure and won
    the FASTER competition on the target family.
- Caprara, A.; Fischetti, M.; Toth, P. (2000), "Algorithms for the Set
  Covering Problem," *Annals of Operations Research* 98, 353–371.
  Public survey copy: https://www.dei.unipd.it/~fisch/papers/survey_set_covering_problem.pdf
  - The survey identifies railway and mass-transit crew scheduling as a major
    SCP application and discusses both heuristic and exact methods.

Semantic note: the MIPLIB page supplies the railway origin but no explicit
reference for this particular file. The papers support the family background;
all reductions used here are independently checked against the MPS.

