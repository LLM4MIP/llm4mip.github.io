#!/usr/bin/env python3
"""Independent Gurobi fixed-variable feasibility check for a sparse .sol file."""

import argparse
from fractions import Fraction

import gurobipy as gp
from gurobipy import GRB


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mps")
    parser.add_argument("solution")
    args = parser.parse_args()

    model = gp.read(args.mps)
    variables = model.getVars()
    by_name = {v.VarName: v for v in variables}
    values = {v.VarName: Fraction(0) for v in variables}
    header = None
    with open(args.solution, "rt", encoding="utf-8") as handle:
        for raw in handle:
            fields = raw.strip().split()
            if not fields:
                continue
            if fields[0] == "=obj=":
                header = Fraction(fields[1])
            elif len(fields) >= 2 and fields[0] in by_name:
                values[fields[0]] = Fraction(fields[1])

    for name, variable in by_name.items():
        value = float(values[name])
        variable.LB = value
        variable.UB = value
    model.Params.OutputFlag = 0
    model.optimize()
    print("status", model.Status, "expected_optimal_status", GRB.OPTIMAL)
    print("solution_header", header)
    if model.Status == GRB.OPTIMAL:
        print("model_objective", model.ObjVal)
        print("absolute_objective_difference", abs(float(header) - model.ObjVal))
        return 0
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
