# fhnw-binschedule0: interval-order optimum certificate

## Disposition

The instance is solved at **15,958**. The official page still lists the
instance as open with incumbent 16,088 at the time of this investigation. The
new result improves that value by 130.

## Exact structural recovery

The original model has 319,319 variables, 58,085 rows, and 1,382,972 nonzeros
as read by Gurobi. Its rows are completely classified by the extraction script:

- 939 item set-partitioning rows;
- 572 capacity rows;
- 18,904 selector windows represented by 37,808 bound rows;
- 15,724 exact OR-definition rows;
- 1,518 difference indicators represented by 3,036 rows;
- six load epigraph rows.

There are 507 items that must be assigned to endpoint machine 0 or 5. Each has
254 endpoint-bin choices on either machine. The remaining 432 items have 96
choices over 16 bins and six machines. The endpoint capacity rows have unit
capacity, whereas the inner-machine bins have capacity 15.

Every endpoint assignment determines an interval `[U_i,L_i]`. All OR supports
lie inside a single capacity slot; none crosses a slot boundary. For each of
the 507 forced endpoint items, its assignment cost, forced OR cost, and interval
are invariant across all endpoint slots and across machines 0 and 5. Their
fixed assignment-plus-OR cost is exactly 31,284.

For two consecutive occupied endpoint slots, the difference cost is exactly
10 if `L_i > U_j`, and zero otherwise. This eliminates the time coordinates:
the endpoint objective depends only on whether consecutive intervals are
compatible.

## Lower-bound certificate

Zero-duration items having the same time point are contracted. This leaves 128
interval groups: 21 point groups and 107 positive-duration singleton groups.
The compatibility relation is a DAG and has no reciprocal inter-group arcs.

In the bipartite representation of this DAG, the certificate stores a matching
of size 62. It also stores a Konig vertex cover of size 62 and verifies that no
compatibility arc is uncovered, so the matching is maximum. The minimum
all-compatible path cover therefore has

```text
128 - 62 = 66 paths.
```

There are 508 endpoint slots for 507 items. Across two machines, the one empty
slot can split the occupied slots into at most three segments. At least
`66 - 3 = 63` segment-internal transitions must therefore be incompatible and
cost 10. Hence every feasible solution satisfies

```text
endpoint load 0 + endpoint load 5 >= 31284 + 10*63 = 31914.
```

Both endpoint loads lie on the even lattice. Thus their maximum is not merely
at least 15,957, but at least **15,958**. Since the global objective is the
maximum of all six machine loads, this is a global lower bound for the original
MIP.

## Matching upper bound

A first whole-path coloring produced a feasible 15,962 solution. A targeted
colored compatibility matching then found a split with 212 compatible arcs on
machine 0 and 229 on machine 5, using 42 and 24 occupied paths respectively.
It yields endpoint loads 15,956 and 15,958. The four inner-machine loads are
2,631, 2,987/2, 1,533, and 1,187, so the original objective is 15,958.

The reduced target model has 2,033 rows, 217,695 binaries, and 108,594
compatibility arcs per endpoint color. Gurobi was used only as a short exact
oracle for this colored matching decision and found a feasible solution at the
root in 6.95 seconds. This oracle is not the lower-bound proof.

The lifted point has zero violations over all 58,085 original rows, zero bound
violations, and zero integrality violations. An independent run fixed every
one of the 319,319 original variables and returned status `OPTIMAL`, objective
15,958, and objective discrepancy zero.

## Why the full solver route was stopped

The directly projected endpoint MIP was given a bounded diagnostic run. After
539 seconds it retained the public endpoint sum 32,174 and the weak bound
31,284. This confirmed that ordinary branch-and-bound was not exposing the
interval-order obstruction. The successful route instead used the exact
path-cover lower bound and only then asked a reduced oracle for a matching
witness.

## Reproducibility scope

`derive_interval_core.py` parses the original model, checks every invariance
used above, emits the compact certificate, constructs the target solution, and
validates every lifted row. The 20 MB reduced LP is intentionally omitted from
Git because the script regenerates it. The decisive solver log and the earlier
bounded diagnostic log are retained under `logs/`.

## Source status

The [official MIPLIB page](https://miplib.zib.de/instance_details_fhnw-binschedule0.html)
describes an industrial production-pipeline scheduling/assignment problem and,
at the time checked, reports 319,319 variables, 58,085 constraints, status
`open`, and incumbent 16,088. The same page identifies
`fhnw-binschedule2` as a similar instance, which motivated the endpoint
inspection, but every invariant and bound used here was re-derived from
`fhnw-binschedule0` itself.
