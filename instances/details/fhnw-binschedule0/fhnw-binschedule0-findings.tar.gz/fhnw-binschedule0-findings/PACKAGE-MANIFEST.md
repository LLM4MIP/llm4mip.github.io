# Package manifest: fhnw-binschedule0

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 10
Excluded source files: 1

## Included files

- `README.md`
- `certificates/interval-order-certificate.json`
- `logs/endpoint-core-gurobi.log`
- `logs/interval-target-15958.log`
- `reports/structural-investigation.md`
- `scripts/derive_interval_core.py`
- `scripts/verify_fixed_solution.py`
- `scripts/verify_interval_certificate.py`
- `solutions/optimal-15958.sol`
- `solutions/public-16088.sol.gz`

## Excluded files

- `input/fhnw-binschedule0.mps.gz (6302469 bytes; raw benchmark input; sha256 5604233f73f5ff3b6d09e4e72f5763edef7c2c09eebf3610a674198b9709e0f2)`
