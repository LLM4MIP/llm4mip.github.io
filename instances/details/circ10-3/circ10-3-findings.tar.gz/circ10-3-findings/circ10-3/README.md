# `circ10-3`

2026-09-14 independent dual-bound review: [adopted bound, proof chain, checks, and limitations](../../docs/dual-bound-audit-2026-09-14/cases/circ10-3.zh.md). Reviewed lower bound: **242**. This review distinguishes exact, literature, and numerical evidence; historical statements below remain dated records.

## Result

**Global conclusion: the optimum is 242.**

This study constructs and exactly validates a solution of objective **242**,
improving the objective 256 listed by MIPLIB when the study was performed.
The MPS is shown to be an exact encoding of the constrained ten-team circular
Traveling Tournament Problem CIRC10.

Published work proves the matching lower bound through an exhaustive IDA*
computation. Combined with the exact formulation crosswalk and the validated
witness, this proves the MPS optimum is 242. The historical lower-bound
computation was not replayed and has no modern proof trace here, so the evidence
type is recorded as a **literature-dependent theorem transfer** rather than a
self-contained local certificate.

## Provenance

- Compressed MPS SHA-256: `DACFD0446A8DE0E0268B0DC102F37CB8D8EA1220F479D52EEB32F75F4F9EB11E`
- Verified objective-242 solution SHA-256: `225D20F0C59CA9574E84FCE000AA2D96136169148BAD9374CA8BD13662B55F43`
- [MIPLIB instance page](https://miplib.zib.de/instance_details_circ10-3.html)

## Reproduction

The dependency-free formulation checker is
[`scripts/audit_formulation.py`](scripts/audit_formulation.py). It regenerates
all 42,620 row senses and right-hand sides, 307,320 matrix coefficients, 2,700
binary bounds, and 900 objective terms from the tournament definition.

[`scripts/build_solution_242.py`](scripts/build_solution_242.py) translates the
published schedule into the MPS variable numbering. The resulting solution is
in [`solutions/verified-242.sol`](solutions/verified-242.sol), and the Gurobi
quality transcript is in [`logs/solution-242-quality.log`](logs/solution-242-quality.log).
See the [full formulation audit](reports/exact-formulation-audit.md) for the
model crosswalk, evidence boundary, and sources.
