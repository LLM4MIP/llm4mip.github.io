#!/usr/bin/env python3
"""Exact, dependency-free audit of the MIPLIB circ10-3 formulation.

The checker reconstructs every coefficient, sense, and right-hand side from
the standard ten-team constrained Traveling Tournament Problem (TTP).  It
also checks the objective, binary bounds, and (optionally) a sparse solution.

Usage:
    python3 audit_circ10_exact.py MODEL.mps.gz [SOLUTION.sol[.gz]]

All indices used below are zero based in the semantic notation.  MPS variable
names are x1,...,x2700.
"""

from __future__ import annotations

import gzip
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path


N_TEAMS = 10
N_ROUNDS = 18


def number(token: str) -> Fraction:
    """Parse an exact MPS number (including decimal/scientific notation)."""
    return Fraction(token)


def schedule_var(round_: int, team: int, venue: int) -> int:
    """MPS id of z[round,team,venue]."""
    assert 0 <= round_ < N_ROUNDS
    assert 0 <= team < N_TEAMS and 0 <= venue < N_TEAMS
    return 1 + 100 * round_ + 10 * team + venue


def arc_offset(origin: int, destination: int) -> int:
    """Zero-based rank of (origin,destination) among ordered unequal pairs."""
    assert 0 <= origin < N_TEAMS and 0 <= destination < N_TEAMS
    assert origin != destination
    return 9 * origin + destination - (destination > origin)


def arc_var(team: int, origin: int, destination: int) -> int:
    """MPS id of y[team,origin,destination]."""
    assert 0 <= team < N_TEAMS
    return 1801 + 90 * team + arc_offset(origin, destination)


def circular_distance(origin: int, destination: int) -> int:
    gap = abs(origin - destination)
    return min(gap, N_TEAMS - gap)


@dataclass(frozen=True)
class Row:
    sense: str
    rhs: Fraction
    coefficients: dict[int, Fraction]
    family: str


@dataclass
class MPS:
    row_order: list[str]
    row_sense: dict[str, str]
    matrix: dict[str, dict[int, Fraction]]
    objective: dict[int, Fraction]
    rhs: dict[str, Fraction]
    columns: set[int]
    bounds: dict[int, tuple[str, Fraction | None]]


def open_text(path: Path):
    if path.suffix == ".gz":
        return gzip.open(path, "rt", encoding="ascii")
    return path.open("rt", encoding="ascii")


def read_mps(path: Path) -> MPS:
    row_order: list[str] = []
    row_sense: dict[str, str] = {}
    matrix: dict[str, dict[int, Fraction]] = defaultdict(dict)
    objective: dict[int, Fraction] = {}
    rhs: dict[str, Fraction] = {}
    columns: set[int] = set()
    bounds: dict[int, tuple[str, Fraction | None]] = {}
    section = None

    with open_text(path) as handle:
        for raw in handle:
            fields = raw.split()
            if not fields:
                continue
            if not raw[0].isspace() and fields[0] in {
                "NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS",
                "ENDATA", "OBJSENSE",
            }:
                section = fields[0]
                continue
            if section == "ROWS":
                sense, name = fields[0], fields[1]
                row_sense[name] = sense
                if sense != "N":
                    row_order.append(name)
            elif section == "COLUMNS":
                if len(fields) >= 3 and fields[1].strip("'") == "MARKER":
                    continue
                assert fields[0].startswith("x"), fields[0]
                var = int(fields[0][1:])
                columns.add(var)
                for pos in range(1, len(fields), 2):
                    row, value = fields[pos], number(fields[pos + 1])
                    if row == "Obj":
                        objective[var] = objective.get(var, Fraction(0)) + value
                    else:
                        matrix[row][var] = matrix[row].get(var, Fraction(0)) + value
            elif section == "RHS":
                for pos in range(1, len(fields), 2):
                    rhs[fields[pos]] = number(fields[pos + 1])
            elif section == "RANGES":
                raise AssertionError("Unexpected RANGES section")
            elif section == "BOUNDS":
                bound_type, var_name = fields[0], fields[2]
                assert var_name.startswith("x"), var_name
                var = int(var_name[1:])
                value = number(fields[3]) if len(fields) > 3 else None
                assert var not in bounds, f"multiple bounds for x{var}"
                bounds[var] = (bound_type, value)

    return MPS(
        row_order=row_order,
        row_sense=row_sense,
        matrix={name: dict(values) for name, values in matrix.items()},
        objective=objective,
        rhs=rhs,
        columns=columns,
        bounds=bounds,
    )


def expected_rows() -> list[Row]:
    rows: list[Row] = []

    def add(sense: str, rhs: int, coefficients: dict[int, int], family: str):
        cleaned = {v: Fraction(c) for v, c in coefficients.items() if c}
        rows.append(Row(sense, Fraction(rhs), cleaned, family))

    # c0--c89: team i visits every other team's venue exactly once.
    for team in range(N_TEAMS):
        for venue in range(N_TEAMS):
            if venue == team:
                continue
            add("E", 1, {
                schedule_var(round_, team, venue): 1
                for round_ in range(N_ROUNDS)
            }, "away_visit_once")

    # c90--c1709: a visitor at j implies that team j is at home.
    for team in range(N_TEAMS):
        for host in range(N_TEAMS):
            if host == team:
                continue
            for round_ in range(N_ROUNDS):
                add("G", 0, {
                    schedule_var(round_, team, host): -1,
                    schedule_var(round_, host, host): 1,
                }, "visitor_implies_host")

    # c1710--c1889: at most one visiting team at a venue in a round.
    for venue in range(N_TEAMS):
        for round_ in range(N_ROUNDS):
            add("G", -1, {
                schedule_var(round_, team, venue): -1
                for team in range(N_TEAMS) if team != venue
            }, "one_visitor_per_venue")

    # c1890--c2069: each team is at exactly one venue in each round.
    for round_ in range(N_ROUNDS):
        for team in range(N_TEAMS):
            add("E", 1, {
                schedule_var(round_, team, venue): 1
                for venue in range(N_TEAMS)
            }, "one_venue_per_team_round")

    # c2070--c2369: no four consecutive home or four consecutive away.
    for start in range(N_ROUNDS - 3):
        for team in range(N_TEAMS):
            add("G", -3, {
                schedule_var(round_, team, team): -1
                for round_ in range(start, start + 4)
            }, "max_three_home")
        for team in range(N_TEAMS):
            add("G", -3, {
                schedule_var(round_, team, venue): -1
                for round_ in range(start, start + 4)
                for venue in range(N_TEAMS) if venue != team
            }, "max_three_away")

    # c2370--c17669: consecutive unequal venues activate a travel arc.
    for round_ in range(N_ROUNDS - 1):
        for team in range(N_TEAMS):
            for origin in range(N_TEAMS):
                for destination in range(N_TEAMS):
                    if destination == origin:
                        continue
                    add("G", -1, {
                        schedule_var(round_, team, origin): -1,
                        schedule_var(round_ + 1, team, destination): -1,
                        arc_var(team, origin, destination): 1,
                    }, "between_round_arc")

    # c17670--c17759: travel from home before round 1.
    for team in range(N_TEAMS):
        for destination in range(N_TEAMS):
            if destination == team:
                continue
            add("G", 0, {
                schedule_var(0, team, destination): -1,
                arc_var(team, team, destination): 1,
            }, "initial_home_arc")

    # c17760--c17849: travel home after round 18.
    for team in range(N_TEAMS):
        for origin in range(N_TEAMS):
            if origin == team:
                continue
            add("G", 0, {
                schedule_var(N_ROUNDS - 1, team, origin): -1,
                arc_var(team, origin, team): 1,
            }, "final_home_arc")

    # c17850--c19379: forbid immediate reversed fixtures (repeaters).
    for team in range(N_TEAMS):
        for opponent in range(N_TEAMS):
            if opponent == team:
                continue
            for round_ in range(N_ROUNDS - 1):
                add("G", -1, {
                    schedule_var(round_, team, opponent): -1,
                    schedule_var(round_ + 1, opponent, team): -1,
                }, "no_repeaters")

    # c19380--c19469: one selected arc enters every away venue.
    for team in range(N_TEAMS):
        for venue in range(N_TEAMS):
            if venue == team:
                continue
            add("E", 1, {
                arc_var(team, origin, venue): 1
                for origin in range(N_TEAMS) if origin != venue
            }, "away_venue_indegree")

    # c19470--c19559: one selected arc leaves every away venue.
    for team in range(N_TEAMS):
        for venue in range(N_TEAMS):
            if venue == team:
                continue
            add("E", 1, {
                arc_var(team, venue, destination): 1
                for destination in range(N_TEAMS) if destination != venue
            }, "away_venue_outdegree")

    # c19560--c19569: at least three road trips return home.
    for team in range(N_TEAMS):
        add("G", 3, {
            arc_var(team, origin, team): 1
            for origin in range(N_TEAMS) if origin != team
        }, "at_least_three_returns")

    # c19570--c19579: at least three road trips depart home.
    for team in range(N_TEAMS):
        add("G", 3, {
            arc_var(team, team, destination): 1
            for destination in range(N_TEAMS) if destination != team
        }, "at_least_three_departures")

    # c19580--c42619: if an away-away arc incident with v is selected
    # and v is used in round t, the other endpoint cannot occur after t+1.
    # Applying the same valid inequality at both endpoints forces adjacency.
    for team in range(N_TEAMS):
        for anchor in range(N_TEAMS):
            if anchor == team:
                continue
            for round_ in range(N_ROUNDS - 2):
                multiplier = N_ROUNDS - 2 - round_
                for other in range(N_TEAMS):
                    if other in (team, anchor):
                        continue
                    for origin, destination in ((anchor, other), (other, anchor)):
                        coefficients = {
                            schedule_var(round_, team, anchor): -multiplier,
                            arc_var(team, origin, destination): -multiplier,
                        }
                        coefficients.update({
                            schedule_var(later, team, other): -1
                            for later in range(round_ + 2, N_ROUNDS)
                        })
                        add("G", -2 * multiplier, coefficients,
                            "away_arc_adjacency_cut")

    return rows


def expected_objective() -> dict[int, Fraction]:
    return {
        arc_var(team, origin, destination): Fraction(
            circular_distance(origin, destination)
        )
        for team in range(N_TEAMS)
        for origin in range(N_TEAMS)
        for destination in range(N_TEAMS)
        if origin != destination
    }


def read_solution(path: Path) -> tuple[dict[int, Fraction], Fraction | None]:
    values: dict[int, Fraction] = {}
    claimed_objective = None
    with open_text(path) as handle:
        for raw in handle:
            fields = raw.split()
            if not fields or fields[0].startswith("#"):
                continue
            if fields[0] == "=obj=":
                claimed_objective = number(fields[1])
            elif fields[0].startswith("x"):
                values[int(fields[0][1:])] = number(fields[1])
    return values, claimed_objective


def row_satisfied(row: Row, values: dict[int, Fraction]) -> bool:
    lhs = sum((coef * values.get(var, 0)
               for var, coef in row.coefficients.items()), Fraction(0))
    if row.sense == "E":
        return lhs == row.rhs
    if row.sense == "G":
        return lhs >= row.rhs
    if row.sense == "L":
        return lhs <= row.rhs
    raise AssertionError(row.sense)


def audit_model(model: MPS) -> tuple[list[Row], Counter]:
    expected = expected_rows()
    assert len(expected) == 42620, len(expected)
    assert model.row_order == [f"c{i}" for i in range(len(expected))]
    assert set(model.row_sense) == {"Obj", *model.row_order}
    assert model.row_sense["Obj"] == "N"

    for index, row in enumerate(expected):
        name = f"c{index}"
        actual = Row(
            model.row_sense[name],
            model.rhs.get(name, Fraction(0)),
            model.matrix.get(name, {}),
            row.family,
        )
        if actual != row:
            raise AssertionError(
                f"first row mismatch at {name} ({row.family})\n"
                f"expected={row}\nactual={actual}"
            )

    assert model.columns == set(range(1, 2701))
    assert model.bounds == {i: ("BV", None) for i in range(1, 2701)}
    assert model.objective == expected_objective()
    assert model.rhs == {
        f"c{i}": row.rhs for i, row in enumerate(expected) if row.rhs
    }
    assert sum(len(row.coefficients) for row in expected) == 307320

    return expected, Counter(row.family for row in expected)


def audit_solution(path: Path, rows: list[Row]) -> dict[str, object]:
    values, claimed_objective = read_solution(path)
    assert set(values) <= set(range(1, 2701))
    assert all(value in (0, 1) for value in values.values())
    bad_rows = [i for i, row in enumerate(rows) if not row_satisfied(row, values)]
    assert not bad_rows, f"violated rows begin {bad_rows[:10]}"

    objective = sum(
        coefficient * values.get(var, 0)
        for var, coefficient in expected_objective().items()
    )
    if claimed_objective is not None:
        assert claimed_objective == objective

    locations: list[list[int]] = []
    for round_ in range(N_ROUNDS):
        round_locations = []
        for team in range(N_TEAMS):
            selected = [venue for venue in range(N_TEAMS)
                        if values.get(schedule_var(round_, team, venue), 0) == 1]
            assert len(selected) == 1
            round_locations.append(selected[0])
        locations.append(round_locations)

    route_arcs: set[tuple[int, int, int]] = set()
    team_distances: list[int] = []
    for team in range(N_TEAMS):
        route = [team] + [locations[r][team] for r in range(N_ROUNDS)] + [team]
        arcs = [(a, b) for a, b in zip(route, route[1:]) if a != b]
        assert len(arcs) == len(set(arcs))
        team_distances.append(sum(circular_distance(a, b) for a, b in arcs))
        route_arcs.update((team, a, b) for a, b in arcs)

    selected_arcs = {
        (team, origin, destination)
        for team in range(N_TEAMS)
        for origin in range(N_TEAMS)
        for destination in range(N_TEAMS)
        if origin != destination
        and values.get(arc_var(team, origin, destination), 0) == 1
    }
    assert selected_arcs == route_arcs
    assert sum(team_distances) == objective

    return {
        "objective": int(objective),
        "schedule_ones": sum(values.get(v, 0) for v in range(1, 1801)),
        "arc_ones": len(selected_arcs),
        "team_distances": team_distances,
    }


def main() -> None:
    if len(sys.argv) not in (2, 3):
        raise SystemExit(__doc__)

    model_path = Path(sys.argv[1])
    model = read_mps(model_path)
    rows, family_counts = audit_model(model)

    print("PASS exact MPS reconstruction")
    print(f"model={model_path}")
    print("variables=2700 (1800 schedule, 900 directed travel arcs), all binary")
    print("rows=42620 nonzeros=307320 objective_terms=900 sense=minimize")
    print("row family counts=" + str(dict(family_counts)))
    print("row map: c0..89 away_visit_once; c90..1709 visitor_implies_host;")
    print("  c1710..1889 one_visitor_per_venue; c1890..2069 one_venue_per_team_round;")
    print("  for s=0..14, c(2070+20s)..c(2079+20s) max_three_home and")
    print("  c(2080+20s)..c(2089+20s) max_three_away;")
    print("  c2370..17669 between_round_arc; c17670..17759 initial_home_arc;")
    print("  c17760..17849 final_home_arc; c17850..19379 no_repeaters;")
    print("  c19380..19469 away_venue_indegree; c19470..19559 away_venue_outdegree;")
    print("  c19560..19569 at_least_three_returns; c19570..19579 at_least_three_departures;")
    print("  c19580..42619 away_arc_adjacency_cut")
    print("objective coefficient histogram=" + str(dict(sorted(
        Counter(model.objective.values()).items()
    ))))

    if len(sys.argv) == 3:
        solution_path = Path(sys.argv[2])
        result = audit_solution(solution_path, rows)
        print("PASS solution")
        print(f"solution={solution_path}")
        for key, value in result.items():
            print(f"{key}={value}")


if __name__ == "__main__":
    main()
