#!/usr/bin/env python3
"""Translate the published CIRC10 objective-242 schedule to circ10-3 MPS variables."""

from __future__ import annotations

import sys
from collections import Counter
from pathlib import Path


SCHEDULE = """
10 3 @2 @9 @8 7 @6 5 4 @1
@2 1 10 @8 @7 @9 5 4 6 @3
3 10 @1 @7 9 @8 4 6 @5 @2
2 @1 @10 9 8 @7 6 @5 @4 3
4 @10 9 @1 7 8 @5 @6 @3 2
@3 @9 1 @10 @6 5 8 @7 2 4
@5 4 @8 @2 1 10 @9 3 7 @6
@4 6 @9 1 10 @2 @8 7 3 @5
6 5 @7 10 @2 @1 3 9 @8 @4
8 @4 5 2 @3 @10 9 @1 @7 6
@7 @5 4 @3 2 9 1 @10 @6 8
@6 @3 2 5 @4 1 @10 @9 8 7
@8 7 @4 3 6 @5 @2 1 10 @9
7 9 6 @5 4 @3 @1 10 @2 @8
9 @8 @5 6 3 @4 10 2 @1 @7
5 @7 @6 8 @1 3 2 @4 @10 9
@9 @6 8 7 @10 2 @4 @3 1 5
@10 8 7 @6 @9 4 @3 @2 5 1
""".strip()


def arc_offset(origin: int, destination: int) -> int:
    """Zero-based index among 90 ordered unequal venue pairs."""
    assert origin != destination
    return origin * 9 + destination - (destination > origin)


def circular_distance(a: int, b: int) -> int:
    gap = abs(a - b)
    return min(gap, 10 - gap)


def main() -> None:
    output = Path(sys.argv[1])
    rows = [line.split() for line in SCHEDULE.splitlines()]
    assert len(rows) == 18 and all(len(row) == 10 for row in rows)

    opponents = []
    locations = []
    away = []
    for round_tokens in rows:
        round_opponents = []
        round_locations = []
        round_away = []
        for team, token in enumerate(round_tokens):
            is_away = token.startswith("@")
            opponent = int(token.removeprefix("@")) - 1
            assert opponent != team
            round_opponents.append(opponent)
            round_away.append(is_away)
            round_locations.append(opponent if is_away else team)
        for team, opponent in enumerate(round_opponents):
            assert round_opponents[opponent] == team
            assert round_away[team] != round_away[opponent]
        opponents.append(round_opponents)
        locations.append(round_locations)
        away.append(round_away)

    for team in range(10):
        away_hosts = [opponents[r][team] for r in range(18) if away[r][team]]
        home_guests = [opponents[r][team] for r in range(18) if not away[r][team]]
        assert sorted(away_hosts) == [x for x in range(10) if x != team]
        assert sorted(home_guests) == [x for x in range(10) if x != team]
        assert all(opponents[r][team] != opponents[r + 1][team] for r in range(17))
        run = 1
        for r in range(1, 18):
            run = run + 1 if away[r][team] == away[r - 1][team] else 1
            assert run <= 3

    selected = set()
    for r in range(18):
        for team in range(10):
            venue = locations[r][team]
            selected.add(1 + r * 100 + team * 10 + venue)

    total_distance = 0
    per_team_distance = []
    used_arcs = []
    for team in range(10):
        route = [team] + [locations[r][team] for r in range(18)] + [team]
        arcs = [(a, b) for a, b in zip(route, route[1:]) if a != b]
        assert len(arcs) == len(set(arcs)), (team, arcs)
        used_arcs.append(arcs)
        distance = sum(circular_distance(a, b) for a, b in arcs)
        per_team_distance.append(distance)
        total_distance += distance
        for a, b in arcs:
            selected.add(1801 + team * 90 + arc_offset(a, b))

    assert total_distance == 242, total_distance
    assert len([x for x in selected if x <= 1800]) == 180
    assert sum(1 for x in selected if x >= 1801) == sum(map(len, used_arcs))

    lines = ["=obj= 242"] + [f"x{i} 1" for i in sorted(selected)]
    output.write_text("\n".join(lines) + "\n", encoding="ascii")

    print(f"objective={total_distance}")
    print(f"team distances={per_team_distance}")
    print(f"selected schedule variables=180")
    print(f"selected travel-arc variables={sum(map(len, used_arcs))}")
    print(f"solution={output}")


if __name__ == "__main__":
    main()
