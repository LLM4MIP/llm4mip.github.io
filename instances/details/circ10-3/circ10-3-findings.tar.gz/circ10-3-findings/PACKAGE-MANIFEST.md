# Package manifest: circ10-3

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 8
Excluded source files: 1

## Included files

- `README.md`
- `logs/solution-242-quality.log`
- `reports/exact-formulation-audit.md`
- `scripts/audit_formulation.py`
- `scripts/build_solution_242.py`
- `solutions/gurobi-242.sol`
- `solutions/official-256.sol.gz`
- `solutions/verified-242.sol`

## Excluded files

- `input/circ10-3.mps.gz (1474065 bytes; raw benchmark input; sha256 dacfd0446a8de0e0268b0dc102f37cb8d8ea1220f479d52eeb32f75f4f9eb11e)`
