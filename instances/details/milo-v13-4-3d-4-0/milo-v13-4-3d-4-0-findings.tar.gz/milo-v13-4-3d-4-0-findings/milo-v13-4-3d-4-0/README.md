# `milo-v13-4-3d-4-0`

## Result

The official incumbent is independently verified feasible. Its published objective is `358152.26219370891`; recomputation from the original MPS gives `358152.26219370893996`, with no row violation above `1e-9`, no bound violation, and no integrality violation.

Global optimality remains open. The latest global lower bound is
**221230.41433552347**, from the two-hour 2026-09-05 structural branch-and-cut
run (gap approximately 38.23%). It supersedes the earlier COPT bound
217809.698264445. This is a floating-point solver bound, not an independently
checked exact proof tree. The nominally smaller saved objective is a numerical
tolerance effect: all 80 member choices are unchanged, so it is **not a new
design or an improved upper bound**. See the [latest report](../../docs/ten-instance-results-2026-09-06.zh.md)
and [run evidence](../../studies/ten-instance-2026-09-06/hour-pass/runs/20260905-2h/milo-v13-4-3d-4-0/).

A strict local certificate was obtained around the incumbent design: **no better feasible solution can differ in at most seven of the 80 member choices**. Radius 8 and radius 16 searches found no improving solution, but reached their time limits, so they are not certificates.

## Input, provenance, and structure

- Compressed MPS SHA-256: `7D4AABE0B2C5D9F15E86B463851EDFBDFBB413C5FB28C468306848B1790F81DF`
- Uncompressed MPS SHA-256: `DDDD6C41B46F599D6A4889CB4290211B3866D28C3164BB1A9A120FF79AD15ED8`
- Official incumbent `.sol.gz` SHA-256: `E79AF257DDFE8D3BC21148477628115DB931CFFDE5731EE3BB54B1D5E538122E`
- Browsing LP SHA-256: `F6F163B61E22BA553F5308B127DEAB57FF34BF5150E8BAFD3FCA28152F29058E`
- MIPLIB metadata and solution source: [instance page](https://miplib.zib.de/instance_details_milo-v13-4-3d-4-0.html)

The original model has 688 variables, 1,328 constraints, and 3,292 matrix nonzeros. The variable families recovered from the MPS are:

| Family | Count | Role visible in the formulation |
|---|---:|---|
| `z` | 160 integer | two section choices for each of 80 structural members |
| `x` | 80 continuous | selected cross-sectional area |
| `d` | 48 continuous | displacement variables |
| `phi` | 160 continuous | disaggregated force-related variables |
| `psi`, `q`, `sigma` | 80 each | elongation, internal-force, and stress-related variables |

For every member `i`, the formulation contains

```text
z_i_0 + z_i_1 = 1
x_i = 2 z_i_0 + 100 z_i_1
```

so the 160 original integer variables encode 80 binary member decisions. The objective coefficients have three length classes: 32 coefficients equal to 100, 40 equal to `141.42135623730951`, and 8 equal to `173.20508075688772`. The incumbent uses the thick choice on 9 unit-length members, 18 square-root-of-two members, and no square-root-of-three members.

## Experiment summary

| Method | CPU threads | Limit | Result |
|---|---:|---:|---|
| Gurobi 13.0.1, incumbent start, feasibility focus | 24 | 900 s | incumbent retained; lower bound `143757.7001226`; 203,629 nodes |
| Gurobi 13.0.1, incumbent start, bound focus | 24 | 900 s | incumbent retained; lower bound `212458.1364119`; 1,010,598 nodes |
| COPT 8.0.4, incumbent start, aggressive heuristics | 32 | 900 s | incumbent retained; lower bound **`217809.698264445`**; 98,734 nodes |
| Gurobi strict-improvement ball, radius 4 | 16 | 600 s | **infeasible**, proved in 14.46 s; 10,680 nodes |
| Gurobi strict-improvement ball, radius 6 | 16 | 600 s | **infeasible**, proved in 74.36 s; 102,200 nodes |
| Gurobi strict-improvement ball, radius 7 | 16 | 600 s | **infeasible**, proved in 124.73 s; 186,469 nodes |
| Gurobi strict-improvement ball, radius 8 | 16 | 600 s | no solution; time limit; bound `334656.4242388`; 936,173 nodes |
| COPT strict-improvement ball, radius 8 | 32 | 600 s | no solution; time limit; bound `301544.837795842`; 763,482 nodes |
| Gurobi strict-improvement ball, radius 16 | 16 | 600 s | no solution; time limit; bound `214491.5201490`; 1,095,671 nodes |

All COPT experiments on `altman` were CPU-only; GPU0 was not used.

## Why the local cutoff is strict and safe

The exhaustive objective-grid check over all possible counts in the three length classes finds that the nearest representable objective below the incumbent is

```text
357985.16226738894994
```

which is `167.09992631999002` below the verified incumbent. Therefore the local models use the conservative cutoff `objective <= 358151.26219370891`. This one-unit margin cannot exclude any genuinely better member design.

The local-branch constraint measures changed **members**, not changed `z` columns. Flipping one member changes both columns in its exactly-one pair, so a member radius `r` is a `z`-space Hamming radius `2r`.

## Numerical note

The feasibility-focused Gurobi run wrote the same integer design as the official incumbent but reported `358152.2621321`, about `6.2e-5` lower. Independent checking found two row residuals above `1e-9`, a maximum residual of `5.9118e-7`, and zero violations above `1e-6`. Because the `z` Hamming distance is zero and the apparent change is continuous-tolerance drift rather than a new representable design, this repository retains the official objective as the canonical feasible value.

## Reproduce

The checker and local-branch generator use only the Python standard library:

```powershell
python .\instances\milo-v13-4-3d-4-0\scripts\analyze_and_check.py `
  .\instances\milo-v13-4-3d-4-0\input\milo-v13-4-3d-4-0.mps.gz `
  --solution .\instances\milo-v13-4-3d-4-0\solutions\official-incumbent.sol

python .\instances\milo-v13-4-3d-4-0\scripts\make_local_branch_lp.py `
  .\instances\milo-v13-4-3d-4-0\artifacts\milo_original.lp `
  .\instances\milo-v13-4-3d-4-0\solutions\official-incumbent.sol `
  7 358152.26219370891 local-radius7.lp
```

See the [full Chinese study](reports/milo-study.md), [exact checker](scripts/analyze_and_check.py), [local-branch generator](scripts/make_local_branch_lp.py), [official incumbent](solutions/official-incumbent.sol), and [`logs/`](logs/).
