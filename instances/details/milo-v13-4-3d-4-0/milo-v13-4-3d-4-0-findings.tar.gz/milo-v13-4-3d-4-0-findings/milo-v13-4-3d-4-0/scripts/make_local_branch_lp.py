#!/usr/bin/env python3
"""Add an incumbent-improvement cutoff and a z-choice Hamming ball to an LP."""

from __future__ import annotations

import argparse
from decimal import Decimal
from pathlib import Path


def read_selected_z(path: Path) -> tuple[list[str], list[str]]:
    values: dict[str, Decimal] = {}
    with path.open(encoding="utf-8") as handle:
        for raw in handle:
            tokens = raw.split()
            if len(tokens) >= 2 and tokens[0].startswith("z_"):
                values[tokens[0]] = Decimal(tokens[1])

    z_variables = [f"z_{member}_{choice}" for member in range(80) for choice in range(2)]
    selected = [name for name in z_variables if values.get(name, Decimal(0)) > Decimal("0.5")]
    for member in range(80):
        pair = [f"z_{member}_0", f"z_{member}_1"]
        if sum(name in selected for name in pair) != 1:
            raise ValueError(f"incumbent does not choose exactly one option for member {member}")
    return z_variables, selected


def wrap_expression(name: str, terms: list[str], suffix: str) -> str:
    lines = [f" {name}:"]
    for start in range(0, len(terms), 12):
        lines.append("  " + " ".join(terms[start : start + 12]))
    lines[-1] += suffix
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base_lp", type=Path)
    parser.add_argument("incumbent", type=Path)
    parser.add_argument("member_radius", type=int)
    parser.add_argument("incumbent_objective", type=Decimal)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "--epsilon",
        type=Decimal,
        default=Decimal(1),
        help="strict-improvement margin; 1 is safe because the next lower representable objective is 167.1 away",
    )
    args = parser.parse_args()
    if not 1 <= args.member_radius <= 80:
        raise ValueError("member_radius must be in [1, 80]")

    source = args.base_lp.read_text(encoding="utf-8")
    if "Minimize\n" not in source or "Subject To\n" not in source or "Bounds\n" not in source:
        raise ValueError("unexpected LP sections")

    objective_block = source.split("Minimize\n", 1)[1].split("Subject To\n", 1)[0].strip()
    objective_lines = [line.strip() for line in objective_block.splitlines() if line.strip()]
    objective_constraint = [f" improve_cutoff: {objective_lines[0]}"]
    objective_constraint.extend(f"  {line}" for line in objective_lines[1:])
    cutoff = args.incumbent_objective - args.epsilon
    objective_constraint[-1] += f" <= {cutoff}"

    z_variables, selected = read_selected_z(args.incumbent)
    selected_set = set(selected)
    terms = [f"- {name}" if name in selected_set else f"+ {name}" for name in z_variables]
    # z variables occur in 80 exactly-one pairs. A member-choice flip changes two
    # z values, so a member radius r is a z-space Hamming radius 2r.
    rhs = 2 * args.member_radius - len(selected)
    local_constraint = wrap_expression("local_branch", terms, f" <= {rhs}")

    additions = "\n".join(objective_constraint) + "\n" + local_constraint + "\n"
    args.output.write_text(source.replace("Bounds\n", additions + "Bounds\n", 1), encoding="utf-8")
    print(
        f"wrote {args.output}; selected_z={len(selected)}; "
        f"member_radius={args.member_radius}; cutoff={cutoff}"
    )


if __name__ == "__main__":
    main()
