#  `milo-v13-4-3d-4-0` experimental report

Date of experiment: 2026 -09 -01 (Asia/Shanghai)

## Conclusion

This round strict calculated MIPLIB official feasible solution, whose official objective value is `358152.26219370891`, and recalculated `358152.26219370893996` from the original MPS. All 1,328 entry constraint, the lower bound on the variable and the integer variable on the 160 are checked; the maximum non-zero row residual is only `1.04e-13`.

This round has no proof globally optimal, nor has it found a different and better integer design. 15 minutes global solve The best lower bound for COPT is `217809.698264445`, and the gap relative to the official incumbent is `39.1852%`.

The main new conclusion is a strict locally optimal certificate: based on the official design, there is no strict better feasible solution if the 7 of the 80 component selection is changed at most. Searches for 8 and 16 radii have not found a better solution, but they terminate in time and cannot be extended to certificate.

##  Model structure

The model has 688 variable, 1,328 bar constraint and 3,292 matrix nonzero entries.

```text
d: 48     phi: 160     psi: 80     q: 80
sigma: 80 x: 80        z: 160
```

Only `z` is an integer variable. For each `i=0,...,79`, there is a set of binary relations:

```text
z_i_0 + z_i_1 = 1
x_i = 2 z_i_0 + 100 z_i_1
```

The apparent 160 integer variables encode cross-section choices for 80 members: area 2 or area 100. The remaining continuous variables describe displacement, internal force, stress and their big-M decompositions. Row names and sparsity patterns also identify 48 `Topology` equilibrium equalities, 80 displacement-extension relations, 80 upper and 80 lower internal-force constraints, and 1,040 selection/physical coupling constraints.

objective only contains 80, `x`, and objective coefficients are divided into three lengths:

```text
100                     × 32
141.42135623730951       × 40
173.20508075688772       × 8
```

Of the official incumbent 27 thick cross-sectional components, 9 belongs to the first length class, 18 belongs to the second length class, and the third length class is 0.

##  An independent test of official solution

The standard library script directly parse compressed MPS and sparse `.sol`, missing variable treated according to 0, and then recalculated objective with `Decimal`, all row activity values, up lower bound and integrality:

```text
claimed objective       = 358152.26219370891
computed objective      = 358152.2621937089399600000
difference              = 2.996e-11
maximum row residual    = 1.03649457877694e-13
row violations > 1e-9  = 0
bound violations        = 0
integrality violations  = 0
z variables equal to 1  = 80 / 160
```

The solutions written by COPT and Gurobi bound-focus have the same set of `z` options and are checked with the same accuracy.

## global solve

| Solver / Parametric focus |  Host |  Threads |  Time limit |  incumbent  |  lower bound  | Gap/Nodes |
|---|---|---:|---:|---:|---:|---|
|  Gurobi 13.0.1 / `MIPFocus=1`, `Heuristics=0.3`, `PumpPasses=100`, `RINS=10`  |  `euler4`  |  24  |  900 s  | Official design |  `143757.7001226`  |  `59.8613%`, 203,629  |
|  Gurobi 13.0.1 / `MIPFocus=3`, `Cuts=3`  |  `euler4`  |  24  |  900 s  | Official design |  `212458.1364119`  |  `40.6794%`, 1,010,598  |
|  COPT 8.0.4 / `HeurLevel=3`  |  `altman`  |  32  |  900 s  | Official design |  **`217809.698264445`**|**`39.1852%`**, 98,734  |

All operations use the official solution as the MIP start. The `altman` uses only the COPT CPU solver, not the GPU0.

Gurobi's feasibility-focus log gives `358152.2621321` on the surface, which is about `6.2e-5` lower than the official objective. However, independent tests show that its integer `z` is the same as the official design complete, continuous variables the maximum row residual is `5.9118e-7`, two rows larger than `1e-9`, no rows larger than `1e-6`. This difference comes from floating-point feasibility tolerance, not a new discrete design, so it cannot be registered as a new incumbent.

##  strict local branch

The local model also includes:

1. Strict-improvement cutoff: `objective <= 358151.26219370891`;
2.  The official `z` selects a member-level Hamming ball around it.

Since each component is a pair of exactly-one `z` variables, changing one component will change two `z` values, the member radius `r` corresponds to the `z` spatial radius `2r`.

In order to confirm that a unit cutoff will not miss a real improvement, the script uses a combination of three categories of objective coefficients.

```text
357985.16226738894994
```

The incumbent is different from the `167.09992631999002`, so the `-1` cutoff is safe for all strictly optimized designs.

|  Member radius  |  solver |  Threads |  result | When/Notes are used | Conclusions on the nature |
|---:|---|---:|---|---|---|
|  4  |  Gurobi  |  16  |  infeasible  |  14.46 s / 10,680  |  strict certificate |
|  6  |  Gurobi  |  16  |  infeasible  |  74.36 s / 102,200  |  strict certificate |
|  **7**|  Gurobi  |  16  |**infeasible**|  124.73 s / 186,469  |** Currently the strongest strict certificate ** |
|  8  |  Gurobi  |  16  | There is no solution, time limit |  600.01 s / 936,173; bound `334656.4242388`  | Not a certificate |
|  8  |  COPT  |  32  | There is no solution, time limit |  600.01 s / 763,482; bound `301544.837795842`  | Not a certificate |
|  16  |  Gurobi  |  16  | There is no solution, time limit |  600.01 s / 1,095,671; bound `214491.5201490`  | Not a certificate |

The radius-7 result subsumes radii 4 and 6, but their logs are retained to document the gradual certificate expansion. At radius 8, neither solver found an improvement, but neither exhausted the search tree. Therefore the strict conclusion must not claim local optimality at radius 8.

##  Conclusion on the boundaries and the directions to follow

-  It has been proven that the official design is locally optimal within the member radius 7, not globally optimal.
-  The global lower bound `217809.698264445` comes from the time limit solve, and the distance from the incumbent remains significant.
-  The Gurobi local lower bound of the 8 radius has reached `334656.4242388`, the most direct starting point for the next round of local proof completion; consideration can be given to retaining the search tree or using parallel partition separately.
-  Another route is to use the 48 bar topological equilibrium equation and the 80 two-layer intersection structure to develop strong dual boundaries for component set decomposition rather than continuing pure node search.

##  Reproducible files

-  `input/milo-v13-4-3d-4-0.mps.gz`: original MIPLIB compressed MPS.
-  `solutions/official-incumbent.sol(.gz)`: official incumbent and original compression versions.
-  `scripts/analyze_and_check.py`: `Decimal` independent calculator of model structure and solution.
-  `scripts/make_local_branch_lp.py`: strict improved cutoff and member-level Hamming ball generator.
-  `artifacts/milo_original.lp`: Browsing LP from Gurobi's original MPS and local branch generator input.
-  `logs/`: Complete solve diary of global and local branches.

## material

- [MIPLIB：milo-v13-4-3d-4-0 instance details](https://miplib.zib.de/instance_details_milo-v13-4-3d-4-0.html)
- [MIPLIB：open tag](https://miplib.zib.de/tag_open.html)
