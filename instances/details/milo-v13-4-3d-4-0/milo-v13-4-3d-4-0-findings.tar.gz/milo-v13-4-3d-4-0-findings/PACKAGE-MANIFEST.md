# Package manifest: milo-v13-4-3d-4-0

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 21
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/milo_original.lp`
- `logs/copt_lb8_improve_10m.log`
- `logs/copt_warm_heur_15m.log`
- `logs/gurobi_lb16_improve_10m.log`
- `logs/gurobi_lb4_improve_10m.log`
- `logs/gurobi_lb6_improve_10m.log`
- `logs/gurobi_lb7_improve_10m.log`
- `logs/gurobi_lb8_improve_10m.log`
- `logs/gurobi_warm_focus1_15m.log`
- `logs/gurobi_warm_focus3_15m.log`
- `reports/milo-study.md`
- `scripts/analyze_and_check.py`
- `scripts/make_local_branch_lp.py`
- `solutions/copt_warm_heur_15m.sol`
- `solutions/gurobi_warm_focus1_15m.sol`
- `solutions/gurobi_warm_focus3_15m.sol`
- `solutions/official-best.sol.gz`
- `solutions/official-best.validation.json`
- `solutions/official-incumbent.sol`
- `solutions/official-incumbent.sol.gz`

## Excluded files

- `input/milo-v13-4-3d-4-0.mps.gz (22588 bytes; raw benchmark input; sha256 7d4aabe0b2c5d9f15e86b463851edfbdfbb413c5fb28c468306848b1790f81df)`
