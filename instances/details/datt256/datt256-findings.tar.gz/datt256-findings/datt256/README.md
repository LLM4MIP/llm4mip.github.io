# `datt256`

## Result

No globally feasible solution was found, and global infeasibility was not proved. This MPS is the official 16×16 Eternity II puzzle, whose complete 480/480 solution remains unknown.

The public Joshua Blackwood 470/480 board was mechanically mapped to 256 MPS placement variables. Exact evaluation shows:

- all assignment, border, starter-clue, bound and integrality conditions hold;
- exactly 20 color-flow rows are violated, corresponding to its ten mismatched physical edges;
- it is a near-feasible start, not a feasible MIP solution.

Exact destroy-and-repair subproblems prove that no 480/480 completion exists when only the following cells are released: the 17 defect endpoints, Manhattan radii 1 and 2 (48 and 75 cells), or the full top six rows (96 cells). With the bottom ten record rows fixed, the top-six-row repair model is infeasible.

Top-eight-row and global searches were unresolved. Their valid Hamming-distance lower bounds imply that a full solution, if it exists, must change at least 36 top-half placements when the bottom half is fixed, and at least 32 placements globally relative to the 470 board.

## Input

- SHA-256: `F2BDB0696291DEE491979AE76A98862A1A5C17B305ED9E857485931809571AA1`
- Model: 11,077 rows, 262,144 binaries and 1,503,732 solver-read nonzeros.
- MIPLIB metadata: [instance page](https://miplib.zib.de/instance_details_datt256.html)

See the [full study](reports/datt256-study.md), [record bridge](artifacts/datt256-bridge.json), [near-feasible start](solutions/datt256-blackwood470.sol), and [repair script](scripts/datt256_repair.py).
