#  `datt256` (Eternity II) experimental report

Date of experiment: 2026 -09 -01 (Asia/Shanghai)

## Conclusion

This round **did not find a feasible solution for `datt256`, nor did it prove the entire instance of infeasible**.

This is not an ordinary unsolved MIP: MIPLIB labels it `open / no_solution`, and it represents official Eternity II, placing 256 pieces on a 16-by-16 board with all 480 internal edges matching. The cited public sources report no complete 480/480 board and a starter-only record of 470/480. Finding a feasible point for this MPS would therefore essentially solve that public challenge.

This round of confirmation of the new information is:

- The public Joshua Blackwood 470/480 board was mechanically mapped to 256 variables set to one in this MPS and checked exactly row by row. It violates only 20 color-balance equalities, corresponding precisely to 10 mismatched physical edges. All other assignment, border, starter-clue, 0/1 and objective requirements are satisfied.
- Fixing the bottom 10 rows of the 470 board and releasing only the top 6 rows (96 cells), which contain all 10 bad edges, allowed Gurobi to prove in 3.39 seconds that no refill completes the board to 480/480. This is a strict **local infeasibility proof**, not a proof that the full `datt256` instance is infeasible.
- The smaller defect neighborhoods of 17, 48, and 75 cells were also strictly proved unable to repair coverage to 480/480.
-  When releasing the top 8 line (128 format), 300 does not find a full complement within seconds, nor does it have closure proof; the valid root lower bound is 36, i.e. any possible 480 / 480 format must at least change the top 36 format, provided that the bottom 8 line keeps the chessboard record unchanged.
- The global guided model with no cells fixed found no feasible solution in approximately 325 seconds and had a root lower bound of 32: any complete solution, if one exists, must differ from the Blackwood 470 board in at least 32 piece-and-rotation placements.

##  Input and model structure

-  Input: `datt256.mps.gz`
- SHA-256：`F2BDB0696291DEE491979AE76A98862A1A5C17B305ED9E857485931809571AA1`
-  Scale: 11,077 line, 262,144 binary variable, 1,503,732 nonzero entries that are actually read.
-  256 pieces × 256 cells × 4 rotations.
-  The size of the 512 bar is the set-division equation for 1024: each block is exactly one block, each block is exactly one.
-  10,560 row color flow/neighboring edge equation: 480 row inner neighbour × 22 motif.
-  1 bar boundary is an unlawful placement equation: it prohibits grays towards the inside of the board or the colored edges towards the outside of the box.
-  4 is a fixed starter piece with the singleton equivalent; `x141795 = 1`, with the other three rotating as 0.
-  The original objective function is always 256 on all complete directions, so this instance is essentially a pure feasibility problem.

The result of recovery of the variable numbering ((either 0 -based) is:

```text
x_index - 1 = piece_id * 1024 + q_position * 4 + mps_rotation
```

The position of the MPS `q_position` is ranked by column priority and the site chessboard is ranked by row priority; the secondary position is mapped as a repositioning. All 256 blocks for official data, the returned rotation deviations are 2, so:

```text
mps_rotation = (2 - website_rotation) mod 4
```

The bridge script is retrieved from MPS's adjacent side constraint diagram and official piece motif data, with no manual guess number.

##  Verification of the public 470 Chessboard

Using the official piece set in the reference website's open-source repository with the `Joshua_Blackwood_470` board edges, first only matching each piece and spin, and then mapping to MPS via the above bridge.

The exact MPS test results:

```text
objective=256
selected binaries=256
exact row violations=20
maximum row violation=1
bound violations=0
integrality violations=0
assignment/border/clue violations=0
```

10 article does not match on the side ((website row-major position; the last two rows are numbered with motif on both sides):

```text
(21,37,9,12)   (26,42,6,19)   (28,29,12,16)
(41,42,17,22)  (46,47,22,21)  (60,61,15,6)
(61,62,21,17)  (69,70,6,16)   (78,79,19,6)
(78,94,9,15)
```

Each physical badge produces two infringing equations in the 22 color flow code (one is multi-colored 1, the other is less 1), so 10 × 2 = 20 row MPS violation. The file is a high-quality near-feasible start, and **is not a feasible solution for** `datt256`.

##  Solver Baseline (CPU only)

|  solver / host |  Threads |  Time limit |  result | Best boundaries / nodes |
|---|---:|---:|---|---|
|  Gurobi 13.0.1 / `euler4`  |  32  |  120 s  | 0 is a feasible solution |  bound 256; 1 node  |
|  COPT 8.0.4 / `altman`  |  32  |  120 s  | 0 is a feasible solution |  bound 156; 1 node  |

Both runs cold-started the original model. Gurobi reached a root LP value of 256 but retained substantial integer infeasibility. The objective is constant at 256, so this bound does not mean that the puzzle was solved. COPT also found no integer solution within the time limit. `altman` used only the COPT CPU solver; **GPU0 was not used**.

##  The exact destroy-and-repair of the 470 chessboard

The experiment fixed a variable on the chessboard outside the release zone; since each block can only be used once, the release zone can only rearrange/spin the pieces that were originally located in the zone. The model still retains the matching constraint on the entire 480 bar of the original MPS, objective is only used to minimize the number of changes in the feasible replenishment, without excluding any 480 / 480 replenishment.

`radius1`, `radius2` uses the Manhattan distance to a bad endpoint of 17; `top6/top8` is the complete horizontal band.

| Free zones | Release | Fixed | The results of Gurobi | Time and boundary |
|---|---:|---:|---|---|
| 10 ends on the wrong side of the bar |  17  |  239  | **infeasible( already proof)** |  1.28 s  |
|  Manhattan radius 1  |  48  |  208  | **infeasible( already proof)** |  1.57 s  |
|  Manhattan radius 2  |  75  |  181  | **infeasible( already proof)** |  1.57 s  |
| The top 6 line (with all the bad sides) |  96  |  160  | **infeasible( already proof)** |  3.39 s  |
| 8 line at the top |  128  |  128  | No solution, no feasible solution |  300.02 s; bound 36  |
| Global (for 470 variable hints only) |  256  |  0  | No solution, no feasible solution |  324.96 s; bound 32  |

An additional top-8 run used a partial MIP start. Gurobi spent all 300 seconds on single-threaded start completion in a sub-MIP and never entered the main tree, so this run is diagnostic only and is excluded from the conclusions. The top-8 run in the table was subsequently repeated without that start using 32 threads.

The exact meaning of local proof is: **does not exist when the fixed region of the chessboard is complete in motion, so that the full disc reaches 480 / 480 filling.** It cannot launch an official puzzle without a solution, nor can it launch a release zone to increase the 470 to 471 close to filling 479 because the original MPS only accepts 480 / 480.

##  Reproducible files

-  `datt256_structure.py`: flowing parse MPS and statistical exact structure.
-  `datt256_mps_bridge.py`: Restore MPS and bridge the numbering of the official piece/cell/rotation.
-  `datt256-bridge.json`: Restored bridge data.
-  `datt256_record_start.py`: solution code public Blackwood 470 Chessboard and generate MPS start.
-  `datt256-blackwood470.sol`: 256 is a rare near-feasible start with a single variable.
-  `datt256-blackwood470.json`: Chessboard, bad side and MPS variable by location
-  `exact_mps_solution_check.py`: Check the MPS lines, boundaries and integrality with the decimal exact.
-  `datt256_repair.py`: local/global exact repair experiments.
-  `datt256_copt.in`:COPT Cold start script.
-  `datt256-*.log`: Gurobi/COPT full log above.
-  `eternity2-reference/`: Reference site warehouse repository snapshot, commit `f961c29c0303141666a79aa8ffb5c60c8b6c489f`.

## material

- [MIPLIB：datt256 instance details](https://miplib.zib.de/instance_details_datt256.html)
-  [Eternity II: puzzle rules, piece set and public records ](https://eternity2.dev/puzzle/)]
- [Eternity II：records & solvers](https://eternity2.dev/research/records/)
- [Eternity II：The rigidity wall](https://eternity2.dev/research/why/rigidity-wall/)
-  [reference to source code ](https://github.com/raphael-anjou/eternity2)]

