#!/usr/bin/env python3
"""Stream the datt256 MPS and summarize its exact row/column structure."""

from __future__ import annotations

import argparse
import gzip
from collections import Counter, defaultdict
from pathlib import Path


def open_text(path: Path):
    if path.suffix == ".gz":
        return gzip.open(path, "rt", encoding="latin-1")
    return path.open(encoding="latin-1")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("--solution", type=Path)
    args = parser.parse_args()

    selected: set[str] = set()
    if args.solution:
        for raw in args.solution.read_text(encoding="utf-8").splitlines():
            tokens = raw.split()
            if len(tokens) == 2 and tokens[0].startswith("x") and float(tokens[1]) > 0.5:
                selected.add(tokens[0])

    section = ""
    row_sense: dict[str, str] = {}
    rhs: dict[str, float] = defaultdict(float)
    row_size: Counter[str] = Counter()
    row_coefficients: dict[str, Counter[float]] = defaultdict(Counter)
    special: dict[str, list[tuple[str, float]]] = defaultdict(list)
    variable_rows: dict[str, list[tuple[str, float]]] = defaultdict(list)
    watched_variables = {
        "x1", "x2", "x3", "x4", "x1021", "x1024", "x1025",
        "x2048", "x2049", "x262141", "x262144",
    }
    selected_border_invalid: list[tuple[str, float]] = []
    selected_activity: dict[str, float] = defaultdict(float)

    with open_text(args.mps) as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if tokens[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = tokens[0]
                continue
            if section == "ROWS":
                row_sense[tokens[1]] = tokens[0]
            elif section == "COLUMNS" and "'MARKER'" not in tokens:
                variable = tokens[0]
                for row, coefficient_text in zip(tokens[1::2], tokens[2::2]):
                    coefficient = float(coefficient_text)
                    if row == "obj":
                        continue
                    row_size[row] += 1
                    row_coefficients[row][coefficient] += 1
                    if row in {f"c{i}" for i in range(11073, 11078)}:
                        special[row].append((variable, coefficient))
                    if variable in watched_variables:
                        variable_rows[variable].append((row, coefficient))
                    if variable in selected:
                        selected_activity[row] += coefficient
                        if row == "c10561":
                            selected_border_invalid.append((variable, coefficient))
            elif section == "RHS":
                for row, value in zip(tokens[1::2], tokens[2::2]):
                    rhs[row] += float(value)

    signatures: Counter[tuple[str, float, int, tuple[tuple[float, int], ...]]] = Counter()
    for row, sense in row_sense.items():
        if sense == "N":
            continue
        signatures[(sense, rhs[row], row_size[row], tuple(sorted(row_coefficients[row].items())))] += 1
    print(f"rows={len(row_sense)-1}")
    for signature, count in signatures.most_common():
        sense, value, size, coefficients = signature
        print(f"count={count} sense={sense} rhs={value:g} size={size} coefficients={coefficients}")
    print("special clue rows")
    for row in (f"c{i}" for i in range(11073, 11078)):
        members = special[row]
        shown = members if len(members) <= 12 else members[:4] + [("...", float(len(members)))] + members[-4:]
        print(f"  {row}: sense={row_sense[row]} rhs={rhs[row]:g} size={row_size[row]} members={shown}")
    print("watched variables")
    for variable in sorted(watched_variables, key=lambda name: int(name[1:])):
        print(f"  {variable}: {variable_rows[variable]}")
    if selected:
        violated = [
            row for row, sense in row_sense.items()
            if sense != "N" and abs(selected_activity[row] - rhs[row]) > 1e-12
        ]
        ranges = Counter(
            "edge" if int(row[1:]) <= 10560 else
            "border" if row == "c10561" else
            "cell_or_piece" if int(row[1:]) <= 11073 else "clue"
            for row in violated
        )
        print(f"selected={len(selected)} violation_ranges={dict(ranges)}")
        print(f"selected_border_invalid={selected_border_invalid}")


if __name__ == "__main__":
    main()
