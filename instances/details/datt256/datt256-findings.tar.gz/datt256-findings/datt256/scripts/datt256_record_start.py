#!/usr/bin/env python3
"""Decode the public Blackwood 470 board into a datt256 MIP start."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from urllib.parse import parse_qs


TO_BUCAS = {
    "jef": "atojeqlgbupkfrmhcwvsnid",
    "marie": "abglqejotchmrfkpudinsvw",
    "jblackwood": "abglqejotchmrfkpudinsvw",
}


def rotate(edges: tuple[int, int, int, int], rotation: int) -> tuple[int, int, int, int]:
    r = rotation & 3
    return tuple(edges[(index + 4 - r) % 4] for index in range(4))  # type: ignore[return-value]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("official_json", type=Path)
    parser.add_argument("known_boards_ts", type=Path)
    parser.add_argument("bridge_json", type=Path)
    parser.add_argument("--board-id", default="Joshua_Blackwood_470")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--metadata-output", type=Path)
    args = parser.parse_args()

    official = json.loads(args.official_json.read_text(encoding="utf-8"))
    bridge = json.loads(args.bridge_json.read_text(encoding="utf-8"))
    pieces = [tuple(map(int, piece)) for piece in official["pieces"]]
    source = args.known_boards_ts.read_text(encoding="utf-8")
    pattern = rf'"id":\s*"{re.escape(args.board_id)}".*?"params":\s*"([^"]+)"'
    match = re.search(pattern, source, flags=re.DOTALL)
    if not match:
        raise SystemExit(f"board {args.board_id!r} not found")
    params = {key: values[0] for key, values in parse_qs(match.group(1)).items()}
    letters = params["board_edges"]
    order = params.get("motifs_order")
    translation = TO_BUCAS.get(order or "")

    cells: list[tuple[int, int, int, int]] = []
    for position in range(256):
        four = letters[4 * position : 4 * position + 4]
        values = []
        for char in four:
            code = ord(char) - ord("a")
            if translation:
                code = ord(translation[code]) - ord("a")
            values.append(code)
        cells.append(tuple(values))  # type: ignore[arg-type]

    lookup: dict[tuple[int, int, int, int], tuple[int, int]] = {}
    for piece_id, piece in enumerate(pieces):
        for rotation in range(4):
            oriented = rotate(piece, rotation)
            if oriented in lookup:
                raise ValueError(f"piece patterns are not unique: {oriented}")
            lookup[oriented] = (piece_id, rotation)

    board: list[tuple[int, int]] = []
    for position, cell in enumerate(cells):
        if cell not in lookup:
            raise ValueError(f"cell {position} is not an official piece: {cell}")
        board.append(lookup[cell])
    if len({piece_id for piece_id, _ in board}) != 256:
        raise ValueError("record board does not use every official piece exactly once")

    mismatches: list[tuple[int, int, int, int]] = []
    score = 0
    for row in range(16):
        for column in range(16):
            position = 16 * row + column
            here = cells[position]
            if column + 1 < 16:
                other = cells[position + 1]
                if here[1] == other[3] and here[1] != 0:
                    score += 1
                else:
                    mismatches.append((position, position + 1, here[1], other[3]))
            if row + 1 < 16:
                other = cells[position + 16]
                if here[2] == other[0] and here[2] != 0:
                    score += 1
                else:
                    mismatches.append((position, position + 16, here[2], other[0]))

    selected: list[str] = []
    for site_position, (piece_id, site_rotation) in enumerate(board):
        mps_position = int(bridge["site_position_to_q"][site_position])
        # datt256 numbers rotations counter-clockwise, while the site numbers
        # them clockwise.  The bridge offset describes MPS rotation zero.
        mps_rotation = (int(bridge["rotation_offset"][piece_id]) - site_rotation) & 3
        variable_index = piece_id * 1024 + mps_position * 4 + mps_rotation + 1
        selected.append(f"x{variable_index}")

    with args.output.open("w", encoding="utf-8") as handle:
        handle.write("=obj= 256\n")
        for variable in selected:
            handle.write(f"{variable} 1\n")
    if args.metadata_output:
        metadata = {
            "board_id": args.board_id,
            "score": score,
            "mismatch_edges": mismatches,
            "mps_variable_by_site_position": selected,
            "piece_rotation_by_site_position": board,
        }
        args.metadata_output.write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")

    starter = board.index((138, 0)) if (138, 0) in board else -1
    print(f"board={args.board_id} score={score}/480 mismatches={len(mismatches)}")
    print(f"official_piece_139_site_position={starter}")
    for watched_piece in (0, 1, 2, 3, 138):
        located = next((position, rotation) for position, (piece, rotation) in enumerate(board) if piece == watched_piece)
        print(f"piece={watched_piece + 1} site_position={located[0]} site_rotation={located[1]}")
    print(f"mps_starter_variable_present={'x141795' in selected}")
    print(f"mismatch_edges={mismatches}")
    print(f"wrote={args.output} selected_variables={len(selected)}")
    if args.metadata_output:
        print(f"metadata={args.metadata_output}")


if __name__ == "__main__":
    main()
