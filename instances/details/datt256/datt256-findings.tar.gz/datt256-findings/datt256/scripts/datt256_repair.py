#!/usr/bin/env python3
"""Exact destroy-and-repair of the public Blackwood 470 board in datt256."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import gurobipy as gp


def expand(positions: set[int], radius: int) -> set[int]:
    result: set[int] = set()
    for position in positions:
        row, column = divmod(position, 16)
        for other_row in range(16):
            for other_column in range(16):
                if abs(row - other_row) + abs(column - other_column) <= radius:
                    result.add(16 * other_row + other_column)
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("metadata", type=Path)
    parser.add_argument(
        "--region",
        choices=("endpoints", "radius1", "radius2", "top6", "top8", "top10", "top12", "global"),
        required=True,
    )
    parser.add_argument("--seconds", type=float, default=120.0)
    parser.add_argument("--threads", type=int, default=32)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--result", type=Path, required=True)
    args = parser.parse_args()

    metadata = json.loads(args.metadata.read_text(encoding="utf-8"))
    mismatch_endpoints = {
        int(position)
        for edge in metadata["mismatch_edges"]
        for position in edge[:2]
    }
    if args.region == "endpoints":
        released = mismatch_endpoints
    elif args.region == "radius1":
        released = expand(mismatch_endpoints, 1)
    elif args.region == "radius2":
        released = expand(mismatch_endpoints, 2)
    elif args.region == "top6":
        released = set(range(6 * 16))
    elif args.region == "top8":
        released = set(range(8 * 16))
    elif args.region == "top10":
        released = set(range(10 * 16))
    elif args.region == "top12":
        released = set(range(12 * 16))
    else:
        released = set(range(16 * 16))

    selected_names = list(metadata["mps_variable_by_site_position"])
    model = gp.read(str(args.mps))
    model.update()
    selected_variables = [model.getVarByName(name) for name in selected_names]
    if any(variable is None for variable in selected_variables):
        raise ValueError("record start contains a variable absent from the MPS")

    fixed = 0
    for site_position, variable in enumerate(selected_variables):
        assert variable is not None
        if site_position not in released:
            variable.LB = 1.0
            fixed += 1
        else:
            variable.VarHintVal = 1.0
            variable.VarHintPri = 10

    # Among exact completions, prefer one changing as few released cells as
    # possible.  This does not exclude any feasible repair.
    model.setObjective(
        len(released) - gp.quicksum(selected_variables[position] for position in released),
        gp.GRB.MINIMIZE,
    )
    model.Params.LogFile = str(args.log)
    model.Params.TimeLimit = args.seconds
    model.Params.Threads = args.threads
    model.Params.MIPFocus = 1
    model.Params.Presolve = 2
    model.Params.Heuristics = 0.5
    model.Params.NoRelHeurTime = min(20.0, args.seconds / 5.0)
    model.Params.SolutionLimit = 1
    print(
        f"region={args.region} mismatch_endpoints={len(mismatch_endpoints)} "
        f"released_cells={len(released)} fixed_cells={fixed}"
    )
    print(f"released_site_positions={sorted(released)}")
    model.optimize()

    if model.SolCount:
        model.write(str(args.result))
        changed = sum(
            1
            for position in released
            if selected_variables[position].X < 0.5
        )
        print(
            f"FOUND exact repair objective_changes={model.ObjVal:g} "
            f"changed_record_cells={changed} status={model.Status}"
        )
    elif model.Status == gp.GRB.INFEASIBLE:
        print(f"PROVED no exact repair in region={args.region}")
    else:
        print(
            f"UNRESOLVED region={args.region} status={model.Status} "
            f"nodes={model.NodeCount:g} bound={model.ObjBound:g}"
        )


if __name__ == "__main__":
    main()
