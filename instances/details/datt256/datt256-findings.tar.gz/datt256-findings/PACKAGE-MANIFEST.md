# Package manifest: datt256

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 19
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/datt256-blackwood470.json`
- `artifacts/datt256-bridge.json`
- `logs/datt256-copt-baseline.log`
- `logs/datt256-gurobi-baseline.log`
- `logs/datt256-repair-endpoints.log`
- `logs/datt256-repair-global.log`
- `logs/datt256-repair-radius1.log`
- `logs/datt256-repair-radius2.log`
- `logs/datt256-repair-top6.log`
- `logs/datt256-repair-top8-main.log`
- `logs/datt256-repair-top8-partial-start.log`
- `reports/datt256-study.md`
- `scripts/datt256_copt.in`
- `scripts/datt256_mps_bridge.py`
- `scripts/datt256_record_start.py`
- `scripts/datt256_repair.py`
- `scripts/datt256_structure.py`
- `solutions/datt256-blackwood470.sol`

## Excluded files

- `input/datt256.mps.gz (7901054 bytes; raw benchmark input; sha256 f2bdb0696291dee491979ae76a98862a1a5c17b305ed9e857485931809571aa1)`
