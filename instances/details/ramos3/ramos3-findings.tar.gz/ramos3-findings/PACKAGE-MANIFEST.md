# Package manifest: ramos3

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 15
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/exact-check-summary.txt`
- `artifacts/radius3-exhaustive-certificate.json`
- `artifacts/structure-and-solution-audit.json`
- `logs/copt_global_launcher.out`
- `logs/gurobi_global_launcher.out`
- `logs/gurobi_local_r5_launcher.out`
- `logs/gurobi_local_r7_launcher.out`
- `logs/gurobi_local_r9_launcher.out`
- `reports/ramos3-study-zh.md`
- `scripts/analyze_structure.py`
- `scripts/gurobi_experiment.py`
- `scripts/prove_radius3.py`
- `solutions/official-186.sol`
- `solutions/official-186.sol.gz`

## Excluded files

- `input/ramos3.mps.gz (129861 bytes; raw benchmark input; sha256 2d2d27fa5371defa54ff0d5899ef84e3a56c79c321815e6bfed5d5e3a16effe2)`
