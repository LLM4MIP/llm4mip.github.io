#  `ramos3` Structural analysis and solve experiments

## Conclusion

This study neither found a cover below 186 nor proved that 186 is globally optimal. The official 186
The solution has undergone two separate checks: one set based on MPS with 80 bit decimal precision recalculation, and the other set based on MPS.
The three-point Hamming geometry checks that were recovered; both were zero defaulted.

```text
156 <= OPT <= 186, and 186 solution strictly locally optimal within the original binary vector Hamming radius 7.
```

Radius 9 within 300 seconds no objective solution greater than or equal to 185 was found, but not closed
proof.

##  Real problems recovered from MPS

This instance is not an unstructured ordinary set coverage.
`2187 = 3^7`. After writing the `x_(i+1)` number `i` as a seven-digit three-dimensional vector, the `i+1`
The line coincidentally consists of all the variables with a Hamming distance of not more than 1 with vector `i`.

```text
Select as few centers as possible in F_3 ^ 7 so that the Hamming distance from all points to a certain center is as much as 1.
```

This is the classical ternary covering-code/football-pool problem `K_3(7,1)`. Each radius-1 ball contains
`1 + 7*2 = 15` points, all 2,187 balls and all 2,187 balls have been paired one by one.
The wrong number is 0.

A simple ball covering the lower bound is `ceil(2187/15)=146`. Kéri's cover code table gives a stronger strict.
The lower bound 156; 2026's latest SDP work by Gijswijt Jenkins Polak improved several adjacent parameters, including:
However, there was no report of `K_3(7,1)` being higher than the new range of 156.
`156 <= OPT <= 186`, rather than the weaker solver lower bound of 145.8–147.

##  Structure of 186 solution

Official solution The number of times a point in 2,187 is covered is as follows:

| Number of times covered |  Point count |
|---:|---:|
| 1 | 1,686 |
| 2 | 444 |
| 3 | 12 |
| 4 | 45 |

The cumulative repeat coverage is 603. Each of the 186 centers has a private point, with at least one 4 and a maximum of one 13.
So any individual deletion would immediately result in uncovered, which is the explanation for why ordinary 1 - flip local searches.
invalid.

Further enumeration All `C(186,2)=17,205` decentralized combinations: each time 8 to 26 is left.
Uncovered points, and no new centers can be repaired at once. So all 2 deleted plus 1 aluminum improvements were removed.
It has been awarded the 3 certificate.

##  Solver experiments

###  Global baseline

-  Gurobi 13.0.1: 64 CPU thread, 600 second, official solution as MIP start; preferably solution 186,
147, 23 nodes at the end of the line.
-  COPT 8.0.4: 64 CPU thread, 600 second, official solution as the initial solution; best solution 186, final boundary
145.8, 17 is a single node.

Neither found 185. The COPT experiment used only the CPU and did not use Altman's GPU0.
These two boundaries also show that it is difficult to keep up with the code theory of the lower bound by simply extending the same general branch-and-bound.

###  Local branch certificate

Add to the center of the official bit vector `z`

```text
sum(z_i=1)(1-x_i) + sum(z_i=0)x_i <= radius
sum_i x_i <= 185
```

The results are as follows:

|  Radius |  result |
|---:|---|
|  5  | Root relaxation infeasible , 1.73 seconds strict proof |
|  7  | 47.53 second, 45,185 second pure form mutation, strict proof |
|  9  | 300 second no solution, 25 single node, not yet closed node |

Therefore, the maximum proof radius is 7. If a solution 185 exists, it is at least as different as the current solution 8.
Bit; small-scale exchanges won't find it.

##  How to Keep Searching for the Best

Primal bound directions should be used for large neighborhoods that span the radius of 7 rather than continuing with 1 -flip or 2 -for- 1:

1.  WLS with adaptive penalty options used by official solutions and explicitly associated with variables;
2.  Destroy/repair in three-digit space, removing a series of adjacent or repeatedly overlapping centers;
3.  Fix the smallest problem after destroy with CP-SAT/MIP only exact;
4.  Using coordinate replacement and symbol replacement for each coordinate, the results of each search are standardized and redirected.

The lower bound / optimality proof direction should use the orbital compression SDP of the Hamming association scheme to combine
An integer is an inequality and a symmetrical branch. Any non-empty overlay code can be transformed into a center by an equal distance.
`0000000`, can first fix the center; then compress the rest of the center by its stabilizing subgroup.
In comparison, this route is more likely to advance the theoretical community of 156 to 186.

## material

-  [MIPLIB `ramos3` page ](https://miplib.zib.de/instance_details_ramos3.html)]
-  [Kéri covers the code boundary table ](https://old.sztaki.hu/~keri/codes/index.htm)
- [Gijswijt–Polak，Semidefinite lower bounds for covering codes](https://arxiv.org/abs/2504.01932)
-  [Umetani, WLS/variable associated local search for ](https://doi.org/10.1016/j.ejor.2017.05.025)]
