from __future__ import annotations

import argparse
import json
import time
from collections import Counter, defaultdict
from pathlib import Path

import gurobipy as gp
import numpy as np


class UnionFind:
    def __init__(self, n: int):
        self.parent = np.arange(n, dtype=np.int32)
        self.size = np.ones(n, dtype=np.int32)

    def find(self, x: int) -> int:
        parent = self.parent
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = int(parent[x])
        return x

    def union(self, a: int, b: int) -> None:
        ra, rb = self.find(a), self.find(b)
        if ra == rb:
            return
        if self.size[ra] < self.size[rb]:
            ra, rb = rb, ra
        self.parent[rb] = ra
        self.size[ra] += self.size[rb]


def quantiles(values: np.ndarray) -> dict:
    if len(values) == 0:
        return {}
    return {
        "min": int(values.min()),
        "p25": float(np.quantile(values, 0.25)),
        "median": float(np.quantile(values, 0.5)),
        "p75": float(np.quantile(values, 0.75)),
        "p90": float(np.quantile(values, 0.9)),
        "p99": float(np.quantile(values, 0.99)),
        "max": int(values.max()),
    }


def frequent_numeric(values: np.ndarray, digits: int = 10, limit: int = 20) -> list[dict]:
    counts = Counter(round(float(v), digits) for v in values)
    return [{"value": value, "count": count} for value, count in counts.most_common(limit)]


def component_analysis(A, senses: np.ndarray, row_degree: np.ndarray, threshold: int) -> tuple[dict, np.ndarray]:
    nvars = A.shape[1]
    uf = UnionFind(nvars)
    used_rows = np.flatnonzero((senses == "=") & (row_degree >= 2) & (row_degree <= threshold))
    touched = np.zeros(nvars, dtype=bool)
    for ridx in used_rows:
        cols = A.indices[A.indptr[ridx] : A.indptr[ridx + 1]]
        if len(cols) < 2:
            continue
        first = int(cols[0])
        touched[cols] = True
        for col in cols[1:]:
            uf.union(first, int(col))

    roots = np.fromiter((uf.find(i) for i in range(nvars)), dtype=np.int32, count=nvars)
    active_roots = roots[touched]
    unique, counts = np.unique(active_roots, return_counts=True)
    order = np.argsort(counts)[::-1]
    size_frequency = Counter(int(v) for v in counts)
    summary = {
        "threshold": threshold,
        "equality_rows_used": int(len(used_rows)),
        "variables_touched": int(touched.sum()),
        "active_components": int(len(unique)),
        "isolated_or_untouched_variables": int((~touched).sum()),
        "largest_component_sizes": [int(counts[i]) for i in order[:30]],
        "most_common_component_sizes": [
            {"size": size, "count": count} for size, count in size_frequency.most_common(30)
        ],
    }
    return summary, roots


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--components", type=Path, required=True)
    args = parser.parse_args()

    started = time.time()
    model = gp.read(str(args.mps))
    A = model.getA().tocsr()
    vars_ = model.getVars()
    constrs = model.getConstrs()
    senses = np.asarray([c.Sense for c in constrs])
    rhs = np.asarray([c.RHS for c in constrs], dtype=np.float64)
    row_degree = np.diff(A.indptr)
    col_degree = np.diff(A.tocsc().indptr)
    obj = np.asarray([v.Obj for v in vars_], dtype=np.float64)
    lb = np.asarray([v.LB for v in vars_], dtype=np.float64)
    ub = np.asarray([v.UB for v in vars_], dtype=np.float64)
    vtypes = np.asarray([v.VType for v in vars_])

    component_summaries = []
    roots20 = None
    for threshold in (5, 10, 20, 50):
        summary, roots = component_analysis(A, senses, row_degree, threshold)
        component_summaries.append(summary)
        if threshold == 20:
            roots20 = roots

    assert roots20 is not None
    coupling = []
    touched_component_counts = []
    for ridx in range(A.shape[0]):
        cols = A.indices[A.indptr[ridx] : A.indptr[ridx + 1]]
        if len(cols) == 0:
            ncomp = 0
        else:
            ncomp = len(set(int(roots20[c]) for c in cols))
        touched_component_counts.append(ncomp)
        if ncomp >= 3 or row_degree[ridx] >= 30:
            coupling.append(
                {
                    "row_index": ridx,
                    "name": constrs[ridx].ConstrName,
                    "sense": senses[ridx],
                    "rhs": float(rhs[ridx]),
                    "nonzeros": int(row_degree[ridx]),
                    "components_touched": int(ncomp),
                    "min_var_index": int(cols.min()) if len(cols) else None,
                    "max_var_index": int(cols.max()) if len(cols) else None,
                }
            )
    coupling.sort(key=lambda item: (item["components_touched"], item["nonzeros"]), reverse=True)

    members = defaultdict(list)
    for idx, root in enumerate(roots20):
        members[int(root)].append(idx)
    signatures = Counter()
    examples = defaultdict(list)
    component_records = []
    for indices in members.values():
        if len(indices) <= 1:
            continue
        arr = np.asarray(indices, dtype=np.int32)
        signature = (
            len(indices),
            int(np.count_nonzero(obj[arr])),
            int(np.count_nonzero(vtypes[arr] == "C")),
        )
        signatures[signature] += 1
        if len(examples[signature]) < 5:
            examples[signature].append([int(arr.min()), int(arr.max())])
        gaps = np.flatnonzero(np.diff(arr) != 1)
        first_run_end = int(arr[gaps[0]]) if len(gaps) else int(arr[-1])
        component_records.append(
            {
                "root": int(roots20[arr[0]]),
                "size": len(indices),
                "min_index": int(arr.min()),
                "max_index": int(arr.max()),
                "first_contiguous_run_end": first_run_end,
                "first_contiguous_run_size": first_run_end - int(arr.min()) + 1,
                "number_of_index_runs": int(len(gaps) + 1),
                "objective_nonzeros": int(np.count_nonzero(obj[arr])),
                "continuous_variables": int(np.count_nonzero(vtypes[arr] == "C")),
                "objective_frequency": frequent_numeric(obj[arr][obj[arr] != 0], limit=10),
            }
        )

    signature_rows = []
    for signature, count in signatures.most_common(40):
        size, obj_nz, continuous = signature
        signature_rows.append(
            {
                "component_size": size,
                "objective_nonzeros": obj_nz,
                "continuous_variables": continuous,
                "count": count,
                "index_examples": examples[signature],
            }
        )

    row_blocks = []
    for start in range(0, A.shape[0], 10000):
        stop = min(start + 10000, A.shape[0])
        block_senses = Counter(senses[start:stop])
        block_deg = row_degree[start:stop]
        row_blocks.append(
            {
                "start": start,
                "stop": stop,
                "senses": dict(block_senses),
                "degree": quantiles(block_deg),
            }
        )

    report = {
        "instance": model.ModelName,
        "matrix": {
            "rows": A.shape[0],
            "columns": A.shape[1],
            "nonzeros": int(A.nnz),
            "row_degree": quantiles(row_degree),
            "column_degree": quantiles(col_degree),
            "row_degree_frequency": [
                {"degree": degree, "count": count}
                for degree, count in Counter(int(x) for x in row_degree).most_common(30)
            ],
            "coefficient_frequency": frequent_numeric(A.data),
        },
        "variables": {
            "types": dict(Counter(vtypes)),
            "objective_nonzeros": int(np.count_nonzero(obj)),
            "objective_frequency": frequent_numeric(obj[obj != 0]),
            "lower_bound_frequency": frequent_numeric(lb),
            "finite_upper_bounds": int(np.count_nonzero(ub < gp.GRB.INFINITY)),
            "finite_upper_bound_frequency": frequent_numeric(ub[ub < gp.GRB.INFINITY]),
        },
        "constraints": {
            "senses": dict(Counter(senses)),
            "rhs_frequency": frequent_numeric(rhs),
            "row_blocks": row_blocks,
        },
        "components_from_low_degree_equalities": component_summaries,
        "threshold20_component_signatures": signature_rows,
        "threshold20_component_records_by_min_index": sorted(component_records, key=lambda x: x["min_index"]),
        "threshold20_rows_touching_multiple_components": {
            "component_count_quantiles": quantiles(np.asarray(touched_component_counts)),
            "top_rows": coupling[:100],
        },
        "runtime_seconds": time.time() - started,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.components.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    np.savez_compressed(args.components, roots_threshold20=roots20)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
