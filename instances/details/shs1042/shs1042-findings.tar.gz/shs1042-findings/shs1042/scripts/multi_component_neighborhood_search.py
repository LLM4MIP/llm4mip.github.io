from __future__ import annotations

import argparse
import gzip
import itertools
import json
import time
from collections import defaultdict
from pathlib import Path

import gurobipy as gp
import numpy as np
from gurobipy import GRB


def read_values(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix == ".gz" else open
    values = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) >= 2:
                try:
                    values[parts[0]] = float(parts[1])
                except ValueError:
                    pass
    return values


def write_solution(path: Path, variables, values: np.ndarray, objective: float) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "wt", encoding="utf-8", newline="\n") as handle:
        handle.write(f"# Objective value = {objective:.17g}\n")
        handle.write("# Multi-component neighborhood search solution.\n")
        for var, value in zip(variables, values):
            handle.write(f"{var.VarName} {float(value):.17g}\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--components", type=Path, required=True)
    parser.add_argument("--single-search", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--best-solution", type=Path, required=True)
    parser.add_argument("--time-per-neighborhood", type=float, default=5.0)
    args = parser.parse_args()

    wall_started = time.time()
    model = gp.read(str(args.mps))
    model.Params.OutputFlag = 0
    model.Params.Threads = 8
    model.Params.Presolve = 2
    model.Params.MIPFocus = 1
    model.Params.Heuristics = 0.25
    model.Params.MIPGap = 1e-9

    variables = model.getVars()
    nvars = len(variables)
    roots = np.load(args.components)["roots_threshold20"]
    supplied = read_values(args.solution)
    current = np.asarray([supplied.get(v.VarName, 0.0) for v in variables], dtype=np.float64)
    original_lb = np.asarray([v.LB for v in variables], dtype=np.float64)
    original_ub = np.asarray([v.UB for v in variables], dtype=np.float64)
    is_integer = np.asarray(
        [v.VType in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT) for v in variables], dtype=bool
    )
    current[is_integer] = np.rint(current[is_integer])

    members = defaultdict(list)
    min_to_root = {}
    for idx, root in enumerate(roots):
        members[int(root)].append(idx)
    for root, indices in members.items():
        if len(indices) > 1:
            min_to_root[min(indices)] = root

    single = json.loads(args.single_search.read_text(encoding="utf-8"))
    gap_roots = []
    for attempt in single["attempts"]:
        bound = attempt.get("bound")
        if bound is not None and attempt["before"] - bound > 1e-5:
            gap_roots.append(int(attempt["root"]))
    gap_roots = list(dict.fromkeys(gap_roots))
    truck_roots = [root for minimum, root in sorted(min_to_root.items()) if minimum >= 334876]

    groups = []
    for a, b in itertools.combinations(gap_roots, 2):
        groups.append(("gap_pair", [a, b]))
    for root in gap_roots:
        for truck in truck_roots:
            groups.append(("gap_plus_one_truck", [root, truck]))
    for root in gap_roots:
        groups.append(("gap_plus_all_trucks", [root] + truck_roots))
    groups.append(("all_gap_components", gap_roots))
    groups.append(("all_gap_plus_all_trucks", gap_roots + truck_roots))

    fixed_lb = original_lb.copy()
    fixed_ub = original_ub.copy()
    fixed_lb[is_integer] = current[is_integer]
    fixed_ub[is_integer] = current[is_integer]
    model.setAttr("LB", variables, fixed_lb.tolist())
    model.setAttr("UB", variables, fixed_ub.tolist())
    model.Params.TimeLimit = 30
    model.optimize()
    if model.SolCount == 0:
        raise RuntimeError("initial rounded solution infeasible")
    current = np.asarray(model.getAttr("X", variables), dtype=np.float64)
    incumbent = float(model.ObjVal)
    initial = incumbent

    attempts = []
    for order, (kind, group_roots) in enumerate(groups, 1):
        open_indices = np.asarray(
            sorted(
                idx
                for root in group_roots
                for idx in members[root]
                if is_integer[idx]
            ),
            dtype=np.int32,
        )
        open_vars = [variables[int(idx)] for idx in open_indices]
        model.setAttr("LB", open_vars, original_lb[open_indices].tolist())
        model.setAttr("UB", open_vars, original_ub[open_indices].tolist())
        model.Params.TimeLimit = args.time_per_neighborhood
        before = incumbent
        run_started = time.time()
        model.optimize()
        candidate = float(model.ObjVal) if model.SolCount else None
        bound = float(model.ObjBound) if model.IsMIP else None
        accepted = candidate is not None and candidate < incumbent - 1e-7
        if accepted:
            current = np.asarray(model.getAttr("X", variables), dtype=np.float64)
            current[is_integer] = np.rint(current[is_integer])
            incumbent = candidate
        model.setAttr("LB", open_vars, current[open_indices].tolist())
        model.setAttr("UB", open_vars, current[open_indices].tolist())
        minimum_indices = [min(members[root]) for root in group_roots]
        attempts.append(
            {
                "order": order,
                "kind": kind,
                "roots": group_roots,
                "minimum_indices": minimum_indices,
                "components_opened": len(group_roots),
                "integer_variables_opened": int(len(open_indices)),
                "before": before,
                "candidate": candidate,
                "bound": bound,
                "local_gap": None if bound is None else before - bound,
                "accepted": accepted,
                "improvement": before - incumbent,
                "status": int(model.Status),
                "nodes": float(model.NodeCount) if model.IsMIP else 0.0,
                "runtime_seconds": time.time() - run_started,
            }
        )
        print(
            f"{order}/{len(groups)} {kind} mins={minimum_indices} open={len(open_indices)} "
            f"candidate={candidate} bound={bound} accepted={accepted}"
        )

    model.Params.TimeLimit = 30
    model.optimize()
    if model.SolCount:
        final_values = np.asarray(model.getAttr("X", variables), dtype=np.float64)
        final_values[is_integer] = np.rint(final_values[is_integer])
        if model.ObjVal <= incumbent + 1e-7:
            current = final_values
            incumbent = float(model.ObjVal)
    write_solution(args.best_solution, variables, current, incumbent)

    report = {
        "instance": model.ModelName,
        "method": "multi-component exact MIP neighborhoods",
        "gap_component_minimum_indices": [min(members[root]) for root in gap_roots],
        "truck_component_minimum_indices": [min(members[root]) for root in truck_roots],
        "neighborhood_count": len(groups),
        "time_per_neighborhood": args.time_per_neighborhood,
        "initial_objective": initial,
        "final_objective": incumbent,
        "total_improvement": initial - incumbent,
        "accepted_improvements": sum(item["accepted"] for item in attempts),
        "attempts": attempts,
        "wall_runtime_seconds": time.time() - wall_started,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
