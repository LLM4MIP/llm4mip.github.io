from __future__ import annotations

import argparse
import gzip
import json
import math
import time
from pathlib import Path

import gurobipy as gp
import numpy as np
from gurobipy import GRB


def read_solution(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix == ".gz" else open
    values: dict[str, float] = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) >= 2:
                try:
                    values[parts[0]] = float(parts[1])
                except ValueError:
                    pass
    return values


def write_solution(path: Path, variables, values: np.ndarray, objective: float) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "wt", encoding="utf-8", newline="\n") as handle:
        handle.write(f"# Objective value = {objective:.17g}\n")
        handle.write("# Improving truck-schedule local-branching solution.\n")
        for var, value in zip(variables, values):
            handle.write(f"{var.VarName} {float(value):.17g}\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--best-solution", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--radius", type=int, required=True)
    parser.add_argument("--minimum-distance", type=int, default=1)
    parser.add_argument("--improvement-epsilon", type=float, default=1e-5)
    parser.add_argument("--time-limit", type=float, default=180.0)
    parser.add_argument("--threads", type=int, default=16)
    parser.add_argument("--mip-focus", type=int, default=3)
    parser.add_argument("--cuts", type=int, default=3)
    parser.add_argument("--dual-reductions", type=int, choices=(0, 1), default=1)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.log.parent.mkdir(parents=True, exist_ok=True)
    wall_started = time.time()
    model = gp.read(str(args.mps))
    original_variables = list(model.getVars())
    original_is_integer = np.asarray(
        [v.VType in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT) for v in original_variables]
    )
    supplied = read_solution(args.solution)
    incumbent_values = np.asarray(
        [supplied.get(v.VarName, 0.0) for v in original_variables], dtype=np.float64
    )
    incumbent_objective = float(
        sum(v.Obj * value for v, value in zip(original_variables, incumbent_values))
    )

    mismatch_terms = []
    promoted_binaries = 0
    encoded_ternaries = 0
    for var in original_variables:
        if var.VType not in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT):
            continue
        lower = math.ceil(var.LB - 1e-9)
        upper = math.floor(var.UB + 1e-9)
        value = int(round(supplied.get(var.VarName, 0.0)))
        if lower == 0 and upper == 1:
            var.VType = GRB.BINARY
            mismatch_terms.append(var if value == 0 else 1 - var)
            promoted_binaries += 1
        elif lower == 0 and upper == 2:
            selectors = model.addVars(range(3), vtype=GRB.BINARY, name=f"ts_{var.VarName}")
            model.addConstr(gp.quicksum(selectors[k] for k in range(3)) == 1)
            model.addConstr(var == selectors[1] + 2 * selectors[2])
            var.VType = GRB.CONTINUOUS
            mismatch_terms.append(1 - selectors[value])
            encoded_ternaries += 1

    distance = gp.quicksum(mismatch_terms)
    model.addConstr(distance >= args.minimum_distance, name="truck_schedule_distance_lower")
    model.addConstr(distance <= args.radius, name="truck_schedule_distance_upper")
    model.addConstr(
        model.getObjective() <= incumbent_objective - args.improvement_epsilon,
        name="strict_incumbent_improvement",
    )
    model.update()

    model.Params.TimeLimit = args.time_limit
    model.Params.Threads = args.threads
    model.Params.Presolve = 2
    model.Params.MIPFocus = args.mip_focus
    model.Params.Heuristics = 0.05 if args.mip_focus == 3 else 0.5
    model.Params.Cuts = args.cuts
    model.Params.MIPGap = 1e-9
    model.Params.FeasibilityTol = 1e-9
    model.Params.IntFeasTol = 1e-9
    model.Params.DualReductions = args.dual_reductions
    model.Params.LogFile = str(args.log)
    model.optimize()

    candidate = float(model.ObjVal) if model.SolCount else None
    if model.SolCount:
        values = np.asarray(model.getAttr("X", original_variables), dtype=np.float64)
        values[original_is_integer] = np.rint(values[original_is_integer])
        write_solution(args.best_solution, original_variables, values, candidate)
    report = {
        "instance": model.ModelName,
        "method": "local branching on the 1728 small-domain truck variables",
        "radius": args.radius,
        "distance_lower_bound": args.minimum_distance,
        "improvement_epsilon": args.improvement_epsilon,
        "incumbent_objective": incumbent_objective,
        "promoted_binary_variables": promoted_binaries,
        "encoded_ternary_variables": encoded_ternaries,
        "candidate_objective": candidate,
        "status": int(model.Status),
        "status_name": {
            GRB.OPTIMAL: "OPTIMAL",
            GRB.INFEASIBLE: "INFEASIBLE",
            GRB.INF_OR_UNBD: "INF_OR_UNBD",
            GRB.TIME_LIMIT: "TIME_LIMIT",
            GRB.INTERRUPTED: "INTERRUPTED",
        }.get(model.Status, "OTHER"),
        "best_bound": float(model.ObjBound) if model.IsMIP else None,
        "node_count": float(model.NodeCount) if model.IsMIP else None,
        "solver_runtime_seconds": float(model.Runtime),
        "wall_runtime_seconds": time.time() - wall_started,
        "time_limit": args.time_limit,
        "threads": args.threads,
        "mip_focus": args.mip_focus,
        "cuts": args.cuts,
        "dual_reductions": args.dual_reductions,
    }
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
