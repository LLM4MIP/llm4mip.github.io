from __future__ import annotations

import argparse
import gzip
import math
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def read_values(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix == ".gz" else open
    values: dict[str, float] = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            if line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) >= 2:
                try:
                    values[parts[0]] = float(parts[1])
                except ValueError:
                    pass
    return values


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    model = gp.read(str(args.mps))
    values = read_values(args.solution)
    repaired = []
    changed = []
    for var in model.getVars():
        old = values.get(var.VarName, 0.0)
        new = old
        if var.VType in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT):
            new = float(round(old))
        if new != old:
            changed.append((var.VarName, old, new))
        repaired.append((var, new))
    objective = model.ObjCon + math.fsum(var.Obj * value for var, value in repaired)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    opener = gzip.open if args.output.suffix == ".gz" else open
    with opener(args.output, "wt", encoding="utf-8", newline="\n") as handle:
        handle.write(f"# Objective value = {objective:.17g}\n")
        handle.write("# Integer variables rounded from the official MIPLIB solution.\n")
        for var, value in repaired:
            handle.write(f"{var.VarName} {value:.17g}\n")
    print(f"objective={objective:.17g}")
    print(f"changed_integer_values={len(changed)}")
    for name, old, new in changed[:50]:
        print(f"{name}: {old:.17g} -> {new:.17g}")


if __name__ == "__main__":
    main()
