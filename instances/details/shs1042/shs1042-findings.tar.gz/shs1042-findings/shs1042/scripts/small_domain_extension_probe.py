from __future__ import annotations

import argparse
import gzip
import json
import math
import time
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def read_solution(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix == ".gz" else open
    values: dict[str, float] = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) < 2:
                continue
            try:
                values[parts[0]] = float(parts[1])
            except ValueError:
                pass
    return values


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--time-limit", type=float, default=240.0)
    parser.add_argument("--threads", type=int, default=16)
    parser.add_argument("--max-domain-width", type=int, default=30)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.log.parent.mkdir(parents=True, exist_ok=True)
    wall_started = time.time()
    model = gp.read(str(args.mps))
    original_variables = list(model.getVars())
    supplied = read_solution(args.solution)

    binary_promotions = 0
    encoded_variables = 0
    added_binaries = 0
    added_constraints = 0
    selector_starts: list[tuple[gp.Var, float]] = []

    for var in original_variables:
        if var.VType not in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT):
            continue
        if var.LB <= -GRB.INFINITY or var.UB >= GRB.INFINITY:
            continue
        lower = math.ceil(var.LB - 1e-9)
        upper = math.floor(var.UB + 1e-9)
        width = upper - lower
        value = round(supplied.get(var.VarName, 0.0))
        if lower == 0 and upper == 1 and var.VType != GRB.BINARY:
            var.VType = GRB.BINARY
            binary_promotions += 1
        elif 1 < width <= args.max_domain_width:
            selectors = model.addVars(
                range(lower, upper + 1),
                vtype=GRB.BINARY,
                name=f"sd_{var.VarName}",
            )
            model.addConstr(
                gp.quicksum(selectors[k] for k in range(lower, upper + 1)) == 1,
                name=f"sd_choose_{var.VarName}",
            )
            model.addConstr(
                var == gp.quicksum(k * selectors[k] for k in range(lower, upper + 1)),
                name=f"sd_link_{var.VarName}",
            )
            var.VType = GRB.CONTINUOUS
            encoded_variables += 1
            added_binaries += width + 1
            added_constraints += 2
            for k in range(lower, upper + 1):
                selector_starts.append((selectors[k], 1.0 if k == value else 0.0))

    model.update()
    for var in model.getVars():
        if var.VarName in supplied:
            value = supplied[var.VarName]
            if var.VType in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT):
                value = round(value)
            var.Start = value
    for selector, value in selector_starts:
        selector.Start = value

    model.Params.TimeLimit = args.time_limit
    model.Params.Threads = args.threads
    model.Params.Presolve = 2
    model.Params.MIPFocus = 3
    model.Params.Cuts = 3
    model.Params.Symmetry = 2
    model.Params.Heuristics = 0.05
    model.Params.LogFile = str(args.log)
    model.optimize()

    report = {
        "instance": model.ModelName,
        "method": "natural-number one-hot extension for bounded integer variables",
        "max_domain_width": args.max_domain_width,
        "binary_promotions": binary_promotions,
        "encoded_original_integer_variables": encoded_variables,
        "added_binary_variables": added_binaries,
        "added_constraints": added_constraints,
        "status": int(model.Status),
        "status_name": {
            GRB.OPTIMAL: "OPTIMAL",
            GRB.INFEASIBLE: "INFEASIBLE",
            GRB.TIME_LIMIT: "TIME_LIMIT",
            GRB.NODE_LIMIT: "NODE_LIMIT",
            GRB.INTERRUPTED: "INTERRUPTED",
        }.get(model.Status, "OTHER"),
        "solution_count": int(model.SolCount),
        "objective": float(model.ObjVal) if model.SolCount else None,
        "best_bound": float(model.ObjBound) if model.IsMIP else None,
        "relative_gap": float(model.MIPGap) if model.IsMIP and model.SolCount else None,
        "node_count": float(model.NodeCount) if model.IsMIP else None,
        "solver_runtime_seconds": float(model.Runtime),
        "wall_runtime_seconds": time.time() - wall_started,
        "work_units": float(model.Work),
        "threads": args.threads,
        "time_limit": args.time_limit,
    }
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
