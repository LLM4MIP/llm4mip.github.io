# allcolor58: exact objective-42 certificate

Date: 2026-09-05
Disposition: **solved locally; the optimum is exactly 42.**

## 1. Certificate and lower bound

The new sparse MPS solution is
`solutions/allcolor58-42-flex.sol`.  It has objective 42 and is feasible for
the unmodified official `allcolor58.mps.gz`.

The matching lower bound is elementary but model-specific.  Every allowed
configuration has even capacity (4, 6, 8, or 10), and every store assignment
count is integral.  Hence the total number of units shipped to each store is
even.  Exactly 42 of the 58 stores have odd total demand.  At each such store,
the shipment-demand balance therefore has nonzero odd parity.  The MPS charges
one per overstock unit and ten per understock unit, so each odd-demand store
costs at least one.  The 42 stores give the disjoint lower bound

\[
  \operatorname{OPT}(\texttt{allcolor58})\geq 42.
\]

The witness has no understock, exactly one permitted overstock unit at each of
those 42 stores, and no discrepancy at the other 16 stores.  Thus it attains
the lower bound and proves

\[
  \boxed{\operatorname{OPT}(\texttt{allcolor58})=42}.
\]

## 2. Human-readable configuration certificate

Products are numbered 1--24.  The 14 configuration rows in the witness are:

| row | capacity | nonzero product counts |
|---:|---:|---|
| 1 | 8 | `19:1, 20:1, 21:1, 22:2, 23:2, 24:1` |
| 2 | 4 | `5:2, 10:1, 11:1` |
| 3 | 6 | `1:1, 2:1, 7:1, 8:2, 12:1` |
| 4 | 4 | `4:1, 9:1, 16:1, 17:1` |
| 5 | 10 | `1:1, 2:1, 4:2, 7:1, 8:2, 10:1, 11:1, 12:1` |
| 6 | 8 | `19:1, 20:1, 21:2, 22:2, 23:1, 24:1` |
| 7 | 6 | `4:1, 9:2, 14:1, 15:1, 16:1` |
| 8 | 8 | `19:1, 20:1, 21:1, 22:3, 23:1, 24:1` |
| 9 | 10 | `2:1, 3:2, 4:1, 6:1, 9:4, 10:1` |
| 10 | 10 | `2:1, 6:1, 13:1, 14:2, 15:3, 17:1, 18:1` |
| 11 | 8 | `4:2, 9:2, 16:4` |
| 12 | 4 | `4:1, 11:1, 16:1, 17:1` |
| 13 | 4 | `3:2, 10:1, 11:1` |
| 14 | 4 | `4:1, 10:1, 16:1, 17:1` |

The sparse `.sol` contains all nonzero store multipliers and the deterministic
binary/product-linearization auxiliaries needed by the original MPS.

## 3. Search chronology

This was not found by running the 84,376-variable MIP directly.
`allcolor58_compact_search.cpp` uses the separable factorization

\[
  d_s+e_s=\sum_{b=1}^{14}x_{bs}y_b,
  \qquad x_{bs}\in\{0,\ldots,7\},
\]

where `e_s=0` for even-demand stores and is one allowed product unit for
odd-demand stores.  For a fixed capacity multiset it enumerates all assignment
count vectors with the required store total, hashes their 24-dimensional
shipments exactly, and prices an entire configuration row from residual target
equations.  It uses integer arithmetic throughout; randomness only chooses
among equal-score configurations and row orders.

Starting from the public optimal `allcolor10` ID-4 configurations, fixed-
capacity coordinate search with seed 17 improved exact target coverage from
21 to 55 of 58 stores in 53 seconds.  The remaining stores were 6, 8, and 33.
A diagnostic fixed-capacity residual sweep covered all 91 labeled row pairs;
none of its exact target-induced candidate pairs repaired all three missing
stores.  This is a local-neighborhood result about that 55-store state, not a
global infeasibility claim.

Allowing the replaced row to choose any capacity in `{4,6,8,10}` was decisive.
The flex search started from the preserved 55-store matrix, used seed 271828,
and improved 55 to 56 to 57 to 58 in 40 seconds.  It reached 58 on pass 7 when
row 9 changed to the capacity-10 configuration shown above.  The 53- and
40-second wall times are the preserved log birth-to-modification intervals.

As a separate bounded experiment, 97 distinct configurations collected from
the six public `allcolor58` solutions, public `allcolor10` ID 4, and the
55-store state were placed in a compact selection MIP (5,891 variables and
7,061 constraints).  Gurobi 13.0.2, `Threads=2`, `TimeLimit=600`, seed
20260905, proved that restricted dictionary infeasible in 3.22 seconds and one
node.  This negative result only rules out that finite dictionary.

## 4. Independent exact validation

Two validators were used on the emitted witness.

1. `validate_allcolor58_solution.py` parses the raw compressed MPS and the
   sparse solution using exact rational arithmetic.  It checked all 84,376
   variable names, bounds, and integrality conditions and all 197,154 row
   activities, senses, and right-hand sides.  It found zero unknown variables,
   zero bound violations, zero integrality violations, zero row violations,
   maximum row violation zero, and objective exactly 42.
2. Independently written `audit_allcolor58_witness.py` repeated the complete
   MPS check with `Decimal` arithmetic (517,968 parsed matrix entries) and also
   reconstructed the `y`, `x`, shipment, overstock, and understock semantics.
   It found capacities `[8,4,6,4,10,8,6,8,10,10,8,4,4,4]`, 42 total
   overstock, zero understock, 16 exact stores, and 42 stores with exactly one
   mismatching product.  All 58 attain their parity minimum.

Finally, Gurobi loaded the sparse witness as a partial MIP start with
`Threads=1`, `NodeLimit=0`, `SolutionLimit=1`, and `TimeLimit=60`.  It completed
the omitted zero variables, accepted objective 42 in 0.03 seconds, explored
zero nodes and zero simplex iterations, and stopped after 0.04 seconds.  The
Gurobi-written result was again passed through the exact rational validator.
The solver check is corroboration; the exact MPS audit is the primary
feasibility evidence.

## 5. Reproduction

From the repository root:

```sh
clang++ -O3 -std=c++17 instances/allcolor58/scripts/compact_search.cpp \
  -lz -o /tmp/allcolor58_compact_search

/tmp/allcolor58_compact_search \
  instances/allcolor58/input/allcolor58.mps.gz \
  instances/allcolor58/artifacts/objective-42-search-seed.tsv \
  instances/allcolor58/solutions/objective-42-exact.sol \
  271828 18 flexsearch

python3 instances/allcolor58/scripts/validate_solution.py \
  instances/allcolor58/input/allcolor58.mps.gz \
  instances/allcolor58/solutions/objective-42-exact.sol

python3 instances/allcolor58/scripts/audit_witness.py \
  instances/allcolor58/input/allcolor58.mps.gz \
  instances/allcolor58/solutions/objective-42-exact.sol \
  --output instances/allcolor58/artifacts/objective-42-independent-audit.json

gurobi_cl Threads=1 TimeLimit=60 NodeLimit=0 SolutionLimit=1 \
  InputFile=instances/allcolor58/solutions/objective-42-exact.sol \
  ResultFile=instances/allcolor58/solutions/objective-42-gurobi.sol \
  LogFile=instances/allcolor58/logs/allcolor58-42_gurobi_start_validation.log \
  instances/allcolor58/input/allcolor58.mps.gz
```

Key artifacts and SHA-256 values:

```text
official model                           cecf7b32c4333a8cf3a838387afb8d00092067c3e56bd72b48b031df66a58397
objective-42 sparse witness              73d5c1f5504e552298467399d2cfb1b8dba79c9703afd8e339f65a5e6c45a23d
Gurobi-accepted output                   59eddcb657d2f5d9c2cf62fd5dccba6b8eb913fa7cef21c9e1dc47e6ef1001aa
compact search source                    23e0b8442b84baf25be8f70265f60b72c740647c53bd0e2bf491ffcddb12bc57
flex-search log                          288cd430eff91e57a098b1e55a763460c152c5cf20be70a1058361d987014807
exact rational validation log           e330d18c42952ae60a6232555106f81de85c9d16a5975494c84f9904441eacfd
independent Decimal/semantic audit       4b383888d264079ffdaf9e8a2c8a03cd9f3d00d4bf9942d275316b5b345a4ebf
Gurobi start-acceptance log              664b0692b8885162e81ec0f59dba6641f256b5a22bb50b747b157d28bee82106
exact audit of Gurobi output             800e053ab10096c0fb0574916277fa96efae38e4116041b24cc71c58b2946ced
```

Detailed evidence is in:

- `../logs/allcolor58_compact_search_from10_seed17.log`;
- `../logs/allcolor58_flexsearch_seed271828.log`;
- `../logs/allcolor58-42_exact_mps_validation.log`;
- `../artifacts/objective-42-independent-audit.json`;
- `../logs/allcolor58-42_gurobi_start_validation.log`;
- `../logs/allcolor58-42_gurobi_output_exact_validation.log`.

## 6. Source status

The [official MIPLIB instance page](https://miplib.zib.de/instance_details_allcolor58.html)
listed 258 as its best solution when checked.  The prepack optimization paper
reported that its heuristic reached 42 but did not publish a replayable
witness.  The local certificate above supplies that missing witness and checks
it directly against the official MPS.

Primary paper:

- https://www.dei.unipd.it/~fisch/papers/prepack_optimization.pdf
