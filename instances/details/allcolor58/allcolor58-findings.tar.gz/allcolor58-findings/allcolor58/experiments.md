# Experiment ledger

This file is generated from `runs/*/result.json` by the controller.

| Run | Solver | Status | Primal | Dual | Gap | Verified | Runtime (s) |
|---|---|---|---:|---:|---:|---|---:|
| `custom-20260904-232306-0cd77fac` | custom-python | success | — | — | — | not checked | 31.3143658638 |
| `custom-20260904-232516-74575024` | custom-cpp | success | 0 | — | — | no | 1.91587090492249 |
| `custom-20260904-232652-a07c8456` | custom-python | success | 0 | — | — | no | 3.34058833122253 |
| `custom-20260904-232835-204bcd94` | custom-python | success | — | — | — | not checked | 5.40468192100525 |
| `custom-20260904-233020-0280fb32` | custom-python | success | — | — | — | not checked | 0.170955181121826 |
| `custom-20260904-233139-354d3571` | custom-python | error | — | — | — | not checked | 2.38511157035828 |
| `custom-20260904-233301-568cbcb2` | custom-python | success | — | — | — | not checked | 0.171005964279175 |
| `custom-20260904-233420-c0e2b662` | custom-python | success | — | — | — | not checked | 2.98833775520325 |
| `custom-20260904-233542-8e5c383b` | custom-python | failed | — | — | — | not checked | 2.0332510471344 |
| `custom-20260904-233703-3a092772` | custom-python | success | 0 | — | — | no | 63.7701845169067 |
