#!/usr/bin/env python3
"""Exact rational validation of an allcolor58 solution against its MPS."""

from __future__ import annotations

import argparse
import gzip
from collections import defaultdict
from fractions import Fraction
from pathlib import Path


def lines(path: Path):
    if path.suffix == ".gz":
        with gzip.open(path, "rt", encoding="latin1", errors="replace") as handle:
            yield from handle
    else:
        with path.open("r", encoding="latin1", errors="replace") as handle:
            yield from handle


def read_solution(path: Path):
    values = {}
    declared_objective = None
    for line in lines(path):
        fields = line.split()
        if not fields or fields[0].startswith("#"):
            continue
        if fields[0] == "=obj=":
            declared_objective = Fraction(fields[1])
            continue
        if len(fields) != 2:
            raise ValueError(f"bad solution line: {line.rstrip()}")
        name, value = fields[0], Fraction(fields[1])
        if name in values:
            raise ValueError(f"duplicate solution variable: {name}")
        if value:
            values[name] = value
    return values, declared_objective


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("solution", type=Path)
    args = parser.parse_args()

    solution, declared_objective = read_solution(args.solution)
    section = None
    row_sense = {}
    row_order = []
    rhs = defaultdict(Fraction)
    activity = defaultdict(Fraction)
    variables = set()
    integer_variables = set()
    lower = {}
    upper = {}
    integer_mode = False

    for line in lines(args.model):
        fields = line.split()
        if not fields or fields[0].startswith("*"):
            continue
        if fields[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
            section = fields[0]
            continue
        if section == "ROWS":
            row_sense[fields[1]] = fields[0]
            row_order.append(fields[1])
        elif section == "COLUMNS":
            if len(fields) >= 3 and fields[1].strip("'") == "MARKER":
                integer_mode = fields[2].strip("'") == "INTORG"
                continue
            name = fields[0]
            variables.add(name)
            if integer_mode:
                integer_variables.add(name)
            value = solution.get(name, Fraction())
            if value:
                for k in range(1, len(fields), 2):
                    activity[fields[k]] += value * Fraction(fields[k + 1])
        elif section == "RHS":
            for k in range(1, len(fields), 2):
                rhs[fields[k]] = Fraction(fields[k + 1])
        elif section == "BOUNDS":
            kind, name = fields[0], fields[2]
            value = Fraction(fields[3]) if len(fields) >= 4 else None
            if kind == "LO" or kind == "LI":
                lower[name] = value
            elif kind == "UP" or kind == "UI":
                upper[name] = value
            elif kind == "FX":
                lower[name] = value
                upper[name] = value
            elif kind == "FR":
                lower[name] = None
                upper[name] = None
            elif kind == "MI":
                lower[name] = None
            elif kind == "PL":
                upper[name] = None
            elif kind == "BV":
                lower[name] = Fraction(0)
                upper[name] = Fraction(1)
                integer_variables.add(name)

    unknown = sorted(set(solution) - variables)
    bound_violations = []
    integrality_violations = []
    for name in variables:
        value = solution.get(name, Fraction())
        lb = lower.get(name, Fraction(0))
        ub = upper.get(name)
        if lb is not None and value < lb:
            bound_violations.append((name, value, "lower", lb))
        if ub is not None and value > ub:
            bound_violations.append((name, value, "upper", ub))
        if name in integer_variables and value.denominator != 1:
            integrality_violations.append((name, value))

    row_violations = []
    max_violation = Fraction()
    for row in row_order:
        sense = row_sense[row]
        if sense == "N":
            continue
        lhs = activity[row]
        right = rhs[row]
        if sense == "E":
            violation = abs(lhs - right)
        elif sense == "L":
            violation = max(Fraction(), lhs - right)
        elif sense == "G":
            violation = max(Fraction(), right - lhs)
        else:
            raise ValueError(f"unsupported row sense {sense}")
        if violation:
            row_violations.append((row, sense, lhs, right, violation))
            max_violation = max(max_violation, violation)

    objective_rows = [row for row in row_order if row_sense[row] == "N"]
    objective = activity[objective_rows[0]] if objective_rows else Fraction()
    print(f"model_variables {len(variables)}")
    print(f"model_constraints {sum(row_sense[row] != 'N' for row in row_order)}")
    print(f"solution_nonzeros {len(solution)}")
    print(f"objective {objective}")
    print(f"declared_objective {declared_objective}")
    print(f"unknown_variables {len(unknown)}")
    print(f"bound_violations {len(bound_violations)}")
    print(f"integrality_violations {len(integrality_violations)}")
    print(f"row_violations {len(row_violations)}")
    print(f"max_row_violation {max_violation}")
    if unknown:
        print("first_unknown", unknown[:5])
    if bound_violations:
        print("first_bound_violations", bound_violations[:5])
    if integrality_violations:
        print("first_integrality_violations", integrality_violations[:5])
    if row_violations:
        print("first_row_violations", row_violations[:5])

    valid = (
        not unknown
        and not bound_violations
        and not integrality_violations
        and not row_violations
        and objective == 42
        and (declared_objective is None or declared_objective == 42)
    )
    print(f"VALID {str(valid).lower()}")
    raise SystemExit(0 if valid else 1)


if __name__ == "__main__":
    main()
