#include <zlib.h>

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <functional>
#include <iostream>
#include <random>
#include <sstream>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace {

constexpr int NCONFIG = 14;
constexpr int NPRODUCT = 24;
constexpr int NSTORE = 58;
constexpr int MAX_MULT = 7;

using Config = std::array<unsigned char, NPRODUCT>;
using CountVector = std::array<unsigned char, NCONFIG>;

struct Key {
  std::array<std::uint64_t, 3> word{};
  bool operator==(const Key &other) const { return word == other.word; }
};

struct KeyHash {
  std::size_t operator()(const Key &key) const {
    std::uint64_t h = 0x9e3779b97f4a7c15ULL;
    for (std::uint64_t x : key.word) {
      x ^= x >> 30;
      x *= 0xbf58476d1ce4e5b9ULL;
      x ^= x >> 27;
      x *= 0x94d049bb133111ebULL;
      x ^= x >> 31;
      h ^= x + 0x9e3779b97f4a7c15ULL + (h << 6) + (h >> 2);
    }
    return static_cast<std::size_t>(h);
  }
};

Key pack(const Config &v) {
  Key key;
  for (int j = 0; j < NPRODUCT; ++j) {
    key.word[j / 8] |= static_cast<std::uint64_t>(v[j]) << (8 * (j % 8));
  }
  return key;
}

Config unpack(const Key &key);

Key add_scaled(Key a, const Key &b, int q) {
  for (int k = 0; k < 3; ++k) a.word[k] += b.word[k] * q;
  return a;
}

Key subtract_scaled(Key a, const Key &b, int q) {
  for (int k = 0; k < 3; ++k) a.word[k] -= b.word[k] * q;
  return a;
}

std::vector<std::string> split(const std::string &line) {
  std::istringstream in(line);
  std::vector<std::string> out;
  for (std::string token; in >> token;) out.push_back(token);
  return out;
}

bool parse_two_indices(const std::string &name, char prefix, int &a, int &b) {
  char fmt[16];
  std::snprintf(fmt, sizeof(fmt), "%c(%%d,%%d)", prefix);
  return std::sscanf(name.c_str(), fmt, &a, &b) == 2;
}

struct Target {
  Config value{};
  Key key{};
  int over_product = -1;
};

struct Instance {
  std::array<Config, NSTORE> demand{};
  std::array<std::array<bool, NPRODUCT>, NSTORE> over_allowed{};
  std::array<std::vector<Target>, NSTORE> targets;
  std::array<int, NSTORE> target_total{};
};

bool read_instance(const std::string &mps_path, Instance &instance) {
  gzFile file = gzopen(mps_path.c_str(), "rb");
  if (!file) return false;
  enum class Section { None, Rows, Columns, Rhs, Bounds } section = Section::None;
  std::unordered_map<std::string, std::pair<int, int>> demand_row;
  char buffer[8192];
  while (gzgets(file, buffer, sizeof(buffer))) {
    std::string line(buffer);
    auto z = split(line);
    if (z.empty() || z[0][0] == '*') continue;
    if (z[0] == "ROWS") { section = Section::Rows; continue; }
    if (z[0] == "COLUMNS") { section = Section::Columns; continue; }
    if (z[0] == "RHS") { section = Section::Rhs; continue; }
    if (z[0] == "BOUNDS") { section = Section::Bounds; continue; }
    if (z[0] == "RANGES" || z[0] == "ENDATA") { section = Section::None; continue; }
    if (z[0] == "NAME") continue;

    if (section == Section::Columns) {
      int j = 0, s = 0;
      if (parse_two_indices(z[0], 'o', j, s)) {
        for (std::size_t k = 1; k + 1 < z.size(); k += 2) {
          if (z[k] != "obj" && std::stod(z[k + 1]) < 0.0) {
            demand_row[z[k]] = {j - 1, s - 1};
          }
        }
      }
    } else if (section == Section::Rhs) {
      for (std::size_t k = 1; k + 1 < z.size(); k += 2) {
        auto it = demand_row.find(z[k]);
        if (it != demand_row.end()) {
          const int value = static_cast<int>(std::lround(std::stod(z[k + 1])));
          instance.demand[it->second.second][it->second.first] = value;
        }
      }
    } else if (section == Section::Bounds && z.size() >= 3) {
      int j = 0, s = 0;
      if (parse_two_indices(z[2], 'o', j, s)) {
        instance.over_allowed[s - 1][j - 1] = (z[0] != "FX");
      }
    }
  }
  gzclose(file);

  if (demand_row.size() != NPRODUCT * NSTORE) {
    std::cerr << "parsed " << demand_row.size() << " demand rows, expected "
              << NPRODUCT * NSTORE << '\n';
    return false;
  }
  for (int s = 0; s < NSTORE; ++s) {
    int total = 0;
    for (int j = 0; j < NPRODUCT; ++j) total += instance.demand[s][j];
    if (total % 2 == 0) {
      Target target;
      target.value = instance.demand[s];
      target.key = pack(target.value);
      instance.targets[s].push_back(target);
      instance.target_total[s] = total;
    } else {
      instance.target_total[s] = total + 1;
      for (int j = 0; j < NPRODUCT; ++j) {
        if (!instance.over_allowed[s][j]) continue;
        Target target;
        target.value = instance.demand[s];
        ++target.value[j];
        target.key = pack(target.value);
        target.over_product = j;
        instance.targets[s].push_back(target);
      }
    }
  }
  return true;
}

bool read_initial_configurations(const std::string &sol_path,
                                 std::array<Config, NCONFIG> &y) {
  gzFile file = gzopen(sol_path.c_str(), "rb");
  if (!file) return false;
  char buffer[8192];
  while (gzgets(file, buffer, sizeof(buffer))) {
    std::string line(buffer);
    auto z = split(line);
    if (z.size() < 2) continue;
    int i = 0, j = 0;
    if (parse_two_indices(z[0], 'y', i, j)) {
      y[i - 1][j - 1] = static_cast<unsigned char>(std::lround(std::stod(z[1])));
    } else if (z.size() == NPRODUCT + 1 && z[0][0] != '#') {
      i = std::stoi(z[0]);
      if (i >= 1 && i <= NCONFIG) {
        for (j = 0; j < NPRODUCT; ++j) {
          y[i - 1][j] = static_cast<unsigned char>(std::stoi(z[j + 1]));
        }
      }
    }
  }
  gzclose(file);
  return true;
}

struct TotalClass {
  int total = 0;
  std::vector<CountVector> counts;
};

void enumerate_counts_rec(const std::array<int, NCONFIG> &capacity, int pos,
                          int remaining, CountVector &x,
                          std::vector<CountVector> &out) {
  if (pos == NCONFIG) {
    if (remaining == 0) out.push_back(x);
    return;
  }
  const int max_value = std::min(MAX_MULT, remaining / capacity[pos]);
  for (int value = 0; value <= max_value; ++value) {
    x[pos] = static_cast<unsigned char>(value);
    enumerate_counts_rec(capacity, pos + 1, remaining - value * capacity[pos], x, out);
  }
  x[pos] = 0;
}

std::vector<TotalClass> enumerate_counts(const Instance &instance,
                                         const std::array<int, NCONFIG> &capacity,
                                         std::array<int, 64> &total_to_class) {
  total_to_class.fill(-1);
  std::vector<int> totals(instance.target_total.begin(), instance.target_total.end());
  std::sort(totals.begin(), totals.end());
  totals.erase(std::unique(totals.begin(), totals.end()), totals.end());
  std::vector<TotalClass> classes;
  for (int total : totals) {
    TotalClass tc;
    tc.total = total;
    CountVector x{};
    enumerate_counts_rec(capacity, 0, total, x, tc.counts);
    total_to_class[total] = static_cast<int>(classes.size());
    classes.push_back(std::move(tc));
  }
  return classes;
}

Key shipment_key(const CountVector &x, const std::array<Key, NCONFIG> &packed_y) {
  Key out;
  for (int i = 0; i < NCONFIG; ++i) out = add_scaled(out, packed_y[i], x[i]);
  return out;
}

struct Coverage {
  int score = 0;
  std::array<bool, NSTORE> covered{};
};

Coverage full_coverage(const Instance &instance,
                       const std::vector<TotalClass> &classes,
                       const std::array<int, 64> &total_to_class,
                       const std::array<Config, NCONFIG> &y) {
  std::array<Key, NCONFIG> packed_y;
  for (int i = 0; i < NCONFIG; ++i) packed_y[i] = pack(y[i]);
  std::vector<std::unordered_map<Key, int, KeyHash>> lookup(classes.size());
  for (std::size_t t = 0; t < classes.size(); ++t) {
    lookup[t].reserve(classes[t].counts.size() * 2);
    for (std::size_t k = 0; k < classes[t].counts.size(); ++k) {
      lookup[t].emplace(shipment_key(classes[t].counts[k], packed_y), static_cast<int>(k));
    }
  }
  Coverage result;
  for (int s = 0; s < NSTORE; ++s) {
    const int tc = total_to_class[instance.target_total[s]];
    for (const Target &target : instance.targets[s]) {
      if (lookup[tc].find(target.key) != lookup[tc].end()) {
        result.covered[s] = true;
        ++result.score;
        break;
      }
    }
  }
  return result;
}

using BaseMap = std::unordered_map<Key, int, KeyHash>;

struct RowOracle {
  int row = 0;
  std::vector<std::array<BaseMap, MAX_MULT + 1>> base;
};

struct PairOracle {
  int first = 0;
  int second = 1;
  std::vector<std::array<std::array<BaseMap, MAX_MULT + 1>, MAX_MULT + 1>> base;
};

RowOracle build_row_oracle(int row, const std::vector<TotalClass> &classes,
                           const std::array<Config, NCONFIG> &y) {
  std::array<Key, NCONFIG> packed_y;
  for (int i = 0; i < NCONFIG; ++i) packed_y[i] = pack(y[i]);
  RowOracle oracle;
  oracle.row = row;
  oracle.base.resize(classes.size());
  for (std::size_t t = 0; t < classes.size(); ++t) {
    std::array<std::size_t, MAX_MULT + 1> count{};
    for (const auto &x : classes[t].counts) ++count[x[row]];
    for (int q = 0; q <= MAX_MULT; ++q) oracle.base[t][q].reserve(count[q] * 2);
    for (std::size_t k = 0; k < classes[t].counts.size(); ++k) {
      const CountVector &x = classes[t].counts[k];
      Key full = shipment_key(x, packed_y);
      Key without = subtract_scaled(full, packed_y[row], x[row]);
      oracle.base[t][x[row]].emplace(without, static_cast<int>(k));
    }
  }
  return oracle;
}

PairOracle build_pair_oracle(int first, int second,
                             const std::vector<TotalClass> &classes,
                             const std::array<Config, NCONFIG> &y) {
  std::array<Key, NCONFIG> packed_y;
  for (int i = 0; i < NCONFIG; ++i) packed_y[i] = pack(y[i]);
  PairOracle oracle;
  oracle.first = first;
  oracle.second = second;
  oracle.base.resize(classes.size());
  for (std::size_t t = 0; t < classes.size(); ++t) {
    std::array<std::array<std::size_t, MAX_MULT + 1>, MAX_MULT + 1> count{};
    for (const auto &x : classes[t].counts) ++count[x[first]][x[second]];
    for (int qa = 0; qa <= MAX_MULT; ++qa) {
      for (int qb = 0; qb <= MAX_MULT; ++qb) {
        oracle.base[t][qa][qb].reserve(count[qa][qb] * 2);
      }
    }
    for (std::size_t k = 0; k < classes[t].counts.size(); ++k) {
      const CountVector &x = classes[t].counts[k];
      Key full = shipment_key(x, packed_y);
      Key without = subtract_scaled(full, packed_y[first], x[first]);
      without = subtract_scaled(without, packed_y[second], x[second]);
      oracle.base[t][x[first]][x[second]].emplace(without, static_cast<int>(k));
    }
  }
  return oracle;
}

Coverage pair_removal_coverage(const Instance &instance,
                               const std::array<int, 64> &total_to_class,
                               const PairOracle &oracle) {
  Coverage result;
  for (int s = 0; s < NSTORE; ++s) {
    const int tc = total_to_class[instance.target_total[s]];
    for (const Target &target : instance.targets[s]) {
      if (oracle.base[tc][0][0].find(target.key) != oracle.base[tc][0][0].end()) {
        result.covered[s] = true;
        ++result.score;
        break;
      }
    }
  }
  return result;
}

bool pair_covers_store(const Instance &instance,
                       const std::array<int, 64> &total_to_class,
                       const PairOracle &oracle, const Config &first,
                       const Config &second, int store) {
  const int tc = total_to_class[instance.target_total[store]];
  const Key first_key = pack(first);
  const Key second_key = pack(second);
  for (const Target &target : instance.targets[store]) {
    for (int qa = 0; qa <= MAX_MULT; ++qa) {
      for (int qb = 0; qb <= MAX_MULT; ++qb) {
        if (oracle.base[tc][qa][qb].empty()) continue;
        bool dominated = true;
        for (int j = 0; j < NPRODUCT; ++j) {
          const int used = qa * static_cast<int>(first[j]) +
                           qb * static_cast<int>(second[j]);
          if (used > static_cast<int>(target.value[j])) {
            dominated = false;
            break;
          }
        }
        if (!dominated) continue;
        Key wanted = subtract_scaled(target.key, first_key, qa);
        wanted = subtract_scaled(wanted, second_key, qb);
        if (oracle.base[tc][qa][qb].find(wanted) != oracle.base[tc][qa][qb].end()) {
          return true;
        }
      }
    }
  }
  return false;
}

Coverage score_pair_candidate(const Instance &instance,
                              const std::array<int, 64> &total_to_class,
                              const PairOracle &oracle, const Config &first,
                              const Config &second) {
  Coverage result;
  for (int s = 0; s < NSTORE; ++s) {
    if (pair_covers_store(instance, total_to_class, oracle, first, second, s)) {
      result.covered[s] = true;
      ++result.score;
    }
  }
  return result;
}

struct ConfigPairKey {
  Key first;
  Key second;
  bool operator==(const ConfigPairKey &other) const {
    return first == other.first && second == other.second;
  }
};

struct ConfigPairHash {
  std::size_t operator()(const ConfigPairKey &value) const {
    const std::size_t a = KeyHash{}(value.first);
    const std::size_t b = KeyHash{}(value.second);
    return a ^ (b + 0x9e3779b97f4a7c15ULL + (a << 6) + (a >> 2));
  }
};

void enumerate_residual_splits_rec(
    int position, int remaining_first, int remaining_second, int qa, int qb,
    const Config &residual, Config &first, Config &second,
    std::unordered_map<ConfigPairKey, std::pair<Config, Config>, ConfigPairHash> &out) {
  if (position == NPRODUCT) {
    if (remaining_first == 0 && remaining_second == 0) {
      out.emplace(ConfigPairKey{pack(first), pack(second)}, std::make_pair(first, second));
    }
    return;
  }
  const int rhs = residual[position];
  const int max_first = std::min(remaining_first, rhs / qa);
  for (int a = 0; a <= max_first; ++a) {
    const int rest = rhs - qa * a;
    if (rest % qb != 0) continue;
    const int b = rest / qb;
    if (b > remaining_second) continue;
    first[position] = static_cast<unsigned char>(a);
    second[position] = static_cast<unsigned char>(b);
    enumerate_residual_splits_rec(position + 1, remaining_first - a,
                                  remaining_second - b, qa, qb, residual,
                                  first, second, out);
  }
  first[position] = 0;
  second[position] = 0;
}

std::unordered_map<ConfigPairKey, std::pair<Config, Config>, ConfigPairHash>
generate_pair_candidates(const Instance &instance,
                         const std::array<int, 64> &total_to_class,
                         const PairOracle &oracle, int capacity_first,
                         int capacity_second, const std::vector<int> &stores) {
  std::unordered_map<ConfigPairKey, std::pair<Config, Config>, ConfigPairHash> out;
  for (int store : stores) {
    const int tc = total_to_class[instance.target_total[store]];
    for (const Target &target : instance.targets[store]) {
      for (int qa = 1; qa <= MAX_MULT; ++qa) {
        for (int qb = 1; qb <= MAX_MULT; ++qb) {
          for (const auto &entry : oracle.base[tc][qa][qb]) {
            const Config base = unpack(entry.first);
            Config residual{};
            bool valid = true;
            for (int j = 0; j < NPRODUCT; ++j) {
              if (base[j] > target.value[j]) {
                valid = false;
                break;
              }
              residual[j] = target.value[j] - base[j];
            }
            if (!valid) continue;
            Config first{}, second{};
            enumerate_residual_splits_rec(0, capacity_first, capacity_second,
                                          qa, qb, residual, first, second, out);
          }
        }
      }
    }
  }
  return out;
}

std::unordered_map<Key, Config, KeyHash> generate_single_candidates(
    const Instance &instance, const std::array<int, 64> &total_to_class,
    const PairOracle &oracle, int capacity, const std::vector<int> &stores,
    bool generate_first) {
  std::unordered_map<Key, Config, KeyHash> out;
  for (int store : stores) {
    const int tc = total_to_class[instance.target_total[store]];
    for (const Target &target : instance.targets[store]) {
      for (int q = 1; q <= MAX_MULT; ++q) {
        const BaseMap &base_map = generate_first ? oracle.base[tc][q][0]
                                                 : oracle.base[tc][0][q];
        for (const auto &entry : base_map) {
          const Config base = unpack(entry.first);
          Config candidate{};
          int sum = 0;
          bool valid = true;
          for (int j = 0; j < NPRODUCT; ++j) {
            const int residual = static_cast<int>(target.value[j]) - base[j];
            if (residual < 0 || residual % q != 0) {
              valid = false;
              break;
            }
            candidate[j] = static_cast<unsigned char>(residual / q);
            sum += candidate[j];
          }
          if (valid && sum == capacity) out.emplace(pack(candidate), candidate);
        }
      }
    }
  }
  return out;
}

bool target_dominates_scaled(const Target &target, const Config &candidate, int q) {
  for (int j = 0; j < NPRODUCT; ++j) {
    if (q * static_cast<int>(candidate[j]) > static_cast<int>(target.value[j])) return false;
  }
  return true;
}

Coverage score_candidate(const Instance &instance,
                         const std::array<int, 64> &total_to_class,
                         const RowOracle &oracle, const Config &candidate) {
  const Key candidate_key = pack(candidate);
  Coverage result;
  for (int s = 0; s < NSTORE; ++s) {
    const int tc = total_to_class[instance.target_total[s]];
    bool found = false;
    for (const Target &target : instance.targets[s]) {
      for (int q = 0; q <= MAX_MULT; ++q) {
        if (oracle.base[tc][q].empty()) continue;
        if (!target_dominates_scaled(target, candidate, q)) continue;
        const Key wanted = subtract_scaled(target.key, candidate_key, q);
        if (oracle.base[tc][q].find(wanted) != oracle.base[tc][q].end()) {
          found = true;
          break;
        }
      }
      if (found) break;
    }
    if (found) {
      result.covered[s] = true;
      ++result.score;
    }
  }
  return result;
}

void enumerate_configurations_rec(int pos, int remaining, Config &candidate,
                                  const std::function<void(const Config &)> &visit) {
  if (pos == NPRODUCT - 1) {
    candidate[pos] = static_cast<unsigned char>(remaining);
    visit(candidate);
    candidate[pos] = 0;
    return;
  }
  for (int value = 0; value <= remaining; ++value) {
    candidate[pos] = static_cast<unsigned char>(value);
    enumerate_configurations_rec(pos + 1, remaining - value, candidate, visit);
  }
  candidate[pos] = 0;
}

std::string config_string(const Config &config) {
  std::ostringstream out;
  bool first = true;
  for (int j = 0; j < NPRODUCT; ++j) {
    if (!config[j]) continue;
    if (!first) out << ',';
    first = false;
    out << (j + 1) << ':' << static_cast<int>(config[j]);
  }
  return out.str();
}

struct CandidateResult {
  int score = -1;
  std::vector<Config> tied;
};

CandidateResult exhaustive_row(const Instance &instance,
                               const std::array<int, 64> &total_to_class,
                               const RowOracle &oracle, int capacity) {
  CandidateResult best;
  Config candidate{};
  enumerate_configurations_rec(0, capacity, candidate, [&](const Config &value) {
    const int score = score_candidate(instance, total_to_class, oracle, value).score;
    if (score > best.score) {
      best.score = score;
      best.tied.clear();
      best.tied.push_back(value);
    } else if (score == best.score) {
      best.tied.push_back(value);
    }
  });
  return best;
}

CandidateResult transfer_neighborhood(const Instance &instance,
                                      const std::array<int, 64> &total_to_class,
                                      const RowOracle &oracle,
                                      const Config &current) {
  CandidateResult best;
  auto consider = [&](const Config &candidate) {
    const int score = score_candidate(instance, total_to_class, oracle, candidate).score;
    if (score > best.score) {
      best.score = score;
      best.tied.assign(1, candidate);
    } else if (score == best.score) {
      best.tied.push_back(candidate);
    }
  };
  consider(current);
  for (int from = 0; from < NPRODUCT; ++from) {
    if (!current[from]) continue;
    for (int to = 0; to < NPRODUCT; ++to) {
      if (to == from) continue;
      Config candidate = current;
      --candidate[from];
      ++candidate[to];
      consider(candidate);
    }
  }
  return best;
}

Config unpack(const Key &key) {
  Config value{};
  for (int j = 0; j < NPRODUCT; ++j) {
    value[j] = static_cast<unsigned char>((key.word[j / 8] >> (8 * (j % 8))) & 0xffU);
  }
  return value;
}

// Every row replacement that newly represents some target has the form
// y=(target-base)/q for a base shipment made by the other 13 configurations
// and q in {1,...,7}.  Generating these patterns is therefore an exact pricing
// step for the binary "number of exactly representable stores" objective.
CandidateResult target_induced_replacements(
    const Instance &instance, const std::array<int, 64> &total_to_class,
    const RowOracle &oracle, int capacity, std::size_t &candidate_count) {
  std::unordered_map<Key, Config, KeyHash> candidates;
  for (int s = 0; s < NSTORE; ++s) {
    const int tc = total_to_class[instance.target_total[s]];
    for (const Target &target : instance.targets[s]) {
      for (int q = 1; q <= MAX_MULT; ++q) {
        for (const auto &entry : oracle.base[tc][q]) {
          const Config base = unpack(entry.first);
          Config candidate{};
          int sum = 0;
          bool valid = true;
          for (int j = 0; j < NPRODUCT; ++j) {
            const int residual = static_cast<int>(target.value[j]) - static_cast<int>(base[j]);
            if (residual < 0 || residual % q != 0) {
              valid = false;
              break;
            }
            const int value = residual / q;
            if (value > 10) {
              valid = false;
              break;
            }
            candidate[j] = static_cast<unsigned char>(value);
            sum += value;
          }
          if (valid && sum == capacity) candidates.emplace(pack(candidate), candidate);
        }
      }
    }
  }
  candidate_count = candidates.size();
  CandidateResult best;
  for (const auto &entry : candidates) {
    const int score = score_candidate(instance, total_to_class, oracle, entry.second).score;
    if (score > best.score) {
      best.score = score;
      best.tied.assign(1, entry.second);
    } else if (score == best.score) {
      best.tied.push_back(entry.second);
    }
  }
  return best;
}

bool find_witness(const Instance &instance, const std::vector<TotalClass> &classes,
                  const std::array<int, 64> &total_to_class,
                  const std::array<Config, NCONFIG> &y,
                  std::array<CountVector, NSTORE> &x,
                  std::array<int, NSTORE> &over_product) {
  std::array<Key, NCONFIG> packed_y;
  for (int i = 0; i < NCONFIG; ++i) packed_y[i] = pack(y[i]);
  std::vector<std::unordered_map<Key, int, KeyHash>> lookup(classes.size());
  for (std::size_t t = 0; t < classes.size(); ++t) {
    lookup[t].reserve(classes[t].counts.size() * 2);
    for (std::size_t k = 0; k < classes[t].counts.size(); ++k) {
      lookup[t].emplace(shipment_key(classes[t].counts[k], packed_y), static_cast<int>(k));
    }
  }
  for (int s = 0; s < NSTORE; ++s) {
    const int tc = total_to_class[instance.target_total[s]];
    bool found = false;
    for (const Target &target : instance.targets[s]) {
      auto it = lookup[tc].find(target.key);
      if (it == lookup[tc].end()) continue;
      x[s] = classes[tc].counts[it->second];
      over_product[s] = target.over_product;
      found = true;
      break;
    }
    if (!found) return false;
  }
  return true;
}

void write_solution(const std::string &path, const Instance &instance,
                    const std::array<int, NCONFIG> &capacity,
                    const std::array<Config, NCONFIG> &y,
                    const std::array<CountVector, NSTORE> &x,
                    const std::array<int, NSTORE> &over_product) {
  std::ofstream out(path);
  out << "=obj= 42\n";
  out << "# Exact compact-factorization witness for allcolor58\n";
  out << "# Objective value = 42\n";
  for (int s = 0; s < NSTORE; ++s) {
    if (over_product[s] >= 0) out << "o(" << over_product[s] + 1 << ',' << s + 1 << ") 1\n";
  }
  for (int i = 0; i < NCONFIG; ++i) {
    for (int j = 0; j < NPRODUCT; ++j) {
      if (y[i][j]) out << "y(" << i + 1 << ',' << j + 1 << ") " << static_cast<int>(y[i][j]) << "\n";
    }
    int capacity_index = 0;
    if (capacity[i] == 4) capacity_index = 1;
    if (capacity[i] == 6) capacity_index = 2;
    if (capacity[i] == 8) capacity_index = 3;
    if (capacity[i] == 10) capacity_index = 4;
    out << "t(" << i + 1 << ',' << capacity_index << ") 1\n";
  }
  for (int i = 0; i < NCONFIG; ++i) {
    for (int s = 0; s < NSTORE; ++s) {
      const int multiplier = x[s][i];
      if (!multiplier) continue;
      out << "x(" << i + 1 << ',' << s + 1 << ") " << multiplier << "\n";
      for (int bit = 0; bit < 3; ++bit) {
        if ((multiplier >> bit) & 1) out << "v(" << i + 1 << ',' << s + 1 << ',' << bit << ") 1\n";
      }
      for (int j = 0; j < NPRODUCT; ++j) {
        if (!y[i][j]) continue;
        out << "q(" << i + 1 << ',' << j + 1 << ',' << s + 1 << ") "
            << multiplier * static_cast<int>(y[i][j]) << "\n";
        for (int bit = 0; bit < 3; ++bit) {
          if ((multiplier >> bit) & 1) {
            out << "w(" << i + 1 << ',' << j + 1 << ',' << s + 1 << ',' << bit << ") "
                << static_cast<int>(y[i][j]) << "\n";
          }
        }
      }
    }
  }
}

void write_y_checkpoint(const std::string &path, int score,
                        const std::array<Config, NCONFIG> &y) {
  std::ofstream out(path);
  out << "# exactly_representable_stores " << score << "\n";
  for (int i = 0; i < NCONFIG; ++i) {
    out << i + 1;
    for (int j = 0; j < NPRODUCT; ++j) out << '\t' << static_cast<int>(y[i][j]);
    out << '\n';
  }
}

}  // namespace

int main(int argc, char **argv) {
  if (argc < 4) {
    std::cerr << "usage: " << argv[0]
              << " MODEL.mps.gz INITIAL.sol.gz OUTPUT.sol [seed] [passes]\n";
    return 2;
  }
  const std::uint64_t seed = argc >= 5 ? std::strtoull(argv[4], nullptr, 10) : 20260905ULL;
  const int max_passes = argc >= 6 ? std::atoi(argv[5]) : 18;
  std::mt19937_64 rng(seed);

  Instance instance;
  if (!read_instance(argv[1], instance)) {
    std::cerr << "failed to parse instance\n";
    return 2;
  }
  std::array<Config, NCONFIG> y{};
  if (!read_initial_configurations(argv[2], y)) {
    std::cerr << "failed to parse initial solution\n";
    return 2;
  }
  std::array<int, NCONFIG> capacity{};
  for (int i = 0; i < NCONFIG; ++i) {
    for (unsigned char value : y[i]) capacity[i] += value;
    if (capacity[i] != 4 && capacity[i] != 6 && capacity[i] != 8 && capacity[i] != 10) {
      std::cerr << "bad capacity in row " << i + 1 << ": " << capacity[i] << '\n';
      return 2;
    }
  }
  std::array<int, 64> total_to_class;
  auto classes = enumerate_counts(instance, capacity, total_to_class);
  std::cout << "seed " << seed << "\ncapacities";
  for (int c : capacity) std::cout << ' ' << c;
  std::cout << '\n';
  for (const auto &tc : classes) std::cout << "count vectors total " << tc.total << ": " << tc.counts.size() << '\n';

  Coverage current = full_coverage(instance, classes, total_to_class, y);
  std::array<Config, NCONFIG> global_best = y;
  int global_score = current.score;
  write_y_checkpoint(std::string(argv[3]) + ".ybest.tsv", global_score, global_best);
  std::cout << "initial exact stores " << current.score << "/" << NSTORE << '\n';

  if (argc >= 7 && std::string(argv[6]) == "survival") {
    struct Result { int score; int first; int second; std::vector<int> lost; };
    std::vector<Result> results;
    for (int first = 0; first < NCONFIG; ++first) {
      for (int second = first + 1; second < NCONFIG; ++second) {
        PairOracle oracle = build_pair_oracle(first, second, classes, y);
        Coverage surviving = pair_removal_coverage(instance, total_to_class, oracle);
        Result result{surviving.score, first, second, {}};
        for (int s = 0; s < NSTORE; ++s) {
          if (current.covered[s] && !surviving.covered[s]) result.lost.push_back(s + 1);
        }
        results.push_back(std::move(result));
      }
    }
    std::sort(results.begin(), results.end(), [](const Result &a, const Result &b) {
      if (a.score != b.score) return a.score > b.score;
      return std::pair<int, int>{a.first, a.second} < std::pair<int, int>{b.first, b.second};
    });
    for (const auto &result : results) {
      std::cout << "pair " << result.first + 1 << ',' << result.second + 1
                << " survivors " << result.score << " lost";
      for (int s : result.lost) std::cout << ' ' << s;
      std::cout << '\n';
    }
    return 0;
  }


  if (argc >= 9 && std::string(argv[6]) == "pairsearch") {
    const int first = std::atoi(argv[7]) - 1;
    const int second = std::atoi(argv[8]) - 1;
    if (first < 0 || second <= first || second >= NCONFIG) {
      std::cerr << "pairsearch needs 1-based FIRST SECOND with FIRST < SECOND\n";
      return 2;
    }
    std::vector<int> uncovered;
    for (int s = 0; s < NSTORE; ++s) if (!current.covered[s]) uncovered.push_back(s);
    PairOracle oracle = build_pair_oracle(first, second, classes, y);
    Coverage removal = pair_removal_coverage(instance, total_to_class, oracle);
    std::cout << "pairsearch rows " << first + 1 << ',' << second + 1
              << " removal survivors " << removal.score << " uncovered";
    for (int s : uncovered) std::cout << ' ' << s + 1;
    std::cout << '\n';
    auto candidates = generate_pair_candidates(
        instance, total_to_class, oracle, capacity[first], capacity[second], uncovered);
    const std::size_t both_positive_count = candidates.size();
    auto first_only = generate_single_candidates(
        instance, total_to_class, oracle, capacity[first], uncovered, true);
    auto second_only = generate_single_candidates(
        instance, total_to_class, oracle, capacity[second], uncovered, false);
    for (const auto &a : first_only) {
      for (const auto &b : second_only) {
        candidates.emplace(ConfigPairKey{a.first, b.first},
                           std::make_pair(a.second, b.second));
      }
    }
    std::cout << "generated exact residual candidate pairs " << candidates.size()
              << " both-positive " << both_positive_count << " first-only "
              << first_only.size() << " second-only " << second_only.size() << '\n';
    int best_score = current.score;
    std::array<Config, NCONFIG> best_y = y;
    std::size_t tested = 0, covers_uncovered = 0;
    for (const auto &entry : candidates) {
      ++tested;
      bool passes = true;
      for (int s : uncovered) {
        if (!pair_covers_store(instance, total_to_class, oracle,
                               entry.second.first, entry.second.second, s)) {
          passes = false;
          break;
        }
      }
      if (!passes) continue;
      ++covers_uncovered;
      Coverage score = score_pair_candidate(instance, total_to_class, oracle,
                                             entry.second.first, entry.second.second);
      if (score.score > best_score) {
        best_score = score.score;
        best_y = y;
        best_y[first] = entry.second.first;
        best_y[second] = entry.second.second;
        write_y_checkpoint(std::string(argv[3]) + ".pairbest.tsv", best_score, best_y);
        std::cout << "new pair best " << best_score << " first "
                  << config_string(entry.second.first) << " second "
                  << config_string(entry.second.second) << '\n';
      }
    }
    std::cout << "pairsearch tested " << tested << " covers-all-uncovered "
              << covers_uncovered << " best " << best_score << '\n';
    if (best_score == NSTORE) {
      std::array<CountVector, NSTORE> x{};
      std::array<int, NSTORE> over_product;
      over_product.fill(-1);
      if (!find_witness(instance, classes, total_to_class, best_y, x, over_product)) {
        std::cerr << "internal error recovering pair witness\n";
        return 3;
      }
      write_solution(argv[3], instance, capacity, best_y, x, over_product);
      std::cout << "wrote exact objective-42 pair witness " << argv[3] << '\n';
      return 0;
    }
    return 1;
  }

  if (argc >= 7 && std::string(argv[6]) == "flexsearch") {
    struct FlexChoice { int capacity; Config config; };
    std::array<Config, NCONFIG> best_y = y;
    std::array<int, NCONFIG> best_capacity = capacity;
    int best_score = current.score;
    for (int pass = 0; pass < max_passes && best_score < NSTORE; ++pass) {
      std::vector<int> rows;
      for (int i = 0; i < NCONFIG; ++i) rows.push_back(i);
      std::shuffle(rows.begin(), rows.end(), rng);
      for (int row : rows) {
        int row_best_score = -1;
        std::vector<FlexChoice> tied;
        for (int proposed_capacity : {4, 6, 8, 10}) {
          auto trial_capacity = capacity;
          trial_capacity[row] = proposed_capacity;
          std::array<int, 64> trial_total_to_class;
          auto trial_classes = enumerate_counts(
              instance, trial_capacity, trial_total_to_class);
          RowOracle oracle = build_row_oracle(row, trial_classes, y);
          std::size_t priced_count = 0;
          CandidateResult priced = target_induced_replacements(
              instance, trial_total_to_class, oracle, proposed_capacity,
              priced_count);
          std::cout << "flex pass " << pass << " row " << row + 1
                    << " capacity " << proposed_capacity << " candidates "
                    << priced_count << " score " << priced.score << '\n';
          if (priced.score > row_best_score) {
            row_best_score = priced.score;
            tied.clear();
          }
          if (priced.score == row_best_score) {
            for (const Config &config : priced.tied) {
              tied.push_back(FlexChoice{proposed_capacity, config});
            }
          }
        }
        if (row_best_score >= current.score && !tied.empty()) {
          std::uniform_int_distribution<std::size_t> pick(0, tied.size() - 1);
          const FlexChoice chosen = tied[pick(rng)];
          y[row] = chosen.config;
          capacity[row] = chosen.capacity;
          classes = enumerate_counts(instance, capacity, total_to_class);
          current = full_coverage(instance, classes, total_to_class, y);
          if (current.score > best_score) {
            best_score = current.score;
            best_y = y;
            best_capacity = capacity;
            write_y_checkpoint(std::string(argv[3]) + ".flexbest.tsv",
                               best_score, best_y);
          }
        }
        std::cout << "flex accepted row " << row + 1 << " capacity "
                  << capacity[row] << " score " << current.score << " best "
                  << best_score << " config " << config_string(y[row]) << '\n';
        if (best_score == NSTORE) break;
      }
    }
    y = best_y;
    capacity = best_capacity;
    classes = enumerate_counts(instance, capacity, total_to_class);
    Coverage final = full_coverage(instance, classes, total_to_class, y);
    std::cout << "flex final exact stores " << final.score << '/' << NSTORE
              << " capacities";
    for (int value : capacity) std::cout << ' ' << value;
    std::cout << '\n';
    if (final.score == NSTORE) {
      std::array<CountVector, NSTORE> x{};
      std::array<int, NSTORE> over_product;
      over_product.fill(-1);
      if (!find_witness(instance, classes, total_to_class, y, x, over_product)) {
        std::cerr << "internal error recovering flex witness\n";
        return 3;
      }
      write_solution(argv[3], instance, capacity, y, x, over_product);
      std::cout << "wrote exact objective-42 flex witness " << argv[3] << '\n';
      return 0;
    }
    return 1;
  }

  // Alternate exact target-induced row pricing, exhaustive capacity-4 row
  // replacements, and all single-unit transfers. Equal-score choices are
  // randomized to move across plateaus.
  for (int pass = 0; pass < max_passes && global_score < NSTORE; ++pass) {
    bool improved = false;
    std::vector<int> rows;
    for (int i = 0; i < NCONFIG; ++i) rows.push_back(i);
    std::shuffle(rows.begin(), rows.end(), rng);
    for (int row : rows) {
      RowOracle oracle = build_row_oracle(row, classes, y);
      std::size_t priced_count = 0;
      CandidateResult best = target_induced_replacements(
          instance, total_to_class, oracle, capacity[row], priced_count);
      if (best.score >= current.score && !best.tied.empty()) {
        std::uniform_int_distribution<std::size_t> pick(0, best.tied.size() - 1);
        Config chosen = best.tied[pick(rng)];
        if (chosen != y[row]) {
          y[row] = chosen;
          current = full_coverage(instance, classes, total_to_class, y);
          improved = improved || current.score > global_score;
          if (current.score > global_score) {
            global_score = current.score;
            global_best = y;
            write_y_checkpoint(std::string(argv[3]) + ".ybest.tsv", global_score, global_best);
          }
        }
      }
      std::cout << "pass " << pass << " priced row " << row + 1
                << " candidates " << priced_count << " score " << current.score
                << " best " << global_score << " ties " << best.tied.size()
                << " config " << config_string(y[row]) << '\n';
      if (global_score == NSTORE) break;
    }
    if (global_score == NSTORE) break;

    rows.clear();
    for (int i = 0; i < NCONFIG; ++i) if (capacity[i] == 4) rows.push_back(i);
    std::shuffle(rows.begin(), rows.end(), rng);
    for (int row : rows) {
      RowOracle oracle = build_row_oracle(row, classes, y);
      CandidateResult best = exhaustive_row(instance, total_to_class, oracle, 4);
      if (best.score >= current.score && !best.tied.empty()) {
        std::uniform_int_distribution<std::size_t> pick(0, best.tied.size() - 1);
        Config chosen = best.tied[pick(rng)];
        if (chosen != y[row]) {
          y[row] = chosen;
          current = full_coverage(instance, classes, total_to_class, y);
          improved = improved || current.score > global_score;
          if (current.score > global_score) {
            global_score = current.score;
            global_best = y;
            write_y_checkpoint(std::string(argv[3]) + ".ybest.tsv", global_score, global_best);
          }
        }
      }
      std::cout << "pass " << pass << " exhaustive row " << row + 1
                << " score " << current.score << " best " << global_score
                << " ties " << best.tied.size() << " config " << config_string(y[row]) << '\n';
      if (global_score == NSTORE) break;
    }
    if (global_score == NSTORE) break;

    rows.clear();
    for (int i = 0; i < NCONFIG; ++i) rows.push_back(i);
    std::shuffle(rows.begin(), rows.end(), rng);
    for (int row : rows) {
      RowOracle oracle = build_row_oracle(row, classes, y);
      CandidateResult best = transfer_neighborhood(instance, total_to_class, oracle, y[row]);
      if (best.score >= current.score && !best.tied.empty()) {
        std::uniform_int_distribution<std::size_t> pick(0, best.tied.size() - 1);
        Config chosen = best.tied[pick(rng)];
        if (chosen != y[row]) {
          y[row] = chosen;
          current = full_coverage(instance, classes, total_to_class, y);
          improved = improved || current.score > global_score;
          if (current.score > global_score) {
            global_score = current.score;
            global_best = y;
            write_y_checkpoint(std::string(argv[3]) + ".ybest.tsv", global_score, global_best);
          }
        }
      }
      if (global_score == NSTORE) break;
    }
    std::cout << "pass " << pass << " end score " << current.score
              << " global " << global_score << " improved " << improved << '\n';
  }

  y = global_best;
  Coverage final_coverage = full_coverage(instance, classes, total_to_class, y);
  std::cout << "final exact stores " << final_coverage.score << "/" << NSTORE << '\n';
  if (final_coverage.score != NSTORE) {
    std::cout << "uncovered";
    for (int s = 0; s < NSTORE; ++s) if (!final_coverage.covered[s]) std::cout << ' ' << s + 1;
    std::cout << '\n';
    return 1;
  }

  std::array<CountVector, NSTORE> x{};
  std::array<int, NSTORE> over_product;
  over_product.fill(-1);
  if (!find_witness(instance, classes, total_to_class, y, x, over_product)) {
    std::cerr << "internal error recovering witness\n";
    return 3;
  }
  write_solution(argv[3], instance, capacity, y, x, over_product);
  std::cout << "wrote exact objective-42 witness " << argv[3] << '\n';
  return 0;
}
