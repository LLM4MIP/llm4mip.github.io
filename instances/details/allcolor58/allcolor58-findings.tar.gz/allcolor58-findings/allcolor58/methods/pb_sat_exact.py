import argparse, gzip, json, os, stat, subprocess, sys, time


def open_model(path):
    with open(path, 'rb') as f:
        magic = f.read(2)
    return gzip.open(path, 'rt', errors='replace') if magic == b'\x1f\x8b' else open(path, 'rt', errors='replace')


def locate(root, preferred):
    hits=[]
    if not os.path.exists(root): return None
    for base, dirs, files in os.walk(root):
        for fn in files:
            p=os.path.join(base,fn)
            low=fn.lower()
            if preferred in low and os.path.isfile(p) and os.access(p,os.X_OK):
                hits.append(p)
    hits.sort(key=lambda p:(0 if os.path.basename(p).lower()==preferred else 1,len(p),p))
    return hits[0] if hits else None


def parse_mps(path):
    section=''; rows={}; cols={}; rhs={}; lb={}; ub={}; objrow=None; int_mode=False
    with open_model(path) as f:
        for raw in f:
            line=raw.rstrip('\n\r')
            if not line or line.lstrip().startswith('*'): continue
            tok=line.split()
            if not tok: continue
            head=tok[0].upper()
            if head in ('NAME','OBJSENSE','OBJNAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA'):
                section=head
                if head=='ENDATA': break
                continue
            if section=='ROWS':
                if len(tok)>=2:
                    typ=tok[0].upper(); name=tok[1]
                    if typ=='N' and objrow is None: objrow=name
                    else: rows[name]=typ
            elif section=='COLUMNS':
                if any("MARKER" in x.upper() for x in tok):
                    joined=' '.join(tok).upper(); int_mode=('INTORG' in joined) or (int_mode and 'INTEND' not in joined)
                    continue
                if len(tok)<3: continue
                var=tok[0]; cols.setdefault(var,{'a':{},'integer':int_mode})
                j=1
                while j+1<len(tok):
                    rn=tok[j]
                    try: val=float(tok[j+1])
                    except: j+=2; continue
                    cols[var]['a'][rn]=cols[var]['a'].get(rn,0.0)+val
                    j+=2
            elif section=='RHS':
                j=1
                while j+1<len(tok):
                    try: rhs[tok[j]]=float(tok[j+1])
                    except: pass
                    j+=2
            elif section=='BOUNDS' and len(tok)>=3:
                typ=tok[0].upper(); var=tok[2]; val=float(tok[3]) if len(tok)>3 else 0.0
                cols.setdefault(var,{'a':{},'integer':False})
                if typ in ('BV','LI','UI','SI'): cols[var]['integer']=True
                if typ=='BV': lb[var]=0.0; ub[var]=1.0
                elif typ in ('LO','LI'): lb[var]=val
                elif typ in ('UP','UI'): ub[var]=val
                elif typ=='FX': lb[var]=val; ub[var]=val
                elif typ=='FR': lb[var]=-float('inf'); ub[var]=float('inf')
                elif typ=='MI': lb[var]=-float('inf')
                elif typ=='PL': ub[var]=float('inf')
    for v,d in cols.items():
        if v not in lb: lb[v]=0.0
        if v not in ub: ub[v]=1.0 if d['integer'] else float('inf')
    return rows,cols,rhs,lb,ub,objrow

class CNF:
    def __init__(self,n): self.n=n; self.c=[]
    def new(self): self.n+=1; return self.n
    def add(self,*l): self.c.append(list(l))
    def atmost(self,lits,k):
        n=len(lits)
        if k<0: self.add(); return
        if k>=n: return
        if k==0:
            for x in lits: self.add(-x)
            return
        # Sinz-style unary prefix: s[i][j] means at least j+1 true among first i+1 literals.
        s=[[self.new() for j in range(min(k,i+1))] for i in range(n)]
        for i,x in enumerate(lits):
            self.add(-x,s[i][0])
            if i>0:
                self.add(-s[i-1][0],s[i][0])
                for j in range(1,min(k,i+1)):
                    self.add(-x,-s[i-1][j-1],s[i][j])
                    if j<len(s[i-1]): self.add(-s[i-1][j],s[i][j])
                self.add(-x,-s[i-1][k-1])
    def atleast(self,lits,k): self.atmost([-x for x in lits],len(lits)-k)


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--model',required=True); ap.add_argument('--seed',type=int,default=1); ap.add_argument('--limit',type=int,default=105); a=ap.parse_args()
    t0=time.time(); audit={'seed':a.seed,'acceptance_criterion':'Every supported binary row is encoded exactly and SAT yields a MIP-checkable assignment, or UNSAT yields a DRAT certificate accepted by DRAT-trim.','pivot_condition':'Scale after a nontrivial supported encoding; otherwise revise the first reported domain, coefficient, range, or parser obstruction.','target_bound':'Strict feasibility proof (SAT primal witness or independently checked UNSAT certificate).'}
    status='success'; term='completed'; role='proof'; work=1; solution=None
    try:
        rows,cols,rhs,lb,ub,obj=parse_mps(a.model)
        names=list(cols); vid={v:i+1 for i,v in enumerate(names)}; unsupported=[]
        cnf=CNF(len(names)); fixed=0
        for v in names:
            lo,hi=lb[v],ub[v]; integ=cols[v]['integer']
            if (not integ) or lo < -1e-9 or hi > 1+1e-9:
                unsupported.append({'kind':'domain','variable':v,'integer':integ,'lb':lo,'ub':hi})
            elif lo>0.5: cnf.add(vid[v]); fixed+=1
            elif hi<0.5: cnf.add(-vid[v]); fixed+=1
        byrow={r:[] for r in rows}
        for v,d in cols.items():
            for r,c in d['a'].items():
                if r in byrow and abs(c)>1e-12: byrow[r].append((v,c))
        encoded=0; maxarity=0
        for r,typ in rows.items():
            terms=byrow[r]; maxarity=max(maxarity,len(terms)); b=rhs.get(r,0.0)
            lits=[]; shift=0
            for v,c in terms:
                q=round(c)
                if abs(c-q)>1e-8 or abs(q)!=1:
                    unsupported.append({'kind':'coefficient','row':r,'variable':v,'value':c}); break
                if q==1: lits.append(vid[v])
                else: lits.append(-vid[v]); shift+=1
            else:
                kf=b+shift; k=round(kf)
                if abs(kf-k)>1e-8: unsupported.append({'kind':'rhs','row':r,'value':kf}); continue
                if typ=='L': cnf.atmost(lits,k)
                elif typ=='G': cnf.atleast(lits,k)
                elif typ=='E': cnf.atmost(lits,k); cnf.atleast(lits,k)
                else: unsupported.append({'kind':'row_type','row':r,'type':typ}); continue
                encoded+=1
        audit.update({'variables':len(names),'constraints':len(rows),'fixed_variables':fixed,'encoded_rows':encoded,'max_row_arity':maxarity,'cnf_variables':cnf.n,'cnf_clauses':len(cnf.c),'unsupported_count':len(unsupported),'unsupported_examples':unsupported[:20]})
        work=max(1,len(cnf.c)+encoded)
        if unsupported or encoded!=len(rows) or not names:
            term='unsupported_exact_encoding'
        else:
            with open('model.cnf','w') as f:
                f.write('p cnf %d %d\n'%(cnf.n,len(cnf.c)))
                for c in cnf.c: f.write(' '.join(map(str,c))+' 0\n')
            cad=locate('/tools/cadical','cadical'); audit['cadical_path']=cad
            if not cad:
                term='cadical_executable_not_found'
            else:
                remain=max(1,min(a.limit,int(a.limit-(time.time()-t0))))
                cmd=[cad,'--seed='+str(a.seed),'--proof=proof.drat','model.cnf']
                try: p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=remain)
                except subprocess.TimeoutExpired as e:
                    p=None; out=(e.stdout or '') if isinstance(e.stdout,str) else ''; term='cadical_time_limit'
                else: out=p.stdout; audit['cadical_returncode']=p.returncode
                open('cadical_output.txt','w').write(out[-200000:])
                sat=('s SATISFIABLE' in out); unsat=('s UNSATISFIABLE' in out)
                audit['sat']=sat; audit['unsat']=unsat
                if sat:
                    vals={}
                    for line in out.splitlines():
                        if line.startswith('v '):
                            for z in line[2:].split():
                                try: q=int(z)
                                except: continue
                                if q: vals[abs(q)]=(q>0)
                    with open('best.sol','w') as f:
                        f.write('# Exact PB-to-SAT satisfying assignment\n')
                        for v in names: f.write('%s %d\n'%(v,1 if vals.get(vid[v],False) else 0))
                    solution='best.sol'; term='sat_assignment_emitted'
                elif unsat:
                    drat=locate('/tools/drat-trim','drat-trim') or locate('/tools/drat-trim','drat')
                    audit['drat_trim_path']=drat
                    if drat and os.path.exists('proof.drat'):
                        remain=max(1,min(30,int(a.limit-(time.time()-t0))))
                        try: q=subprocess.run([drat,'model.cnf','proof.drat'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=remain)
                        except subprocess.TimeoutExpired as e: chk=(e.stdout or '') if isinstance(e.stdout,str) else ''; rc=-1
                        else: chk=q.stdout; rc=q.returncode
                        open('proof_check.txt','w').write(chk)
                        verified=(rc==0 and ('VERIFIED' in chk.upper() or 's VERIFIED' in chk))
                        audit['proof_check_returncode']=rc; audit['proof_verified']=verified
                        term='unsat_certificate_verified' if verified else 'unsat_certificate_not_verified'
                    else: term='unsat_without_checker'
                elif term!='cadical_time_limit': term='cadical_unknown'
    except Exception as e:
        status='error'; term='exception'; audit['error']=repr(e)
    runtime=time.time()-t0; audit['runtime_seconds']=runtime; audit['termination_reason']=term
    with open('pb_sat_exact_audit.json','w') as f: json.dump(audit,f,indent=2)
    result={'status':status,'algorithm_family':'exact pseudo-Boolean to SAT compilation with DRAT checking','algorithm_role':role,'hypothesis':'The compressed allcolor model is a binary unit-coefficient feasibility system whose exact cardinality encoding can yield either a verified assignment or an independently checkable contradiction.','work_units':work,'work_unit_name':'encoded rows plus emitted CNF clauses','termination_reason':term,'target_bound':'Strict feasibility proof or globally valid infeasibility certificate','seed':a.seed,'runtime_seconds':runtime,'acceptance_criterion':audit['acceptance_criterion'],'pivot_condition':audit['pivot_condition'],'objective':0.0 if solution else None,'solution_file':solution,'certificate_file':'proof.drat' if os.path.exists('proof.drat') else None,'certificate_verified':audit.get('proof_verified',False)}
    with open('method_result.json','w') as f: json.dump(result,f,indent=2)

if __name__=='__main__': main()
