#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <queue>
#include <random>
#include <sstream>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;

struct Row { char type='N'; double rhs=0.0, range=0.0, lo=-INFINITY, hi=INFINITY, act=0.0; vector<pair<int,double>> a; uint64_t ver=0; };
struct Var { string name; double lo=0.0, hi=INFINITY, x=0.0; bool integer=false; vector<pair<int,double>> inc; };
struct HeapItem { double score; int row; uint64_t ver; bool operator<(const HeapItem& o) const { return score<o.score; } };

static vector<string> toks(const string& s){ istringstream in(s); vector<string> z; string x; while(in>>x) z.push_back(x); return z; }
static double num(string s){ for(char& c:s) if(c=='D'||c=='d') c='E'; return stod(s); }
static double project(double z,const Var& v){ if(isfinite(v.lo)) z=max(z,v.lo); if(isfinite(v.hi)) z=min(z,v.hi); if(v.integer) z=round(z); return z; }
static double violation(const Row& r){ if(r.act<r.lo) return r.lo-r.act; if(r.act>r.hi) return r.act-r.hi; return 0.0; }
static double normviol(const Row& r){ return violation(r)/(1.0+max(abs(r.lo== -INFINITY?0.0:r.lo),abs(r.hi==INFINITY?0.0:r.hi))); }
static string esc(const string& s){ string o; for(char c:s){ if(c=='\\'||c=='\"') o+='\\'; o+=c; } return o; }

int main(int argc,char**argv){
 string model; int seed=1; double runtime=90.0; long long maxmoves=20000000;
 for(int i=1;i<argc;i++){ string a=argv[i]; if(a=="--model"&&i+1<argc) model=argv[++i]; else if(a=="--seed"&&i+1<argc) seed=stoi(argv[++i]); else if(a=="--runtime"&&i+1<argc) runtime=stod(argv[++i]); else if(a=="--max-moves"&&i+1<argc) maxmoves=stoll(argv[++i]); }
 auto started=chrono::steady_clock::now();
 ifstream f(model); if(!f){ cerr<<"Cannot open model\n"; return 2; }
 enum Sec{NONE,ROWS,COLS,RHS,BOUNDS,RANGES} sec=NONE;
 vector<Row> rows; vector<Var> vars; unordered_map<string,int> rid,vid; string objrow; bool intmode=false; string line;
 auto getv=[&](const string& n){ auto it=vid.find(n); if(it!=vid.end()) return it->second; int k=vars.size(); vid[n]=k; vars.push_back(Var()); vars.back().name=n; vars.back().integer=intmode; return k; };
 while(getline(f,line)){
  if(line.empty()||line[0]=='*') continue; vector<string> t=toks(line); if(t.empty()) continue;
  string h=t[0];
  if(h=="ROWS"){sec=ROWS;continue;} if(h=="COLUMNS"){sec=COLS;continue;} if(h=="RHS"){sec=RHS;continue;} if(h=="BOUNDS"){sec=BOUNDS;continue;} if(h=="RANGES"){sec=RANGES;continue;} if(h=="ENDATA") break;
  if(h=="NAME"||h=="OBJSENSE"||h=="OBJNAME") continue;
  if(sec==ROWS && t.size()>=2){ Row r; r.type=t[0][0]; int k=rows.size(); rid[t[1]]=k; rows.push_back(r); if(r.type=='N'&&objrow.empty()) objrow=t[1]; continue; }
  if(sec==COLS){
   if(t.size()>=3 && t[1].find("MARKER")!=string::npos){ if(t[2].find("INTORG")!=string::npos) intmode=true; if(t[2].find("INTEND")!=string::npos) intmode=false; continue; }
   if(t.size()<3) continue; int v=getv(t[0]); if(intmode) vars[v].integer=true;
   for(size_t p=1;p+1<t.size();p+=2){ auto q=rid.find(t[p]); if(q==rid.end()) continue; double a=num(t[p+1]); rows[q->second].a.push_back({v,a}); vars[v].inc.push_back({q->second,a}); }
   continue;
  }
  if(sec==RHS && t.size()>=3){ for(size_t p=1;p+1<t.size();p+=2){ auto q=rid.find(t[p]); if(q!=rid.end()) rows[q->second].rhs=num(t[p+1]); } continue; }
  if(sec==RANGES && t.size()>=3){ for(size_t p=1;p+1<t.size();p+=2){ auto q=rid.find(t[p]); if(q!=rid.end()) rows[q->second].range=num(t[p+1]); } continue; }
  if(sec==BOUNDS && t.size()>=3){ string bt=t[0], vn=t[2]; int v=getv(vn); double z=t.size()>3?num(t[3]):0.0;
   if(bt=="LO") vars[v].lo=z; else if(bt=="UP") vars[v].hi=z; else if(bt=="FX") vars[v].lo=vars[v].hi=z; else if(bt=="FR"){vars[v].lo=-INFINITY;vars[v].hi=INFINITY;} else if(bt=="MI") vars[v].lo=-INFINITY; else if(bt=="PL") vars[v].hi=INFINITY; else if(bt=="BV"){vars[v].lo=0;vars[v].hi=1;vars[v].integer=true;} else if(bt=="LI"){vars[v].lo=z;vars[v].integer=true;} else if(bt=="UI"){vars[v].hi=z;vars[v].integer=true;} continue;
  }
 }
 int obj=-1; if(!objrow.empty()&&rid.count(objrow)) obj=rid[objrow];
 for(Row& r:rows){ double rr=abs(r.range); if(r.type=='E'){r.lo=r.rhs;r.hi=r.rhs; if(rr){ if(r.range>=0) r.hi=r.rhs+rr; else r.lo=r.rhs-rr; }} else if(r.type=='L'){r.hi=r.rhs;r.lo=-INFINITY;if(rr)r.lo=r.rhs-rr;} else if(r.type=='G'){r.lo=r.rhs;r.hi=INFINITY;if(rr)r.hi=r.rhs+rr;} else {r.lo=-INFINITY;r.hi=INFINITY;} }
 for(Var& v:vars){ double z=0; if(isfinite(v.lo)&&z<v.lo)z=v.lo; if(isfinite(v.hi)&&z>v.hi)z=v.hi; v.x=project(z,v); }
 for(Row& r:rows){ r.act=0; for(auto [v,a]:r.a) r.act+=a*vars[v].x; }
 auto totalViolation=[&](){ long double s=0; long long bad=0; double worst=0; for(int i=0;i<(int)rows.size();i++) if(i!=obj){double q=violation(rows[i]);s+=q; if(q>1e-7)bad++; worst=max(worst,q);} return tuple<long double,long long,double>(s,bad,worst); };
 priority_queue<HeapItem> pq; auto pushrow=[&](int r){ if(r==obj)return; rows[r].ver++; double q=normviol(rows[r]); if(q>1e-10)pq.push({q,r,rows[r].ver}); };
 for(int r=0;r<(int)rows.size();r++) pushrow(r);
 auto [initialV,initialBad,initialWorst]=totalViolation(); long double bestV=initialV; long long moves=0,accepted=0,kicks=0,stale=0; mt19937_64 rng(seed); bool feasible=initialBad==0; string term=feasible?"feasible_initial_point":"time_limit";
 while(!feasible && moves<maxmoves){
  double elapsed=chrono::duration<double>(chrono::steady_clock::now()-started).count(); if(elapsed>=runtime){term="runtime_limit";break;}
  while(!pq.empty() && (pq.top().ver!=rows[pq.top().row].ver || normviol(rows[pq.top().row])<1e-10)){pq.pop();stale++;}
  if(pq.empty()){term="violation_queue_exhausted";break;}
  int r=pq.top().row; pq.pop(); Row &rr=rows[r]; double target=rr.act<rr.lo?rr.lo:rr.hi;
  double bestDelta=0, bestNew=0; int bestVar=-1; size_t examined=0;
  size_t offset=rr.a.empty()?0:(moves%rr.a.size());
  for(size_t kk=0;kk<rr.a.size() && examined<96;kk++,examined++){
   auto [v,a]=rr.a[(offset+kk)%rr.a.size()]; if(abs(a)<1e-15)continue; Var &vv=vars[v]; if(vv.lo==vv.hi)continue;
   double raw=vv.x+(target-rr.act)/a; vector<double> cand;
   if(vv.integer){cand={floor(raw),ceil(raw),floor(raw)-1,ceil(raw)+1};}else cand={raw};
   for(double nz:cand){ nz=project(nz,vv); double dx=nz-vv.x; if(abs(dx)<1e-14)continue; long double delta=0;
    for(auto [j,b]:vv.inc){ if(j==obj)continue; double old=violation(rows[j]); double na=rows[j].act+b*dx; double nv=na<rows[j].lo?rows[j].lo-na:(na>rows[j].hi?na-rows[j].hi:0.0); delta+=nv-old; }
    if(delta<bestDelta-1e-12){bestDelta=delta;bestVar=v;bestNew=nz;}
   }
  }
  if(bestVar<0){
   if(rr.a.empty()){pushrow(r);term="empty_violated_row";break;}
   auto [v,a]=rr.a[rng()%rr.a.size()]; Var &vv=vars[v]; if(vv.lo!=vv.hi){ double raw=vv.x+(target-rr.act)/a; if(vv.integer) raw+=((rng()&1)?1:-1); bestVar=v;bestNew=project(raw,vv);kicks++; }
  }
  if(bestVar>=0 && abs(bestNew-vars[bestVar].x)>1e-14){ Var& vv=vars[bestVar]; double dx=bestNew-vv.x; vv.x=bestNew; for(auto [j,a]:vv.inc){rows[j].act+=a*dx;pushrow(j);} if(bestDelta<0)accepted++; }
  else pushrow(r);
  moves++;
  if((moves&4095)==0){ auto [tv,bad,worst]=totalViolation(); bestV=min(bestV,tv); if(bad==0){feasible=true;term="feasible_solution_found";break;} }
 }
 auto [finalV,finalBad,finalWorst]=totalViolation(); if(finalBad==0){feasible=true;term="feasible_solution_found";}
 double objective=0; if(obj>=0) objective=rows[obj].act;
 if(feasible){ ofstream sol("best.sol"); sol<<"# Objective value = "<<setprecision(17)<<objective<<"\n"; for(const Var&v:vars) sol<<v.name<<" "<<setprecision(17)<<v.x<<"\n"; }
 double elapsed=chrono::duration<double>(chrono::steady_clock::now()-started).count();
 ofstream rep("sparse_minconflicts_report.json"); rep<<setprecision(17)<<"{\n  \"variables\": "<<vars.size()<<",\n  \"rows\": "<<rows.size()<<",\n  \"integer_variables\": "<<count_if(vars.begin(),vars.end(),[](const Var&v){return v.integer;})<<",\n  \"initial_violated_rows\": "<<initialBad<<",\n  \"final_violated_rows\": "<<finalBad<<",\n  \"initial_total_violation\": "<<(double)initialV<<",\n  \"final_total_violation\": "<<(double)finalV<<",\n  \"final_worst_violation\": "<<finalWorst<<",\n  \"moves\": "<<moves<<",\n  \"improving_moves\": "<<accepted<<",\n  \"diversification_kicks\": "<<kicks<<",\n  \"stale_heap_entries\": "<<stale<<",\n  \"feasible\": "<<(feasible?"true":"false")<<",\n  \"objective_if_feasible\": "<<(feasible?to_string(objective):"null")<<"\n}\n";
 ofstream mr("method_result.json"); mr<<setprecision(17)<<"{\n  \"status\": \"success\",\n  \"algorithm_family\": \"sparse incremental row min-conflicts with projected coordinate repair\",\n  \"algorithm_role\": \"primal\",\n  \"hypothesis\": \"The highly sparse allcolor formulation has a narrow violated-row repair path after bound-projected initialization, and incremental min-conflicts can construct an integer-feasible incumbent without invoking a generic MIP solver.\",\n  \"work_units\": "<<max<long long>(1,moves)<<",\n  \"work_unit_name\": \"coordinate repair moves\",\n  \"termination_reason\": \""<<esc(term)<<"\",\n  \"target_bound\": \"feasibility first, then improvement of the public minimization primal target recorded in background.md\",\n  \"objective\": "<<(feasible?to_string(objective):"null")<<",\n  \"solution_artifact\": "<<(feasible?"\"best.sol\"":"null")<<",\n  \"certificate_artifact\": null,\n  \"seed\": "<<seed<<",\n  \"requested_algorithm_runtime_seconds\": "<<runtime<<",\n  \"actual_runtime_seconds\": "<<elapsed<<",\n  \"acceptance_criterion\": \"Choose the projected row-repair coordinate with the largest strict decrease in global L1 row violation; use a deterministic-seeded kick only at a local pivot failure.\",\n  \"pivot_condition\": \"Pivot when the maximum normalized violated row has no strictly improving projected coordinate among up to 96 incident candidates.\",\n  \"final_violated_rows\": "<<finalBad<<",\n  \"final_total_violation\": "<<(double)finalV<<"\n}\n";
 return 0;
}
