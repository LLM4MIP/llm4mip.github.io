import argparse, gzip, json, math, random, time


def lines_of(path):
    with open(path, 'rb') as f:
        magic = f.read(2)
    op = gzip.open if magic == b'\x1f\x8b' else open
    return op(path, 'rt', errors='replace')


def parse_mps(path):
    rows=[]; sense=[]; rid={}; objrow=None; entries=[]; rhs={}; ranges={}
    names=[]; vid={}; lo=[]; up=[]; integer=[]
    section=''; int_mode=False; records=0
    def var(n):
        if n not in vid:
            vid[n]=len(names); names.append(n); lo.append(0.0); up.append(float('inf')); integer.append(False)
        return vid[n]
    with lines_of(path) as f:
        for raw in f:
            s=raw.strip()
            if not s or s.startswith('*'): continue
            t=s.split(); head=t[0].upper()
            if head in ('NAME','OBJSENSE','OBJNAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA'):
                section=head
                if head=='ENDATA': break
                continue
            if section=='ROWS' and len(t)>=2:
                ty=t[0].upper(); n=t[1]
                if ty=='N' and objrow is None: objrow=n
                elif ty in ('E','L','G'):
                    rid[n]=len(rows); rows.append(n); sense.append(ty)
            elif section=='COLUMNS' and len(t)>=3:
                if any('MARKER' in x.upper() for x in t):
                    u=' '.join(t).upper()
                    if 'INTORG' in u: int_mode=True
                    elif 'INTEND' in u: int_mode=False
                    continue
                j=var(t[0]); integer[j] = integer[j] or int_mode
                k=1
                while k+1<len(t):
                    rn=t[k]
                    try: a=float(t[k+1].replace('D','E').replace('d','e'))
                    except ValueError: k+=2; continue
                    if rn in rid and a!=0.0: entries.append((rid[rn],j,a)); records+=1
                    k+=2
            elif section in ('RHS','RANGES') and len(t)>=3:
                dest=rhs if section=='RHS' else ranges; k=1
                while k+1<len(t):
                    if t[k] in rid:
                        try: dest[rid[t[k]]]=float(t[k+1].replace('D','E').replace('d','e'))
                        except ValueError: pass
                    k+=2
            elif section=='BOUNDS' and len(t)>=3:
                bt=t[0].upper(); j=var(t[2]); val=0.0
                if len(t)>=4:
                    try: val=float(t[3].replace('D','E').replace('d','e'))
                    except ValueError: val=0.0
                if bt=='LO': lo[j]=val
                elif bt=='UP': up[j]=val
                elif bt=='FX': lo[j]=val; up[j]=val
                elif bt=='FR': lo[j]=-float('inf'); up[j]=float('inf')
                elif bt=='MI': lo[j]=-float('inf')
                elif bt=='PL': up[j]=float('inf')
                elif bt=='BV': lo[j]=0.0; up[j]=1.0; integer[j]=True
                elif bt=='LI': lo[j]=val; integer[j]=True
                elif bt=='UI': up[j]=val; integer[j]=True
    m=len(rows); row_terms=[[] for _ in range(m)]; inc=[[] for _ in names]
    merged={}
    for i,j,a in entries: merged[(i,j)]=merged.get((i,j),0.0)+a
    for (i,j),a in merged.items():
        if a!=0.0: row_terms[i].append((j,a)); inc[j].append((i,a))
    lb=[-float('inf')]*m; ub=[float('inf')]*m
    for i in range(m):
        b=rhs.get(i,0.0); ty=sense[i]
        if ty=='E': lb[i]=ub[i]=b
        elif ty=='L': ub[i]=b
        else: lb[i]=b
        if i in ranges:
            r=ranges[i]
            if ty=='E':
                if r>=0: lb[i]=b; ub[i]=b+abs(r)
                else: lb[i]=b-abs(r); ub[i]=b
            elif ty=='L': lb[i]=b-abs(r); ub[i]=b
            else: lb[i]=b; ub[i]=b+abs(r)
    return names,lo,up,integer,row_terms,inc,lb,ub,records


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--model',required=True); ap.add_argument('--seed',type=int,default=17); ap.add_argument('--duration',type=float,default=105.0); a=ap.parse_args()
    start=time.monotonic(); rng=random.Random(a.seed)
    result={'status':'success','algorithm_family':'full-representation sparse weighted row repair','algorithm_role':'hybrid','hypothesis':'The prior breakout failure was caused by rejecting bounded continuous auxiliaries; retaining them permits exact coordinate repairs coupled with integer flips and incremental weighted violation evaluation.','seed':a.seed,'requested_runtime_seconds':a.duration,'acceptance_criterion':'Accept a witness only if every original MPS row and every variable bound is satisfied within 1e-7; scale only after complete parsing and positive incremental repair work.','pivot_condition':'Scale to 1,800 seconds if parsing succeeds, updates are substantive, and violations decrease; otherwise replace the mixed coordinate representation.','target_bound':'Verified feasible objective 0 and diagnostic reduction of the unresolved proof gap.','work_units':1,'termination_reason':'initializing'}
    try:
        names,lo,up,isint,rt,inc,lb,ub,records=parse_mps(a.model)
        n=len(names); m=len(rt); x=[0.0]*n
        for j in range(n):
            l,u=lo[j],up[j]
            if math.isfinite(l) and math.isfinite(u):
                if l==u: v=l
                elif isint[j]: v=float(rng.randint(math.ceil(l),math.floor(u)))
                else: v=(l+u)*0.5
            elif math.isfinite(l): v=max(l,0.0)
            elif math.isfinite(u): v=min(u,0.0)
            else: v=0.0
            x[j]=v
        act=[sum(c*x[j] for j,c in row) for row in rt]
        tol=1e-7
        def vio(i,val=None):
            z=act[i] if val is None else val
            if z<lb[i]-tol: return lb[i]-z
            if z>ub[i]+tol: return z-ub[i]
            return 0.0
        initial=sum(1 for i in range(m) if vio(i)>0); best_count=initial
        weights=[1.0]*m; updates=0; scans=0; breakout=0; restarts=0
        deadline=start+max(1.0,a.duration-2.0)
        while time.monotonic()<deadline and best_count>0:
            bad=[i for i in range(m) if vio(i)>0]
            scans+=m
            if not bad: best_count=0; break
            i=bad[rng.randrange(len(bad))]; z=act[i]
            target=lb[i] if z<lb[i] else ub[i]
            cand=rt[i]
            if not cand: weights[i]+=1.0; breakout+=1; continue
            best=None; best_gain=-1e300
            sample=cand if len(cand)<=48 else rng.sample(cand,48)
            for j,c in sample:
                if c==0 or lo[j]==up[j]: continue
                desired=x[j]+(target-z)/c
                if isint[j]:
                    options={math.floor(desired),math.ceil(desired),math.floor(x[j])-1,math.ceil(x[j])+1}
                else: options={desired,lo[j],up[j]}
                for nv in options:
                    if not math.isfinite(nv): continue
                    nv=max(lo[j],min(up[j],float(nv)))
                    if isint[j]: nv=float(round(nv))
                    d=nv-x[j]
                    if abs(d)<1e-12: continue
                    gain=0.0
                    for q,coef in inc[j]:
                        gain+=weights[q]*(vio(q)-vio(q,act[q]+coef*d)); scans+=1
                    if gain>best_gain: best_gain=gain; best=(j,nv)
            if best is None or best_gain<=1e-12:
                weights[i]+=1.0; breakout+=1
                if breakout%1000==0:
                    for q in bad[:min(100,len(bad))]: weights[q]+=0.25
                continue
            j,nv=best; d=nv-x[j]; x[j]=nv
            for q,c in inc[j]: act[q]+=c*d
            updates+=1
            if updates%1000==0:
                cnt=sum(1 for q in range(m) if vio(q)>0); scans+=m
                if cnt<best_count: best_count=cnt
        final_bad=[i for i in range(m) if vio(i)>0]
        feasible=not final_bad
        if feasible:
            with open('best.sol','w') as f:
                f.write('# Objective value = 0\n')
                for nm,v in zip(names,x):
                    if abs(v)>1e-12: f.write(f'{nm} {v:.17g}\n')
        result.update({'variables':n,'integer_variables':sum(isint),'continuous_variables':n-sum(isint),'constraints':m,'parse_records':records,'parse_ok':True,'initial_violated_rows':initial,'best_violated_rows':best_count,'final_violated_rows':len(final_bad),'max_final_violation':max([vio(i) for i in final_bad],default=0.0),'coordinate_updates':updates,'constraint_evaluations':scans,'breakout_updates':breakout,'restarts':restarts,'feasible':feasible,'objective':0.0 if feasible else None,'work_units':max(1,updates+breakout),'termination_reason':'verified_feasible_witness' if feasible else ('dry_run_time_budget' if time.monotonic()>=deadline else 'search_exhausted')})
    except Exception as e:
        result.update({'status':'failed','parse_ok':False,'error':type(e).__name__+': '+str(e),'termination_reason':'parser_or_runtime_failure','work_units':1})
    result['runtime_seconds']=time.monotonic()-start
    with open('method_result.json','w') as f: json.dump(result,f,indent=2,sort_keys=True)

if __name__=='__main__': main()
