#!/usr/bin/env python3
"""Exact MPS domain propagation and auditable trivial objective bounding.

This is not a generic optimizer. It parses the linear model into an independent
mathematical abstraction and applies only exact interval implications to integer
variables. All reported bounds are consequences of original rows and domains.
"""
import argparse
import gzip
import json
import math
import os
import time
from fractions import Fraction


def frac(s):
    s = s.strip()
    if s.upper() in {"INF", "+INF"}:
        return None
    if s.upper() == "-INF":
        return None
    return Fraction(s.replace("D", "E").replace("d", "e"))


def ceilq(x):
    return -((-x.numerator) // x.denominator)


def floorq(x):
    return x.numerator // x.denominator


def enc(x):
    if x is None:
        return None
    if x.denominator == 1:
        return int(x.numerator)
    return {"numerator": x.numerator, "denominator": x.denominator,
            "decimal": float(x)}


def open_model(path):
    if path.lower().endswith(".gz"):
        return gzip.open(path, "rt", encoding="utf-8", errors="replace")
    return open(path, "rt", encoding="utf-8", errors="replace")


def parse_mps(path):
    section = None
    row_type = {}
    rows = {}
    objective_row = None
    obj = {}
    rhs = {}
    ranges = {}
    bounds_records = []
    integer_mode = False
    integer_names = set()
    all_names = set()
    obj_sense = "min"
    ignored_sections = set()
    with open_model(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("*"):
                continue
            tok = line.split()
            head = tok[0].upper()
            if head in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA", "OBJSENSE", "OBJNAME", "SOS", "QSECTION", "QUADOBJ"}:
                section = head
                if head == "ENDATA":
                    break
                if head in {"SOS", "QSECTION", "QUADOBJ"}:
                    ignored_sections.add(head)
                continue
            if section == "OBJSENSE":
                if tok[0].upper().startswith("MAX"):
                    obj_sense = "max"
                elif tok[0].upper().startswith("MIN"):
                    obj_sense = "min"
            elif section == "ROWS":
                if len(tok) >= 2:
                    typ, name = tok[0].upper(), tok[1]
                    row_type[name] = typ
                    if typ == "N" and objective_row is None:
                        objective_row = name
                    elif typ in {"L", "G", "E"}:
                        rows[name] = []
            elif section == "COLUMNS":
                upper = [x.upper().strip("'") for x in tok]
                if "MARKER" in upper:
                    if "INTORG" in upper:
                        integer_mode = True
                    if "INTEND" in upper:
                        integer_mode = False
                    continue
                if len(tok) < 3:
                    continue
                var = tok[0]
                all_names.add(var)
                if integer_mode:
                    integer_names.add(var)
                pairs = tok[1:]
                for i in range(0, len(pairs) - 1, 2):
                    rn, vs = pairs[i], pairs[i + 1]
                    v = frac(vs)
                    if rn == objective_row or row_type.get(rn) == "N":
                        obj[var] = obj.get(var, Fraction(0)) + v
                    elif rn in rows:
                        rows[rn].append((var, v))
            elif section == "RHS":
                if len(tok) >= 3:
                    pairs = tok[1:]
                    for i in range(0, len(pairs) - 1, 2):
                        rhs[pairs[i]] = frac(pairs[i + 1])
            elif section == "RANGES":
                if len(tok) >= 3:
                    pairs = tok[1:]
                    for i in range(0, len(pairs) - 1, 2):
                        ranges[pairs[i]] = frac(pairs[i + 1])
            elif section == "BOUNDS":
                if len(tok) >= 3:
                    bt = tok[0].upper()
                    var = tok[2]
                    val = frac(tok[3]) if len(tok) >= 4 else None
                    all_names.add(var)
                    bounds_records.append((bt, var, val))
    lb = {v: Fraction(0) for v in all_names}
    ub = {v: None for v in all_names}
    for bt, v, val in bounds_records:
        if bt == "LO": lb[v] = val
        elif bt == "UP": ub[v] = val
        elif bt == "FX": lb[v] = val; ub[v] = val
        elif bt == "FR": lb[v] = None; ub[v] = None
        elif bt == "MI": lb[v] = None
        elif bt == "PL": ub[v] = None
        elif bt == "BV": lb[v] = Fraction(0); ub[v] = Fraction(1); integer_names.add(v)
        elif bt == "LI": lb[v] = val; integer_names.add(v)
        elif bt == "UI": ub[v] = val; integer_names.add(v)
        elif bt == "SC": ub[v] = val
    row_bounds = {}
    for r in rows:
        typ = row_type[r]
        b = rhs.get(r, Fraction(0))
        lo = hi = None
        if typ == "L": hi = b
        elif typ == "G": lo = b
        else: lo = b; hi = b
        if r in ranges:
            a = abs(ranges[r])
            if typ == "L": lo = b - a
            elif typ == "G": hi = b + a
            elif ranges[r] >= 0: hi = b + a
            else: lo = b - a
        row_bounds[r] = (lo, hi)
    return rows, row_bounds, obj, obj_sense, lb, ub, integer_names, ignored_sections


def contribution(a, lo, hi):
    if a >= 0:
        return (None if lo is None else a * lo,
                None if hi is None else a * hi)
    return (None if hi is None else a * hi,
            None if lo is None else a * lo)


def propagate(rows, row_bounds, lb, ub, integers, max_rounds, deadline):
    changes = 0
    row_visits = 0
    coefficient_visits = 0
    contradictions = []
    trace = []
    rounds = 0
    for rnd in range(max_rounds):
        rounds += 1
        round_changes = 0
        for rn, terms in rows.items():
            if time.monotonic() >= deadline:
                return rounds, changes, row_visits, coefficient_visits, contradictions, trace, "deadline"
            row_visits += 1
            mins, maxs = [], []
            finite_min = Fraction(0); finite_max = Fraction(0)
            ninf_min = 0; ninf_max = 0
            for v, a in terms:
                mn, mx = contribution(a, lb[v], ub[v])
                mins.append(mn); maxs.append(mx)
                if mn is None: ninf_min += 1
                else: finite_min += mn
                if mx is None: ninf_max += 1
                else: finite_max += mx
            coefficient_visits += len(terms)
            lo_row, hi_row = row_bounds[rn]
            if hi_row is not None and ninf_min == 0 and finite_min > hi_row:
                contradictions.append({"row": rn, "kind": "minimum_exceeds_upper", "minimum": enc(finite_min), "upper": enc(hi_row)})
                return rounds, changes, row_visits, coefficient_visits, contradictions, trace, "exact_row_contradiction"
            if lo_row is not None and ninf_max == 0 and finite_max < lo_row:
                contradictions.append({"row": rn, "kind": "maximum_below_lower", "maximum": enc(finite_max), "lower": enc(lo_row)})
                return rounds, changes, row_visits, coefficient_visits, contradictions, trace, "exact_row_contradiction"
            for j, (v, a) in enumerate(terms):
                if v not in integers or a == 0:
                    continue
                oldlo, oldhi = lb[v], ub[v]
                ownmn, ownmx = mins[j], maxs[j]
                other_min = None
                if ninf_min - (1 if ownmn is None else 0) == 0:
                    other_min = finite_min - (ownmn if ownmn is not None else 0)
                other_max = None
                if ninf_max - (1 if ownmx is None else 0) == 0:
                    other_max = finite_max - (ownmx if ownmx is not None else 0)
                newlo, newhi = oldlo, oldhi
                if hi_row is not None and other_min is not None:
                    q = (hi_row - other_min) / a
                    if a > 0:
                        z = Fraction(floorq(q)); newhi = z if newhi is None or z < newhi else newhi
                    else:
                        z = Fraction(ceilq(q)); newlo = z if newlo is None or z > newlo else newlo
                if lo_row is not None and other_max is not None:
                    q = (lo_row - other_max) / a
                    if a > 0:
                        z = Fraction(ceilq(q)); newlo = z if newlo is None or z > newlo else newlo
                    else:
                        z = Fraction(floorq(q)); newhi = z if newhi is None or z < newhi else newhi
                if newlo is not None and newhi is not None and newlo > newhi:
                    contradictions.append({"row": rn, "variable": v, "kind": "empty_integer_domain", "lower": enc(newlo), "upper": enc(newhi)})
                    return rounds, changes, row_visits, coefficient_visits, contradictions, trace, "exact_domain_contradiction"
                if newlo != oldlo or newhi != oldhi:
                    lb[v], ub[v] = newlo, newhi
                    changes += 1; round_changes += 1
                    if len(trace) < 200:
                        trace.append({"round": rnd + 1, "row": rn, "variable": v,
                                      "old_lower": enc(oldlo), "old_upper": enc(oldhi),
                                      "new_lower": enc(newlo), "new_upper": enc(newhi)})
        if round_changes == 0:
            return rounds, changes, row_visits, coefficient_visits, contradictions, trace, "fixpoint"
    return rounds, changes, row_visits, coefficient_visits, contradictions, trace, "round_limit"


def objective_domain_bound(obj, sense, lb, ub):
    total = Fraction(0)
    for v, c in obj.items():
        endpoint = (lb[v] if c >= 0 else ub[v]) if sense == "min" else (ub[v] if c >= 0 else lb[v])
        if endpoint is None:
            return None
        total += c * endpoint
    return total


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--max-rounds", type=int, default=3)
    ap.add_argument("--soft-seconds", type=float, default=90.0)
    args = ap.parse_args()
    start = time.monotonic()
    rows, rb, obj, sense, lb, ub, ints, ignored = parse_mps(args.model)
    parse_elapsed = time.monotonic() - start
    initial_fixed = sum(1 for v in lb if lb[v] is not None and ub[v] is not None and lb[v] == ub[v])
    rounds, changes, row_visits, coefficient_visits, contradictions, trace, term = propagate(
        rows, rb, lb, ub, ints, max(1, args.max_rounds), start + max(1.0, args.soft_seconds))
    bound = objective_domain_bound(obj, sense, lb, ub)
    fixed = sum(1 for v in lb if lb[v] is not None and ub[v] is not None and lb[v] == ub[v])
    binaries = sum(1 for v in ints if lb.get(v) == 0 and ub.get(v) == 1)
    finite_domains = sum(1 for v in ints if lb.get(v) is not None and ub.get(v) is not None)
    report = {
        "parser": "independent tokenized MPS parser with exact rational coefficients",
        "objective_sense": sense,
        "variables": len(lb), "integer_variables": len(ints), "binary_variables_after_propagation": binaries,
        "rows": len(rows), "nonzeros": sum(len(x) for x in rows.values()), "objective_nonzeros": len(obj),
        "finite_integer_domains": finite_domains, "initial_fixed_variables": initial_fixed,
        "final_fixed_variables": fixed, "domain_changes": changes, "rounds": rounds,
        "row_visits": row_visits, "coefficient_visits": coefficient_visits,
        "termination": term, "contradictions": contradictions,
        "objective_domain_bound": enc(bound), "objective_bound_kind": "global_lower" if sense == "min" else "global_upper",
        "ignored_nonlinear_sections": sorted(ignored), "sample_implications": trace,
        "limitations": ["Objective offset is assumed zero unless represented through an explicit fixed variable.",
                        "A contradiction is an auditable candidate certificate, not by itself a controller-trusted infeasibility proof."]
    }
    with open("propagation_report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, sort_keys=True)
    elapsed = time.monotonic() - start
    result = {
        "status": "success",
        "algorithm_family": "exact interval domain propagation",
        "algorithm_role": "dual_bound",
        "hypothesis": "The bounded sparse integer formulation admits useful exact row-wise implications and an auditable global objective bound before combinatorial search.",
        "work_units": max(1, coefficient_visits),
        "work_unit_name": "coefficient_visits",
        "termination_reason": term,
        "target_bound": "global objective lower bound" if sense == "min" else "global objective upper bound",
        "objective_bound": enc(bound),
        "objective_sense": sense,
        "certificate_artifact": "propagation_report.json",
        "seed": args.seed,
        "runtime_seconds": elapsed,
        "acceptance_criterion": "Parse at least one row and visit coefficients using exact arithmetic; retain only domain implications justified by a complete row interval.",
        "pivot_condition": "Scale if finite-domain coverage and propagation activity are material; otherwise use decoded row-variable incidence to replace the bounded-domain hypothesis.",
        "metrics": {"rows": len(rows), "variables": len(lb), "integer_variables": len(ints),
                    "finite_integer_domains": finite_domains, "domain_changes": changes,
                    "fixed_variables": fixed, "parse_seconds": parse_elapsed,
                    "coefficient_visits": coefficient_visits, "contradictions": len(contradictions)}
    }
    with open("method_result.json", "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, sort_keys=True)


if __name__ == "__main__":
    main()
