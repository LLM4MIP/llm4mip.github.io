import argparse, json, math, os, time
from collections import defaultdict


def number(s):
    s=s.replace('D','E').replace('d','e')
    v=float(s)
    if not math.isfinite(v): raise ValueError('nonfinite numeric token '+s)
    return v


def parse_mps(path):
    rows_type={}; cols=defaultdict(dict); rhs=defaultdict(float); ranges={}
    lb=defaultdict(float); ub=defaultdict(lambda: float('inf'))
    integer=set(); section=None; int_mode=False; obj=None; parse_records=0
    with open(path,'r',errors='replace') as f:
        for lineno,raw in enumerate(f,1):
            line=raw.rstrip('\r\n')
            if not line or line.lstrip().startswith('*'): continue
            tok=line.split()
            if not tok: continue
            head=tok[0].upper()
            if head in ('NAME','OBJSENSE','OBJNAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA'):
                section=head
                if head=='ENDATA': break
                continue
            try:
                if section=='OBJSENSE':
                    continue
                if section=='OBJNAME':
                    if tok: obj=tok[0]
                    continue
                if section=='ROWS':
                    if len(tok)<2: raise ValueError('short ROWS record')
                    typ=tok[0].upper(); name=tok[1]
                    if typ not in ('N','E','L','G'): raise ValueError('unknown row type '+typ)
                    rows_type[name]=typ
                    if typ=='N' and obj is None: obj=name
                    parse_records+=1
                elif section=='COLUMNS':
                    up=[x.upper().strip("'\"") for x in tok]
                    if 'MARKER' in up:
                        if 'INTORG' in up: int_mode=True
                        if 'INTEND' in up: int_mode=False
                        continue
                    if len(tok)<3: raise ValueError('short COLUMNS record')
                    var=tok[0]
                    if int_mode: integer.add(var)
                    rem=tok[1:]
                    if len(rem)%2: raise ValueError('unpaired COLUMNS row/value tokens')
                    for j in range(0,len(rem),2):
                        row=rem[j]; val=number(rem[j+1])
                        cols[row][var]=cols[row].get(var,0.0)+val
                    parse_records+=1
                elif section=='RHS':
                    if len(tok)<3: raise ValueError('short RHS record')
                    rem=tok[1:]
                    if len(rem)%2: raise ValueError('unpaired RHS row/value tokens')
                    for j in range(0,len(rem),2): rhs[rem[j]]=number(rem[j+1])
                    parse_records+=1
                elif section=='RANGES':
                    if len(tok)<3: raise ValueError('short RANGES record')
                    rem=tok[1:]
                    if len(rem)%2: raise ValueError('unpaired RANGES row/value tokens')
                    for j in range(0,len(rem),2): ranges[rem[j]]=number(rem[j+1])
                    parse_records+=1
                elif section=='BOUNDS':
                    if len(tok)<3: raise ValueError('short BOUNDS record')
                    typ=tok[0].upper(); var=tok[2]; val=number(tok[3]) if len(tok)>3 else None
                    if typ=='BV': lb[var]=0.0; ub[var]=1.0; integer.add(var)
                    elif typ=='LI': lb[var]=val; integer.add(var)
                    elif typ=='UI': ub[var]=val; integer.add(var)
                    elif typ=='LO': lb[var]=val
                    elif typ=='UP': ub[var]=val
                    elif typ=='FX': lb[var]=val; ub[var]=val
                    elif typ=='FR': lb[var]=-float('inf'); ub[var]=float('inf')
                    elif typ=='MI': lb[var]=-float('inf')
                    elif typ=='PL': ub[var]=float('inf')
                    else: raise ValueError('unsupported bound type '+typ)
                    parse_records+=1
            except Exception as e:
                raise RuntimeError('line %d section %s tokens %r: %s'%(lineno,section,tok,e))
    variables=set(integer)|set(lb)|set(ub)
    for r in cols.values(): variables.update(r)
    return rows_type,cols,rhs,ranges,lb,ub,integer,variables,obj,parse_records


def as_int(x,tol=1e-8):
    q=round(x)
    if abs(x-q)>tol: return None
    return int(q)


def inequality_states(weights,cap,state_limit,deadline):
    # Exact reachable partial sums, merging all sums above cap into cap+1.
    # This is the state set used by a reduced ordered PB decision diagram.
    states={0}; work=0; peak=1
    for w in weights:
        if time.monotonic()>deadline: return None,work,peak,'time_limit'
        nxt=set(states)
        for s in states:
            nxt.add(min(cap+1,s+w)); work+=1
            if len(nxt)>state_limit: return None,work,max(peak,len(nxt)),'state_limit'
        states=nxt; peak=max(peak,len(states))
    return len(states),work,peak,'complete'


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--model',required=True); ap.add_argument('--seed',type=int,default=1)
    ap.add_argument('--state-limit',type=int,default=2000000); ap.add_argument('--audit-seconds',type=float,default=105.0)
    args=ap.parse_args(); started=time.monotonic(); deadline=started+max(1,args.audit_seconds)
    acceptance='All nonobjective rows have exact integral binary PB representations and their reduced-DP state audit completes within the state limit.'
    pivot='Generate a complete Tseitin PB encoding if supported and manageable; otherwise repair the first domain/parser obstruction or replace DP encoding for rows causing state explosion.'
    target='Strict feasibility proof: a SAT witness checkable against the MIP, or an UNSAT certificate independently accepted by DRAT-trim.'
    report={'seed':args.seed,'acceptance_criterion':acceptance,'pivot_condition':pivot,'target_bound':target}
    try:
        rt,cols,rhs,ranges,lb,ub,integer,variables,obj,records=parse_mps(args.model)
        nonbinary=[]
        for v in sorted(variables):
            if v not in integer or abs(lb[v])>1e-9 or abs(ub[v]-1)>1e-9: nonbinary.append({'variable':v,'integer':v in integer,'lb':lb[v],'ub':None if math.isinf(ub[v]) else ub[v]})
            if len(nonbinary)>=25: break
        unsupported=[]; row_stats=[]; total_states=0; total_work=records; peak=0; audited=0
        if ranges: unsupported.append({'kind':'RANGES','count':len(ranges),'first':next(iter(ranges))})
        for row,typ in rt.items():
            if typ=='N': continue
            if time.monotonic()>deadline: break
            terms=cols.get(row,{})
            iw=[]; bad=False
            b=as_int(rhs.get(row,0.0))
            if b is None: unsupported.append({'row':row,'reason':'nonintegral_rhs'}); continue
            for v,a in terms.items():
                ai=as_int(a)
                if ai is None:
                    unsupported.append({'row':row,'reason':'nonintegral_coefficient','variable':v,'coefficient':a}); bad=True; break
                if v not in integer or abs(lb[v])>1e-9 or abs(ub[v]-1)>1e-9:
                    unsupported.append({'row':row,'reason':'nonbinary_variable','variable':v}); bad=True; break
                iw.append(ai)
            if bad: continue
            # Convert signed coefficients to positive literal weights by complementing negative terms.
            shift=sum(-a for a in iw if a<0); weights=[abs(a) for a in iw if a]
            checks=[]
            if typ in ('L','E'): checks.append(b+shift)
            if typ in ('G','E'): checks.append(sum(weights)-(b+shift))
            row_peak=0; row_work=0; outcomes=[]
            for cap in checks:
                if cap<0 or cap>=sum(weights):
                    outcomes.append('constant'); total_work+=1; row_work+=1; continue
                count,w,p,why=inequality_states(weights,cap,args.state_limit,deadline)
                total_work+=w; row_work+=w; row_peak=max(row_peak,p); peak=max(peak,p)
                outcomes.append(why)
                if why!='complete':
                    unsupported.append({'row':row,'reason':'dp_'+why,'terms':len(weights),'cap':cap,'peak_states':p})
                    break
                total_states+=count
            audited+=1
            row_stats.append({'row':row,'sense':typ,'terms':len(weights),'weight_sum':sum(weights),'peak_states':row_peak,'work_units':row_work,'outcomes':outcomes})
        elapsed=time.monotonic()-started
        complete=(audited==sum(1 for t in rt.values() if t!='N'))
        manageable=complete and not nonbinary and not unsupported
        report.update({'status':'success','variables':len(variables),'integer_variables':len(integer),'constraint_rows':sum(1 for t in rt.values() if t!='N'),'audited_rows':audited,'parse_records':records,'nonbinary_examples':nonbinary,'unsupported':unsupported[:50],'total_reduced_states':total_states,'peak_row_states':peak,'largest_rows':sorted(row_stats,key=lambda x:(x['peak_states'],x['terms']),reverse=True)[:30],'encoding_recommended':manageable,'runtime_seconds':elapsed,'termination_reason':'audit_complete' if complete else 'audit_time_limit'})
        result={'status':'success','algorithm_family':'exact pseudo-Boolean reduced-state audit','algorithm_role':'proof','hypothesis':'The allcolor feasibility model has an exact binary pseudo-Boolean representation whose row decision diagrams are small enough for a complete SAT encoding.','work_units':max(1,total_work),'termination_reason':report['termination_reason'],'target_bound':target,'seed':args.seed,'runtime_seconds':elapsed,'acceptance_criterion':acceptance,'pivot_condition':pivot,'certificate_artifact':'pb_width_audit.json','encoding_recommended':manageable,'audited_rows':audited,'peak_row_states':peak}
    except Exception as e:
        elapsed=time.monotonic()-started
        report.update({'status':'error','error':repr(e),'runtime_seconds':elapsed,'termination_reason':'parser_or_representation_exception'})
        result={'status':'error','algorithm_family':'exact pseudo-Boolean reduced-state audit','algorithm_role':'proof','hypothesis':'A defensive parser will isolate or eliminate the prior PB translator indexing defect.','work_units':1,'termination_reason':'parser_or_representation_exception','target_bound':target,'seed':args.seed,'runtime_seconds':elapsed,'acceptance_criterion':acceptance,'pivot_condition':pivot,'error':repr(e)}
    with open('pb_width_audit.json','w') as f: json.dump(report,f,indent=2,sort_keys=True)
    with open('method_result.json','w') as f: json.dump(result,f,indent=2,sort_keys=True)

if __name__=='__main__': main()
