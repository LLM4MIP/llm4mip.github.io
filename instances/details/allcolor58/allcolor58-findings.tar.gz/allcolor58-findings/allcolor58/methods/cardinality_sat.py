import argparse, gzip, json, math, os, subprocess, sys, time
from collections import defaultdict
from fractions import Fraction


def open_model(path):
    return gzip.open(path, 'rt', encoding='utf-8', errors='replace') if path.endswith('.gz') else open(path, 'r', encoding='utf-8', errors='replace')


def num(s):
    s = s.replace('D','E').replace('d','e')
    return Fraction(s)


def parse_mps(path):
    section = None
    rows = {}
    objrow = None
    cols = defaultdict(lambda: defaultdict(Fraction))
    rhs_vectors = {}
    range_vectors = {}
    bounds = defaultdict(lambda: [Fraction(0), None])
    integer_vars = set()
    all_vars = []
    seen_vars = set()
    in_integer = False
    with open_model(path) as f:
        for raw in f:
            line = raw.rstrip('\n\r')
            if not line.strip() or line.lstrip().startswith('*'):
                continue
            tok = line.split()
            if not tok:
                continue
            head = tok[0].upper()
            if head in ('NAME','OBJSENSE','OBJNAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA') and (line[:1] not in (' ', '\t') or head in ('ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA')):
                if head == 'ENDATA':
                    break
                section = head
                continue
            if section == 'OBJSENSE':
                continue
            if section == 'ROWS':
                if len(tok) >= 2:
                    typ, rn = tok[0].upper(), tok[1]
                    rows[rn] = typ
                    if typ == 'N' and objrow is None:
                        objrow = rn
            elif section == 'COLUMNS':
                if len(tok) >= 3 and tok[1].strip("'").upper() == 'MARKER':
                    marker = tok[2].strip("'").upper()
                    in_integer = marker == 'INTORG'
                    continue
                if len(tok) < 3:
                    continue
                v = tok[0]
                if v not in seen_vars:
                    seen_vars.add(v); all_vars.append(v)
                if in_integer:
                    integer_vars.add(v)
                pairs = tok[1:]
                for i in range(0, len(pairs)-1, 2):
                    cols[v][pairs[i]] += num(pairs[i+1])
            elif section == 'RHS':
                if len(tok) < 3: continue
                name = tok[0]
                d = rhs_vectors.setdefault(name, defaultdict(Fraction))
                for i in range(1, len(tok)-1, 2):
                    d[tok[i]] += num(tok[i+1])
            elif section == 'RANGES':
                if len(tok) < 3: continue
                name = tok[0]
                d = range_vectors.setdefault(name, defaultdict(Fraction))
                for i in range(1, len(tok)-1, 2):
                    d[tok[i]] += num(tok[i+1])
            elif section == 'BOUNDS':
                if len(tok) < 3: continue
                bt, bn, v = tok[0].upper(), tok[1], tok[2]
                val = num(tok[3]) if len(tok) > 3 else None
                lo, up = bounds[v]
                if bt == 'LO': lo = val
                elif bt == 'UP': up = val
                elif bt == 'FX': lo = val; up = val
                elif bt == 'FR': lo = None; up = None
                elif bt == 'MI': lo = None
                elif bt == 'PL': up = None
                elif bt == 'BV': lo = Fraction(0); up = Fraction(1); integer_vars.add(v)
                elif bt == 'LI': lo = val; integer_vars.add(v)
                elif bt == 'UI': up = val; integer_vars.add(v)
                bounds[v] = [lo, up]
    rhs_name = next(iter(rhs_vectors), None)
    range_name = next(iter(range_vectors), None)
    rhs = rhs_vectors.get(rhs_name, {})
    rng = range_vectors.get(range_name, {})
    row_terms = defaultdict(dict)
    objective = {}
    for v in all_vars:
        for r, a in cols[v].items():
            if a == 0: continue
            if r == objrow:
                objective[v] = a
            elif r in rows and rows[r] != 'N':
                row_terms[r][v] = a
    intervals = {}
    for r, typ in rows.items():
        if typ == 'N': continue
        b = rhs.get(r, Fraction(0))
        lo = up = None
        if typ == 'E': lo = b; up = b
        elif typ == 'L': up = b
        elif typ == 'G': lo = b
        if r in rng:
            q = rng[r]
            if typ == 'L': lo = b - abs(q); up = b
            elif typ == 'G': lo = b; up = b + abs(q)
            elif typ == 'E':
                if q >= 0: lo = b; up = b + q
                else: lo = b + q; up = b
        intervals[r] = (lo, up)
    return {'rows':rows,'terms':row_terms,'intervals':intervals,'vars':all_vars,'bounds':bounds,'integer':integer_vars,'objective':objective,'rhs_name':rhs_name,'range_name':range_name}


class CNF:
    def __init__(self, nbase):
        self.nvar = nbase
        self.clauses = []
    def new(self):
        self.nvar += 1
        return self.nvar
    def add(self, *lits):
        self.clauses.append(tuple(int(x) for x in lits))
    def atmost(self, lits, k):
        n = len(lits)
        if k < 0:
            self.add(); return
        if k >= n: return
        if k == 0:
            for x in lits: self.add(-x)
            return
        if n == 1:
            return
        s = [[self.new() for _ in range(k)] for _ in range(n-1)]
        self.add(-lits[0], s[0][0])
        for j in range(1,k): self.add(-s[0][j])
        for i in range(1,n-1):
            self.add(-lits[i], s[i][0])
            self.add(-s[i-1][0], s[i][0])
            for j in range(1,k):
                self.add(-lits[i], -s[i-1][j-1], s[i][j])
                self.add(-s[i-1][j], s[i][j])
            self.add(-lits[i], -s[i-1][k-1])
        self.add(-lits[-1], -s[n-2][k-1])
    def atleast(self, lits, k):
        self.atmost([-x for x in lits], len(lits)-k)


def find_tool(root, needle):
    candidates=[]
    for base, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if not d.startswith('.')]
        for f in files:
            p=os.path.join(base,f)
            if needle in f.lower() and os.access(p,os.X_OK): candidates.append(p)
    if not candidates: return None
    candidates.sort(key=lambda p:(len(p),p))
    return candidates[0]


def exact_audit(m, assignment):
    bad=[]; maxv=Fraction(0)
    for r,(lo,up) in m['intervals'].items():
        act=sum((a*assignment.get(v,0) for v,a in m['terms'].get(r,{}).items()), Fraction(0))
        viol=Fraction(0)
        if lo is not None and act < lo: viol=lo-act
        if up is not None and act > up: viol=max(viol,act-up)
        if viol:
            bad.append({'row':r,'activity':str(act),'lower':None if lo is None else str(lo),'upper':None if up is None else str(up),'violation':str(viol)})
            maxv=max(maxv,viol)
    bbad=[]
    for v in m['vars']:
        x=Fraction(assignment.get(v,0)); lo,up=m['bounds'][v]
        if (lo is not None and x<lo) or (up is not None and x>up) or (v in m['integer'] and x.denominator!=1): bbad.append(v)
    return bad,bbad,maxv


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--model',required=True); ap.add_argument('--seed',type=int,default=1); ap.add_argument('--solver-seconds',type=int,default=90)
    args=ap.parse_args(); t0=time.monotonic()
    result={'status':'success','algorithm_family':'exact binary cardinality SAT translation with sequential counters','algorithm_role':'hybrid','hypothesis':'The allcolor model is a binary unit-coefficient constraint system whose feasibility can be searched without the failed coordinate-repair representation by translating exact row intervals to cardinality CNF.','work_units':1,'work_unit_name':'translated rows plus CNF clauses','termination_reason':'initialization','target_bound':'verified objective-0 primal feasibility, or an independently checkable UNSAT certificate for the exact translated binary system','objective':None,'seed':args.seed,'requested_algorithm_runtime_seconds':float(args.solver_seconds),'actual_runtime_seconds':0.0,'acceptance_criterion':'Emit best.sol only after SAT and an exact rational audit of every selected MPS row, variable bound, and integrality condition.','pivot_condition':'Scale only if parsing and CNF construction are supported; pivot to a weighted pseudo-Boolean encoding if any non-unit coefficients are encountered.'}
    audit={}
    try:
        m=parse_mps(args.model)
        unsupported=[]
        for v in m['vars']:
            lo,up=m['bounds'][v]
            if lo != 0 or up != 1 or v not in m['integer']:
                unsupported.append({'kind':'domain','variable':v,'lower':None if lo is None else str(lo),'upper':None if up is None else str(up),'integer':v in m['integer']})
                if len(unsupported)>=20: break
        if not unsupported:
            for r,terms in m['terms'].items():
                for v,a in terms.items():
                    if a not in (Fraction(-1),Fraction(1)):
                        unsupported.append({'kind':'coefficient','row':r,'variable':v,'coefficient':str(a)})
                        if len(unsupported)>=20: break
                if unsupported: break
        audit.update({'variables':len(m['vars']),'constraint_rows':len(m['intervals']),'matrix_nonzeros':sum(len(x) for x in m['terms'].values()),'objective_nonzeros':len(m['objective']),'rhs_vector':m['rhs_name'],'range_vector':m['range_name'],'unsupported_examples':unsupported})
        if unsupported:
            result['termination_reason']='representation_unsupported_nonbinary_or_nonunit_model'
            result['work_units']=max(1,sum(len(x) for x in m['terms'].values()))
        else:
            ids={v:i+1 for i,v in enumerate(m['vars'])}; cnf=CNF(len(ids)); translated=0
            for r,(lo,up) in m['intervals'].items():
                lits=[]; shift=0
                for v,a in m['terms'].get(r,{}).items():
                    if a==1: lits.append(ids[v])
                    else: lits.append(-ids[v]); shift-=1
                if lo is not None:
                    q=lo-shift
                    if q.denominator!=1: cnf.add()
                    else: cnf.atleast(lits,int(q))
                if up is not None:
                    q=up-shift
                    if q.denominator!=1: cnf.add()
                    else: cnf.atmost(lits,int(q))
                translated+=1
            audit.update({'translated_rows':translated,'cnf_variables':cnf.nvar,'cnf_clauses':len(cnf.clauses)})
            with open('instance.cnf','w',encoding='ascii') as f:
                f.write('p cnf %d %d\n'%(cnf.nvar,len(cnf.clauses)))
                for c in cnf.clauses: f.write(' '.join(map(str,c))+' 0\n')
            cad=find_tool('/tools/cadical','cadical')
            if not cad: raise RuntimeError('CaDiCaL executable not found in configured tool directory')
            cmd=[cad,'--seed=%d'%args.seed,'--proof=proof.drat','instance.cnf']
            try:
                p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=max(1,args.solver_seconds))
                out=p.stdout; rc=p.returncode
            except subprocess.TimeoutExpired as e:
                out=(e.stdout or '') if isinstance(e.stdout,str) else ((e.stdout or b'').decode(errors='replace'))
                rc=124
            with open('cadical.log','w',encoding='utf-8') as f: f.write(out[-200000:])
            sat=('s SATISFIABLE' in out) or rc==10
            unsat=('s UNSATISFIABLE' in out) or rc==20
            audit.update({'cadical_returncode':rc,'sat':sat,'unsat':unsat})
            result['work_units']=max(1,translated+len(cnf.clauses))
            if sat:
                vals={}
                for line in out.splitlines():
                    if line.startswith('v '):
                        for z in line[2:].split():
                            try: q=int(z)
                            except: continue
                            if q: vals[abs(q)]=q>0
                assignment={v:(1 if vals.get(i,False) else 0) for v,i in ids.items()}
                bad,bbad,maxv=exact_audit(m,assignment)
                audit.update({'exact_row_violations':len(bad),'exact_bound_violations':len(bbad),'maximum_exact_violation':str(maxv),'violation_examples':bad[:20]})
                if not bad and not bbad:
                    obj=sum((a*assignment[v] for v,a in m['objective'].items()),Fraction(0))
                    with open('best.sol','w',encoding='utf-8') as f:
                        f.write('# Objective value = %s\n'%str(float(obj)))
                        for v in m['vars']: f.write('%s %d\n'%(v,assignment[v]))
                    result.update({'termination_reason':'sat_candidate_passed_exact_internal_row_audit','objective':float(obj),'solution_artifact':'best.sol'})
                else:
                    result['termination_reason']='sat_assignment_failed_exact_translation_audit'
            elif unsat:
                result.update({'termination_reason':'translated_cardinality_cnf_unsat_proof_emitted','certificate_artifact':'proof.drat'})
            else:
                result['termination_reason']='cadical_time_limit_or_unknown'
    except Exception as e:
        result['status']='failed'; result['termination_reason']='implementation_or_parse_failure'; result['error']=repr(e)
    result['actual_runtime_seconds']=time.monotonic()-t0
    with open('sat_translation_audit.json','w',encoding='utf-8') as f: json.dump(audit,f,indent=2)
    with open('method_result.json','w',encoding='utf-8') as f: json.dump(result,f,indent=2)

if __name__=='__main__': main()
