import argparse, gzip, json, math, os, random, time


def open_model(path):
    with open(path, 'rb') as f:
        magic = f.read(2)
    return gzip.open(path, 'rt', encoding='utf-8', errors='replace') if magic == b'\x1f\x8b' else open(path, 'rt', encoding='utf-8', errors='replace')


def parse_mps(path):
    row_type = {}
    objective_rows = set()
    rhs = {}
    columns = {}
    lower = {}
    upper = {}
    integer_named = set()
    section = None
    integer_mode = False
    records = 0
    with open_model(path) as f:
        for raw in f:
            records += 1
            s = raw.strip()
            if not s or s.startswith('*'):
                continue
            p = s.split()
            head = p[0].upper()
            if head in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE','OBJNAME'):
                section = head
                if head == 'ENDATA':
                    break
                continue
            if section == 'ROWS':
                if len(p) >= 2:
                    typ, name = p[0].upper(), p[1]
                    if typ == 'N': objective_rows.add(name)
                    else: row_type[name] = typ
            elif section == 'COLUMNS':
                if len(p) >= 2 and p[1].strip("'").upper() == 'MARKER':
                    marker = p[-1].strip("'").upper()
                    integer_mode = marker == 'INTORG'
                    continue
                var = p[0]
                if integer_mode: integer_named.add(var)
                dest = columns.setdefault(var, [])
                i = 1
                while i + 1 < len(p):
                    r = p[i]
                    try: a = float(p[i+1].replace('D','E').replace('d','e'))
                    except ValueError:
                        i += 2
                        continue
                    if r not in objective_rows:
                        dest.append((r, a))
                    i += 2
            elif section == 'RHS':
                i = 1
                while i + 1 < len(p):
                    r = p[i]
                    try: v = float(p[i+1].replace('D','E').replace('d','e'))
                    except ValueError:
                        i += 2
                        continue
                    if r in row_type: rhs[r] = v
                    i += 2
            elif section == 'BOUNDS' and len(p) >= 3:
                typ, var = p[0].upper(), p[2]
                val = 0.0
                if len(p) >= 4:
                    try: val = float(p[3].replace('D','E').replace('d','e'))
                    except ValueError: val = 0.0
                if typ == 'BV':
                    lower[var], upper[var] = 0.0, 1.0
                    integer_named.add(var)
                elif typ == 'FX': lower[var] = upper[var] = val
                elif typ == 'LO': lower[var] = val
                elif typ == 'UP': upper[var] = val
                elif typ == 'LI': lower[var] = val; integer_named.add(var)
                elif typ == 'UI': upper[var] = val; integer_named.add(var)
                elif typ == 'FR': lower[var], upper[var] = -math.inf, math.inf
                elif typ == 'MI': lower[var] = -math.inf
                elif typ == 'PL': upper[var] = math.inf
    allvars = set(columns) | set(lower) | set(upper) | integer_named
    fixed = {}
    binary = []
    unsupported = []
    for v in sorted(allvars):
        lo = lower.get(v, 0.0)
        up = upper.get(v, math.inf)
        if math.isfinite(lo) and math.isfinite(up) and abs(lo-up) <= 1e-12:
            fixed[v] = lo
        elif v in integer_named and lo >= -1e-12 and up <= 1.0 + 1e-12:
            binary.append(v)
        else:
            unsupported.append((v, lo, up, v in integer_named))
    adjusted_rhs = {r: rhs.get(r, 0.0) for r in row_type}
    for v, value in fixed.items():
        if value:
            for r, a in columns.get(v, []):
                if r in adjusted_rhs: adjusted_rhs[r] -= a * value
    rnames = list(row_type)
    rid = {r:i for i,r in enumerate(rnames)}
    senses = [row_type[r] for r in rnames]
    b = [adjusted_rhs[r] for r in rnames]
    incid = []
    for v in binary:
        agg = {}
        for r,a in columns.get(v, []):
            if r in rid: agg[rid[r]] = agg.get(rid[r], 0.0) + a
        incid.append([(i,a) for i,a in agg.items() if abs(a) > 1e-15])
    return binary, fixed, rnames, senses, b, incid, unsupported, records


def viol(sense, activity, rhs):
    if sense == 'E': return abs(activity-rhs)
    if sense == 'L': return max(0.0, activity-rhs)
    if sense == 'G': return max(0.0, rhs-activity)
    return math.inf


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--seed', type=int, default=58)
    ap.add_argument('--runtime', type=float, default=105.0)
    ap.add_argument('--sample', type=int, default=48)
    args = ap.parse_args()
    start = time.monotonic()
    rng = random.Random(args.seed)
    parse_ok = False
    parse_error = None
    try:
        names, fixed, rnames, senses, rhs, incid, unsupported, records = parse_mps(args.model)
        parse_ok = len(unsupported) == 0 and len(names) > 0
    except Exception as e:
        names=[]; fixed={}; rnames=[]; senses=[]; rhs=[]; incid=[]; unsupported=[]; records=0
        parse_error = repr(e)
    deadline = start + max(0.1, args.runtime)
    flips = evaluations = restarts = breakout_updates = 0
    feasible = False
    best_count = len(rnames) if rnames else None
    best_magnitude = None
    best_x = None
    initial_count = None
    if parse_ok:
        n, m = len(names), len(rnames)
        weights = [1.0]*m
        x = [rng.randrange(2) for _ in range(n)]
        activity = [0.0]*m
        for j,val in enumerate(x):
            if val:
                for i,a in incid[j]: activity[i] += a
        vv = [viol(senses[i],activity[i],rhs[i]) for i in range(m)]
        count = sum(v > 1e-7 for v in vv)
        magnitude = sum(vv)
        initial_count = count
        best_count, best_magnitude, best_x = count, magnitude, x[:]
        stagnant = 0
        while time.monotonic() < deadline and not feasible:
            if count == 0:
                feasible = True
                best_x = x[:]
                break
            candidates = set()
            while len(candidates) < min(args.sample,n): candidates.add(rng.randrange(n))
            bestj = -1; bestdelta = math.inf; best_dc = 0; best_dm = 0.0
            for j in candidates:
                sign = 1.0 if x[j] == 0 else -1.0
                dw = 0.0; dc = 0; dm = 0.0
                for i,a in incid[j]:
                    old = vv[i]
                    new = viol(senses[i], activity[i] + sign*a, rhs[i])
                    dw += weights[i]*(new-old)
                    dc += int(new>1e-7)-int(old>1e-7)
                    dm += new-old
                evaluations += len(incid[j])
                if dw < bestdelta - 1e-12 or (abs(dw-bestdelta)<=1e-12 and (dc,best_dm) < (best_dc,dm)):
                    bestdelta, bestj, best_dc, best_dm = dw, j, dc, dm
            if bestj < 0: break
            if bestdelta >= -1e-12:
                stagnant += 1
                if stagnant % 20 == 0:
                    for i,v in enumerate(vv):
                        if v > 1e-7: weights[i] += 1.0
                    breakout_updates += 1
                if rng.random() < 0.12:
                    bestj = rng.randrange(n)
            else:
                stagnant = 0
            sign = 1.0 if x[bestj] == 0 else -1.0
            oldc = oldm = 0.0
            for i,a in incid[bestj]:
                old = vv[i]
                activity[i] += sign*a
                new = viol(senses[i],activity[i],rhs[i])
                vv[i] = new
                count += int(new>1e-7)-int(old>1e-7)
                magnitude += new-old
            x[bestj] ^= 1
            flips += 1
            if (count < best_count) or (count == best_count and magnitude < best_magnitude-1e-9):
                best_count, best_magnitude, best_x = count, magnitude, x[:]
            if stagnant > 4000:
                restarts += 1; stagnant = 0
                x = best_x[:]
                for _ in range(max(1,n//25)): x[rng.randrange(n)] ^= 1
                activity = [0.0]*m
                for j,val in enumerate(x):
                    if val:
                        for i,a in incid[j]: activity[i] += a
                vv = [viol(senses[i],activity[i],rhs[i]) for i in range(m)]
                count = sum(v>1e-7 for v in vv); magnitude=sum(vv)
        if best_count == 0:
            feasible = True
            with open('best.sol','w',encoding='utf-8') as out:
                out.write('# Objective value = 0\n')
                for v,val in fixed.items():
                    if abs(val)>1e-15: out.write('%s %.17g\n' % (v,val))
                for v,val in zip(names,best_x):
                    if val: out.write('%s 1\n' % v)
    elapsed = time.monotonic()-start
    report = {
      'status':'success' if parse_ok else 'failed',
      'algorithm_family':'sparse pseudo-Boolean weighted-breakout local search with fixed-variable elimination',
      'algorithm_role':'proof',
      'hypothesis':'After exact substitution of the 81,884 fixed-zero auxiliary variables, the remaining 2,492-variable pseudo-Boolean system supports high-throughput incremental breakout search and may expose a small residual core or an independently verifiable feasible witness.',
      'work_units':max(1,flips),
      'termination_reason':'feasible_assignment' if feasible else ('runtime_limit' if parse_ok else 'representation_failure'),
      'target_bound':'Proof or justified reduction of the unresolved gap at objective 0.',
      'seed':args.seed,
      'runtime_seconds':elapsed,
      'acceptance_criterion':'Accept a witness only when direct evaluation of every original row after fixed-variable substitution has violation at most 1e-7; scale only if parsing is complete and measured violations or core structure improve.',
      'pivot_condition':'Scale to 1,800 seconds if parsing is exact and throughput is material; otherwise replace the representation or neighborhood according to the measured failure mode.',
      'parse_ok':parse_ok,
      'parse_error':parse_error,
      'parse_records':records,
      'binary_variables':len(names),
      'fixed_variables':len(fixed),
      'constraints':len(rnames),
      'unsupported_count':len(unsupported),
      'unsupported_examples':[{'variable':v,'lower':lo,'upper':up,'integer':it} for v,lo,up,it in unsupported[:10]],
      'initial_violated_rows':initial_count,
      'best_violated_rows':best_count,
      'best_violation_magnitude':best_magnitude,
      'flips':flips,
      'constraint_evaluations':evaluations,
      'breakout_updates':breakout_updates,
      'restarts':restarts,
      'feasible':feasible
    }
    with open('pb_breakout_repaired_report.json','w',encoding='utf-8') as f: json.dump(report,f,indent=2,sort_keys=True)
    with open('method_result.json','w',encoding='utf-8') as f: json.dump(report,f,indent=2,sort_keys=True)

if __name__ == '__main__': main()
