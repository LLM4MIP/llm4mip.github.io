# Formal Solving Strategy: allcolor58

## Goal hierarchy

1. Preserve any controller-verified feasible solution with an objective smaller than the current experiment incumbent.
2. Preserve any globally valid dual bound larger than the current experiment dual bound.
3. Reduce the justified primal-dual gap.
4. Establish optimality or infeasibility only through strict trusted-solver status or independently checked exact proof.

The objective sense is minimization. Pre-experiment public numerical targets are currently unknown because the Background evidence was lost; official primary-source values must be restored before any public-record comparison.

## Phase 1: deterministic propagation dry run

Implement a standalone MPS parser and sparse interval-propagation engine. It will:

- recognize ROWS, COLUMNS, RHS, RANGES, and BOUNDS records, including integer markers and objective offset;
- preserve exact integral data and use conservative rational arithmetic for continuous-variable bounds;
- verify counts and checksums against `structure.json` diagnostics;
- build row adjacency and connected-component statistics;
- apply sound row activity tests and directed-rounding bound updates for integer variables;
- record the number of row scans, bound tightenings, contradiction checks, and queue operations as positive work units;
- compute a globally valid objective lower bound from final domains;
- emit a compact structural profile and `method_result.json` with seed 0, requested runtime, acceptance criterion, pivot condition, target bound, termination reason, and numeric work units.

The first run is a small deterministic validation, not an idle runtime exercise. Acceptance requires successful parsing, consistent model counts, positive propagation work, and a justified bound statement. If accepted, a larger run adds equality substitution, gcd/congruence checks, and repeated-block detection.

## Phase 2: primal feasibility repair

Using the parsed sparse representation and propagated domains, implement incremental weighted violation descent. The search objective is lexicographic: first reduce exact aggregate constraint violation to zero, then reduce the original objective while retaining feasibility. Moves include one-variable changes, equality-balanced pairs, and block moves inferred from repeated row signatures. Adaptive penalties and deterministic seeded restarts provide diversification. Any `best.sol` is submitted to controller verification; an unverified objective is never reported as a bound.

The dry-run acceptance criterion is measurable reduction in violation plus positive evaluated-move work. The pivot condition is stagnation after a stated number of accepted moves or discovery that required domains cannot be safely capped. A plausible but undersized neighborhood will be enlarged before scale-up.

## Phase 3: incidence decomposition and exact neighborhoods

Construct the bipartite incidence graph. Exploit exact connected components immediately. For a giant component, identify articulation variables, repeated row blocks, and small boundary neighborhoods. Enumerate or dynamically program local assignments only where all domains are finite and the boundary is explicit. Each accepted neighborhood pivot must preserve global feasibility or reduce exact violation. Report states, transitions, and pruned assignments as work units.

If graph width is too large, pivot to separator-conditioned block repair or repeated-template aggregation rather than merely increasing runtime.

## Phase 4: proof-oriented SAT cutoff test

Only after exact domain analysis, encode a mathematically closed finite-domain core for an objective cutoff. Continuous variables must either be eliminated exactly through equations/bounds or handled by a separately proved rational feasibility condition. Run CaDiCaL only on the derived CNF. An UNSAT claim is accepted only with a DRAT artifact independently validated by drat-trim and with a documented mapping from the MIP cutoff to CNF. SAT assignments are translated back and checked against the original model.

## Custom-method gate schedule

At least four materially distinct methods will be launched and at least three must complete successfully. Each begins with a deterministic dry run and, if its hypothesis survives, receives a substantive scale-up. Successful custom runtime must total at least 3,600 actual seconds, including at least one scaled run of at least 1,800 seconds. At least one successful method targets a valid dual bound or independently checkable proof; the propagation and SAT methods fill that role. Runtime is never accumulated by sleeping or repeating an exhausted tiny neighborhood.

## Direct solver policy

The fixed Gurobi and COPT diagnostics failed during remote launch and will not be duplicated. No post-baseline direct solver request is allowed before all custom gates are met. Afterwards, any request is at most 600 seconds and must fit the controller-reported remainder of the 1,800-second global allowance. Such a run will be considered only when custom work has supplied a strong incumbent, stronger bound, reduced core, or warm start that supports a specific proof hypothesis.

## Result schema and reproducibility

Every custom run writes `method_result.json` containing status, algorithm family, algorithm role, hypothesis, positive numeric work units, termination reason, target bound, seed, requested/actual runtime, acceptance criterion, pivot condition, and all objective, solution, bound, or certificate artifacts. Source code is preserved under `methods/`. Any negative result is classified as parsing, representation, feasibility repair, neighborhood size, evaluation cost, diversification, or false structural hypothesis before the next experiment is chosen.

## Stop conditions

- Return `feasible` with the stage incomplete when a feasible solution is verified but no proof closes the gap.
- Return `optimal` and stop all further computation immediately only when verified primal and dual bounds coincide within tolerance or an independent exact proof is checked.
- Return `infeasible` only from strict trusted-solver status or a reproducible independently checked certificate.
- A timeout, absent incumbent, propagation contradiction without an independently verified trace, or custom assertion is never treated as a proof.