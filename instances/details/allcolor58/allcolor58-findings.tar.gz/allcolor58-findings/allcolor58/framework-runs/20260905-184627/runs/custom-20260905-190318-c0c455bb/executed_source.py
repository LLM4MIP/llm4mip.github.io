from model_access import load_model
import re,json,collections
D=load_model(); V=D['variables']; R=D['rows']
pat=re.compile(r'^([^ (]+)\((.*)\)$')
def parse(n):
 m=pat.match(n)
 if not m:return n,()
 z=[]
 for a in m.group(2).split(','):
  a=a.strip()
  try:z.append(int(a))
  except:z.append(a)
 return m.group(1),tuple(z)
P=[parse(v['name']) for v in V]
fams=collections.defaultdict(list)
for i,(f,ix) in enumerate(P):fams[f].append(i)
out={'sense':D['sense'],'objective_offset':D['objective_offset'],'counts':D['counts'],'families':{},'row_signatures':[],'blocks':[]}
for f,ids in fams.items():
 typ=collections.Counter(V[i]['type'] for i in ids)
 bnd=collections.Counter((V[i]['lb'],V[i]['ub']) for i in ids)
 obj=collections.Counter(V[i]['obj'] for i in ids)
 ar=collections.Counter(len(P[i][1]) for i in ids)
 dims=[]
 for k in range(max(ar) if ar else 0):
  vals=[P[i][1][k] for i in ids if len(P[i][1])>k]
  dims.append({'min':min(vals),'max':max(vals),'distinct':len(set(vals))})
 out['families'][f]={'count':len(ids),'types':dict(typ),'bounds':dict((str(k),v) for k,v in bnd.items()),'objectives':dict(obj),'arities':dict(ar),'dimensions':dims,'examples':[V[i]['name'] for i in ids[:4]]}
def sig(r):
 # coefficient/family multiplicities, enough to expose generated templates
 c=collections.Counter()
 for j,a in r['terms']:
  c[(P[j][0],a)]+=1
 return (r['sense'],r['rhs'],len(r['terms']),tuple(sorted((f,a,n) for (f,a),n in c.items())))
def equation(r,cap=80):
 ts=[]
 for j,a in r['terms'][:cap]:ts.append([a,V[j]['name'],V[j]['lb'],V[j]['ub']])
 return {'row':r['name'],'sense':r['sense'],'rhs':r['rhs'],'nterms':len(r['terms']),'terms':ts,'truncated':len(r['terms'])>cap}
SC=collections.Counter(sig(r) for r in R)
for s,n in SC.most_common():
 reps=[k for k,r in enumerate(R) if sig(r)==s][:2]
 out['row_signatures'].append({'count':n,'signature':s,'indices':reps,'examples':[equation(R[k]) for k in reps]})
# consecutive coarse-template blocks
last=None; st=0
for k,r in enumerate(R+[None]):
 s=None if r is None else sig(r)
 if k and s!=last:
  out['blocks'].append({'start':st,'end':k-1,'count':k-st,'first':equation(R[st]),'last':equation(R[k-1]),'signature':last})
  st=k
 last=s
with open('template_report.json','w') as h:json.dump(out,h,indent=2)
# concise text emphasizing block boundaries and first equation
with open('template_report.txt','w') as h:
 h.write('VARIABLE FAMILIES\n')
 for f,x in out['families'].items():h.write(f'{f}: {x}\n')
 h.write('\nCONSECUTIVE BLOCKS\n')
 for b in out['blocks']:
  h.write(f"{b['start']}..{b['end']} ({b['count']}): {b['first']}\n")
 h.write('\nTOP SIGNATURES\n')
 for x in out['row_signatures'][:100]:h.write(str(x)+'\n')
with open('method_result.json','w') as h:json.dump({'algorithm_family':'structural semantic extraction','algorithm_role':'diagnostic','hypothesis':'rows form a small number of indexed templates permitting projection','positive_work_units':len(R),'termination_reason':'complete scan','status':'completed'},h)
print(json.dumps({'families':out['families'],'nblocks':len(out['blocks']),'nsignatures':len(out['row_signatures']),'blocks':[(b['start'],b['end'],b['count'],b['first']['row'],b['first']['sense'],b['first']['rhs'],b['first']['nterms']) for b in out['blocks'][:80]]},indent=2))
