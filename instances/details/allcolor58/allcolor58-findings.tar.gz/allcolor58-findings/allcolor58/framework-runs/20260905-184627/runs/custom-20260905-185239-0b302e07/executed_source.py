import re,json,collections
from model_access import load_model
D=load_model(); V=D['variables']; R=D['rows']
def g(x,k,default=None): return x.get(k,default) if isinstance(x,dict) else getattr(x,k,default)
def fam(n):
 m=re.match(r'([A-Za-z]+)',n); return m.group(1) if m else n
print('MODEL',len(V),len(R),'sense',D.get('sense',D.get('objective_sense')))
vf=collections.defaultdict(collections.Counter); examples=collections.defaultdict(list)
for i,v in enumerate(V):
 n=g(v,'name'); f=fam(n); pat=(str(g(v,'type')),str(g(v,'lb')),str(g(v,'ub')),str(g(v,'obj'))); vf[f][pat]+=1
 if len(examples[f])<8: examples[f].append((i,n)+pat)
print('\nVARIABLES')
for f in sorted(vf): print(f,'n=',sum(vf[f].values()),'patterns=',vf[f].most_common(12),'examples=',examples[f])
sig=collections.defaultdict(list)
for ri,r in enumerate(R):
 fc=collections.defaultdict(collections.Counter)
 for ci,a in g(r,'terms'): fc[fam(g(V[ci],'name'))][str(a)]+=1
 key=(g(r,'sense'),str(g(r,'rhs')),tuple((f,tuple(sorted(c.items()))) for f,c in sorted(fc.items())),len(g(r,'terms')))
 sig[key].append(ri)
print('\nROW SIGNATURES',len(sig))
for k,ids in sorted(sig.items(),key=lambda z:(-len(z[1]),z[1][0])):
 print('\nCOUNT',len(ids),'IDS',ids[:5],'KEY',k)
 for ri in ids[:2]:
  r=R[ri]; print(' ',ri,g(r,'name'),':',' + '.join(f'{a}*{g(V[ci],"name")}' for ci,a in g(r,'terms')),g(r,'sense'),g(r,'rhs'))
rp=collections.Counter(re.match(r'[^0-9\[]*',g(r,'name')).group(0) for r in R)
print('\nROW PREFIX',rp)
