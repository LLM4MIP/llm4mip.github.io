# Final Research Report: `allcolor58`

> Operator correction: this original model-written report is preserved as evidence.
> See [operator-audit.md](operator-audit.md) for actual run counts, failed web searches,
> budget accounting and corrections. The proposed objective-zero target is impossible
> by original row c1. The previously verified incumbent remains 258.

## Outcome

The controller's final status is **unknown**.

No result was independently verified during this session:

- Best verified primal bound: **none**
- Best verified dual bound: **none**
- Verified feasible solution: **none**
- Strict optimality proof: **none**
- Strict infeasibility proof: **none**
- Relative gap: **not available**

Accordingly, this report makes no claim that the instance was solved, that any candidate is feasible, or that any bound was accepted.

## Model facts and formulation structure

The controller-provided model summary records:

- 84,376 variables
- 197,154 linear rows
- 515,184 nonzeros
- Minimization objective
- Eight variable families:
  - `w`: 58,464
  - `q`: 19,488
  - `v`: 2,436
  - `o`: 1,392
  - `u`: 1,392
  - `x`: 812
  - `y`: 336
  - `t`: 56
- Fifteen distinct row signatures

Formulation inspection found a nonnegative penalty objective of the form

`sum(o) + 10 sum(u)`.

Since the objective variables are nonnegative, zero is an elementary structural lower limit on objective values. However, the controller did **not** record this as a verified dual bound, and no feasible objective-zero assignment was validated. It must therefore not be presented as a solved optimal value.

Sampled rows show repeated indexed templates linking `o` and `u` to sums of `q`, together with a much larger auxiliary structure involving the other variable families. This supports classifying the instance as a large, highly structured mixed-integer feasibility/penalty model. The exact underlying combinatorial interpretation was not established conclusively in this session.

## Prior results versus session-verified results

Prior material reported an archived public solution with objective 258. That archived result was reviewed only as background and was **not** accepted by the controller in this session. It is also distinct from the rejected objective-zero candidate discussed in prior notes.

The actual rejected objective-zero candidate and its row-level validation diagnostics were not located before the solving phase ended. Therefore none of the following possible explanations was resolved:

1. incomplete or malformed solution serialization;
2. insufficient numerical precision in continuous auxiliary values;
3. inconsistent reconstruction of `q`, `v`, `w`, or other auxiliaries;
4. bound or integrality violations; or
5. genuine infeasibility of the candidate's discrete assignment.

Prior notes suggesting that the discrete part might be repairable remain hypotheses, not evidence of feasibility.

## Work actually performed

The session performed research and diagnostic preparation rather than a completed solve:

1. Inspected the parsed model dimensions, variable families, objective structure, and repeated row templates.
2. Reviewed available prior result/report material to distinguish the reported objective-258 public solution from the missing rejected objective-zero candidate.
3. Formulated a candidate-recovery plan based on evaluating a complete assignment against every original row, variable bound, and integrality condition.
4. Prepared a handoff describing deterministic reconstruction of auxiliary variables as the next diagnostic step.

No custom exact algorithm, repair algorithm, SAT/CP encoding, or optimizer run produced a controller-verified result. Proposed reconstruction and residual-classification procedures were not completed and must not be described as having run successfully.

## Negative results and failure diagnosis

- No candidate solution was verified against the original MPS.
- No objective value became a verified primal bound.
- No dual certificate or accepted dual bound was produced.
- No strict optimality or infeasibility certificate was checked.
- The objective-zero candidate referenced by prior work could not be found in time.
- Without that file and its validator output, row-signature residual analysis and auxiliary reconstruction could not begin.
- The reported objective-258 archive did not substitute for the missing candidate and was not independently validated here.

The principal blocker was therefore artifact recovery and diagnosis, not a demonstrated mathematical impossibility or a conclusive algorithmic failure.

## Phase usage and stopping reason

### Background phase

- Time window: 2026-09-05 10:46:27 UTC to 10:49:36 UTC
- Elapsed wall time: approximately 3 minutes 8 seconds
- Turns: 2
- Billable tokens: 13,336
- Finish reason: agent completed
- Unused token allocation rolled into solving: 11,664

### Solving phase

- Time window: 2026-09-05 10:49:36 UTC to 11:10:56 UTC
- Elapsed wall time: approximately 21 minutes 20 seconds
- Turns: 31
- Billable tokens: 156,938
- Finish reason: reserved handoff budget
- Tokens reserved for reporting: 9,726

The solving phase stopped to preserve the controller-reserved reporting/handoff budget. It did not stop because of a proof, verified incumbent, exhaustive search, or established infeasibility.

### Reporting phase

The reporting phase was reserved solely to record the controller evidence and unresolved state. No further data collection or solving was performed.

## Remaining uncertainty and recommended next work

The most actionable continuation is:

1. Locate the exact rejected objective-zero `best.sol` and the corresponding validator output.
2. Parse the complete assignment with `model_access.read_solution`.
3. Evaluate it with `model_access.evaluate` against every original row, variable bound, and integrality requirement.
4. Group violations by row signature and dependency layer.
5. Determine whether the first violations come from serialization/precision, missing auxiliary values, or the discrete assignment itself.
6. If the discrete assignment is consistent, reconstruct `q`, `v`, `w`, and related auxiliaries deterministically and re-evaluate the entire original model.
7. Submit any repaired solution to the controller for validation; only a controller-accepted result should be reported as feasible.
8. If objective zero is verified feasible, combine that primal result with the nonnegative-objective argument through an operator-approved verification route before claiming optimality.

If the missing candidate cannot be recovered, the next session should reconstruct the combinatorial semantics from all fifteen row signatures before implementing a fresh structure-derived search.

## Conclusion

This session improved the structural understanding of `allcolor58` and clarified that the archived objective-258 result is not the missing objective-zero candidate. It did not establish a verified primal or dual bound. The definitive status remains **unknown**.
