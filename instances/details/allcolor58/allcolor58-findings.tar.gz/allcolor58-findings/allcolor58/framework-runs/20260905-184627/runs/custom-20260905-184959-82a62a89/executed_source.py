import json,re,collections,os
from model_access import load_model

def fld(x,k,default=None):
    if isinstance(x,dict): return x.get(k,default)
    return getattr(x,k,default)

def decstr(x): return str(x)
def parse_name(n):
    m=re.match(r'^([^\(]+)(?:\((.*)\))?$',n)
    fam=m.group(1); inds=()
    if m.group(2) is not None:
        try: inds=tuple(int(z) for z in m.group(2).split(','))
        except: inds=tuple(m.group(2).split(','))
    return fam,inds

data=load_model(); vs=fld(data,'variables',[]); rs=fld(data,'rows',[])
# normalize rows/terms. Terms are documented as (column index, decimal string).
names=[fld(v,'name',str(i)) for i,v in enumerate(vs)]
fams=collections.defaultdict(list)
for i,v in enumerate(vs):
    f,ind=parse_name(names[i]); fams[f].append((i,ind,v))
out={'counts':{'variables':len(vs),'rows':len(rs)},'variable_families':{},'objective_support':[]}
for f,a in sorted(fams.items()):
    dims=max((len(ind) for _,ind,_ in a),default=0)
    ranges=[]
    for d in range(dims):
        vals=sorted({ind[d] for _,ind,_ in a})
        ranges.append({'count':len(vals),'min':vals[0] if vals else None,'max':vals[-1] if vals else None,'values':vals if len(vals)<=70 else vals[:5]+['...']+vals[-5:]})
    typ=collections.Counter(decstr(fld(v,'type')) for _,_,v in a)
    lbs=collections.Counter(decstr(fld(v,'lb')) for _,_,v in a)
    ubs=collections.Counter(decstr(fld(v,'ub')) for _,_,v in a)
    objs=collections.Counter(decstr(fld(v,'obj')) for _,_,v in a)
    out['variable_families'][f]={'count':len(a),'dimensions':dims,'index_ranges':ranges,'types':dict(typ),'lbs':dict(lbs),'ubs':dict(ubs),'objectives':dict(objs),'first':[names[i] for i,_,_ in a[:5]],'last':[names[i] for i,_,_ in a[-5:]]}
for i,v in enumerate(vs):
    o=fld(v,'obj',0)
    try: nz=float(o)!=0
    except: nz=str(o) not in ('0','0.0','-0.0')
    if nz: out['objective_support'].append({'i':i,'name':names[i],'obj':decstr(o),'type':decstr(fld(v,'type')),'lb':decstr(fld(v,'lb')),'ub':decstr(fld(v,'ub'))})

def normterms(r):
    ans=[]
    for z in fld(r,'terms',[]):
        if isinstance(z,dict): j=z.get('column',z.get('index')); c=z.get('coefficient',z.get('value'))
        else: j,c=z
        j=int(j); ans.append((j,decstr(c)))
    return ans

def signature(r):
    c=collections.Counter()
    for j,a in normterms(r):
        f,_=parse_name(names[j]); c[(f,a)]+=1
    return (decstr(fld(r,'sense')),tuple(sorted((f,a,n) for (f,a),n in c.items())),len(normterms(r)))
sig_ids={}; sig_rows=collections.defaultdict(list); seq=[]
for ri,r in enumerate(rs):
    s=signature(r)
    if s not in sig_ids: sig_ids[s]=len(sig_ids)
    sid=sig_ids[s]; sig_rows[sid].append(ri); seq.append(sid)
# contiguous blocks
blocks=[]; st=0
for i in range(1,len(seq)+1):
    if i==len(seq) or seq[i]!=seq[st]:
        blocks.append({'signature':seq[st],'start':st,'end':i-1,'count':i-st,'first_name':fld(rs[st],'name'),'last_name':fld(rs[i-1],'name')}); st=i
out['signatures']=[]
out['representative_rows']=[]
for s,sid in sorted(sig_ids.items(),key=lambda kv:kv[1]):
    inds=sig_rows[sid]
    rhs=collections.Counter(decstr(fld(rs[i],'rhs')) for i in inds)
    out['signatures'].append({'id':sid,'sense':s[0],'term_pattern':s[1],'term_count':s[2],'row_count':len(inds),'first':inds[0],'last':inds[-1],'rhs_counts':dict(rhs)})
    # up to 3 strategic complete examples
    picks=sorted(set([inds[0],inds[len(inds)//2],inds[-1]]))
    for i in picks:
        r=rs[i]
        out['representative_rows'].append({'signature':sid,'index':i,'name':fld(r,'name'),'sense':decstr(fld(r,'sense')),'rhs':decstr(fld(r,'rhs')),'terms':[(names[j],a) for j,a in normterms(r)]})
out['blocks']=blocks
# incidence of each family across signatures
out['family_signature_incidence']={f:[] for f in fams}
for ent in out['signatures']:
    used={x[0] for x in ent['term_pattern']}
    for f in used: out['family_signature_incidence'][f].append(ent['id'])
with open('structure_audit.json','w') as g: json.dump(out,g,indent=2)
with open('method_result.json','w') as g: json.dump({'algorithm_family':'exact formulation audit','algorithm_role':'diagnostic','hypothesis':'indexed domains and complete row blocks reveal the source combinatorial problem and eliminable auxiliaries','positive_work_units':len(rs)+len(vs),'termination_reason':'audit complete','status':'completed'},g,indent=2)
print(json.dumps({'families':out['variable_families'],'objective_support':out['objective_support'][:100],'signatures':out['signatures'],'blocks':blocks},indent=2))
