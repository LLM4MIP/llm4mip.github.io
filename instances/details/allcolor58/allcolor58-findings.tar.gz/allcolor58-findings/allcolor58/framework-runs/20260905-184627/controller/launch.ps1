param([ValidateSet('api-smoke','doctor','init','run','resume','status','dry-run')][string]$Mode = 'run')
$ErrorActionPreference = 'Stop'
$ResearchRoot = 'D:\sufe\code\AI+MIP\research-agent-v3'
$ResearchPython = 'D:\sufe\code\AI+MIP\experiment\.venv\Scripts\python.exe'
$ResearchConfig = Join-Path $PSScriptRoot 'experiment.toml'
$ResearchModel = 'D:\sufe\code\AI+MIP\allcolor58-research-v3-results\instances\allcolor58\input\allcolor58.mps.gz'
$env:PYTHONPATH = Join-Path $ResearchRoot 'src'
$env:PYTHONUNBUFFERED = '1'
$env:PYTHONIOENCODING = 'utf-8'
if (-not $env:SHUBIAOBIAO_API_KEY) {
    $env:SHUBIAOBIAO_API_KEY = [Environment]::GetEnvironmentVariable('SHUBIAOBIAO_API_KEY', 'User')
}
if (-not $env:SHUBIAOBIAO_API_KEY) {
    $env:SHUBIAOBIAO_API_KEY = (Get-Content -LiteralPath 'D:\sufe\code\AI+MIP\experiment\.secrets\SHUBIAOBIAO_API_KEY.txt' -Raw).Trim()
}
if (-not $env:SHUBIAOBIAO_API_KEY -or $env:SHUBIAOBIAO_API_KEY -eq 'PASTE_API_KEY_HERE') { throw 'API key is not configured.' }
Set-Location -LiteralPath $ResearchRoot
switch ($Mode) {
    'api-smoke' { & $ResearchPython -m mip_experiment --config $ResearchConfig api-smoke }
    'doctor' { & $ResearchPython -m mip_experiment --config $ResearchConfig doctor --remote }
    'init' { & $ResearchPython -m mip_experiment --config $ResearchConfig init allcolor58 $ResearchModel }
    'dry-run' { & $ResearchPython -m mip_experiment --config $ResearchConfig run allcolor58 $ResearchModel --dry-run }
    'run' { & $ResearchPython -m mip_experiment --config $ResearchConfig run allcolor58 $ResearchModel --no-commit }
    'resume' { & $ResearchPython -m mip_experiment --config $ResearchConfig resume allcolor58 --no-commit }
    'status' { & $ResearchPython -m mip_experiment --config $ResearchConfig status allcolor58 }
}
exit $LASTEXITCODE
