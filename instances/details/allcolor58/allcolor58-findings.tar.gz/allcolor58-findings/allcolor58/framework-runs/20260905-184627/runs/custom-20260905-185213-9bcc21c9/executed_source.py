import re,json,collections
from model_access import load_model
D=load_model(); V=D.variables; R=D.rows

def fam(n):
 m=re.match(r'([A-Za-z]+)',n); return m.group(1) if m else n
print('MODEL',len(V),len(R),'sense',getattr(D,'sense',None))
# variable families / types / bounds / objective
vf=collections.defaultdict(lambda:collections.Counter())
examples=collections.defaultdict(list)
for i,v in enumerate(V):
 f=fam(v.name); vf[f][(v.type,str(v.lb),str(v.ub),str(v.obj))]+=1
 if len(examples[f])<8: examples[f].append((i,v.name,v.type,str(v.lb),str(v.ub),str(v.obj)))
print('\nVARIABLES')
for f in sorted(vf):
 print(f,'n=',sum(vf[f].values()),'patterns=',vf[f].most_common(12),'examples=',examples[f])
# row signatures: sense,rhs, family coefficient multisets and term count
sig=collections.defaultdict(list)
for ri,r in enumerate(R):
 fc=collections.defaultdict(collections.Counter)
 for ci,a in r.terms: fc[fam(V[ci].name)][str(a)]+=1
 key=(r.sense,str(r.rhs),tuple((f,tuple(sorted(c.items()))) for f,c in sorted(fc.items())),len(r.terms))
 sig[key].append(ri)
print('\nROW SIGNATURES',len(sig))
for k,ids in sorted(sig.items(),key=lambda z:(-len(z[1]),z[1][0])):
 print('\nCOUNT',len(ids),'IDS',ids[:5],'KEY',k)
 for ri in ids[:2]:
  r=R[ri]; print(' ',ri,r.name,':',' + '.join(f'{a}*{V[ci].name}' for ci,a in r.terms),r.sense,r.rhs)
# ordering and row-name prefixes
rp=collections.Counter(re.match(r'[^0-9\[]*',r.name).group(0) for r in R)
print('\nROW PREFIX',rp)
