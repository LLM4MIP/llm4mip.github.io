# Research handoff: allcolor58

## Verified status

The controller ended this phase with status **unknown**. There is no controller-verified primal solution, dual bound, strict optimality proof, or strict infeasibility proof. Accordingly, no finite primal or dual bound should be claimed from this work.

## What actually ran

This phase inspected prior research artifacts, including `prior/final_report.md` and `prior/result.json`, together with the controller-provided model summary. The investigation focused on distinguishing the archived public solution from a previously mentioned rejected objective-0 candidate and on planning an exact residual diagnosis.

No new optimizer run, custom repair run, certificate verification, or controller-accepted solution check was completed during this phase. The archived public `allcolor58.sol` is reported in the prior material as having objective 258; it is not the rejected objective-0 candidate. Its presence in an archive is not a feasibility certificate, and it was not accepted as a primal bound by the current controller.

## Structural conclusions

The model has 84,376 variables, 197,154 rows, and 515,184 nonzeros. Its variable families are `w`, `q`, `v`, `o`, `u`, `x`, `y`, and `t`, and the rows fall into 15 structural signatures.

The objective is

`sum(o) + 10 sum(u)`.

The `o` and `u` variables are nonnegative. Therefore objective value 0 is a valid mathematical lower bound. If an objective-0 assignment is accepted against the original MPS, it matches this lower bound and proves optimality. This observation does not itself prove that such an assignment is feasible.

## Unresolved mathematical issues

1. The actual rejected objective-0 candidate was not located before the handoff deadline.
2. Its violating rows, bounds, integrality residuals, and violation magnitudes remain unknown.
3. It is unknown whether the candidate's discrete assignment is valid and only its continuous auxiliaries are inconsistent, or whether the combinatorial assignment itself violates the formulation.
4. The complete meanings and dependency order of all 15 row signatures have not yet been documented.
5. The archived objective-258 solution has not been accepted by the current controller, so it cannot presently be reported as a verified incumbent.

## Unresolved code and infrastructure issues

1. There is no confirmed path to the rejected objective-0 `best.sol` or its validator report.
2. No evaluator/repair script was completed and tested against a known assignment in this phase.
3. Any future evaluator must use `model_access.load_model`, `read_solution`, and `evaluate`, and must first reproduce a known validation result before its diagnostics are trusted.
4. Auxiliary reconstruction must respect the full variable dependency graph; patching isolated violated rows risks breaking downstream equalities.
5. Decimal output precision and completeness of assignments must be checked separately from mathematical feasibility.

## Strongest next experiment

Recover the rejected objective-0 candidate and validator diagnostics. Then perform one short, deterministic diagnostic run:

1. Read the complete candidate with `model_access.read_solution`.
2. Evaluate every original row, variable bound, and integrality condition with `model_access.evaluate`.
3. Group violations by row signature and report counts, maximum residuals, and representative variable indices.
4. Determine whether any violations involve the primary discrete families (`x`, `y`, or `t`) or only derived families (`q`, `v`, `w`, `o`, and `u`).
5. If only derived variables fail, reconstruct them in row-dependency order from the fixed discrete assignment, write a complete high-precision `best.sol`, and request controller validation.
6. If the repaired point is feasible with objective 0, combine that accepted primal value with the elementary nonnegative-objective lower bound 0; only an operator-approved verification should then be treated as strict proof.

If the objective-0 candidate cannot be recovered, the fallback experiment is to submit the archived objective-258 solution unchanged for controller validation. A successful check would at least preserve a finite incumbent while formulation decoding continues.

## Bottom line

The most promising route remains repair of the missing objective-0 assignment because one accepted feasible point at value 0 would settle the instance. At handoff, however, all bounds remain unverified and the official result is unknown.
