from model_access import load_model
import re,json,collections
D=load_model(); V=D['variables']; R=D['rows']
pat=re.compile(r'^([^ (]+)(?:\((.*)\))?$')
def parse(n):
 m=pat.match(n)
 if not m:return n,()
 if m.group(2) is None:return m.group(1),()
 z=[]
 for a in m.group(2).split(','):
  a=a.strip()
  try:z.append(int(a))
  except:z.append(a)
 return m.group(1),tuple(z)
P=[parse(v['name']) for v in V]
RP=[parse(r['name']) for r in R]
def cntstr(c):
 it=c.items() if hasattr(c,'items') else c
 return {str(k):v for k,v in it}
def eq(k,cap=32):
 r=R[k]
 return {'index':k,'row':r['name'],'sense':r['sense'],'rhs':r['rhs'],'nterms':len(r['terms']),'terms':[[a,V[j]['name']] for j,a in r['terms'][:cap]],'truncated':len(r['terms'])>cap}
out={'sense':D['sense'],'objective_offset':D['objective_offset'],'counts':D['counts']}
vf=collections.defaultdict(list)
for i,(f,ix) in enumerate(P):vf[f].append(i)
out['variable_families']={}
for f,ids in vf.items():
 ar=collections.Counter(len(P[i][1]) for i in ids); dims=[]
 for k in range(max(ar,default=0)):
  vals=[P[i][1][k] for i in ids if len(P[i][1])>k]; nums=[x for x in vals if isinstance(x,int)]
  dims.append({'min':min(nums) if nums else None,'max':max(nums) if nums else None,'distinct':len(set(vals))})
 out['variable_families'][f]={'count':len(ids),'types':cntstr(collections.Counter(V[i]['type'] for i in ids)),'bounds':cntstr(collections.Counter((V[i]['lb'],V[i]['ub']) for i in ids)),'objectives':cntstr(collections.Counter(V[i]['obj'] for i in ids)),'arities':cntstr(ar),'dimensions':dims,'examples':[V[i]['name'] for i in ids[:5]]}
rf=collections.defaultdict(list)
for i,(f,ix) in enumerate(RP):rf[f].append(i)
out['row_families']={}
for f,ids in rf.items():
 picks=[]
 for p in [0,1,len(ids)//2,len(ids)-2,len(ids)-1]:
  if 0<=p<len(ids) and ids[p] not in picks:picks.append(ids[p])
 famterms=collections.Counter()
 for i in ids:
  for j,a in R[i]['terms']:famterms[(P[j][0],a)]+=1
 out['row_families'][f]={'count':len(ids),'senses':cntstr(collections.Counter(R[i]['sense'] for i in ids)),'rhs':cntstr(collections.Counter(R[i]['rhs'] for i in ids).most_common(20)),'nterms':cntstr(collections.Counter(len(R[i]['terms']) for i in ids).most_common(20)),'term_family_coeff_totals':[{'family':a,'coef':b,'occurrences':n} for (a,b),n in famterms.most_common(30)],'examples':[eq(i) for i in picks]}
def sig(i):
 r=R[i]; c=collections.Counter((P[j][0],a) for j,a in r['terms'])
 return (r['sense'],r['rhs'],len(r['terms']),tuple(sorted((f,a,n) for (f,a),n in c.items())))
sc=collections.Counter(); first={}
for i in range(len(R)):
 s=sig(i); sc[s]+=1
 if s not in first:first[s]=i
out['signature_count']=len(sc)
out['top_signatures']=[{'count':n,'signature':s,'example':eq(first[s])} for s,n in sc.most_common(100)]
blocks=[]; bcounts=collections.Counter(); last=None; st=0
for i in range(len(R)+1):
 s=None if i==len(R) else sig(i)
 if i and s!=last:
  bcounts[(last,i-st)]+=1
  if len(blocks)<40:blocks.append({'start':st,'end':i-1,'length':i-st,'example':eq(st)})
  st=i
 last=s
out['block_count']=sum(bcounts.values()); out['first_blocks']=blocks
out['top_block_types']=[{'multiplicity':n,'length':k[1],'signature':k[0]} for k,n in bcounts.most_common(50)]
with open('template_report.json','w') as h:json.dump(out,h,separators=(',',':'))
with open('template_report.txt','w') as h:
 h.write('MODEL '+str({k:out[k] for k in ['sense','objective_offset','counts']})+'\n\nVARIABLE FAMILIES\n')
 for f,x in out['variable_families'].items():h.write(f+' '+str(x)+'\n')
 h.write('\nROW FAMILIES\n')
 for f,x in out['row_families'].items():h.write(f+' '+str(x)+'\n')
 h.write('\nTOP SIGNATURES\n')
 for x in out['top_signatures']:h.write(str(x)+'\n')
with open('method_result.json','w') as h:json.dump({'algorithm_family':'bounded structural semantic extraction','algorithm_role':'diagnostic','hypothesis':'a few indexed row families expose a projectable combinatorial core','positive_work_units':len(R),'termination_reason':'complete scan with capped output','status':'completed'},h)
print(json.dumps({'variables':len(V),'rows':len(R),'var_families':list(vf),'row_families':[(k,len(v)) for k,v in rf.items()],'signatures':len(sc),'blocks':out['block_count']}))
