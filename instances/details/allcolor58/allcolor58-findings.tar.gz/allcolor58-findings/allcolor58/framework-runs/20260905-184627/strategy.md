# Research strategy

## Objective

Obtain a controller-verified feasible solution and then improve it or establish a rigorous dual bound. Optimality or infeasibility may be claimed only after independent verification accepted by the controller.

The reported historical objective 258 is a replay target, not a current bound. The controller presently reports no verified primal or dual value.

## Stage 1: establish ground truth

Run the `audit_and_replay` test described in `method_selection.md`.

Deliverables:

- `structural_audit.json` with exact domain and objective inventories;
- `row_templates.md` describing all row families without semantic guesses;
- `replay_report.json` if a candidate is supplied;
- `best.sol` only for a candidate passing the supplied evaluator;
- `method_result.json` with measured work and termination status.

Decision gate:

- If an emitted candidate passes the original-MPS check, preserve that primal bound immediately.
- If replay fails, retain the violating rows and classify whether the issue is candidate corruption, omitted values, indexing, or a false historical claim.
- If no candidate artifact exists, do not infer one from an objective value; proceed from the structural audit.

## Stage 2: reconstruct the algebra, not the story

For each of the 15 row signatures, determine:

1. exact index ranges;
2. variable domains;
3. whether each row defines an auxiliary, imposes a local choice, or couples blocks globally;
4. which variables occur in the objective;
5. which symmetries are literal automorphisms of the algebra.

Produce a compact formulation note with every proposed identity traceable to rows in the snapshot. Semantic labels such as color, position, or difference remain provisional until all affected templates agree.

## Stage 3: validate a reduced evaluator

Only if fast search needs an incremental evaluator:

1. begin with a known full assignment, preferably a replayed incumbent;
2. compare the specialized evaluator with `model_access.evaluate` on that assignment;
3. make controlled single-variable and block modifications;
4. compare objectives and every affected original row;
5. fail closed on any mismatch.

This stage is mandatory before trusting custom repair scores or projected constraints.

## Stage 4: obtain or improve a primal

Select the search neighborhood from the established algebra.

Preferred order:

1. deterministic propagation of variables defined by equalities;
2. repair of violated global rows while preserving local equalities;
3. block swaps or reassignment moves on true decision variables;
4. large-neighborhood re-optimization with CP/SAT only if an exact encoding is available;
5. multiple seeded restarts only after a short run shows positive progress per unit time.

Every improved candidate must be written as `best.sol` and checked against the original MPS. Preserve every controller-verified improvement even if later methods fail.

## Stage 5: develop lower bounds

Inspect the audited objective and coupling rows to select a bound:

- assignment/flow relaxation if one-to-one structure is established;
- covering or packing bound if global incidence rows dominate;
- counting bound from exact capacities and demands;
- dynamic-programming relaxation if coupling is sequential;
- block decomposition or Lagrangian bound if a small set of rows links otherwise independent blocks.

Document all assumptions. A numerical value from floating-point custom code is a research bound until validated by an accepted certificate or exact derivation.

## Stage 6: exact proof attempt

Attempt strict optimality only when a verified incumbent and a matching or promising lower-bound mechanism exist. Prefer proof-producing finite-domain or combinatorial methods where the operator has a registered checker. Retain proof artifacts, mappings, hashes, and command parameters.

A solver's self-reported `OPTIMAL` or `UNSAT`, a copied log, or prose reasoning is not sufficient. Stop and report only after the controller confirms independent verification.

## Resource and stopping rules

- Begin with a short full-snapshot audit; its work is measurable by rows and variables inspected.
- Scale a search method only after a validation run demonstrates correct evaluation and useful progress.
- Repair plausible implementation defects before abandoning a method.
- Distinguish infrastructure, candidate, encoding, and mathematical failures in every result.
- If no valid candidate, no exploitable projection, and no proof-capable backend can be established after the audit and one well-validated search branch, record an actionable blocker rather than making unsupported claims.

## Immediate next action

Implement and run `methods/audit_and_replay.py` using `load_model`, `read_solution`, and `evaluate`. Supply a historical solution only if an actual artifact is available. Submit any passing `best.sol` to the controller's original-MPS check; otherwise use the completed domain/objective/row audit to choose the first structure-derived search algorithm.