# allcolor58

This trial reproduced the public incumbent 258 but made no numerical improvement
and obtained no optimality proof. See the [post-run audit](operator-audit.md)
for actual attempts, the custom RHS-parser error, the 191,290-token budget
termination, and a fresh zero-tolerance verification. No optimization algorithm
was executed; the two custom programs performed reproduction and diagnostics.

## Result

- Status: `feasible_verified_at_tolerance`
- Best solver-accepted primal: `258`
- Best tolerance-verified primal: `258`
- Best dual bound: `—`
- Combined relative gap: `—`

This README is a controller-generated baseline. It deliberately separates solver
acceptance, tolerance-based feasibility verification, and global proof status.

## Files

- `final_report.md`: outcome, budget, and claim boundary
- `experiments.md` / `experiments.json`: complete run ledger
- `result.json`: machine-readable aggregate
- `structure.json`: controller-owned Gurobi structure extraction
- `method_selection.md`, `research_notes.md`: partial research notes; `background.md` and `strategy.md` were not produced
- `runs/`: raw custom-program results and logs
- `controller/`: executed configuration, state, API responses, job manifests and controller logs
- `verification/`: independent solution checks when supported
