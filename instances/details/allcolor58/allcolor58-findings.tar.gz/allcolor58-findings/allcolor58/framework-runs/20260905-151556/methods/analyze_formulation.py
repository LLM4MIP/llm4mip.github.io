#!/usr/bin/env python3
"""Deterministic structure audit for allcolor58; performs no optimization."""
import argparse, collections, gzip, json, math, os, re

ap=argparse.ArgumentParser()
ap.add_argument('--model',required=True)
ap.add_argument('--sol',default='/resources/best.sol')
a=ap.parse_args()

def opn(p):
    return gzip.open(p,'rt',errors='replace') if p.endswith('.gz') else open(p,'r',errors='replace')

def num(x):
    try:return float(x.replace('D','E').replace('d','e'))
    except:return None

def fam(n):
    m=re.match(r'^([^\(\[]+)[\(\[](.+)[\)\]]$',n)
    if not m:return n,()
    q=[]
    for z in re.split(r'\s*,\s*',m.group(2)):
        try:q.append(int(z))
        except:q.append(z)
    return m.group(1),tuple(q)

# Parse free/fixed-compatible MPS. The supplied model uses ordinary ROWS/COLUMNS/RHS/BOUNDS.
rows={}; order=[]; cols=collections.defaultdict(list); obj=collections.defaultdict(float)
bounds={}; vtype={}; objs=set(); section=None; integer=False
with opn(a.model) as f:
  for raw in f:
    if not raw.strip() or raw.lstrip().startswith('*'):continue
    t=raw.split()
    if not t:continue
    key=t[0].upper()
    if key in ('NAME','OBJSENSE','OBJNAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA'):
        section=key
        if key=='ENDATA':break
        continue
    if section=='ROWS' and len(t)>=2:
        typ,n=t[0].upper(),t[1]
        if typ=='N':objs.add(n)
        else: rows[n]={'sense':typ,'rhs':0.0,'terms':[]}; order.append(n)
    elif section=='COLUMNS':
        if any('MARKER' in x.upper() for x in t):
            integer=any('INTORG' in x.upper() for x in t); continue
        v=t[0]; vtype.setdefault(v,'I' if integer else 'C')
        z=t[1:]
        for k in range(0,len(z)-1,2):
            r=z[k]; c=num(z[k+1])
            if c is None:continue
            if r in objs:obj[v]+=c
            elif r in rows:rows[r]['terms'].append((v,c)); cols[v].append((r,c))
    elif section=='RHS':
        z=t[1:]
        for k in range(0,len(z)-1,2):
            r=z[k]; c=num(z[k+1])
            if r in rows and c is not None:rows[r]['rhs']=c
    elif section=='BOUNDS' and len(t)>=3:
        bt=t[0].upper(); v=t[2]; x=num(t[3]) if len(t)>3 else None
        lo,up=bounds.get(v,(0.0,math.inf))
        if bt=='LO':lo=x
        elif bt=='UP':up=x
        elif bt=='FX':lo=up=x
        elif bt=='FR':lo,up=-math.inf,math.inf
        elif bt=='MI':lo=-math.inf
        elif bt=='PL':up=math.inf
        elif bt=='BV':lo,up=0.0,1.0;vtype[v]='I'
        elif bt=='LI':lo=x;vtype[v]='I'
        elif bt=='UI':up=x;vtype[v]='I'
        bounds[v]=(lo,up)

allvars=set(cols)|set(obj)|set(bounds)|set(vtype)
# Read incumbent. Accepted formats include '# Objective' then name value.
sol={}
if os.path.exists(a.sol):
 with open(a.sol,'r',errors='replace') as f:
  for line in f:
   if not line.strip() or line.lstrip().startswith('#'):continue
   t=line.split()
   if len(t)>=2 and num(t[1]) is not None:sol[t[0]]=num(t[1])

def hist(vals):
 d=collections.Counter(vals)
 return {str(k):v for k,v in sorted(d.items(),key=lambda x:str(x[0]))}

vf={}
for v in sorted(allvars):
 f,ix=fam(v); d=vf.setdefault(f,{'count':0,'arity':collections.Counter(),'mins':{},'maxs':{},'types':collections.Counter(),'objective':collections.Counter(),'degrees':collections.Counter(),'bounds':collections.Counter(),'nonzero_solution':0,'solution_values':collections.Counter(),'objective_value':0.0,'samples':[]})
 d['count']+=1;d['arity'][len(ix)]+=1;d['types'][vtype.get(v,'C')]+=1;d['objective'][obj.get(v,0.0)]+=1;d['degrees'][len(cols.get(v,()))]+=1
 lo,up=bounds.get(v,(0.0,math.inf)); d['bounds'][(lo,up)]+=1
 x=sol.get(v,0.0)
 if abs(x)>1e-12:d['nonzero_solution']+=1
 d['solution_values'][x]+=1;d['objective_value']+=obj.get(v,0.0)*x
 if len(d['samples'])<8:d['samples'].append(v)
 for k,z in enumerate(ix):
  if isinstance(z,int):d['mins'][k]=min(d['mins'].get(k,z),z);d['maxs'][k]=max(d['maxs'].get(k,z),z)
for d in vf.values():
 for k in ('arity','types','objective','degrees','bounds','solution_values'):d[k]=hist(d[k].elements()) if isinstance(d[k],collections.Counter) else d[k]
 d['mins']={str(k):v for k,v in d['mins'].items()};d['maxs']={str(k):v for k,v in d['maxs'].items()}

# Row structural templates, contiguous blocks, and incumbent activity.
def rsig(r):
 z=rows[r]; fc=collections.Counter(); cc=collections.Counter()
 for v,c in z['terms']:fc[(fam(v)[0],c)]+=1;cc[c]+=1
 return (z['sense'],z['rhs'],len(z['terms']),tuple(sorted(fc.items())))
def sigjson(s):
 return {'sense':s[0],'rhs':s[1],'length':s[2],'family_coeff_counts':[[f,c,n] for ((f,c),n) in s[3]]}
templates={}; blocks=[];last=None;start=None;prev=None
viol=[];tight=collections.Counter(); slackstats=collections.defaultdict(lambda:[math.inf,-math.inf,0])
for pos,r in enumerate(order):
 s=rsig(r); rec=templates.setdefault(s,{'count':0,'samples':[]});rec['count']+=1
 if len(rec['samples'])<3:rec['samples'].append({'row':r,'terms':rows[r]['terms'][:60]})
 if s!=last:
  if last is not None:blocks.append({'start_pos':start,'end_pos':pos-1,'first':order[start],'last':prev,'signature':sigjson(last)})
  start=pos;last=s
 prev=r
 z=rows[r];act=sum(c*sol.get(v,0.0) for v,c in z['terms']);rhs=z['rhs']; typ=z['sense']
 sl=(act-rhs if typ=='G' else rhs-act if typ=='L' else -abs(act-rhs))
 slackstats[s][0]=min(slackstats[s][0],sl);slackstats[s][1]=max(slackstats[s][1],sl);slackstats[s][2]+=abs(sl)<=1e-7
 if sl < -1e-7:viol.append([r,typ,rhs,act,sl])
if last is not None:blocks.append({'start_pos':start,'end_pos':len(order)-1,'first':order[start],'last':prev,'signature':sigjson(last)})
rt=[]
for s,d in sorted(templates.items(),key=lambda x:(-x[1]['count'],str(x[0]))):
 q={'signature':sigjson(s),'count':d['count'],'samples':d['samples'],'min_slack':slackstats[s][0],'max_slack':slackstats[s][1],'tight_count':slackstats[s][2]};rt.append(q)

# Decode nonzero indexed core and objective contributors.
core={}; nz=[]; contrib=[]
for v in sorted(allvars):
 x=sol.get(v,0.0); f,ix=fam(v)
 if abs(x)>1e-12:
  nz.append((v,x))
  if f=='o':core[v]=x
 c=obj.get(v,0.0)*x
 if abs(c)>1e-12:contrib.append((v,x,obj.get(v,0.0),c))
contrib.sort(key=lambda z:(-abs(z[3]),z[0]))
by_second=collections.defaultdict(list);by_first=collections.defaultdict(list)
for v,x in core.items():
 _,ix=fam(v)
 if len(ix)>=2:by_first[str(ix[0])].append([ix[1],x]);by_second[str(ix[1])].append([ix[0],x])

out={'model':{'variables':len(allvars),'rows':len(rows),'nonzeros':sum(len(x['terms']) for x in rows.values()),'objective_nz':sum(abs(x)>0 for x in obj.values())},'solution':{'path':a.sol,'assigned':len(sol),'objective':sum(obj.get(v,0)*sol.get(v,0) for v in allvars),'violations':viol[:100],'violation_count':len(viol),'nonzero_count':len(nz)},'variable_families':vf,'row_templates':rt,'contiguous_blocks':blocks[:2000],'block_count':len(blocks),'o_nonzero':core,'o_by_first':by_first,'o_by_second':by_second,'objective_contributors':contrib[:500],'nonzero_samples':nz[:500]}
with open('analysis.json','w') as f:json.dump(out,f,indent=2,sort_keys=True,allow_nan=True)
with open('method_result.json','w') as f:json.dump({'algorithm_family':'deterministic MPS structural reconstruction','algorithm_role':'diagnostic','hypothesis':'indexed row templates reveal a deterministic sequence evaluator and lift','positive_work_units':len(rows)+len(allvars),'termination_reason':'complete audit','status':'completed','objective':out['solution']['objective'],'violation_count':len(viol)},f,indent=2)
# Preserve the checked incumbent unchanged for controller validation.
if os.path.exists(a.sol):
 with open(a.sol,'rb') as src,open('best.sol','wb') as dst:dst.write(src.read())
print(json.dumps({'families':len(vf),'templates':len(rt),'blocks':len(blocks),'objective':out['solution']['objective'],'violations':len(viol)}))
