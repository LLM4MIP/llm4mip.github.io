# Method selection: allcolor58

## Immediate method: public-incumbent reproduction

The strongest credible prior numerical claim is the complete public assignment with reported objective 258. Before developing a new algorithm, copy that assignment byte-for-byte to `best.sol` and let the controller check it against the supplied original MPS.

**Target:** establish a primal bound of 258, not a dual bound or proof of optimality.

**Hypothesis:** the copied public file is a complete feasible assignment for this exact allcolor58 model fingerprint. This differs from the prior objective-0 constructions, which failed 1,244 coupling/completion rows with maximum violation 6.

**Mapping:** no inferred mapping is used in this first test; every named variable/value in the public solution is retained unchanged. Therefore a rejection diagnoses instance/file mismatch or public-assignment validity, while acceptance gives a trusted semantic reference for decoding the `o(i,j)` order variables and the timing/penalty auxiliaries.

**Measurable outcome:** controller acceptance or rejection of `best.sol`, its checked objective, and any reported row/bound/integrality violations. Only after this deterministic validation will sequence-space search be attempted.

No Gurobi/COPT optimization or presolve is used.