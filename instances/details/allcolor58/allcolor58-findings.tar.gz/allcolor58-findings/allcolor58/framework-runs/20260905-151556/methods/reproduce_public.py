#!/usr/bin/env python3
import json, pathlib, shutil, sys

# Reproduce, without modification, the strongest prior assignment.  The controller
# will evaluate best.sol against the supplied original MPS; this program makes no
# feasibility or optimality claim of its own.
src = pathlib.Path('/resources/allcolor58.sol')
if not src.exists():
    candidates = list(pathlib.Path('/resources').glob('*.sol'))
    if not candidates:
        raise FileNotFoundError('public allcolor58.sol was not mounted')
    src = candidates[0]
shutil.copyfile(src, 'best.sol')
text = src.read_text(errors='replace')
nonempty = [x for x in text.splitlines() if x.strip()]
json.dump({
  'algorithm_family':'incumbent reproduction and original-model validation',
  'algorithm_role':'primal',
  'hypothesis':'The archived official MIPLIB assignment is a complete feasible solution of objective 258 in original variable names.',
  'positive_work_units':max(1,len(nonempty)),
  'termination_reason':'copied_complete_public_assignment_for_controller_check',
  'status':'candidate_feasible',
  'source_file':src.name,
  'nonempty_lines':len(nonempty)
}, open('method_result.json','w'), indent=2)
json.dump({'source':str(src),'bytes':src.stat().st_size,'nonempty_lines':len(nonempty),'first_lines':nonempty[:5]}, open('reproduction_trace.json','w'), indent=2)
