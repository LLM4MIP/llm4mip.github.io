# allcolor58 public research notes

## 2026-09-05 — reproduction validation

The model is a nonnegative-objective PrePack sequencing/assignment formulation (84,376 variables, 197,154 rows). The archived official assignment reports objective 258. It is being copied unchanged and submitted to the controller’s checker against the original MPS. This is a primal-reproduction test, not an optimality claim.

The previous objective-0 constructors are not retained as incumbents: their files had 1,244 violated original rows with maximum violation 6. This is diagnosed as an encoding/completion failure, not evidence that objective zero is attainable. The next algorithm will only operate after row and column families have been mapped back to the underlying sequence decisions.
