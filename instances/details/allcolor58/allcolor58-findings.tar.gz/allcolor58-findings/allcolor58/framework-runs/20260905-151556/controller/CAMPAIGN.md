# allcolor58: research-agent-v3 campaign

- Start: 2026-09-05 15:15:54 Asia/Shanghai.
- Initial controller PowerShell PID: 32392.
- Framework commit: effd2c4a087e0eb0ba147ed2c1608f8671af6e97.
- Results baseline commit: 3d1bad4 (origin/main at clone time).
- Model requested and returned in smoke test: gpt-5.6-sol.
- API smoke: succeeded; 13 input + 3 output tokens, separate from experiment budget.
- Model SHA256: CECF7B32C4333A8CF3A838387AFB8D00092067C3E56BD72B48B031DF66A58397.
- Local config SHA256: 93490B35658E311B239C7BD50901ABC09C38A0D789CE5F012C02F8DCAB239578.
- Token budget: 200,000 input plus output, including reported reasoning output once.
- Background: 3,600 seconds / 25,000 tokens.
- Solving: 7,200 seconds / 155,000 tokens.
- Reporting: 1,800 seconds / 20,000 tokens.
- Unused token quota rolls forward only; time quotas do not roll forward.
- Solver policy: structure_only; no Gurobi/COPT optimization.
- Custom computation: euler4 CPU, 32 threads maximum, 16 GiB per custom job, network-disabled sandbox; no GPUs.
- Remote root: /data1/wyc/miplib-experiments.
- Preflight: API smoke, Gurobi and COPT availability, CPU sandbox checks succeeded.
- Preflight euler4 capacity: 128 logical CPUs; load average about 56, approximately 493 GiB available memory. Existing unrelated jobs were left untouched.
- Prior audited public incumbent: 258. Historical objective-0 candidates are invalid; prior results are read-only evidence, not a new discovery.
- Results checkout: D:/sufe/code/AI+MIP/allcolor58-research-v3-results.
- Results directory: instances/allcolor58/framework-runs/20260905-151556.
- Controller state: allcolor58/state.json relative to this directory.
- Publication: automatic commit disabled; review and publish scoped results to main after completion.
- Framework source remains on research-agent-v3; local config and logs are Git-ignored.

The controller's configured phase limits are not a guarantee of proof or improvement. Only independently checked evidence supports a feasibility, bound, or optimality claim.
