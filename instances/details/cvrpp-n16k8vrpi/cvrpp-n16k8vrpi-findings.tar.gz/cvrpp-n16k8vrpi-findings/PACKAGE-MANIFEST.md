# Package manifest: cvrpp-n16k8vrpi

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 11
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/P-n16-k8.opt`
- `artifacts/P-n16-k8.vrp`
- `artifacts/cvrpp-n16k8-exact-certificate.json`
- `logs/cvrpp-n16k8vrpi-copt-baseline.log`
- `logs/cvrpp-n16k8vrpi-gurobi-baseline.log`
- `logs/cvrpp-n16k8vrpi-gurobi-known450-focus3.log`
- `scripts/cvrpp_n16k8_exact_dp.py`
- `solutions/cvrpp-n16k8vrpi-known450.sol`
- `solutions/cvrpp-n16k8vrpi-known450.sol.gz`
- `solutions/cvrpp-n16k8vrpi-verified450.sol`

## Excluded files

- `input/cvrpp-n16k8vrpi.mps.gz (269622 bytes; raw benchmark input; sha256 d07ca11a223231562842334a053ea4d891c33d74c7245cccb4fcc0fab3216b86)`
