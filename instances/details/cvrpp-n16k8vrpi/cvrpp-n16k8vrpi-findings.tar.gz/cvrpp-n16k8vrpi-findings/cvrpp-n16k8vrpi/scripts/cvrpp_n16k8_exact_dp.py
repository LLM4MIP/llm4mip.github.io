#!/usr/bin/env python3
"""Exhaustive exact solver/certificate for the CVRPLIB instance P-n16-k8.

The MIPLIB instance cvrpp-n16k8vrpi is the indicator-constraint MiniZinc
compilation of this 15-customer CVRP.  We enumerate every capacity-feasible
route, solve the TSP ordering of each route exactly, and then solve the exact
8-route set-partitioning problem by dynamic programming.
"""

from __future__ import annotations

import argparse
import itertools
import json
import math
from functools import lru_cache
from pathlib import Path


CAPACITY = 35
VEHICLES = 8
# Official node 1 is the depot; nodes 2,...,16 are customers.
COORDS = [
    (30, 40),
    (37, 52),
    (49, 49),
    (52, 64),
    (31, 62),
    (52, 33),
    (42, 41),
    (52, 41),
    (57, 58),
    (62, 42),
    (42, 57),
    (27, 68),
    (43, 67),
    (58, 48),
    (58, 27),
    (37, 69),
]
DEMANDS = [0, 19, 30, 16, 23, 11, 31, 15, 28, 8, 8, 7, 14, 6, 19, 11]


def verify_vrp_file(path: Path) -> None:
    capacity: int | None = None
    dimension: int | None = None
    section = ""
    coords: dict[int, tuple[int, int]] = {}
    demands: dict[int, int] = {}
    depots: list[int] = []
    for raw in path.read_text(encoding="ascii").splitlines():
        line = raw.strip()
        if not line or line == "EOF":
            continue
        if line in {"NODE_COORD_SECTION", "DEMAND_SECTION", "DEPOT_SECTION"}:
            section = line
            continue
        if ":" in line and not section:
            key, value = (part.strip() for part in line.split(":", 1))
            if key == "CAPACITY":
                capacity = int(value)
            elif key == "DIMENSION":
                dimension = int(value)
            continue
        tokens = line.split()
        if section == "NODE_COORD_SECTION":
            coords[int(tokens[0])] = (int(tokens[1]), int(tokens[2]))
        elif section == "DEMAND_SECTION":
            demands[int(tokens[0])] = int(tokens[1])
        elif section == "DEPOT_SECTION":
            value = int(tokens[0])
            if value != -1:
                depots.append(value)

    if dimension != len(COORDS) or capacity != CAPACITY or depots != [1]:
        raise ValueError(
            f"Unexpected metadata: dimension={dimension}, capacity={capacity}, depots={depots}"
        )
    parsed_coords = [coords[index] for index in range(1, dimension + 1)]
    parsed_demands = [demands[index] for index in range(1, dimension + 1)]
    if parsed_coords != COORDS or parsed_demands != DEMANDS:
        raise ValueError("The supplied VRP file does not match the certified P-n16-k8 data")
    print(f"verified_vrp_file={path}")


def euc_2d(i: int, j: int) -> int:
    dx = COORDS[i][0] - COORDS[j][0]
    dy = COORDS[i][1] - COORDS[j][1]
    return int(math.sqrt(dx * dx + dy * dy) + 0.5)


def solve() -> dict[str, object]:
    n_customers = len(COORDS) - 1
    full_mask = (1 << n_customers) - 1
    feasible_routes: dict[int, tuple[int, tuple[int, ...], int]] = {}

    for mask in range(1, full_mask + 1):
        nodes = [bit + 1 for bit in range(n_customers) if mask & (1 << bit)]
        demand = sum(DEMANDS[node] for node in nodes)
        if demand > CAPACITY:
            continue
        best_cost = math.inf
        best_order: tuple[int, ...] = ()
        for order in itertools.permutations(nodes):
            cost = euc_2d(0, order[0]) + euc_2d(order[-1], 0)
            cost += sum(euc_2d(order[k], order[k + 1]) for k in range(len(order) - 1))
            if cost < best_cost:
                best_cost = cost
                best_order = order
        feasible_routes[mask] = (int(best_cost), best_order, demand)

    routes_by_first: dict[int, list[int]] = {bit: [] for bit in range(n_customers)}
    for route_mask in feasible_routes:
        for bit in range(n_customers):
            if route_mask & (1 << bit):
                routes_by_first[bit].append(route_mask)

    choice: dict[tuple[int, int], int] = {}

    @lru_cache(maxsize=None)
    def dp(mask: int, routes_left: int) -> int:
        if mask == 0:
            return 0 if routes_left == 0 else math.inf
        if routes_left <= 0 or mask.bit_count() < routes_left:
            return math.inf
        remaining_demand = sum(
            DEMANDS[bit + 1] for bit in range(n_customers) if mask & (1 << bit)
        )
        if remaining_demand > routes_left * CAPACITY:
            return math.inf

        first_bit = (mask & -mask).bit_length() - 1
        best = math.inf
        best_route = 0
        for route_mask in routes_by_first[first_bit]:
            if route_mask & mask != route_mask:
                continue
            route_cost = feasible_routes[route_mask][0]
            tail = dp(mask ^ route_mask, routes_left - 1)
            value = route_cost + tail
            if value < best:
                best = value
                best_route = route_mask
        if best_route:
            choice[(mask, routes_left)] = best_route
        return best

    optimum = dp(full_mask, VEHICLES)
    if optimum == math.inf:
        raise RuntimeError("No feasible eight-route partition")

    selected: list[dict[str, object]] = []
    mask, routes_left = full_mask, VEHICLES
    while mask:
        route_mask = choice[(mask, routes_left)]
        cost, order, demand = feasible_routes[route_mask]
        selected.append(
            {
                "customers": [node + 1 for node in order],  # convert 0-based Python node to official ID
                "demand": demand,
                "cost": cost,
            }
        )
        mask ^= route_mask
        routes_left -= 1

    selected.sort(key=lambda route: tuple(route["customers"]))
    return {
        "instance": "P-n16-k8",
        "customers": n_customers,
        "vehicles": VEHICLES,
        "capacity": CAPACITY,
        "total_demand": sum(DEMANDS),
        "feasible_route_subsets": len(feasible_routes),
        "dynamic_programming_states": dp.cache_info().currsize,
        "optimal_objective": optimum,
        "routes": selected,
        "source": "https://www.coin-or.org/SYMPHONY/branchandcut/VRP/data/P/P-n16-k8.vrp",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--json", type=Path)
    parser.add_argument("--vrp", type=Path)
    args = parser.parse_args()
    if args.vrp:
        verify_vrp_file(args.vrp)
    result = solve()
    print(
        f"instance={result['instance']} customers={result['customers']} "
        f"vehicles={result['vehicles']} capacity={result['capacity']} "
        f"total_demand={result['total_demand']}"
    )
    print(
        f"enumerated_feasible_route_subsets={result['feasible_route_subsets']} "
        f"dp_states={result['dynamic_programming_states']}"
    )
    for index, route in enumerate(result["routes"], start=1):
        print(
            f"route_{index}: customers={route['customers']} "
            f"demand={route['demand']} cost={route['cost']}"
        )
    print(f"EXACT OPTIMUM: {result['optimal_objective']}")
    if args.json:
        args.json.write_text(json.dumps(result, indent=2), encoding="utf-8")
        print(f"wrote_json={args.json}")


if __name__ == "__main__":
    main()
