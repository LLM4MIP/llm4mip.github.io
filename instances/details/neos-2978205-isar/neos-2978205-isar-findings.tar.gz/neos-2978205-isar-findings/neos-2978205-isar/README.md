# `neos-2978205-isar`

## Result

This study obtained the computational global conclusion

```text
OPT = -11.925808687
```

which matches the public incumbent. The original MPS is an assignment/facility-
selection model with 320 binary selectors and 103,680 continuous assignment
variables. Exact coefficient comparison collapses the 320 selector columns to
40 cost types, each appearing once in each of eight selector groups. A
Gale--Ryser margin condition makes the resulting 40-type quotient equivalent to
the original model.

Gurobi solved that exact quotient at the root with equal primal and dual values.
The quotient solution was then lifted constructively, and an independent audit
of the lifted solution found zero row, bound, and integrality violation in the
original 104,000-variable MPS.

## Evidence boundary

The conclusion is based on the executable exact quotient/mapping argument,
the quotient solver result, the deterministic lift, and the independent
original-MPS audit. It is **not** a portable formal proof trace from a
proof-producing solver or proof assistant. Reproduction therefore still relies
on the stated quotient equivalence and on Gurobi's global solve of that quotient.
It does not rely on fixing the incumbent or adding an assumed objective cutoff.

The generated uncompressed quotient MPS is intentionally omitted because it is
fully regenerable by the published script. The compact mapping certificate,
solver records, lifted solutions, and independent audit are retained.

## Provenance

- [MIPLIB instance page](https://miplib.zib.de/instance_details_neos-2978205-isar.html)
- Original MPS SHA-256:
  `4022931069021dc2667b4decb8a84bfcd42925c3e55386550402980205c938b9`
- Research date: 2026-09-09
- Research model: `gpt-5.6-sol`, used for bounded structural design and review
- Generic MIP optimization: approximately 0.565 seconds across two quotient runs

## Reproduction

From this instance directory, with Gurobi, NumPy, and SciPy available:

```powershell
python .\scripts\analyze_lagrangian.py `
  .\input\neos-2978205-isar.mps.gz `
  .\input\neos-2978205-isar.public.sol.gz `
  .\artifacts\main_lagrangian.recheck.json --iterations 100000

python .\scripts\solve_aggregated.py `
  .\input\neos-2978205-isar.mps.gz `
  .\input\neos-2978205-isar.public.sol.gz `
  .\artifacts\aggregated_solve.recheck.json `
  .\solutions\aggregated_lifted.recheck.sol.gz `
  .\logs\aggregated_gurobi_recheck.log --time-limit 600
```

The second command validates the 40-type and group-transversal assumptions
before building the quotient.

## Contents

- [`reports/final_report.md`](reports/final_report.md): full derivation and results
- [`reports/effort_ledger.md`](reports/effort_ledger.md): wall-time, API, and solver accounting
- [`sources/sources.md`](sources/sources.md): authoritative sources and sibling control
- [`artifacts/mapping_certificate.npz`](artifacts/mapping_certificate.npz): parsed type mapping
- [`artifacts/aggregated_solve.json`](artifacts/aggregated_solve.json): quotient solve and lift record
- [`artifacts/independent_solution_audit.json`](artifacts/independent_solution_audit.json): original-MPS audit
- [`solutions/aggregated_lifted.sol.gz`](solutions/aggregated_lifted.sol.gz): lifted witness
- [`logs/aggregated_gurobi_repro.log`](logs/aggregated_gurobi_repro.log): reproducibility solver log

