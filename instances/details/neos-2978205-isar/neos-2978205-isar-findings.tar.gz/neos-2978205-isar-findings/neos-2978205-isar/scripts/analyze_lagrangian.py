"""Recover and analyze the capacitated-selector structure without MIP optimize.

The script uses Gurobi only as an MPS parser.  Fixed-selector solutions are
evaluated as a rectangular linear assignment problem by expanding each selected
facility into ten slots.  Every reported Lagrangian value is recomputed from
the mathematical definition and is therefore a valid lower bound.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
import gzip
import json
import math
from pathlib import Path
import time

import gurobipy as gp
import numpy as np
from scipy.optimize import linear_sum_assignment


def parse_solution(path: Path) -> tuple[float | None, dict[str, float]]:
    values: dict[str, float] = {}
    declared = None
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        for raw in handle:
            line = raw.strip()
            if not line:
                continue
            if line.startswith("=obj="):
                declared = float(line.split()[-1])
                continue
            pieces = line.split()
            if len(pieces) == 2:
                values[pieces[0]] = float(pieces[1])
    return declared, values


def recover(model: gp.Model) -> dict:
    variables = model.getVars()
    constraints = model.getConstrs()
    row_terms: dict[int, list[tuple[int, float]]] = {}
    occurrences: dict[int, list[tuple[int, float]]] = defaultdict(list)
    for con in constraints:
        row = model.getRow(con)
        terms = []
        for p in range(row.size()):
            var = row.getVar(p)
            coef = float(row.getCoeff(p))
            terms.append((var.index, coef))
            occurrences[var.index].append((con.index, coef))
        row_terms[con.index] = terms

    client_rows = []
    cardinality_rows = []
    capacity_rows = []
    for con in constraints:
        terms = row_terms[con.index]
        coeffs = [coef for _, coef in terms]
        if con.Sense == "=" and abs(con.RHS - 1.0) <= 1e-12 and all(abs(c - 1.0) <= 1e-12 for c in coeffs):
            client_rows.append(con.index)
        elif con.Sense == "=" and len(terms) > 0 and all(abs(c - 1.0) <= 1e-12 for c in coeffs):
            cardinality_rows.append(con.index)
        elif con.Sense == "<" and abs(con.RHS) <= 1e-12 and sum(abs(c + 10.0) <= 1e-12 for c in coeffs) == 1:
            capacity_rows.append(con.index)

    assert len(client_rows) == 324, len(client_rows)
    n_facility = len(capacity_rows)
    assert n_facility in (64, 320), n_facility
    assert len(cardinality_rows) == 8, len(cardinality_rows)

    client_position = {row: i for i, row in enumerate(client_rows)}
    capacity_position = {row: j for j, row in enumerate(capacity_rows)}

    selector_for_capacity: dict[int, int] = {}
    x_map: dict[int, tuple[int, int]] = {}
    for row in capacity_rows:
        terms = row_terms[row]
        minus = [v for v, c in terms if abs(c + 10.0) <= 1e-12]
        plus = [v for v, c in terms if abs(c - 1.0) <= 1e-12]
        assert len(minus) == 1 and len(plus) == 324
        selector_for_capacity[row] = minus[0]
        j = capacity_position[row]
        for v in plus:
            clients = [r for r, c in occurrences[v] if r in client_position and abs(c - 1.0) <= 1e-12]
            assert len(clients) == 1
            x_map[v] = (client_position[clients[0]], j)

    selector_index = {selector_for_capacity[row]: capacity_position[row] for row in capacity_rows}
    groups: list[list[int]] = []
    k: list[int] = []
    cardinality_names = []
    for row in cardinality_rows:
        con = constraints[row]
        members = []
        for v, coef in row_terms[row]:
            assert abs(coef - 1.0) <= 1e-12 and v in selector_index
            members.append(selector_index[v])
        assert len(members) == n_facility // 8
        groups.append(sorted(members))
        k.append(int(round(con.RHS)))
        cardinality_names.append(con.ConstrName)
    flattened = [j for group in groups for j in group]
    assert sorted(flattened) == list(range(n_facility))

    assert len(x_map) == 324 * n_facility
    C = np.empty((324, n_facility), dtype=np.float64)
    x_var_index = np.empty((324, n_facility), dtype=np.int64)
    for v, (i, j) in x_map.items():
        C[i, j] = variables[v].Obj
        x_var_index[i, j] = v
        assert len(occurrences[v]) == 2
        assert variables[v].VType == gp.GRB.CONTINUOUS
        assert abs(variables[v].LB) <= 1e-12 and abs(variables[v].UB - 1.0) <= 1e-12
    for v, j in selector_index.items():
        assert len(occurrences[v]) == 2
        assert variables[v].VType in (gp.GRB.BINARY, gp.GRB.INTEGER)
        assert abs(variables[v].LB) <= 1e-12 and abs(variables[v].UB - 1.0) <= 1e-12
        assert abs(variables[v].Obj) <= 1e-12

    return {
        "variables": variables,
        "constraints": constraints,
        "row_terms": row_terms,
        "occurrences": occurrences,
        "client_rows": client_rows,
        "capacity_rows": capacity_rows,
        "groups": groups,
        "k": k,
        "cardinality_names": cardinality_names,
        "selector_for_capacity": selector_for_capacity,
        "selector_index": selector_index,
        "x_map": x_map,
        "x_var_index": x_var_index,
        "C": C,
    }


def audit_solution(model: gp.Model, recovered: dict, declared: float | None, sparse: dict[str, float]) -> dict:
    variables = recovered["variables"]
    values = np.array([sparse.get(v.VarName, 0.0) for v in variables], dtype=np.float64)
    max_bound = 0.0
    max_integrality = 0.0
    for v in variables:
        x = values[v.index]
        max_bound = max(max_bound, max(v.LB - x, x - v.UB, 0.0))
        if v.VType != gp.GRB.CONTINUOUS:
            max_integrality = max(max_integrality, abs(x - round(x)))
    max_row = 0.0
    worst_row = None
    for con in recovered["constraints"]:
        activity = sum(coef * values[v] for v, coef in recovered["row_terms"][con.index])
        if con.Sense == "=":
            violation = abs(activity - con.RHS)
        elif con.Sense == "<":
            violation = max(activity - con.RHS, 0.0)
        else:
            violation = max(con.RHS - activity, 0.0)
        if violation > max_row:
            max_row = violation
            worst_row = con.ConstrName
    objective = float(model.ObjCon + sum(v.Obj * values[v.index] for v in variables))
    selectors = []
    for v, j in recovered["selector_index"].items():
        if values[v] > 0.5:
            selectors.append(j)
    return {
        "declared_objective": declared,
        "recomputed_objective": objective,
        "objective_difference": None if declared is None else objective - declared,
        "max_bound_violation": max_bound,
        "max_integrality_violation": max_integrality,
        "max_row_violation": max_row,
        "worst_row": worst_row,
        "nonzero_entries": int(np.count_nonzero(values)),
        "selected_facilities": selectors,
        "feasible_at_1e-7": max(max_bound, max_integrality, max_row) <= 1e-7,
    }


def fixed_selector_assignment(C: np.ndarray, selected: list[int]) -> dict:
    slots = np.repeat(np.asarray(selected, dtype=int), 10)
    rows, slot_choice = linear_sum_assignment(C[:, slots])
    assert len(rows) == C.shape[0]
    facilities = slots[slot_choice]
    counts = np.bincount(facilities, minlength=C.shape[1])
    return {
        "objective": float(C[rows, facilities].sum()),
        "max_load": int(counts.max()),
        "unused_capacity": int(10 * len(selected) - C.shape[0]),
        "assignment": facilities.tolist(),
        "loads": {str(j): int(counts[j]) for j in selected},
    }


def lagrangian(C: np.ndarray, groups: list[list[int]], k: list[int], upper: float, iterations: int) -> dict:
    groups_np = [np.asarray(group, dtype=int) for group in groups]
    best_L = -math.inf
    best_lam = np.zeros(C.shape[1])
    best_residual = np.zeros(C.shape[1], dtype=int)
    traces = []
    total_iterations = 0
    start = time.perf_counter()

    # Sequential phases start from the best multiplier found so far.  Distinct
    # scale/restart choices reduce dependence on a single step schedule.
    phases = [(0.25, 0.0), (0.8, 0.0), (1.5, 1e-9), (0.4, 1e-8)]
    phase_iterations = max(1, iterations // len(phases))
    lam_seed = np.zeros(C.shape[1])
    for phase, (scale, perturb) in enumerate(phases):
        lam = lam_seed.copy()
        if perturb:
            lam += perturb * (1.0 + np.arange(C.shape[1]) / C.shape[1])
        stagnation = 0
        phase_best = -math.inf
        for it in range(phase_iterations):
            reduced = C + lam[None, :]
            assignment = np.argmin(reduced, axis=1)
            counts = np.bincount(assignment, minlength=C.shape[1])
            z = np.zeros(C.shape[1], dtype=np.int8)
            for G, kg in zip(groups_np, k):
                order = np.argsort(lam[G], kind="stable")
                z[G[order[-kg:]]] = 1
            L = float(reduced[np.arange(C.shape[0]), assignment].sum() - 10.0 * lam.dot(z))
            # Independent recomputation from the original definition.
            check = float(np.min(C + lam[None, :], axis=1).sum())
            check -= 10.0 * sum(float(np.sort(lam[G])[-kg:].sum()) for G, kg in zip(groups_np, k))
            assert abs(L - check) <= 1e-8 * max(1.0, abs(L), abs(check))
            assert L <= upper + 1e-6, (L, upper)
            residual = counts - 10 * z
            assert int(residual.sum()) == C.shape[0] - 10 * sum(k)
            if L > best_L:
                best_L = L
                best_lam = lam.copy()
                best_residual = residual.copy()
                lam_seed = lam.copy()
            if L > phase_best + 1e-12:
                phase_best = L
                stagnation = 0
            else:
                stagnation += 1
            norm2 = float(residual.dot(residual))
            gap = max(upper - L, 0.0)
            if norm2 == 0.0 or gap <= 1e-10:
                break
            decay = 1.0 / math.sqrt(1.0 + it / 250.0)
            step = scale * decay * gap / norm2
            if stagnation > 400:
                step *= 0.25
                stagnation = 0
            lam = np.maximum(0.0, lam + step * residual)
            total_iterations += 1
        traces.append({"phase": phase, "scale": scale, "best": phase_best})

    baseline = float(np.min(C, axis=1).sum())
    top = np.argsort(-np.abs(best_residual))[:20]
    return {
        "baseline_L0": baseline,
        "best_lower_bound": best_L,
        "gap_to_upper": upper - best_L,
        "iterations": total_iterations,
        "elapsed_seconds": time.perf_counter() - start,
        "phases": traces,
        "lambda": best_lam.tolist(),
        "largest_capacity_residuals": [
            {"facility": int(j), "residual": int(best_residual[j]), "lambda": float(best_lam[j])}
            for j in top
        ],
    }


def cost_diagnostics(C: np.ndarray) -> dict:
    rounded = np.round(C, 12)
    _, counts = np.unique(rounded, axis=1, return_counts=True)
    centered = C - C.mean(axis=0, keepdims=True) - C.mean(axis=1, keepdims=True) + C.mean()
    singular = np.linalg.svd(centered, compute_uv=False)
    energy = np.cumsum(singular * singular) / np.sum(singular * singular)
    return {
        "shape": list(C.shape),
        "min": float(C.min()),
        "median": float(np.median(C)),
        "max": float(C.max()),
        "distinct_exact_columns_at_1e-12": int(len(counts)),
        "largest_exact_column_multiplicity": int(counts.max()),
        "centered_numerical_rank_tol_1e-10": int(np.sum(singular > singular[0] * 1e-10)),
        "energy_rank_99pct": int(np.searchsorted(energy, 0.99) + 1),
        "top_singular_values": singular[:20].tolist(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--iterations", type=int, default=20_000)
    args = parser.parse_args()

    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()
    model = gp.read(str(args.model), env)
    recovered = recover(model)
    declared, sparse = parse_solution(args.solution)
    audit = audit_solution(model, recovered, declared, sparse)
    if not audit["feasible_at_1e-7"]:
        raise RuntimeError(f"public solution failed audit: {audit}")
    fixed = fixed_selector_assignment(recovered["C"], audit["selected_facilities"])
    lag = lagrangian(
        recovered["C"], recovered["groups"], recovered["k"],
        audit["recomputed_objective"], args.iterations,
    )
    payload = {
        "source_model": str(args.model),
        "gurobi_used_as_parser_only": True,
        "optimize_called": False,
        "dimensions": {
            "clients": len(recovered["client_rows"]),
            "facilities": len(recovered["capacity_rows"]),
            "groups": len(recovered["groups"]),
            "group_sizes": [len(group) for group in recovered["groups"]],
            "group_rhs": recovered["k"],
            "selected_total": sum(recovered["k"]),
            "capacity": 10,
        },
        "cost_diagnostics": cost_diagnostics(recovered["C"]),
        "public_solution_audit": audit,
        "fixed_selector_exact_assignment": fixed,
        "lagrangian_dual": lag,
        "certified_interval": [lag["best_lower_bound"], audit["recomputed_objective"]],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "group_rhs": recovered["k"],
        "incumbent": audit["recomputed_objective"],
        "fixed_selector": fixed["objective"],
        "lower_bound": lag["best_lower_bound"],
        "gap": lag["gap_to_upper"],
        "seconds": lag["elapsed_seconds"],
    }))


if __name__ == "__main__":
    main()
