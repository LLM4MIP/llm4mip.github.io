"""Exact symmetry aggregation for neos-2978205-isar.

Gurobi is applied only after an independently checked reduction from 320
selector copies and 103,680 assignment variables to 40 cost types, 12,960
assignment variables, and a graphical degree-sequence description of selector
multiplicities.  The script lifts any incumbent back to the original MPS and
audits every original row.
"""
from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path
import sys
import time

import gurobipy as gp
import numpy as np
from scipy.optimize import linear_sum_assignment

sys.path.insert(0, str(Path(__file__).resolve().parent))
from analyze_lagrangian import audit_solution, parse_solution, recover  # noqa: E402


def cost_classes(C: np.ndarray) -> tuple[np.ndarray, np.ndarray, list[list[int]]]:
    unique_rows, inverse = np.unique(C.T, axis=0, return_inverse=True)
    unique_C = unique_rows.T.copy()
    members = [np.flatnonzero(inverse == t).tolist() for t in range(unique_C.shape[1])]
    return unique_C, inverse, members


def realize_group_type_matrix(group_rhs: list[int], z: list[int]) -> np.ndarray:
    """Havel-Hakimi realization of a bipartite degree sequence."""
    remaining = np.asarray(z, dtype=int).copy()
    matrix = np.zeros((len(group_rhs), len(z)), dtype=np.int8)
    for g in np.argsort(-np.asarray(group_rhs), kind="stable"):
        degree = group_rhs[g]
        order = np.argsort(-remaining, kind="stable")
        chosen = order[:degree]
        if degree and remaining[chosen[-1]] <= 0:
            raise RuntimeError("degree sequence is not graphical")
        matrix[g, chosen] = 1
        remaining[chosen] -= 1
    if np.any(remaining != 0):
        raise RuntimeError(f"Havel-Hakimi residual {remaining.tolist()}")
    assert np.all(matrix.sum(axis=1) == np.asarray(group_rhs))
    assert np.all(matrix.sum(axis=0) == np.asarray(z))
    return matrix


def manual_audit(model: gp.Model, recovered: dict, values: np.ndarray) -> dict:
    max_bound = 0.0
    max_integer = 0.0
    for var in recovered["variables"]:
        val = values[var.index]
        max_bound = max(max_bound, max(var.LB - val, val - var.UB, 0.0))
        if var.VType != gp.GRB.CONTINUOUS:
            max_integer = max(max_integer, abs(val - round(val)))
    max_row = 0.0
    worst = None
    for con in recovered["constraints"]:
        activity = sum(coef * values[v] for v, coef in recovered["row_terms"][con.index])
        if con.Sense == "=":
            viol = abs(activity - con.RHS)
        elif con.Sense == "<":
            viol = max(activity - con.RHS, 0.0)
        else:
            viol = max(con.RHS - activity, 0.0)
        if viol > max_row:
            max_row, worst = viol, con.ConstrName
    obj = float(model.ObjCon + sum(v.Obj * values[v.index] for v in recovered["variables"]))
    return {
        "objective": obj,
        "max_bound_violation": max_bound,
        "max_integrality_violation": max_integer,
        "max_row_violation": max_row,
        "worst_row": worst,
        "feasible_at_1e-7": max(max_bound, max_integer, max_row) <= 1e-7,
    }


def write_sparse_solution(path: Path, model: gp.Model, values: np.ndarray, objective: float) -> None:
    lines = [f"=obj= {objective:.12g}"]
    for var in model.getVars():
        val = values[var.index]
        if abs(val) > 1e-10:
            lines.append(f"{var.VarName} {val:.12g}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with gzip.open(path, "wt", encoding="utf-8", newline="\n") as handle:
        handle.write("\n".join(lines) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("public_solution", type=Path)
    parser.add_argument("output_json", type=Path)
    parser.add_argument("lifted_solution", type=Path)
    parser.add_argument("solver_log", type=Path)
    parser.add_argument("--time-limit", type=float, default=600.0)
    args = parser.parse_args()

    parse_env = gp.Env(empty=True)
    parse_env.setParam("OutputFlag", 0)
    parse_env.start()
    original = gp.read(str(args.model), parse_env)
    recovered = recover(original)
    C = recovered["C"]
    type_C, inverse, class_members = cost_classes(C)

    # Exact-copy and group-transversal checks establish the quotient map.
    assert type_C.shape == (324, 40), type_C.shape
    assert sorted(len(m) for m in class_members) == [8] * 40
    group_type_facility = np.full((8, 40), -1, dtype=int)
    for g, group in enumerate(recovered["groups"]):
        seen = set()
        for j in group:
            t = int(inverse[j])
            assert t not in seen
            seen.add(t)
            group_type_facility[g, t] = j
        assert len(seen) == 40
    assert np.all(group_type_facility >= 0)

    declared, public_sparse = parse_solution(args.public_solution)
    public_audit = audit_solution(original, recovered, declared, public_sparse)
    assert public_audit["feasible_at_1e-7"]
    public_z = np.bincount(
        inverse[np.asarray(public_audit["selected_facilities"], dtype=int)], minlength=40
    )

    # Gale-Ryser: for row degrees sorted (5,5,5,4,4,4,4,3), only k=4 adds
    # information beyond 0<=z_t<=8 and sum z=34: the four largest z values
    # must sum to at most 31.  This is equivalent to at most three z_t=8.
    row_degrees = sorted(recovered["k"], reverse=True)
    gale_ryser_rhs = [sum(min(r, q) for r in row_degrees) for q in range(1, 41)]
    assert gale_ryser_rhs[:5] == [8, 16, 24, 31, 34]
    assert all(v == 34 for v in gale_ryser_rhs[4:])
    assert int(public_z.sum()) == 34 and int(public_z.max()) <= 8
    assert int(np.sum(public_z == 8)) <= 3

    args.solver_log.parent.mkdir(parents=True, exist_ok=True)
    solve_env = gp.Env(empty=True)
    solve_env.setParam("OutputFlag", 1)
    solve_env.setParam("LogFile", str(args.solver_log))
    solve_env.start()
    quotient = gp.Model("neos-2978205-isar-exact-40-type-quotient", env=solve_env)
    quotient.Params.TimeLimit = args.time_limit
    quotient.Params.Threads = 8
    quotient.Params.Seed = 1
    quotient.Params.MIPGap = 0.0

    x = quotient.addVars(324, 40, lb=0.0, ub=1.0, vtype=gp.GRB.CONTINUOUS, name="x")
    z = quotient.addVars(40, lb=0.0, ub=8.0, vtype=gp.GRB.INTEGER, name="z")
    full = quotient.addVars(40, vtype=gp.GRB.BINARY, name="is_eight")
    quotient.setObjective(
        gp.quicksum(float(type_C[i, t]) * x[i, t] for i in range(324) for t in range(40)),
        gp.GRB.MINIMIZE,
    )
    quotient.addConstrs((gp.quicksum(x[i, t] for t in range(40)) == 1 for i in range(324)), name="client")
    quotient.addConstrs((gp.quicksum(x[i, t] for i in range(324)) <= 10 * z[t] for t in range(40)), name="capacity")
    quotient.addConstr(gp.quicksum(z[t] for t in range(40)) == 34, name="selected_copies")
    quotient.addConstrs((z[t] <= 7 + full[t] for t in range(40)), name="eight_indicator")
    quotient.addConstr(gp.quicksum(full[t] for t in range(40)) <= 3, name="gale_ryser_k4")
    for t in range(40):
        z[t].Start = int(public_z[t])
        full[t].Start = int(public_z[t] == 8)
    quotient.update()
    quotient_model_path = args.output_json.with_name("exact_quotient.mps")
    quotient.write(str(quotient_model_path))
    mapping_path = args.output_json.with_name("mapping_certificate.npz")
    np.savez_compressed(
        mapping_path,
        cost_matrix=type_C,
        original_facility_to_type=inverse,
        group_type_to_original_facility=group_type_facility,
        original_x_variable_index=recovered["x_var_index"],
    )
    start = time.perf_counter()
    quotient.optimize()
    solve_seconds = time.perf_counter() - start

    has_solution = quotient.SolCount > 0
    result = {
        "exact_reduction": {
            "original_assignment_columns": 103680,
            "original_selectors": 320,
            "cost_types": 40,
            "copies_per_type": [len(m) for m in class_members],
            "every_group_contains_each_type_once": True,
            "group_rhs": recovered["k"],
            "gale_ryser_rhs_first_five": gale_ryser_rhs[:5],
            "degree_sequence_condition": "sum z=34, 0<=z<=8, and at most three z_t equal 8",
            "quotient_model": str(quotient_model_path),
            "mapping_certificate": str(mapping_path),
        },
        "public_solution": public_audit,
        "public_type_multiplicities": public_z.tolist(),
        "solver": {
            "status": int(quotient.Status),
            "status_name": {
                gp.GRB.OPTIMAL: "OPTIMAL",
                gp.GRB.TIME_LIMIT: "TIME_LIMIT",
                gp.GRB.INTERRUPTED: "INTERRUPTED",
            }.get(quotient.Status, str(quotient.Status)),
            "wall_seconds": solve_seconds,
            "runtime_reported": quotient.Runtime,
            "node_count": quotient.NodeCount,
            "solution_count": quotient.SolCount,
            "best_objective": quotient.ObjVal if has_solution else None,
            "best_bound": quotient.ObjBound if has_solution or quotient.Status == gp.GRB.TIME_LIMIT else None,
            "gap": quotient.MIPGap if has_solution else None,
        },
    }

    if has_solution:
        best_z = [int(round(z[t].X)) for t in range(40)]
        margin = realize_group_type_matrix(recovered["k"], best_z)
        slots = np.concatenate([np.repeat(t, 10 * best_z[t]) for t in range(40)]).astype(int)
        rows, chosen_slots = linear_sum_assignment(type_C[:, slots])
        assigned_type = slots[chosen_slots]
        exact_assignment_obj = float(type_C[rows, assigned_type].sum())
        selected_facilities_by_type: list[list[int]] = [[] for _ in range(40)]
        original_values = np.zeros(original.NumVars, dtype=np.float64)
        for g in range(8):
            for t in np.flatnonzero(margin[g]):
                j = int(group_type_facility[g, t])
                selected_facilities_by_type[t].append(j)
                capacity_row = recovered["capacity_rows"][j]
                selector_var = recovered["selector_for_capacity"][capacity_row]
                original_values[selector_var] = 1.0
        for t in range(40):
            clients = np.flatnonzero(assigned_type == t).tolist()
            copies = selected_facilities_by_type[t]
            assert len(clients) <= 10 * len(copies)
            for q, i in enumerate(clients):
                j = copies[q // 10]
                original_values[int(recovered["x_var_index"][i, j])] = 1.0
        lifted_audit = manual_audit(original, recovered, original_values)
        assert lifted_audit["feasible_at_1e-7"]
        assert abs(lifted_audit["objective"] - exact_assignment_obj) <= 1e-7
        write_sparse_solution(args.lifted_solution, original, original_values, lifted_audit["objective"])
        result["quotient_incumbent"] = {
            "z": best_z,
            "number_of_full_types": sum(v == 8 for v in best_z),
            "group_type_incidence": margin.tolist(),
            "exact_assignment_objective": exact_assignment_obj,
            "lifted_original_audit": lifted_audit,
            "lifted_solution": str(args.lifted_solution),
        }

    result["strict_optimality_claim"] = bool(
        quotient.Status == gp.GRB.OPTIMAL
        and has_solution
        and result["quotient_incumbent"]["lifted_original_audit"]["feasible_at_1e-7"]
        and abs(quotient.ObjVal - quotient.ObjBound) <= 1e-7
    )
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result["solver"]))
    if has_solution:
        print(json.dumps(result["quotient_incumbent"]["lifted_original_audit"]))


if __name__ == "__main__":
    main()
