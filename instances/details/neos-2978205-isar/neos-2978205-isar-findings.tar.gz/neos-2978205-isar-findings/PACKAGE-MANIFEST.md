# Package manifest: neos-2978205-isar

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 18
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/aggregated_solve.json`
- `artifacts/aggregated_solve.root_recheck.json`
- `artifacts/independent_solution_audit.json`
- `artifacts/main_lagrangian.json`
- `artifacts/mapping_certificate.npz`
- `input/neos-2978205-isar.public.sol.gz`
- `logs/aggregated_gurobi_repro.log`
- `logs/aggregated_gurobi_root_recheck.log`
- `reports/effort_ledger.md`
- `reports/final_report.md`
- `scripts/analyze_lagrangian.py`
- `scripts/solve_aggregated.py`
- `solutions/aggregated_lifted.root_recheck.sol.gz`
- `solutions/aggregated_lifted.sol.gz`
- `sources/sources.md`
- `structure/structure.compact.json`
- `structure/structure.json`

## Excluded files

- `input/neos-2978205-isar.mps.gz (1420907 bytes; raw benchmark input; sha256 4022931069021dc2667b4decb8a84bfcd42925c3e55386550402980205c938b9)`
