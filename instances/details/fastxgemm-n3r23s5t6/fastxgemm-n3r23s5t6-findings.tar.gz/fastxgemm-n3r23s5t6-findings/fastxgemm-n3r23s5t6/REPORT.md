#  `fastxgemm-n3r23s5t6` follow-up report

Date of release: 2026 -09 -09

##  Strict conclusions

```text
Old project area:[87,174]
New strict range:[90,153]
```

The three points must be stated at the same time:

1. **153 is not a project/GPT primal contribution.** It comes from Ballard, Ikenmeyer, Landsberg,
Ryder is located at [arXiv: 1801.00843 ](https://arxiv.org/abs/1801.00843) Annex B
Given `S_Lader-Z3` decomposition. This article only completes source identification, transcription, model mapping and independent verification.
2. **90 is a new global lower bound from this project.** The proof excludes exact `K=29`, hence
Upgrade the old lower bound 87 to 90.
3.  **is still open.** currently has no exclusion exact `30<=K<=50`, so it cannot be written as 153.
   optimal。

## external exact UB 153

The BILR is composed of a fixed point 5 and a three-circle orbit 6, `R=23`.
The balanced-ternary code exact can be unlocked.

```text
E = 0
K = 51
raw factor support = 3K = 153
official objective = 1000E + 3K = 153
```

We fixed all of the 414 POS/NEG integer variables to this construct, and on the unmodified official MPS,
Gurobi completes the remainder of the variable; 20,394 a variable; 240,116 constraint results in objective as 153.
The integer space independently checks all 729 Brent identities, and checks the line up, lower bound and integrality.
The default number is 0. The main evidence is located at `artifacts/external-audit/`.
It's the `solutions/external-bilr2018-strict-153.sol`.

In the course of the study, Laurent Sorber's `K=58` start through a small unimodular shear.
`K=51` is independently obtained. It is equivalent to BILR; this numerical difference is strict solution separately.
It is classified as `artifacts/bilr-equivalent-shear-strict-153.sol`. It is independent of external results.
The discovery and cross-checking did not constitute a new primal authorship.

## global LB 90

The target slices of each mode 9 have rank 3, so the degree of each factor row is at least as high as
3; two degree-3 tight rows in the same mode cannot share rank position.

If exact `K=29`, the degree pattern must be `(5,3^8)` or `(4,4,3^7)`:

-  `(5,3^8)` requires different rank positions for `8*3=24`, but only for instance 23;
-  Seven tight rows in `(4,4,3^7)` in three modes each covering one position of 21, leaving only two.
The underlying vectors are estimated for each of the four combinations of fixed A or B/C/D orbits.
The primal bound of `K` that can be reached does not exceed 25, 28, 27, 27, all of which are smaller than 29.

Therefore, the exact point satisfies `K>=30`, i.e. support at least 90.
support floor 84, and residual sum at least 1, so the official integer feasible domain has a global effective cut:

```text
sum(ABS_ALT_U, ABS_ALT_V, ABS_ALT_W) + 6*sum(RESIDUAL) >= 90.
```

The finite audit enumeration combines the uncovered-vector pairs 253 with the non-tight-row pairs 36.
9,108 Coordinate/Orbit Situation; all passed.
The root bound is upgraded from 84 to 90.
This is a complete proof. See `artifacts/LB90_PROOF.md`.

##  Continue searching for results and boundaries

Around the BILR 153 the construction of the Hamming coefficient radius 1 / 2 was completed, all
`23*3^9=452,709` single full vector substitution and fixed 51 support locations
exact `K<=50` MIP; none has been improved, and the last branch returns `INFEASIBLE` in full.
Local or fixed-support range accordingly.

Simultaneous enumeration is a bounded simultaneous-conjugation matrix of 1,487,976 in which the 480 remains.
ternary, the `K=51` of the BILR equivalent is still optimal. For this parent 480, a fixed A is deleted.
Complete examination of 2,400 candidates for R22 and 4,800 candidates for R21, with a minimum of 1150 and 2147 respectively.

SAT/XOR probes that allow a new support for MIP, GF, 2, are all terminated by `TIME_LIMIT`; they
It is not a global proof without an infeasibility certificate.
The core objective is to produce verifiable UNSAT/PB certificates for the exact `30<=K<=50`, or to find a new one.
`K<=50` exactly constructed.

##  Published quality

It can be claimed that the strict interval `[90,153]`, the project LB contributed `84->90`, the BILR external UB 153 is already in place.
Independent strict verification on official MPS. 153 cannot be claimed to be the new primal found by the GPT, nor can this title be claimed.
`3K` is raw factor support, not actual addition count after CSE.
