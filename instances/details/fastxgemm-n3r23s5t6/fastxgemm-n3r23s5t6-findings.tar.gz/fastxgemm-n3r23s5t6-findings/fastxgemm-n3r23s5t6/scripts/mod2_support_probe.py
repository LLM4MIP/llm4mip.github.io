#!/usr/bin/env python3
"""Necessary-condition probe: cyclic exact decomposition reduced modulo two."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB

import exact_semantic_audit as semantic


def source_for_rank(mode: str, row: int, rank: int) -> tuple[str, int, int]:
    if rank < semantic.S:
        return ("A", row, rank)
    offset = rank - semantic.S
    group, column = divmod(offset, semantic.T)
    orders = {"U": "BCD", "V": "DBC", "W": "CDB"}
    return (orders[mode][group], row, column)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("start", type=Path)
    parser.add_argument("--support-cap", type=int, default=57)
    parser.add_argument("--time-limit", type=float, default=300)
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    args = parser.parse_args()
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.log.parent.mkdir(parents=True, exist_ok=True)

    start_values, _ = semantic.read_solution(args.start)
    model = gp.Model("fastxgemm_n3r23s5t6_mod2_support")
    x = {}
    start_x = {}
    for letter, width in semantic.BLOCK_WIDTHS.items():
        for row in range(9):
            for column in range(width):
                key = (letter, row, column)
                x[key] = model.addVar(vtype=GRB.BINARY, name=f"X_{letter}_{row}_{column}")
                start_x[key] = int(
                    round(start_values[f"POS_{letter}_{row}_{column}"])
                    or round(start_values[f"NEG_{letter}_{row}_{column}"])
                )
                x[key].Start = start_x[key]

    model.addConstr(gp.quicksum(x.values()) <= args.support_cap, name="SUPPORT_CAP")
    # Every rank term is nonzero in every mode. For an orbit term this means
    # each of its B/C/D vectors is nonzero; for a fixed cube, its A vector is nonzero.
    for column in range(semantic.S):
        model.addConstr(gp.quicksum(x["A", row, column] for row in range(9)) >= 1)
    for letter in "BCD":
        for column in range(semantic.T):
            model.addConstr(gp.quicksum(x[letter, row, column] for row in range(9)) >= 1)
    # Exact slice rank is three over GF(2), hence every factor row has degree >=3.
    for row in range(9):
        model.addConstr(
            gp.quicksum(
                x[letter, row, column]
                for letter, width in semantic.BLOCK_WIDTHS.items()
                for column in range(width)
            ) >= 3,
            name=f"ROW_DEGREE_{row}",
        )

    product_count = 0
    parity_auxiliaries = 0
    for i in range(9):
        for j in range(9):
            for k in range(9):
                products = []
                product_starts = []
                for rank in range(semantic.R):
                    # Several factors can reference the same underlying variable
                    # (notably the A^3 fixed terms).  Deduplicate by the immutable
                    # coefficient key rather than by a gurobipy Var object.
                    input_keys = {
                        source_for_rank("U", i, rank),
                        source_for_rank("V", j, rank),
                        source_for_rank("W", k, rank),
                    }
                    inputs = [x[key] for key in input_keys]
                    y = model.addVar(vtype=GRB.BINARY, name=f"Y_{i}_{j}_{k}_{rank}")
                    product_count += 1
                    for variable in inputs:
                        model.addConstr(y <= variable)
                    model.addConstr(y >= gp.quicksum(inputs) - (len(inputs) - 1))
                    product_start = math.prod(
                        start_x[source_for_rank(mode, row, rank)]
                        for mode, row in (("U", i), ("V", j), ("W", k))
                    )
                    y.Start = product_start
                    products.append(y)
                    product_starts.append(product_start)
                target = semantic.target_value(i, j, k)
                parity = model.addVar(vtype=GRB.INTEGER, lb=0, ub=11, name=f"Q_{i}_{j}_{k}")
                parity.Start = (sum(product_starts) - target) // 2
                parity_auxiliaries += 1
                model.addConstr(gp.quicksum(products) - 2 * parity == target)

    model.setObjective(0.0)
    model.Params.TimeLimit = args.time_limit
    model.Params.Threads = args.threads
    model.Params.Presolve = 2
    model.Params.MIPFocus = 1
    model.Params.Symmetry = 2
    model.Params.FeasibilityTol = 1e-9
    model.Params.IntFeasTol = 1e-9
    model.Params.LogFile = str(args.log)
    model.optimize()

    status_names = {
        GRB.OPTIMAL: "FEASIBLE_FOUND",
        GRB.INFEASIBLE: "INFEASIBLE",
        GRB.TIME_LIMIT: "TIME_LIMIT",
    }
    report = {
        "instance": "fastxgemm-n3r23s5t6",
        "model": "necessary GF(2) reduction of an exact balanced-ternary cyclic decomposition",
        "logic": (
            "Any integer exact decomposition with support <= cap reduces to a feasible "
            "pattern here. Infeasibility would therefore be a valid lower-bound certificate; "
            "feasibility is only a necessary mod-2 pattern and need not lift to signs over Z."
        ),
        "support_cap": args.support_cap,
        "variables": model.NumVars,
        "constraints": model.NumConstrs,
        "nonzeros": model.NumNZs,
        "underlying_binary_coefficients": len(x),
        "product_binaries": product_count,
        "parity_integer_auxiliaries": parity_auxiliaries,
        "author_start_support": sum(start_x.values()),
        "author_start_violates_cap_by": sum(start_x.values()) - args.support_cap,
        "parameters": {"time_limit": args.time_limit, "threads": args.threads},
        "status_code": int(model.Status),
        "status": status_names.get(model.Status, str(model.Status)),
        "solution_count": int(model.SolCount),
        "runtime_seconds": float(model.Runtime),
        "node_count": float(model.NodeCount),
        "best_bound": float(model.ObjBound) if model.IsMIP else None,
    }
    if model.SolCount:
        pattern = [
            {"letter": key[0], "row": key[1], "column": key[2]}
            for key, variable in x.items()
            if variable.X > 0.5
        ]
        report["found_support"] = len(pattern)
        report["found_pattern"] = pattern
    args.json.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in report.items() if k != "found_pattern"}, indent=2))


if __name__ == "__main__":
    main()
