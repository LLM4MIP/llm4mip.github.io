#!/usr/bin/env python3
"""Finite audit of the post-slice-lemma K=29 case split for R23.

This does not enumerate ternary decompositions.  It exhausts the finite
combinatorial cases that remain after the standard rank-three slice lemma:
all rows have degree at least three, distinct tight rows use disjoint rank
positions, and a position covered by tight rows in all three modes is a
coordinate singleton.
"""

from __future__ import annotations

import argparse
import functools
import itertools
import json
from collections import Counter
from pathlib import Path


N = 3
R = 23
S = 5
T = 6
GRID = tuple((i // N, i % N) for i in range(N * N))
MODES = ("U", "V", "W")


def target(i: int, j: int, k: int) -> int:
    n, q = GRID[i]
    q2, m = GRID[j]
    m2, n2 = GRID[k]
    return int(q == q2 and m == m2 and n == n2)


def labels() -> tuple[str, ...]:
    return tuple(
        [f"A{i}" for i in range(S)]
        + [f"{letter}{i}" for letter in "BCD" for i in range(T)]
    )


def factor_at_position(mode: str, position: str) -> str:
    letter, suffix = position[0], position[1:]
    maps = {
        "U": {"A": "A", "B": "B", "C": "C", "D": "D"},
        "V": {"A": "A", "B": "D", "C": "B", "D": "C"},
        "W": {"A": "A", "B": "C", "C": "D", "D": "B"},
    }
    return f"{maps[mode][letter]}{suffix}"


def position_of(mode: str, vector: str) -> str:
    hits = [p for p in labels() if factor_at_position(mode, p) == vector]
    assert len(hits) == 1
    return hits[0]


@functools.lru_cache(maxsize=None)
def opposite_space(mode: str, fixed: int, other: str) -> frozenset[int]:
    """Coordinate support forced on ``other`` by a tight ``mode`` slice."""
    ans: set[int] = set()
    for i, j, k in itertools.product(range(9), repeat=3):
        coords = {"U": i, "V": j, "W": k}
        if coords[mode] == fixed and target(i, j, k):
            ans.add(coords[other])
    assert len(ans) == 3
    return frozenset(ans)


def degree_audit() -> dict:
    vectors = []
    for extra in itertools.product(range(3), repeat=9):
        if sum(extra) == 2:
            vectors.append(tuple(3 + x for x in extra))
    hist = Counter(sum(x == 3 for x in d) for d in vectors)
    assert hist == Counter({7: 36, 8: 9})
    return {
        "ordered_degree_vectors_at_K29": len(vectors),
        "degree_multiset_counts": {"(5,3^8)": 9, "(4,4,3^7)": 36},
        "eight_tight_positions_needed": 24,
        "rank_positions_available": R,
        "eight_tight_impossible": 24 > R,
        "seven_tight_covered_positions_per_mode": 21,
        "seven_tight_uncovered_positions_per_mode": R - 21,
    }


def common_covered_positions(uncovered: frozenset[str]) -> set[str]:
    covered: set[str] = set()
    for position in labels():
        if all(factor_at_position(mode, position) not in uncovered for mode in MODES):
            covered.add(position)
    return covered


def orbit_support_max(
    suffix: int, uncovered: frozenset[str], non_tight: frozenset[int]
) -> tuple[int, dict]:
    """Max support allowed by every tight-primary slice restriction in one orbit."""
    orbit = tuple(f"{letter}{suffix}" for letter in "BCD")
    local_uncovered = frozenset(v for v in orbit if v in uncovered)
    covered = tuple(v for v in orbit if v not in local_uncovered)
    tight = tuple(i for i in range(9) if i not in non_tight)
    best = -1
    witness = None
    for assigned in itertools.product(tight, repeat=len(covered)):
        primary = dict(zip(covered, assigned))
        allowed = {
            v: set(non_tight) if v in local_uncovered else set(non_tight) | {primary[v]}
            for v in orbit
        }
        for position in orbit:
            at = {mode: factor_at_position(mode, position) for mode in MODES}
            for mode in MODES:
                primary_vector = at[mode]
                if primary_vector in local_uncovered:
                    continue
                fixed = primary[primary_vector]
                for other in MODES:
                    if other != mode:
                        allowed[at[other]] &= opposite_space(mode, fixed, other)
        # The official model imposes a nonzero lower bound on every factor
        # column; in a cyclic orbit this makes every B/C/D vector nonzero.
        if any(not allowed[v] for v in orbit):
            continue
        if any(primary[v] not in allowed[v] for v in covered):
            continue
        value = sum(len(allowed[v]) for v in orbit)
        if value > best:
            best = value
            witness = {
                "primary_tight_coordinate": primary,
                "allowed_support": {v: sorted(allowed[v]) for v in orbit},
            }
    return best, witness or {}


def classify(uncovered: frozenset[str]) -> str:
    a_count = sum(v.startswith("A") for v in uncovered)
    if a_count == 2:
        return "two_A"
    if a_count == 1:
        return "A_plus_BCD"
    suffixes = {int(v[1:]) for v in uncovered}
    return "two_BCD_same_orbit" if len(suffixes) == 1 else "two_BCD_different_orbits"


def case_audit() -> dict:
    maxima: dict[str, int] = {}
    counts: Counter[str] = Counter()
    examples: dict[str, dict] = {}
    checked = 0
    for non_tight_pair in itertools.combinations(range(9), 2):
        non_tight = frozenset(non_tight_pair)
        for uncovered_pair in itertools.combinations(labels(), 2):
            uncovered = frozenset(uncovered_pair)
            kind = classify(uncovered)
            counts[kind] += 1
            common = common_covered_positions(uncovered)

            # Each common-covered aligned position gives a singleton U column.
            upper = len(common)
            details: dict = {"common_singletons": len(common), "orbits": {}}

            for vector in uncovered:
                if vector.startswith("A"):
                    upper += len(non_tight)  # uncovered A support is contained in N

            affected_suffixes = sorted(
                {int(v[1:]) for v in uncovered if not v.startswith("A")}
            )
            for suffix in affected_suffixes:
                local_max, witness = orbit_support_max(suffix, uncovered, non_tight)
                assert local_max >= 0
                upper += local_max
                details["orbits"][str(suffix)] = {
                    "support_upper_bound": local_max,
                    "witness": witness,
                }

            # A positions that are not uncovered are already common-covered and
            # counted once above.  All BCD positions outside affected orbits are too.
            maxima[kind] = max(maxima.get(kind, -1), upper)
            counts[kind] += 0
            checked += 1
            if kind not in examples or upper > examples[kind]["K_upper_bound"]:
                examples[kind] = {
                    "non_tight_coordinates": sorted(non_tight),
                    "uncovered_underlying_vectors": sorted(uncovered),
                    "K_upper_bound": upper,
                    **details,
                }

    expected = {
        "two_A": 25,
        "A_plus_BCD": 26,
        "two_BCD_same_orbit": 26,
        "two_BCD_different_orbits": 27,
    }
    assert maxima == expected, (maxima, expected)
    assert all(v < 29 for v in maxima.values())
    return {
        "non_tight_pairs": 36,
        "uncovered_pairs_per_non_tight_pair": len(tuple(itertools.combinations(labels(), 2))),
        "total_cases_checked": checked,
        "case_occurrences_including_all_non_tight_pairs": dict(sorted(counts.items())),
        "maximum_K_allowed_by_slice_geometry": maxima,
        "expected_maxima": expected,
        "all_K29_cases_contradict_support_sum": True,
        "maximizing_examples": examples,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()
    report = {
        "instance": "fastxgemm-n3r23s5t6",
        "parameters": {"N": N, "R": R, "S": S, "T": T},
        "scope": "finite audit after the rank-three tight-slice lemmas; not exhaustive factor enumeration",
        "degree_audit": degree_audit(),
        "K29_case_audit": case_audit(),
    }
    report["all_checks_pass"] = (
        report["degree_audit"]["eight_tight_impossible"]
        and report["K29_case_audit"]["all_K29_cases_contradict_support_sum"]
    )
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
