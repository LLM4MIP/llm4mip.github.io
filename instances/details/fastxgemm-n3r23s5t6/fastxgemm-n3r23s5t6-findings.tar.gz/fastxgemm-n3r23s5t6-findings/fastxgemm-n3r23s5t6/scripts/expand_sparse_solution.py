#!/usr/bin/env python3
"""Expand a sparse MIPLIB .sol(.gz) by writing all absent MPS variables as zero."""

from __future__ import annotations

import argparse
import gzip
from pathlib import Path

import gurobipy as gp


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("input_solution", type=Path)
    parser.add_argument("output_solution", type=Path)
    parser.add_argument("--objective", type=int, required=True)
    args = parser.parse_args()

    opener = gzip.open if args.input_solution.suffix == ".gz" else open
    values: dict[str, str] = {}
    with opener(args.input_solution, "rt", encoding="utf-8") as stream:
        for raw in stream:
            fields = raw.strip().split()
            if len(fields) >= 2 and not fields[0].startswith(("#", "=")):
                values[fields[0]] = fields[1]

    model = gp.read(str(args.mps))
    model.Params.OutputFlag = 0
    model_names = [v.VarName for v in model.getVars()]
    unknown = sorted(set(values) - set(model_names))
    if unknown:
        raise RuntimeError(f"unknown variables: {unknown[:10]}")

    lines = [
        f"=obj= {args.objective}",
        "# Sparse public MIPLIB solution expanded with absent variables equal to zero.",
    ]
    for name in model_names:
        token = values.get(name, "0")
        number = float(token)
        lines.append(f"{name} {int(number) if number.is_integer() else token}")
    args.output_solution.parent.mkdir(parents=True, exist_ok=True)
    args.output_solution.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(
        f"supplied={len(values)} expanded={len(model_names)} "
        f"implicit_zero={len(model_names)-len(values)} unknown={len(unknown)}"
    )


if __name__ == "__main__":
    main()
