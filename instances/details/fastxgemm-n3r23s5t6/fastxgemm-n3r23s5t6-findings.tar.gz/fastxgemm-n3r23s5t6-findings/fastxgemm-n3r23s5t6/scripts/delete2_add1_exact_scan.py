#!/usr/bin/env python3
"""Exhaustively test the nearest support-improving move: delete two, add one."""

from __future__ import annotations

import argparse
import itertools
import json
import time
from pathlib import Path

import numpy as np

import exact_semantic_audit as semantic
from coefficient_radius2_scan import component_key, component_tensor
from one_vector_scan import target_tensor, tensor_from_factors


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()
    started = time.perf_counter()

    values, _ = semantic.read_solution(args.solution)
    raw = semantic.reconstruct_blocks(values, tolerance=1e-9)
    blocks = {letter: np.asarray(raw[letter], dtype=np.int8) for letter in "ABCD"}
    u, v, w = semantic.factors_from_blocks(raw)
    incumbent_tensor = tensor_from_factors(
        np.asarray(u, dtype=np.int8),
        np.asarray(v, dtype=np.int8),
        np.asarray(w, dtype=np.int8),
    )
    target = target_tensor()
    if not np.array_equal(incumbent_tensor, target):
        raise RuntimeError("the input solution is not exact")

    support = []
    zeros = []
    for letter in "ABCD":
        for column in range(semantic.BLOCK_WIDTHS[letter]):
            for row in range(9):
                item = (letter, row, column)
                (support if blocks[letter][row, column] else zeros).append(item)
    if len(support) != 58 or len(zeros) != 149:
        raise RuntimeError(f"unexpected support split {len(support)}+{len(zeros)}")

    keys = [("A", col) for col in range(semantic.S)] + [
        ("G", col) for col in range(semantic.T)
    ]
    base_component = {key: component_tensor(blocks, key) for key in keys}

    def single_delta(item, new_value):
        letter, row, column = item
        modified = {x: blocks[x].copy() for x in "ABCD"}
        modified[letter][row, column] = new_value
        key = component_key(letter, column)
        return component_tensor(modified, key) - base_component[key]

    delete_delta = {item: single_delta(item, 0) for item in support}
    add_delta = {
        (item, sign): single_delta(item, sign)
        for item in zeros
        for sign in (-1, 1)
    }

    nominal = 0
    structurally_valid = 0
    distinct_component_fast_path = 0
    shared_component_exact_recomputations = 0
    exact_matches = []

    for left, right in itertools.combinations(support, 2):
        left_key = component_key(left[0], left[2])
        right_key = component_key(right[0], right[2])
        for addition in zeros:
            add_key = component_key(addition[0], addition[2])
            for sign in (-1, 1):
                nominal += 1

                # The official model forbids an all-zero factor column.
                modified_support = {
                    (letter, column): int(np.count_nonzero(blocks[letter][:, column]))
                    for letter, _, column in (left, right, addition)
                }
                modified_support[(left[0], left[2])] -= 1
                modified_support[(right[0], right[2])] -= 1
                modified_support[(addition[0], addition[2])] += 1
                if any(count == 0 for count in modified_support.values()):
                    continue
                structurally_valid += 1

                if len({left_key, right_key, add_key}) == 3:
                    distinct_component_fast_path += 1
                    delta = delete_delta[left] + delete_delta[right] + add_delta[(addition, sign)]
                else:
                    shared_component_exact_recomputations += 1
                    modified = {x: blocks[x].copy() for x in "ABCD"}
                    modified[left[0]][left[1], left[2]] = 0
                    modified[right[0]][right[1], right[2]] = 0
                    modified[addition[0]][addition[1], addition[2]] = sign
                    delta = np.zeros((9, 9, 9), dtype=np.int16)
                    for key in {left_key, right_key, add_key}:
                        delta += component_tensor(modified, key) - base_component[key]

                if not np.any(delta):
                    exact_matches.append(
                        {
                            "delete": [list(left), list(right)],
                            "add": [*addition, sign],
                        }
                    )

    report = {
        "instance": "fastxgemm-n3r23s5t6",
        "scope": (
            "all coefficient-Hamming-distance-3 patterns that delete exactly two "
            "incumbent support locations and activate exactly one outside location; "
            "no additional sign flips"
        ),
        "incumbent": {"E": 0, "K": 58, "objective": 174},
        "candidate": {"E": 0, "K": 57, "objective": 171},
        "support_locations": len(support),
        "outside_locations": len(zeros),
        "nominal_candidates": nominal,
        "structurally_valid_candidates": structurally_valid,
        "distinct_component_fast_path": distinct_component_fast_path,
        "shared_component_exact_recomputations": shared_component_exact_recomputations,
        "exact_match_count": len(exact_matches),
        "exact_matches": exact_matches[:100],
        "strict_improvement_found": bool(exact_matches),
        "elapsed_seconds": time.perf_counter() - started,
        "interpretation": (
            "No match proves only this nearest support-edit neighborhood. It is not a "
            "global proof for K>=58 and permits no extra sign changes."
        ),
    }
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
