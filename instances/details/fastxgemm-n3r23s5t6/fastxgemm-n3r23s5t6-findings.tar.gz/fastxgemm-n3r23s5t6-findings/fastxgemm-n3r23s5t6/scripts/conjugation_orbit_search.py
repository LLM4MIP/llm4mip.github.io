#!/usr/bin/env python3
"""Search support-reducing simultaneous conjugations of the exact R23 scheme."""

from __future__ import annotations

import argparse
import collections
import itertools
import json
import sys
import time
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import exact_semantic_audit as semantic  # noqa: E402


def matrix_key(matrix: np.ndarray) -> tuple[int, ...]:
    return tuple(int(value) for value in matrix.ravel())


def exact_inverse(matrix: np.ndarray) -> np.ndarray | None:
    determinant = round(float(np.linalg.det(matrix)))
    if abs(determinant) != 1:
        return None
    inverse = np.rint(np.linalg.inv(matrix)).astype(int)
    if not np.array_equal(matrix @ inverse, np.eye(3, dtype=int)):
        return None
    return inverse


def transform_blocks(blocks, p: np.ndarray, p_inv: np.ndarray):
    # If f_M(X)=<M,X>, then f_M(P^-1 X P)=<P^-T M P^T,X>.
    left = p_inv.T
    right = p.T
    transformed = {}
    for letter, matrix in blocks.items():
        array = np.asarray(matrix, dtype=int)
        output = np.zeros_like(array)
        for col in range(array.shape[1]):
            coefficient = array[:, col].reshape(3, 3)
            output[:, col] = (left @ coefficient @ right).reshape(9)
        transformed[letter] = output.tolist()
    return transformed


def exact_tensor_audit(blocks):
    u, v, w = semantic.factors_from_blocks(blocks)
    residual = 0
    max_error = 0
    nonzero_errors = 0
    for i in range(9):
        for j in range(9):
            for k in range(9):
                expansion = semantic.expand_entry(u, v, w, i, j, k)
                error = semantic.target_value(i, j, k) - expansion
                residual += abs(error)
                max_error = max(max_error, abs(error))
                nonzero_errors += int(error != 0)
    support = sum(value != 0 for matrix in blocks.values()
                  for row in matrix for value in row)
    maximum_coefficient = max(abs(value) for matrix in blocks.values()
                              for row in matrix for value in row)
    return {
        "E": residual,
        "K": support,
        "objective": 1000 * residual + 3 * support,
        "max_abs_error": max_error,
        "nonzero_error_coordinates": nonzero_errors,
        "max_abs_coefficient": maximum_coefficient,
        "balanced_ternary": maximum_coefficient <= 1,
    }


def write_pos_neg_solution(blocks, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = ["# exact POS/NEG core from simultaneous conjugation"]
    for letter, width in semantic.BLOCK_WIDTHS.items():
        for row in range(9):
            for col in range(width):
                value = blocks[letter][row][col]
                lines.append(f"POS_{letter}_{row}_{col} {int(value == 1)}")
                lines.append(f"NEG_{letter}_{row}_{col} {int(value == -1)}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("start", type=Path)
    parser.add_argument("--max-depth", type=int, default=6)
    parser.add_argument("--matrix-entry-bound", type=int, default=4)
    parser.add_argument("--inverse-entry-bound", type=int, default=4)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--best-solution", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    args = parser.parse_args()
    for path in (args.json, args.best_solution, args.log):
        path.parent.mkdir(parents=True, exist_ok=True)

    values, _ = semantic.read_solution(args.start)
    original = semantic.reconstruct_blocks(values, tolerance=1e-6)
    baseline = exact_tensor_audit(original)
    if baseline["E"] != 0 or not baseline["balanced_ternary"]:
        raise ValueError(f"input is not exact balanced ternary: {baseline}")

    generators = []
    for i, j in itertools.permutations(range(3), 2):
        for sign in (-1, 1):
            generator = np.eye(3, dtype=int)
            generator[i, j] = sign
            generators.append(generator)

    identity = np.eye(3, dtype=int)
    queue = collections.deque([(identity, 0)])
    seen = {matrix_key(identity)}
    evaluated = 0
    ternary_count = 0
    best = baseline
    best_blocks = original
    best_p = identity
    depth_counts = collections.Counter()
    start_time = time.perf_counter()
    log_lines = [f"baseline={baseline}"]

    while queue:
        p, depth = queue.popleft()
        p_inv = exact_inverse(p)
        assert p_inv is not None
        evaluated += 1
        depth_counts[depth] += 1
        transformed = transform_blocks(original, p, p_inv)
        max_coefficient = max(abs(value) for matrix in transformed.values()
                              for row in matrix for value in row)
        if max_coefficient <= 1:
            ternary_count += 1
            audit = exact_tensor_audit(transformed)
            if audit["E"] != 0:
                raise AssertionError(f"conjugation lost exactness P={p.tolist()} audit={audit}")
            if audit["K"] < best["K"]:
                best = audit
                best_blocks = transformed
                best_p = p.copy()
                line = f"new_best depth={depth} P={p.tolist()} audit={audit}"
                print(line, flush=True)
                log_lines.append(line)
                args.log.write_text("\n".join(log_lines) + "\n", encoding="utf-8")
        if depth >= args.max_depth:
            continue
        for generator in generators:
            child = p @ generator
            key = matrix_key(child)
            if key in seen:
                continue
            child_inv = exact_inverse(child)
            if child_inv is None:
                continue
            if np.max(np.abs(child)) > args.matrix_entry_bound:
                continue
            if np.max(np.abs(child_inv)) > args.inverse_entry_bound:
                continue
            seen.add(key)
            queue.append((child, depth + 1))

    elapsed = time.perf_counter() - start_time
    write_pos_neg_solution(best_blocks, args.best_solution)
    report = {
        "instance": "fastxgemm-n3r23s5t6",
        "method": "simultaneous small-unimodular conjugation orbit search",
        "invariance": "trace(P^-1 X P P^-1 Y P P^-1 Z P)=trace(XYZ)",
        "input": str(args.start),
        "parameters": {
            "max_depth": args.max_depth,
            "matrix_entry_bound": args.matrix_entry_bound,
            "inverse_entry_bound": args.inverse_entry_bound,
            "generators": len(generators),
        },
        "runtime_seconds": elapsed,
        "matrices_evaluated": evaluated,
        "ternary_transforms": ternary_count,
        "depth_counts": {str(k): v for k, v in sorted(depth_counts.items())},
        "baseline": baseline,
        "best": best,
        "best_P": best_p.tolist(),
        "strict_improvement": best["objective"] < baseline["objective"],
        "best_solution": str(args.best_solution),
    }
    args.json.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    log_lines.append(json.dumps(report, indent=2))
    args.log.write_text("\n".join(log_lines) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
