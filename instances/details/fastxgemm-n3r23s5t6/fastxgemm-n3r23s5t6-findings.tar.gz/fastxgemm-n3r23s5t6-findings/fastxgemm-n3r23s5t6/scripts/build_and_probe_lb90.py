#!/usr/bin/env python3
"""Add the R23 integer-valid LB90 row to the official MPS and audit it."""

from __future__ import annotations

import argparse
import gzip
import json
import math
from pathlib import Path

import gurobipy as gp


CUT_NAME = "VALID_R23_LB90_SUPPORT_PLUS_6E"


def read_solution(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix == ".gz" else open
    values: dict[str, float] = {}
    with opener(path, "rt", encoding="utf-8") as stream:
        for raw in stream:
            fields = raw.strip().split()
            if len(fields) >= 2 and not fields[0].startswith(("#", "=")):
                values[fields[0]] = float(fields[1])
    return values


def finite(value: float) -> float | None:
    return float(value) if math.isfinite(float(value)) else None


def configure(model: gp.Model, seconds: float, threads: int, log: Path) -> None:
    model.Params.TimeLimit = seconds
    model.Params.Threads = threads
    model.Params.Presolve = 2
    model.Params.NumericFocus = 2
    model.Params.FeasibilityTol = 1e-9
    model.Params.OptimalityTol = 1e-9
    model.Params.LogFile = str(log)


def solve_lp(model: gp.Model, seconds: float, threads: int, log: Path) -> dict:
    probe = model.relax()
    configure(probe, seconds, threads, log)
    probe.Params.Method = 1
    probe.optimize()
    return {
        "status": int(probe.Status),
        "status_name": "OPTIMAL" if probe.Status == gp.GRB.OPTIMAL else str(probe.Status),
        "objective": finite(probe.ObjVal) if probe.SolCount else None,
        "runtime_seconds": float(probe.Runtime),
        "simplex_iterations": float(probe.IterCount),
        "solution_count": int(probe.SolCount),
    }


def solve_root(
    model: gp.Model, start: Path, seconds: float, threads: int, log: Path
) -> dict:
    probe = model.copy()
    probe.read(str(start))
    configure(probe, seconds, threads, log)
    probe.Params.NodeLimit = 0
    probe.Params.MIPFocus = 3
    probe.Params.Symmetry = 2
    probe.optimize()
    names = {
        gp.GRB.OPTIMAL: "OPTIMAL",
        gp.GRB.NODE_LIMIT: "NODE_LIMIT",
        gp.GRB.TIME_LIMIT: "TIME_LIMIT",
    }
    return {
        "status": int(probe.Status),
        "status_name": names.get(probe.Status, str(probe.Status)),
        "objective": finite(probe.ObjVal) if probe.SolCount else None,
        "objective_bound": finite(probe.ObjBound),
        "runtime_seconds": float(probe.Runtime),
        "node_count": float(probe.NodeCount),
        "solution_count": int(probe.SolCount),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--output-model", type=Path, required=True)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--original-lp-log", type=Path, required=True)
    parser.add_argument("--augmented-lp-log", type=Path, required=True)
    parser.add_argument("--root-log", type=Path, required=True)
    parser.add_argument("--time-limit", type=float, default=120.0)
    parser.add_argument("--threads", type=int, default=4)
    args = parser.parse_args()
    for path in (
        args.output_model,
        args.json,
        args.original_lp_log,
        args.augmented_lp_log,
        args.root_log,
    ):
        path.parent.mkdir(parents=True, exist_ok=True)

    model = gp.read(str(args.mps))
    support = [v for v in model.getVars() if v.VarName.startswith("ABS_ALT_")]
    residual = [v for v in model.getVars() if v.VarName.startswith("RESIDUAL_")]
    if len(support) != 621 or len(residual) != 729:
        raise RuntimeError(f"unexpected families: support={len(support)}, residual={len(residual)}")

    # Verify rather than assume that the official MPS contains sum ABS_ALT >= 84.
    support_names = {v.VarName for v in support}
    original_support_rows: list[str] = []
    for constraint in model.getConstrs():
        if constraint.Sense != ">" or abs(constraint.RHS - 84.0) > 1e-12:
            continue
        row = model.getRow(constraint)
        if row.size() != len(support):
            continue
        names = {row.getVar(i).VarName for i in range(row.size())}
        coeffs = {row.getCoeff(i) for i in range(row.size())}
        if names == support_names and coeffs == {1.0}:
            original_support_rows.append(constraint.ConstrName)
    if len(original_support_rows) != 1:
        raise RuntimeError(f"could not uniquely verify support row: {original_support_rows}")

    exact_abs = [
        v
        for v in model.getVars()
        if v.VarName.startswith(("ABS_U_", "ABS_V_", "ABS_W_"))
        and not v.VarName.startswith(("ABS_ALT_", "ABS_DIFF_"))
    ]
    if len(exact_abs) != 621:
        raise RuntimeError(f"unexpected exact-ABS count: {len(exact_abs)}")
    expected_column_sets = {
        frozenset(f"ABS_{factor}_{row}_{column}" for row in range(9))
        for factor in "UVW"
        for column in range(23)
    }
    verified_column_sets: set[frozenset[str]] = set()
    for constraint in model.getConstrs():
        if constraint.Sense != ">" or abs(constraint.RHS - 1.0) > 1e-12:
            continue
        row = model.getRow(constraint)
        if row.size() != 9 or {row.getCoeff(i) for i in range(9)} != {1.0}:
            continue
        names = frozenset(row.getVar(i).VarName for i in range(9))
        if names in expected_column_sets:
            verified_column_sets.add(names)
    if verified_column_sets != expected_column_sets:
        raise RuntimeError(
            f"verified {len(verified_column_sets)}/69 exact factor-column nonzero rows"
        )

    dimensions = {
        "variables": model.NumVars,
        "constraints": model.NumConstrs,
        "nonzeros": model.NumNZs,
        "integer_variables": sum(v.VType in {gp.GRB.BINARY, gp.GRB.INTEGER} for v in model.getVars()),
    }
    original_lp = solve_lp(model, args.time_limit, args.threads, args.original_lp_log)

    model.addConstr(
        gp.quicksum(support) + 6 * gp.quicksum(residual) >= 90,
        name=CUT_NAME,
    )
    model.update()
    model.write(str(args.output_model))
    cut = model.getConstrByName(CUT_NAME)
    row = model.getRow(cut)
    coeff_counts: dict[str, int] = {}
    for i in range(row.size()):
        key = format(row.getCoeff(i), ".12g")
        coeff_counts[key] = coeff_counts.get(key, 0) + 1

    incumbent = read_solution(args.solution)
    missing = [v.VarName for v in support + residual if v.VarName not in incumbent]
    if missing:
        raise RuntimeError(f"solution missing {len(missing)} cut variables")
    inc_support = sum(incumbent[v.VarName] for v in support)
    inc_error = sum(incumbent[v.VarName] for v in residual)

    report = {
        "instance": "fastxgemm-n3r23s5t6",
        "gurobi_version": ".".join(map(str, gp.gurobi.version())),
        "claim": {
            "previous_project_global_lb": 87,
            "new_project_global_lb": 90,
            "strict_improvement": True,
            "external_published_BILR_upper_bound": 153,
            "global_optimality_proved": False,
        },
        "proof": {
            "exact_branch": "E=0 implies K>=30, hence sum(ABS_ALT)>=3K>=90",
            "inexact_branch": "E_actual>=1, residual auxiliaries dominate E_actual, and official sum(ABS_ALT)>=84",
            "scope": "official ternary cyclic S=5,T=6,R=23 integer model only",
            "uses_official_factor_column_nonzero_rows": True,
            "verified_exact_factor_column_nonzero_rows": len(verified_column_sets),
            "integer_valid_not_plain_lp_valid": True,
            "verified_original_abs_alt_support_bound_rows": original_support_rows,
        },
        "cut": {
            "name": CUT_NAME,
            "formula": "sum(ABS_ALT_U,V,W) + 6*sum(RESIDUAL) >= 90",
            "rhs": float(cut.RHS),
            "nonzeros": row.size(),
            "coefficient_counts": coeff_counts,
            "support_variable_count": len(support),
            "residual_variable_count": len(residual),
        },
        "dimensions": {
            "original": dimensions,
            "augmented": {
                "variables": model.NumVars,
                "constraints": model.NumConstrs,
                "nonzeros": model.NumNZs,
            },
        },
        "external_BILR_153_solution_cut_check": {
            "solution": str(args.solution),
            "full_factor_support": inc_support,
            "E": inc_error,
            "cut_lhs": inc_support + 6 * inc_error,
            "cut_slack": inc_support + 6 * inc_error - 90,
        },
        "original_lp_relaxation": original_lp,
        "augmented_lp_relaxation": solve_lp(
            model, args.time_limit, args.threads, args.augmented_lp_log
        ),
        "augmented_root_probe": solve_root(
            model, args.solution, args.time_limit, args.threads, args.root_log
        ),
        "output_model": str(args.output_model),
    }
    args.json.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
