#!/usr/bin/env python3
"""Search small full isotropy transformations that retain the S5/T6 template."""

from __future__ import annotations

import argparse
import collections
import itertools
import json
import sys
import time
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import exact_semantic_audit as semantic  # noqa: E402


def exact_inverse(matrix: np.ndarray) -> np.ndarray | None:
    determinant = round(float(np.linalg.det(matrix)))
    if abs(determinant) != 1:
        return None
    inverse = np.rint(np.linalg.inv(matrix)).astype(int)
    return inverse if np.array_equal(matrix @ inverse, np.eye(3, dtype=int)) else None


def matrix_key(matrix: np.ndarray) -> tuple[int, ...]:
    return tuple(int(value) for value in matrix.ravel())


def transformations(max_depth: int, entry_bound: int) -> list[np.ndarray]:
    identity = np.eye(3, dtype=int)
    generators = []
    for i, j in itertools.permutations(range(3), 2):
        for sign in (-1, 1):
            generator = identity.copy()
            generator[i, j] = sign
            generators.append(generator)
    queue = collections.deque([(identity, 0)])
    seen = {matrix_key(identity): identity}
    while queue:
        matrix, depth = queue.popleft()
        if depth >= max_depth:
            continue
        for generator in generators:
            child = matrix @ generator
            key = matrix_key(child)
            if key in seen:
                continue
            inverse = exact_inverse(child)
            if inverse is None:
                continue
            if max(np.max(np.abs(child)), np.max(np.abs(inverse))) > entry_bound:
                continue
            seen[key] = child
            queue.append((child, depth + 1))
    return list(seen.values())


def transform_factor(factor: np.ndarray, left: np.ndarray, right: np.ndarray) -> np.ndarray:
    """Coefficient map M -> left^{-T} M right^T, column by column."""
    left_inverse = exact_inverse(left)
    assert left_inverse is not None
    result = np.empty_like(factor)
    for rank in range(factor.shape[1]):
        matrix = factor[:, rank].reshape(3, 3)
        result[:, rank] = (left_inverse.T @ matrix @ right.T).reshape(9)
    return result


def tensor_key(u: np.ndarray, v: np.ndarray, w: np.ndarray) -> tuple[int, ...]:
    variants = []
    for su, sv, sw in ((1, 1, 1), (-1, -1, 1), (-1, 1, -1), (1, -1, -1)):
        variants.append(tuple(int(x) for x in np.concatenate((su * u, sv * v, sw * w))))
    return min(variants)


def split_key(key: tuple[int, ...]):
    array = np.asarray(key, dtype=int)
    return array[:9], array[9:18], array[18:]


def cyclic_signature(u: np.ndarray, v: np.ndarray, w: np.ndarray) -> dict:
    keys = [tensor_key(u[:, rank], v[:, rank], w[:, rank]) for rank in range(u.shape[1])]
    counts = collections.Counter(keys)
    visited = set()
    fixed_terms = 0
    triple_orbits = 0
    valid = True
    for key in counts:
        if key in visited:
            continue
        a, b, c = split_key(key)
        rotations = {
            tensor_key(a, b, c), tensor_key(b, c, a), tensor_key(c, a, b)
        }
        visited.update(rotations)
        multiplicities = [counts.get(rotated, 0) for rotated in rotations]
        if len(rotations) == 1:
            fixed_terms += multiplicities[0]
        else:
            if len(rotations) != 3 or len(set(multiplicities)) != 1:
                valid = False
            triple_orbits += min(multiplicities) if multiplicities else 0
    valid = valid and fixed_terms == 5 and triple_orbits == 6 and len(keys) == 23
    return {
        "valid_s5_t6": valid,
        "fixed_terms": fixed_terms,
        "triple_orbits": triple_orbits,
        "distinct_tensor_terms": len(counts),
    }


def exact_error(u: np.ndarray, v: np.ndarray, w: np.ndarray) -> int:
    residual = 0
    for i in range(9):
        for j in range(9):
            for k in range(9):
                expansion = int(sum(int(u[i, r]) * int(v[j, r]) * int(w[k, r])
                                    for r in range(23)))
                residual += abs(semantic.target_value(i, j, k) - expansion)
    return residual


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--transform-depth", type=int, default=1)
    parser.add_argument("--entry-bound", type=int, default=2)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    args = parser.parse_args()
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.log.parent.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()

    values, _ = semantic.read_solution(args.solution)
    blocks = semantic.reconstruct_blocks(values, tolerance=1e-9)
    u0, v0, w0 = (np.asarray(matrix, dtype=int)
                  for matrix in semantic.factors_from_blocks(blocks))
    transforms = transformations(args.transform_depth, args.entry_bound)

    # Precompute admissible directed pair transformations separately for U,V,W.
    admissible = []
    for factor in (u0, v0, w0):
        table = {}
        for left_idx, left in enumerate(transforms):
            for right_idx, right in enumerate(transforms):
                transformed = transform_factor(factor, left, right)
                if np.max(np.abs(transformed)) <= 1:
                    table[left_idx, right_idx] = transformed
        admissible.append(table)

    candidates = []
    exact_checks = 0
    cyclic_checks = 0
    for p in range(len(transforms)):
        q_choices = [q for q in range(len(transforms)) if (p, q) in admissible[0]]
        for q in q_choices:
            r_choices = [r for r in range(len(transforms))
                         if (q, r) in admissible[1] and (r, p) in admissible[2]]
            for r in r_choices:
                u = admissible[0][p, q]
                v = admissible[1][q, r]
                w = admissible[2][r, p]
                full_support = int(np.count_nonzero(u) + np.count_nonzero(v) + np.count_nonzero(w))
                # An S5/T6 representation repeats every underlying coefficient
                # three times, so divisibility and the target threshold are cheap filters.
                if full_support % 3:
                    continue
                signature = cyclic_signature(u, v, w)
                cyclic_checks += 1
                if not signature["valid_s5_t6"]:
                    continue
                error = exact_error(u, v, w)
                exact_checks += 1
                if error:
                    raise AssertionError(f"isotropy transform not exact: PQR={p,q,r} E={error}")
                candidates.append({
                    "P_index": p, "Q_index": q, "R_index": r,
                    "P": transforms[p].tolist(),
                    "Q": transforms[q].tolist(),
                    "R": transforms[r].tolist(),
                    "full_factor_support": full_support,
                    "K": full_support // 3,
                    "objective": full_support,
                    **signature,
                })
    candidates.sort(key=lambda item: (item["objective"], item["P_index"],
                                      item["Q_index"], item["R_index"]))
    report = {
        "instance": "fastxgemm-n3r23s5t6",
        "method": "small P,Q,R matrix-multiplication isotropy search with cyclic-closure test",
        "identity": (
            "X->P^-1 X Q, Y->Q^-1 Y R, Z->R^-1 Z P preserves trace(XYZ)"
        ),
        "input": str(args.solution),
        "parameters": {"transform_depth": args.transform_depth,
                       "entry_bound": args.entry_bound},
        "transform_count": len(transforms),
        "admissible_pair_counts": [len(table) for table in admissible],
        "cyclic_closure_checks": cyclic_checks,
        "exact_checks": exact_checks,
        "candidate_count": len(candidates),
        "best_objective": candidates[0]["objective"] if candidates else None,
        "strict_below_153_found": bool(candidates and candidates[0]["objective"] < 153),
        "best_candidates": candidates[:50],
        "runtime_seconds": time.perf_counter() - started,
        "interpretation": (
            "This is a finite isotropy neighborhood only, not a global K>=51 proof."
        ),
    }
    args.json.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    args.log.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
