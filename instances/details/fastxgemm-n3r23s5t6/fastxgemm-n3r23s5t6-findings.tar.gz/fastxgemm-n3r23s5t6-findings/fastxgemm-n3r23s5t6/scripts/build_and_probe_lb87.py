#!/usr/bin/env python3
"""Add the valid full-support + 3E >= 87 inequality and probe LP/root."""

from __future__ import annotations

import argparse
import gzip
import json
import math
from pathlib import Path

import gurobipy as gp


CUT_NAME = "VALID_LB87_SUPPORTPLUS3E"


def read_solution(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix == ".gz" else open
    result: dict[str, float] = {}
    with opener(path, "rt", encoding="utf-8") as stream:
        for raw in stream:
            fields = raw.strip().split()
            if len(fields) >= 2 and not fields[0].startswith(("#", "=")):
                result[fields[0]] = float(fields[1])
    return result


def finite(value: float) -> float | None:
    return float(value) if math.isfinite(float(value)) else None


def solve_probe(model: gp.Model, mode: str, seconds: float, threads: int, log: Path) -> dict:
    probe = model.relax() if mode == "lp" else model.copy()
    probe.Params.TimeLimit = seconds
    probe.Params.Threads = threads
    probe.Params.Presolve = 2
    probe.Params.NumericFocus = 2
    probe.Params.LogFile = str(log)
    if mode == "lp":
        probe.Params.Method = 1
        probe.Params.FeasibilityTol = 1e-9
        probe.Params.OptimalityTol = 1e-9
    else:
        probe.Params.NodeLimit = 0
        probe.Params.MIPFocus = 3
        probe.Params.Symmetry = 2
    probe.optimize()
    return {
        "mode": mode,
        "status": int(probe.Status),
        "runtime_seconds": float(probe.Runtime),
        "work": float(probe.Work),
        "simplex_iterations": float(probe.IterCount),
        "node_count": float(probe.NodeCount),
        "solution_count": int(probe.SolCount),
        "objective": finite(probe.ObjVal) if probe.SolCount else None,
        "objective_bound": finite(probe.ObjBound) if probe.IsMIP else None,
        "mip_gap": finite(probe.MIPGap) if probe.IsMIP and probe.SolCount else None,
        "dimensions": {
            "variables": probe.NumVars,
            "constraints": probe.NumConstrs,
            "nonzeros": probe.NumNZs,
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--output-model", type=Path, required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--lp-log", type=Path, required=True)
    parser.add_argument("--root-log", type=Path, required=True)
    parser.add_argument("--time-limit", type=float, default=120.0)
    parser.add_argument("--threads", type=int, default=8)
    args = parser.parse_args()

    for path in (args.output_model, args.output_json, args.lp_log, args.root_log):
        path.parent.mkdir(parents=True, exist_ok=True)

    model = gp.read(str(args.mps))
    original = {
        "variables": model.NumVars,
        "constraints": model.NumConstrs,
        "nonzeros": model.NumNZs,
        "integer_variables": sum(v.VType in {gp.GRB.BINARY, gp.GRB.INTEGER} for v in model.getVars()),
    }
    abs_alt = [v for v in model.getVars() if v.VarName.startswith("ABS_ALT_")]
    residual = [v for v in model.getVars() if v.VarName.startswith("RESIDUAL_")]
    if len(abs_alt) != 621 or len(residual) != 729:
        raise RuntimeError(f"unexpected families: ABS_ALT={len(abs_alt)}, RESIDUAL={len(residual)}")
    model.addConstr(gp.quicksum(abs_alt) + 3 * gp.quicksum(residual) >= 87, name=CUT_NAME)
    model.update()
    model.write(str(args.output_model))

    cut = model.getConstrByName(CUT_NAME)
    row = model.getRow(cut)
    coefficient_counts: dict[str, int] = {}
    for idx in range(row.size()):
        key = format(row.getCoeff(idx), ".12g")
        coefficient_counts[key] = coefficient_counts.get(key, 0) + 1

    incumbent = read_solution(args.solution)
    incumbent_k = sum(incumbent[v.VarName] for v in abs_alt)
    incumbent_e = sum(incumbent[v.VarName] for v in residual)
    report = {
        "gurobi_version": ".".join(map(str, gp.gurobi.version())),
        "input_mps": str(args.mps),
        "checked_solution": str(args.solution),
        "output_model": str(args.output_model),
        "cut": {
            "name": CUT_NAME,
            "sense": cut.Sense,
            "rhs": cut.RHS,
            "nonzeros": row.size(),
            "coefficient_counts": coefficient_counts,
            "abs_alt_variable_count": len(abs_alt),
            "residual_variable_count": len(residual),
            "checked_solution_k_float": incumbent_k,
            "checked_solution_e_float": incumbent_e,
            "checked_solution_lhs_float": incumbent_k + 3 * incumbent_e,
            "checked_solution_slack_float": incumbent_k + 3 * incumbent_e - 87,
        },
        "integer_projection_check": {
            "original": original,
            "augmented": {
                "variables": model.NumVars,
                "constraints": model.NumConstrs,
                "nonzeros": model.NumNZs,
                "integer_variables": sum(
                    v.VType in {gp.GRB.BINARY, gp.GRB.INTEGER} for v in model.getVars()
                ),
            },
            "new_variables": model.NumVars - original["variables"],
            "new_integer_variables": sum(
                v.VType in {gp.GRB.BINARY, gp.GRB.INTEGER} for v in model.getVars()
            ) - original["integer_variables"],
            "note": "The row adds no variables. Logical validity for all integral factor patterns is a separate combinatorial argument; the numerical check confirms that the checked incumbent remains feasible.",
        },
        "parameters": {
            "time_limit": args.time_limit,
            "threads": args.threads,
            "presolve": 2,
            "numeric_focus": 2,
            "lp_method": 1,
            "root_node_limit": 0,
            "root_mip_focus": 3,
            "root_symmetry": 2,
        },
    }
    report["lp_probe"] = solve_probe(model, "lp", args.time_limit, args.threads, args.lp_log)
    report["root_probe"] = solve_probe(model, "root", args.time_limit, args.threads, args.root_log)
    args.output_json.write_text(
        json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
