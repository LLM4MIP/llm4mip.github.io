#!/usr/bin/env python3
"""Compare all three explicit S=5,T=6 decompositions in BILR 2018."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from verify_ballard_laderman_z3 import FIXED as LADER_FIXED
from verify_ballard_laderman_z3 import ORBIT_SEEDS as LADER_SEEDS
from verify_ballard_laderman_z3 import flatten


ADDITIONAL_1_FIXED = [
    [[0, 0, 0], [0, 0, 0], [0, -1, 1]],
    [[1, 0, 0], [1, 0, 0], [0, 0, 0]],
    [[1, -1, 0], [0, 0, 0], [0, -1, 0]],
    [[0, 0, 0], [0, 1, 0], [0, 1, 0]],
    [[-1, 1, 0], [-1, 0, 0], [0, 1, 0]],
]
ADDITIONAL_1_SEEDS = [
    (
        [[0, 0, 0], [0, 0, 1], [0, 0, 0]],
        [[0, 0, 0], [0, 0, 0], [-1, 0, 0]],
        [[0, -1, 1], [0, 0, 0], [0, 0, 0]],
    ),
    (
        [[0, 0, 0], [0, -1, 1], [0, -1, 1]],
        [[1, 0, -1], [-1, -1, 1], [0, -1, 0]],
        [[0, 0, 0], [0, 0, 0], [0, -1, 0]],
    ),
    (
        [[0, 0, 0], [1, 1, -1], [1, 1, -1]],
        [[-1, 0, 1], [0, 0, 0], [0, 0, 0]],
        [[0, 0, 0], [0, 0, 1], [0, 0, 1]],
    ),
    (
        [[0, 0, 0], [0, 0, 1], [0, -1, 1]],
        [[0, 0, 0], [1, 1, -1], [0, 1, -1]],
        [[1, 0, -1], [0, 0, 0], [0, -1, 0]],
    ),
    (
        [[0, 0, 0], [0, 0, 0], [1, 0, 0]],
        [[1, 0, 0], [0, 0, 0], [0, 0, 0]],
        [[0, 0, 1], [0, 0, 1], [0, 0, 1]],
    ),
    (
        [[0, -1, 0], [0, 0, 0], [0, -1, 0]],
        [[1, -1, 0], [1, -1, 0], [0, -1, 0]],
        [[0, 0, 0], [1, 0, 0], [0, 0, 0]],
    ),
]


ADDITIONAL_2_FIXED = [
    [[0, 1, -1], [0, 1, 0], [0, 0, 0]],
    [[0, 0, 0], [-1, 1, 1], [0, 0, 0]],
    [[1, 0, 0], [0, 0, 0], [0, 0, 0]],
    [[0, -1, 1], [1, -1, -1], [0, 0, 0]],
    [[0, 0, 0], [0, 0, 0], [0, 0, 1]],
]
ADDITIONAL_2_SEEDS = [
    (
        [[-1, 0, 1], [0, 0, 0], [-1, 0, 1]],
        [[0, 0, 0], [0, 1, 0], [0, 1, 0]],
        [[0, 0, 0], [0, 0, 1], [0, 0, 0]],
    ),
    (
        [[0, -1, 1], [0, 0, 0], [0, 0, 0]],
        [[0, 0, 0], [-1, 0, 1], [0, 0, 0]],
        [[1, -1, 0], [1, -1, -1], [0, 0, 0]],
    ),
    (
        [[0, 0, 0], [1, 0, 0], [1, 0, 0]],
        [[-1, 0, 0], [0, 0, 0], [-1, 0, 0]],
        [[0, -1, 0], [0, -1, 0], [0, -1, 0]],
    ),
    (
        [[0, 0, 0], [0, 0, -1], [0, 0, 0]],
        [[0, 1, -1], [0, 0, 0], [0, 1, -1]],
        [[0, 0, 0], [0, -1, 0], [0, 0, 0]],
    ),
    (
        [[1, 0, -1], [0, 0, 0], [1, 0, 0]],
        [[0, 1, -1], [0, 1, 0], [0, 1, 0]],
        [[0, 0, 0], [-1, 0, 1], [-1, 0, 0]],
    ),
    (
        [[0, -1, 1], [-1, -1, 1], [-1, -1, 1]],
        [[0, 0, 0], [0, 0, 0], [-1, 0, 0]],
        [[0, 0, -1], [0, 0, 0], [0, 0, 0]],
    ),
]


def audit(name, fixed_matrices, seed_matrices, location):
    fixed = [flatten(matrix) for matrix in fixed_matrices]
    seeds = [tuple(flatten(matrix) for matrix in seed) for seed in seed_matrices]
    terms = [(a, a, a) for a in fixed]
    for x, y, z in seeds:
        terms.extend([(x, y, z), (y, z, x), (z, x, y)])
    residuals = []
    for a in range(9):
        ai, aj = divmod(a, 3)
        for b in range(9):
            bj, bk = divmod(b, 3)
            for c in range(9):
                ck, ci = divmod(c, 3)
                target = int(aj == bj and bk == ck and ci == ai)
                actual = sum(u[a] * v[b] * w[c] for u, v, w in terms)
                if actual != target:
                    residuals.append([a, b, c, actual - target])
    fixed_support = [sum(value != 0 for value in vector) for vector in fixed]
    seed_support = [
        [sum(value != 0 for value in vector) for vector in seed] for seed in seeds
    ]
    core = sum(fixed_support) + sum(map(sum, seed_support))
    return {
        "name": name,
        "source_location": location,
        "rank": len(terms),
        "fixed_count": len(fixed),
        "orbit_count": len(seeds),
        "coefficient_domain": sorted({value for term in terms for vector in term for value in vector}),
        "exact_integer_tensor": not residuals,
        "nonzero_residual_count": len(residuals),
        "residual_l1": sum(abs(item[3]) for item in residuals),
        "residual_examples": residuals[:10],
        "fixed_core_supports": fixed_support,
        "orbit_seed_supports": seed_support,
        "core_K": core,
        "full_factor_support": 3 * core,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    reports = [
        audit("S_Lader-Z3", LADER_FIXED, LADER_SEEDS, "Appendix B, eqs. 77-84, PDF p.29"),
        audit("Additional decomposition #1", ADDITIONAL_1_FIXED, ADDITIONAL_1_SEEDS, "Appendix A.1, PDF p.24"),
        audit("Additional decomposition #2", ADDITIONAL_2_FIXED, ADDITIONAL_2_SEEDS, "Appendix A.2, eqs. 53-60, PDF p.26"),
    ]
    result = {
        "source": "Ballard-Ikenmeyer-Landsberg-Ryder, arXiv:1801.00843v1",
        "scope": "all explicit decompositions in the paper with five Z3-fixed terms and six length-three orbits",
        "reports": reports,
        "all_exact": all(report["exact_integer_tensor"] for report in reports),
        "best": min(reports, key=lambda report: report["full_factor_support"]),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
