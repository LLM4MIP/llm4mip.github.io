#!/usr/bin/env python3
"""Audit catalogued 3x3 rank-23 schemes against fastxgemm-n3r23s5t6.

The catalog uses rank-major U/V and column-major W coordinates.  Some
Perminov files use shared linear forms (``*_fresh``); these are expanded
exactly before checking the 729 Brent identities and cyclic orbit closure.
"""

from __future__ import annotations

import argparse
import json
from collections import Counter
from fractions import Fraction
from pathlib import Path
from typing import Any


Vector = tuple[Fraction, ...]
Term = tuple[Vector, Vector, Vector]


def coefficient(value: Any) -> Fraction:
    if isinstance(value, dict):
        if set(value) >= {"numerator", "denominator"}:
            return Fraction(value["numerator"], value["denominator"])
        raise ValueError(f"unsupported coefficient object: {value}")
    return Fraction(value)


def linear_form(entries: list[dict[str, Any]], nodes: list[Vector]) -> Vector:
    result = [Fraction(0) for _ in nodes[0]]
    for entry in entries:
        source = nodes[int(entry["index"])]
        value = coefficient(entry["value"])
        for index, item in enumerate(source):
            result[index] += value * item
    return tuple(result)


def expand_input_forms(
    forms: list[list[dict[str, Any]]],
    fresh: list[list[dict[str, Any]]],
    dimension: int,
) -> list[Vector]:
    nodes: list[Vector] = []
    for index in range(dimension):
        nodes.append(tuple(Fraction(int(j == index)) for j in range(dimension)))
    for definition in fresh:
        nodes.append(linear_form(definition, nodes))
    return [linear_form(form, nodes) for form in forms]


def expand_output_forms(
    outputs: list[list[dict[str, Any]]],
    fresh: list[list[dict[str, Any]]],
    rank: int,
) -> list[Vector]:
    nodes: list[Vector] = []
    for index in range(rank):
        nodes.append(tuple(Fraction(int(j == index)) for j in range(rank)))
    for definition in fresh:
        nodes.append(linear_form(definition, nodes))
    output_by_product = [linear_form(form, nodes) for form in outputs]
    return [
        tuple(output_by_product[coordinate][product] for coordinate in range(len(outputs)))
        for product in range(rank)
    ]


def factors(data: dict[str, Any]) -> tuple[list[Vector], list[Vector], list[Vector], str]:
    rank = int(data["m"])
    n, m, p = map(int, data["n"])
    raw_u = data["u"]
    if not raw_u:
        raise ValueError("empty U")
    if not raw_u[0] or not isinstance(raw_u[0][0], dict):
        u = [tuple(map(coefficient, row)) for row in raw_u]
        v = [tuple(map(coefficient, row)) for row in data["v"]]
        w = [tuple(map(coefficient, row)) for row in data["w"]]
        representation = "dense rank-major U/V/W"
    else:
        u = expand_input_forms(raw_u, data.get("u_fresh", []), n * m)
        v = expand_input_forms(data["v"], data.get("v_fresh", []), m * p)
        w = expand_output_forms(data["w"], data.get("w_fresh", []), rank)
        representation = "shared forms expanded to dense rank-major U/V/W"
    if not (len(u) == len(v) == len(w) == rank):
        raise ValueError(f"rank mismatch: {len(u)}, {len(v)}, {len(w)}, expected {rank}")
    if any(len(row) != n * m for row in u):
        raise ValueError("U dimension mismatch")
    if any(len(row) != m * p for row in v):
        raise ValueError("V dimension mismatch")
    if any(len(row) != n * p for row in w):
        raise ValueError("W dimension mismatch")
    return u, v, w, representation


def tensor_audit(u: list[Vector], v: list[Vector], w: list[Vector]) -> dict[str, Any]:
    residuals: list[tuple[int, int, int, Fraction]] = []
    for a in range(9):
        ai, aj = divmod(a, 3)
        for b in range(9):
            bj, bk = divmod(b, 3)
            for c in range(9):
                # Catalog W is column-major: coordinate c = output_col * 3 + output_row.
                output_col, output_row = divmod(c, 3)
                target = Fraction(int(aj == bj and ai == output_row and bk == output_col))
                actual = sum(
                    (u[r][a] * v[r][b] * w[r][c] for r in range(len(u))),
                    Fraction(0),
                )
                if actual != target:
                    residuals.append((a, b, c, actual - target))
    integral = all(value.denominator == 1 for *_, value in residuals)
    l1 = sum(abs(value) for *_, value in residuals)
    return {
        "exact_over_Q": not residuals,
        "nonzero_residual_count": len(residuals),
        "residual_l1": int(l1) if integral else str(l1),
        "residual_examples": [
            {"u": a, "v": b, "w": c, "residual": str(value)}
            for a, b, c, value in residuals[:10]
        ],
    }


def first_sign(vector: Vector) -> int:
    for value in vector:
        if value:
            if value not in (-1, 1):
                raise ValueError("canonical ternary sign gauge requested for non-ternary vector")
            return 1 if value > 0 else -1
    raise ValueError("zero factor vector")


def scale(vector: Vector, sign: int) -> Vector:
    return tuple(sign * value for value in vector)


def canonical(term: Term) -> Term:
    u, v, w = term
    su = first_sign(u)
    sv = first_sign(v)
    return scale(u, su), scale(v, sv), scale(w, su * sv)


def rotate(term: Term) -> Term:
    u, v, w = term
    return canonical((v, w, u))


def cyclic_audit(u: list[Vector], v: list[Vector], w: list[Vector]) -> dict[str, Any]:
    terms = [canonical(term) for term in zip(u, v, w)]
    counts = Counter(terms)
    missing = []
    for index, term in enumerate(terms):
        rotated = rotate(term)
        if counts[rotated] != counts[term]:
            missing.append(
                {
                    "term_index": index,
                    "multiplicity": counts[term],
                    "rotated_multiplicity": counts[rotated],
                }
            )
    closed = not missing
    fixed = sum(rotate(term) == term for term in terms) if closed else None
    triples = (len(terms) - fixed) // 3 if closed else None
    return {
        "closed_under_factor_rotation": closed,
        "fixed_term_count": fixed,
        "length_three_orbit_count": triples,
        "matches_s5_t6": bool(closed and fixed == 5 and triples == 6),
        "missing_rotation_count": len(missing),
        "missing_rotation_examples": missing[:10],
    }


def audit(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    u, v, w, representation = factors(data)
    values = [value for matrix in (u, v, w) for row in matrix for value in row]
    ternary = all(value in (-1, 0, 1) for value in values)
    nonzero_values = sorted({str(value) for value in values if value not in (-1, 0, 1)})
    support = sum(value != 0 for value in values)
    tensor = tensor_audit(u, v, w)
    cyclic = cyclic_audit(u, v, w) if ternary and tensor["exact_over_Q"] else None
    return {
        "file": path.name,
        "source": data.get("source"),
        "source_scheme_url": data.get("source_scheme_url"),
        "fields": data.get("fields"),
        "zt_metadata": data.get("zt"),
        "representation": representation,
        "rank": data.get("m"),
        "shape": data.get("n"),
        "commutative_only": data.get("commutative"),
        "ternary_after_exact_expansion": ternary,
        "nonternary_value_examples": nonzero_values[:10],
        "raw_factor_support": support,
        "catalog_additions": data.get("additions"),
        "catalog_min_additions": data.get("min_additions"),
        "tensor": tensor,
        "cyclic": cyclic,
        "strict_ub_below_174": bool(
            tensor["exact_over_Q"]
            and ternary
            and cyclic
            and cyclic["matches_s5_t6"]
            and support < 174
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("catalog", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    candidates: list[Path] = []
    for path in args.catalog.rglob("*.json"):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if data.get("n") == [3, 3, 3] and data.get("m") == 23 and all(
            key in data for key in ("u", "v", "w")
        ):
            candidates.append(path)

    reports = []
    errors = []
    for path in sorted(candidates):
        try:
            reports.append(audit(path))
        except Exception as exc:  # keep a complete machine-readable batch audit
            errors.append({"file": str(path), "error": f"{type(exc).__name__}: {exc}"})

    result = {
        "catalog_root": str(args.catalog.resolve()),
        "coordinate_convention": (
            "Catalog U/V are row-major input forms and W is column-major "
            "(output_col*3+output_row), matching the fastxgemm MIP convention."
        ),
        "candidate_count": len(candidates),
        "audited_count": len(reports),
        "error_count": len(errors),
        "strict_improvement_count": sum(item["strict_ub_below_174"] for item in reports),
        "s5t6_feasible_count": sum(
            bool(item["cyclic"] and item["cyclic"]["matches_s5_t6"])
            for item in reports
        ),
        "reports": reports,
        "errors": errors,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
