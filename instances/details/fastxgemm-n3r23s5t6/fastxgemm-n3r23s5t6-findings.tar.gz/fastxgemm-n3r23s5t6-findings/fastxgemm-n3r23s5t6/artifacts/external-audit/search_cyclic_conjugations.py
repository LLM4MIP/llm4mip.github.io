#!/usr/bin/env python3
"""Search small rational diagonal-PGL basis changes of a cyclic decomposition.

For every primitive integer 3x3 representative G in a bounded box, this
checks the simultaneous conjugation X -> G X G^{-1}.  A transformed fixed
matrix must itself be ternary.  Within a length-three orbit, each transformed
matrix may be projectively normalized to ternary when its nonzero entries have
one common magnitude and the three magnitudes multiply to one.
"""

from __future__ import annotations

import argparse
import itertools
import json
import math
from collections import Counter
from pathlib import Path


def determinant(g: tuple[int, ...]) -> int:
    a, b, c, d, e, f, h, i, j = g
    return a * (e * j - f * i) - b * (d * j - f * h) + c * (d * i - e * h)


def adjugate(g: tuple[int, ...]) -> tuple[int, ...]:
    a, b, c, d, e, f, h, i, j = g
    return (
        e * j - f * i,
        c * i - b * j,
        b * f - c * e,
        f * h - d * j,
        a * j - c * h,
        c * d - a * f,
        d * i - e * h,
        b * h - a * i,
        a * e - b * d,
    )


def multiply(left: tuple[int, ...], right: tuple[int, ...]) -> tuple[int, ...]:
    return tuple(
        sum(left[3 * row + k] * right[3 * k + col] for k in range(3))
        for row in range(3)
        for col in range(3)
    )


def transform_numerators(
    g: tuple[int, ...], adj: tuple[int, ...], matrix: tuple[int, ...]
) -> tuple[int, ...]:
    return multiply(multiply(g, matrix), adj)


def uniform_abs_nonzero(numerators: tuple[int, ...]) -> int | None:
    magnitudes = {abs(value) for value in numerators if value}
    if len(magnitudes) != 1:
        return None
    return next(iter(magnitudes))


def normalized_ternary(numerators: tuple[int, ...], det: int) -> list[int]:
    # Division is by a positive magnitude; det contributes the common sign.
    sign_det = 1 if det > 0 else -1
    return [0 if value == 0 else sign_det * (1 if value > 0 else -1) for value in numerators]


def primitive_canonical(g: tuple[int, ...]) -> tuple[int, ...] | None:
    gcd = 0
    for value in g:
        gcd = math.gcd(gcd, abs(value))
    if gcd != 1:
        return None
    first = next((value for value in g if value), 0)
    if first < 0:
        return tuple(-value for value in g)
    return g


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("transcription_audit", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--entry-bound", type=int, default=1)
    args = parser.parse_args()

    source = json.loads(args.transcription_audit.read_text(encoding="utf-8"))
    raw = source["fastxgemm_core_mapping"]
    fixed = [tuple(map(int, vector)) for vector in raw["A"]]
    # The audit stores B=x, C=z, D=y, so seeds in paper order are (B,D,C).
    seeds = [
        (tuple(map(int, b)), tuple(map(int, d)), tuple(map(int, c)))
        for b, c, d in zip(raw["B"], raw["C"], raw["D"])
    ]

    values = range(-args.entry_bound, args.entry_bound + 1)
    seen: set[tuple[int, ...]] = set()
    nonsingular = 0
    admissible = 0
    support_histogram: Counter[int] = Counter()
    best_support = 10**9
    best: list[dict] = []

    for candidate in itertools.product(values, repeat=9):
        g = primitive_canonical(candidate)
        if g is None or g in seen:
            continue
        seen.add(g)
        det = determinant(g)
        if det == 0:
            continue
        nonsingular += 1
        adj = adjugate(g)

        transformed_fixed = [transform_numerators(g, adj, matrix) for matrix in fixed]
        fixed_magnitudes = [uniform_abs_nonzero(matrix) for matrix in transformed_fixed]
        if any(magnitude != abs(det) for magnitude in fixed_magnitudes):
            continue

        transformed_seeds = [
            tuple(transform_numerators(g, adj, matrix) for matrix in seed)
            for seed in seeds
        ]
        seed_magnitudes = [
            tuple(uniform_abs_nonzero(matrix) for matrix in seed)
            for seed in transformed_seeds
        ]
        if any(any(magnitude is None for magnitude in magnitudes) for magnitudes in seed_magnitudes):
            continue
        if any(
            math.prod(magnitudes) != abs(det) ** 3
            for magnitudes in seed_magnitudes
        ):
            continue

        admissible += 1
        support = sum(sum(value != 0 for value in matrix) for matrix in transformed_fixed)
        support += sum(
            sum(sum(value != 0 for value in matrix) for matrix in seed)
            for seed in transformed_seeds
        )
        support_histogram[support] += 1

        record = {
            "G": [list(g[0:3]), list(g[3:6]), list(g[6:9])],
            "determinant": det,
            "core_K": support,
            "full_factor_support": 3 * support,
            "fixed": [normalized_ternary(matrix, det) for matrix in transformed_fixed],
            "orbit_seeds_xyz": [
                [normalized_ternary(matrix, det) for matrix in seed]
                for seed in transformed_seeds
            ],
            "orbit_projective_magnitudes_numerator_over_absdet": [
                [f"{magnitude}/{abs(det)}" for magnitude in magnitudes]
                for magnitudes in seed_magnitudes
            ],
        }
        if support < best_support:
            best_support = support
            best = [record]
        elif support == best_support and len(best) < 20:
            best.append(record)

    result = {
        "source": str(args.transcription_audit.resolve()),
        "entry_bound": args.entry_bound,
        "primitive_projective_representatives_checked": len(seen),
        "nonsingular_representatives": nonsingular,
        "ternary_projectively_admissible_representatives": admissible,
        "original_core_K": source["support"]["core_K"],
        "best_core_K": best_support if best else None,
        "best_full_factor_support": 3 * best_support if best else None,
        "strict_improvement_found": bool(best and best_support < source["support"]["core_K"]),
        "support_histogram": dict(sorted(support_histogram.items())),
        "best_representatives": best,
        "scope": (
            "Exhaustive only over primitive integer G with entries in the stated box, modulo G~-G. "
            "This is not a global optimality proof over PGL(3)."
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
