# A global lower bound of 90 for `fastxgemm-n3r23s5t6`

This note concerns the integer-feasible points of the official MIPLIB model:
ternary factors, `R=23`, and the cyclic parametrization `S=5,T=6`.  It is not
a lower bound for unrestricted rank-23 decompositions of the 3-by-3 matrix
multiplication tensor.

## Notation and the tight-slice facts

Write

```text
U = [A B C D],   V = [A D B C],   W = [A C D B],
```

where `A` has five columns and `B,C,D` have six columns each.  Let `K` be
the number of nonzeros in `[A B C D]`.  Since `U,V,W` are column
permutations of these same vectors, their row-degree sequences agree and
their total raw factor support is `3K`.

Index each factor coordinate by `(n,q) in {0,1,2}^2`.  Every target slice
obtained by fixing one coordinate has matrix rank three.  Consequently every
factor row has degree at least three.  A row of degree exactly three is called
*tight*.

Equality in the slice-rank bound implies that, at every rank position used by
a tight row, the two opposite factor vectors lie in the target slice's
three-dimensional coordinate spaces.  In grid notation these are one grid
row and one grid column.  It follows that:

1. distinct tight rows in one mode use disjoint rank positions; and
2. if an aligned rank position is used by a tight row in all three modes,
   each factor vector at that position is supported on at most one grid
   coordinate.

The first statement holds because two different tight slices have disjoint
opposite coordinate spaces on at least one side.  A shared position would
make that rank-one summand zero and leave at most two nonzero summands for a
rank-three slice.  The second statement follows by intersecting the grid-row
and grid-column restrictions supplied by the other two modes.

The official model also requires every factor column to be nonzero.  This
official-model condition is used explicitly in the final case below.

## Excluding exact `K=29`

The earlier slice argument already gives `K>=29`: if `K<=28`, at least eight
of the nine rows are tight and require `8*3=24` distinct rank positions,
more than `R=23`.

Assume for contradiction that an exact reconstruction has `K=29`.  Its
degree multiset is either

```text
(5,3,3,3,3,3,3,3,3)  or  (4,4,3,3,3,3,3,3,3).
```

The first has eight tight rows and is again impossible by `24>23`.  In the
second, the seven tight grid coordinates are the same in every mode, because
the three factors have the same row-degree sequence.  Call the other two
coordinates `N`.  The seven tight rows cover exactly 21 distinct rank
positions in each mode, leaving exactly two uncovered positions.

Equivalently, exactly two underlying columns of `[A B C D]` have support
contained in `N`; call them the two uncovered vectors.  Every other underlying
column has exactly one tight support coordinate.  We classify the pair of
uncovered vectors by the cyclic column orbits.

### Case 1: two `A` vectors

An `A` vector occupies the same aligned position in all three modes.  The
other 21 positions are therefore covered in all modes and are coordinate
singletons.  Each uncovered `A` vector has support at most two, so

```text
K <= 21 + 2 + 2 = 25,
```

contrary to `K=29`.

### Case 2: one `A` vector and one `B/C/D` vector

The `A` vector removes one aligned position, while an uncovered vector in a
cyclic triple removes the three positions of that triple from common
three-mode coverage.  Thus 19 outside positions are coordinate singletons.
The uncovered `A` vector has support at most two.

Within the affected cyclic triple, relabel the uncovered vector as `B` and
the covered mates as `C,D`.  The tight primary coordinates of `C,D` restrict
`B` respectively to one grid row and one grid column, so its support is at
most one.  Each of `C,D` has one tight coordinate and can additionally use
only the two coordinates in `N`, hence support at most three.  Therefore

```text
K <= 19 + 2 + 1 + 3 + 3 = 28,
```

again a contradiction.

### Case 3: two `B/C/D` vectors from the same cyclic triple

All 20 positions outside that triple are covered in all modes and are
coordinate singletons.  The two uncovered vectors each have support at most
two; the remaining covered mate has one tight coordinate and at most the two
coordinates in `N`.  Hence

```text
K <= 20 + 2 + 2 + 3 = 27,
```

a contradiction.

### Case 4: two `B/C/D` vectors from different cyclic triples

The 17 positions outside the two affected triples are coordinate singletons.
It remains to show that each affected triple has total support at most five.

Consider one triple and relabel its uncovered vector `B`.  Let the unique
tight coordinates of `C,D` be

```text
c=(alpha,beta),   d=(gamma,delta).
```

From the tight `U` slice whose primary vector is `C`, the opposite vectors
satisfy

```text
supp(B) subset row(beta),   supp(D) subset column(alpha).
```

From the tight `U` slice whose primary vector is `D`, they satisfy

```text
supp(C) subset row(delta),  supp(B) subset column(gamma).
```

Because `c` belongs to `C` and `d` belongs to `D`, necessarily
`alpha=delta=:a`.  Thus `C` lies in `row(a)`, `D` lies in `column(a)`, and
the nonzero official column `B` is the singleton `(beta,gamma)`, which lies
in `N`.

Besides their one tight coordinate each, `C,D` can use only incidences of
the two points of `N` with `row(a)` and `column(a)`.  The total number of
these incidences is at most two:

- if `(a,a)` is not in `N`, each of the two points lies on at most one of
  the two lines;
- if `(a,a)` is in `N`, it contributes two incidences, while the singleton
  `(beta,gamma)` cannot lie on either line.  Otherwise `beta=a` or
  `gamma=a`, making the tight primary coordinate `c` or `d` equal to
  `(a,a)`, contradicting `(a,a) in N`.

Therefore this triple contributes at most

```text
1 (uncovered singleton) + 2 (tight entries of C,D) + 2 (N incidences) = 5.
```

For the two different triples,

```text
K <= 17 + 5 + 5 = 27,
```

which is the final contradiction.

All possibilities for exact `K=29` are impossible.  Thus every exact
integer reconstruction in the official model has `K>=30`, and its raw
factor support is at least `3K>=90`.

## The globally valid cut

Let `E_actual` be the integer L1 tensor discrepancy reconstructed from the
ternary factors, and let `R_aux=sum(RESIDUAL)` be the official continuous
residual auxiliaries.  Their linking constraints imply
`R_aux>=E_actual` even when auxiliaries are not chosen minimally.

- In the exact branch, the argument above gives actual factor support
  `3K>=90`; the absolute-value auxiliaries satisfy
  `sum(ABS_ALT)>=3K>=90`.
- In the inexact branch, `E_actual>=1`, hence `R_aux>=1`, and the official
  model already contains `sum(ABS_ALT)>=84`.

Consequently every integer-feasible point satisfies

```text
sum(ABS_ALT_U,ABS_ALT_V,ABS_ALT_W) + 6*sum(RESIDUAL) >= 90.  (CUT-90)
```

This is an integer-valid inequality, not a claim about the unaugmented
fractional LP relaxation.  Since the remaining objective terms are
nonnegative, it proves the global integer objective lower bound 90.

The finite post-lemma case audit is in `lb90_combinatorial_audit.json`; the
official-MPS cut/LP/root implementation audit is in `lb90_probe.json`.
