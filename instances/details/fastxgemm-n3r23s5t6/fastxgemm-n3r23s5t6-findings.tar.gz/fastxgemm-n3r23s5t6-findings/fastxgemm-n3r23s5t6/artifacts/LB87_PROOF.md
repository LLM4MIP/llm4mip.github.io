#  History of `fastxgemm-n3r23s5t6` global lower bound 87

>  The proof has been reinforced by the `LB90_PROOF.md` strict of the same catalogue; it is preserved to record the proof evolution.

This proof is only for balanced-ternary, cyclic, `N=3,R=23,S=5,T=6` in official MIP.
It does not prove the general 3 × 3 matrix times the rank lower bound, nor does it prove the Sorber 174 used at the time.
optimal.

## notation

Models used

```text
U = [A B C D],   V = [A D B C],   W = [A C D B],
```

where `A` has 5 columns and `B,C,D` each have 6. Let `K` denote the number in `[A B C D]` of
Total nonzero coefficients. The three-factor matrix is just a column replacement of these blocks, so each one is exactly the same.
`K` is a non-zero, complete factor support for `F=3K`.

##  Reasoning 1: Each factor line of exact decomposition contains at least one non-zero 3

Write a line of the first form as `i=(n,q)`. The corresponding objective tensor slice is a
9 × 9 matrix, in which

```text
((q,m),(m,n)), m=0,1,2
```

There are three 1s, so the matrix rank is 3.

```text
sum_{r: U[i,r] != 0} U[i,r] V[:,r] W[:,r]^T.
```

If the non-zero number on the `i` line of `U` is `d_i`, the right-hand rank is at most `d_i`, then
`d_i>=3`. The synonym applies to all nine lines and the other two models.
`K=sum_i d_i>=27`。

##  2: two different degree- 3 rows cannot share rank column

Call a row with `d_i=3` tight. When a rank-3 slice is the sum of exactly three rank-one matrices,
The three relatively modular vectors must be the exact line spaces and column spaces of the slice respectively.
For the `i=(n,q)`, each participant in the `r` is therefore satisfied

```text
V[:,r] in span{e_(q,m): m=0,1,2},
W[:,r] in span{e_(m,n): m=0,1,2}.
```

If two distinct tight rows `(n,q)` and `(n',q')` share a column: when `q!=q'`,
Two allowed `V[:,r]` coordinate spaces do not intersect, forcing `V[:,r]=0`; when `q=q'`
There must be `n!=n'`, and the two allowed `W[:,r]` subspaces do not intersect, forcing `W[:,r]=0`.
In both cases, the corresponding rank-one of the shared columns is zero; the tight slice is then left as much as possible.
Two non-zero rank-one entries cannot be ranked 3. This contradiction does not even require additional model dependence.
Each factor column is a non-zero-zero constraint. Thus, different tight lines use three non-intersecting columns.
rank columns。

##  The exact situation: `K>=29`

If `K<=28`, the nine line dimensions are at least 3 and the residual value beyond the minimum sum of 27 is at most 1.
So at least eight lines tight. Considering that 2 requires at least `8*3=24` to have different rank columns.
However, the model only has 23 columns, which are contradictory.

```text
K >= 29,   F=3K >= 87.
```

This method cannot exclude `K=29`: the scale pattern `3^7 4^2` only occupies 21 with a tight line.
The rank columns that are covered remain two columns. So the lower bound cannot be written as 90, nor can it be written as such.
174 is optimum.

##  Effective cuts to the entire MIP

The official model originally had two RHS support constraints for 84, so any integer feasible point is satisfied.
`sum(ABS_ALT)>=84`. The integer factor pattern makes each reconstruction tensor sequence an integer;
If not exact, the absolute value of at least one tensor discrepancy is at least 1, then
`sum(RESIDUAL)>=1`. `F>=87` combined with the exact case, all integer feasible points are satisfied.

```text
sum(ABS_ALT) + 3 sum(RESIDUAL) >= 87.                 (CUT-87)
```

This is a **integer-valid cut**: proof uses a discrete factor pattern, not claiming it.
The original LP relaxation automatically generates an arbitrary score.

```text
1000 sum(RESIDUAL) + sum(ABS_ALT) + 0.001 sum(ABS_DIFF),
```

All variables are nonnegative, so `(CUT-87)` simultaneously gives the global objective lower bound 87.

The Sorber historical solution 174 used at the time was `E=0,F=174`, with the cut on the left taking the 174, which of course remains strict.
feasible. This file is reserved for the earlier LB87 proof; the current stronger result is `LB=90, UB=153`, see instance
ReadME and `LB90_PROOF.md`.
