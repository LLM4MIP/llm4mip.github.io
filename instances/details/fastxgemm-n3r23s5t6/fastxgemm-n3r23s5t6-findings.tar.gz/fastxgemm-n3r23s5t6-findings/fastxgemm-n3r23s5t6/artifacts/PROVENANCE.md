#  Source verification of the objective 174 solution

## Conclusion

`fastxgemm-N3-R23-S5-T6.lp.mst` is not only located in Laurent Sorber's public author warehouse repository.
It is also in the original official submission of MIPLIB 2017.
**byte is the same as**:

```text
bytes:   492838
SHA256:  03ad7e05cef5af4a2d9fd701eda2a9522bc2ef06a8953aacd26c5c3d28233a8c
```

The project retains two source documents:

-  `source/fastxgemm-N3-R23-S5-T6.lp.mst`: A snapshot of the author's repository;
-  `source/official-submission-fastxgemm-N3-R23-S5-T6.lp.mst`: from the original ZIB
Submission fixed commit downloaded copy.

##  Fixed source

-  The author's own repository: < https://github.com/lsorber/fast-matrix-multiplication >
-  Local Author's Warehouse Repository snapshot: `c2adb64ebac59571a6bf04ac6e4ede38c4850378`
- Commit that first introduced the file:
  [`165ac7dc40e3cb0bbb8d03008a2b787acd9cbe9e`](https://github.com/lsorber/fast-matrix-multiplication/commit/165ac7dc40e3cb0bbb8d03008a2b787acd9cbe9e)
- Git blob：`645cfd87c08f99615be4effe326ae1ef0b8d1ce3`
- MIPLIB original submission commit: 
  [`26a7703fda632540c6df3c537f41b07f61d7de37`](https://git.zib.de/miplib2017/submissions/-/commit/26a7703fda632540c6df3c537f41b07f61d7de37)
- submission path : 
  [`9e830.../misc/fastxgemm-N3-R23-S5-T6.lp.mst`](https://git.zib.de/miplib2017/submissions/-/blob/26a7703fda632540c6df3c537f41b07f61d7de37/9e830301-898b-4340-97f7-c8478277e652/misc/fastxgemm-N3-R23-S5-T6.lp.mst)

The SHA-256 of the LP in the author's warehouse repository is
`22b3511c630c094f89d2634592adfa95632396cc1c732cbfe7f5febe8e88a71b`。
Each model compares `lp_mps_equivalence.json` proof to the current official MPS variable.
The lower bound, objective, RHS, sense and all 786402 matrix coefficients are the same; the only sequencing difference is
414 A `[0,1]` variable is labeled as binary in LP and bounded integer in MPS.
The two are the same feasible domain.

##  It's not about what you're saying.

Determine: The start of objective 174 already exists at the time of the original submission of 2017, and is valid for the current official
MPS strict feasible; MIPLIB's current public solution history does not record it.

There is no explanation as to why the supplementary `.mst` has not entered the best-solution archive.
Therefore, it is only reasonable to assume that the process of standardization of the substrate without automatically importing the submitter-specific start-up substrate is a reasonable assumption.
It cannot be claimed that MIPLIB has rejected it, that the document has not been submitted, or that it has been invalidated due to numerical issues.

Finally, the 174 construct comes from external authors; this round of research contributes to the discovery, migration, and independent strict verification.
It is not possible to label the GPT as an autonomous construct.
