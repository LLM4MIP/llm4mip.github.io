# `fastxgemm-n3r23s5t6`

Research date: 2026-09-09
Official template: balanced ternary, `N=3,R=23,S=5,T=6`

## Result

The strict interval established and audited in this continuation is

```text
90 <= OPT <= 153.
```

The two ends have different provenance:

- **153 is external, not a project/GPT primal contribution.**  It is the
  `S_Lader-Z3` decomposition published by Ballard, Ikenmeyer, Landsberg, and
  Ryder (BILR), arXiv:1801.00843v1, Appendix B, equations (77)--(84).  Exact
  transcription gives `E=0,K=51`, hence full raw factor support and official
  objective 153.  Fixing all 414 integer variables in the unmodified official
  MPS gives objective 153 with zero row, bound, integrality, and exact tensor
  violations.  The direct source/official-MPS audit is in
  [`artifacts/external-audit/`](artifacts/external-audit/). The attribution-labelled
  official-MPS solution is also archived as
  [`solutions/external-bilr2018-strict-153.sol`](solutions/external-bilr2018-strict-153.sol).
- **90 is a new global integer lower bound for this official template.**  A
  mathematical case split excludes exact `K=29`, so exact solutions have
  `K>=30` and raw factor support at least 90.  Combining this with the
  official support floor 84 on the inexact branch gives the integer-valid
  cut

  ```text
  sum(ABS_ALT_U,ABS_ALT_V,ABS_ALT_W) + 6*sum(RESIDUAL) >= 90.
  ```

The instance remains open.  Because every inexact integer factor pattern has
objective at least `1000+84`, a proof of optimality at 153 now reduces to
excluding exact `30<=K<=50`.  No experiment in this directory does that.

## Why the lower bound is valid

Every one of the nine tensor slices has rank three, so every factor row has
degree at least three.  A degree-three (*tight*) row uses three rank positions;
different tight rows cannot share a position.  At `K=29`, the only degree
patterns are `(5,3^8)` and `(4,4,3^7)`.  The first needs 24 positions, but only
23 exist.  In the second, seven tight rows cover 21 positions in every mode
and leave two underlying vectors supported only on the same two non-tight grid
coordinates.

The complete cyclic case split for those two vectors gives these one-factor
support upper bounds.  The proof column uses only the restrictions needed for
the contradiction; the finite audit intersects the tight-slice restrictions
from all three modes and is sometimes sharper.

| uncovered-vector types | hand-proof upper bound | all-mode finite-audit bound |
|---|---:|---:|
| two fixed `A` vectors | 25 | 25 |
| one `A`, one `B/C/D` vector | 28 | 26 |
| two `B/C/D` vectors in one orbit | 27 | 26 |
| two `B/C/D` vectors in different orbits | 27 | 27 |

All are below the assumed `K=29`.  The delicate last case uses the official
constraint that every factor column is nonzero; the official-MPS audit finds
all 69 such rows.  The human-readable proof is
[`artifacts/LB90_PROOF.md`](artifacts/LB90_PROOF.md).  The independent finite
post-lemma enumeration checks 9,108 coordinate/orbit cases in
`artifacts/lb90_combinatorial_audit.json`.

Adding the cut to the official MPS changes its LP optimum from 84 to 90 and
its probed root bound to 90.  This numerical probe checks the implementation;
global validity comes from the integer proof.  See `artifacts/lb90_probe.json`
and `artifacts/fastxgemm-n3r23s5t6-lb90.mps.gz`.

## External 153 solution and equivalence audit

Before the BILR source was identified, a small-unimodular simultaneous
conjugation of the author's `K=58` start independently reached `K=51`.  The
map was

```text
P = [[1,0,0],[0,1,-1],[0,0,1]],
M -> P^(-T) M P^T.
```

Although that core differs from the BILR transcription in 89 of 207 raw
coefficients, `compare_cyclic_cores.py` proves that they are equivalent under
an explicit finite group: a simultaneous signed coordinate permutation,
fixed-`A` column permutation, cyclic-group permutation/rotation, and admissible
sign gauges.  It is therefore an independent rediscovery and equivalence
check of an external published construction, not a new project primal.

The transformed core was also completed on the official MPS: 20,394 variables,
240,116 rows, objective 153, and zero violations.  See
`artifacts/conjugation_vs_bilr153_equivalence.json` and
`artifacts/external_bilr153_official_mps_audit.json`. It is archived separately
as `artifacts/bilr-equivalent-shear-strict-153.sol`; the canonical direct BILR
transcription is `solutions/external-bilr2018-strict-153.sol`.

## Improvement searches and their exact scope

| experiment | actual search domain | result | permitted conclusion |
|---|---|---|---|
| fixed BILR support, `E=0,K<=50` | arbitrary deletion/resigning within the 51 published locations; all 156 outside locations fixed zero | Gurobi `INFEASIBLE`, 127 nodes | complete only for this fixed-support domain |
| at most one new support location | same, but one of the 156 outside locations may activate | 600.14 s `TIME_LIMIT`, 9,746 nodes, no incumbent | no conclusion |
| complete one-vector replacement | all 23 vectors, each of the `3^9` ternary values; 452,709 candidates | no objective below 153 | exact one-vector local optimum |
| coefficient Hamming radius 1/2 | 414 plus 85,284 nominal edits | no objective below 153 | exact radius-two local result |
| finite simultaneous-conjugation orbit | 1,487,976 bounded BFS matrices; 480 transformed cores remain ternary | minimum `K=51`; it is BILR-equivalent | no `K<51` in this finite orbit only |
| finite `P,Q,R` isotropy search | depth two, 121 transforms per side, 7,607 closure checks, 23 valid cyclic candidates | minimum 153 | no improvement in this finite isotropy neighborhood |
| aggregate GF(2) contraction ILP | 511 nonzero factor-support patterns and all 511 contraction-rank cuts | optimum `K=27` | valid relaxation, but no new bound |
| CNF GF(2), `K<=57` | Brent parities, column/degree constraints, contraction cuts, safe symmetry | Kissat and CaDiCaL each `TIME_LIMIT` at 600 s | no conclusion |
| native-XOR GF(2), `K<=50` | same necessary conditions with 12,482 native XORs | CryptoMiniSat `TIME_LIMIT` at 900.65 s | no conclusion |

The fixed BILR `K=51` pattern is accepted immediately by both the exact model
and the native-XOR positive control.  A GF(2) `SAT` result would still be only
a necessary support pattern requiring exact sign lifting; only a completed
`UNSAT` proof could globally exclude the chosen support cap.  No such proof
was obtained here.

## Cross-instance fixed-`A` truncation audit

For each of the same 480 ternary admissible conjugates, the script exhausts
all deletions of one fixed `A` column (2,400 R22 candidates) and two fixed `A`
columns (4,800 R21 candidates):

| child | operation | minimum found | comparison |
|---|---|---:|---|
| `R22,S=4,T=6` | delete one fixed cube | `E=1,K=50`, objective **1150** | no value below 1150 |
| `R21,S=3,T=6` | delete two fixed cubes | `E=2,K=49`, objective **2147** | no value below 2147 |

This rules out only “bounded conjugation followed by fixed-`A` truncation” as
a way to beat those reference values.  It is not a global result for either
child instance.  See `artifacts/truncation_conjugation_orbit.json`.

## Reproduction

From this directory, the central deterministic checks are:

```powershell
python .\scripts\verify_lb90_combinatorics.py --json .\artifacts\lb90_combinatorial_audit.json

python .\scripts\build_and_probe_lb90.py .\input\fastxgemm-n3r23s5t6.mps.gz `
  --solution .\artifacts\bilr-equivalent-shear-strict-153.sol `
  --output-model .\artifacts\fastxgemm-n3r23s5t6-lb90.mps.gz `
  --json .\artifacts\lb90_probe.json `
  --original-lp-log .\logs\lb90_original_lp.log `
  --augmented-lp-log .\logs\lb90_augmented_lp.log `
  --root-log .\logs\lb90_augmented_root.log

python .\scripts\truncation_conjugation_orbit.py .\solutions\author-2017-exact-174.sol `
  --json .\artifacts\truncation_conjugation_orbit.json `
  --r22-core .\artifacts\truncation_orbit_best_r22_core.sol `
  --r21-core .\artifacts\truncation_orbit_best_r21_core.sol
```

Other scripts have their complete parameters archived in the corresponding
JSON and log files.

## Metric warning

`K` is the nonzero count in the cyclic core and the official exact objective
is `3K`.  This is **raw factor support**, not the number of additions in an
optimized common-subexpression-eliminated straight-line program.  Rank,
raw support, and CSE/SLP additions must not be reported interchangeably.
