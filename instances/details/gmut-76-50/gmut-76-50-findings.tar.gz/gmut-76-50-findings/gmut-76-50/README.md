# `gmut-76-50`

## Result

The timber-harvest scheduling instance remains open. This study found neither
a new strict incumbent nor a new global bound. The best rigorously validated
integer witness retained here is public solution 1, with recomputed objective

```text
-14171397.8275
```

Public solution 2 reports the better value `-14171893.7789212`, but eleven of
its binary values are about `9.5e-6` away from integers. Rounding them and
recomputing the six aggregate harvest variables leaves the first lower-flow
constraint violated by approximately `0.065235`. It is therefore not treated
as a strict integer incumbent.

## Structural work

Read-only MPS inspection recovered a seven-period generalized-management-unit
area-restriction model, including 300 base-unit packing rows, 2,269
period-specific adjacency rows, six harvest-volume equalities, ten temporal
smoothing inequalities, and one terminal age constraint. Three custom methods
were executed without general-purpose optimization:

- exact enumeration of 1,035 one-to-three-column exchanges around the rounded support;
- exact support-difference component analysis between the two public solutions;
- a bounded packing-preserving spatial ejection-chain beam.

None yielded a better strict witness. The support difference contains 216
columns in one conflict-connected component, so the attractive near-integral
point is not repairable as a collection of independent small changes. These
failed neighborhoods are diagnostic evidence, not a lower bound or proof.

## Evidence boundary

Gurobi was used only to parse and audit the model; `optimize()` and `presolve()`
were not called. No optimality claim is made. The file
`solutions/public2-rounded-recomputed.sol` is deliberately retained as a
**failed candidate**, not a feasible solution; its infeasibility is documented
by the corresponding audit artifacts and full report.

## Provenance

- [MIPLIB instance page](https://miplib.zib.de/instance_details_gmut-76-50.html)
- Original MPS SHA-256:
  `cc5a3eb49c5c896b819424770c19d7e4aba0f31dd89abd170eb9bafce047aede`
- Research date: 2026-09-09
- Research effort: 60 minutes; generic solver optimization: 0 minutes

## Contents

- [`reports/final_report.md`](reports/final_report.md): full result and method discussion
- [`reports/effort_ledger.md`](reports/effort_ledger.md): experiment accounting
- [`sources/official_background.md`](sources/official_background.md): forestry background and references
- [`artifacts/audit_public_1.json`](artifacts/audit_public_1.json): strict incumbent audit
- [`artifacts/audit_public_2.json`](artifacts/audit_public_2.json): fractional public-solution audit
- [`artifacts/api_local_exchange.json`](artifacts/api_local_exchange.json): bounded exchange outcomes
- [`artifacts/api_support_difference.json`](artifacts/api_support_difference.json): exact component analysis
- [`artifacts/api_spatial_beam.json`](artifacts/api_spatial_beam.json): bounded spatial search diagnostics
- [`scripts/`](scripts/): read-only structure, audit, and custom-search implementations

