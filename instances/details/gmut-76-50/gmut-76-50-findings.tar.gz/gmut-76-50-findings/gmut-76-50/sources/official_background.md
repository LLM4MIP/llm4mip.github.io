# Official and authoritative background: gmut-76-50

## MIPLIB record

- Official page: <https://miplib.zib.de/instance_details_gmut-76-50.html>
- Official MPS: <https://miplib.zib.de/WebData/instances/gmut-76-50.mps.gz>
- Status observed on 2026-09-09: open.
- MIPLIB objective convention: minimization; displayed best value
  `-14171893.7789212*`.
- Original size: 68,865 variables (68,859 binary/integer-marked columns and six
  continuous variables), 2,586 constraints, and 470,045 nonzeros.
- MIPLIB classifications: variable-bound, set-packing, and mixed-binary.

MIPLIB describes the source problem as timber-harvest scheduling.  Management
units and generalized management units may be harvested at most once over the
planning horizon.  Additional constraints smooth harvested volume between
successive periods, enforce a terminal area-weighted average forest age, and
limit clear-cut size in every period.

The official solution archive contains solution 1 (exact objective
`-14171398`) and solution 2 (displayed objective `-14171894`, integrality
violation `9.5e-06`).  Both were downloaded so that any claimed incumbent can
be checked against the original MPS rather than trusted as metadata.

## Initial methodological reading

This is a column-rich packing formulation with a very small layer of global
continuous coupling.  Natural specialized routes include recovering the
latent management-unit/period structure, eliminating or substituting the six
continuous aggregate columns, configuration dominance, conflict-graph
methods, Lagrangian relaxation of the temporal/global rows, and exact cutoff
certification.  A long generic branch-and-bound run is explicitly not the
research method.

The earlier five-minute ranking note was only a prioritization assessment, not
a solution attempt.  It suggested the same configuration-aware and
Lagrangian/PB direction; it is retained as context but is not treated as an
experimental result.

## Method references

- McDill, Rebain, and Braze, *Harvest Scheduling with Area-Based Adjacency
  Constraints*, Forest Science 48(4), 2002:
  <https://faculty.washington.edu/toths/Presentations/Lecture%2010/McDill_etal_2002.pdf>.
  This paper defines the generalized-management-unit/cluster-packing ARM used
  here and discusses enumeration-based size reduction.
- Goycoolea et al., *Harvest Scheduling Subject to Maximum Area Restrictions:
  Exploring Exact Approaches*, Operations Research 53(3), 2005,
  DOI 10.1287/opre.1040.0169:
  <https://pubsonline.informs.org/doi/abs/10.1287/opre.1040.0169>.
  The exact approach is based on clique strengthening of a projected model.
- Konnyu and Toth, *A cutting plane method for solving harvest scheduling
  models with area restrictions*, EJOR 228(1), 2013,
  DOI 10.1016/j.ejor.2013.01.020:
  <https://www.sciencedirect.com/science/article/abs/pii/S0377221713000507>.
  It separates violated area restrictions instead of relying only on an
  a-priori enumerated formulation.
