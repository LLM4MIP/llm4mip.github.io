#!/usr/bin/env python3
"""
Spatial configuration recovery and bounded ejection-chain repair.

Usage:
    python spatial_beam.py INSTANCE.mps SOL2.sol[.gz] OUTPUT.json \
        [OUTPUT.sol]

The script:
  * reads the MPS with gurobipy;
  * never calls optimize();
  * accepts Gurobi .sol and .sol.gz files;
  * recovers AA, Adj, harvest, age, and objective signatures;
  * reports exact duplicates and conservative dominance;
  * constructs the 300-node management-unit conflict graph;
  * searches packing-preserving spatial ejection chains;
  * validates every returned witness against every original MPS row;
  * writes a sparse .sol if a feasible integral witness is found.

This is a primal heuristic and structural diagnostic, not a proof method.
"""

import sys
import os
import json
import gzip
import math
import heapq
import xml.etree.ElementTree as ET
from collections import defaultdict, Counter

import gurobipy as gp
from gurobipy import GRB


# ------------------------------- limits -----------------------------------

MAX_CONFIG_REPORT = 250
MAX_DUPLICATE_REPORT = 100
MAX_DOMINANCE_REPORT = 100
MAX_GRAPH_EDGES_REPORT = 300
MAX_CANDIDATES = 40
BEAM_WIDTH = 20
MAX_DEPTH = 4
MAX_EXPANDED = 300
MAX_RETURNED = 20

ROUND_EPS = 2.0e-5
FEAS_TOL = 1.0e-7
AGE_TOL = 1.0e-7

# Objective/violation score weights. They affect search ordering only.
FLOW_WEIGHT = 50000.0
AGE_WEIGHT = 1000.0
CHAIN_WEIGHT = 2.0


# ------------------------- solution file reader ----------------------------

def read_sol(path):
    if path.endswith(".gz"):
        with gzip.open(path, "rb") as f:
            raw = f.read()
    else:
        with open(path, "rb") as f:
            raw = f.read()

    ans = {}
    try:
        root = ET.fromstring(raw)
        for e in root.iter():
            n = e.attrib.get("name")
            x = e.attrib.get("value")
            if n is not None and x is not None:
                try:
                    ans[n] = float(x)
                except ValueError:
                    pass
        if ans:
            return ans
    except ET.ParseError:
        pass

    # Fallback for simple "name value" files.
    text = raw.decode("utf-8", errors="replace")
    for line in text.splitlines():
        z = line.replace(",", " ").split()
        if len(z) >= 2:
            try:
                ans[z[0]] = float(z[1])
            except ValueError:
                pass
    return ans


def parse_x(name):
    if not name.startswith("x") or "_" not in name:
        return None
    try:
        a, t = name[1:].rsplit("_", 1)
        return int(a), int(t)
    except Exception:
        return None


def is_x(v):
    return parse_x(v.VarName) is not None


# ----------------------------- row utilities -------------------------------

def violation(sense, lhs, rhs):
    if sense == GRB.LESS_EQUAL:
        return max(0.0, lhs - rhs)
    if sense == GRB.GREATER_EQUAL:
        return max(0.0, rhs - lhs)
    if sense == GRB.EQUAL:
        return abs(lhs - rhs)
    return float("inf")


def main():
    if len(sys.argv) not in (4, 5):
        print(
            "usage: spatial_beam.py INSTANCE.mps SOL2.sol[.gz] "
            "OUTPUT.json [OUTPUT.sol]",
            file=sys.stderr,
        )
        sys.exit(2)

    mps_path, sol_path, json_path = sys.argv[1:4]
    sol_out = sys.argv[4] if len(sys.argv) == 5 else None

    supplied = read_sol(sol_path)

    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()

    # Parse only. Deliberately no optimize().
    model = gp.read(mps_path, env=env)
    variables = model.getVars()
    rows = model.getConstrs()

    var_by_name = {v.VarName: v for v in variables}
    row_by_name = {r.ConstrName: r for r in rows}

    # One sparse incidence extraction.
    col_rows = defaultdict(list)
    row_cols = defaultdict(list)
    for v in variables:
        col = model.getCol(v)
        for pos in range(col.size()):
            r = col.getConstr(pos)
            c = col.getCoeff(pos)
            rn = r.ConstrName
            cc = float(c)
            col_rows[v.VarName].append((rn, cc))
            row_cols[rn].append((v.VarName, cc))

    xvars = [v for v in variables if is_x(v)]
    xnames = [v.VarName for v in xvars]

    # --------------------- configuration recovery --------------------------

    configs = {}
    config_names_by_id = defaultdict(list)

    for v in xvars:
        p = parse_x(v.VarName)
        cid, period = p

        aa = []
        adj = []
        volume = 0.0
        age = 0.0

        for rn, c in col_rows[v.VarName]:
            if rn.startswith("AA_"):
                try:
                    aa.append(int(rn[3:]))
                except ValueError:
                    pass
            elif rn.startswith("Adj_"):
                try:
                    adj.append(int(rn[4:]))
                except ValueError:
                    pass
            elif rn == f"Sawti_H{period}":
                volume += c
            elif rn == "_EAge_11":
                age += c

        # In this formulation each x objective is its complete contribution.
        rec = {
            "name": v.VarName,
            "id": cid,
            "period": period,
            "base_units": tuple(sorted(set(aa))),
            "adjacency_rows": tuple(sorted(set(adj))),
            "volume": volume,
            "age": age,
            "objective": float(v.Obj),
            "column_nnz": len(col_rows[v.VarName]),
        }
        configs[v.VarName] = rec
        config_names_by_id[cid].append(v.VarName)

    # Exact duplicate signatures. Objective is included, because equal
    # geometry with different objective is not an exact duplicate.
    exact_groups = defaultdict(list)
    for n, q in configs.items():
        key = (
            q["period"],
            q["base_units"],
            q["adjacency_rows"],
            round(q["volume"], 10),
            round(q["age"], 10),
            round(q["objective"], 10),
        )
        exact_groups[key].append(n)

    duplicate_groups = [
        g for g in exact_groups.values() if len(g) > 1
    ]

    # Conservative dominance:
    # A dominates B only when same period, same objective direction, and A
    # uses subsets of both AA and Adj resources, has no smaller volume, and
    # has no smaller terminal-age coefficient. This is a structural report;
    # the script does not delete variables from the model.
    dominance = []
    resource_buckets = defaultdict(list)
    for name, record in configs.items():
        resource_buckets[(record["period"], record["base_units"], record["adjacency_rows"])].append(name)
    for bucket in resource_buckets.values():
        for a in bucket:
            A = configs[a]
            for b in bucket:
                if a == b:
                    continue
                B = configs[b]
                if A["volume"] + 1e-8 < B["volume"]:
                    continue
                if A["age"] + 1e-8 < B["age"]:
                    continue
                # Minimization: more negative objective is better.
                if A["objective"] > B["objective"] + 1e-8:
                    continue
                dominance.append((a, b))

    # --------------------- rounded incumbent -------------------------------

    rounded = {}
    for v in variables:
        if is_x(v):
            rounded[v.VarName] = (
                1.0 if supplied.get(v.VarName, 0.0) >= 0.5 else 0.0
            )
        else:
            rounded[v.VarName] = supplied.get(v.VarName, 0.0)

    selected0 = {
        n for n in xnames if rounded.get(n, 0.0) >= 0.5
    }

    # Base-unit and adjacency occupancy of incumbent.
    unit_count0 = Counter()
    adj_count0 = Counter()
    for n in selected0:
        q = configs[n]
        for u in q["base_units"]:
            unit_count0[u] += 1
        for a in q["adjacency_rows"]:
            adj_count0[(q["period"], a)] += 1

    # H is reconstructed from selected x columns through Sawti equalities.
    sawti = {}
    hcoef = {}
    hrow_terms = {}
    for t in range(1, 7):
        rn = f"Sawti_H{t}"
        terms = row_cols.get(rn, [])
        hrow_terms[t] = terms
        for n, c in terms:
            if n == f"H_{t}":
                hcoef[t] = c
            elif parse_x(n) is not None:
                sawti.setdefault(t, {})[n] = c

    def compute_H(selected):
        H = {}
        for t in range(1, 7):
            fixed = 0.0
            for n, c in sawti.get(t, {}).items():
                if n in selected:
                    fixed += c
            rn = f"Sawti_H{t}"
            rhs = float(row_by_name[rn].RHS)
            hc = hcoef[t]
            H[t] = (rhs - fixed) / hc
        return H

    H0 = compute_H(selected0)

    # One complete baseline row evaluation, used for final validation and
    # incumbent diagnostics. Candidate states use sparse deltas only.
    baseline_lhs = {}
    for r in rows:
        lhs = 0.0
        for n, c in row_cols[r.ConstrName]:
            lhs += c * rounded.get(n, 0.0)
        baseline_lhs[r.ConstrName] = lhs

    obj0 = sum(float(v.Obj) * rounded.get(v.VarName, 0.0)
               for v in variables)

    # ------------------- spatial graph reconstruction ----------------------

    # Configurations sharing a base unit define hyperedges on the 300 nodes.
    unit_to_configs = defaultdict(list)
    for n, q in configs.items():
        for u in q["base_units"]:
            if 1 <= u <= 300:
                unit_to_configs[u].append(n)

    # Pairwise conflict graph among management units: two units are linked
    # when some configuration contains both.
    graph = defaultdict(set)
    hyperedge_count = 0
    max_hyperedge = 0
    for n, q in configs.items():
        U = [u for u in q["base_units"] if 1 <= u <= 300]
        if len(U) >= 2:
            hyperedge_count += 1
            max_hyperedge = max(max_hyperedge, len(U))
            for i, u in enumerate(U):
                for w in U[i + 1:]:
                    graph[u].add(w)
                    graph[w].add(u)

    graph_edges = sum(len(z) for z in graph.values()) // 2
    degrees = [len(graph[u]) for u in range(1, 301)]
    graph_stats = {
        "management_units": 300,
        "units_present_in_any_configuration": sum(
            1 for u in range(1, 301) if unit_to_configs[u]
        ),
        "hyperedges_with_at_least_two_units": hyperedge_count,
        "max_configuration_base_unit_cardinality": max_hyperedge,
        "pairwise_graph_edges": graph_edges,
        "min_degree_present_units": min(
            [degrees[u - 1] for u in range(1, 301)
             if unit_to_configs[u]] or [0]
        ),
        "max_degree": max(degrees or [0]),
        "mean_degree_present_units": (
            sum(degrees[u - 1] for u in range(1, 301)
                if unit_to_configs[u])
            / max(1, sum(1 for u in range(1, 301)
                         if unit_to_configs[u]))
        ),
        "isolated_units": [
            u for u in range(1, 301)
            if unit_to_configs[u] and not graph[u]
        ],
    }

    # ---------------- candidate generation -------------------------------

    # Candidate additions are spatially related to incumbent clusters:
    # sharing an AA unit, an adjacency row, or a configuration ID.
    related = defaultdict(set)
    selected_by_unit = defaultdict(set)
    selected_by_adj = defaultdict(set)

    for n in selected0:
        q = configs[n]
        for u in q["base_units"]:
            selected_by_unit[u].add(n)
        for a in q["adjacency_rows"]:
            selected_by_adj[(q["period"], a)].add(n)

    for n, q in configs.items():
        if n in selected0:
            continue
        score = 0
        for u in q["base_units"]:
            if selected_by_unit[u]:
                score += 4
        for a in q["adjacency_rows"]:
            if selected_by_adj[(q["period"], a)]:
                score += 1
        if config_names_by_id[q["id"]]:
            score += 1
        if score:
            related[n] = score

    candidate_adds = sorted(
        related,
        key=lambda n: (
            -related[n],
            configs[n]["objective"],
            configs[n]["period"],
            n,
        ),
    )[:MAX_CANDIDATES]

    # Also include period alternatives for selected configuration IDs.
    for n in list(selected0):
        cid = configs[n]["id"]
        for z in config_names_by_id[cid]:
            if z not in selected0 and z not in candidate_adds:
                candidate_adds.append(z)
                if len(candidate_adds) >= MAX_CANDIDATES:
                    break
        if len(candidate_adds) >= MAX_CANDIDATES:
            break

    # Remove candidates impossible on their own because of a static AA/Adj
    # conflict with the incumbent, unless the conflicting selected column can
    # be ejected.
    candidate_adds = list(dict.fromkeys(candidate_adds))

    # Sparse effect of toggling one x column. The only non-x effect is the
    # induced H change required by Sawti_Ht.
    x_effect = {}
    x_dH = {}
    for n in set(candidate_adds) | selected0:
        eff = defaultdict(float)
        for rn, c in col_rows[n]:
            eff[rn] += c
        p = parse_x(n)
        dh = {t: 0.0 for t in range(1, 7)}
        if p and p[1] in hcoef and hcoef[p[1]] != 0.0:
            t = p[1]
            dx = 1.0
            dh[t] = -sawti.get(t, {}).get(n, 0.0) / hcoef[t]
            hn = f"H_{t}"
            for rn, c in col_rows.get(hn, []):
                eff[rn] += dh[t] * c
        x_effect[n] = {
            rn: c for rn, c in eff.items() if abs(c) > 1e-12
        }
        x_dH[n] = dh

    # ---------------- incremental state machinery --------------------------

    # A state stores only modifications to the rounded incumbent.
    # It does not copy the full 68,865-variable vector.
    #
    # state:
    #   selected: frozenset of currently selected x names
    #   removed: frozenset relative to selected0
    #   added: frozenset relative to selected0
    #   unit_count, adj_count: copied only for the small counters
    #   row_delta: sparse affected-row delta
    #   dH: six-number harvest change
    #   depth
    #   objective_delta

    def flow_info(dH):
        H = {t: H0[t] + dH[t] for t in range(1, 7)}
        slacks = {}
        violation_sum = 0.0
        maxv = 0.0
        for t in range(1, 6):
            lo = H[t + 1] - 0.95 * H[t]
            hi = 1.10 * H[t] - H[t + 1]
            slacks[t] = (lo, hi)
            violation_sum += max(0.0, -lo) + max(0.0, -hi)
            maxv = max(maxv, max(0.0, -lo), max(0.0, -hi))
        return H, slacks, violation_sum, maxv

    def state_score(st):
        _, _, fv, fm = flow_info(st["dH"])
        # Terminal age is checked through the sparse row delta when needed.
        age_delta = st["row_delta"].get("_EAge_11", 0.0)
        age_row = row_by_name.get("_EAge_11")
        age_v = 0.0
        if age_row is not None:
            age_v = violation(
                age_row.Sense,
                baseline_lhs["_EAge_11"] + age_delta,
                float(age_row.RHS),
            )
        # Favor objective, then flow feasibility, then age feasibility.
        return (
            st["objective_delta"]
            + FLOW_WEIGHT * fv
            + AGE_WEIGHT * age_v
            + CHAIN_WEIGHT * len(st["added"] | st["removed"]),
            fm,
            len(st["added"] | st["removed"]),
        )

    def try_toggle(st, remove_name, add_name):
        """
        Apply one replacement incrementally.

        The replacement is permitted only if:
          * remove_name is selected;
          * add_name is unselected;
          * all AA and period-specific Adj rows remain <= 1.
        """
        if remove_name not in st["selected"]:
            return None
        if add_name in st["selected"]:
            return None
        if remove_name == add_name:
            return None

        selected = set(st["selected"])
        selected.remove(remove_name)
        selected.add(add_name)

        uc = st["unit_count"].copy()
        ac = st["adj_count"].copy()

        qr = configs[remove_name]
        qa = configs[add_name]

        for u in qr["base_units"]:
            uc[u] -= 1
        for a in qr["adjacency_rows"]:
            ac[(qr["period"], a)] -= 1

        # Test additions after removal.
        for u in qa["base_units"]:
            if uc[u] >= 1:
                return None
        for a in qa["adjacency_rows"]:
            if ac[(qa["period"], a)] >= 1:
                return None

        for u in qa["base_units"]:
            uc[u] += 1
        for a in qa["adjacency_rows"]:
            ac[(qa["period"], a)] += 1

        rd = st["row_delta"].copy()
        for rn, c in x_effect[remove_name].items():
            rd[rn] = rd.get(rn, 0.0) - c
        for rn, c in x_effect[add_name].items():
            rd[rn] = rd.get(rn, 0.0) + c
        rd = {rn: c for rn, c in rd.items() if abs(c) > 1e-12}

        dh = st["dH"].copy()
        for t in range(1, 7):
            dh[t] -= x_dH[remove_name][t]
            dh[t] += x_dH[add_name][t]

        rem = set(st["removed"])
        add = set(st["added"])

        # Relative to rounded solution 2.
        if remove_name in selected0:
            if remove_name in rem:
                rem.remove(remove_name)
            else:
                rem.add(remove_name)
        else:
            # This case is not expected for a selected removal.
            add.discard(remove_name)

        if add_name in selected0:
            rem.discard(add_name)
        else:
            if add_name in add:
                add.remove(add_name)
            else:
                add.add(add_name)

        return {
            "selected": frozenset(selected),
            "removed": frozenset(rem),
            "added": frozenset(add),
            "unit_count": uc,
            "adj_count": ac,
            "row_delta": rd,
            "dH": dh,
            "depth": st["depth"] + 1,
            "objective_delta": (
                st["objective_delta"]
                - float(var_by_name[remove_name].Obj)
                + float(var_by_name[add_name].Obj)
            ),
        }

    # Initial state.
    initial = {
        "selected": frozenset(selected0),
        "removed": frozenset(),
        "added": frozenset(),
        "unit_count": unit_count0,
        "adj_count": adj_count0,
        "row_delta": {},
        "dH": {t: 0.0 for t in range(1, 7)},
        "depth": 0,
        "objective_delta": 0.0,
    }

    # Search only swaps. This preserves the incumbent number of selected
    # configurations and naturally creates ejection chains. The candidate
    # pool is spatially related and bounded.
    beam = [initial]
    visited = set()
    expanded = 0
    best_states = []

    while beam and expanded < MAX_EXPANDED:
        nxt = []
        for st in beam:
            expanded += 1
            if st["depth"] >= MAX_DEPTH:
                continue

            # Prioritize removals touching units/Adj rows of promising
            # candidate additions. This avoids scanning all selected columns.
            possible_removals = set()
            for a in candidate_adds:
                if a in st["selected"]:
                    continue
                qa = configs[a]
                for n in st["selected"]:
                    qn = configs[n]
                    if (
                        set(qa["base_units"]) & set(qn["base_units"])
                        or (
                            qa["period"] == qn["period"]
                            and set(qa["adjacency_rows"]) &
                            set(qn["adjacency_rows"])
                        )
                    ):
                        possible_removals.add(n)

            for r in possible_removals:
                for a in candidate_adds:
                    if a in st["selected"]:
                        continue
                    ns = try_toggle(st, r, a)
                    if ns is None:
                        continue

                    key = (
                        tuple(sorted(ns["added"])),
                        tuple(sorted(ns["removed"])),
                    )
                    if key in visited:
                        continue
                    visited.add(key)
                    nxt.append(ns)

                    # Retain compact diagnostics for states that improve the
                    # flow chain or objective.
                    if (
                        ns["objective_delta"] < 0.0
                        or flow_info(ns["dH"])[2] <
                        flow_info(st["dH"])[2]
                    ):
                        best_states.append(ns)

                    if expanded >= MAX_EXPANDED:
                        break
                if expanded >= MAX_EXPANDED:
                    break
            if expanded >= MAX_EXPANDED:
                break

        nxt.sort(key=state_score)
        beam = nxt[:BEAM_WIDTH]

    # ----------------------- final witness validation ----------------------

    def materialize(selected):
        vals = defaultdict(float)
        # Preserve all supplied non-x values, then overwrite x and H.
        for v in variables:
            if not is_x(v):
                vals[v.VarName] = supplied.get(v.VarName, 0.0)
            else:
                vals[v.VarName] = 1.0 if v.VarName in selected else 0.0

        H = compute_H(selected)
        for t in range(1, 7):
            vals[f"H_{t}"] = H[t]
        return vals

    def validate(selected):
        vals = materialize(selected)
        bad = []
        maxv = 0.0
        obj = 0.0

        for v in variables:
            x = vals[v.VarName]
            obj += float(v.Obj) * x
            if x < v.LB - FEAS_TOL or x > v.UB + FEAS_TOL:
                bad.append({
                    "type": "bound",
                    "var": v.VarName,
                    "value": x,
                    "lb": float(v.LB),
                    "ub": float(v.UB),
                })
            if v.VType in (GRB.BINARY, GRB.INTEGER):
                if abs(x - round(x)) > FEAS_TOL:
                    bad.append({
                        "type": "integrality",
                        "var": v.VarName,
                        "value": x,
                    })

        for r in rows:
            lhs = 0.0
            for n, c in row_cols[r.ConstrName]:
                lhs += c * vals[n]
            vv = violation(r.Sense, lhs, float(r.RHS))
            maxv = max(maxv, vv)
            if vv > FEAS_TOL:
                bad.append({
                    "type": "row",
                    "row": r.ConstrName,
                    "lhs": lhs,
                    "rhs": float(r.RHS),
                    "sense": r.Sense,
                    "violation": vv,
                })

        return {
            "feasible": not bad,
            "objective": obj,
            "max_violation": maxv,
            "bad": bad[:MAX_ROW_OUTPUT],
            "values": vals,
        }

    # Evaluate all retained promising states, plus the best beam states.
    candidates = best_states + beam
    candidates.sort(key=state_score)

    witnesses = []
    seen_witnesses = set()
    for st in candidates[:MAX_RETURNED * 4]:
        key = (
            tuple(sorted(st["added"])),
            tuple(sorted(st["removed"])),
        )
        if key in seen_witnesses:
            continue
        seen_witnesses.add(key)

        vr = validate(st["selected"])
        H, fs, fv, fm = flow_info(st["dH"])
        witnesses.append({
            "depth": st["depth"],
            "added": sorted(st["added"]),
            "removed": sorted(st["removed"]),
            "objective_delta_from_rounded_solution2": (
                st["objective_delta"]
            ),
            "objective": vr["objective"],
            "H": H,
            "flow_slacks": fs,
            "flow_violation_sum": fv,
            "max_flow_violation": fm,
            "feasible": vr["feasible"],
            "max_original_mps_violation": vr["max_violation"],
            "bad_rows": vr["bad"][:MAX_ROW_OUTPUT],
        })

    feasible_witnesses = [z for z in witnesses if z["feasible"]]
    feasible_witnesses.sort(
        key=lambda z: (
            z["objective"],
            len(z["added"]) + len(z["removed"]),
        )
    )

    # Write the best valid integral witness, if any.
    written_sol = None
    if sol_out and feasible_witnesses:
        best = feasible_witnesses[0]
        selected = set(selected0)
        selected.difference_update(best["removed"])
        selected.update(best["added"])
        vals = materialize(selected)

        with open(sol_out, "w") as f:
            f.write("# spatial beam feasible integral witness\n")
            f.write("# generated without optimization\n")
            for v in variables:
                x = vals[v.VarName]
                if abs(x) > 1.0e-12:
                    f.write(f"{v.VarName} {x:.12g}\n")
        written_sol = sol_out

    # ------------------------- bounded reporting ---------------------------

    config_report = []
    for n in sorted(configs)[:MAX_CONFIG_REPORT]:
        q = configs[n]
        config_report.append({
            "name": n,
            "id": q["id"],
            "period": q["period"],
            "base_units": list(q["base_units"]),
            "adjacency_rows": list(q["adjacency_rows"]),
            "volume": q["volume"],
            "age": q["age"],
            "objective": q["objective"],
            "column_nnz": q["column_nnz"],
        })

    duplicate_report = [
        {
            "size": len(g),
            "columns": g[:MAX_DUPLICATE_REPORT],
        }
        for g in duplicate_groups[:MAX_DUPLICATE_REPORT]
    ]

    dominance_report = [
        {
            "dominator": a,
            "dominated": b,
            "period": configs[a]["period"],
        }
        for a, b in dominance[:MAX_DOMINANCE_REPORT]
    ]

    # Best search state, whether or not feasible.
    all_reported = witnesses
    if all_reported:
        best_state = min(
            all_reported,
            key=lambda z: (
                0 if z["feasible"] else 1,
                z["objective"],
                z["max_original_mps_violation"],
            ),
        )
        min_violation = min(
            z["max_original_mps_violation"] for z in all_reported
        )
        best_objective = min(z["objective"] for z in all_reported)
    else:
        best_state = None
        min_violation = None
        best_objective = None

    if feasible_witnesses:
        diagnosis = (
            "A packing-preserving spatial ejection chain produced a valid "
            "integral witness. Compare its objective with solution 1; if it "
            "is better, enlarge the same spatial candidate generator. If it "
            "is worse, retain it as a feasible incumbent but do not infer "
            "optimality."
        )
    elif best_state is not None and min_violation <= 1.0e-5:
        diagnosis = (
            "The bounded spatial beam nearly repaired the flow chain but "
            "found no fully feasible witness. Increase chain depth or add "
            "the specific conflicting adjacency neighborhoods of the best "
            "state; do not yet move to dual analysis."
        )
    else:
        diagnosis = (
            "No near-feasible spatial ejection chain was found. The next "
            "experiment should construct projected singleton-period harvest "
            "variables and separate maximal spatial cliques/path inequalities "
            "from the recovered 300-node hypergraph. The current beam is "
            "falsified as the primary repair method for this incumbent."
        )

    output = {
        "model_shape": {
            "rows": model.NumConstrs,
            "columns": model.NumVars,
            "nonzeros": model.NumNZs,
        },
        "input": {
            "mps": mps_path,
            "solution2": sol_path,
        },
        "configuration_recovery": {
            "configuration_period_columns": len(configs),
            "distinct_configuration_ids": len(config_names_by_id),
            "configuration_examples": config_report,
        },
        "exact_duplicates": {
            "groups": len(duplicate_groups),
            "columns_in_duplicate_groups": sum(
                len(g) for g in duplicate_groups
            ),
            "largest_group": max(
                [len(g) for g in duplicate_groups] or [0]
            ),
            "examples": duplicate_report,
        },
        "conservative_dominance": {
            "ordered_dominance_pairs": len(dominance),
            "examples": dominance_report,
            "note": (
                "Dominance is reported conservatively and is not applied "
                "automatically because terminal-age and flow semantics may "
                "make a weaker-looking column useful in another period."
            ),
        },
        "management_unit_hypergraph": {
            "nodes": 300,
            "statistics": graph_stats,
            "sample_edges": [
                [u, w]
                for u in sorted(graph)
                for w in sorted(graph[u])
                if u < w
            ][:MAX_GRAPH_EDGES_REPORT],
            "unit_to_configuration_counts": {
                str(u): len(unit_to_configs[u])
                for u in range(1, 301)
                if unit_to_configs[u]
            },
        },
        "rounded_solution2": {
            "selected_columns": len(selected0),
            "objective": obj0,
            "H": H0,
        },
        "search": {
            "candidate_additions": len(candidate_adds),
            "candidate_addition_examples": candidate_adds[:MAX_CANDIDATES],
            "beam_width": BEAM_WIDTH,
            "max_depth": MAX_DEPTH,
            "max_expanded": MAX_EXPANDED,
            "nodes_expanded": expanded,
            "states_visited": len(visited),
            "reported_states": len(witnesses),
            "best_objective_seen": best_objective,
            "minimum_original_mps_violation_seen": min_violation,
            "feasible_witnesses": len(feasible_witnesses),
            "witnesses": witnesses[:MAX_RETURNED],
            "written_solution": written_sol,
        },
        "next_step": {
            "diagnosis": diagnosis,
            "falsifiable_rule": (
                "If feasible_witnesses > 0, spatial ejection chains are "
                "viable and should be expanded around the best witness. If "
                "feasible_witnesses == 0 and minimum_original_mps_violation_seen "
                "is materially positive, switch to projected singleton "
                "harvest/clique/path separation. A JSON candidate is not a "
                "witness unless feasible is true and max_original_mps_violation "
                "is at most the stated tolerance."
            ),
        },
    }

    with open(json_path, "w") as f:
        json.dump(output, f, indent=2, sort_keys=True)

    print(json.dumps({
        "json": json_path,
        "config_columns": len(configs),
        "duplicate_groups": len(duplicate_groups),
        "dominance_pairs": len(dominance),
        "graph_edges": graph_edges,
        "candidate_additions": len(candidate_adds),
        "nodes_expanded": expanded,
        "feasible_witnesses": len(feasible_witnesses),
        "best_objective_seen": best_objective,
        "minimum_original_mps_violation_seen": min_violation,
        "written_solution": written_sol,
        "diagnosis": diagnosis,
    }, indent=2))


if __name__ == "__main__":
    main()
