"""Exact read-only forensic summary for gmut-76-50.

The script intentionally never calls Model.optimize or Model.presolve.
"""
from __future__ import annotations

from collections import Counter, defaultdict
import gzip
import json
import math
from pathlib import Path
import re
import sys

import gurobipy as gp


X_RE = re.compile(r"^x(\d+)_(\d+)$")


def finite(value: float):
    return value if math.isfinite(value) else ("inf" if value > 0 else "-inf")


def solution_support(path: Path) -> dict:
    support: dict[str, float] = {}
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8", errors="replace") as stream:
        for raw in stream:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            fields = line.split()
            if len(fields) >= 2:
                try:
                    value = float(fields[1])
                except ValueError:
                    continue
                if abs(value) > 1e-12:
                    support[fields[0]] = value
    return {
        "file": str(path),
        "nonzero_count": len(support),
        "integer_nonzeros": sorted(k for k, v in support.items() if k.startswith("x") and abs(v) > 1e-12),
        "continuous_nonzeros": {k: v for k, v in support.items() if k.startswith("H_")},
    }


def main() -> None:
    if len(sys.argv) < 3:
        raise SystemExit("usage: forensic_structure.py MODEL OUTPUT [SOLUTION ...]")
    model_path = Path(sys.argv[1])
    output_path = Path(sys.argv[2])
    environment = gp.Env(empty=True)
    environment.setParam("OutputFlag", 0)
    environment.start()
    model = gp.read(str(model_path), environment)

    suffix = defaultdict(lambda: Counter())
    base = defaultdict(lambda: Counter())
    inactive = []
    malformed = []
    for var in model.getVars():
        match = X_RE.match(var.VarName)
        if not match:
            if not var.VarName.startswith("H_"):
                malformed.append(var.VarName)
            continue
        first, second = map(int, match.groups())
        degree = model.getCol(var).size()
        flags = {
            "count": 1,
            "active": int(degree > 0 or var.Obj != 0),
            "obj_nz": int(var.Obj != 0),
            "degree_sum": degree,
        }
        for key, value in flags.items():
            suffix[second][key] += value
            base[first][key] += value
        if degree == 0 and var.Obj == 0:
            inactive.append(var.VarName)

    rows = []
    for con in model.getConstrs():
        expr = model.getRow(con)
        terms = []
        period_counts = Counter()
        first_indices = []
        for pos in range(expr.size()):
            var = expr.getVar(pos)
            coefficient = expr.getCoeff(pos)
            match = X_RE.match(var.VarName)
            if match:
                first, second = map(int, match.groups())
                first_indices.append(first)
                period_counts[second] += 1
            terms.append([var.VarName, coefficient])
        family = re.split(r"_\d", con.ConstrName, maxsplit=1)[0]
        keep_terms = terms[:30] if con.ConstrName.startswith(("Flct", "Sawti", "_EAge")) else terms[:12]
        coefficients = [item[1] for item in terms]
        rows.append(
            {
                "name": con.ConstrName,
                "family": family,
                "sense": con.Sense,
                "rhs": con.RHS,
                "degree": expr.size(),
                "period_counts": dict(sorted(period_counts.items())),
                "first_index_minmax": [min(first_indices), max(first_indices)] if first_indices else None,
                "coefficient_minmax": [min(coefficients), max(coefficients)] if coefficients else None,
                "coefficient_distinct_rounded": len({round(value, 8) for value in coefficients}),
                "terms": keep_terms,
                "terms_truncated": len(keep_terms) < len(terms),
            }
        )

    by_family = defaultdict(list)
    for row in rows:
        by_family[row["family"]].append(row)
    family_summary = {}
    for name, members in sorted(by_family.items()):
        degrees = Counter(item["degree"] for item in members)
        family_summary[name] = {
            "count": len(members),
            "degree_histogram": dict(sorted(degrees.items())),
            "examples": members[:3],
        }

    active_first = [idx for idx, info in base.items() if info["active"]]
    payload = {
        "source": str(model_path),
        "counts": {"variables": model.NumVars, "constraints": model.NumConstrs, "nonzeros": model.NumNZs},
        "suffix_summary": {str(k): dict(v) for k, v in sorted(suffix.items())},
        "first_index": {
            "distinct": len(base),
            "min": min(base),
            "max": max(base),
            "active_distinct": len(active_first),
            "active_minmax": [min(active_first), max(active_first)],
        },
        "inactive_count": len(inactive),
        "inactive_first_and_last": inactive[:20] + inactive[-20:],
        "malformed_columns": malformed,
        "families": family_summary,
        "all_global_rows": [row for row in rows if row["name"].startswith(("Flct", "Sawti", "_EAge"))],
        "solutions": [solution_support(Path(item)) for item in sys.argv[3:]],
        "notes": ["Read-only parse; optimize and presolve were not called."],
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
