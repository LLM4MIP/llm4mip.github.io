#!/usr/bin/env python3
"""Fix an incumbent's discrete pattern and strictly reoptimize its continuous LP."""

from __future__ import annotations

import argparse
from pathlib import Path

import gurobipy as gp


def read_solution(path: Path) -> dict[str, float]:
    values: dict[str, float] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        fields = line.split()
        if len(fields) != 2 or fields[0].startswith(("#", "=")):
            continue
        try:
            values[fields[0]] = float(fields[1])
        except ValueError:
            pass
    return values


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("incumbent", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--log", type=Path)
    args = parser.parse_args()

    model = gp.read(str(args.mps))
    values = read_solution(args.incumbent)
    fixed = 0
    selected = 0
    for variable in model.getVars():
        if variable.VType == gp.GRB.CONTINUOUS:
            continue
        value = round(values.get(variable.VarName, 0.0))
        variable.LB = value
        variable.UB = value
        fixed += 1
        selected += value

    model.Params.FeasibilityTol = 1e-9
    model.Params.IntFeasTol = 1e-9
    model.Params.OptimalityTol = 1e-9
    model.Params.NumericFocus = 3
    model.Params.Method = 1
    if args.log:
        model.Params.LogFile = str(args.log)
    model.optimize()
    if model.SolCount:
        model.write(str(args.output))
    print(
        f"status={model.Status} fixed={fixed} selected={selected} "
        f"solutions={model.SolCount} objective={model.ObjVal if model.SolCount else None}"
    )


if __name__ == "__main__":
    main()
