#!/usr/bin/env python3
"""Inspect the indexed structure of the eva1aprime5x5opt MPS with Gurobi."""

from __future__ import annotations

import argparse
import collections
import math
from pathlib import Path

import gurobipy as gp


def numeric_index(name: str) -> int:
    try:
        return int(name.rsplit("_", 1)[1])
    except (IndexError, ValueError):
        return -1


def runs(values: list[int]) -> list[tuple[int, int]]:
    if not values:
        return []
    result: list[tuple[int, int]] = []
    start = previous = values[0]
    for value in values[1:]:
        if value != previous + 1:
            result.append((start, previous))
            start = value
        previous = value
    result.append((start, previous))
    return result


def fmt_runs(values: list[int]) -> str:
    return ", ".join(str(a) if a == b else f"{a}-{b}" for a, b in runs(values))


def read_solution(path: Path) -> dict[str, float]:
    result: dict[str, float] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        fields = line.split()
        if len(fields) != 2 or fields[0].startswith(("#", "=")):
            continue
        try:
            result[fields[0]] = float(fields[1])
        except ValueError:
            pass
    return result


def row_signature(model: gp.Model, row: gp.Constr) -> tuple:
    expr = model.getRow(row)
    integer = 0
    continuous = 0
    coefficients: list[float] = []
    for k in range(expr.size()):
        variable = expr.getVar(k)
        coefficients.append(abs(expr.getCoeff(k)))
        if variable.VType in (gp.GRB.BINARY, gp.GRB.INTEGER):
            integer += 1
        else:
            continuous += 1
    nonzero = [value for value in coefficients if value]
    log_range = None
    if nonzero:
        log_range = round(math.log10(max(nonzero) / min(nonzero)), 3)
    return row.Sense, continuous, integer, len(coefficients), log_range


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--presolved", type=Path)
    args = parser.parse_args()

    model = gp.read(str(args.mps))
    model.update()
    variables = model.getVars()
    rows = model.getConstrs()
    solution = read_solution(args.solution)

    integer = sorted(
        [numeric_index(v.VarName) for v in variables if v.VType != gp.GRB.CONTINUOUS]
    )
    continuous = sorted(
        [numeric_index(v.VarName) for v in variables if v.VType == gp.GRB.CONTINUOUS]
    )
    print(f"model={model.ModelName}")
    print(f"rows={model.NumConstrs} cols={model.NumVars} nonzeros={model.NumNZs}")
    print(f"continuous_indices={fmt_runs(continuous)}")
    print(f"integer_indices={fmt_runs(integer)}")

    objective = [(v.VarName, v.Obj) for v in variables if v.Obj]
    print(f"objective={objective}")
    selected = sorted(
        numeric_index(v.VarName)
        for v in variables
        if v.VType != gp.GRB.CONTINUOUS and solution.get(v.VarName, 0.0) > 0.5
    )
    print(f"selected_integer_count={len(selected)}")
    print(f"selected_integer_indices={fmt_runs(selected)}")

    degrees: collections.defaultdict[str, list[tuple[int, int]]] = collections.defaultdict(list)
    for variable in variables:
        kind = "I" if variable.VType != gp.GRB.CONTINUOUS else "C"
        degrees[kind].append((numeric_index(variable.VarName), model.getCol(variable).size()))
    for kind in ("C", "I"):
        counts = collections.Counter(degree for _, degree in degrees[kind])
        print(f"{kind}_column_degree_histogram={sorted(counts.items())}")
        print(f"{kind}_column_degrees")
        for index, degree in degrees[kind]:
            print(f"  x_{index} degree={degree} value={solution.get(f'x_{index}', 0.0):.16g}")

    signatures: collections.defaultdict[tuple, list[int]] = collections.defaultdict(list)
    for row in rows:
        signatures[row_signature(model, row)].append(numeric_index(row.ConstrName))
    print("row_signature_runs")
    for signature, indices in sorted(signatures.items(), key=lambda item: item[1][0]):
        print(f"  signature={signature} count={len(indices)} rows={fmt_runs(indices)}")

    if args.presolved:
        presolved = model.presolve()
        presolved.write(str(args.presolved))
        presolved_integer = sorted(
            numeric_index(v.VarName)
            for v in presolved.getVars()
            if v.VType != gp.GRB.CONTINUOUS
        )
        removed_integer = sorted(set(integer) - set(presolved_integer))
        print(
            f"presolved_rows={presolved.NumConstrs} presolved_cols={presolved.NumVars} "
            f"presolved_nonzeros={presolved.NumNZs}"
        )
        print(f"presolved_integer_indices={fmt_runs(presolved_integer)}")
        print(f"removed_integer_indices={fmt_runs(removed_integer)}")


if __name__ == "__main__":
    main()
