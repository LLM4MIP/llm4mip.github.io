#!/usr/bin/env python3
"""Build a strict-improvement Hamming neighborhood around a MIPLIB solution."""

from __future__ import annotations

import argparse
from pathlib import Path

import gurobipy as gp


def read_solution(path: Path) -> dict[str, float]:
    values: dict[str, float] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        fields = line.split()
        if len(fields) != 2 or fields[0].startswith(("#", "=")):
            continue
        try:
            values[fields[0]] = float(fields[1])
        except ValueError:
            pass
    return values


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("radius", type=int)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cutoff", type=float, required=True)
    args = parser.parse_args()

    model = gp.read(str(args.mps))
    values = read_solution(args.solution)
    discrete = [v for v in model.getVars() if v.VType != gp.GRB.CONTINUOUS]
    selected = [v for v in discrete if values.get(v.VarName, 0.0) > 0.5]
    unselected = [v for v in discrete if values.get(v.VarName, 0.0) <= 0.5]

    model.addConstr(
        gp.quicksum(1 - v for v in selected) + gp.quicksum(unselected)
        <= args.radius,
        name="study_hamming_ball",
    )
    model.addConstr(model.getObjective() <= args.cutoff, name="study_strict_improvement")
    for variable in model.getVars():
        if variable.VarName in values:
            variable.Start = values[variable.VarName]
    model.update()
    model.write(str(args.output))
    model.write(str(args.output.with_suffix(".mst")))
    print(
        f"wrote={args.output} radius={args.radius} cutoff={args.cutoff:.17g} "
        f"discrete={len(discrete)} incumbent_ones={len(selected)}"
    )


if __name__ == "__main__":
    main()
