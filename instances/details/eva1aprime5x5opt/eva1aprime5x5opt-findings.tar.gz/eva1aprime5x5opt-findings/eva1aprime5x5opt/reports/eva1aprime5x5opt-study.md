#  `eva1aprime5x5opt` structured solution report

Date of experiment: 2026 -09 -01 (Asia/Shanghai)

## Conclusion

This round has found no credible new global incumbent, MIPLIB official objective
`-17.94807560443689` remains the strict primal bound maintained in this study. The new valid result is the locally optimal sex certificate: yes.
Objective thresholds

```text
-17.94807660443689
```

that is, requiring improvement of at least `1e-6`, Gurobi has proved that within **Hamming radius 8** of the official 400-bit material-selection vector
Infeasible. Finally confirmed to run the `FeasibilityTol=1e-9`, `IntFeasTol=1e-9`,
`NumericFocus=3` and `DualReductions=0`, clearly returned after one node of 492.69 seconds, 71,682
`Model is infeasible`. Radius 10 Search 900 Seconds found no improvement, but no closed tree, so it cannot be extended to proof.

The best global lower bound in the current experiment is COPT's `-458.919072061`, with incumbent
It's a long way off.

##  Model structure

This is a topological optimization problem for the negative heat expansion cycle skeleton. Each candidate can select materials 1, material 2, or
Vacuum; continuous variables describing the state of warming and the locomotion of nodes under normal load, the amplitude voltage and the linearity of the auxiliaries.
The objective `1000*x_1` is the scaling value of the thermal displacement of the interface node, where the negative represents the more obvious thermal contraction.

The original model contains 1,712 variables, 11,929 rows and 57,162 nonzero entries:

|  Composition |  Count |  Explanation |
|---|---:|---|
|  continuous variables |  1,312  | Both states of displacement, internal force and auxiliary force |
| Material 1 is a binary variable |  200  |  `x_1313`--`x_1512`  |
| Material 2 is a binary variable |  200  |  `x_1513`--`x_1712`  |
| Selection of single material constraint |  200  | One material is chosen for each rod. |
| Cross-platform set-packing constraint |  3,424  | Alternative candidate pointers cannot exist simultaneously |
| Differential symmetry equation |  192  | symmetrical location using the same material choice |

The 192 line symmetry equation compresses the 200 root pad into a 104 symmetrical orbit: 96 has a size of 2 and another 8 single-point orbit.
The official design selected 14 roots, in which the material 1 is 6 roots, and the material 2 is 8 roots, all occupying a complete symmetry of 7.
Orbits. Gurobi solves the binary variable 400 down to 152.

##  Strict inspection of official solution

Use the 80 bit decimal to recalculate the original MPS row by row:

```text
objective                         -17.948075604436890000
rows                              11929
row violations above 1e-6        0
maximum exact-decimal residual    8.35124468861839713e-14
bound violations                  0
integrality violations            0
```

Because solution files and MPS coefficients are finite decimal text, row by row complete is not a rational requirement; its maximum
residual is much smaller than the `1e-9` strict tolerance used in this study.

##  Numerical False Improvement and Repair

Gurobi's NoRel heuristic has consistently reported better objectives, which ultimately led to the adoption of a new approach.
`-17.948224788857717`. But it has the same binary option as the official solution 400.
row residual `1.97833395e-7`. This, although less common than `1e-6`, is clearly dependent on feasibility tolerance.

Fixed all binary variables and used `FeasibilityTol=1e-9`, `OptimalityTol=1e-9`,
`NumericFocus=3` Resolve After a continuous LP, the objective returns to `-17.948075604436321`, with the maximum row residual decreasing to
`6.64e-15`. Therefore, the so-called `-17.9482248` is not a new topology, nor is it a strict improvement recognized in this study.

The strict global Gurobi is also available with `-17.948075606331715`, which is only about two yuan smaller than the official `1.9e-9`.
The pattern is still complete; this also belongs to continuous numerical noise and is not released as a new result.

##  Local branch methods

Add local branch inequality to the official binary vector:

```text
sum_{official 1} (1-z_i) + sum_{official 0} z_i <= radius
```

Added explicit objective to intercept `objective <= -17.94807660443689`.
It is also explicitly recommended to use local MILP searches. The radius here is calculated by the original material bit; as a result of the symmetry equation, a
A complete symmetrical shift of a rod usually consumes two bits.

| Bit radius | The results of Gurobi |  Time |  Nodes |
|---:|---|---:|---:|
|  2  | Closed trees, no improvements |  7.54 s  |  109  |
|  4  | Closed trees, no improvements |  20.96 s  |  1,205  |
|  6  | Closed trees, no improvements |  112.86 s  |  12,524  |
| 8 | **INFEASIBLE**，`DualReductions=0` | 492.69 s | 71,682 |
|  10  | No solution found, deadline reached |  900 s  |  69,002  |

The radius of 10 is ultimately best bound to `-26.1690925895`, still below objective intercept, so there is no proof infeasible.

##  Global solver baseline

|  solver |  Settings |  result |
|---|---|---|
|  Gurobi 13.0.1  | 32 thread, strict tolerance, NoRel 600 s, total time limit of 900 s | Official Topography: bound to `-497.110592744` |
|  COPT 8.0.4  | 32 thread, `HeurLevel=3` , 900 s | This is the official solution for `-458.919072061` |

Both global root relaxations are very weak. The difficulties are mainly due to the 200 root pivot triode selection, 3,424 for cross-conflict and mechanics.
the coupling between equilibrium and stress conditions, rather than the continuous LP itself: once the binary topology is fixed, the continuous problem takes less than one second
That's the solution.

COPT uses only the CPU on `altman`, while **does not use GPU0**.

## Next step

1.  Defining neighborhoods for a symmetrical orbit of 104 instead of an original bit of 400 to avoid the radius budget being used by symmetrical replication;
2.  The tree with radius 10 splits and preserves the file of the node, continuing closure of the neighborhood;
3.  From LP dual, information is filtered for the most sensitive of the objective's vacuum pads, constructing oriented add/drop/material-swap.
neighborhood;
4.  Using logic Benders: main problem selecting material topology, fixed topology continuous mechanics LP yielding feasibility / optimality
   cuts；
5.  On any new numerical incumbent, the first fixed binary topology is strictly re-optimized to avoid re-establishing feasibility tolerance as
It's really getting better.

## material

-  [MIPLIB `eva1aprime5x5opt` page ](https://miplib.zib.de/instance_details_eva1aprime5x5opt.html)]
-  [Hirota Kanno technical report full text ](https://www.keisu.t.u-tokyo.ac.jp/data/2014/METR14-02.pdf)]
-  [document from DOI ](https://doi.org/10.1007/s11081-015-9276-z)]
