# Package manifest: eva1aprime5x5opt

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 26
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/discrete-structure-summary.txt`
- `artifacts/eva1aprime5x5opt_presolved.lp`
- `artifacts/exact-check-summary.txt`
- `artifacts/structure-analysis.txt`
- `logs/copt_baseline_15m.log`
- `logs/gurobi_baseline_15m.log`
- `logs/gurobi_lb10_strict_15m.log`
- `logs/gurobi_lb2_strict_5m.log`
- `logs/gurobi_lb4_strict_5m.log`
- `logs/gurobi_lb6_strict_5m.log`
- `logs/gurobi_lb8_explicit_infeasible_10m.log`
- `logs/gurobi_lb8_strict_10m.log`
- `logs/gurobi_repair_strict.log`
- `logs/gurobi_strict_global_15m.log`
- `reports/eva1aprime5x5opt-study.md`
- `scripts/analyze_discrete_structure.py`
- `scripts/analyze_gurobi_structure.py`
- `scripts/fix_and_reoptimize.py`
- `scripts/make_local_branch_model.py`
- `solutions/copt_baseline.sol`
- `solutions/gurobi-default-tolerance.sol`
- `solutions/gurobi-repaired-strict.sol`
- `solutions/gurobi_strict_global.sol`
- `solutions/official-best.sol`
- `solutions/official-best.sol.gz`

## Excluded files

- `input/eva1aprime5x5opt.mps.gz (326307 bytes; raw benchmark input; sha256 20eb8329ba8f417f782a89a22b1d1cfb9f6064536a5e16887879f5f90b224af4)`
