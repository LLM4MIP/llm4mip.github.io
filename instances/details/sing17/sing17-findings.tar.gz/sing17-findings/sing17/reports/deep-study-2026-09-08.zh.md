# `sing17` research summary — 2026-09-08

## Bottom line

`sing17` remains open. We did not prove global optimality and did not find a new integer pattern. The only primal change is numerical polishing: fixing the official 432,541-variable integer pattern and reoptimizing all 20,246 continuous variables lowered the objective from the official declared `36,161,699.378832512` to a strictly audited `36,161,699.3779386893546367410`, an improvement of `0.000893822645363259` (relative `2.47e-11`). This must not be presented as a structural breakthrough.

The strongest newly reproducible global lower bound is `35,556,219.47983733`, obtained after 2,400 seconds of aggressive root cutting. Against the strict polished primal, the remaining absolute gap is `605,479.89810136`, or `1.6743679%`. An older COPT 10-hour PDF-only number, `35,599,182.4`, is stronger, but this batch does not contain its raw log or an exact certificate; it is a comparison baseline, not a new result.

## What was tested

- Official model: 452,787 variables, including 432,541 integer and 20,246 continuous variables; 266,802 rows and 1,205,830 nonzeros.
- Official decomposition: 50 blocks and 672 master rows. There are 42,224 variables touching master rows, including 336 master-only variables.
- LP relaxation: `35,483,848.8765138`, leaving a `1.8744985%` gap. Only 4,540 integer variables are fractional. They are entirely concentrated in blocks 15 (3,273), 16 (919), 20 (174), 9 (140), 10 (32), and 50 (2).
- Complete MIP start: every omitted sparse-solution variable was explicitly set to zero; no variable name was missing and no integer value needed rounding.
- Deep bound run: Gurobi 13.0.2, 2,400 seconds, four threads, `MIPFocus=3`, aggressive cuts, symmetry handling, no heuristics. It remained at the root and generated 1,931 MIR, 44 flow-cover, five Gomory, four lift-and-project, and two GUB-cover cuts.

## Neighborhood results

All 50 official decomposition blocks were rerun uniformly with both `MIPGap=0` and `MIPGapAbs=0`. Every block returned Gurobi status `OPTIMAL`, the largest reported gap was only `1.69e-14`, and no block produced a discrete or objective improvement. The uniform verification used 77.038 additive solver seconds and 88.136 script-wall seconds. We can therefore state that all 50/50 one-block neighborhoods were closed computationally at zero configured gap, while still noting that this is floating-point solver evidence rather than an exact certificate.

Eleven multi-block neighborhoods were also tested. Nine returned Gurobi status `OPTIMAL` under their run tolerance and two reached the time limit. Eight of the nine completed groups had a reported gap below `1e-14`; group `(9,10)` stopped at `9.82e-5` under the default tolerance.

- Historical coupling `(2,3,15,16)` closed after 1,316 nodes and 165.917 seconds, with no improvement.
- Historical coupling `(2,3,15,16,17,22)` timed out after 300.077 seconds and 1,070 nodes, with a conditional neighborhood gap of `0.056326%` and no improvement.
- Fractional core `(15,16,20)` closed after 2,658 nodes and 122.803 seconds, with no improvement.
- All fractional blocks `(9,10,15,16,20,50)` timed out after 600.057 seconds and 627 nodes, with a conditional neighborhood gap of `0.671763%` and no improvement.

Neighborhood bounds are conditional on fixing every variable outside the released blocks. They are not global lower bounds for the original problem.

## Evidence and reproducibility

- Strict fixed-pattern primal audit: [`artifacts/sing17-public-fixed-lp-repair.json`](../artifacts/sing17-public-fixed-lp-repair.json)
- Strict polished solution: [`solutions/sing17-strict-polished.sol`](../solutions/sing17-strict-polished.sol)
- Deep global bound run: [`artifacts/sing17-deep-cuts-sym.json`](../artifacts/sing17-deep-cuts-sym.json) and [`logs/sing17-deep-cuts-sym.log`](../logs/sing17-deep-cuts-sym.log)
- LP block diagnosis: [`artifacts/sing17-lp-block-diagnostics.json`](../artifacts/sing17-lp-block-diagnostics.json)
- Uniform 50/50 zero-gap one-block verification: [`artifacts/sing17-block-lns-all50-gap0.json`](../artifacts/sing17-block-lns-all50-gap0.json)
- Earlier exploratory one-block runs were superseded by the uniform verification and intentionally omitted from the curated GitHub package.
- Multi-block tests: [`artifacts/sing17-group-lns-repeated.json`](../artifacts/sing17-group-lns-repeated.json), [`artifacts/sing17-group-lns-historical-coupled.json`](../artifacts/sing17-group-lns-historical-coupled.json), and [`artifacts/sing17-group-lns-fractional-blocks.json`](../artifacts/sing17-group-lns-fractional-blocks.json)
- Machine-readable synthesis: [`artifacts/sing17-final-summary-20260908.json`](../artifacts/sing17-final-summary-20260908.json)

Including the new uniform 50-block verification, the primary recorded experiment set accounts for 115 solver calls, 3,893.297 additive solver seconds, and 3,997.907 additive script-wall seconds. Including all preliminary duplicate probes gives 125 calls, 3,927.159 additive solver seconds, and 4,067.422 additive script-wall seconds. Some jobs ran concurrently, so these additive totals are compute accounting rather than elapsed campaign clock time.

## Interpretation

The incumbent is robust to all tested one-block moves and to several historically and LP-motivated coupled moves. The difficult part is not locating a small local correction: it is coordinating a large set of blocks through 672 master constraints. The LP diagnosis reinforces this point—fractionality is sparse in variable count but highly concentrated in a few large, coupled blocks. Standard root cutting improves the bound materially (`+72,370.60` over the plain LP) but still does not match the older 10-hour COPT numerical baseline and remains far from proving optimality.
