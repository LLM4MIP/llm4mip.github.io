# `sing17` — numerical primal polish and block diagnosis (2026-09-08)

Official MIPLIB page: <https://miplib.zib.de/instance_details_sing17.html>

## Result

`sing17` remains **globally open**. Fixing the public integer pattern and
reoptimizing the continuous variables yields a strictly feasible objective
slightly below the MIPLIB headline, but the difference is only numerical-scale
polishing. No discrete incumbent improvement or global proof was found.

| Quantity | Value | Evidence boundary |
|---|---:|---|
| Strict polished upper bound | **36,161,699.3779386893546367410** | Original-MPS Decimal audit; maximum row violation `3.70e-13` |
| MIPLIB headline | **36,161,699.378832512** | Same integer pattern |
| Numerical decrease | **0.000893822645363259** | Relative change about `2.47e-11`; not a structural primal result |
| Locally reproducible lower bound | **35,556,219.47983733** | Gurobi 13.0.2 root cuts/symmetry, 2,400 s, four threads, one node |
| Reproducible relative gap | **1.6743679%** | `(UB-LB)/abs(UB)` |
| Archived COPT 10-hour lower bound | **35,599,182.4** | Stronger PDF-only value; no matching raw log or exact certificate |

The strict sparse witness is
[`solutions/sing17-strict-polished.sol`](solutions/sing17-strict-polished.sol),
and its audit is
[`sing17-public-fixed-lp-repair.json`](artifacts/sing17-public-fixed-lp-repair.json).
All 432,541 integer variables are unchanged; only 20,246 continuous variables
were reoptimized. A second read of the exact file published here is archived as
[`published-solution-replay.json`](artifacts/published-solution-replay.json).

## Structure and fractional core

The original model has 452,787 variables, 266,802 rows, and 1,205,830
nonzeros. The official decomposition has 50 blocks and 672 master rows, of
which 336 are hourly demand equations and 336 are reserve inequalities for a
two-week, 336-hour horizon.

At the LP relaxation only 4,540 of 432,541 integer variables are fractional.
They are concentrated in blocks 15 (3,273), 16 (919), 20 (174), 9 (140), 10
(32), and 50 (2). The counts and row/block diagnostics are archived in
[`sing17-lp-block-diagnostics.json`](artifacts/sing17-lp-block-diagnostics.json).

## Full-MIP and conditional LNS evidence

The 2,400-second aggressive root run reached `35,556,219.47983733` after about
302,273 simplex iterations. It found no new incumbent. See the
[result JSON](artifacts/sing17-deep-cuts-sym.json) and
[raw log](logs/sing17-deep-cuts-sym.log). This is a valid numerical global
solver bound, not a portable rational certificate; the archived COPT PDF value
above is stronger but cannot be replayed from this repository.

Every official block was then rerun under a uniform zero-gap configuration:

- **50/50** single-block subproblems returned `OPTIMAL`;
- `MIPGap=0`, `MIPGapAbs=0`, and the maximum recorded solver gap was
  `1.69e-14`;
- none improved the incumbent.

No targeted multi-block test beat the final strict-polished upper bound. An
early `(9,10)` pilot improved its less accurate rounded start by only
`1.445e-6`, but its resulting objective was still worse than the final strict
witness; it used the solver's default nonzero gap tolerance and is not counted
as a zero-gap closure. In the later targeted runs,
`(15,16,20)` closed to zero conditional gap, as did `(2,3,15,16)`. The larger
historical group `(2,3,15,16,17,22)` stopped after 300 seconds with a 0.0563%
conditional gap, while all six fractional blocks `(9,10,15,16,20,50)` stopped
after 600 seconds with a 0.6718% conditional gap.

The summaries are
[`sing17-block-lns-all50-gap0.json`](artifacts/sing17-block-lns-all50-gap0.json),
[`sing17-group-lns-repeated.json`](artifacts/sing17-group-lns-repeated.json),
[`sing17-group-lns-historical-coupled.json`](artifacts/sing17-group-lns-historical-coupled.json),
and [`sing17-group-lns-fractional-blocks.json`](artifacts/sing17-group-lns-fractional-blocks.json).
Raw subproblem logs are under [`logs/`](logs/). Some early multi-block log files
contain only Gurobi's logger-initialization header; the complete parameters and
numerical outcomes for those runs are preserved in the JSON summaries above.

All of these LNS statements are conditional on fixing the complement of the
released blocks. A zero conditional gap is not a global lower bound for the
original `sing17` model.

## Reproduction

Download the official MPS as described in [`input/README.md`](input/README.md),
then run from this directory with Gurobi 13.x.

Recreate the continuous-variable polish:

```powershell
python scripts/repair_fixed_integer_solution.py `
  --mps input/sing17.mps.gz --solution input/sing17-public.sol.gz `
  --output-json replay/fixed-lp-repair.json `
  --output-sparse-sol replay/strict-polished.sol `
  --output-full-sol replay/strict-polished-full.sol `
  --log replay/fixed-lp-repair.log --time-limit 300 --threads 2
```

Recreate the deep root-bound configuration:

```powershell
python scripts/sing17_experiment.py `
  --mps input/sing17.mps.gz --solution solutions/sing17-strict-polished.sol `
  --output replay/deep-cuts-sym.json --log replay/deep-cuts-sym.log `
  --time-limit 2400 --threads 4 --seed 1701 --mip-focus 3 `
  --cuts 3 --symmetry 2 --heuristics 0 --presolve 2 --node-limit 1
```

Input hashes are in [`input/SHA256SUMS`](input/SHA256SUMS). The detailed study
is in [`reports/deep-study-2026-09-08.zh.md`](reports/deep-study-2026-09-08.zh.md),
and the cross-instance interpretation is in the
[`sing` family report](../../docs/sing-family-2026-09-08.zh.md).

## Scope of the conclusion

The same integer schedule has merely been completed more accurately in the
continuous variables, and the reproducible numerical gap remains 1.6744%.
Therefore this package records **no meaningful primal improvement and no
global optimality proof**; `sing17` is still open.
