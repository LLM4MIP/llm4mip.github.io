#  `sorrell7` Structural analysis and solve experiments

## Conclusion

The official objective `-198` has been checked and restored by the independent set on the chart through the decimal row by row inspection of the original MPS.
Both are zero default. There is no 199 score code found this time, nor is there any proof of 198 globally optimal.
The strict scope is

```text
198 <= alpha(G) <= 210, equivalent to -210 <= OPT_MPS <= -198.
```

210 comes from the coding theory primal bound of the OEIS records, not the bound of the repository's new proof.
The best global primal bound for solver is Gurobi's compact model 216.

The main result was a strong local certificate: any 199 dot solution retains at least one 185 dot in the official solution.
This means that at least one of the official 13 points must be removed, at least one new point added to 14, with the official binary vector.
Hamming distance is at least 27. This conclusion is given by COPT's radius 12 infeasible proof, which is smaller.
Radius 4, 6, 8 are also cross verified independently by Gurobi and COPT.

##  Real problems recovered from MPS

`2048=2^11` A variable that corresponds to all 11 bit binary strings by number. 78,848 bar constraint are two variables.
Conflict side, and repeat twice in MPS on each side; only the 39,424 side is reversed.
If and only if:

1.  Hamming distance is 1; or
2.  The Hamming distance is 2, and the two strings have the same weight.

Therefore, the instance is a single non-symmetric error Z-channel length 11 conflict graph `1zc.2048`.
Equivalent to a binary error-correcting code with asymmetric distance 2. A vertex of weight `w` has degree
`11+w(11-w)`; all 2,048 peaks belong to the same connected fraction.

##  A compact model

Each binary string `y` with its entire superset is a clique; `y` with its entire subset is also a clique.
The clique constraint 4,096 is used to exactly replace the 78,848 repeating lateral constraint.
Add the valid primal bound of the 4 code by weight to the constant weight distance.

```text
(1, 1, 5, 17, 35, 66, 66, 35, 17, 5, 1, 1)。
```

These boundaries can be introduced by subset counting strictly. At weight 3, oddity reduces the plain boundary 18 to 17;
When weighing 4, give the number of times a coordinate link, 10, is packed into a triangular group.
`4*A_4 <= 11*13`, so `A_4<=35`; the remaining half is obtained by complementary mapping symmetry.

The compact LP is 233.333333, better than the original model root LP, 238.72955, and better than the challenging web page record.
Historical Lovasz theta value 237.4. Gurobi's cutting plane further compresses the global boundary of the 600 second to 216.

##  Structure and exact inspection of 198 solution

The number of points selected for each weight level is:

```text
weight  : 0  1  2  3  4  5  6  7  8  9 10 11
selected: 1  0  5 15 31 47 47 31 15  5  0  1
```

Public exact checker for 78,848 lines, boundaries and integrality all report zero default.
Confirm that no two ends of the 39,424 line have been selected at the same time. Each unselected point is in conflict with a pre-selected point from 1 to 6,
So the solution is at least inclusion-maximal.
`{1:2, 2:107, 3:407, 4:629, 5:549, 6:156}`。

Exact enumeration excluded all improving exchanges deleting at most 3 points. Two 45-second destroy/repair
ILS ((seed 7 and 198) together complete the 48,303 second generation, preferably remaining 198; both output solutions are again
Passed the zero-tolerance check against the original MPS.

##  Solver experiments

|  Experiment |  result |
|---|---|
| Original MPS, Gurobi 13.0.1, 64 thread, 180 second |  `-198` ,  lower bound `-221` |
| Original MPS, COPT 8.0.4, 64 thread, 180 second |  `-198` ,  original lower bound `-232.650724638` |
| 64 thread, 600 second | 198 , primal bound 216 , 4,602 nodes |
| Compact model, COPT, 64 thread, 600 second |  198 ,  primal bound 233.333333332 |
| Objective 199, maximum deleted from 4 | Gurobi 0.39 second, COPT 1.51 second equals infeasible |
| Objective 199, maximum deleted from 6 | Gurobi 92.25 second, COPT 109.76 second equals infeasible |
| Objective 199, maximum deleted from 8 | Gurobi 238.39 second, COPT 110.92 second equals infeasible |
| Objective 199, maximum deleted from 10 | COPT 128.47 second confirmed infeasible; Gurobi 300 second not closed |
| Objective 199, maximum deleted from 12 | COPT 222.36 seconds, 3,924 node proof of infeasible |

All of the COPT experiments on Altman were CPU-only, with **not using GPU0**.
License numbers and private installation paths have been cleared.

##  The next step is to find the best 199 or proof 198.

The radius-12 certificate shows that small exchanges cannot help. Searching for a better code should destroy at least 13
official points, then use MIP/CP-SAT exact repair, and specify the search results with coordinate replacement and complementary mapping
Weighing local search using the earlier MIPLIB solution can be replicated and the exact local search can be performed.
The model is used as a large neighborhood repair machine.

In terms of global proof, the public primal bound 210 is still stronger than Gurobi's 216.
SDP boundaries, compression orbits and symmetrical branch-and-bound of the Z-channel association scheme,
This is not a mere extension of the time of repetition of MIP.

##  Information and reproduction

-  [MIPLIB `sorrell7` page ](https://miplib.zib.de/instance_details_sorrell7.html)]
- [OEIS A010101](https://oeis.org/A010101)
-  [Sloane independent set challenge page ](https://oeis.org/A265032/a265032.html)]
-  Structure and solution check:[ `../scripts/analyze_graph.py` ](../scripts/analyze_graph.py)
-  Compact/local model generated:[ `../scripts/make_compact_model.py` ](../scripts/make_compact_model.py)
-  Exact small exchange with ILS:[ `../scripts/exchange_and_ils.py` ](../scripts/exchange_and_ils.py)
-  The data is compiled by:[ `../artifacts/solver-summary.json` ](../artifacts/solver-summary.json)
