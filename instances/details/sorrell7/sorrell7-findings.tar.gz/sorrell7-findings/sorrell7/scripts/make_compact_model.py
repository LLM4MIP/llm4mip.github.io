#!/usr/bin/env python3
"""Write an exact compact model for the ``sorrell7`` independent-set graph.

Every binary word ``y`` defines two valid cliques: ``y`` together with all
one-bit supersets, and ``y`` together with all one-bit subsets.  These 4096
clique inequalities replace the 78,848 duplicated edge rows in the MPS.  The
model also includes rigorously derived constant-weight packing caps.
"""

from __future__ import annotations

import argparse
import gzip
from decimal import Decimal
from pathlib import Path


BITS = 11
N = 1 << BITS

# Exact/elementary upper bounds for constant-weight distance-four codes.
# For weights 3 and 8, parity improves the pair-counting cap from 18 to 17.
# For weights 4 and 7, linking at a coordinate and applying the degree bound
# for triple packings on 10 points gives 4*A_4 <= 11*13, hence A_4 <= 35.
WEIGHT_CAPS = (1, 1, 5, 17, 35, 66, 66, 35, 17, 5, 1, 1)


def open_text(path: Path, encoding: str = "utf-8"):
    if path.suffix.lower() == ".gz":
        return gzip.open(path, "rt", encoding=encoding)
    return path.open("r", encoding=encoding)


def read_selected(path: Path) -> set[int]:
    selected: set[int] = set()
    with open_text(path) as handle:
        for raw in handle:
            line = raw.strip()
            if not line or line.startswith("#") or line.startswith("=obj="):
                continue
            tokens = line.split()
            if len(tokens) != 2 or not tokens[0].startswith("x_"):
                continue
            if Decimal(tokens[1]) == 1:
                selected.add(int(tokens[0].split("_", 1)[1]) - 1)
    return selected


def variable(word: int) -> str:
    return f"x_{word + 1}"


def write_sum(handle, words) -> None:
    for index, word in enumerate(words):
        if index and index % 16 == 0:
            handle.write("\n  ")
        handle.write((" + " if index else " ") + variable(word))


def write_lp(
    path: Path,
    target: int | None,
    symmetry_breaking: bool,
    local_selected: set[int] | None,
    max_removed: int | None,
) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write("\\ Exact compact Z-channel-code formulation of sorrell7\n")
        handle.write("Maximize\n independent_set:")
        write_sum(handle, range(N))
        handle.write("\nSubject To\n")

        for word in range(N):
            supersets = [word] + [
                word | (1 << bit) for bit in range(BITS) if not word & (1 << bit)
            ]
            handle.write(f" up_{word}:")
            write_sum(handle, supersets)
            handle.write(" <= 1\n")

            subsets = [word] + [
                word & ~(1 << bit) for bit in range(BITS) if word & (1 << bit)
            ]
            handle.write(f" down_{word}:")
            write_sum(handle, subsets)
            handle.write(" <= 1\n")

        for weight, cap in enumerate(WEIGHT_CAPS):
            words = [word for word in range(N) if word.bit_count() == weight]
            handle.write(f" weight_cap_{weight}:")
            write_sum(handle, words)
            handle.write(f" <= {cap}\n")

        if target is not None:
            handle.write(" target:")
            write_sum(handle, range(N))
            handle.write(f" >= {target}\n")

        if max_removed is not None:
            assert local_selected is not None
            handle.write(" local_removals:")
            write_sum(handle, sorted(local_selected))
            handle.write(f" >= {len(local_selected) - max_removed}\n")

        if symmetry_breaking:
            # Complementation lets us assume x_0 >= x_(2^11-1).
            handle.write(f" complement_order: {variable(0)} - {variable(N - 1)} >= 0\n")
            # If a singleton is selected, coordinate permutation lets us use bit 0.
            for bit in range(1, BITS):
                handle.write(
                    f" singleton_order_{bit}: {variable(1)} - {variable(1 << bit)} >= 0\n"
                )

        handle.write("Binaries\n")
        for start in range(0, N, 16):
            handle.write(" " + " ".join(variable(word) for word in range(start, start + 16)) + "\n")
        handle.write("End\n")


def write_mst(path: Path, selected: set[int]) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write("# MIP start for the compact sorrell7 model\n")
        for word in range(N):
            handle.write(f"{variable(word)} {int(word in selected)}\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lp", required=True, type=Path)
    parser.add_argument("--solution", type=Path)
    parser.add_argument("--mst", type=Path)
    parser.add_argument("--target", type=int)
    parser.add_argument(
        "--max-removed",
        type=int,
        help="restrict the target search to this many removals from --solution",
    )
    parser.add_argument("--no-symmetry-breaking", action="store_true")
    args = parser.parse_args()

    selected = read_selected(args.solution) if args.solution else set()
    if args.max_removed is not None and not selected:
        parser.error("--max-removed requires a nonempty --solution")
    args.lp.parent.mkdir(parents=True, exist_ok=True)
    # A fixed incumbent neighborhood is not invariant under the global graph
    # symmetries, so global symmetry breaking must never be added to a local
    # model.  It remains safe for the unrestricted global formulation.
    symmetry_breaking = not args.no_symmetry_breaking and args.max_removed is None
    write_lp(
        args.lp,
        args.target,
        symmetry_breaking,
        selected if args.max_removed is not None else None,
        args.max_removed,
    )
    if args.mst:
        args.mst.parent.mkdir(parents=True, exist_ok=True)
        write_mst(args.mst, selected)
    print(
        f"wrote {args.lp}: variables={N}, clique_rows={2*N}, "
        f"weight_caps={WEIGHT_CAPS}, target={args.target}, "
        f"max_removed={args.max_removed}, start_size={len(selected)}, "
        f"symmetry_breaking={symmetry_breaking}"
    )


if __name__ == "__main__":
    main()
