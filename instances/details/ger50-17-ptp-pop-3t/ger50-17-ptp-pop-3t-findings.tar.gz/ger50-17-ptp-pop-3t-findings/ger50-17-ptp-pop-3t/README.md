# `ger50-17-ptp-pop-3t` — strict incumbent; numerical anomaly; optimum open

Official MIPLIB page: <https://miplib.zib.de/instance_details_ger50-17-ptp-pop-3t.html>

## Result

The instance remains **globally open**. The imported material establishes a
strict feasible upper bound and a useful numerical lower bound, but it does
not contain a trustworthy matching bound or a portable optimality
certificate.

| quantity | value | evidence |
|---|---:|---|
| strict feasible upper bound | **`5224.5144`** | solver-independent exact-decimal replay; zero row, bound and integrality violation |
| local numerical lower bound | **`5183.93592586653`** | Gurobi 12.0.3, 60 s, one thread, on an exactly equivalent flow-scaled model |
| numerical gap | `0.7767%` | time-limit result |
| global optimum | unknown | no independently checkable proof of the lower bound |

The feasible vector is
[`strict-5224.5144.sol`](solutions/strict-5224.5144.sol). The original MPS is
not stored here; see [`input/README.md`](input/README.md) for its official
MIPLIB link and hash.

## What was verified

The model has 4,892 variables and 545 rows. Its main structure is a
16-commodity network design: 4,352 continuous directed-flow variables share
136 physical links, while 540 general-integer design variables install link
equipment and channels.

The raw displayed MIPLIB solution has a small continuous-flow residual at a
`1e-9` feasibility tolerance. Fixing only its 540 integer design values and
reoptimizing the continuous flow subproblem produces the same objective,
`5224.5144`. Independent finite-decimal replay of the repaired displayed
vector then reports exactly zero violation in every original row, bound and
integrality condition.

The [structural audit](structural/README.md) also records several exact facts:

- one zero-capacity link and 16 redundant balance rows can be removed;
- changing flow units by `g=f/1000` is a bijective reformulation and improves
  the matrix range from `[1,32000]` to `[1,40]`; and
- every feasible objective lies on the lattice `0.0002 Z`, so proving the
  strict cutoff `cost <= 5224.5142` infeasible would prove optimality of the
  incumbent.

The generators for the scaled and cutoff models are retained, but the
generated MPS files are intentionally not committed.

## Why the zero-gap runs are rejected

Two Gurobi 13.0.2 runs printed zero gap at `5224.5144`. They are **not** used
as optimality evidence: the same executable and strict settings also rejected
the rounded official start and then declared `7577.089` optimal, even though
the independently checked `5224.5144` vector is feasible for the same model.
That contradiction demonstrates an incumbent-dependent numerical failure.

For this reason, the retained
[`scaled-gurobi12-60s.log`](logs/scaled-gurobi12-60s.log) is treated only as
numerical branch-and-bound evidence, and
[`rejected-gurobi13-counterexample.log`](logs/rejected-gurobi13-counterexample.log)
documents why the apparently stronger zero-gap output cannot be accepted.
