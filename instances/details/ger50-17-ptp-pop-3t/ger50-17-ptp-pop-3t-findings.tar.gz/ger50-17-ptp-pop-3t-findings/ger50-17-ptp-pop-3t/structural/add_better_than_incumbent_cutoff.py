#!/usr/bin/env python3
"""Add an exact better-than-incumbent feasibility cutoff to the MPS.

All objective-bearing variables in this instance are integer.  Multiplying
their finite-decimal costs by 10,000 gives integers with gcd 2, so every
objective value lies on the lattice 0.0002 Z.  Therefore a design is strictly
better than 5224.5144 iff it satisfies cost <= 5224.5142.

The generated model also gives every integer variable its implied individual
upper bound floor(cutoff / positive_cost).  These bounds do not remove any
point satisfying the added cutoff.
"""

from decimal import Decimal, getcontext
from pathlib import Path
import sys


getcontext().prec = 60
CUTOFF = Decimal("5224.5142")
CUTOFF_ROW = "better_5224_5144"


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: add_better_than_incumbent_cutoff.py SOURCE.mps TARGET.mps")
    source, target = map(Path, sys.argv[1:])
    section = None
    objective_coefficients = {}
    cutoff_entries = 0
    row_written = False
    rhs_written = False
    bounds_written = False

    with source.open("r", encoding="utf-8") as input_file, target.open("w", encoding="utf-8") as output_file:
        for raw in input_file:
            stripped = raw.strip()
            if stripped == "COLUMNS" and not row_written:
                output_file.write(f" L  {CUTOFF_ROW}\n")
                row_written = True
            if stripped == "BOUNDS" and not rhs_written:
                output_file.write(f"    rhs  {CUTOFF_ROW}  {CUTOFF}\n")
                rhs_written = True
            if stripped == "ENDATA" and not bounds_written:
                for variable, coefficient in objective_coefficients.items():
                    upper_bound = int(CUTOFF // coefficient)
                    output_file.write(f" UI bnd  {variable}  {upper_bound}\n")
                bounds_written = True

            output_file.write(raw)

            if stripped in {"ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = stripped
                continue
            if section == "COLUMNS":
                parts = stripped.split()
                if len(parts) >= 3 and parts[1].strip("'") != "MARKER":
                    for index in range(1, len(parts), 2):
                        if parts[index] == "cost":
                            coefficient = Decimal(parts[index + 1])
                            if coefficient <= 0:
                                raise ValueError(f"Nonpositive objective coefficient for {parts[0]}")
                            objective_coefficients[parts[0]] = coefficient
                            output_file.write(f"    {parts[0]}  {CUTOFF_ROW}  {parts[index + 1]}\n")
                            cutoff_entries += 1

    if not (row_written and rhs_written and bounds_written):
        raise RuntimeError("Could not locate all MPS insertion points")
    print(f"cutoff={CUTOFF}")
    print(f"cutoff_coefficients={cutoff_entries}")
    print(f"implied_integer_upper_bounds={len(objective_coefficients)}")


if __name__ == "__main__":
    main()
