#!/usr/bin/env python3
"""Create an exactly equivalent flow-scaled MPS and transformed solution.

The new variables retain the original flow names but have value
``f_scaled = f_original / 1000``.  Consequently, node-balance right-hand
sides and the design coefficients in capacity rows are divided by 1000.
No integer coefficient, objective coefficient, bound, or feasible design is
changed.
"""

from decimal import Decimal, getcontext
import gzip
from pathlib import Path
import sys
from typing import Optional


getcontext().prec = 60
SCALE = Decimal(1000)


def decimal_text(value: Decimal) -> str:
    text = format(value, "f")
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return text if text not in {"", "-0"} else "0"


def transformed_mps_line(section: Optional[str], raw: str):
    parts = raw.split()
    if not parts or raw.lstrip().startswith("*"):
        return raw, 0, 0
    if section == "COLUMNS" and len(parts) >= 3 and parts[1].strip("'") != "MARKER":
        changed = 0
        for index in range(1, len(parts), 2):
            row = parts[index]
            if parts[0].startswith("x$") and row.startswith("link_capacit"):
                parts[index + 1] = decimal_text(Decimal(parts[index + 1]) / SCALE)
                changed += 1
        if changed:
            return "    " + "  ".join(parts) + "\n", changed, 0
    elif section == "RHS" and len(parts) >= 3:
        changed = 0
        for index in range(1, len(parts), 2):
            if parts[index].startswith("demand_"):
                parts[index + 1] = decimal_text(Decimal(parts[index + 1]) / SCALE)
                changed += 1
        if changed:
            return "    " + "  ".join(parts) + "\n", 0, changed
    return raw, 0, 0


def make_mps(source: Path, target: Path):
    section = None
    capacity_changes = 0
    rhs_changes = 0
    opener = gzip.open if source.suffix == ".gz" else open
    with opener(source, "rt", encoding="utf-8") as input_file, target.open("w", encoding="utf-8") as output_file:
        for raw in input_file:
            stripped = raw.strip()
            if stripped in {"ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = stripped
            line, changed_capacity, changed_rhs = transformed_mps_line(section, raw)
            output_file.write(line)
            capacity_changes += changed_capacity
            rhs_changes += changed_rhs
    return capacity_changes, rhs_changes


def make_solution(source: Path, target: Path):
    changed = 0
    opener = gzip.open if source.suffix == ".gz" else open
    with opener(source, "rt", encoding="utf-8") as input_file, target.open("w", encoding="utf-8") as output_file:
        for raw in input_file:
            stripped = raw.strip()
            if stripped and not stripped.startswith("#") and not stripped.startswith("=obj="):
                parts = stripped.split()
                if parts[0].startswith("f_"):
                    parts[1] = decimal_text(Decimal(parts[1]) / SCALE)
                    raw = f"{parts[0]} {parts[1]}\n"
                    changed += 1
            output_file.write(raw)
    return changed


def main():
    if len(sys.argv) != 5:
        raise SystemExit("usage: make_flow_scaled_model.py SOURCE.mps.gz TARGET.mps SOURCE.sol TARGET.sol")
    source_mps, target_mps, source_sol, target_sol = map(Path, sys.argv[1:])
    target_mps.parent.mkdir(parents=True, exist_ok=True)
    target_sol.parent.mkdir(parents=True, exist_ok=True)
    capacity_changes, rhs_changes = make_mps(source_mps, target_mps)
    flow_changes = make_solution(source_sol, target_sol)
    print(f"scaled_capacity_coefficients={capacity_changes}")
    print(f"scaled_nonzero_demand_rhs_entries={rhs_changes}")
    print(f"scaled_solution_flow_values={flow_changes}")
    if capacity_changes != 405:
        raise SystemExit(f"expected 405 capacity design coefficients, got {capacity_changes}")
    if flow_changes != 4352:
        raise SystemExit(f"expected 4352 displayed flow values, got {flow_changes}")


if __name__ == "__main__":
    main()
