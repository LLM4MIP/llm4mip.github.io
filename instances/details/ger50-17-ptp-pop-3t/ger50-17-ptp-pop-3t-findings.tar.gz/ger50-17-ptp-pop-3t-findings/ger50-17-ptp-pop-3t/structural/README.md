# Structural audit of `ger50-17-ptp-pop-3t`

Audit date: 2026-09-08.

## Conclusion

The official incumbent `5224.5144` has a clean, exactly displayed feasible
representative, but this audit does **not** call the instance solved.  Gurobi
13.0.2 twice returned a zero-gap `OPTIMAL` status after receiving the repaired
start, yet a different Gurobi 13.0.2 search path also returned a demonstrably
false `OPTIMAL` status of `7577.089`.  The latter is contradicted by the
feasible `5224.5144` vector.  The zero-gap runs are therefore floating-point
evidence, not a trustworthy lower-bound certificate.

MIPLIB also continues to list the instance as open:
https://miplib.zib.de/instance_details_ger50-17-ptp-pop-3t.html

## Exact model structure

The 4,892 variables split as follows.

- There are 16 commodities, 17 node-balance rows per commodity, 136
  undirected physical links, and two directed flow variables per
  commodity-link pair.  Thus the continuous flow count is
  `16 * 136 * 2 = 4,352`.
- Of the 136 physical links, 135 are designable.  Every designable link has
  three nonnegative general-integer equipment variables and one nonnegative
  general-integer channel variable.  Thus the integer count is
  `135 * (3 + 1) = 540`.

For a designable link `e`, let `a_e`, `b_e`, and `c_e` be its three `x`
variables, let `z_e` be its `z` variable, and let `f^+_{ek}, f^-_{ek}` be the
two directed flows for commodity `k`.  Its two local rows are exactly

```
sum_k (f^+_{ek} + f^-_{ek}) <= 8000 a_e + 32000 b_e + 32000 c_e,
a_e + 4 b_e + c_e <= 40 z_e.
```

All three equipment costs are link-independent: `18.585`, `34.74`, and
`35.74`, respectively.  The 135 channel costs are link-dependent and range
from `8.5416` to `35.1872`.  The only two global design rows are

```
sum_e z_e >= 15,
sum_e (a_e + b_e + c_e) >= 15.
```

The row count is consequently

```
272 node balances + 136 capacity rows + 135 channel rows + 2 global rows = 545.
```

The supplied MIPLIB decomposition has 136 link blocks.  Each ordinary block
contains a capacity row and its channel row; block 43 contains only the
capacity row.  The 272 balances and two global rows are the border.  This is
the natural arc decomposition: local design/capacity decisions are coupled by
the multicommodity conservation equations.

## Provably valid reductions and reformulations

### Dead link 43

`link_capacity_43` has no design variables and zero right-hand side.  It is
the sum of 32 nonnegative directed flows constrained to be at most zero.
Therefore all 32 flows are identically zero and the row and variables can be
deleted.  Gurobi's ordinary presolve makes exactly this deletion, reducing to
4,860 columns and 544 rows.

### Sixteen redundant balances

For each commodity, every flow column has one `+1` and one `-1` in its block
of 17 balance rows.  The right-hand sides in each of the 16 blocks sum exactly
to zero.  Hence the sum of the 17 rows is `0 = 0`, and one balance row per
commodity can be deleted.  This gives 16 independent exact row reductions.
It is a structural rank reduction; it does not alter the feasible set.

### Exact flow scaling

The original coefficient range is needlessly wide because demand is measured
in units of one while installed capacity is 8,000 or 32,000.  Define

```
g_{ek} = f_{ek} / 1000.
```

Dividing every balance right-hand side by 1,000 and every design coefficient
in a capacity row by 1,000 gives the exactly equivalent local capacity row

```
sum_k (g^+_{ek} + g^-_{ek}) <= 8 a_e + 32 b_e + 32 c_e.
```

The generator is `make_flow_scaled_model.py`.  Given the downloaded original
MPS and [`../solutions/strict-5224.5144.sol`](../solutions/strict-5224.5144.sol),
it can create a scaled MPS and mapped start in a local replay directory.  Those
generated files are intentionally not stored in this repository.  The
transformation changed exactly 405 capacity coefficients,
152 nonzero demand right-hand sides, and all 4,352 displayed flow values.  It
changed no objective coefficient, integer variable, bound, or combinatorial
decision.  Gurobi reads the same 545 rows, 4,892 columns, and 14,285 nonzeros,
while the matrix range improves from `[1, 32000]` to `[1, 40]` and the
right-hand-side range from roughly `[15, 4e5]` to `[2, 4e2]`.

The solver-independent decimal audit reports zero row, bound, and integrality
violation for the transformed incumbent.

### Exact better-than-incumbent feasibility target

All 540 objective-bearing variables are integer.  Multiplying the 540 finite
decimal objective coefficients by 10,000 produces integers whose gcd is 2.
Every feasible objective is therefore in `0.0002 * Z`.  Consequently, a point
is strictly better than `5224.5144` if and only if it satisfies

```
cost <= 5224.5142.
```

`add_better_than_incumbent_cutoff.py` adds precisely this row to a regenerated
scaled model and also adds each positive-cost variable's individually implied
finite upper bound.  The generated cutoff MPS is intentionally not stored.
Proving this model infeasible would be
a much cleaner optimality test than relying on incumbent-dependent stopping.
No infeasibility proof was obtained in this structural audit.

### Exact cut-set inequalities available for strengthening

For a node set `S`, let `B_k(S)` be the sum of scaled demand right-hand sides
for commodity `k` over nodes in `S`, and let `delta(S)` be the physical links
crossing the cut.  Summing flow conservation over `S` and using the shared
link capacities gives the valid design-only inequality

```
sum_{e in delta(S)} (a_e + 4 b_e + 4 c_e)
    >= ceil( sum_k |B_k(S)| / 8 ).
```

The rounding is exact because the left-hand side is integer.  These are the
natural multicommodity cut-set inequalities for this formulation.  There are
`2^16 - 1 = 65,535` distinct nontrivial cuts after identifying complements;
single-node, two-node, and three-node cuts are a modest static subset.  They
were derived but not bulk-added here, because the scaled/cutoff formulation
was the highest-priority safe test within the time budget.

### Signed-flow projection

For every commodity-link pair, the two directed variables can be projected to
`g = f^+ - f^-`.  The exact projected capacity term is `|g|`; any simultaneous
counterflow or flow cycle can be removed without harming conservation or
capacity.  This exposes substantial continuous degeneracy, but an LP
linearization of all absolute values uses an auxiliary magnitude variable and
does not reduce the variable count.  It is therefore more useful as a
decomposition observation than as a compact MILP reformulation.

## Incumbent audit

The raw MIPLIB ID 4 vector is integral, but at `FeasibilityTol=1e-9` Gurobi
rejects its printed continuous flows because `demand_55` has residual about
`6.1e-8`.  Keeping only its 540 integer values and reoptimizing the continuous
flow LP produces the same objective `5224.5144` with strict feasibility.

`audit_solution.py` independently parses the finite-decimal MPS and the
displayed repaired solution, without a solver API.  For
[`../solutions/strict-5224.5144.sol`](../solutions/strict-5224.5144.sol) it
reports:

```
objective_recomputed       = 5224.5144
maximum row violation      = 0
maximum equality residual  = 0
maximum bound violation    = 0
maximum integrality error  = 0
unknown solution names     = 0
```

The clean design uses 74 positive `x` variables with sum 116 and maximum 3,
and 74 positive `z` variables, all equal to 1.  The reconstructed flow uses
235 positive directed variables.  Both global lower-bound rows are very
slack: their slacks are 101 and 59, respectively.

## Numerical optimality evidence and why it is not accepted as proof

- Gurobi 13.0.2, one thread, strict `1e-9` feasibility/integrality/optimality
  tolerances and zero relative/absolute MIP gap, returned `OPTIMAL` at
  `5224.5144` after 582 nodes in 3.75 seconds with Seed 1.  Seed 7 repeated the
  status after 587 nodes in 4.83 seconds.
- However, another Gurobi 13.0.2 default-presolve run first rejected the raw
  official start for its `6.1e-8` row residual and then returned `OPTIMAL` at
  `7577.089` after 0.87 seconds.  This is false because the independently
  checked `5224.5144` vector is feasible for the same official MPS.
- More conservative checks did not reproduce the zero-gap lower bound.
  Gurobi 12.0.3 on the exactly scaled model ended after 60 seconds at bound
  `5183.935925867` (0.7767% gap); this is the strongest retained numerical
  bound. On the original model, Gurobi 12.0.3 with the repaired start and
  strict tolerances ended at `5179.498090299` (0.8616% gap). Gurobi 13 with
  `NumericFocus=3` ended after 10 seconds at bound `3546.475995126`, and
  `NumericFocus=2` ended after 10 seconds at bound `3975.449827207`.

Thus the primal result is clean, while global optimality remains unconfirmed.
The official status should remain **open** unless a numerically safe solver
reproduces the lower bound or the cutoff model receives an independently
checkable infeasibility certificate.

## Reproducibility hashes

- Official MPS gzip:
  `8dcb784e3145ac52d395cded5aaefc977e7837139ddec24f428fb2904dfcb744`
- Official ID 4 solution gzip:
  `86c679ec88f8ff3a093b7115999a62fb704fc12c14782bbe76cdd6681ace8521`
- Repaired displayed solution:
  `6bc1eeb520a90a7efe8d6101e9281d1e4842a971c69943bafdb0d49cc04bf3a0`
- Scaled MPS from the source audit (not retained here):
  `62650b4e1fbdcd801edc99570c927e325aeda504f8be0606ddd9a92df6ac4c4d`
- Scaled displayed solution from the source audit (not retained here):
  `96a7e6cf6bbd88dcf0dd09613318604d4363c60977b94d1503bc7ee78818b4da`
- Scaled strict-improvement cutoff MPS from the source audit (not retained here):
  `cc1bb356816ed80f0a8fde4d23b0e4d0b77937e4c164e82c8c6087883f91117e`
- Seed 1 zero-gap log from the source audit (not retained here):
  `688a0b5f967d60df31fb927cb83d9138353b53199e40c50f3788cb174f572c68`
