# neos-5045105-creuse

## Result

This experiment found a Gurobi-accepted incumbent with objective
`20.571410408673007` and a best observed dual bound of
`19.932229270717325`. Combining the best bounds from the archived runs gives a
relative gap of approximately `3.1071%`.

**Status: feasible under Gurobi's numerical tolerances; global optimum not
proved.** The solution has not been independently certified against the
original model with stricter or exact arithmetic. Its floating-point objective
is slightly below the exact-looking MIPLIB value `20.57143`, so this repository
does not claim a new official incumbent or a strict numerical improvement.

## Model structure

| Property | Value |
|---|---:|
| Objective sense | Minimize |
| Variables | 3,848 |
| General integer variables | 3,780 |
| Continuous variables | 68 |
| Linear constraints | 252 |
| Matrix nonzeros | 23,108 |
| Nonzero objective coefficients | 20 |

The constraints comprise 124 `<=`, 48 `=`, and 80 `>=` rows. There are no
binary variables, SOS constraints, quadratic constraints, or general
constraints. See [`structure.json`](structure.json),
[`background.md`](background.md), and [`strategy.md`](strategy.md) for the
machine-readable structure and the analysis performed before solving.

## Experiment summary

The 5.5-hour framework was configured for 60k background-search tokens, 195k
solving tokens, and 45k reporting tokens. Actual use was:

| Stage | Tokens | Wall time |
|---|---:|---:|
| Background search | 43,743 | 567 s |
| Solving | 159,039 | 14,402 s |
| Reporting | 42,219 | 175 s |
| **Total** | **245,001** | **15,144 s (about 4 h 12 min)** |

Seven Gurobi 13.0.1 runs were executed on `euler4` with 32 CPU threads. The
experiments compared root-only probing, default search, MIP-focus settings,
stronger cuts, symmetry handling, and reuse of the incumbent as a MIP start.
The last run explored 2,129,342 nodes in 180 seconds and ended at the time
limit with objective `20.5714104748211`, bound `19.9322292707173`, and gap
`3.1071%`. The numerically smallest accepted incumbent
`20.571410408673007` came from an earlier run. COPT was not used, so the trial
does not constitute a Gurobi-versus-COPT comparison.

Every run has its own directory under [`runs/`](runs/) containing the solver
log, driver output, parameter/result JSON, and—when available—the best `.sol`
file.

## Reproducibility and provenance

- Input: [`input/neos-5045105-creuse.mps.gz`](input/neos-5045105-creuse.mps.gz)
- Compressed-file SHA-256:
  `e97c1d05f8d41bcebd795035b657d9e841e3db82b88a02e8e252d75f488e87c0`
- Uncompressed MPS SHA-256 recorded by the remote structure reader:
  `b3d146ba1c192759be79d81e3590cf03187eeaf200325c0238fa784893acbe63`
- Solver: Gurobi 13.0.1 on `euler4`; CPU only

## Claim boundary

The archived logs establish what the configured floating-point solver reported.
They do not provide an exact feasibility certificate, an optimality proof, or
an infeasibility proof. A next study should independently check the incumbent
with tighter tolerances or exact row arithmetic and should test COPT on
`altman` CPU before comparing solver behavior.
