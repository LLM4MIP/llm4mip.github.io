#  Neos-3691541 -lonja: exact subset structure with strictly feasible solution

##  Current Conclusions

As of 2026 -09 -08, [MIPLIB instance page ](https://miplib.zib.de/instance_details_neos-3691541-lonja.html)
This instance will still be labeled as `open` and the page headline will be tolerance solution with a star rating.
`-0.00744145058*`。

The best zero tolerance strictly feasible solution available in this directory is:

```text
0.0918239856 = 57389991 / 625000000
```

The solution is in [`solutions/lonja-0.0918239856-strict.sol` ](solutions/lonja-0.0918239856-strict.sol)].
The internal Fraction replay of the exact projection solver, the second set of independent weight parse and the public checker of the warehouse repository confirm:
10,300 boundary of a variable, 10,200 integer variable and 10,320 article original MPS constraint zero default, maximum exact row violation is zero.
For evidence, see
[`analysis/cpsat-seed79-independent-validation.json`](analysis/cpsat-seed79-independent-validation.json)
and
[`solutions/lonja-0.0918239856-strict.validation.log`](solutions/lonja-0.0918239856-strict.validation.log)。

This is strictly feasible primal bound, but lower than the MIPLIB headline `0.09926543618`, so ** does not improve MIPLIB.
Numerical primal bound **. There is no globally optimal sex proof or strict global lower bound in this directory.

##  Background and Gurobi only read structure

MIPLIB assigned it to `neos-pseudoapplication-13` without providing a bibliography.
Business source, this study is directly from the original coefficient recovery model.

The original MPS was read-only loaded on `euler4` by Gurobi 13.0.1 without calling `presolve()` or
`optimize()`.
[`analysis/gurobi-13.0.1-structure.json`](analysis/gurobi-13.0.1-structure.json)
It is also known as `logs/gurobi-13.0.1-structure.log` ](logs/gurobi-13.0.1-structure.log).

|  Property |  Numerical |
|---|---:|
|  Variables |  10,300  |
|  constraint |  10,320  |
|  nonzero entries |  40,568  |
| Binary variable |  10,200  |
| Free continuous variables |  100  |
| Objective non-zero |  10,000  |
|  objective sense | Minimized |

The original MPS SHA-256 was designed for
`25a0730056fd49caac2d95064aeebb7627e889ec9c1e25165eac94e59d6f5f5c`；
MPS, DEC and the official revision 2 are stored in [`input/` ](input/)].

##  The exact model from which the coefficient is recovered

[`analysis/exact-master-structure.json` ](analysis/exact-master-structure.json) is fully recorded]
Block structure. The model consists of 100 item, 100 group:

-  `10,000 = 100 × 100` is an assignment of the binary variable `x[i,j]`;
-  Each item is assigned to a group and `x[i,j] <= y[j]`;
-  100 group activates the variable `y[j]`, satisfying `sum(y) <= 15`, with another constraint on the `y` side of 3;
-  100 A free continuum `c[j]` is determined by the equation as a weighted assignment only and can therefore be exactly deleted;
-  100 A looser variable `z[j]` controls the upward and downward deviation of the objective value of `c[j]` and `sum(z) <= 6`;
-  Only one 15 group has a positive objective value, while the rest of 85 is a zero objective group.

So at least 9 a positive objective group must satisfy the exact subset-sum. This structure is not 100 × 100 permutation.
Models;group can receive multiple items. Exact subset audit
`analysis/exact-subset-audit.json` ](analysis/exact-subset-audit.json): 15 has a positive objective
14 can be reached individually and group 75 cannot be reached individually.

## official solution strict audit

The literal objective of 2 is `-0.00744145058`, the integrality is passed with the variable interface, but the original
MPS has 73 article exact row violation, the maximum value is `9.3153731313792e-6`.
[`analysis/official-2-strict-validation.json`](analysis/official-2-strict-validation.json)
It is also known as `logs/official-2-common-checker.log` ](logs/official-2-common-checker.log).

Only exact replenish 100 continuous variables with 9 row violation remaining, maximum value
`1747/125000000 = 0.000013976`; see
[`analysis/official-2-singleton-exactify.json`](analysis/official-2-singleton-exactify.json)。
Therefore, the title of the page cannot be considered a zero tolerance strict solution.

##  Key to solving experiments

###  bitset witness and catalogue master

Weigh an item for 100 using the Python integer bitset to make an exact subset-sum, polynomial random item order.
1,288 witness, covering the 14 achievable positive objective group.
10 is a two-by-two non-contact witness; see summary
[`analysis/bitset-witness-catalogue-merged.json`](analysis/bitset-witness-catalogue-merged.json)，
Each shard is in the [`experiments/bitset-witnesses/` ](experiments/bitset-witnesses/)].

Select the exact group 9 and put the rest of the item in the relaxed group 6 to get the strict point.
`0.10642427138`. Subsequently on the 1,288 witness and the 1,500 relaxed-assignment variable.
For objective master, 74.12 is given the strict point `0.1046509635` by CP-SAT `OPTIMAL` in seconds.
`OPTIMAL` **is only for the finite witness catalogue master**, not the original MPS globally optimal.
The result is [`experiments/catalogue-objective/result.json` ](experiments/catalogue-objective/result.json)].

###  Full projection CP-SAT

100 is a continuous variable defined by its equation exact eliminated, and all decimal coefficients integrated; catalogue strict points
For all 10,200 binary variables, explicit hint (including the missing zero variable), running 600 seconds, 12 threads:

|  seed  |  Status |  strict incumbent |  numerical projection bound |  Conclusion |
|---:|---|---:|---:|---|
|  73  |  `FEASIBLE`  |  `0.1036652288`  |  `-0.0179290875427`  | timeout, strict pass |
|  79  |  `FEASIBLE`  |  `0.0918239856`  |  `-0.0158844787159`  | timeout, strictly approved; current best |

The result is a log in `experiments/cpsat-completehint-seed*/` and
`logs/cpsat-completehint-seed*/`; two intermediate solutions are also preserved [`solutions/` ](solutions/)].
These bound are the numerical output of the solver on the integer projection model and are not converted into a portable proof file.

### unsuccessful experiments

-  Full projection of the scant official hint CP-SAT: 1,200 seconds, `UNKNOWN`, no incumbent;
-  CP-SAT symmetry reduction for the positive objective group of 15 only: 600 second, `UNKNOWN`, no incumbent;
-  From the `0.1046509635` to the full model COPT warm start: 600 seconds, 5,366 nodes, without improvement,
  floating-point bound `-0.029989431010705035` ; 
-  Primary space 10,200 binary variable Hamming radius 40: 600 seconds, 16,569 nodes, without improvement,
Restricted neighborhood floating-point bound `0.044313566906055`.

The answer is:
[`experiments/cpsat-seed17-no-incumbent/`](experiments/cpsat-seed17-no-incumbent/)、
[`experiments/positive15-no-incumbent/`](experiments/positive15-no-incumbent/)、
[`experiments/full-warm-copt8/` ](experiments/full-warm-copt8/) and
[`experiments/hamming40-copt8/`](experiments/hamming40-copt8/)。

## Evidence Boundary

-  `0.0918239856` is the strict feasible primal bound on the original MPS, not the MIPLIB headline improvement.
-  CP-SAT `FEASIBLE` and COPT status 8 both indicate deadline termination, which cannot be explained as optimal.
-  Catalogue `OPTIMAL` only closure 1,288 -witness finite has been generated
-  Hamming bound belongs only to restricted neighborhoods; other solver bound are also floating-point numerical.
-  There is no DRAT, VIPR or other portable global lower-bound/optimality certificate in this directory.
-  Therefore, the instance should still be labeled as `open` and not written as `optimal`.

## Reproduction

From warehouse repository root directory verification to final solution and official solution:

```bash
python common/exact_mps_solution_check.py \
  instances/neos-3691541-lonja/input/neos-3691541-lonja.mps.gz \
  instances/neos-3691541-lonja/solutions/lonja-0.0918239856-strict.sol \
  --tolerance 0

python common/exact_mps_solution_check.py \
  instances/neos-3691541-lonja/input/neos-3691541-lonja.mps.gz \
  instances/neos-3691541-lonja/input/neos-3691541-lonja-official-2.sol.gz \
  --tolerance 0
```

Replayable witness in the OR-Tools environment combined with full hint search:

```bash
python instances/neos-3691541-lonja/experiments/merge_witness_catalogue.py \
  --glob 'instances/neos-3691541-lonja/experiments/bitset-witnesses/seed-*.json' \
  --audit instances/neos-3691541-lonja/analysis/exact-subset-audit.json \
  --output /tmp/lonja-witness-merged.json --seconds 120 --workers 8

python instances/neos-3691541-lonja/experiments/solve_lonja_exact_cpsat_completehint.py \
  --model instances/neos-3691541-lonja/input/neos-3691541-lonja.mps.gz \
  --hint instances/neos-3691541-lonja/solutions/lonja-0.1046509635-catalogue-strict.sol \
  --complete-hint --output-dir /tmp/lonja-seed79 \
  --time-limit 600 --threads 12 --seed 79
```

hash checks:

```bash
(cd instances/neos-3691541-lonja && sha256sum -c SHA256SUMS)
```

`SHA256SUMS` covers all archival files except for the list itself.
