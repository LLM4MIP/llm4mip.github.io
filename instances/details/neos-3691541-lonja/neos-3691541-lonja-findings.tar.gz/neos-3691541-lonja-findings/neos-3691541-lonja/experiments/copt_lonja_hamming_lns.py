#!/usr/bin/env python3
"""Run a COPT local-branching search around a strict lonja incumbent."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import time
from pathlib import Path

import coptpy as cp
from coptpy import COPT


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_sparse_solution(path: Path) -> dict[str, float]:
    values: dict[str, float] = {}
    for raw in path.read_text(encoding="ascii").splitlines():
        fields = raw.split()
        if len(fields) != 2 or fields[0].startswith(("#", "=")):
            continue
        values[fields[0]] = float(fields[1])
    return values


def safe_attr(model, name: str, default=None):
    try:
        return getattr(model, name)
    except Exception:
        return default


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--radius", type=int, default=40)
    parser.add_argument("--time-limit", type=float, default=600.0)
    parser.add_argument("--threads", type=int, default=8)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    supplied = read_sparse_solution(args.solution)
    model = cp.Envr().createModel("lonja-hamming-lns")
    model.read(str(args.model))
    variables = model.getVars().getAll()
    binaries = [variable for variable in variables if variable.vtype == COPT.BINARY]
    if len(variables) != 10300 or len(binaries) != 10200:
        raise RuntimeError(f"unexpected lonja dimensions: {len(variables)}, {len(binaries)}")

    rounded = {variable.name: int(supplied.get(variable.name, 0.0) >= 0.5) for variable in binaries}
    distance = cp.quicksum(
        1 - variable if rounded[variable.name] else variable for variable in binaries
    )
    model.addConstr(distance <= args.radius, name="strict_incumbent_hamming_ball")

    start = [supplied.get(variable.name, 0.0) for variable in variables]
    model.setMipStart(variables, start)
    load_return = model.loadMipStart()
    model.setLogFile(str(args.output_dir / "solver.log"))
    model.setParam(COPT.Param.Threads, args.threads)
    model.setParam(COPT.Param.TimeLimit, args.time_limit)
    model.setParam(COPT.Param.RelGap, 0.0)
    model.setParam(COPT.Param.GPUMode, 0)
    for parameter, value in (
        (COPT.Param.HeurLevel, 3),
        (COPT.Param.PreRootHeurLevel, 3),
        (COPT.Param.RoundingHeurLevel, 3),
        (COPT.Param.DivingHeurLevel, 3),
        (COPT.Param.FAPHeurLevel, 4),
        (COPT.Param.SubMipHeurLevel, 3),
        (COPT.Param.MipRepair, 3),
    ):
        try:
            model.setParam(parameter, value)
        except Exception:
            pass

    started = time.monotonic()
    model.solve()
    wall_seconds = time.monotonic() - started
    report = {
        "schema": "lonja-copt-hamming-lns-v1",
        "host": platform.node(),
        "scope": "all 10200 original binary variables within a Hamming ball; 100 continuous variables free",
        "interpretation": "restricted primal neighborhood only; any solver bound is local and numerical",
        "model_sha256": sha256(args.model),
        "start_sha256": sha256(args.solution),
        "script_sha256": sha256(Path(__file__)),
        "binary_variables": len(binaries),
        "radius": args.radius,
        "threads": args.threads,
        "time_limit_seconds": args.time_limit,
        "load_mip_start_return": repr(load_return),
        "wall_seconds": wall_seconds,
        "status": safe_attr(model, "status"),
        "has_mip_solution": bool(safe_attr(model, "hasmipsol", False)),
        "objective": safe_attr(model, "objval"),
        "best_bound": safe_attr(model, "bestbnd"),
        "relative_gap": safe_attr(model, "mipgap"),
        "node_count": safe_attr(model, "nodecnt"),
        "solver_time": safe_attr(model, "solvingtime"),
    }
    if report["has_mip_solution"]:
        candidate = args.output_dir / "candidate.sol"
        model.write(str(candidate))
        report["candidate_sha256"] = sha256(candidate)
    (args.output_dir / "result.json").write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print("FINAL_RESULT " + json.dumps(report, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
