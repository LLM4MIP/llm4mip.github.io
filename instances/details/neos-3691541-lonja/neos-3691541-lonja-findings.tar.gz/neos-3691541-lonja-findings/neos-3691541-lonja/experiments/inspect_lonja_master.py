#!/usr/bin/env python3
"""Recover the exact block/master structure of neos-3691541-lonja."""

from __future__ import annotations

import argparse
import collections
import json
from fractions import Fraction
from pathlib import Path

from helper_route_logic import parse


def read_dec(path: Path) -> list[list[str]]:
    blocks: list[list[str]] = []
    current: list[str] | None = None
    for raw in path.read_text(encoding="ascii").splitlines():
        fields = raw.split()
        if not fields or raw.lstrip().startswith("\\"):
            continue
        if fields[0].upper() == "MASTERCONSS":
            current = None
            continue
        if fields[0].upper() == "BLOCK":
            current = []
            blocks.append(current)
        elif current is not None:
            current.append(fields[0])
    return blocks


def fs(value: Fraction | None) -> str | None:
    return None if value is None else str(value)


def term(v: str, a: Fraction) -> list[str]:
    return [v, str(a)]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=Path, required=True)
    ap.add_argument("--dec", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    senses, row_order, variables, columns, rows, rhs, lb, ub, integer = parse(args.model)
    blocks = read_dec(args.dec)
    local_row_to_block = {
        row: block_id
        for block_id, block_rows in enumerate(blocks)
        for row in block_rows
    }
    master_rows = [row for row in row_order if row not in local_row_to_block]
    var_blocks: dict[str, set[int]] = collections.defaultdict(set)
    for variable in variables:
        for row in columns[variable]:
            if row in local_row_to_block:
                var_blocks[variable].add(local_row_to_block[row])
    block_variables = [[] for _ in blocks]
    for variable, memberships in var_blocks.items():
        if len(memberships) == 1:
            block_variables[next(iter(memberships))].append(variable)

    def row_record(row: str) -> dict:
        return {
            "row": row,
            "sense": senses[row],
            "rhs": fs(rhs.get(row, Fraction(0))),
            "terms": [term(v, a) for v, a in rows[row]],
        }

    examples = []
    for block_id in range(min(3, len(blocks))):
        vs = block_variables[block_id]
        examples.append({
            "block": block_id + 1,
            "variables": [{
                "name": v,
                "integer": v in integer,
                "lb": fs(lb[v]),
                "ub": fs(ub[v]),
                "objective": fs(next((a for row, a in columns[v].items() if row not in senses), Fraction(0))),
                "master_terms": [[row, str(a)] for row, a in columns[v].items() if row in master_rows],
                "local_terms": [[row, str(a)] for row, a in columns[v].items() if row in local_row_to_block],
            } for v in vs],
            "local_rows": [row_record(row) for row in blocks[block_id]],
        })

    master_compact = []
    for row in master_rows:
        terms = rows[row]
        master_compact.append({
            "row": row,
            "sense": senses[row],
            "rhs": fs(rhs.get(row, Fraction(0))),
            "nnz": len(terms),
            "type_counts": dict(collections.Counter(
                "integer" if v in integer else "continuous" for v, _ in terms
            )),
            "coefficients": dict(collections.Counter(str(a) for _, a in terms)),
            "terms": [term(v, a) for v, a in terms],
        })

    result = {
        "nblocks": len(blocks),
        "master_rows": master_compact,
        "block_row_counts": [len(x) for x in blocks],
        "block_variable_counts": [len(x) for x in block_variables],
        "variable_membership_counts": dict(collections.Counter(len(x) for x in var_blocks.values())),
        "examples": examples,
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "nblocks": result["nblocks"],
        "master_rows": len(master_rows),
        "block_row_counts": dict(collections.Counter(result["block_row_counts"])),
        "block_variable_counts": dict(collections.Counter(result["block_variable_counts"])),
        "membership_counts": result["variable_membership_counts"],
    }, indent=2))


if __name__ == "__main__":
    main()
