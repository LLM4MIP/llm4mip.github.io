#!/usr/bin/env python3
"""Round integer values and exactly replay singleton-continuous equalities."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from fractions import Fraction
from pathlib import Path

from helper_route_logic import parse


def lines(path: Path) -> list[str]:
    if path.suffix == ".gz":
        with gzip.open(path, "rt", encoding="ascii") as stream:
            return stream.read().splitlines()
    return path.read_text(encoding="ascii").splitlines()


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def terminating(value: Fraction) -> str:
    if value == 0:
        return "0"
    sign = "-" if value < 0 else ""
    numerator, denominator = abs(value.numerator), value.denominator
    twos = fives = 0
    while denominator % 2 == 0:
        denominator //= 2
        twos += 1
    while denominator % 5 == 0:
        denominator //= 5
        fives += 1
    if denominator != 1:
        raise ValueError(f"nonterminating fraction {value}")
    places = max(twos, fives)
    scaled = numerator * (2 ** (places - twos)) * (5 ** (places - fives))
    digits = str(scaled).rjust(places + 1, "0")
    if places == 0:
        return sign + digits
    result = sign + digits[:-places] + "." + digits[-places:]
    return result.rstrip("0").rstrip(".")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--input-solution", type=Path, required=True)
    parser.add_argument("--output-solution", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()

    senses, row_order, variables, columns, rows, rhs, lower, upper, integer = parse(args.model)
    variable_set = set(variables)
    values: dict[str, Fraction] = {}
    for number, raw in enumerate(lines(args.input_solution), 1):
        line = raw.strip()
        if not line or line.startswith("#") or line.startswith("=obj="):
            continue
        fields = line.split()
        if len(fields) != 2 or fields[0] not in variable_set:
            raise ValueError(f"bad solution line {number}: {raw}")
        values[fields[0]] = Fraction(fields[1])
    for variable in variables:
        values.setdefault(variable, Fraction(0))

    rounding = []
    for variable in integer:
        old = values[variable]
        rounded = Fraction(round(float(old)))
        if old != rounded:
            rounding.append([variable, str(old), str(rounded), str(abs(old - rounded))])
        values[variable] = rounded

    continuous = set(variables) - set(integer)
    solved: set[str] = set()
    replay_rows = []
    progress = True
    while progress:
        progress = False
        for row in row_order:
            if senses[row] != "E":
                continue
            unknown = [
                (variable, coefficient)
                for variable, coefficient in rows[row]
                if variable in continuous and variable not in solved
            ]
            if len(unknown) != 1:
                continue
            variable, coefficient = unknown[0]
            known_sum = sum(
                other_coefficient * values[other]
                for other, other_coefficient in rows[row]
                if other != variable
            )
            values[variable] = (rhs.get(row, Fraction(0)) - known_sum) / coefficient
            solved.add(variable)
            replay_rows.append([row, variable, str(values[variable])])
            progress = True

    bound_count = integrality_count = row_count = 0
    maximum = Fraction(0)
    maximum_row = None
    row_samples = []
    for variable in variables:
        value = values[variable]
        if ((lower[variable] is not None and value < lower[variable])
                or (upper[variable] is not None and value > upper[variable])):
            bound_count += 1
        if variable in integer and value.denominator != 1:
            integrality_count += 1
    for row in row_order:
        activity = sum(coefficient * values[variable] for variable, coefficient in rows[row])
        target = rhs.get(row, Fraction(0))
        violation = (
            abs(activity - target) if senses[row] == "E"
            else max(Fraction(0), activity - target) if senses[row] == "L"
            else max(Fraction(0), target - activity)
        )
        if violation:
            row_count += 1
            if len(row_samples) < 100:
                row_samples.append([row, str(activity), senses[row], str(target), str(violation)])
        if violation > maximum:
            maximum, maximum_row = violation, row

    objective_rows = {
        row for terms in columns.values() for row, coefficient in terms.items()
        if row not in senses and coefficient
    }
    if len(objective_rows) != 1:
        raise ValueError(f"objective rows: {objective_rows}")
    objective_row = next(iter(objective_rows))
    objective = sum(
        columns[variable].get(objective_row, Fraction(0)) * values[variable]
        for variable in variables
    )
    args.output_solution.parent.mkdir(parents=True, exist_ok=True)
    with args.output_solution.open("w", encoding="ascii", newline="\n") as stream:
        stream.write(f"=obj= {terminating(objective)}\n")
        for variable in variables:
            if values[variable]:
                stream.write(f"{variable} {terminating(values[variable])}\n")
    report = {
        "schema": "singleton-continuous-exactification-v1",
        "model": args.model.as_posix(),
        "input_solution": args.input_solution.as_posix(),
        "output_solution": args.output_solution.as_posix(),
        "integer_values_changed": len(rounding),
        "maximum_integer_rounding_error": max((item[3] for item in rounding), default="0"),
        "rounding_samples": rounding[:100],
        "continuous_variables": len(continuous),
        "continuous_variables_exactly_replayed": len(solved),
        "replay_rows": replay_rows,
        "objective_fraction": str(objective),
        "objective_decimal": terminating(objective),
        "bound_violation_count": bound_count,
        "integrality_violation_count": integrality_count,
        "row_violation_count": row_count,
        "maximum_exact_row_violation": str(maximum),
        "maximum_violation_row": maximum_row,
        "valid_at_zero_tolerance_before_serialized_reparse": (
            bound_count == 0 and integrality_count == 0 and row_count == 0
        ),
        "row_violation_samples": row_samples,
        "model_sha256": sha256(args.model),
        "input_solution_sha256": sha256(args.input_solution),
        "output_solution_sha256": sha256(args.output_solution),
        "script_sha256": sha256(Path(__file__)),
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({key: report[key] for key in (
        "integer_values_changed", "continuous_variables_exactly_replayed",
        "objective_fraction", "bound_violation_count", "integrality_violation_count",
        "row_violation_count", "maximum_exact_row_violation",
        "valid_at_zero_tolerance_before_serialized_reparse",
    )}, indent=2))


if __name__ == "__main__":
    main()
