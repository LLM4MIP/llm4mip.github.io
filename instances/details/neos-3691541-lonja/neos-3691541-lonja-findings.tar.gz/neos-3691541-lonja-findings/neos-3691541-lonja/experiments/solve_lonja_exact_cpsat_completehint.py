#!/usr/bin/env python3
"""Solve lonja after exact elimination of its 100 free continuous variables."""

from __future__ import annotations

import argparse
import collections
import gzip
import hashlib
import json
import math
import time
from fractions import Fraction
from pathlib import Path

from ortools.sat.python import cp_model

from helper_route_logic import parse


def read_solution(path: Path) -> dict[str, Fraction]:
    opener = gzip.open if path.suffix == ".gz" else open
    values: dict[str, Fraction] = {}
    with opener(path, "rt", encoding="ascii") as stream:
        for raw in stream:
            fields = raw.split()
            if len(fields) == 2 and not fields[0].startswith(("#", "=obj=")):
                values[fields[0]] = Fraction(fields[1])
    return values


def integerize(coefficients: dict[str, Fraction], rhs: Fraction) -> tuple[dict[str, int], int]:
    scale = math.lcm(rhs.denominator, *(value.denominator for value in coefficients.values()))
    ints = {variable: int(value * scale) for variable, value in coefficients.items() if value}
    irhs = int(rhs * scale)
    divisor = math.gcd(abs(irhs), *(abs(value) for value in ints.values()))
    if divisor > 1:
        ints = {variable: value // divisor for variable, value in ints.items()}
        irhs //= divisor
    return ints, irhs


def terminating(value: Fraction) -> str:
    if value == 0:
        return "0"
    sign = "-" if value < 0 else ""
    numerator, denominator = abs(value.numerator), value.denominator
    twos = fives = 0
    while denominator % 2 == 0:
        denominator //= 2
        twos += 1
    while denominator % 5 == 0:
        denominator //= 5
        fives += 1
    if denominator != 1:
        raise ValueError(f"nonterminating fraction: {value}")
    places = max(twos, fives)
    scaled = numerator * 2 ** (places - twos) * 5 ** (places - fives)
    digits = str(scaled).rjust(places + 1, "0")
    if places == 0:
        return sign + digits
    result = sign + digits[:-places] + "." + digits[-places:]
    return result.rstrip("0").rstrip(".")


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--model", type=Path, required=True)
    ap.add_argument("--hint", type=Path)
    ap.add_argument(
        "--complete-hint",
        action="store_true",
        help="Treat every integer variable absent from the sparse solution as zero.",
    )
    ap.add_argument("--output-dir", type=Path, required=True)
    ap.add_argument("--time-limit", type=float, default=1200)
    ap.add_argument("--threads", type=int, default=16)
    ap.add_argument("--seed", type=int, default=17)
    args = ap.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    senses, row_order, variables, columns, rows, rhs, lb, ub, integer = parse(args.model)
    continuous = [variable for variable in variables if variable not in integer]
    assert len(continuous) == 100 and len(integer) == 10200
    assert all(lb[v] == 0 and ub[v] == 1 for v in integer)

    # Recover c_j = sum_i w_i*x_ij from its unique equality, then substitute it
    # into every original row. This is an exact projection because every c_j is free.
    continuous_expression: dict[str, dict[str, Fraction]] = {}
    defining_rows: set[str] = set()
    for variable in continuous:
        candidate_rows = []
        for row, coefficient in columns[variable].items():
            if row in senses and senses[row] == "E":
                continuous_terms = [(v, a) for v, a in rows[row] if v in continuous]
                if len(continuous_terms) == 1:
                    candidate_rows.append((row, coefficient))
        assert len(candidate_rows) == 1, (variable, candidate_rows)
        row, coefficient = candidate_rows[0]
        assert rhs.get(row, Fraction(0)) == 0
        expression = {
            other: -other_coefficient / coefficient
            for other, other_coefficient in rows[row]
            if other != variable
        }
        assert expression and set(expression) <= integer
        continuous_expression[variable] = expression
        defining_rows.add(row)

    projected_rows: list[tuple[str, str, dict[str, int], int]] = []
    maximum_abs_coefficient = 0
    for row in row_order:
        if row in defining_rows:
            continue
        projected: dict[str, Fraction] = collections.defaultdict(Fraction)
        for variable, coefficient in rows[row]:
            if variable in integer:
                projected[variable] += coefficient
            else:
                for other, factor in continuous_expression[variable].items():
                    projected[other] += coefficient * factor
        icoefficients, irhs = integerize(projected, rhs.get(row, Fraction(0)))
        projected_rows.append((row, senses[row], icoefficients, irhs))
        maximum_abs_coefficient = max(maximum_abs_coefficient, *(abs(v) for v in icoefficients.values()))

    objective_rows = {
        row for terms in columns.values() for row in terms if row not in senses
    }
    assert len(objective_rows) == 1
    objective_row = next(iter(objective_rows))
    objective: dict[str, Fraction] = collections.defaultdict(Fraction)
    for variable in variables:
        coefficient = columns[variable].get(objective_row, Fraction(0))
        if variable in integer:
            objective[variable] += coefficient
        else:
            for other, factor in continuous_expression[variable].items():
                objective[other] += coefficient * factor
    objective_scale = math.lcm(*(value.denominator for value in objective.values()))
    objective_integer = {variable: int(value * objective_scale) for variable, value in objective.items() if value}

    model = cp_model.CpModel()
    cp_variables = {variable: model.new_bool_var(variable) for variable in integer}
    for _, sense, coefficients, target in projected_rows:
        expression = sum(value * cp_variables[variable] for variable, value in coefficients.items())
        if sense == "E":
            model.add(expression == target)
        elif sense == "L":
            model.add(expression <= target)
        elif sense == "G":
            model.add(expression >= target)
        else:
            raise ValueError(sense)
    model.minimize(sum(value * cp_variables[variable] for variable, value in objective_integer.items()))

    hint_values = read_solution(args.hint) if args.hint else {}
    hint_count = 0
    for variable in integer:
        if variable in hint_values or (args.hint and args.complete_hint):
            value = int(hint_values.get(variable, Fraction(0)) >= Fraction(1, 2))
            model.add_hint(cp_variables[variable], value)
            hint_count += 1

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = args.time_limit
    solver.parameters.num_search_workers = args.threads
    solver.parameters.random_seed = args.seed
    solver.parameters.log_search_progress = True
    solver.parameters.log_to_stdout = True
    solver.parameters.cp_model_presolve = True
    start = time.monotonic()
    status = solver.solve(model)
    elapsed = time.monotonic() - start
    status_name = solver.status_name(status)

    report = {
        "schema": "lonja-exact-projected-cpsat-v1",
        "status": int(status),
        "status_name": status_name,
        "elapsed_seconds": elapsed,
        "time_limit_seconds": args.time_limit,
        "threads": args.threads,
        "seed": args.seed,
        "integer_variables": len(integer),
        "continuous_variables_exactly_eliminated": len(continuous),
        "projected_rows": len(projected_rows),
        "maximum_absolute_integer_row_coefficient": maximum_abs_coefficient,
        "objective_scale": objective_scale,
        "hint_variables": hint_count,
        "complete_hint": args.complete_hint,
        "branches": solver.num_branches,
        "conflicts": solver.num_conflicts,
        "wall_time": solver.wall_time,
        "best_objective_bound_scaled": solver.best_objective_bound,
        "model_sha256": digest(args.model),
        "script_sha256": digest(Path(__file__)),
    }

    if status in (cp_model.FEASIBLE, cp_model.OPTIMAL):
        values = {variable: Fraction(solver.value(cp_variables[variable])) for variable in integer}
        for variable, expression in continuous_expression.items():
            values[variable] = sum((coefficient * values[other] for other, coefficient in expression.items()), Fraction(0))
        objective_fraction = sum(objective.get(variable, Fraction(0)) * values[variable] for variable in variables)

        bound_violations = integrality_violations = row_violations = 0
        maximum_violation = Fraction(0)
        violation_samples = []
        for variable in variables:
            value = values[variable]
            if ((lb[variable] is not None and value < lb[variable])
                    or (ub[variable] is not None and value > ub[variable])):
                bound_violations += 1
            if variable in integer and value.denominator != 1:
                integrality_violations += 1
        for row in row_order:
            activity = sum(coefficient * values[variable] for variable, coefficient in rows[row])
            target = rhs.get(row, Fraction(0))
            violation = (
                abs(activity - target) if senses[row] == "E"
                else max(Fraction(0), activity - target) if senses[row] == "L"
                else max(Fraction(0), target - activity)
            )
            if violation:
                row_violations += 1
                if len(violation_samples) < 20:
                    violation_samples.append([row, str(activity), senses[row], str(target), str(violation)])
            maximum_violation = max(maximum_violation, violation)

        solution_path = args.output_dir / "solution.sol"
        with solution_path.open("w", encoding="ascii", newline="\n") as stream:
            stream.write(f"=obj= {terminating(objective_fraction)}\n")
            for variable in variables:
                if values[variable]:
                    stream.write(f"{variable} {terminating(values[variable])}\n")
        report.update({
            "objective_fraction": str(objective_fraction),
            "objective_decimal": terminating(objective_fraction),
            "objective_scaled_integer": int(objective_fraction * objective_scale),
            "bound_violation_count": bound_violations,
            "integrality_violation_count": integrality_violations,
            "row_violation_count": row_violations,
            "maximum_exact_row_violation": str(maximum_violation),
            "violation_samples": violation_samples,
            "valid_at_zero_tolerance_before_reparse": (
                bound_violations == 0 and integrality_violations == 0 and row_violations == 0
            ),
            "solution_sha256": digest(solution_path),
        })
    report_path = args.output_dir / "result.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print("FINAL_RESULT " + json.dumps(report, sort_keys=True))


if __name__ == "__main__":
    main()
