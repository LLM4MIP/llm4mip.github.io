#!/usr/bin/env python3
"""Lift a disjoint exact-subset witness pack into strict original lonja solutions."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from fractions import Fraction
from pathlib import Path

from helper_route_logic import parse


def name(index: int) -> str:
    return f"C{index:04d}"


def terminating(value: Fraction) -> str:
    if value == 0:
        return "0"
    sign = "-" if value < 0 else ""
    numerator, denominator = abs(value.numerator), value.denominator
    twos = fives = 0
    while denominator % 2 == 0:
        denominator //= 2
        twos += 1
    while denominator % 5 == 0:
        denominator //= 5
        fives += 1
    if denominator != 1:
        raise ValueError(value)
    places = max(twos, fives)
    scaled = numerator * 2 ** (places - twos) * 5 ** (places - fives)
    digits = str(scaled).rjust(places + 1, "0")
    if places == 0:
        return sign + digits
    return (sign + digits[:-places] + "." + digits[-places:]).rstrip("0").rstrip(".")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--model", type=Path, required=True)
    ap.add_argument("--witness-pack", type=Path, required=True)
    ap.add_argument("--output-dir", type=Path, required=True)
    args = ap.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    senses, row_order, variables, columns, rows, rhs, lb, ub, integer = parse(args.model)
    pack = json.loads(args.witness_pack.read_text(encoding="utf-8"))
    chosen = {
        int(record["target_block"]) - 1: {int(item) - 1 for item in record["items"]}
        for record in pack["chosen"]
    }
    assert len(chosen) >= 9
    flattened = [item for subset in chosen.values() for item in subset]
    assert len(flattened) == len(set(flattened)) and all(0 <= item < 100 for item in flattened)

    xname = [[name(100 * i + j) for j in range(1, 101)] for i in range(1, 101)]
    cname = [name(j) for j in range(1, 101)]
    yname = [name(10100 + j) for j in range(1, 101)]
    zname = [name(10200 + j) for j in range(1, 101)]
    weights: list[Fraction] | None = None
    targets: list[Fraction] = []
    for j in range(100):
        erows = [row for row in row_order if senses[row] == "E" and dict(rows[row]).get(cname[j])]
        erows = [row for row in erows if sum(variable in cname for variable, _ in rows[row]) == 1]
        assert len(erows) == 1
        terms = dict(rows[erows[0]])
        candidate = [-terms[xname[i][j]] / terms[cname[j]] for i in range(100)]
        if weights is None:
            weights = candidate
        else:
            assert candidate == weights
        upper = [
            row for row in row_order
            if dict(rows[row]).get(cname[j]) == 1 and dict(rows[row]).get(zname[j]) == -1
        ]
        assert len(upper) == 1
        targets.append(rhs.get(upper[0], Fraction(0)))
    assert weights is not None
    positive = [j for j, target in enumerate(targets) if target > 0]
    assert len(positive) == 15 and set(chosen) <= set(positive)
    objective_rows = {row for terms in columns.values() for row in terms if row not in senses}
    assert len(objective_rows) == 1
    objective_row = next(iter(objective_rows))
    costs = [[columns[xname[i][j]].get(objective_row, Fraction(0)) for j in range(100)] for i in range(100)]

    witness_checks = {}
    for block, items in chosen.items():
        total = sum((weights[item] for item in items), Fraction(0))
        witness_checks[str(block + 1)] = {
            "items": sorted(item + 1 for item in items),
            "weight_sum": str(total),
            "target": str(targets[block]),
            "exact": total == targets[block],
        }
        assert total == targets[block]

    def build(exact_blocks: set[int]) -> tuple[dict[str, Fraction], dict]:
        relaxed = sorted(set(positive) - exact_blocks)
        assert len(relaxed) <= 6 and relaxed
        values = {variable: Fraction(0) for variable in variables}
        assigned: set[int] = set()
        for block in exact_blocks:
            for item in chosen[block]:
                assert item not in assigned
                assigned.add(item)
                values[xname[item][block]] = Fraction(1)
        leftover_assignments = []
        for item in range(100):
            if item in assigned:
                continue
            block = min(relaxed, key=lambda candidate: (costs[item][candidate], candidate))
            values[xname[item][block]] = Fraction(1)
            leftover_assignments.append([item + 1, block + 1, str(costs[item][block])])
        for block in positive:
            values[yname[block]] = Fraction(1)
            values[zname[block]] = Fraction(block in relaxed)
        for block in range(100):
            values[cname[block]] = sum(weights[item] * values[xname[item][block]] for item in range(100))

        bound_count = integrality_count = row_count = 0
        maximum = Fraction(0)
        samples = []
        for variable in variables:
            value = values[variable]
            if ((lb[variable] is not None and value < lb[variable])
                    or (ub[variable] is not None and value > ub[variable])):
                bound_count += 1
            if variable in integer and value.denominator != 1:
                integrality_count += 1
        for row in row_order:
            activity = sum(coefficient * values[variable] for variable, coefficient in rows[row])
            target = rhs.get(row, Fraction(0))
            violation = (
                abs(activity - target) if senses[row] == "E"
                else max(Fraction(0), activity - target) if senses[row] == "L"
                else max(Fraction(0), target - activity)
            )
            if violation:
                row_count += 1
                if len(samples) < 20:
                    samples.append([row, str(activity), senses[row], str(target), str(violation)])
            maximum = max(maximum, violation)
        objective = sum(columns[v].get(objective_row, Fraction(0)) * values[v] for v in variables)
        metadata = {
            "exact_blocks_one_based": sorted(block + 1 for block in exact_blocks),
            "relaxed_blocks_one_based": [block + 1 for block in relaxed],
            "exact_block_count": len(exact_blocks),
            "relaxed_block_count": len(relaxed),
            "leftover_items": len(leftover_assignments),
            "leftover_assignments": leftover_assignments,
            "objective_fraction": str(objective),
            "objective_decimal": terminating(objective),
            "bound_violation_count": bound_count,
            "integrality_violation_count": integrality_count,
            "row_violation_count": row_count,
            "maximum_exact_row_violation": str(maximum),
            "violation_samples": samples,
            "valid_at_zero_tolerance_before_reparse": (
                bound_count == 0 and integrality_count == 0 and row_count == 0
            ),
        }
        return values, metadata

    candidates = []
    exact_all = set(chosen)
    option_sets = [("ten-exact", exact_all)] + [
        (f"drop-{block + 1}", exact_all - {block}) for block in sorted(exact_all)
    ]
    for label, exact_blocks in option_sets:
        values, metadata = build(exact_blocks)
        metadata["label"] = label
        if metadata["valid_at_zero_tolerance_before_reparse"]:
            path = args.output_dir / ("strict-ten-exact.sol" if label == "ten-exact" else f"strict-{label}.sol")
            with path.open("w", encoding="ascii", newline="\n") as stream:
                stream.write(f"=obj= {metadata['objective_decimal']}\n")
                for variable in variables:
                    if values[variable]:
                        stream.write(f"{variable} {terminating(values[variable])}\n")
            metadata["solution"] = path.as_posix()
            metadata["solution_sha256"] = sha(path)
        candidates.append(metadata)
    valid_nine = [item for item in candidates if item["exact_block_count"] == 9 and item["valid_at_zero_tolerance_before_reparse"]]
    best = min(valid_nine, key=lambda item: Fraction(item["objective_fraction"])) if valid_nine else None
    result = {
        "schema": "lonja-witness-pack-lift-v1",
        "model_sha256": sha(args.model),
        "witness_pack_sha256": sha(args.witness_pack),
        "script_sha256": sha(Path(__file__)),
        "witness_checks": witness_checks,
        "options": candidates,
        "valid_nine_exact_options": len(valid_nine),
        "best_nine_exact_label": None if best is None else best["label"],
        "best_nine_exact_objective_fraction": None if best is None else best["objective_fraction"],
        "best_nine_exact_objective_decimal": None if best is None else best["objective_decimal"],
        "best_nine_exact_solution": None if best is None else best["solution"],
        "best_nine_exact_solution_sha256": None if best is None else best["solution_sha256"],
    }
    report_path = args.output_dir / "lift-result.json"
    report_path.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "valid_nine_exact_options": result["valid_nine_exact_options"],
        "best_nine_exact_label": result["best_nine_exact_label"],
        "best_nine_exact_objective_fraction": result["best_nine_exact_objective_fraction"],
        "best_nine_exact_solution": result["best_nine_exact_solution"],
        "best_nine_exact_solution_sha256": result["best_nine_exact_solution_sha256"],
    }, indent=2))


if __name__ == "__main__":
    main()
