# Package manifest: neos-3691541-lonja

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 70
Excluded source files: 1

## Included files

- `README.md`
- `SHA256SUMS`
- `analysis/bitset-witness-catalogue-merged.json`
- `analysis/catalogue-0.1046509635-independent-validation.json`
- `analysis/cpsat-seed73-independent-validation.json`
- `analysis/cpsat-seed79-independent-validation.json`
- `analysis/exact-master-structure.json`
- `analysis/exact-subset-audit.json`
- `analysis/gurobi-13.0.1-structure.json`
- `analysis/official-2-singleton-exactified-still-infeasible.sol`
- `analysis/official-2-singleton-exactify.json`
- `analysis/official-2-strict-validation.json`
- `analysis/witness-lift-0.10642427138-independent-validation.json`
- `experiments/bitset-witnesses/seed-20260908.json`
- `experiments/bitset-witnesses/seed-20261000.json`
- `experiments/bitset-witnesses/seed-20262000.json`
- `experiments/bitset-witnesses/seed-20263000.json`
- `experiments/bitset-witnesses/seed-20264000.json`
- `experiments/bitset-witnesses/seed-20265000.json`
- `experiments/bitset-witnesses/seed-20266000.json`
- `experiments/catalogue-objective/result.json`
- `experiments/copt_lonja_hamming_lns.py`
- `experiments/copt_warmstart.py`
- `experiments/cpsat-completehint-seed73/result.json`
- `experiments/cpsat-completehint-seed79/result.json`
- `experiments/cpsat-seed17-no-incumbent/result.json`
- `experiments/exactify_singleton_continuous.py`
- `experiments/full-warm-copt8/result.json`
- `experiments/generate_bitset_witnesses.py`
- `experiments/generic_fraction_validator.py`
- `experiments/hamming40-copt8/result.json`
- `experiments/helper_route_logic.py`
- `experiments/inspect_lonja_master.py`
- `experiments/lift_lonja_witness_pack.py`
- `experiments/lonja_exact_subset_audit.py`
- `experiments/merge_witness_catalogue.py`
- `experiments/optimize_lonja_witness_catalogue.py`
- `experiments/positive15-no-incumbent/result.json`
- `experiments/solve_lonja_exact_cpsat_completehint.py`
- `experiments/solve_lonja_positive_groups_cpsat.py`
- `experiments/witness-lift/result.json`
- `input/neos-3691541-lonja-official-2.sol.gz`
- `input/neos-3691541-lonja.dec`
- `logs/bitset-witnesses/seed-20260908.log`
- `logs/bitset-witnesses/seed-20261000.log`
- `logs/bitset-witnesses/seed-20262000.log`
- `logs/bitset-witnesses/seed-20263000.log`
- `logs/bitset-witnesses/seed-20264000.log`
- `logs/bitset-witnesses/seed-20265000.log`
- `logs/bitset-witnesses/seed-20266000.log`
- `logs/catalogue-objective/console.log`
- `logs/cpsat-completehint-seed73/console.log`
- `logs/cpsat-completehint-seed73/strict-validation.log`
- `logs/cpsat-completehint-seed79/console.log`
- `logs/cpsat-completehint-seed79/strict-validation.log`
- `logs/cpsat-seed17-no-incumbent/console.log`
- `logs/exact-subset-audit.log`
- `logs/full-warm-copt8/console.log`
- `logs/full-warm-copt8/solver.log`
- `logs/gurobi-13.0.1-structure.log`
- `logs/hamming40-copt8/console.log`
- `logs/hamming40-copt8/solver.log`
- `logs/official-2-common-checker.log`
- `logs/official-2-strict-validation.log`
- `logs/positive15-no-incumbent/console.log`
- `solutions/lonja-0.0918239856-strict.sol`
- `solutions/lonja-0.0918239856-strict.validation.log`
- `solutions/lonja-0.1036652288-strict.sol`
- `solutions/lonja-0.1046509635-catalogue-strict.sol`
- `solutions/lonja-0.10642427138-strict.sol`

## Excluded files

- `input/neos-3691541-lonja.mps.gz (282473 bytes; raw benchmark input; sha256 25a0730056fd49caac2d95064aeebb7627e889ec9c1e25165eac94e59d6f5f5c)`
