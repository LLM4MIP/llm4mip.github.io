# Input model

The original MPS is not stored in this repository package. Download
[`rmine21.mps.gz`](https://miplib.zib.de/WebData/instances/rmine21.mps.gz)
from the official MIPLIB site and place it in this directory before replaying
the certificates. Its expected SHA-256 is recorded in `SHA256SUMS`.

Verify the downloaded model and retained local evidence with
`sha256sum -c SHA256SUMS` from this directory.
