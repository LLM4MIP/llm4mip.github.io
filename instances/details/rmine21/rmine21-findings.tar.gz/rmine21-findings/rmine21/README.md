# rmine21 — strict rounded incumbent and exact Lagrangian lower bound

Official MIPLIB page: <https://miplib.zib.de/instance_details_rmine21.html>

Official MPS: [download `rmine21.mps.gz`](https://miplib.zib.de/WebData/instances/rmine21.mps.gz)

## Status and bounds

`rmine21` is a minimization problem.  Its global optimum remains **open**: no
experiment reported here proves that the primal and lower bounds meet.

| evidence | value | claim supported |
|---|---:|---|
| strict feasible upper bound | `-10618.7507269999999491342` | exact original-MPS feasibility of the rounded solution |
| COPT 10-hour numeric lower bound | `-10674.8943` | strongest available floating-point global bound |
| portable exact global lower bound | `-10679.232567260660741` | independently replayable rational Lagrangian/closure certificate |

For a minimization problem, `LB <= OPT <= UB`; because the values are negative,
a larger lower bound and a smaller upper bound are stronger.  The COPT numeric
gap is `56.1435730000000508658` (about `0.528721%`).  Using only portable exact
evidence gives the certified interval

```text
-10679.232567260660741 <= OPT <= -10618.7507269999999491342
```

of width `60.4818402606607918658` (about `0.569576%`).  The COPT number is
tighter numerically, but it is deliberately not promoted to a portable exact
bound: the archived solver result has no independently checkable proof trace.

## Recovered structure

The original MPS has 162,547 binary variables, 1,441,651 rows, and 3,514,884
nonzeros.  It represents 9,261 mine blocks over 21 periods with cumulative
variables: `x_Bb_t = 1` means that block `b` has been extracted by the end of
period `t`.

The rows consist of 1,288,323 spatial precedence implications, 153,286
temporal monotonicity implications, and only 42 side constraints: two resource
capacities in each period.  Removing those 42 capacity rows leaves a binary
precedence-closure problem.  This is the structure used by the exact lower-bound
certificate rather than by a long generic branch-and-bound run.

The original MPS is not duplicated in this package.  Download it from the
[official MIPLIB link](https://miplib.zib.de/WebData/instances/rmine21.mps.gz)
and save it as `input/rmine21.mps.gz`.  Its expected SHA-256 is
`0a6366deda67e1fcf89ddfb5a5e131c4e7a2650a8be487f8c2e7f8878fb1c10b`.
The same value is recorded in [`input/SHA256SUMS`](input/SHA256SUMS).

## Strict rounded upper bound

The best public MIPLIB vector is a tolerance solution, not a mathematical 0/1
vector.  Direct 60-digit `Decimal` replay gives objective
`-10618.75083837231859101855752944528230055433`, but finds 89 nonintegral
entries, with maximum integrality error
`0.0000065541166170772910`.  It also has 152 exact row violations, each tiny;
the maximum is `5.0000000000012E-9`.  Therefore this tolerance vector cannot by
itself support a strict upper bound.

Every listed value was rounded to its nearest binary value and unlisted
variables were set to zero.  Rounding alone is not a feasibility proof.  The
result was subsequently substituted into all 1,441,651 rows of the original
MPS using 60-digit `Decimal` arithmetic.  The independent audit found:

| check | exact result |
|---|---:|
| row violations | `0` |
| bound violations | `0` |
| integrality violations | `0` |
| recomputed objective | `-10618.7507269999999491342` |

The rounding cost relative to the tolerance vector is only
`0.0001113723186418843575294452823`.  The rounded point also improves the
previous exactly audited public incumbent by `1.135325`.

The strict solution is
[`solutions/rmine21-best-rounded.sol`](solutions/rmine21-best-rounded.sol),
with SHA-256
`fbbd12686adeccbe2527735e15354d060ccf4d4a74c7924a1de7369a67ce9751`.
The two relevant audits are
[`artifacts/rmine21-best-tolerance-exact-audit.json`](artifacts/rmine21-best-tolerance-exact-audit.json)
and
[`artifacts/rmine21-best-rounded-exact-audit.json`](artifacts/rmine21-best-rounded-exact-audit.json).

## Portable exact lower bound

The 42 capacity rows were relaxed with nonnegative rational multipliers.  For
that fixed multiplier vector, the remaining binary problem is a minimum-weight
closure problem.  All finite MPS decimals and multipliers were converted to
exact fractions and then to one common integer scale.  The certificate stores
both a feasible integral maximum flow and a cut of exactly the same capacity,
thereby proving the closure-oracle value.  Combining that value with the exact
Lagrangian constant yields the global lower bound
`-10679.232567260660741`.

This claim does not depend on COPT or Gurobi tolerances.  The verifier checks the
MPS hash, multiplier signs, reconstructed network capacities, flow capacity and
conservation, flow/cut equality, and the final rational bound.  The archived
verification result has `verified: true`.

Evidence files:

- [`artifacts/rmine21-lp-lambda.json`](artifacts/rmine21-lp-lambda.json): the
  rationalized capacity multipliers;
- [`artifacts/rmine21-lp-cert.json.gz`](artifacts/rmine21-lp-cert.json.gz): the
  complete flow/cut witness and exact bound;
- [`artifacts/rmine21-lp-cert-verification.json`](artifacts/rmine21-lp-cert-verification.json):
  the compact replay result;
- [`scripts/exact_lagrangian_certificate.py`](scripts/exact_lagrangian_certificate.py):
  the solver-free generator and verifier.

To replay the existing certificate:

```sh
python scripts/exact_lagrangian_certificate.py verify \
  input/rmine21.mps.gz \
  artifacts/rmine21-lp-cert.json.gz
```

The strict rounded solution proves only the upper bound, and the exact
Lagrangian certificate proves only the lower bound.  Their remaining separation
is why no global-optimality claim is made.
