# Package manifest: fastxgemm-n3r21s3t6

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 118
Excluded source files: 1

## Included files

- `GUROBI_STRUCTURE_SUMMARY.md`
- `README.md`
- `REPORT.md`
- `REPRODUCE.md`
- `SHA256SUMS.txt`
- `artifacts/CONDITIONAL_SUPPORT_BOUNDS.md`
- `artifacts/IMPROVEMENT_REDUCTION.md`
- `artifacts/LB90_PROOF.md`
- `artifacts/LB93_PROOF.md`
- `artifacts/OFFICIAL_SUBMISSION_PROVENANCE.md`
- `artifacts/all_bilr_s5t6_children.json`
- `artifacts/author-mst-direct-audit.json`
- `artifacts/author-mst-strict-completion.json`
- `artifacts/author_mst_coefficient_radius2_scan.json`
- `artifacts/author_mst_exact_semantic_audit.json`
- `artifacts/author_mst_one_vector_scan.json`
- `artifacts/bilr_a_deletion_enumeration.json`
- `artifacts/bilr_coefficient_radius2_scan.json`
- `artifacts/bilr_conjugation_deletions_bound1.json`
- `artifacts/bilr_exact_decimal_mps_audit_2147.json`
- `artifacts/bilr_exact_semantic_audit_2147.json`
- `artifacts/bilr_fixed_support_improve.json`
- `artifacts/bilr_mps_completion_2147.json`
- `artifacts/bilr_one_vector_scan.json`
- `artifacts/bilr_r21_best_core.json`
- `artifacts/bilr_support_expansion_1_improve.json`
- `artifacts/classify_k30_high_sets.json`
- `artifacts/conditional_e1_lp_probe.json`
- `artifacts/diagonal-e-le1.json`
- `artifacts/diagonal-e2-k55.json`
- `artifacts/dp_verify_k30_support_symmetry.json`
- `artifacts/enumerate_k30_high_sets.json`
- `artifacts/exact_semantic_audit.json`
- `artifacts/fastxgemm-n3r21s3t6-lb90.mps.gz`
- `artifacts/fastxgemm-n3r21s3t6-lb93.mps.gz`
- `artifacts/fixed_author_support_improve.json`
- `artifacts/gurobi-fixed-pattern.json`
- `artifacts/gurobi-lb90-probe.json`
- `artifacts/gurobi-lb93-probe.json`
- `artifacts/gurobi-lp.json`
- `artifacts/gurobi-root.json`
- `artifacts/gurobi-structure-audit.json`
- `artifacts/lp_mps_equivalence.json`
- `artifacts/one_vector_scan.json`
- `artifacts/parent_lineage_audit.json`
- `artifacts/rank23_parent_transform_search.json`
- `artifacts/scan_exact_support_relaxation.json`
- `artifacts/strict_2168_audit.json`
- `artifacts/strict_feasibility_audit.json`
- `artifacts/support_expansion_1_improve.json`
- `artifacts/support_k30_necessary.ilp`
- `artifacts/support_k30_necessary.json`
- `artifacts/support_k30_necessary.mps.gz`
- `artifacts/target-pair-k55.json`
- `artifacts/three_vector_r1_each_exact.json`
- `artifacts/two_vector_r2_each_exact.json`
- `input/fastxgemm-n3r21s3t6-best.sol.gz`
- `logs/author-mst-strict-completion.log`
- `logs/bilr_fixed_support_improve.log`
- `logs/bilr_mps_completion_2147.log`
- `logs/bilr_support_expansion_1_improve.log`
- `logs/conditional_e1_lp_baseline.log`
- `logs/conditional_e1_lp_cut.log`
- `logs/diagonal-e-le1.log`
- `logs/diagonal-e2-k55.log`
- `logs/exact_support_k30.log`
- `logs/exact_support_k31.log`
- `logs/fixed_author_support_improve.log`
- `logs/gurobi-fixed-pattern.log`
- `logs/gurobi-lb90-lp.log`
- `logs/gurobi-lb90-root.log`
- `logs/gurobi-lp.log`
- `logs/gurobi-root.log`
- `logs/lb93-lp.log`
- `logs/lb93-root.log`
- `logs/strict_2168_audit.txt`
- `logs/strict_feasibility_audit.txt`
- `logs/support_expansion_1_improve.log`
- `logs/support_k30_necessary.log`
- `logs/target-pair-k55.log`
- `result_summary.json`
- `scripts/audit_lp_mps_equivalence.py`
- `scripts/audit_parent_lineage.py`
- `scripts/build_and_probe_lb90.py`
- `scripts/build_and_probe_lb93.py`
- `scripts/build_result_summary.py`
- `scripts/classify_k30_high_sets.py`
- `scripts/coefficient_radius2_scan.py`
- `scripts/complete_author_mst.py`
- `scripts/complete_external_r21_candidate.py`
- `scripts/dp_verify_k30_support.py`
- `scripts/dp_verify_k30_support_symmetry.py`
- `scripts/enumerate_all_bilr_s5t6_children.py`
- `scripts/enumerate_bilr_a_deletions.py`
- `scripts/enumerate_k30_high_sets.py`
- `scripts/exact_semantic_audit.py`
- `scripts/gurobi_bilr_support_expansion.py`
- `scripts/gurobi_fixed_bilr_support_improve.py`
- `scripts/gurobi_fixed_support_improve.py`
- `scripts/gurobi_probe.py`
- `scripts/gurobi_structure_audit.py`
- `scripts/gurobi_support_expansion_improve.py`
- `scripts/make_sha256_manifest.py`
- `scripts/normalize_and_audit_author_mst.py`
- `scripts/one_vector_scan.py`
- `scripts/probe_conditional_support_cut.py`
- `scripts/rank23_parent_transform_search.py`
- `scripts/repair_and_audit_incumbent.py`
- `scripts/run_exact_decimal_audit.py`
- `scripts/scan_exact_support_relaxation.py`
- `scripts/search_bilr_conjugation_deletions.py`
- `scripts/structured_improvement_search.py`
- `scripts/support_k30_necessary.py`
- `scripts/three_vector_r1_each_exact.py`
- `scripts/two_vector_r2_each_exact.py`
- `scripts/verify_sha256_manifest.py`
- `solutions/author-2017-strict-2168.sol`
- `solutions/external-bilr-derived-strict-2147.sol`

## Excluded files

- `input/fastxgemm-n3r21s3t6.mps.gz (3853878 bytes; raw benchmark input; sha256 210e76e09285ab346c1ae92155d5fc88efeeaafe96a4b5944b54011fa0103fba)`
