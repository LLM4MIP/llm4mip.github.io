# Reproduce `fastxgemm-n3r21s3t6` continuation

Run from this instance directory with Python 3.13. Official-MPS completion and
bound probes additionally require Gurobi 13.0.2.

## Rebuild the external-derived 2147 solution

```powershell
python .\scripts\enumerate_bilr_a_deletions.py `
  ..\fastxgemm-n3r23s5t6\artifacts\external-audit\ballard-laderman-z3-audit.json `
  --output-json .\artifacts\bilr_a_deletion_enumeration.json `
  --best-core-json .\artifacts\bilr_r21_best_core.json

python .\scripts\complete_external_r21_candidate.py `
  .\input\fastxgemm-n3r21s3t6.mps.gz `
  .\artifacts\bilr_r21_best_core.json `
  --solution .\solutions\external-bilr-derived-strict-2147.sol `
  --report .\artifacts\bilr_mps_completion_2147.json `
  --log .\logs\bilr_mps_completion_2147.log
```

Expected: `E=2`, `K=49`, objective 2147, and zero official-MPS violations.

## Verify the lower-bound proof cases

```powershell
python .\scripts\classify_k30_high_sets.py `
  --output-json .\artifacts\classify_k30_high_sets.json

python .\scripts\dp_verify_k30_support_symmetry.py `
  --output-json .\artifacts\dp_verify_k30_support_symmetry.json `
  --workers 1
```

Expected: 12 symmetry representatives cover all 84 high-row sets and all 12
are unreachable. `--workers 1` is the portable setting; a larger worker count
may be used where multiprocessing is available.

## Build and probe the LB93 model

```powershell
python .\scripts\build_and_probe_lb93.py `
  .\input\fastxgemm-n3r21s3t6.mps.gz `
  --solution .\solutions\external-bilr-derived-strict-2147.sol `
  --output-model .\artifacts\fastxgemm-n3r21s3t6-lb93.mps.gz `
  --output-json .\artifacts\gurobi-lb93-probe.json `
  --lp-log .\logs\lb93-lp.log `
  --root-log .\logs\lb93-root.log
```

Expected LP optimum and root bound: 93.

## Recheck the strict upper bound

The archived audits are:

- `artifacts/bilr_mps_completion_2147.json`;
- `artifacts/bilr_exact_decimal_mps_audit_2147.json`;
- `artifacts/bilr_exact_semantic_audit_2147.json`.

They must agree on `E=2`, `K=49`, objective 2147, and zero official-MPS or
tensor violations. `result_summary.json` cross-checks the headline fields.

## Rebuild machine summaries and checksums

From the repository root, use the Git-index mode so hashes describe the exact
published blobs independently of checkout line-ending settings:

```powershell
python .\instances\fastxgemm-n3r21s3t6\scripts\build_result_summary.py --git-index
python .\instances\fastxgemm-n3r21s3t6\scripts\make_sha256_manifest.py `
  .\instances\fastxgemm-n3r21s3t6 `
  .\instances\fastxgemm-n3r21s3t6\SHA256SUMS.txt --git-index
python .\instances\fastxgemm-n3r21s3t6\scripts\verify_sha256_manifest.py `
  .\instances\fastxgemm-n3r21s3t6\SHA256SUMS.txt --git-index
```
