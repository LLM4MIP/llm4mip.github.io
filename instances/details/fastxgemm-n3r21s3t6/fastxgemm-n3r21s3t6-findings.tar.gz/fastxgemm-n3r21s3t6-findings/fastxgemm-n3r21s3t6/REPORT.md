#  `fastxgemm-n3r21s3t6` follow-up report

Date of release: 2026 -09 -09

##  Strict Conclusions and Attributes

```text
Old project area:[90,2168]
New strict range:[93,2147]
```

The upper bound 2147 is derived from the external BILR 2018 `S_Lader-Z3` construction by deleting its two singleton
fixed A, constructed from `R=21,S=3,T=6`'s `E=2,K=49`.
**external-derived**, counted as a project primal improvement based on external work under the updated 2026-09-16 convention, without claiming authorship of the parent construction. Laurent Sorber's 2017 start with value 2168
It is still preserved as a historical baseline, but has been upgraded by 2147 strict.

The lower bound 93 is a new global proof from this project. The gap `93<2147` remains open, so this instance cannot be claimed
optimal。

## external-derived UB 2147

After deleting the two singleton A items of the BILR parent, the exact volume is released.

```text
E = 2
K = 49
full UVW support = 147
objective = 1000*2 + 147 = 2147
```

The two errors are the missing unit tensor entries `(4,4,4)` and `(8,8,8)`.
Removing two combinations of 10 types in the item, the complete enumeration indicates that 2147 is the only optimal value in the finite set;
The three explicit S5T6 constituents of the paper, 30, removed two children to do the same audit, three parent
The best values for each are 2147, 14174, 2180.

The strictly feasible solution fixes all 378 POS/NEG integer encodings of the official MPS. Gurobi 13.0.2, on the fixed
The pattern returns objective/bound 2147, followed by the decimal checker for 219,368 official constraint
row by row exact replay, row, boundary and integrality default is 0; independent integer tensor expansion also returns
`E=2,K=49`. Thus 2147 is strictly feasible primal bound, but the fixed-pattern `OPTIMAL` is not complete.
The global optimality of MIP.

## global LB 93

For the exact structure, each factor row corresponds to the rank-3 target slice and the degree is at least 3;
Degree-3 tight rows in the same mode use distinct rank positions. The previous LB90 excludes
`K<=29`. If `K=30`, the scale divides by the total

```text
(6,3,3,3,3,3,3,3,3),
(5,4,3,3,3,3,3,3,3),
(4,4,4,3,3,3,3,3,3).
```

The first type has eight tight rows and requires `8*3=24>21` rank columns, so it's impossible.
The seven tight rows of the second pattern use all 21 rank columns; intersection conditions across the three modes force
Each factor column is a singleton, followed by `K=21` instead of 30.

The six tight rows occupy the 18 core vectors, the remaining three deficient vectors must be
In three degree- 4 high rows, the primal bound of the 12 sequence of incidences per orbit indicates that it reaches
12 can only use three different B/C/D orbits, each lacking a tight coordinate; each has an equal number.
The multiplicity of situations on high rows is `(2,1,1)`. Three doubled points must be different.
In the same way, the sum is `(4,4,4)`.

The final finite classification checks all `C(9,3)=84` high-row sets and, under simultaneous S3 relabeling and
Transpose is compressed to a symmetrical class 12. Each high-row set allows at least one doubled point.
The exact `K=30` does not exist, and the exact branch does.
`K>=31`, raw support at least 93.

The second complete non-solver bitmask DP represents the 12 symmetry for each test, covering the entire 84.
In high-row sets, 12 representatives are unavailable; canonical payload SHA- 256 is
`aa8b34948c205703f78ab4a8a0a291bf4b37e374a666e59dbd2f8e20dd811917`。

The official support floor 84 with the residual sum of at least 1 combined with the inexact point is the global integer.
Effective cut:

```text
sum(ABS_ALT) + 9*sum(RESIDUAL) >= 93.
```

This line of enhanced MPS contains 567 coefficients 1, 729 coefficients 9, RHS 93, and does not add a variable.
After reading, the LP optimum is 93.00000000000038 and the root bound is 93.00000000000003.
Numerical probe verification The mathematical effectiveness of this test comes from the above proof and finite audit.

##  Continue to improve your search

The results of the finite experiments around the 2147 core are as follows:

| Search area |  result | Allowing conclusions |
|---|---|---|
| All `21*3^9=413,343` single whole vector replacement | Not less than 2147 | Single vector locally optimal |
|  coefficient Hamming radius 1/2  | 378 / 71,064 A nominal moves, without improvement | Radius - 2 Local results |
| In the 49 support locations, the objective `<=2146` is deleted or changed. | Gurobi Full `INFEASIBLE` |  fixed -support certificate |
| The above freedoms allow for up to one new support location. | 300 seconds, 47,178 nodes, no incumbent, `TIME_LIMIT` | There are no global conclusions |
| 480 a ternary-admissible with boundary conjugates 4,800 a double A deleted | The best way to do this is 2147. | Only covers the finite orbit |

The support-only necessary-condition MIP is infeasible at `K=30`, while `K=31` is only feasible in that
Support relaxation is feasible; this is not an exact tensor decomposition.
Therefore, continuing to improve the lower bound cannot only repeat the current line-support argument; it is necessary to add symbol compatibility or more directly.
Continuing to lower the primal bound should give priority to at least two new support locations.
Multi-vector/orbit simultaneous replacement, or gauge transformations beyond the audited small coefficient box.

##  Published quality

The strict interval of the official integer MIP can be claimed to be `[93,2147]`, where LB93 is the project proof and UB2147
is an external-derived construction that passes the official MPS check and exact tensor audit. It cannot be claimed that 2147
GPT constructed from scratch, and cannot claim that the subject is optimal. All TIME_LIMIT branches are reserved for clarity only.
There is a lot of negative search evidence.
