#!/usr/bin/env python3
"""Search/prove improvement with a bounded number of new support locations."""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB

import exact_semantic_audit as semantic


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path)
    parser.add_argument("start", type=Path)
    parser.add_argument("--max-new-support", type=int, default=1)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--solution", type=Path)
    parser.add_argument("--time-limit", type=float, default=300.0)
    args = parser.parse_args()
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.log.parent.mkdir(parents=True, exist_ok=True)
    if args.solution:
        args.solution.parent.mkdir(parents=True, exist_ok=True)

    started = time.perf_counter()
    start_values, _ = semantic.read_solution(args.start)
    model = gp.read(str(args.model))
    model.Params.LogFile = str(args.log)
    model.Params.Threads = 2
    model.Params.TimeLimit = args.time_limit
    model.Params.FeasibilityTol = 1e-9
    model.Params.IntFeasTol = 1e-9
    model.Params.OptimalityTol = 1e-9
    model.Params.NumericFocus = 3
    model.Params.Presolve = 2
    model.Params.MIPFocus = 1

    outside_support = []
    incumbent_support = 0
    for letter, width in semantic.BLOCK_WIDTHS.items():
        for row in range(9):
            for column in range(width):
                pos_name = f"POS_{letter}_{row}_{column}"
                neg_name = f"NEG_{letter}_{row}_{column}"
                if round(start_values[pos_name]) == 0 and round(start_values[neg_name]) == 0:
                    outside_support.extend((model.getVarByName(pos_name), model.getVarByName(neg_name)))
                else:
                    incumbent_support += 1

    diagonal_residuals = []
    non_diagonal_fixed = 0
    for i in range(9):
        for j in range(9):
            for k in range(9):
                residual = model.getVarByName(f"RESIDUAL_{i}_{j}_{k}")
                if i == j == k:
                    diagonal_residuals.append(residual)
                else:
                    residual.UB = 0.0
                    non_diagonal_fixed += 1

    model.addConstr(
        gp.quicksum(outside_support) <= args.max_new_support,
        name="MAX_NEW_UNDERLYING_SUPPORT",
    )
    model.addConstr(gp.quicksum(diagonal_residuals) <= 2, name="IMPROVE_DIAGONAL_E_LE_2")
    model.addConstr(model.getObjective() <= 2165, name="STRICT_IMPROVEMENT_LATTICE_CAP")
    model.update()
    model.read(str(args.start))
    model.optimize()

    result = {
        "instance": "fastxgemm-n3r21s3t6",
        "scope": "arbitrary resigning/deletion plus bounded activations outside author support",
        "incumbent_support_locations": incumbent_support,
        "outside_support_locations": len(outside_support) // 2,
        "max_new_support_locations": args.max_new_support,
        "non_diagonal_residuals_fixed_zero": non_diagonal_fixed,
        "objective_cap": 2165,
        "status_code": int(model.Status),
        "status": {
            GRB.OPTIMAL: "OPTIMAL",
            GRB.INFEASIBLE: "INFEASIBLE",
            GRB.TIME_LIMIT: "TIME_LIMIT",
            GRB.INTERRUPTED: "INTERRUPTED",
        }.get(model.Status, str(model.Status)),
        "solution_count": int(model.SolCount),
        "runtime_seconds": float(model.Runtime),
        "wall_seconds": time.perf_counter() - started,
        "node_count": float(model.NodeCount),
        "best_bound": (
            float(model.ObjBound)
            if model.IsMIP and math.isfinite(float(model.ObjBound))
            else None
        ),
        "best_objective": float(model.ObjVal) if model.SolCount else None,
    }
    if args.solution and model.SolCount:
        model.write(str(args.solution))
    args.json.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
