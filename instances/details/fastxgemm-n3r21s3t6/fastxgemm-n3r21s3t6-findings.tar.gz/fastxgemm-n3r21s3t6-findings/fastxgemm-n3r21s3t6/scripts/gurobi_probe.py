#!/usr/bin/env python3
"""Bounded Gurobi probes: LP relaxation, fixed incumbent pattern, or root node."""

from __future__ import annotations

import argparse
import gzip
import json
import math
from pathlib import Path

import gurobipy as gp


def read_solution(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix == ".gz" else open
    values: dict[str, float] = {}
    with opener(path, "rt", encoding="utf-8") as stream:
        for raw in stream:
            fields = raw.strip().split()
            if len(fields) < 2 or fields[0].startswith("#") or fields[0].startswith("="):
                continue
            values[fields[0]] = float(fields[1])
    return values


def finite(value: float) -> float | None:
    return float(value) if math.isfinite(float(value)) else None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("lp", "fixed-pattern", "root"))
    parser.add_argument("mps", type=Path)
    parser.add_argument("--solution", type=Path)
    parser.add_argument("--time-limit", type=float, default=120.0)
    parser.add_argument("--threads", type=int, default=8)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.log.parent.mkdir(parents=True, exist_ok=True)

    original = gp.read(str(args.mps))
    fixed_integer_count = 0
    rounded_integer_ones = None

    if args.mode == "lp":
        model = original.relax()
        model.Params.Method = 1
    elif args.mode == "fixed-pattern":
        if args.solution is None:
            raise SystemExit("--solution is required for fixed-pattern")
        incumbent = read_solution(args.solution)
        rounded_integer_ones = 0
        for variable in original.getVars():
            if variable.VType in {gp.GRB.BINARY, gp.GRB.INTEGER}:
                fixed = round(incumbent[variable.VarName])
                variable.LB = fixed
                variable.UB = fixed
                fixed_integer_count += 1
                rounded_integer_ones += int(fixed == 1)
        original.update()
        model = original.relax()
        model.Params.Method = 1
        model.Params.FeasibilityTol = 1e-9
        model.Params.OptimalityTol = 1e-9
        model.Params.NumericFocus = 3
    else:
        model = original
        model.Params.NodeLimit = 0
        model.Params.MIPFocus = 3
        model.Params.Symmetry = 2
        model.Params.NumericFocus = 2

    model.Params.Threads = args.threads
    model.Params.TimeLimit = args.time_limit
    model.Params.Presolve = 2
    model.Params.LogFile = str(args.log)
    model.optimize()

    status_names = {
        gp.GRB.LOADED: "LOADED",
        gp.GRB.OPTIMAL: "OPTIMAL",
        gp.GRB.INFEASIBLE: "INFEASIBLE",
        gp.GRB.INF_OR_UNBD: "INF_OR_UNBD",
        gp.GRB.UNBOUNDED: "UNBOUNDED",
        gp.GRB.CUTOFF: "CUTOFF",
        gp.GRB.ITERATION_LIMIT: "ITERATION_LIMIT",
        gp.GRB.NODE_LIMIT: "NODE_LIMIT",
        gp.GRB.TIME_LIMIT: "TIME_LIMIT",
        gp.GRB.SOLUTION_LIMIT: "SOLUTION_LIMIT",
        gp.GRB.INTERRUPTED: "INTERRUPTED",
        gp.GRB.NUMERIC: "NUMERIC",
        gp.GRB.SUBOPTIMAL: "SUBOPTIMAL",
        gp.GRB.INPROGRESS: "INPROGRESS",
        gp.GRB.USER_OBJ_LIMIT: "USER_OBJ_LIMIT",
        gp.GRB.WORK_LIMIT: "WORK_LIMIT",
        gp.GRB.MEM_LIMIT: "MEM_LIMIT",
    }
    report = {
        "mode": args.mode,
        "gurobi_version": ".".join(map(str, gp.gurobi.version())),
        "inputs": {
            "mps": str(args.mps),
            "solution": str(args.solution) if args.solution else None,
        },
        "parameters": {
            "TimeLimit": args.time_limit,
            "Threads": args.threads,
            "Presolve": 2,
            "Method": int(model.Params.Method),
            "FeasibilityTol": float(model.Params.FeasibilityTol),
            "OptimalityTol": float(model.Params.OptimalityTol),
            "NumericFocus": int(model.Params.NumericFocus),
            "NodeLimit": finite(model.Params.NodeLimit),
            "MIPFocus": int(model.Params.MIPFocus),
            "Symmetry": int(model.Params.Symmetry),
        },
        "fixed_integer_count": fixed_integer_count,
        "rounded_integer_ones": rounded_integer_ones,
        "status": int(model.Status),
        "status_name": status_names.get(model.Status, "UNKNOWN"),
        "runtime_seconds": float(model.Runtime),
        "work": float(model.Work),
        "simplex_iterations": float(model.IterCount),
        "barrier_iterations": int(model.BarIterCount),
        "node_count": float(model.NodeCount),
        "solution_count": int(model.SolCount),
        "objective": finite(model.ObjVal) if model.SolCount else None,
        "objective_bound": finite(model.ObjBound) if model.IsMIP else None,
        "mip_gap": finite(model.MIPGap) if model.IsMIP and model.SolCount else None,
        "model_dimensions": {
            "variables": model.NumVars,
            "constraints": model.NumConstrs,
            "nonzeros": model.NumNZs,
        },
    }
    args.output.write_text(
        json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
