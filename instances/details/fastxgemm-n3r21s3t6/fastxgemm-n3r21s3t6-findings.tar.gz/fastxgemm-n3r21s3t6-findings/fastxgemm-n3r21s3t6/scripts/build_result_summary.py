#!/usr/bin/env python3
"""Assemble and cross-check the continuation's machine-readable result summary."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from pathlib import Path


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def git_output(repository: Path, *args: str) -> bytes:
    return subprocess.run(
        ["git", *args],
        cwd=repository,
        check=True,
        stdout=subprocess.PIPE,
    ).stdout


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--directory",
        type=Path,
        default=Path(__file__).resolve().parent.parent,
        help="published instance directory (default: parent of this scripts directory)",
    )
    parser.add_argument("--output", type=Path)
    parser.add_argument(
        "--git-index",
        action="store_true",
        help="hash selected artifacts from staged Git blobs",
    )
    args = parser.parse_args()
    directory = args.directory.resolve()
    artifacts = directory / "artifacts"
    output = args.output.resolve() if args.output else directory / "result_summary.json"
    repository = None
    if args.git_index:
        repository = Path(
            git_output(directory, "rev-parse", "--show-toplevel")
            .decode("utf-8")
            .strip()
        ).resolve()

    def selected_sha256(relative: str) -> str:
        path = directory / relative
        if repository is None:
            return sha256(path)
        repository_relative = path.relative_to(repository).as_posix()
        return hashlib.sha256(
            git_output(repository, "show", f":{repository_relative}")
        ).hexdigest()

    completion = load(artifacts / "bilr_mps_completion_2147.json")
    decimal_audit = load(artifacts / "bilr_exact_decimal_mps_audit_2147.json")
    semantic = load(artifacts / "bilr_exact_semantic_audit_2147.json")
    deletion = load(artifacts / "bilr_a_deletion_enumeration.json")
    all_children = load(artifacts / "all_bilr_s5t6_children.json")
    one_vector = load(artifacts / "bilr_one_vector_scan.json")
    radius = load(artifacts / "bilr_coefficient_radius2_scan.json")
    fixed_support = load(artifacts / "bilr_fixed_support_improve.json")
    expansion = load(artifacts / "bilr_support_expansion_1_improve.json")
    conjugation = load(artifacts / "bilr_conjugation_deletions_bound1.json")
    classify = load(artifacts / "classify_k30_high_sets.json")
    dp = load(artifacts / "dp_verify_k30_support_symmetry.json")
    cut = load(artifacts / "gurobi-lb93-probe.json")
    support_scan = load(artifacts / "scan_exact_support_relaxation.json")

    exact = semantic["exact_from_binary_pattern"]
    parsed_decimal = decimal_audit["parsed"]
    assertions = {
        "upper_objective_2147": completion["solve"]["objective"] == 2147 == exact["objective_1000E_plus_3K"],
        "upper_E2_K49": exact["E_tensor_l1_error"] == 2 and exact["K_underlying_ABCD_support"] == 49,
        "official_mps_zero_exact_row_violations": parsed_decimal["exact_row_violations"] == 0,
        "official_mps_zero_integrality_violations": parsed_decimal["exact_integrality_violations"] == 0,
        "all_84_classified": classify["all_84_high_sets_checked_directly"] and classify["covered_high_sets"] == 84,
        "d1_max_four_asserted": classify["all_84_deficit_one_maximum_at_most_four"],
        "no_three_doubled_points": classify["all_classes_exclude_three_distinct_doubled_points"],
        "solver_free_dp_all_unreachable": dp["all_84_high_sets_unreachable"] and dp["reachable_representative_count"] == 0,
        "cut_signature": (
            cut["cut"]["rhs"] == 93
            and cut["cut"]["coefficient_counts"] == {"1": 567, "9": 729}
            and cut["cut"]["family_counts"] == {"ABS_ALT": 567, "OTHER": 0, "RESIDUAL": 729}
        ),
        "cut_adds_no_integer_variables": cut["integer_projection_check"]["new_integer_variables"] == 0,
        "lp_bound_93": abs(cut["lp_probe"]["objective"] - 93) <= 1e-9,
        "root_bound_93": abs(cut["root_probe"]["objective_bound"] - 93) <= 1e-9,
        "fixed_support_complete_infeasible": fixed_support["status"] == "INFEASIBLE",
    }
    if not all(assertions.values()):
        raise AssertionError({key: value for key, value in assertions.items() if not value})

    k30 = next(case for case in support_scan["cases"] if case["K"] == 30)
    k31 = next(case for case in support_scan["cases"] if case["K"] == 31)
    report_bests = [report["best_child_objective"] for report in all_children["reports"]]
    selected_artifacts = [
        "README.md",
        "artifacts/LB93_PROOF.md",
        "solutions/external-bilr-derived-strict-2147.sol",
        "artifacts/bilr_mps_completion_2147.json",
        "artifacts/bilr_exact_decimal_mps_audit_2147.json",
        "artifacts/bilr_exact_semantic_audit_2147.json",
        "artifacts/bilr_r21_best_core.json",
        "scripts/classify_k30_high_sets.py",
        "artifacts/classify_k30_high_sets.json",
        "scripts/dp_verify_k30_support.py",
        "scripts/dp_verify_k30_support_symmetry.py",
        "artifacts/dp_verify_k30_support_symmetry.json",
        "scripts/build_and_probe_lb93.py",
        "artifacts/fastxgemm-n3r21s3t6-lb93.mps.gz",
        "artifacts/gurobi-lb93-probe.json",
        "artifacts/bilr_fixed_support_improve.json",
        "artifacts/bilr_support_expansion_1_improve.json",
    ]
    result = {
        "instance": "fastxgemm-n3r21s3t6",
        "date": "2026-09-09",
        "previous_published_interval": {"global_lower_bound": 90, "strict_upper_bound": 2168},
        "improved_interval": {"global_lower_bound": 93, "strict_upper_bound": 2147},
        "strict_upper_bound": {
            "objective": 2147,
            "E": exact["E_tensor_l1_error"],
            "K": exact["K_underlying_ABCD_support"],
            "full_factor_support": exact["full_UVW_support"],
            "errors": semantic["errors"],
            "attribution": completion["attribution"],
            "not_gpt_original": True,
            "official_mps_fixed_pattern_status": completion["solve"]["status_name"],
            "fixed_pattern_status_is_not_global_optimality": True,
            "decimal_mps_audit": parsed_decimal,
        },
        "global_lower_bound": {
            "objective_lower_bound": 93,
            "exact_core_support_lower_bound": 31,
            "valid_integer_cut": "sum(ABS_ALT) + 9*sum(RESIDUAL) >= 93",
            "proof": "artifacts/LB93_PROOF.md",
            "finite_classification": {
                "high_sets": classify["covered_high_sets"],
                "symmetry_classes": classify["symmetry_class_count"],
                "all_d1_incidence_bounds_at_most_four": classify["all_84_deficit_one_maximum_at_most_four"],
                "all_classes_exclude_three_distinct_doubled_points": classify["all_classes_exclude_three_distinct_doubled_points"],
            },
            "solver_free_dp": {
                "representatives": dp["representative_count"],
                "covered_high_sets": dp["covered_high_sets"],
                "reachable_representatives": dp["reachable_representative_count"],
                "reports_sha256": dp["reports_sha256"],
                "elapsed_seconds": dp["elapsed_seconds"],
            },
            "official_mps_probe": {
                "lp_status": cut["lp_probe"]["status_name"],
                "lp_objective": cut["lp_probe"]["objective"],
                "root_status": cut["root_probe"]["status_name"],
                "root_bound": cut["root_probe"]["objective_bound"],
                "row": cut["cut"],
            },
            "support_relaxation_boundary": {
                "K30_status": k30["status_name"],
                "K31_status": k31["status_name"],
                "K31_is_only_a_relaxation_witness": True,
            },
        },
        "scoped_improvement_searches": {
            "two_A_deletions_from_selected_parent": {
                "cases": deletion["case_count"],
                "best": deletion["best_objective"],
            },
            "two_A_deletions_all_three_explicit_BILR_cores": {
                "cases": all_children["case_count"],
                "per_core_best": report_bests,
            },
            "single_vector_replacement": {
                "candidates": one_vector["total_candidates"],
                "strict_improvement_found": one_vector["strict_improvement_found"],
            },
            "coefficient_hamming_radius_1_2": {
                "counts": radius["radius_counts"],
                "strict_improvement_found": radius["strict_improvement_found"],
            },
            "fixed_support_objective_at_most_2146": {
                "status": fixed_support["status"],
                "residual_variables_additionally_fixed": fixed_support["residual_variables_additionally_fixed"],
                "nodes": fixed_support["node_count"],
            },
            "at_most_one_new_support_objective_at_most_2146": {
                "status": expansion["status"],
                "solution_count": expansion["solution_count"],
                "runtime_seconds": expansion["runtime_seconds"],
                "nodes": expansion["node_count"],
                "conclusion": "unresolved: no solution found, but time limit is not an infeasibility proof",
            },
            "bounded_conjugation_then_deletion": {
                "entry_bound": conjugation["entry_bound"],
                "primitive_projective_representatives": conjugation["primitive_projective_representatives_checked"],
                "ternary_admissible_representatives": conjugation["ternary_projectively_admissible_representatives"],
                "deletion_children": conjugation["r21_deletion_children_checked"],
                "best": conjugation["best_objective"],
                "not_global_over_PGL3": True,
            },
        },
        "failed_or_non_global_boundaries": [
            "Fixed-pattern OPTIMAL is not full-MIP optimality.",
            "The one-new-support run timed out and is unresolved.",
            "Bounded conjugation searches do not cover all of PGL(3).",
            "The 84-case Gurobi enumeration had 80 timeouts and is not used in the LB93 proof.",
            "K=31 is feasible only in the support relaxation, not certified as an exact tensor decomposition.",
        ],
        "cross_checks": assertions,
        "selected_artifact_sha256": {
            name: selected_sha256(name) for name in selected_artifacts
        },
    }
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({
        "interval": result["improved_interval"],
        "cross_checks_passed": sum(assertions.values()),
        "cross_checks_total": len(assertions),
        "selected_artifacts": len(selected_artifacts),
        "hash_source": "git-index" if args.git_index else "working-tree",
        "output": str(output),
    }, indent=2))


if __name__ == "__main__":
    main()
