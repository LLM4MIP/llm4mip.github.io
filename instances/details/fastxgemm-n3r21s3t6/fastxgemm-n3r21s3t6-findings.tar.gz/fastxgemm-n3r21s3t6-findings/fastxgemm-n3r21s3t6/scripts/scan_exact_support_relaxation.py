#!/usr/bin/env python3
"""Scan exact-support values with the tight-slice necessary-condition model.

For each fixed K this model keeps only support incidence, row-rank lower
bounds, nonzero columns, and implications forced by rows of degree exactly 3.
An INFEASIBLE status rules out that K for an exact decomposition.  A feasible
witness is only a witness for the relaxation.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import gurobipy as gp

from support_k30_necessary import allowed_opposite, core_maps


ROWS = tuple(range(9))
POSITIONS = tuple(range(21))


def finite(value: float) -> float | None:
    return float(value) if math.isfinite(float(value)) else None


def solve_k(k_value: int, time_limit: float, threads: int, log: Path) -> dict:
    maps = core_maps()
    model = gp.Model(f"r21_exact_support_necessary_k{k_value}")
    x = model.addVars(POSITIONS, ROWS, vtype=gp.GRB.BINARY, name="SUPPORT")
    tight = model.addVars(ROWS, vtype=gp.GRB.BINARY, name="DEGREE3")

    model.addConstr(gp.quicksum(x[q, i] for q in POSITIONS for i in ROWS) == k_value)
    for i in ROWS:
        degree = gp.quicksum(x[q, i] for q in POSITIONS)
        model.addConstr(degree >= 4 - tight[i], name=f"DEGREE_LOWER_{i}")
        model.addConstr(degree <= 3 + 18 * (1 - tight[i]), name=f"DEGREE3_UPPER_{i}")
    for q in POSITIONS:
        model.addConstr(gp.quicksum(x[q, i] for i in ROWS) >= 1, name=f"COLUMN_NONZERO_{q}")

    implication_count = 0
    for primary_mode in ("U", "V", "W"):
        for i in ROWS:
            for p in POSITIONS:
                primary_q = maps[primary_mode][p]
                for opposite_mode, allowed in allowed_opposite(primary_mode, i).items():
                    opposite_q = maps[opposite_mode][p]
                    for j in ROWS:
                        if j not in allowed:
                            model.addConstr(
                                x[primary_q, i] + x[opposite_q, j] <= 2 - tight[i]
                            )
                            implication_count += 1

    model.setObjective(0.0)
    model.Params.TimeLimit = time_limit
    model.Params.Threads = threads
    model.Params.Presolve = 2
    model.Params.Symmetry = 2
    model.Params.MIPFocus = 1
    model.Params.SolutionLimit = 1
    model.Params.LogFile = str(log)
    model.optimize()

    witness = None
    if model.SolCount:
        row_degrees = [sum(x[q, i].X > 0.5 for q in POSITIONS) for i in ROWS]
        witness = {
            "row_degrees": row_degrees,
            "degree3_rows": [i for i, degree in enumerate(row_degrees) if degree == 3],
            "core_column_supports": [
                [i for i in ROWS if x[q, i].X > 0.5] for q in POSITIONS
            ],
        }
    return {
        "K": k_value,
        "status": int(model.Status),
        "status_name": {
            gp.GRB.OPTIMAL: "OPTIMAL",
            gp.GRB.INFEASIBLE: "INFEASIBLE",
            gp.GRB.TIME_LIMIT: "TIME_LIMIT",
            gp.GRB.SOLUTION_LIMIT: "SOLUTION_LIMIT",
        }.get(model.Status, str(model.Status)),
        "runtime_seconds": float(model.Runtime),
        "work": float(model.Work),
        "nodes": float(model.NodeCount),
        "solutions": int(model.SolCount),
        "bound": finite(model.ObjBound),
        "tight_slice_implications": implication_count,
        "log": str(log),
        "witness": witness,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--k-min", type=int, default=30)
    parser.add_argument("--k-max", type=int, default=40)
    parser.add_argument("--time-limit", type=float, default=120.0)
    parser.add_argument("--threads", type=int, default=8)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--log-dir", type=Path, required=True)
    args = parser.parse_args()
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.log_dir.mkdir(parents=True, exist_ok=True)

    cases = []
    for k_value in range(args.k_min, args.k_max + 1):
        case = solve_k(
            k_value,
            args.time_limit,
            args.threads,
            args.log_dir / f"exact_support_k{k_value}.log",
        )
        cases.append(case)
        print(json.dumps({key: case[key] for key in ("K", "status_name", "runtime_seconds", "nodes", "solutions")}), flush=True)
        if case["solutions"]:
            break

    result = {
        "scope": (
            "Support-only necessary conditions for exact ternary cyclic S=3,T=6,R=21 "
            "decompositions. Infeasible K values are globally excluded for that exact branch; "
            "a feasible support witness need not admit signs or tensor reconstruction."
        ),
        "gurobi_version": ".".join(map(str, gp.gurobi.version())),
        "requested_range": [args.k_min, args.k_max],
        "cases": cases,
    }
    args.output_json.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
