#!/usr/bin/env python3
"""Strictly complete and audit the author's R=21 MIP start on the MIPLIB MPS."""

from __future__ import annotations

import argparse
import collections
import json
import math
from pathlib import Path

import gurobipy as gp
import numpy as np


def parse_mst(path: Path) -> dict[str, float]:
    values: dict[str, float] = {}
    with path.open("r", encoding="utf-8") as stream:
        for raw in stream:
            fields = raw.strip().split()
            if len(fields) >= 2 and not fields[0].startswith(("#", "=")):
                values[fields[0]] = float(fields[1])
    return values


def constraint_violations(model: gp.Model, x: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    matrix = model.getA().tocsr()
    activity = matrix.dot(x)
    constraints = model.getConstrs()
    violation = np.zeros(model.NumConstrs, dtype=float)
    for idx, constraint in enumerate(constraints):
        if constraint.Sense == "<":
            violation[idx] = max(0.0, activity[idx] - constraint.RHS)
        elif constraint.Sense == ">":
            violation[idx] = max(0.0, constraint.RHS - activity[idx])
        else:
            violation[idx] = abs(activity[idx] - constraint.RHS)
    return activity, violation


def audit(model: gp.Model, x: np.ndarray) -> dict:
    variables = model.getVars()
    activity, row_violation = constraint_violations(model, x)
    lb = np.array([v.LB for v in variables], dtype=float)
    ub = np.array([v.UB for v in variables], dtype=float)
    bound_violation = np.maximum(np.maximum(lb - x, 0.0), np.maximum(x - ub, 0.0))
    int_indices = np.array(
        [i for i, v in enumerate(variables) if v.VType in {gp.GRB.BINARY, gp.GRB.INTEGER}],
        dtype=int,
    )
    integrality = np.abs(x[int_indices] - np.rint(x[int_indices]))
    all_integrality = np.abs(x - np.rint(x))
    objective = float(sum(v.Obj * x[i] for i, v in enumerate(variables)) + model.ObjCon)
    family_sums = collections.defaultdict(float)
    nonzero_residuals = []
    for i, variable in enumerate(variables):
        for prefix in ("ABS_ALT_U", "ABS_ALT_V", "ABS_ALT_W", "ABS_DIFF_U", "ABS_DIFF_V", "ABS_DIFF_W", "RESIDUAL"):
            if variable.VarName.startswith(prefix + "_"):
                family_sums[prefix] += x[i]
                if prefix == "RESIDUAL" and abs(x[i]) > 1e-12:
                    nonzero_residuals.append({"name": variable.VarName, "value": float(x[i])})
                break
    worst = np.argsort(-row_violation)[:20]
    rounded = np.rint(x)
    _, exact_replay_violation = constraint_violations(model, rounded)
    return {
        "objective_recomputed": objective,
        "family_sums": dict(sorted(family_sums.items())),
        "semantic_E_residual_sum": family_sums["RESIDUAL"],
        "expanded_factor_nonzeros": (
            family_sums["ABS_ALT_U"] + family_sums["ABS_ALT_V"] + family_sums["ABS_ALT_W"]
        ),
        "cyclic_core_nonzeros": family_sums["ABS_ALT_U"],
        "nonzero_residuals": nonzero_residuals,
        "max_constraint_violation": float(np.max(row_violation)),
        "violated_rows_gt_1e-9": int(np.sum(row_violation > 1e-9)),
        "max_bound_violation": float(np.max(bound_violation)),
        "max_integrality_violation_declared_integer_variables": float(np.max(integrality)),
        "max_distance_to_integer_all_variables": float(np.max(all_integrality)),
        "declared_integer_variables": int(len(int_indices)),
        "declared_integer_ones": int(np.sum(np.rint(x[int_indices]) == 1)),
        "exact_integer_replay": {
            "applicable_all_values_within_1e-12": bool(np.max(all_integrality) <= 1e-12),
            "max_constraint_violation_after_rounding_all_values": float(np.max(exact_replay_violation)),
            "objective_after_rounding_all_values": float(
                sum(v.Obj * rounded[i] for i, v in enumerate(variables)) + model.ObjCon
            ),
        },
        "worst_rows": [
            {
                "name": model.getConstrs()[idx].ConstrName,
                "sense": model.getConstrs()[idx].Sense,
                "rhs": float(model.getConstrs()[idx].RHS),
                "activity": float(activity[idx]),
                "violation": float(row_violation[idx]),
            }
            for idx in worst
            if row_violation[idx] > 0
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("mst", type=Path)
    parser.add_argument("--output-solution", type=Path, required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--time-limit", type=float, default=120.0)
    parser.add_argument("--threads", type=int, default=8)
    args = parser.parse_args()

    for path in (args.output_solution, args.output_json, args.log):
        path.parent.mkdir(parents=True, exist_ok=True)

    supplied = parse_mst(args.mst)
    model = gp.read(str(args.mps))
    variables = model.getVars()
    model_names = {v.VarName for v in variables}
    unknown = sorted(set(supplied) - model_names)
    missing = sorted(model_names - set(supplied))
    if unknown or missing:
        raise RuntimeError(f"MST mismatch: unknown={len(unknown)}, missing={len(missing)}")

    # Ask Gurobi itself to read the author's complete MIP start, then fix only
    # the 378 declared integer columns. Continuous auxiliaries remain free and
    # are recomputed by the strict LP completion.
    model.read(str(args.mst))
    fixed_integer_count = 0
    fixed_integer_ones = 0
    for variable in variables:
        if variable.VType in {gp.GRB.BINARY, gp.GRB.INTEGER}:
            value = round(supplied[variable.VarName])
            variable.LB = value
            variable.UB = value
            fixed_integer_count += 1
            fixed_integer_ones += int(value == 1)
    model.update()

    model.Params.FeasibilityTol = 1e-9
    model.Params.IntFeasTol = 1e-9
    model.Params.OptimalityTol = 1e-9
    model.Params.NumericFocus = 3
    model.Params.Presolve = 2
    model.Params.Method = 1
    model.Params.Threads = args.threads
    model.Params.TimeLimit = args.time_limit
    model.Params.LogFile = str(args.log)
    model.optimize()
    if model.Status != gp.GRB.OPTIMAL or model.SolCount < 1:
        raise RuntimeError(f"strict completion failed: status={model.Status}, solcount={model.SolCount}")
    model.write(str(args.output_solution))

    x = np.array([v.X for v in variables], dtype=float)
    start = np.array([supplied[v.VarName] for v in variables], dtype=float)
    result = {
        "gurobi_version": ".".join(map(str, gp.gurobi.version())),
        "inputs": {"mps": str(args.mps), "author_mst": str(args.mst)},
        "outputs": {"strict_solution": str(args.output_solution), "log": str(args.log)},
        "model_fingerprint": "0x%08x" % (model.Fingerprint & 0xFFFFFFFF),
        "dimensions": {
            "variables": model.NumVars,
            "constraints": model.NumConstrs,
            "nonzeros": model.NumNZs,
        },
        "mst_name_check": {
            "supplied": len(supplied),
            "unknown": len(unknown),
            "missing": len(missing),
        },
        "fixed_integer_count": fixed_integer_count,
        "fixed_integer_ones": fixed_integer_ones,
        "parameters": {
            "FeasibilityTol": 1e-9,
            "IntFeasTol": 1e-9,
            "OptimalityTol": 1e-9,
            "NumericFocus": 3,
            "Presolve": 2,
            "Method": 1,
            "Threads": args.threads,
            "TimeLimit": args.time_limit,
        },
        "solve": {
            "status": int(model.Status),
            "status_name": "OPTIMAL",
            "runtime_seconds": float(model.Runtime),
            "work": float(model.Work),
            "objective": float(model.ObjVal),
            "objective_bound": float(model.ObjBound),
            "solution_count": int(model.SolCount),
        },
        "comparison_to_author_mst": {
            "max_absolute_variable_change": float(np.max(np.abs(x - start))),
            "changed_variables_gt_1e-12": int(np.sum(np.abs(x - start) > 1e-12)),
        },
        "strict_solution_audit": audit(model, x),
        "author_mst_direct_audit": audit(model, start),
    }
    args.output_json.write_text(
        json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
