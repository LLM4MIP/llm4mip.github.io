#!/usr/bin/env python3
"""Verify every entry in SHA256SUMS.txt."""

from __future__ import annotations

import argparse
import hashlib
import subprocess
from pathlib import Path


def digest(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def git_output(repository: Path, *args: str) -> bytes:
    return subprocess.run(
        ["git", *args],
        cwd=repository,
        check=True,
        stdout=subprocess.PIPE,
    ).stdout


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path)
    parser.add_argument(
        "--git-index",
        action="store_true",
        help="verify staged Git blobs rather than checkout bytes",
    )
    args = parser.parse_args()
    root = args.manifest.resolve().parent
    if args.git_index:
        repository = Path(
            git_output(root, "rev-parse", "--show-toplevel")
            .decode("utf-8")
            .strip()
        ).resolve()
    checked = 0
    for line in args.manifest.read_text(encoding="utf-8").splitlines():
        expected, relative = line.split("  ", 1)
        if args.git_index:
            repository_relative = (root / Path(relative)).relative_to(repository).as_posix()
            actual = hashlib.sha256(
                git_output(repository, "show", f":{repository_relative}")
            ).hexdigest()
        else:
            actual = digest(root / Path(relative))
        if actual != expected:
            raise AssertionError((relative, expected, actual))
        checked += 1
    print(f"verified={checked} manifest={args.manifest.resolve()}")


if __name__ == "__main__":
    main()
