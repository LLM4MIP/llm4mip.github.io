#!/usr/bin/env python3
"""Audit the exact R23 -> R22 -> R21 truncation lineage in upstream MIP starts."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import numpy as np


ENCODING = re.compile(r"^(POS|NEG)_([ABCD])_(\d+)_(\d+)$")
N = 3


def read_values(path: Path) -> dict[str, int]:
    values: dict[str, int] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        fields = line.split()
        if len(fields) < 2:
            continue
        match = ENCODING.match(fields[0])
        if not match:
            continue
        value = float(fields[1])
        rounded = round(value)
        if abs(value - rounded) > 1e-12 or rounded not in (0, 1):
            raise ValueError(f"nonbinary encoding value: {fields[0]}={fields[1]}")
        values[fields[0]] = int(rounded)
    return values


def decode(path: Path) -> dict:
    values = read_values(path)
    widths: dict[str, int] = {}
    for name in values:
        match = ENCODING.match(name)
        assert match
        letter, col = match.group(2), int(match.group(4))
        widths[letter] = max(widths.get(letter, 0), col + 1)
    if set(widths) != set("ABCD") or not (widths["B"] == widths["C"] == widths["D"]):
        raise ValueError(f"unexpected block widths: {widths}")

    blocks: dict[str, np.ndarray] = {}
    for letter, width in widths.items():
        matrix = np.zeros((N * N, width), dtype=np.int64)
        for row in range(N * N):
            for col in range(width):
                pos = values[f"POS_{letter}_{row}_{col}"]
                neg = values[f"NEG_{letter}_{row}_{col}"]
                if pos + neg > 1:
                    raise ValueError(f"POS+NEG > 1 for {letter},{row},{col}")
                matrix[row, col] = pos - neg
        blocks[letter] = matrix

    a, b, c, d = (blocks[x] for x in "ABCD")
    u = np.hstack((a, b, c, d))
    v = np.hstack((a, d, b, c))
    w = np.hstack((a, c, d, b))
    expansion = np.einsum("ir,jr,kr->ijk", u, v, w, dtype=np.int64)
    target = np.zeros((N * N, N * N, N * N), dtype=np.int64)
    for n in range(N):
        for q in range(N):
            for m in range(N):
                target[N * n + q, N * q + m, N * m + n] = 1
    difference = target - expansion
    error_locations = np.argwhere(difference != 0)
    e = int(np.abs(difference).sum())
    k = int(sum(np.count_nonzero(block) for block in blocks.values()))
    return {
        "path": str(path),
        "S": widths["A"],
        "T": widths["B"],
        "R": int(u.shape[1]),
        "E": e,
        "K": k,
        "expanded_support": 3 * k,
        "objective": 1000 * e + 3 * k,
        "errors": [
            {
                "coordinate": location.tolist(),
                "target_minus_expansion": int(difference[tuple(location)]),
            }
            for location in error_locations
        ],
        "blocks": {letter: matrix.tolist() for letter, matrix in blocks.items()},
    }


def removed_singleton(column: np.ndarray) -> dict:
    support = np.flatnonzero(column)
    return {
        "support_size": int(support.size),
        "row": int(support[0]) if support.size == 1 else None,
        "value": int(column[support[0]]) if support.size == 1 else None,
        "cube_coordinate": [int(support[0])] * 3 if support.size == 1 else None,
        "cube_value": int(column[support[0]] ** 3) if support.size == 1 else None,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("r21", type=Path)
    parser.add_argument("r22", type=Path)
    parser.add_argument("r23", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()

    records = {"R21": decode(args.r21), "R22": decode(args.r22), "R23": decode(args.r23)}
    arrays = {
        rank: {letter: np.asarray(matrix, dtype=np.int64) for letter, matrix in record.pop("blocks").items()}
        for rank, record in records.items()
    }
    suffix_checks = {
        "R22_equals_R23_after_first_A_column": bool(
            np.array_equal(arrays["R22"]["A"], arrays["R23"]["A"][:, 1:])
            and all(np.array_equal(arrays["R22"][x], arrays["R23"][x]) for x in "BCD")
        ),
        "R21_equals_R23_after_first_two_A_columns": bool(
            np.array_equal(arrays["R21"]["A"], arrays["R23"]["A"][:, 2:])
            and all(np.array_equal(arrays["R21"][x], arrays["R23"][x]) for x in "BCD")
        ),
        "R21_equals_R22_after_first_A_column": bool(
            np.array_equal(arrays["R21"]["A"], arrays["R22"]["A"][:, 1:])
            and all(np.array_equal(arrays["R21"][x], arrays["R22"][x]) for x in "BCD")
        ),
    }
    output = {
        "method": "decode only POS/NEG core indicators and reconstruct all tensor entries with int64",
        "instances": records,
        "suffix_checks": suffix_checks,
        "R23_removed_A_columns": [
            removed_singleton(arrays["R23"]["A"][:, 0]),
            removed_singleton(arrays["R23"]["A"][:, 1]),
        ],
    }
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
