#!/usr/bin/env python3
"""Complete strict-improvement search inside the external BILR R21 support."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import gurobipy as gp


WIDTHS = {"A": 3, "B": 6, "C": 6, "D": 6}


def read_solution(path: Path) -> dict[str, float]:
    values: dict[str, float] = {}
    with path.open("r", encoding="utf-8") as stream:
        for raw in stream:
            fields = raw.strip().split()
            if len(fields) >= 2 and not fields[0].startswith(("#", "=")):
                values[fields[0]] = float(fields[1])
    return values


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path)
    parser.add_argument("start", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--solution", type=Path)
    parser.add_argument("--time-limit", type=float, default=300.0)
    parser.add_argument("--threads", type=int, default=8)
    args = parser.parse_args()
    for path in (args.json, args.log, args.solution):
        if path:
            path.parent.mkdir(parents=True, exist_ok=True)

    start_values = read_solution(args.start)
    model = gp.read(str(args.model))
    fixed_zero_locations = 0
    free_locations = 0
    for letter, width in WIDTHS.items():
        for row in range(9):
            for column in range(width):
                pos_name = f"POS_{letter}_{row}_{column}"
                neg_name = f"NEG_{letter}_{row}_{column}"
                if pos_name not in start_values or neg_name not in start_values:
                    raise ValueError(f"start misses {pos_name}/{neg_name}")
                if round(start_values[pos_name]) == 0 and round(start_values[neg_name]) == 0:
                    model.getVarByName(pos_name).UB = 0.0
                    model.getVarByName(neg_name).UB = 0.0
                    fixed_zero_locations += 1
                else:
                    free_locations += 1

    # Do not restrict the locations of tensor errors: alternate signs on the
    # same factor support may move errors away from the incumbent's two
    # diagonal coordinates.  The objective cap alone bounds their total.
    model.addConstr(model.getObjective() <= 2146, name="STRICT_IMPROVEMENT_OBJ_LE_2146")
    model.update()
    model.read(str(args.start))
    model.Params.LogFile = str(args.log)
    model.Params.Threads = args.threads
    model.Params.TimeLimit = args.time_limit
    model.Params.FeasibilityTol = 1e-9
    model.Params.IntFeasTol = 1e-9
    model.Params.OptimalityTol = 1e-9
    model.Params.NumericFocus = 3
    model.Params.Presolve = 2
    model.Params.MIPFocus = 1
    model.Params.Symmetry = 2
    model.optimize()

    result = {
        "instance": "fastxgemm-n3r21s3t6",
        "attribution": "Neighborhood centered on the external-derived BILR 2018 R21 candidate.",
        "scope": (
            "All 49 support locations of the BILR-derived 2147 point may be deleted or re-signed; "
            "all other 140 underlying positions are fixed to zero. All 729 residual variables remain "
            "unrestricted within the official model. This is a complete fixed-support objective<=2146 "
            "subproblem, not a global optimality proof."
        ),
        "fixed_zero_underlying_locations": fixed_zero_locations,
        "free_underlying_locations": free_locations,
        "residual_variables_additionally_fixed": 0,
        "objective_cap": 2146,
        "gurobi_version": ".".join(map(str, gp.gurobi.version())),
        "status_code": int(model.Status),
        "status": {
            gp.GRB.OPTIMAL: "OPTIMAL",
            gp.GRB.INFEASIBLE: "INFEASIBLE",
            gp.GRB.TIME_LIMIT: "TIME_LIMIT",
            gp.GRB.INTERRUPTED: "INTERRUPTED",
        }.get(model.Status, str(model.Status)),
        "solution_count": int(model.SolCount),
        "runtime_seconds": float(model.Runtime),
        "work": float(model.Work),
        "node_count": float(model.NodeCount),
        "best_bound": float(model.ObjBound) if model.IsMIP and math.isfinite(float(model.ObjBound)) else None,
        "best_objective": float(model.ObjVal) if model.SolCount else None,
        "parameters": {
            "TimeLimit": args.time_limit,
            "Threads": args.threads,
            "FeasibilityTol": 1e-9,
            "IntFeasTol": 1e-9,
            "OptimalityTol": 1e-9,
            "NumericFocus": 3,
            "Presolve": 2,
            "MIPFocus": 1,
            "Symmetry": 2,
        },
    }
    if args.solution and model.SolCount:
        model.write(str(args.solution))
    args.json.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
