#!/usr/bin/env python3
"""Read-only structural and incumbent audit for fastxgemm-n3r21s3t6."""

from __future__ import annotations

import argparse
import collections
import gzip
import json
import math
import re
from pathlib import Path

import gurobipy as gp
import numpy as np


TRAILING_INDICES = re.compile(r"(?:_-?\d+)+$")


def family(name: str) -> str:
    return TRAILING_INDICES.sub("", name)


def finite(value: float) -> float | None:
    return float(value) if math.isfinite(float(value)) else None


def quantiles(values: np.ndarray) -> dict[str, float]:
    if values.size == 0:
        return {}
    return {
        "min": float(np.min(values)),
        "q25": float(np.quantile(values, 0.25)),
        "median": float(np.median(values)),
        "q75": float(np.quantile(values, 0.75)),
        "q90": float(np.quantile(values, 0.90)),
        "q99": float(np.quantile(values, 0.99)),
        "max": float(np.max(values)),
        "mean": float(np.mean(values)),
    }


def value_key(value: float) -> str:
    if math.isinf(value):
        return "+inf" if value > 0 else "-inf"
    if value == 0:
        return "0"
    return format(float(value), ".12g")


def top_counter(counter: collections.Counter, n: int = 40) -> dict[str, int]:
    return {str(key): int(count) for key, count in counter.most_common(n)}


def read_solution(path: Path) -> tuple[float | None, dict[str, float]]:
    opener = gzip.open if path.suffix == ".gz" else open
    declared = None
    values: dict[str, float] = {}
    with opener(path, "rt", encoding="utf-8") as stream:
        for raw in stream:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            fields = line.split()
            if fields[0].lower() in {"=obj=", "=best=", "=opt="}:
                declared = float(fields[1])
                continue
            if len(fields) >= 2:
                values[fields[0]] = float(fields[1])
    return declared, values


def parse_dec(path: Path, constraint_index: dict[str, int], matrix, variables) -> dict:
    blocks: dict[int, list[str]] = collections.defaultdict(list)
    master: list[str] = []
    section: tuple[str, int | None] | None = None
    expected_blocks = None
    pending_nblocks = False
    with path.open("r", encoding="utf-8") as stream:
        for raw in stream:
            line = raw.strip()
            if not line or line.startswith("\\"):
                continue
            if pending_nblocks:
                expected_blocks = int(line)
                pending_nblocks = False
                continue
            if line == "NBLOCKS":
                pending_nblocks = True
                continue
            if line.startswith("BLOCK "):
                block_id = int(line.split()[1])
                section = ("block", block_id)
                continue
            if line == "MASTERCONSS":
                section = ("master", None)
                continue
            if line in {"PRESOLVED", "0", "1"} and section is None:
                continue
            if section is None:
                continue
            if section[0] == "block":
                blocks[int(section[1])].append(line)
            else:
                master.append(line)

    row_block = np.full(matrix.shape[0], -2, dtype=np.int32)
    missing: list[str] = []
    for block_id, names in blocks.items():
        for name in names:
            idx = constraint_index.get(name)
            if idx is None:
                missing.append(name)
            else:
                row_block[idx] = block_id
    for name in master:
        idx = constraint_index.get(name)
        if idx is None:
            missing.append(name)
        else:
            row_block[idx] = 0

    csc = matrix.tocsc()
    variable_scope_counts = collections.Counter()
    scope_family_counts: dict[str, collections.Counter] = collections.defaultdict(collections.Counter)
    scope_type_counts: dict[str, collections.Counter] = collections.defaultdict(collections.Counter)
    family_scope_counts: dict[str, collections.Counter] = collections.defaultdict(collections.Counter)
    linking_examples: list[dict] = []
    block_local_counts = collections.Counter()
    block_local_integer_counts = collections.Counter()
    for col in range(csc.shape[1]):
        rows = csc.indices[csc.indptr[col] : csc.indptr[col + 1]]
        scopes = sorted(set(int(row_block[row]) for row in rows))
        positive_blocks = [scope for scope in scopes if scope > 0]
        has_master = 0 in scopes
        has_unassigned = -2 in scopes
        if has_unassigned:
            key = "touches_unassigned"
        elif len(positive_blocks) == 1:
            key = "single_block_and_master" if has_master else "single_block_only"
            block_local_counts[positive_blocks[0]] += 1
        elif len(positive_blocks) > 1:
            key = "multi_block_linking"
        elif has_master:
            key = "master_only"
        else:
            key = "no_rows"
        variable_scope_counts[key] += 1
        fam = family(variables[col].VarName)
        scope_family_counts[key][fam] += 1
        scope_type_counts[key][variables[col].VType] += 1
        family_scope_counts[fam][key] += 1
        if key in {"single_block_only", "single_block_and_master"} and variables[col].VType in {
            gp.GRB.BINARY,
            gp.GRB.INTEGER,
        }:
            block_local_integer_counts[positive_blocks[0]] += 1
        if key == "multi_block_linking" and len(linking_examples) < 30:
            linking_examples.append(
                {"column": int(col), "name": variables[col].VarName, "scopes": scopes}
            )

    def signature_counts(rows: np.ndarray) -> dict[str, int]:
        counter = collections.Counter()
        for row in rows:
            start, end = matrix.indptr[row], matrix.indptr[row + 1]
            columns = matrix.indices[start:end]
            counter[
                (
                    int(end - start),
                    int(sum(variables[col].VType in {gp.GRB.BINARY, gp.GRB.INTEGER} for col in columns)),
                )
            ] += 1
        return {"nnz=%d|integer=%d" % key: int(value) for key, value in counter.most_common()}

    return {
        "declared_nblocks": expected_blocks,
        "parsed_nblocks": len(blocks),
        "block_constraint_counts": {str(k): len(v) for k, v in sorted(blocks.items())},
        "master_constraint_count": len(master),
        "unassigned_constraint_count": int(np.sum(row_block == -2)),
        "missing_constraint_count": len(missing),
        "missing_constraint_examples": missing[:20],
        "variable_scope_counts": dict(variable_scope_counts),
        "scope_family_counts": {
            scope: dict(counter.most_common()) for scope, counter in sorted(scope_family_counts.items())
        },
        "scope_type_counts": {
            scope: dict(counter) for scope, counter in sorted(scope_type_counts.items())
        },
        "family_scope_counts": {
            fam: dict(counter) for fam, counter in sorted(family_scope_counts.items())
        },
        "block_local_variable_counts": {str(k): int(v) for k, v in sorted(block_local_counts.items())},
        "block_local_integer_counts": {
            str(k): int(v) for k, v in sorted(block_local_integer_counts.items())
        },
        "master_row_signature_counts": signature_counts(np.flatnonzero(row_block == 0)),
        "block_1_row_signature_counts": signature_counts(np.flatnonzero(row_block == 1)),
        "multi_block_linking_examples": linking_examples,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("--solution", type=Path)
    parser.add_argument("--dec", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    model = gp.read(str(args.mps))
    model.Params.OutputFlag = 0
    variables = model.getVars()
    constraints = model.getConstrs()
    matrix = model.getA().tocsr()

    var_types = collections.Counter(v.VType for v in variables)
    var_families = collections.Counter(family(v.VarName) for v in variables)
    bound_patterns = collections.Counter(
        (v.VType, value_key(v.LB), value_key(v.UB)) for v in variables
    )
    objective_coefficients = collections.Counter(value_key(v.Obj) for v in variables if v.Obj)
    objective_families: dict[str, dict] = {}
    for fam in sorted(set(family(v.VarName) for v in variables if v.Obj)):
        members = [v for v in variables if v.Obj and family(v.VarName) == fam]
        objective_families[fam] = {
            "count": len(members),
            "coefficient_counts": top_counter(collections.Counter(value_key(v.Obj) for v in members)),
            "coefficient_sum": float(sum(v.Obj for v in members)),
        }

    senses = collections.Counter(c.Sense for c in constraints)
    rhs = np.array([c.RHS for c in constraints], dtype=float)
    row_nnz = np.diff(matrix.indptr)
    csc = matrix.tocsc()
    col_nnz = np.diff(csc.indptr)
    coefficients = matrix.data
    coefficient_counts = collections.Counter(value_key(x) for x in coefficients)
    rhs_counts = collections.Counter(value_key(x) for x in rhs)

    int_mask = np.array([v.VType in {gp.GRB.BINARY, gp.GRB.INTEGER} for v in variables])
    int_per_row = np.diff(matrix[:, int_mask].indptr)
    cont_per_row = row_nnz - int_per_row
    row_signature_counts = collections.Counter(
        (constraints[i].Sense, value_key(rhs[i]), int(row_nnz[i]), int(int_per_row[i]), int(cont_per_row[i]))
        for i in range(model.NumConstrs)
    )

    report: dict = {
        "tool": {"gurobi_version": ".".join(map(str, gp.gurobi.version()))},
        "inputs": {
            "mps": str(args.mps),
            "solution": str(args.solution) if args.solution else None,
            "dec": str(args.dec) if args.dec else None,
        },
        "model": {
            "name": model.ModelName,
            "sense": "minimize" if model.ModelSense == 1 else "maximize",
            "variables": model.NumVars,
            "constraints": model.NumConstrs,
            "nonzeros": model.NumNZs,
            "variable_type_counts": dict(var_types),
            "variable_family_counts": dict(var_families.most_common()),
            "bound_patterns": {"|".join(k): v for k, v in bound_patterns.most_common()},
            "constraint_sense_counts": dict(senses),
            "rhs_counts_top": top_counter(rhs_counts),
            "objective_nonzero_count": int(sum(objective_coefficients.values())),
            "objective_coefficient_counts": top_counter(objective_coefficients),
            "objective_families": objective_families,
            "matrix_coefficient_counts_top": top_counter(coefficient_counts, 60),
            "row_nnz_quantiles": quantiles(row_nnz),
            "column_nnz_quantiles": quantiles(col_nnz),
            "integer_columns_per_row_quantiles": quantiles(int_per_row),
            "continuous_columns_per_row_quantiles": quantiles(cont_per_row),
            "rows_without_integer_columns": int(np.sum(int_per_row == 0)),
            "rows_with_integer_columns": int(np.sum(int_per_row > 0)),
            "row_signature_counts_top": {
                "|".join(map(str, signature)): int(count)
                for signature, count in row_signature_counts.most_common(60)
            },
        },
    }

    if args.dec:
        report["decomposition"] = parse_dec(
            args.dec,
            {c.ConstrName: i for i, c in enumerate(constraints)},
            matrix,
            variables,
        )

    if args.solution:
        declared, supplied = read_solution(args.solution)
        x = np.array([supplied.get(v.VarName, 0.0) for v in variables], dtype=float)
        missing = [v.VarName for v in variables if v.VarName not in supplied]
        unknown = sorted(set(supplied) - {v.VarName for v in variables})
        obj = np.array([v.Obj for v in variables], dtype=float)
        lb = np.array([v.LB for v in variables], dtype=float)
        ub = np.array([v.UB for v in variables], dtype=float)
        activity = matrix.dot(x)
        violations = np.zeros(model.NumConstrs, dtype=float)
        for i, constraint in enumerate(constraints):
            if constraint.Sense == "<":
                violations[i] = max(0.0, activity[i] - rhs[i])
            elif constraint.Sense == ">":
                violations[i] = max(0.0, rhs[i] - activity[i])
            else:
                violations[i] = abs(activity[i] - rhs[i])
        bound_violation = np.maximum(np.maximum(lb - x, 0.0), np.maximum(x - ub, 0.0))
        integer_indices = np.flatnonzero(int_mask)
        integrality_violation = np.abs(x[integer_indices] - np.rint(x[integer_indices]))
        worst_rows = np.argsort(-violations)[:30]
        nonzero_objective_contributions = collections.defaultdict(float)
        for j, v in enumerate(variables):
            if v.Obj:
                nonzero_objective_contributions[family(v.VarName)] += v.Obj * x[j]
        report["solution_audit"] = {
            "declared_objective": declared,
            "recomputed_objective_float": float(obj @ x + model.ObjCon),
            "supplied_variable_count": len(supplied),
            "missing_variable_count": len(missing),
            "missing_variable_examples": missing[:20],
            "unknown_variable_count": len(unknown),
            "unknown_variable_examples": unknown[:20],
            "max_constraint_violation_float": float(np.max(violations)),
            "violated_rows_gt_1e-9": int(np.sum(violations > 1e-9)),
            "violated_rows_gt_1e-7": int(np.sum(violations > 1e-7)),
            "violated_rows_gt_1e-6": int(np.sum(violations > 1e-6)),
            "max_bound_violation_float": float(np.max(bound_violation)),
            "max_integrality_violation_float": float(np.max(integrality_violation)),
            "fractional_integer_count_gt_1e-9": int(np.sum(integrality_violation > 1e-9)),
            "fractional_integer_count_gt_1e-7": int(np.sum(integrality_violation > 1e-7)),
            "integer_ones_after_rounding": int(np.sum(np.rint(x[integer_indices]) == 1)),
            "integer_zeros_after_rounding": int(np.sum(np.rint(x[integer_indices]) == 0)),
            "objective_contribution_by_family": dict(sorted(nonzero_objective_contributions.items())),
            "worst_rows": [
                {
                    "row": constraints[i].ConstrName,
                    "sense": constraints[i].Sense,
                    "rhs": float(rhs[i]),
                    "activity": float(activity[i]),
                    "violation": float(violations[i]),
                    "nnz": int(row_nnz[i]),
                    "integer_columns": int(int_per_row[i]),
                }
                for i in worst_rows
                if violations[i] > 0
            ],
        }

    # Gurobi's explicit presolve operation is diagnostic only; it does not optimize.
    presolved = model.presolve()
    presolved_variables = presolved.getVars()
    report["gurobi_presolve"] = {
        "variables": presolved.NumVars,
        "constraints": presolved.NumConstrs,
        "nonzeros": presolved.NumNZs,
        "variable_type_counts": dict(collections.Counter(v.VType for v in presolved_variables)),
        "objective_nonzero_count": int(sum(v.Obj != 0 for v in presolved_variables)),
    }

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
