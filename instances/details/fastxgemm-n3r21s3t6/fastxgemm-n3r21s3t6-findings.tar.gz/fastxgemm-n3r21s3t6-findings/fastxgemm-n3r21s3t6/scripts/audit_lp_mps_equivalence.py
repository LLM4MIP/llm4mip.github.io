#!/usr/bin/env python3
"""Compare the upstream LP and the official MIPLIB MPS coefficient by coefficient."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from collections import Counter
from pathlib import Path

import gurobipy as gp
import numpy as np


def sha256(path: Path, decompress: bool = False) -> str:
    digest = hashlib.sha256()
    opener = gzip.open if decompress and path.suffix == ".gz" else open
    with opener(path, "rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("author_lp", type=Path)
    parser.add_argument("official_mps", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--source-commit", required=True)
    parser.add_argument("--source-file-commit", required=True)
    args = parser.parse_args()

    lp = gp.read(str(args.author_lp))
    mps = gp.read(str(args.official_mps))
    lp_vars, mps_vars = lp.getVars(), mps.getVars()
    lp_rows, mps_rows = lp.getConstrs(), mps.getConstrs()

    var_names_same = [v.VarName for v in lp_vars] == [v.VarName for v in mps_vars]
    row_names_same = [c.ConstrName for c in lp_rows] == [c.ConstrName for c in mps_rows]
    bounds_same = np.array_equal(np.array(lp.getAttr("LB")), np.array(mps.getAttr("LB"))) and np.array_equal(
        np.array(lp.getAttr("UB")), np.array(mps.getAttr("UB"))
    )
    objectives_same = np.array_equal(
        np.array(lp.getAttr("Obj")), np.array(mps.getAttr("Obj"))
    ) and lp.ObjCon == mps.ObjCon and lp.ModelSense == mps.ModelSense
    rhs_same = np.array_equal(np.array(lp.getAttr("RHS")), np.array(mps.getAttr("RHS")))
    senses_same = [c.Sense for c in lp_rows] == [c.Sense for c in mps_rows]
    difference = lp.getA() - mps.getA()
    matrix_same = difference.nnz == 0

    type_differences = []
    domain_equivalent = True
    for left, right in zip(lp_vars, mps_vars):
        if left.VType == right.VType:
            continue
        binary_integer_relabel = (
            {left.VType, right.VType} == {gp.GRB.BINARY, gp.GRB.INTEGER}
            and left.LB == right.LB == 0
            and left.UB == right.UB == 1
        )
        domain_equivalent &= binary_integer_relabel
        if len(type_differences) < 30:
            type_differences.append(
                {
                    "variable": left.VarName,
                    "author_lp_type": left.VType,
                    "official_mps_type": right.VType,
                    "lower_bound": left.LB,
                    "upper_bound": left.UB,
                    "domain_equivalent": binary_integer_relabel,
                }
            )

    dimensions_same = (
        lp.NumVars == mps.NumVars
        and lp.NumConstrs == mps.NumConstrs
        and lp.NumNZs == mps.NumNZs
    )
    equivalent = all(
        (
            dimensions_same,
            var_names_same,
            row_names_same,
            bounds_same,
            objectives_same,
            rhs_same,
            senses_same,
            matrix_same,
            domain_equivalent,
        )
    )
    if not equivalent:
        raise RuntimeError("author LP and official MPS are not semantically equivalent")

    report = {
        "instance": "fastxgemm-n3r21s3t6",
        "tool": {"gurobi_version": ".".join(map(str, gp.gurobi.version()))},
        "inputs": {
            "author_lp": (
                "source/fast-matrix-multiplication/instances/"
                "fastxgemm-N3-R21-S3-T6.lp"
            ),
            "official_mps": "input/fastxgemm-n3r21s3t6.mps.gz",
            "source_snapshot_commit": args.source_commit,
            "source_file_introduction_commit": args.source_file_commit,
        },
        "sha256": {
            "author_lp": sha256(args.author_lp),
            "official_mps_gzip": sha256(args.official_mps),
            "official_mps_decompressed": sha256(args.official_mps, decompress=True),
        },
        "dimensions": {
            "author_lp": {
                "variables": lp.NumVars,
                "constraints": lp.NumConstrs,
                "nonzeros": lp.NumNZs,
            },
            "official_mps": {
                "variables": mps.NumVars,
                "constraints": mps.NumConstrs,
                "nonzeros": mps.NumNZs,
            },
            "equal": dimensions_same,
        },
        "checks": {
            "variable_names_and_order_equal": var_names_same,
            "constraint_names_and_order_equal": row_names_same,
            "bounds_equal": bounds_same,
            "objective_coefficients_constant_sense_equal": objectives_same,
            "constraint_rhs_equal": rhs_same,
            "constraint_senses_equal": senses_same,
            "coefficient_matrix_equal": matrix_same,
            "coefficient_matrix_difference_nonzeros": difference.nnz,
            "coefficient_matrix_max_absolute_difference": float(
                max(np.abs(difference.data), default=0)
            ),
            "variable_domains_equivalent": domain_equivalent,
        },
        "variable_type_serialization": {
            "author_lp_counts": dict(Counter(v.VType for v in lp_vars)),
            "official_mps_counts": dict(Counter(v.VType for v in mps_vars)),
            "different_type_label_count": sum(
                left.VType != right.VType for left, right in zip(lp_vars, mps_vars)
            ),
            "examples": type_differences,
            "explanation": (
                "The LP labels 378 variables as binary, while the MPS labels the same "
                "variables as general integer with bounds [0,1]. Their feasible domains "
                "are exactly identical."
            ),
        },
        "gurobi_fingerprints": {
            "author_lp": lp.Fingerprint,
            "official_mps": mps.Fingerprint,
            "note": (
                "Fingerprint inequality is expected because model names and binary/integer "
                "type labels differ; coefficient-level checks above establish equivalence."
            ),
        },
        "semantically_equivalent": equivalent,
        "conclusion": (
            "The upstream LP and official MIPLIB MPS have identical variables, rows, "
            "bounds, objective, RHS values, senses, and coefficient matrix. The sole "
            "serialization difference is B versus bounded-I labels on 378 variables, "
            "which does not change their {0,1} domains."
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
