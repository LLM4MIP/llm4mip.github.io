#!/usr/bin/env python3
"""Search two-A deletion children across bounded BILR conjugations.

This extends the already published bounded conjugation audit by scoring every
R21 child obtained after deleting two transformed fixed terms.  The search is
exhaustive only over primitive integer 3x3 representatives in the stated box.
"""

from __future__ import annotations

import argparse
import itertools
import json
import math
from collections import Counter
from pathlib import Path

from enumerate_bilr_a_deletions import audit_core


def determinant(g: tuple[int, ...]) -> int:
    a, b, c, d, e, f, h, i, j = g
    return a * (e * j - f * i) - b * (d * j - f * h) + c * (d * i - e * h)


def adjugate(g: tuple[int, ...]) -> tuple[int, ...]:
    a, b, c, d, e, f, h, i, j = g
    return (e*j-f*i, c*i-b*j, b*f-c*e, f*h-d*j, a*j-c*h, c*d-a*f, d*i-e*h, b*h-a*i, a*e-b*d)


def multiply(left: tuple[int, ...], right: tuple[int, ...]) -> tuple[int, ...]:
    return tuple(sum(left[3*r+k] * right[3*k+c] for k in range(3)) for r in range(3) for c in range(3))


def transform(g: tuple[int, ...], adj: tuple[int, ...], matrix: tuple[int, ...]) -> tuple[int, ...]:
    return multiply(multiply(g, matrix), adj)


def magnitude(values: tuple[int, ...]) -> int | None:
    magnitudes = {abs(value) for value in values if value}
    return next(iter(magnitudes)) if len(magnitudes) == 1 else None


def normalize(values: tuple[int, ...], det: int) -> list[int]:
    sign_det = 1 if det > 0 else -1
    return [0 if value == 0 else sign_det * (1 if value > 0 else -1) for value in values]


def canonical(g: tuple[int, ...]) -> tuple[int, ...] | None:
    divisor = 0
    for value in g:
        divisor = math.gcd(divisor, abs(value))
    if divisor != 1:
        return None
    first = next((value for value in g if value), 0)
    return tuple(-value for value in g) if first < 0 else g


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source_audit", type=Path)
    parser.add_argument("--entry-bound", type=int, default=1)
    parser.add_argument("--output-json", type=Path, required=True)
    args = parser.parse_args()
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    source = json.loads(args.source_audit.read_text(encoding="utf-8"))
    raw = source["fastxgemm_core_mapping"]
    fixed = [tuple(map(int, vector)) for vector in raw["A"]]
    seeds = [
        (tuple(map(int, b)), tuple(map(int, d)), tuple(map(int, c)))
        for b, c, d in zip(raw["B"], raw["C"], raw["D"])
    ]

    seen: set[tuple[int, ...]] = set()
    nonsingular = 0
    admissible = 0
    child_cases = 0
    objective_histogram: Counter[int] = Counter()
    best_objective = 10**18
    best_records = []
    values = range(-args.entry_bound, args.entry_bound + 1)
    for candidate in itertools.product(values, repeat=9):
        g = canonical(candidate)
        if g is None or g in seen:
            continue
        seen.add(g)
        det = determinant(g)
        if det == 0:
            continue
        nonsingular += 1
        adj = adjugate(g)
        tfixed = [transform(g, adj, matrix) for matrix in fixed]
        if any(magnitude(matrix) != abs(det) for matrix in tfixed):
            continue
        tseeds = [tuple(transform(g, adj, matrix) for matrix in seed) for seed in seeds]
        seed_magnitudes = [tuple(magnitude(matrix) for matrix in seed) for seed in tseeds]
        if any(any(item is None for item in mags) for mags in seed_magnitudes):
            continue
        if any(math.prod(mags) != abs(det) ** 3 for mags in seed_magnitudes):
            continue
        admissible += 1
        nf = [normalize(matrix, det) for matrix in tfixed]
        ns = [tuple(normalize(matrix, det) for matrix in seed) for seed in tseeds]
        parent_core = {
            "A": nf,
            "B": [seed[0] for seed in ns],
            "C": [seed[2] for seed in ns],
            "D": [seed[1] for seed in ns],
        }
        parent_k = sum(value != 0 for columns in parent_core.values() for column in columns for value in column)
        for deleted in itertools.combinations(range(5), 2):
            child_cases += 1
            child = {**parent_core, "A": [nf[i] for i in range(5) if i not in deleted]}
            audit = audit_core(child)
            if not audit["passes_original_discrete_side_conditions"]:
                continue
            objective_histogram[audit["objective"]] += 1
            record = {
                "G": [list(g[0:3]), list(g[3:6]), list(g[6:9])],
                "determinant": det,
                "parent_K": parent_k,
                "deleted_A_indices": list(deleted),
                "child": audit,
            }
            if audit["objective"] < best_objective:
                best_objective = audit["objective"]
                best_records = [record]
            elif audit["objective"] == best_objective and len(best_records) < 100:
                best_records.append(record)

    result = {
        "attribution": "Derived from BILR arXiv:1801.00843v1 S_Lader-Z3; not a GPT-original decomposition.",
        "entry_bound": args.entry_bound,
        "primitive_projective_representatives_checked": len(seen),
        "nonsingular_representatives": nonsingular,
        "ternary_projectively_admissible_representatives": admissible,
        "r21_deletion_children_checked": child_cases,
        "best_objective": best_objective if best_records else None,
        "best_record_count_saved": len(best_records),
        "best_records": best_records,
        "objective_histogram": dict(sorted(objective_histogram.items())),
        "scope": "Exhaustive only over bounded primitive integer conjugating matrices, modulo G~-G, and all ten two-A deletions per admissible transformed core.",
    }
    args.output_json.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({key: result[key] for key in ("entry_bound", "primitive_projective_representatives_checked", "ternary_projectively_admissible_representatives", "r21_deletion_children_checked", "best_objective", "best_record_count_saved")}, indent=2))


if __name__ == "__main__":
    main()
