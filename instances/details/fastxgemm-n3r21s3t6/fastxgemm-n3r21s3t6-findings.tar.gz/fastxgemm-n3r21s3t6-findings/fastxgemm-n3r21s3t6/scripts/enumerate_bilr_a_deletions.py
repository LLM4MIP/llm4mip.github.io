#!/usr/bin/env python3
"""Enumerate all two-A-column deletions of the BILR cyclic rank-23 core.

The external rank-23 decomposition is due to Ballard, Ikenmeyer, Landsberg,
and Ryder (arXiv:1801.00843v1, Appendix B, equations 77--84).  This script
only derives and audits its ten S=3,T=6 rank-21 deletion children.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from pathlib import Path


def hstack(columns: list[list[int]]) -> list[list[int]]:
    return [[columns[col][row] for col in range(len(columns))] for row in range(9)]


def target(i: int, j: int, k: int) -> int:
    n, q = divmod(i, 3)
    q2, m = divmod(j, 3)
    m2, n2 = divmod(k, 3)
    return int(q == q2 and m == m2 and n == n2)


def audit_core(core: dict[str, list[list[int]]]) -> dict:
    a, b, c, d = (core[letter] for letter in "ABCD")
    u = hstack(a + b + c + d)
    v = hstack(a + d + b + c)
    w = hstack(a + c + d + b)
    assert all(len(row) == 21 for factor in (u, v, w) for row in factor)
    errors = []
    for i, j, k in itertools.product(range(9), repeat=3):
        actual = sum(u[i][r] * v[j][r] * w[k][r] for r in range(21))
        wanted = target(i, j, k)
        if actual != wanted:
            errors.append(
                {
                    "coordinate": [i, j, k],
                    "target": wanted,
                    "actual": actual,
                    "absolute_error": abs(wanted - actual),
                }
            )
    k_support = sum(value != 0 for columns in core.values() for column in columns for value in column)
    row_degrees = [sum(factor[i][r] != 0 for r in range(21)) for i in range(9) for factor in (u,)]
    column_supports = {
        letter: [sum(value != 0 for value in column) for column in core[letter]]
        for letter in "ABCD"
    }
    e = sum(item["absolute_error"] for item in errors)
    structural = {
        "all_core_columns_nonzero": all(value >= 1 for values in column_supports.values() for value in values),
        "all_factor_rows_nonzero": all(value >= 1 for value in row_degrees),
        "model_core_support_lb_28": k_support >= 28,
        "each_residual_at_most_one": all(item["absolute_error"] <= 1 for item in errors),
    }
    return {
        "E": e,
        "K": k_support,
        "full_factor_support": 3 * k_support,
        "objective": 1000 * e + 3 * k_support,
        "nonzero_error_count": len(errors),
        "errors": errors,
        "row_degrees": row_degrees,
        "column_supports": column_supports,
        "structural_checks": structural,
        "passes_original_discrete_side_conditions": all(structural.values()),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source_audit", type=Path)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--best-core-json", type=Path, required=True)
    args = parser.parse_args()
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.best_core_json.parent.mkdir(parents=True, exist_ok=True)

    source = json.loads(args.source_audit.read_text(encoding="utf-8"))
    raw = source["fastxgemm_core_mapping"]
    if len(raw["A"]) != 5 or any(len(raw[x]) != 6 for x in "BCD"):
        raise ValueError("source is not an S=5,T=6 core")
    if source["support"]["core_K"] != 51 or not source["exact_integer_tensor_audit"]["exact"]:
        raise ValueError("source audit is not the expected exact K=51 BILR core")

    cases = []
    for deleted in itertools.combinations(range(5), 2):
        kept = [index for index in range(5) if index not in deleted]
        core = {
            "A": [raw["A"][index] for index in kept],
            "B": raw["B"],
            "C": raw["C"],
            "D": raw["D"],
        }
        audit = audit_core(core)
        cases.append({"deleted_A_indices": list(deleted), "kept_A_indices": kept, **audit})

    eligible = [case for case in cases if case["passes_original_discrete_side_conditions"]]
    best_objective = min(case["objective"] for case in eligible)
    best_cases = [case for case in eligible if case["objective"] == best_objective]
    best_case = best_cases[0]
    best_core = {
        "A": [raw["A"][index] for index in best_case["kept_A_indices"]],
        "B": raw["B"],
        "C": raw["C"],
        "D": raw["D"],
    }
    source_sha256 = hashlib.sha256(args.source_audit.read_bytes()).hexdigest()
    result = {
        "attribution": (
            "External-derived from the cyclic rank-23 decomposition S_Lader-Z3 of "
            "Ballard, Ikenmeyer, Landsberg, and Ryder, arXiv:1801.00843v1, "
            "Appendix B, equations 77--84. Not a GPT-original factor decomposition."
        ),
        "source_audit": str(args.source_audit.resolve()),
        "source_audit_sha256": source_sha256,
        "scope": "Exhaustive over all C(5,2)=10 deletions of two fixed A columns from this one audited external S=5,T=6 core.",
        "case_count": len(cases),
        "best_objective": best_objective,
        "best_case_count": len(best_cases),
        "best_cases": best_cases,
        "cases": cases,
        "claim": "A discrete candidate only until completed and audited on the official R21 MPS.",
    }
    candidate = {
        "attribution": result["attribution"],
        "derivation": {
            "operation": "delete two fixed A columns",
            "deleted_A_indices": best_case["deleted_A_indices"],
            "kept_A_indices": best_case["kept_A_indices"],
            "enumeration_report": str(args.output_json.resolve()),
        },
        "exact_integer_tensor_audit": {
            "exact": best_case["E"] == 0,
            "residual_l1": best_case["E"],
            "nonzero_residual_count": best_case["nonzero_error_count"],
            "residual_examples": best_case["errors"],
        },
        "support": {
            "core_K": best_case["K"],
            "full_factor_support": best_case["full_factor_support"],
            "candidate_fastxgemm_objective_if_mapped": best_case["objective"],
        },
        "fastxgemm_core_mapping": best_core,
        "structural_checks": best_case["structural_checks"],
    }
    args.output_json.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    args.best_core_json.write_text(json.dumps(candidate, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"best_objective": best_objective, "best_cases": best_cases}, indent=2))


if __name__ == "__main__":
    main()
