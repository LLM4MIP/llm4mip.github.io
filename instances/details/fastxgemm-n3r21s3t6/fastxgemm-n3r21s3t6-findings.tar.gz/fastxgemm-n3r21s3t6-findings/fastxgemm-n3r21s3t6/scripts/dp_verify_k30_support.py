#!/usr/bin/env python3
"""Independent exact DP verifier for the K=30 tight-slice support obstruction.

The verifier uses only Python integer bit masks and finite set dynamic
programming; it does not import or call a mathematical-programming solver.
For each of the 84 choices of the three degree-4 rows, it enumerates every
support contribution possible for one A column and one (B,C,D) orbit under
the tight-slice restrictions, then combines exactly 3 A columns and 6 BCD
orbits to test the required row-degree vector.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import time
from pathlib import Path


ROWS = tuple(range(9))
ALL_MASK = (1 << 9) - 1
ROW_MASKS = tuple(sum(1 << (3 * a + b) for b in range(3)) for a in range(3))
COL_MASKS = tuple(sum(1 << (3 * a + b) for a in range(3)) for b in range(3))


def bits(mask: int) -> tuple[int, ...]:
    return tuple(i for i in ROWS if mask & (1 << i))


def contribution(*masks: int) -> tuple[int, ...]:
    return tuple(sum(bool(mask & (1 << i)) for mask in masks) for i in ROWS)


def candidate_vector_supports(high_mask: int) -> tuple[int, ...]:
    """All nonempty supports with at most one tight-row entry.

    At most one tight entry is complete for a B/C/D vector: two distinct
    tight entries would force one of the other two vectors in its orbit into
    the intersection of two distinct grid rows or columns, hence to zero.
    """
    tight_mask = ALL_MASK ^ high_mask
    result: set[int] = set()
    sub = high_mask
    while True:
        if sub:
            result.add(sub)
        for i in bits(tight_mask):
            result.add(sub | (1 << i))
        if sub == 0:
            break
        sub = (sub - 1) & high_mask
    return tuple(sorted(result))


def a_patterns(high_mask: int) -> tuple[tuple[int, ...], ...]:
    """All row-degree contributions of one fixed A column."""
    tight_mask = ALL_MASK ^ high_mask
    supports: set[int] = set()
    sub = high_mask
    while sub:
        supports.add(sub)
        sub = (sub - 1) & high_mask
    # If an A vector meets a tight row (a,b), the U-slice restriction puts the
    # same vector in grid row b and grid column a.  Nonzeroness at (a,b)
    # therefore requires a=b and makes the support that diagonal singleton.
    for i in bits(tight_mask):
        a, b = divmod(i, 3)
        if a == b:
            supports.add(1 << i)
    return tuple(sorted({contribution(mask) for mask in supports}))


def tight_entry(mask: int, tight_mask: int) -> int | None:
    selected = mask & tight_mask
    if not selected:
        return None
    assert selected & (selected - 1) == 0
    return selected.bit_length() - 1


def bcd_patterns(high_mask: int) -> tuple[tuple[int, ...], ...]:
    """Enumerate all degree contributions of one complete B/C/D orbit."""
    tight_mask = ALL_MASK ^ high_mask
    candidates = candidate_vector_supports(high_mask)
    tagged = [(mask, tight_entry(mask, tight_mask)) for mask in candidates]
    patterns: set[tuple[int, ...]] = set()

    for b_mask, b_tight in tagged:
        for c_mask, c_tight in tagged:
            # B tight at (a,b) forces C into grid column a.
            if b_tight is not None:
                a, _ = divmod(b_tight, 3)
                if c_mask & ~COL_MASKS[a]:
                    continue
            # C tight at (a,b) forces B into grid row b.
            if c_tight is not None:
                _, b = divmod(c_tight, 3)
                if b_mask & ~ROW_MASKS[b]:
                    continue
            for d_mask, d_tight in tagged:
                valid = True
                if b_tight is not None:
                    _, b = divmod(b_tight, 3)
                    valid = valid and not (d_mask & ~ROW_MASKS[b])
                if c_tight is not None:
                    a, _ = divmod(c_tight, 3)
                    valid = valid and not (d_mask & ~COL_MASKS[a])
                if d_tight is not None:
                    a, b = divmod(d_tight, 3)
                    valid = (
                        valid
                        and not (b_mask & ~COL_MASKS[a])
                        and not (c_mask & ~ROW_MASKS[b])
                    )
                if valid:
                    patterns.add(contribution(b_mask, c_mask, d_mask))
    return tuple(sorted(patterns, key=lambda p: (sum(p), p)))


def add_if_fits(state: tuple[int, ...], pattern: tuple[int, ...], target: tuple[int, ...]):
    candidate = tuple(a + b for a, b in zip(state, pattern))
    return candidate if all(a <= b for a, b in zip(candidate, target)) else None


def reachable_target(
    target: tuple[int, ...],
    ap: tuple[tuple[int, ...], ...],
    bp: tuple[tuple[int, ...], ...],
) -> tuple[bool, list[int]]:
    """Exact finite-set DP over three labeled A and six labeled BCD orbits."""
    orbit_patterns = [ap] * 3 + [bp] * 6
    minimum_remaining = [0] * (len(orbit_patterns) + 1)
    for idx in range(len(orbit_patterns) - 1, -1, -1):
        minimum_remaining[idx] = minimum_remaining[idx + 1] + min(
            sum(p) for p in orbit_patterns[idx]
        )

    states = {(0,) * 9}
    state_counts = [1]
    target_total = sum(target)
    for idx, patterns in enumerate(orbit_patterns):
        remaining_min = minimum_remaining[idx + 1]
        next_states: set[tuple[int, ...]] = set()
        for state in states:
            for pattern in patterns:
                if sum(state) + sum(pattern) + remaining_min > target_total:
                    break
                candidate = add_if_fits(state, pattern, target)
                if candidate is not None:
                    next_states.add(candidate)
        states = next_states
        state_counts.append(len(states))
        if not states:
            break
    return target in states, state_counts


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-json", type=Path, required=True)
    args = parser.parse_args()
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()

    cases = []
    for high_rows in itertools.combinations(ROWS, 3):
        high_mask = sum(1 << i for i in high_rows)
        target = tuple(4 if i in high_rows else 3 for i in ROWS)
        ap = a_patterns(high_mask)
        bp = bcd_patterns(high_mask)
        reachable, state_counts = reachable_target(target, ap, bp)
        cases.append(
            {
                "high_rows": list(high_rows),
                "high_coordinates": [list(divmod(i, 3)) for i in high_rows],
                "a_contribution_patterns": len(ap),
                "bcd_contribution_patterns": len(bp),
                "reachable": reachable,
                "dp_state_counts": state_counts,
            }
        )
        print(f"{high_rows}: reachable={reachable}, A={len(ap)}, BCD={len(bp)}, states={state_counts[-1]}", flush=True)

    canonical_payload = json.dumps(cases, sort_keys=True, separators=(",", ":")).encode()
    result = {
        "claim_scope": (
            "Exact exhaustive verification of the support-only tight-slice necessary "
            "conditions for the sole unresolved K=30 degree pattern (3,3,3,3,3,3,4,4,4)."
        ),
        "method": (
            "Pure Python integer-bitmask enumeration of all one-orbit contributions, "
            "followed by finite-set DP for 3 A columns and 6 BCD orbits; no solver used."
        ),
        "case_count": len(cases),
        "reachable_case_count": sum(case["reachable"] for case in cases),
        "unreachable_case_count": sum(not case["reachable"] for case in cases),
        "elapsed_seconds": time.perf_counter() - started,
        "cases_sha256": hashlib.sha256(canonical_payload).hexdigest(),
        "cases": cases,
        "interpretation": (
            "If reachable_case_count is zero, no support pattern with K=30 satisfies "
            "the necessary conditions. Combined with the analytic exclusions of the "
            "other K=30 degree partitions, every exact decomposition has K>=31."
        ),
    }
    args.output_json.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: result[k] for k in ("case_count", "reachable_case_count", "unreachable_case_count", "elapsed_seconds", "cases_sha256")}, indent=2))


if __name__ == "__main__":
    main()
