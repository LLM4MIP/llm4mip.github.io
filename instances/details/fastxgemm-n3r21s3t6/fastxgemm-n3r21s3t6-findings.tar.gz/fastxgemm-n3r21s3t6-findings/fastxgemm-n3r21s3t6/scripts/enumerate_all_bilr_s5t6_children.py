#!/usr/bin/env python3
"""Audit every two-A deletion child of the three explicit BILR S5T6 cores."""

from __future__ import annotations

import argparse
import importlib.util
import itertools
import json
import sys
from pathlib import Path

from enumerate_bilr_a_deletions import audit_core


def load_module(path: Path):
    sys.path.insert(0, str(path.parent.resolve()))
    spec = importlib.util.spec_from_file_location("bilr_all_source", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("bilr_source_script", type=Path)
    parser.add_argument("--output-json", type=Path, required=True)
    args = parser.parse_args()
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    module = load_module(args.bilr_source_script)
    decompositions = [
        ("S_Lader-Z3", module.LADER_FIXED, module.LADER_SEEDS, "Appendix B, equations 77--84"),
        ("Additional decomposition #1", module.ADDITIONAL_1_FIXED, module.ADDITIONAL_1_SEEDS, "Appendix A.1"),
        ("Additional decomposition #2", module.ADDITIONAL_2_FIXED, module.ADDITIONAL_2_SEEDS, "Appendix A.2, equations 53--60"),
    ]
    reports = []
    for name, fixed_matrices, seed_matrices, location in decompositions:
        fixed = [list(module.flatten(matrix)) for matrix in fixed_matrices]
        seeds = [tuple(list(module.flatten(matrix)) for matrix in seed) for seed in seed_matrices]
        full_core = {
            "A": fixed,
            "B": [seed[0] for seed in seeds],
            "C": [seed[2] for seed in seeds],
            "D": [seed[1] for seed in seeds],
        }
        parent_audit = module.audit(name, fixed_matrices, seed_matrices, location)
        if not parent_audit["exact_integer_tensor"]:
            raise ValueError(f"{name} transcription is not exact")
        cases = []
        for deleted in itertools.combinations(range(5), 2):
            kept = [index for index in range(5) if index not in deleted]
            child = {**full_core, "A": [fixed[index] for index in kept]}
            cases.append({"deleted_A_indices": list(deleted), "kept_A_indices": kept, **audit_core(child)})
        feasible = [case for case in cases if case["passes_original_discrete_side_conditions"]]
        reports.append(
            {
                "name": name,
                "source_location": location,
                "parent_K": parent_audit["core_K"],
                "case_count": len(cases),
                "best_child_objective": min(case["objective"] for case in feasible),
                "best_children": [
                    case for case in feasible
                    if case["objective"] == min(item["objective"] for item in feasible)
                ],
                "cases": cases,
            }
        )
    result = {
        "attribution": "Ballard, Ikenmeyer, Landsberg, Ryder, arXiv:1801.00843v1.",
        "scope": "All 3 explicit S=5,T=6 decompositions in the cited paper and all 10 two-A deletions of each (30 R21 children total).",
        "report_count": len(reports),
        "case_count": sum(report["case_count"] for report in reports),
        "best_objective": min(report["best_child_objective"] for report in reports),
        "reports": reports,
    }
    args.output_json.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"case_count": result["case_count"], "best_objective": result["best_objective"], "per_parent": [{"name": r["name"], "parent_K": r["parent_K"], "best": r["best_child_objective"]} for r in reports]}, indent=2))


if __name__ == "__main__":
    main()
