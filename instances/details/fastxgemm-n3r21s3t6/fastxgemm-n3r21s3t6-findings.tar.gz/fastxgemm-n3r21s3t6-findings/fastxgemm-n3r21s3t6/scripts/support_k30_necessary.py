#!/usr/bin/env python3
"""Test the tight-slice support necessary conditions at exact core support K=30.

This is deliberately a support-only relaxation.  Feasibility is not an exact
tensor decomposition; infeasibility would rule out K=30, while feasibility
only produces a witness showing where the current proof method stops.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import gurobipy as gp


ROWS = range(9)
POSITIONS = range(21)


def core_maps() -> dict[str, list[int]]:
    """Underlying core-vector index used at each rank position/mode."""
    u = list(POSITIONS)
    v = list(range(3)) + list(range(15, 21)) + list(range(3, 9)) + list(range(9, 15))
    w = list(range(3)) + list(range(9, 15)) + list(range(15, 21)) + list(range(3, 9))
    assert sorted(u) == sorted(v) == sorted(w) == list(POSITIONS)
    return {"U": u, "V": v, "W": w}


def allowed_opposite(mode: str, row: int) -> dict[str, set[int]]:
    a, b = divmod(row, 3)
    grid_row = lambda q: {3 * q + z for z in range(3)}
    grid_col = lambda q: {3 * z + q for z in range(3)}
    if mode == "U":
        return {"V": grid_row(b), "W": grid_col(a)}
    if mode == "V":
        return {"U": grid_col(a), "W": grid_row(b)}
    if mode == "W":
        return {"U": grid_row(b), "V": grid_col(a)}
    raise ValueError(mode)


def finite(value: float) -> float | None:
    return float(value) if math.isfinite(float(value)) else None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--output-model", type=Path)
    parser.add_argument("--output-iis", type=Path)
    parser.add_argument("--time-limit", type=float, default=120.0)
    parser.add_argument("--threads", type=int, default=8)
    args = parser.parse_args()
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.log.parent.mkdir(parents=True, exist_ok=True)
    if args.output_model:
        args.output_model.parent.mkdir(parents=True, exist_ok=True)
    if args.output_iis:
        args.output_iis.parent.mkdir(parents=True, exist_ok=True)

    maps = core_maps()
    model = gp.Model("fastxgemm_r21_exact_k30_support_necessary")
    x = model.addVars(POSITIONS, ROWS, vtype=gp.GRB.BINARY, name="SUPPORT")
    high = model.addVars(ROWS, vtype=gp.GRB.BINARY, name="HIGH_ROW")

    # K=30 has exactly three degree-4 rows and six degree-3 (tight) rows.
    model.addConstr(gp.quicksum(high[i] for i in ROWS) == 3, name="THREE_HIGH_ROWS")
    for i in ROWS:
        model.addConstr(
            gp.quicksum(x[q, i] for q in POSITIONS) == 3 + high[i],
            name=f"ROW_DEGREE_{i}",
        )
    for q in POSITIONS:
        model.addConstr(gp.quicksum(x[q, i] for i in ROWS) >= 1, name=f"COLUMN_NONZERO_{q}")

    implication_count = 0
    for primary_mode in ("U", "V", "W"):
        for i in ROWS:
            for p in POSITIONS:
                primary_q = maps[primary_mode][p]
                for opposite_mode, allowed in allowed_opposite(primary_mode, i).items():
                    opposite_q = maps[opposite_mode][p]
                    for j in ROWS:
                        if j not in allowed:
                            model.addConstr(
                                x[primary_q, i] + x[opposite_q, j] <= 1 + high[i],
                                name=f"TIGHT_{primary_mode}_{i}_{p}_{opposite_mode}_{j}",
                            )
                            implication_count += 1

    model.setObjective(0.0)
    model.update()
    if args.output_model:
        model.write(str(args.output_model))
    model.Params.TimeLimit = args.time_limit
    model.Params.Threads = args.threads
    model.Params.Presolve = 2
    model.Params.Symmetry = 2
    model.Params.MIPFocus = 1
    model.Params.LogFile = str(args.log)
    model.optimize()

    if model.Status == gp.GRB.INFEASIBLE and args.output_iis:
        model.computeIIS()
        model.write(str(args.output_iis))

    witness = None
    if model.SolCount:
        witness = {
            "high_rows": [i for i in ROWS if high[i].X > 0.5],
            "row_degrees": [sum(x[q, i].X > 0.5 for q in POSITIONS) for i in ROWS],
            "core_column_supports": [
                [i for i in ROWS if x[q, i].X > 0.5] for q in POSITIONS
            ],
        }

    result = {
        "claim_scope": (
            "Support-only necessary-condition model for an exact ternary cyclic R21 "
            "decomposition with K=30. Feasible does not imply an exact decomposition."
        ),
        "formulation": {
            "support_variables": 21 * 9,
            "high_row_variables": 9,
            "tight_slice_implications": implication_count,
            "row_degree_pattern": "six rows of degree 3 and three rows of degree 4",
            "column_nonzero": True,
        },
        "gurobi_version": ".".join(map(str, gp.gurobi.version())),
        "solve": {
            "status": int(model.Status),
            "status_name": {
                gp.GRB.OPTIMAL: "OPTIMAL",
                gp.GRB.INFEASIBLE: "INFEASIBLE",
                gp.GRB.TIME_LIMIT: "TIME_LIMIT",
            }.get(model.Status, str(model.Status)),
            "runtime_seconds": float(model.Runtime),
            "node_count": float(model.NodeCount),
            "solution_count": int(model.SolCount),
            "objective_bound": finite(model.ObjBound),
        },
        "outputs": {
            "model": str(args.output_model) if args.output_model else None,
            "iis": str(args.output_iis) if args.output_iis else None,
            "log": str(args.log),
        },
        "witness": witness,
        "interpretation": (
            "INFEASIBLE would prove that tight-slice support restrictions exclude K=30. "
            "OPTIMAL/feasible only certifies that these necessary conditions alone are insufficient."
        ),
    }
    args.output_json.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
