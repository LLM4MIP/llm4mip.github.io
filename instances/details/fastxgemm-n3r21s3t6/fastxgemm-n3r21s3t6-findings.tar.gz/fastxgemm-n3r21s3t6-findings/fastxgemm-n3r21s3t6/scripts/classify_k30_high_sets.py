#!/usr/bin/env python3
"""Human-scale classification for the last K=30 support case.

After counting reductions, K=30 could only survive if three BCD orbits each
have exactly two tight vectors and contribute four incidences on the three
degree-4 rows H.  Such an orbit contributes multiplicities (2,1,1), so all
three points of H would each have to be the doubled point of some admissible
orbit.  This script classifies H under simultaneous S3 relabeling and grid
transpose and checks that this never happens.
"""

from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path


def transform_point(point: int, permutation: tuple[int, int, int], transpose: bool) -> int:
    a, b = divmod(point, 3)
    if transpose:
        a, b = b, a
    return 3 * permutation[a] + permutation[b]


def canonical(high: frozenset[int]) -> tuple[int, ...]:
    images = []
    for permutation in itertools.permutations(range(3)):
        for transpose in (False, True):
            images.append(tuple(sorted(transform_point(x, permutation, transpose) for x in high)))
    return min(images)


def deficit_one_configs(high: frozenset[int]) -> list[dict]:
    """All legal configurations for a BCD orbit with two tight vectors.

    Up to cyclicly renaming B,C,D, write the tight entries as (a,b) in B and
    (c,a) in C.  Tight-slice restrictions put B in grid row a, C in grid
    column a, and the non-tight D at the singleton (b,c), which must lie in H.

    The incidence score is an upper bound: B and C need not actually use
    every available high-row entry.  Enumerating the upper bound makes the
    key ``score <= 4`` statement independent of any MIP solve.
    """
    configs = []
    for a, b, c in itertools.product(range(3), repeat=3):
        tight_b = 3 * a + b
        tight_c = 3 * c + a
        singleton_d = 3 * b + c
        if tight_b in high or tight_c in high or singleton_d not in high:
            continue
        multiplicities = {
            point: int(divmod(point, 3)[0] == a)
            + int(divmod(point, 3)[1] == a)
            + int(point == singleton_d)
            for point in high
        }
        score = sum(multiplicities.values())
        if score > 4:
            raise AssertionError(("deficit-one score exceeds four", high, a, b, c, multiplicities))
        doubled = [point for point, value in multiplicities.items() if value == 2]
        if score == 4 and (sorted(multiplicities.values()) != [1, 1, 2] or len(doubled) != 1):
            raise AssertionError(("invalid equality pattern", high, a, b, c, multiplicities))
        configs.append(
            {
                "center": a,
                "tight_entries": [tight_b, tight_c],
                "non_tight_singleton": singleton_d,
                "high_incidence_upper_bound": score,
                "multiplicities_on_H": {str(k): v for k, v in sorted(multiplicities.items())},
                "doubled_point": doubled[0] if score == 4 else None,
            }
        )
    return configs


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-json", type=Path, required=True)
    args = parser.parse_args()
    args.output_json.parent.mkdir(parents=True, exist_ok=True)

    classes: dict[tuple[int, ...], list[frozenset[int]]] = {}
    for high_tuple in itertools.combinations(range(9), 3):
        high = frozenset(high_tuple)
        classes.setdefault(canonical(high), []).append(high)

    reports = []
    all_safe = True
    all_84_max_at_most_four = True
    direct_high_set_audit = []
    for high_tuple in itertools.combinations(range(9), 3):
        high = frozenset(high_tuple)
        configs = deficit_one_configs(high)
        max_score = max((config["high_incidence_upper_bound"] for config in configs), default=0)
        if max_score > 4:
            raise AssertionError((high_tuple, max_score))
        all_84_max_at_most_four = all_84_max_at_most_four and max_score <= 4
        equality_doubled = sorted({
            config["doubled_point"]
            for config in configs
            if config["high_incidence_upper_bound"] == 4
        })
        if len(equality_doubled) > 1:
            raise AssertionError(("more than one doubleable point", high_tuple, equality_doubled))
        direct_high_set_audit.append(
            {
                "high_rows": list(high_tuple),
                "legal_configuration_count": len(configs),
                "maximum_high_incidence_upper_bound": max_score,
                "equality_doubled_rows": equality_doubled,
            }
        )

    for representative, members in sorted(classes.items()):
        high = frozenset(representative)
        all_configs = deficit_one_configs(high)
        max_score = max((config["high_incidence_upper_bound"] for config in all_configs), default=0)
        configs = [config for config in all_configs if config["high_incidence_upper_bound"] == 4]
        doubled = sorted({config["doubled_point"] for config in configs})
        safe = len(doubled) < 3
        all_safe = all_safe and safe
        reports.append(
            {
                "representative_rows": list(representative),
                "representative_coordinates": [list(divmod(x, 3)) for x in representative],
                "orbit_size": len(members),
                "legal_deficit_one_configuration_count": len(all_configs),
                "maximum_high_incidence_upper_bound": max_score,
                "max_deficit_one_configuration_count": len(configs),
                "possible_doubled_rows": doubled,
                "possible_doubled_coordinates": [list(divmod(x, 3)) for x in doubled],
                "all_three_rows_can_be_doubled": len(doubled) == 3,
                "configurations": configs,
            }
        )

    result = {
        "method": "Exact enumeration of 84 three-point subsets, compressed under simultaneous S3 relabeling and transpose.",
        "symmetry_class_count": len(reports),
        "covered_high_sets": sum(report["orbit_size"] for report in reports),
        "all_84_high_sets_checked_directly": len(direct_high_set_audit) == 84,
        "all_84_deficit_one_maximum_at_most_four": all_84_max_at_most_four,
        "all_classes_exclude_three_distinct_doubled_points": all_safe,
        "direct_high_set_audit": direct_high_set_audit,
        "classes": reports,
        "interpretation": (
            "The counting proof requires three deficit-one BCD components, each with four high-row incidences. "
            "Their doubled points would have to be the three distinct elements of H. The table shows that every "
            "H symmetry class has fewer than three possible doubled points, completing the support contradiction."
        ),
    }
    args.output_json.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "symmetry_class_count": result["symmetry_class_count"],
        "covered_high_sets": result["covered_high_sets"],
        "all_84_max_at_most_four": all_84_max_at_most_four,
        "all_safe": all_safe,
        "table": [
            {
                "H": report["representative_coordinates"],
                "orbit_size": report["orbit_size"],
                "possible_doubled": report["possible_doubled_coordinates"],
            }
            for report in reports
        ],
    }, indent=2))


if __name__ == "__main__":
    main()
