#!/usr/bin/env python3
"""Enumerate all 84 possible degree-4 row sets in the K=30 support relaxation."""

from __future__ import annotations

import argparse
import concurrent.futures
import itertools
import json
from pathlib import Path

import gurobipy as gp

from support_k30_necessary import allowed_opposite, core_maps


ROWS = tuple(range(9))
POSITIONS = tuple(range(21))


def build(high_rows: tuple[int, int, int], relax: bool) -> tuple[gp.Model, int]:
    high = set(high_rows)
    maps = core_maps()
    model = gp.Model(f"k30_high_{'_'.join(map(str, high_rows))}_{'lp' if relax else 'mip'}")
    model.Params.OutputFlag = 0
    vtype = gp.GRB.CONTINUOUS if relax else gp.GRB.BINARY
    x = model.addVars(POSITIONS, ROWS, lb=0.0, ub=1.0, vtype=vtype, name="SUPPORT")
    for i in ROWS:
        model.addConstr(gp.quicksum(x[q, i] for q in POSITIONS) == (4 if i in high else 3))
    for q in POSITIONS:
        model.addConstr(gp.quicksum(x[q, i] for i in ROWS) >= 1)
    implications = 0
    for primary_mode in ("U", "V", "W"):
        for i in ROWS:
            if i in high:
                continue
            for p in POSITIONS:
                primary_q = maps[primary_mode][p]
                for opposite_mode, allowed in allowed_opposite(primary_mode, i).items():
                    opposite_q = maps[opposite_mode][p]
                    for j in ROWS:
                        if j not in allowed:
                            model.addConstr(x[primary_q, i] + x[opposite_q, j] <= 1)
                            implications += 1
    model.setObjective(0.0)
    return model, implications


def solve_case(payload: tuple[tuple[int, int, int], int, float]) -> dict:
    high_rows, threads, time_limit = payload
    lp, implications = build(high_rows, True)
    lp.Params.Method = 1
    lp.optimize()
    lp_result = {
        "status": int(lp.Status),
        "runtime_seconds": float(lp.Runtime),
        "iterations": float(lp.IterCount),
    }

    mip, _ = build(high_rows, False)
    mip.Params.Threads = threads
    mip.Params.Presolve = 2
    mip.Params.Symmetry = 2
    mip.Params.SolutionLimit = 1
    mip.Params.TimeLimit = time_limit
    mip.optimize()
    mip_result = {
        "status": int(mip.Status),
        "runtime_seconds": float(mip.Runtime),
        "nodes": float(mip.NodeCount),
        "solutions": int(mip.SolCount),
    }
    return {
        "high_rows": list(high_rows),
        "high_coordinates": [list(divmod(i, 3)) for i in high_rows],
        "tight_slice_implications": implications,
        "lp": lp_result,
        "mip": mip_result,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--threads", type=int, default=1)
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument("--case-time-limit", type=float, default=120.0)
    args = parser.parse_args()
    args.output_json.parent.mkdir(parents=True, exist_ok=True)

    high_sets = list(itertools.combinations(ROWS, 3))
    payloads = [(h, args.threads, args.case_time_limit) for h in high_sets]
    cases = []
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
        for completed, case in enumerate(pool.map(solve_case, payloads), start=1):
            cases.append(case)
            if completed % 10 == 0 or completed == len(payloads):
                print(f"completed {completed}/{len(payloads)}", flush=True)
    result = {
        "scope": (
            "All C(9,3)=84 degree patterns in the support-only necessary-condition "
            "relaxation for exact K=30. Individual cases are conclusive only when their "
            "status is INFEASIBLE or a feasible solution is present; time-limited cases are open."
        ),
        "gurobi_version": ".".join(map(str, gp.gurobi.version())),
        "case_count": len(cases),
        "summary": {
            "lp_infeasible": sum(c["lp"]["status"] == gp.GRB.INFEASIBLE for c in cases),
            "lp_feasible": sum(c["lp"]["status"] == gp.GRB.OPTIMAL for c in cases),
            "mip_infeasible": sum(c["mip"]["status"] == gp.GRB.INFEASIBLE for c in cases),
            "mip_feasible": sum(c["mip"]["solutions"] > 0 for c in cases),
            "mip_time_limit_without_solution": sum(
                c["mip"]["status"] == gp.GRB.TIME_LIMIT and c["mip"]["solutions"] == 0
                for c in cases
            ),
            "total_lp_runtime_seconds": sum(c["lp"]["runtime_seconds"] for c in cases),
            "total_mip_runtime_seconds": sum(c["mip"]["runtime_seconds"] for c in cases),
            "total_mip_nodes": sum(c["mip"]["nodes"] for c in cases),
        },
        "cases": cases,
        "interpretation": (
            "Only a completed infeasibility result for all 84 cases would exclude the remaining "
            "K=30 pattern. This finite-time run is diagnostic when any case timed out; the published "
            "LB93 proof instead uses the complete counting/classification audit."
        ),
    }
    args.output_json.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result["summary"], indent=2))


if __name__ == "__main__":
    main()
