#!/usr/bin/env python3
"""Exact three-vector radius-one search around the strict 2168 solution.

Every unordered triple of distinct underlying A/B/C/D column vectors is
replaced independently within coefficient-Hamming radius one.  Interactions
between B/C/D vectors belonging to the same cyclic column are recomputed
jointly.  The search covers C(21,3)*19^3 = 9,122,470 nominal replacements.

Only tensors with E <= 2 need be matched, because an objective below 2168 is
equivalent to E <= 1, or E == 2 and K <= 55.  All retained matches are checked
again by an independent expansion of all 729 tensor entries.  This is a local
exhaustive certificate, not a global optimality proof.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import time
from pathlib import Path

import numpy as np

import exact_semantic_audit as semantic
from two_vector_r2_each_exact import (
    LETTERS,
    allowed_final_errors,
    candidate_component_deltas,
    component,
    component_key,
    group_component,
    joint_group_components,
    orbit_representatives,
    target_on_orbits,
)


def candidates_radius_one(vector: np.ndarray) -> np.ndarray:
    candidates = [vector.copy()]
    for position in range(9):
        for value in (-1, 0, 1):
            if value == vector[position]:
                continue
            candidate = vector.copy()
            candidate[position] = value
            candidates.append(candidate)
    result = np.asarray(candidates, dtype=np.int16)
    if result.shape != (19, 9) or len({row.tobytes() for row in result}) != 19:
        raise RuntimeError(f"unexpected candidate set: {result.shape}")
    return result


def triple_structure_valid(
    base_row_coverage: np.ndarray,
    incumbent_k: int,
    old_vectors: list[np.ndarray],
    new_vectors: list[np.ndarray],
) -> tuple[bool, int]:
    if any(np.count_nonzero(vector) == 0 for vector in new_vectors):
        return False, 0
    k_value = incumbent_k
    coverage = base_row_coverage.copy()
    for old, new in zip(old_vectors, new_vectors):
        k_value += int(np.count_nonzero(new)) - int(np.count_nonzero(old))
        coverage += (new != 0).astype(np.int16) - (old != 0).astype(np.int16)
    return bool(k_value >= 28 and np.all(coverage >= 1)), k_value


def full_tensor_crosscheck(
    blocks: dict[str, np.ndarray],
    vector_ids: list[tuple[str, int]],
    new_vectors: list[np.ndarray],
    target: np.ndarray,
) -> tuple[int, int, int]:
    trial = {letter: matrix.copy() for letter, matrix in blocks.items()}
    for vector_id, new_vector in zip(vector_ids, new_vectors):
        trial[vector_id[0]][:, vector_id[1]] = new_vector
    a, b, c, d = (trial[letter] for letter in LETTERS)
    u = np.hstack((a, b, c, d)).astype(np.int16)
    v = np.hstack((a, d, b, c)).astype(np.int16)
    w = np.hstack((a, c, d, b)).astype(np.int16)
    expansion = np.einsum("ir,jr,kr->ijk", u, v, w, optimize=True)
    errors = target - expansion
    e_value = int(np.sum(np.abs(errors)))
    k_value = int(sum(np.count_nonzero(trial[letter]) for letter in LETTERS))
    return e_value, k_value, int(np.max(np.abs(errors)))


def three_way_group_components(
    b: np.ndarray,
    c: np.ndarray,
    d_candidates: np.ndarray,
    reps: np.ndarray,
) -> np.ndarray:
    i, j, k = reps[:, 0], reps[:, 1], reps[:, 2]
    return (
        b[i][None, :] * d_candidates[:, j] * c[k][None, :]
        + c[i][None, :] * b[j][None, :] * d_candidates[:, k]
        + d_candidates[:, i] * c[j][None, :] * b[k][None, :]
    ).astype(np.int16)


def describe(vector_id: tuple[str, int], old: np.ndarray, new: np.ndarray) -> dict:
    return {
        "vector": f"{vector_id[0]}{vector_id[1]}",
        "hamming_distance": int(np.count_nonzero(old != new)),
        "old": old.astype(int).tolist(),
        "new": new.astype(int).tolist(),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()
    started = time.perf_counter()

    supplied, _ = semantic.read_solution(args.solution)
    raw = semantic.reconstruct_blocks(supplied, tolerance=0.0)
    blocks = {letter: np.asarray(raw[letter], dtype=np.int16) for letter in LETTERS}
    reps, weights = orbit_representatives()
    target_orbits = target_on_orbits(reps)
    target_full = np.asarray(
        [
            semantic.target_value(i, j, k)
            for i in range(9)
            for j in range(9)
            for k in range(9)
        ],
        dtype=np.int16,
    ).reshape(9, 9, 9)
    components = {
        key: component(blocks, key, reps)
        for key in [*(('A', column) for column in range(3)), *(("G", column) for column in range(6))]
    }
    incumbent_tensor = sum(components.values(), np.zeros(len(reps), dtype=np.int16))
    incumbent_error = target_orbits - incumbent_tensor
    incumbent_e = int(np.abs(incumbent_error) @ weights)
    incumbent_k = int(sum(np.count_nonzero(blocks[letter]) for letter in LETTERS))
    incumbent_objective = 1000 * incumbent_e + 3 * incumbent_k
    if (incumbent_e, incumbent_k, incumbent_objective) != (2, 56, 2168):
        raise RuntimeError("unexpected incumbent semantics")

    vector_ids = [("A", column) for column in range(3)] + [
        (letter, column) for letter in "BCD" for column in range(6)
    ]
    candidate_sets = {
        vector_id: candidates_radius_one(blocks[vector_id[0]][:, vector_id[1]])
        for vector_id in vector_ids
    }
    deltas = {
        vector_id: candidate_component_deltas(
            blocks,
            vector_id[0],
            vector_id[1],
            candidate_sets[vector_id],
            reps,
        )
        for vector_id in vector_ids
    }
    base_row_coverage = sum(
        np.count_nonzero(blocks[letter], axis=1) for letter in LETTERS
    ).astype(np.int16)
    allowed_errors = allowed_final_errors(reps)

    best = {
        "objective": incumbent_objective,
        "E": incumbent_e,
        "K": incumbent_k,
        "triple": None,
        "replacements": [],
    }
    strict_improvements: list[dict] = []
    triple_reports: list[dict] = []
    category_counts = {"all_components_distinct": 0, "one_same_component_pair": 0, "all_same_component": 0}
    total_low_error_matches = 0
    total_structurally_valid_matches = 0
    full_crosschecks = 0

    def process_match(
        ids: list[tuple[str, int]],
        indexes: tuple[int, int, int],
        e_value: int,
    ) -> tuple[bool, int, int]:
        nonlocal best, full_crosschecks
        old_vectors = [blocks[letter][:, column] for letter, column in ids]
        new_vectors = [candidate_sets[vector_id][index] for vector_id, index in zip(ids, indexes)]
        valid, k_value = triple_structure_valid(
            base_row_coverage, incumbent_k, old_vectors, new_vectors
        )
        if not valid:
            return False, k_value, 0
        checked_e, checked_k, checked_max = full_tensor_crosscheck(
            blocks, ids, new_vectors, target_full
        )
        if (checked_e, checked_k) != (e_value, k_value) or checked_max > 1:
            raise RuntimeError(
                f"orbit/full cross-check failed for {ids}: "
                f"orbit={(e_value, k_value)}, full={(checked_e, checked_k, checked_max)}"
            )
        full_crosschecks += 1
        objective = 1000 * e_value + 3 * k_value
        record = {
            "objective": objective,
            "E": e_value,
            "K": k_value,
            "triple": [f"{letter}{column}" for letter, column in ids],
            "replacements": [
                describe(vector_id, old, new)
                for vector_id, old, new in zip(ids, old_vectors, new_vectors)
            ],
        }
        if objective < best["objective"]:
            best = record
        if objective < incumbent_objective and len(strict_improvements) < 100:
            strict_improvements.append(record)
        return True, k_value, objective

    for triple in itertools.combinations(vector_ids, 3):
        ids = list(triple)
        keys = [component_key(*vector_id) for vector_id in ids]
        unique_keys = set(keys)
        low_matches = 0
        valid_matches = 0
        triple_best: int | None = None

        if len(unique_keys) == 3:
            category = "all_components_distinct"
            pair_map: dict[bytes, list[tuple[int, int]]] = {}
            for first_index, first_delta in enumerate(deltas[ids[0]]):
                for second_index, second_delta in enumerate(deltas[ids[1]]):
                    pair_delta = (first_delta + second_delta).astype(np.int16)
                    pair_map.setdefault(pair_delta.tobytes(), []).append(
                        (first_index, second_index)
                    )
            for third_index, third_delta in enumerate(deltas[ids[2]]):
                for final_error, e_value in allowed_errors:
                    needed = (incumbent_error - final_error - third_delta).astype(np.int16)
                    for first_index, second_index in pair_map.get(needed.tobytes(), ()):
                        low_matches += 1
                        valid, _, objective = process_match(
                            ids, (first_index, second_index, third_index), e_value
                        )
                        if valid:
                            valid_matches += 1
                            triple_best = objective if triple_best is None else min(triple_best, objective)

        elif len(unique_keys) == 2:
            category = "one_same_component_pair"
            duplicate_key = next(key for key in unique_keys if keys.count(key) == 2)
            pair_positions = [position for position, key in enumerate(keys) if key == duplicate_key]
            single_position = next(position for position, key in enumerate(keys) if key != duplicate_key)
            pair_ids = [ids[position] for position in pair_positions]
            single_id = ids[single_position]
            old_component = components[duplicate_key]
            pair_delta_map: dict[bytes, list[tuple[int, int]]] = {}
            for first_index, first_candidate in enumerate(candidate_sets[pair_ids[0]]):
                new_components = joint_group_components(
                    blocks,
                    pair_ids[0][1],
                    pair_ids[0][0],
                    pair_ids[1][0],
                    first_candidate,
                    candidate_sets[pair_ids[1]],
                    reps,
                )
                for second_index, new_component in enumerate(new_components):
                    pair_delta = (new_component - old_component).astype(np.int16)
                    pair_delta_map.setdefault(pair_delta.tobytes(), []).append(
                        (first_index, second_index)
                    )
            for single_index, single_delta in enumerate(deltas[single_id]):
                for final_error, e_value in allowed_errors:
                    needed = (incumbent_error - final_error - single_delta).astype(np.int16)
                    for first_index, second_index in pair_delta_map.get(needed.tobytes(), ()):
                        indexes_list = [0, 0, 0]
                        indexes_list[pair_positions[0]] = first_index
                        indexes_list[pair_positions[1]] = second_index
                        indexes_list[single_position] = single_index
                        low_matches += 1
                        valid, _, objective = process_match(
                            ids, tuple(indexes_list), e_value
                        )
                        if valid:
                            valid_matches += 1
                            triple_best = objective if triple_best is None else min(triple_best, objective)

        else:
            category = "all_same_component"
            by_letter = {vector_id[0]: vector_id for vector_id in ids}
            if set(by_letter) != {"B", "C", "D"}:
                raise RuntimeError(f"unexpected all-same-component triple: {ids}")
            column = ids[0][1]
            old_component = group_component(blocks, column, reps)
            for b_index, b_candidate in enumerate(candidate_sets[by_letter["B"]]):
                for c_index, c_candidate in enumerate(candidate_sets[by_letter["C"]]):
                    new_components = three_way_group_components(
                        b_candidate,
                        c_candidate,
                        candidate_sets[by_letter["D"]],
                        reps,
                    )
                    final_errors = incumbent_error[None, :] - (
                        new_components - old_component[None, :]
                    )
                    e_values = np.abs(final_errors) @ weights
                    allowed_mask = np.all(np.abs(final_errors) <= 1, axis=1) & (e_values <= 2)
                    for d_index in np.flatnonzero(allowed_mask):
                        indexes_by_letter = {"B": b_index, "C": c_index, "D": int(d_index)}
                        indexes = tuple(indexes_by_letter[vector_id[0]] for vector_id in ids)
                        e_value = int(e_values[d_index])
                        low_matches += 1
                        valid, _, objective = process_match(ids, indexes, e_value)
                        if valid:
                            valid_matches += 1
                            triple_best = objective if triple_best is None else min(triple_best, objective)

        category_counts[category] += 1
        total_low_error_matches += low_matches
        total_structurally_valid_matches += valid_matches
        triple_reports.append(
            {
                "triple": [f"{letter}{column}" for letter, column in ids],
                "interaction_category": category,
                "nominal_candidates": 19**3,
                "low_error_matches_E_le_2": low_matches,
                "structurally_valid_low_error_matches": valid_matches,
                "best_objective_among_low_error_matches": triple_best,
            }
        )

    nominal = len(triple_reports) * 19**3
    if len(triple_reports) != 1330 or nominal != 9_122_470:
        raise RuntimeError("triple enumeration count mismatch")
    if category_counts != {
        "all_components_distinct": 1000,
        "one_same_component_pair": 324,
        "all_same_component": 6,
    }:
        raise RuntimeError(f"unexpected interaction category counts: {category_counts}")
    if full_crosschecks != total_structurally_valid_matches:
        raise RuntimeError("not every structurally valid match was cross-checked")

    result = {
        "instance": "fastxgemm-n3r21s3t6",
        "method": (
            "exact replacement of every unordered triple of distinct underlying "
            "vectors, coefficient-Hamming radius at most 1 per vector"
        ),
        "input_solution": "artifacts/exact_2168.sol",
        "input_solution_sha256": hashlib.sha256(args.solution.read_bytes()).hexdigest(),
        "arithmetic": (
            "integer cyclic-orbit matching plus independent integer expansion of "
            "all 729 entries for every structurally valid low-error match"
        ),
        "incumbent": {"E": incumbent_e, "K": incumbent_k, "objective": incumbent_objective},
        "scope": {
            "underlying_vectors": len(vector_ids),
            "unordered_distinct_vector_triples": len(triple_reports),
            "candidates_per_vector": 19,
            "nominal_triple_replacements": nominal,
            "maximum_hamming_radius_per_vector": 1,
            "maximum_total_coefficient_hamming_radius": 3,
            "allowed_final_error_patterns_E_le_2": len(allowed_errors),
            "interaction_category_counts": category_counts,
        },
        "search_counts": {
            "triple_replacements_with_E_le_2_before_structure_checks": total_low_error_matches,
            "original_model_structurally_valid_triple_replacements_with_E_le_2": (
                total_structurally_valid_matches
            ),
            "independent_full_729_entry_crosschecks": full_crosschecks,
        },
        "best": best,
        "strict_improvement_found": bool(strict_improvements),
        "strict_improvements_saved": strict_improvements,
        "certificate_scope": (
            "No objective below 2168 exists among points whose changes are confined "
            "to at most three distinct A/B/C/D column vectors, with at most one "
            "changed coefficient in each. This is a local exhaustive certificate, "
            "not a global optimality proof."
        ),
        "elapsed_seconds": time.perf_counter() - started,
        "triple_results": triple_reports,
    }
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(
        json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "best": best,
                "strict_improvement_found": bool(strict_improvements),
                "nominal": nominal,
                "low_error_matches": total_low_error_matches,
                "structurally_valid_low_error_matches": total_structurally_valid_matches,
                "elapsed_seconds": result["elapsed_seconds"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
