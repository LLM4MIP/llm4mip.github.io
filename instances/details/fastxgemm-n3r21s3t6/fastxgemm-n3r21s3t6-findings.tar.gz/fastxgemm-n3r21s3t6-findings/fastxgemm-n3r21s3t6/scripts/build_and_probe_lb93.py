#!/usr/bin/env python3
"""Add the integer-valid support + 9*error >= 93 row and probe LP/root."""

from __future__ import annotations

import argparse
import gzip
import json
import math
from pathlib import Path

import gurobipy as gp


CUT_NAME = "VALID_LB93_KPLUS9E"


def read_solution(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix == ".gz" else open
    result: dict[str, float] = {}
    with opener(path, "rt", encoding="utf-8") as stream:
        for raw in stream:
            fields = raw.strip().split()
            if len(fields) >= 2 and not fields[0].startswith(("#", "=")):
                result[fields[0]] = float(fields[1])
    return result


def finite(value: float) -> float | None:
    return float(value) if math.isfinite(float(value)) else None


def solve_probe(model: gp.Model, mode: str, seconds: float, threads: int, log: Path) -> dict:
    probe = model.relax() if mode == "lp" else model.copy()
    probe.Params.TimeLimit = seconds
    probe.Params.Threads = threads
    probe.Params.Presolve = 2
    probe.Params.NumericFocus = 2
    probe.Params.LogFile = str(log)
    if mode == "lp":
        probe.Params.Method = 1
        probe.Params.FeasibilityTol = 1e-9
        probe.Params.OptimalityTol = 1e-9
    else:
        probe.Params.NodeLimit = 0
        probe.Params.MIPFocus = 3
        probe.Params.Symmetry = 2
    probe.optimize()
    return {
        "mode": mode,
        "status": int(probe.Status),
        "status_name": {
            gp.GRB.OPTIMAL: "OPTIMAL",
            gp.GRB.NODE_LIMIT: "NODE_LIMIT",
            gp.GRB.TIME_LIMIT: "TIME_LIMIT",
        }.get(probe.Status, str(probe.Status)),
        "runtime_seconds": float(probe.Runtime),
        "work": float(probe.Work),
        "simplex_iterations": float(probe.IterCount),
        "node_count": float(probe.NodeCount),
        "solution_count": int(probe.SolCount),
        "objective": finite(probe.ObjVal) if probe.SolCount else None,
        "objective_bound": finite(probe.ObjBound) if probe.IsMIP else None,
        "mip_gap": finite(probe.MIPGap) if probe.IsMIP and probe.SolCount else None,
        "dimensions": {
            "variables": probe.NumVars,
            "constraints": probe.NumConstrs,
            "nonzeros": probe.NumNZs,
        },
    }


def row_signature(model: gp.Model) -> dict:
    cut = model.getConstrByName(CUT_NAME)
    if cut is None:
        raise RuntimeError(f"missing emitted row {CUT_NAME}")
    row = model.getRow(cut)
    coefficient_counts: dict[str, int] = {}
    family_counts = {"ABS_ALT": 0, "RESIDUAL": 0, "OTHER": 0}
    for idx in range(row.size()):
        coefficient = row.getCoeff(idx)
        variable = row.getVar(idx)
        key = format(coefficient, ".12g")
        coefficient_counts[key] = coefficient_counts.get(key, 0) + 1
        if variable.VarName.startswith("ABS_ALT_"):
            family_counts["ABS_ALT"] += 1
        elif variable.VarName.startswith("RESIDUAL_"):
            family_counts["RESIDUAL"] += 1
        else:
            family_counts["OTHER"] += 1
    return {
        "name": cut.ConstrName,
        "sense": cut.Sense,
        "rhs": cut.RHS,
        "nonzeros": row.size(),
        "coefficient_counts": coefficient_counts,
        "family_counts": family_counts,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--output-model", type=Path, required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--lp-log", type=Path, required=True)
    parser.add_argument("--root-log", type=Path, required=True)
    parser.add_argument("--time-limit", type=float, default=120.0)
    parser.add_argument("--threads", type=int, default=8)
    args = parser.parse_args()

    for path in (args.output_model, args.output_json, args.lp_log, args.root_log):
        path.parent.mkdir(parents=True, exist_ok=True)

    model = gp.read(str(args.mps))
    original = {
        "variables": model.NumVars,
        "constraints": model.NumConstrs,
        "nonzeros": model.NumNZs,
        "integer_variables": sum(v.VType in {gp.GRB.BINARY, gp.GRB.INTEGER} for v in model.getVars()),
    }
    abs_alt = [v for v in model.getVars() if v.VarName.startswith("ABS_ALT_")]
    residual = [v for v in model.getVars() if v.VarName.startswith("RESIDUAL_")]
    if len(abs_alt) != 567 or len(residual) != 729:
        raise RuntimeError(f"unexpected families: ABS_ALT={len(abs_alt)}, RESIDUAL={len(residual)}")

    model.addConstr(gp.quicksum(abs_alt) + 9 * gp.quicksum(residual) >= 93, name=CUT_NAME)
    model.update()
    model.write(str(args.output_model))

    # Re-read the actual deliverable, rather than trusting only the in-memory row.
    emitted = gp.read(str(args.output_model))
    signature = row_signature(emitted)
    expected_signature = {
        "sense": ">",
        "rhs": 93.0,
        "nonzeros": 1296,
        "coefficient_counts": {"1": 567, "9": 729},
        "family_counts": {"ABS_ALT": 567, "RESIDUAL": 729, "OTHER": 0},
    }
    for key, value in expected_signature.items():
        if signature[key] != value:
            raise AssertionError((key, signature[key], value))

    incumbent = read_solution(args.solution)
    missing = [v.VarName for v in abs_alt + residual if v.VarName not in incumbent]
    if missing:
        raise RuntimeError(f"solution omits {len(missing)} cut variables; first={missing[:5]}")
    incumbent_support = sum(incumbent[v.VarName] for v in abs_alt)
    incumbent_error = sum(incumbent[v.VarName] for v in residual)
    incumbent_lhs = incumbent_support + 9 * incumbent_error

    augmented_integer_variables = sum(
        v.VType in {gp.GRB.BINARY, gp.GRB.INTEGER} for v in emitted.getVars()
    )
    report = {
        "claim_scope": (
            "Numerical construction/probe of the integer-valid CUT-93 proved in LB93_PROOF.md. "
            "LP/root values show the effect after adding the row; they are not the validity proof."
        ),
        "gurobi_version": ".".join(map(str, gp.gurobi.version())),
        "input_mps": str(args.mps),
        "checked_solution": str(args.solution),
        "output_model": str(args.output_model),
        "emitted_model_reread": True,
        "cut": {
            **signature,
            "checked_solution_support_float": incumbent_support,
            "checked_solution_error_float": incumbent_error,
            "checked_solution_lhs_float": incumbent_lhs,
            "checked_solution_slack_float": incumbent_lhs - 93,
        },
        "integer_projection_check": {
            "original": original,
            "augmented": {
                "variables": emitted.NumVars,
                "constraints": emitted.NumConstrs,
                "nonzeros": emitted.NumNZs,
                "integer_variables": augmented_integer_variables,
            },
            "new_variables": emitted.NumVars - original["variables"],
            "new_integer_variables": augmented_integer_variables - original["integer_variables"],
        },
        "parameters": {
            "time_limit": args.time_limit,
            "threads": args.threads,
            "presolve": 2,
            "numeric_focus": 2,
            "lp_method": 1,
            "root_node_limit": 0,
            "root_mip_focus": 3,
            "root_symmetry": 2,
        },
    }
    report["lp_probe"] = solve_probe(emitted, "lp", args.time_limit, args.threads, args.lp_log)
    report["root_probe"] = solve_probe(emitted, "root", args.time_limit, args.threads, args.root_log)
    args.output_json.write_text(
        json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    print(json.dumps({"cut": report["cut"], "lp": report["lp_probe"], "root": report["root_probe"]}, indent=2))


if __name__ == "__main__":
    main()
