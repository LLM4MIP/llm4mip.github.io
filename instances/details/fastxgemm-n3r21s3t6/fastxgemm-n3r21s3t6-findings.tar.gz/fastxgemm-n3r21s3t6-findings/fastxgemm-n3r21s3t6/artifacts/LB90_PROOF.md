# Historical valid lower-bound cut of 90 for `fastxgemm-n3r21s3t6`

> This valid proof is retained as research history. It is strictly strengthened
> by `LB93_PROOF.md`, which gives the current project lower bound 93.

This note proves a statement about the **specific MIPLIB model**
`fastxgemm-n3r21s3t6`: ternary factors, rank 21, and the fixed cyclic
parametrization `S=3,T=6`.  It does not prove a general lower bound of 21 or
22 for unrestricted 3-by-3 matrix multiplication.

## Notation

Write the 21-column factor matrices as

```text
U = [A B C D],   V = [A D B C],   W = [A C D B],
```

where `A` has three columns and `B,C,D` each have six.  Every factor entry is
in `{-1,0,1}` at an integer solution.  Let

```text
K = number of nonzero entries in [A B C D].
```

Block permutation shows that each of `U,V,W` has exactly `K` nonzeros, so the
full factor support is `3K`.

Index a row of a factor matrix by a pair in `{0,1,2}^2`, using
`(a,b) -> 3a+b`.  The matrix-multiplication tensor has ones precisely at

```text
((n,q), (q,m), (m,n)),   n,q,m in {0,1,2},
```

and zeros elsewhere.

## Lemma 1: every factor row has degree at least three

Fix the first-mode row `i=(n,q)`.  Its target slice is a 9-by-9 matrix with
three ones at

```text
((q,m),(m,n)),   m=0,1,2.
```

This slice has rank three.  In an exact decomposition it is

```text
sum_{r : U[i,r] != 0} U[i,r] V[:,r] W[:,r]^T.
```

If `d_i` is the number of nonzeros in row `i` of `U`, the right side has rank
at most `d_i`; hence `d_i >= 3`.  Because `U,V,W` differ only by permutations
of the blocks `A,B,C,D`, the same row-degree sequence occurs in all three
modes and

```text
sum_i d_i = K.
```

## Lemma 2: distinct tight rows use disjoint rank columns

Call row `i=(n,q)` *tight* when `d_i=3`.  Its rank-three slice is then a sum
of exactly three rank-one matrices.  Both sets of opposite-mode vectors must
be linearly independent and span the exact column and row spaces of the
slice.  Thus, for every participating rank column `r`,

```text
V[:,r] lies in span{e_(q,m) : m=0,1,2},
W[:,r] lies in span{e_(m,n) : m=0,1,2}.
```

Suppose two distinct tight `U` rows `(n,q)` and `(n',q')` shared a rank
column.  If `q != q'`, the two required coordinate spaces for `V[:,r]` are
disjoint, forcing `V[:,r]=0`.  If `q=q'`, then `n != n'` and the two required
coordinate spaces for `W[:,r]` are disjoint, forcing `W[:,r]=0`.  In either
case the shared rank-one term is zero, so a tight rank-three slice would be
represented by at most two nonzero rank-one terms, which is impossible.
Therefore the three rank columns incident to each tight row are disjoint from
those of every other tight row; no separate nonzero-column constraint is
needed for this conclusion.

## Proposition: exact reconstruction implies `K >= 30`

If `K <= 28`, the nine degrees are at least three and at most one unit above
their total minimum of 27.  At least eight rows are tight.  Lemma 2 would then
require at least `8*3=24` distinct rank columns, but only 21 exist.

It remains to exclude `K=29`.  The possible degree patterns are:

1. eight rows of degree three and one of degree five; or
2. seven rows of degree three and two of degree four.

The first case is excluded by the same `24>21` count.  In the second case,
the seven tight rows use all 21 rank columns exactly once.  The row degrees
are identical in `U,V,W`, so this statement holds in every mode.

More explicitly, applying Lemma 2 separately in each mode shows that the
seven tight rows of `U` partition the 21 rank columns into seven disjoint
triples.  The seven tight rows of `V` do the same, independently, and so do
the seven tight rows of `W`.  Hence every rank column is incident to exactly
one tight row in each of the three modes.

Take any rank column `r`.  It is incident to a tight row in each mode.  Write
those tight coordinates as

```text
i=(n,q) in U,   j=(q',m) in V,   k=(m',n') in W.
```

Applying the tight-slice restrictions in the three modes gives

```text
U[:,r] in span{e_(a,q') : a=0,1,2}
         intersect span{e_(n',b) : b=0,1,2},

V[:,r] in span{e_(q,b) : b=0,1,2}
         intersect span{e_(a,m') : a=0,1,2},

W[:,r] in span{e_(a,n) : a=0,1,2}
         intersect span{e_(m,b) : b=0,1,2}.
```

Each intersection is one-dimensional and supported on a single coordinate.
Moreover, each rank column is incident to a tight row in every mode, so its
coordinate in every factor is nonzero.  Every column of each factor is
therefore a singleton.  Each factor would have exactly 21 nonzeros, implying
`K=21`, in contradiction with `K=29`.  Hence every exact reconstruction has
`K>=30`.

## The globally valid cut

At an integer factor assignment, the product gadgets make every reconstructed
tensor entry integral.

- If the tensor reconstruction is exact, the proposition gives full factor
  support `3K >= 90`, and `sum(ABS_ALT) >= 90`.
- If it is inexact, at least one integer tensor discrepancy has magnitude at
  least one, so `sum(RESIDUAL) >= 1`.  The original MPS already contains
  `sum(ABS_ALT) >= 84`.

Consequently every integer-feasible point satisfies

```text
sum(ABS_ALT) + 6 sum(RESIDUAL) >= 90.                 (CUT-90)
```

Here `ABS_ALT` dominates the entrywise absolute values of the factors, while
`ABS_ALT`, `RESIDUAL`, and `ABS_DIFF` are all nonnegative.  `CUT-90` is an
**integer-valid cut**: its proof uses integrality of the factor pattern and
does not claim that the inequality is valid for every point of the original
continuous LP relaxation.

The original objective is

```text
1000 sum(RESIDUAL) + sum(ABS_ALT) + 0.001 sum(ABS_DIFF),
```

with nonnegative residual and difference variables.  Therefore `(CUT-90)`
also proves the global objective lower bound 90.  Adding this row strengthens
only the continuous relaxation; it removes no integer-feasible solution.
