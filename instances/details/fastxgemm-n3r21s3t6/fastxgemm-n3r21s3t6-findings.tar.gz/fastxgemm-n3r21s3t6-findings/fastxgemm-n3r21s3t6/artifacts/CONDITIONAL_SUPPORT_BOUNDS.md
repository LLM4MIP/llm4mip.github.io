# Conditional support bounds for `fastxgemm-n3r21s3t6`

> **Historical, superseded context.** The conditional inequalities in this
> note remain valid, but references to the verified 2168 incumbent describe the
> earlier Sorber start. The current strict interval is `[93,2147]`, with
> external-derived incumbent `E=2,K=49`; see `../README.md` and
> `LB93_PROOF.md` for the current result.

This note sharpens the support analysis only on the branch in which the
actual tensor \(\ell_1\) error is at most two.  It concerns the particular
ternary, cyclic \(S=3,T=6,R=21\) MIPLIB model, not unrestricted matrix
multiplication algorithms.

## Result

Let

* \(E\) be the actual integer tensor \(\ell_1\) error;
* \(K\) be the number of nonzeros in one factor matrix (equivalently, in
  the underlying block matrix \([A\ B\ C\ D]\)); hence the full support in
  \(U,V,W\) is \(3K\);
* \(m\) be the number of **missing positive diagonal tensor entries** among
  \((0,0,0),(4,4,4),(8,8,8)\).  “Missing” means that the target coefficient
  1 is reconstructed as 0, not as 2.

For an integer solution of the official model with \(E\leq 2\),

\[
                         \boxed{K+m\geq 30}.                 \tag{1}
\]

Consequently:

| Error case | Lower bound on \(K\) | Lower bound on full support \(3K\) |
|---|---:|---:|
| \(E=1\), the error is a missing positive diagonal | 29 | 87 |
| \(E=1\), any other possible error | 30 | 90 |
| \(E=2\), no missing positive diagonal | 30 | 90 |
| \(E=2\), exactly one missing positive diagonal | 29 | 87 |
| \(E=2\), two missing positive diagonals | 28 | 84 |

Thus \(E=1\) has an unconditional improvement from the model's existing
full-support bound 84 to 87.  For arbitrary \(E=2\), no unconditional
improvement over 84 follows: the important two-missing-diagonals branch
remains at 84. The historical verified incumbent of value 2168 lies in precisely this
last branch (it misses \((0,0,0)\) and \((4,4,4)\)), although its actual
support is much larger, \(K=56\).

## 1. Which diagonal errors are possible

Index a factor row by a grid coordinate \(x=(a,b)\in\{0,1,2\}^2\), flattened
as \(3a+b\).  Cyclic invariance sends a tensor coordinate
\((i,j,k)\) to \((j,k,i)\).  Every non-diagonal coordinate therefore has an
orbit of size three.  With integer residuals and \(E\leq2\), a non-diagonal
error is impossible; all errors must be at \((x,x,x)\).

The official model bounds each residual by one.  Hence, for \(E\leq2\),
there are at most two distinct unit errors.  The three diagonal coordinates
with target value one are \(x=0,4,8\); the other six diagonal coordinates
have target value zero.

Fix the first-mode slice with row \(x=(a,b)\).  Its target is a rank-three
9-by-9 partial permutation matrix.  Changing only \((x,x,x)\) has one of
three effects:

1. If \(a=b\) and the target 1 is changed to 0, the slice rank falls from
   three to two.  Call this an `M` (missing) row.
2. If \(a=b\) and the target 1 is changed to 2, the slice still has rank
   three and exactly the same row and column spaces as the target.  Treat it
   as a normal rank-three row.
3. If \(a\ne b\), the erroneous entry is outside both the row space and the
   column space of the target slice.  The slice rank rises from three to
   four.  Call this an `O` (off-target) row.

The same classification holds in all three modes because the erroneous
coordinate is diagonal.

## 2. Tight-slice restrictions

For a row \(i\), let \(d_i\) be its number of nonzeros in a factor matrix.
The cyclic block form

```text
U = [A B C D],   V = [A D B C],   W = [A C D B]
```

implies that the row-degree sequence is identical in all three factors.
Slice rank gives

* \(d_i\geq3\) for a normal row;
* \(d_i\geq2\) for an `M` row;
* \(d_i\geq4\) for an `O` row.

A normal row with degree three, or an `M` row with degree two, is called
*rank-tight*.  Equality in the rank bound forces every opposite factor
vector used by that slice into its exact slice row/column space.  For a
normal row these are coordinate lines of length three in the 3-by-3 grid;
for an `M` row they are the corresponding coordinate lines with one basis
vector deleted.

Two distinct rank-tight rows in the same mode cannot share a rank column.
For two normal rows this is the disjointness argument used in
`LB90_PROOF.md`.  It remains true when one or both rows are `M` rows: either
their required row-coordinate lines are disjoint, or their required
column-coordinate lines are disjoint.  A shared column would force one of
the opposite factor vectors to zero, contrary to the model's nonzero-column
constraints.

There is a second useful consequence.  If a rank column is incident to a
rank-tight row in each of the three modes, each of its three factor vectors
is constrained by a grid row in one opposite mode and a grid column in the
other.  Their intersection has at most one coordinate.  Since factor
columns are nonzero, that rank-one term is coordinate-singleton.

## 3. Proof when there is no missing positive diagonal (\(m=0\))

Let \(q\in\{0,1,2\}\) be the number of `O` errors.  All other rows have
rank three with the standard coordinate spaces.  The row-rank lower bound
is

\[
                 K=\sum_i d_i\geq27+q.
\]

Assume \(K\leq29\).  Directly distributing the at most \(2-q\) excess
degrees shows one of the following:

* more than seven normal rows are tight, so their disjoint rank columns
  number more than \(7\cdot3=21\); or
* exactly seven normal rows are tight and use all 21 rank columns.

The first case is impossible.  In the second case every rank column is
covered by a tight row in every mode, so the preceding intersection argument
makes every rank-one term coordinate-singleton.  That would give \(K=21\),
contradicting \(K\geq27+q\).  Therefore \(K\geq30\).

This covers both an overshoot of a positive target diagonal and an error at
one of the six zero target diagonals.

## 4. Proof when exactly one positive diagonal is missing (\(m=1\))

The official model already contains \(K\geq28\).  Suppose for contradiction
that \(K=28\).  Besides the one rank-two `M` row, there are either

* eight normal rank-three rows; or
* seven normal rank-three rows and one rank-four `O` row.

Distributing the two excess degrees in the first case, or the one excess
degree in the second case, shows that every allocation is immediately
impossible by tight-row disjointness except one common pattern:

```text
one tight M row          ->  2 disjoint rank columns
six tight normal rows    -> 18 disjoint rank columns
                              ------------------------
                              20 covered columns
```

Thus exactly one of the 21 rank positions is not incident to any tight row
in a given mode.

The cyclic parametrization induces an order-three permutation of rank
positions: each `A` position is fixed, while each triple
`(B_t,C_t,D_t)` is a 3-cycle.  Because the tight row set is the same in all
three modes, there are only two possibilities for the unique uncovered
position.

For clarity, for each fixed `t` the column mapping is exactly

| rank position | factor in `U` | factor in `V` | factor in `W` |
|---|---|---|---|
| `B_t` position | `B_t` | `D_t` | `C_t` |
| `C_t` position | `C_t` | `B_t` | `D_t` |
| `D_t` position | `D_t` | `C_t` | `B_t` |

Thus if the unique uncovered position for `U` is the `B_t` position, the
unique uncovered positions for `V` and `W` are respectively the `C_t` and
`D_t` positions.  This is the cyclic-column mapping used below.

### 4.1 The uncovered position is an `A` column

The same position is uncovered in all three modes.  The other 20 rank terms
are covered in every mode and hence are coordinate-singleton.  Since
\(K=28\), the remaining `A` vector must have support eight.  Its contribution
\(a\otimes a\otimes a\) has \(8^3=512\) nonzero coordinates.  Twenty
coordinate-singleton terms can cancel at most twenty of them, whereas the
target plus at most two unit errors has support at most 29.  This is
impossible.

### 4.2 The uncovered position belongs to a `(B_t,C_t,D_t)` orbit

The three modes then have three different uncovered positions in that
orbit.  The other 18 rank terms are covered in all modes and are
coordinate-singleton.

Name the underlying vector that is uncovered when it is the primary factor
`B` (the names can be cyclically relabelled).  The other two underlying
vectors `C,D` are primary factors of tight slices.  Their tight-slice
restrictions constrain `B` in complementary ways: at the `C_t` rank
position, tightness of the primary `C_t` puts `B_t` in a grid row; at the
`D_t` rank position, tightness of the primary `D_t` puts `B_t` in a grid
column.  Hence their intersection has at most one coordinate, so
\(|\operatorname{supp}B|\leq1\).  They constrain each of `C,D` from at least
one opposite mode, so

\[
 |\operatorname{supp}B|+|\operatorname{supp}C|+
 |\operatorname{supp}D|\leq1+3+3=7.
\]

Consequently the total one-factor support is at most \(18+7=25\), contrary
to \(K=28\).  Both possibilities are excluded, so \(K\geq29\).

## 5. Why the same argument stops with two missing diagonals

When two positive diagonals are missing, the basic rank lower bounds sum to

\[
                  2+2+7\cdot3=25.
\]

At \(K=28\), the three excess degrees can be placed on three different
normal rows.  The degree pattern can then be

```text
2, 2, 4, 4, 4, 3, 3, 3, 3,
```

so the two tight `M` rows and four tight normal rows require only
\(2+2+4\cdot3=16\) disjoint rank columns.  Five rank positions remain
uncovered.  This satisfies all the slice-rank and tight-row incidence counts;
the one-uncovered-column argument from Section 4 no longer applies.

This is an obstruction to the **present proof method**, not a constructed
factorization with \(K=28\).  No such feasible tensor decomposition was
found here, and this note does not assert that one exists.  Excluding it
would require information beyond individual slice ranks and tight-row
counting, such as coupled multi-slice equations or a checkable exhaustive
certificate.

## 6. Solver cut for the \(E\leq2\) search branch

Let

```text
Rplus = RESIDUAL_0_0_0 + RESIDUAL_4_4_4 + RESIDUAL_8_8_8.
```

Every missing positive diagonal forces its corresponding residual to one,
so `Rplus >= m`.  Equation (1) therefore gives the directly usable valid
inequality

```text
sum_{f in {U,V,W},i,r} ABS_f_i_r + 3 Rplus >= 90.       (CUT-COND-90)
```

The same inequality with `ABS_ALT` in place of `ABS` is also valid because
`ABS_ALT >= |factor|`.  `CUT-COND-90` must be added together with the branch
restriction

```text
sum_{i,j,k} RESIDUAL_i_j_k <= 2.
```

It is not claimed globally for solutions with larger tensor error.

For a sharper formulation, introduce a binary `MISS_x` for each
`x in {0,4,8}` and let

```text
y_x = sum_r VALUE_x_x_x_r.
MISS_x + y_x >= 1
2 MISS_x + y_x <= 2
```

On this branch \(y_x\in\{0,1,2\}\), so these constraints make `MISS_x=1`
exactly when the target 1 is reconstructed as 0.  Then the strongest result
proved here is

```text
sum_{i,r} ABS_U_i_r + sum_{x in {0,4,8}} MISS_x >= 30,
```

or its three-factor symmetric version with right-hand side 90.

### LP-relaxation check

`scripts/probe_conditional_support_cut.py` independently tested the simple
`Rplus` version on the complete official MPS.  On the branch that fixes all
non-diagonal residuals to zero and fixes the sum of the nine diagonal
residuals to one, Gurobi 13.0.2 solved both LP relaxations to optimality:

| LP | Objective bound | Runtime |
|---|---:|---:|
| Original branch | 1084.0000000000002 | 2.884 s |
| With `CUT-COND-90` | 1087.0000000000002 | 2.913 s |

Thus this cut realizes exactly the predicted three-unit strengthening on
the \(E=1\) LP branch.  This is only an LP-relaxation measurement, not an
integer infeasibility or optimality proof.  Machine-readable details are in
`artifacts/conditional_e1_lp_probe.json`; logs are
`logs/conditional_e1_lp_baseline.log` and
`logs/conditional_e1_lp_cut.log`.

## Scope warning

The bounds above use all of the following: integer ternary factors, the
specific cyclic block structure, 21 rank columns, nonzero factor columns,
the official model's existing \(K\geq28\), and the branch \(E\leq2\).  They
must not be stated as lower bounds for unrestricted rank-21 matrix
multiplication decompositions.
