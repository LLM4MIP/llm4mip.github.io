# Official-submission provenance of the 2168 MIP start

## Scope and conclusion

This note records where the `fastxgemm-N3-R21-S3-T6.lp.mst` file came
from and what can, and cannot, be concluded about its absence from the public
MIPLIB incumbent list.

The key finding is stronger than merely locating the file in the author's
GitHub repository: **the MIP start was part of Laurent Sorber's original
MIPLIB 2017 submission on 2017-04-30, and it remained in the official ZIB
submission repositories.**  A strict audit against the present official MPS
gives objective 2168 with no tolerance-dependent feasibility.  Nevertheless,
the public MIPLIB solution history does not list this solution.  The available
official records do not document why it was not registered.

## 1. Original MIPLIB submission

The authoritative submission record is ZIB's public
[`miplib2017/submissions`](https://git.zib.de/miplib2017/submissions)
repository.

- Submission commit:
  [`26a7703fda632540c6df3c537f41b07f61d7de37`](https://git.zib.de/miplib2017/submissions/-/commit/26a7703fda632540c6df3c537f41b07f61d7de37)
- Author and commit time: `2017-04-30T14:06:06+02:00`
- Commit message: `New submission at 2017-04-30 14:06:05.234168`
- Original submission directory:
  `9e830301-898b-4340-97f7-c8478277e652`
- MIP-start path:
  [`9e830.../misc/fastxgemm-N3-R21-S3-T6.lp.mst`](https://git.zib.de/miplib2017/submissions/-/blob/26a7703fda632540c6df3c537f41b07f61d7de37/9e830301-898b-4340-97f7-c8478277e652/misc/fastxgemm-N3-R21-S3-T6.lp.mst)
- Git object at that path: `89edb75aae0743a10fc3d05af71a140fdc676b5c`

The Git object is an LFS pointer whose payload metadata is:

```text
version https://git-lfs.github.com/spec/v1
oid sha256:c2b001e63a0e8a602a89c82907ccef0ee783e39cda72b8816c69e86aa70a7891
size 450862
```

The submitted LP is present in the same commit at
`instances/fastxgemm-N3-R21-S3-T6.lp`.  Its LFS metadata gives SHA-256
`a8edb2756b526a177f28a74a0c10baa8535f79f0ac3c27ed1e7d197dc73e397e`
and size `12,381,855` bytes.

On 2017-05-26, ZIB renamed UUID submission directories to submitter names in
commit
[`2ff902dc3c23e436f48ba4f74bedfb3f39cefb75`](https://git.zib.de/miplib2017/submissions/-/commit/2ff902dc3c23e436f48ba4f74bedfb3f39cefb75).
The MST was moved without content change to
`Laurent_Sorber/misc/fastxgemm-N3-R21-S3-T6.lp.mst`.

The later official
[`miplib2017/revised-submissions-final`](https://git.zib.de/miplib2017/revised-submissions-final)
repository also contains the file.  Its root commit
[`0489c6fde5691138e639fb5ddf48260488411ea3`](https://git.zib.de/miplib2017/revised-submissions-final/-/commit/0489c6fde5691138e639fb5ddf48260488411ea3),
dated `2018-08-09T10:58:24+02:00`, stores the 450,862-byte CRLF payload as Git
blob `f4ff4760973c0e1fd81b3ec6fd1befc8b0834f62` at
[`Laurent_Sorber/misc/fastxgemm-N3-R21-S3-T6.lp.mst`](https://git.zib.de/miplib2017/revised-submissions-final/-/blob/0489c6fde5691138e639fb5ddf48260488411ea3/Laurent_Sorber/misc/fastxgemm-N3-R21-S3-T6.lp.mst).

These records establish as fact that the MST was delivered to MIPLIB before
the 2018 problem-selection solution was recorded.

## 2. Author-repository lineage and line endings

The author's primary source repository is
[`lsorber/fast-matrix-multiplication`](https://github.com/lsorber/fast-matrix-multiplication).
The MST first appears in commit
[`165ac7dc40e3cb0bbb8d03008a2b787acd9cbe9e`](https://github.com/lsorber/fast-matrix-multiplication/commit/165ac7dc40e3cb0bbb8d03008a2b787acd9cbe9e),
dated `2017-04-30T13:27:24+02:00`, with the message
`Finalized intances for submission to MIPLIB 2017. Added manuscript.`  This
precedes the official submission commit by about 39 minutes.

Pinned source file:
[`instances/fastxgemm-N3-R21-S3-T6.lp.mst`](https://github.com/lsorber/fast-matrix-multiplication/blob/165ac7dc40e3cb0bbb8d03008a2b787acd9cbe9e/instances/fastxgemm-N3-R21-S3-T6.lp.mst)

There are two byte hashes because GitHub stores the text with LF endings,
whereas the MIPLIB LFS payload uses CRLF endings:

| Representation | Bytes | SHA-256 |
|---|---:|---|
| GitHub Git blob `5deaa53ac235e87ad59e3dc43092b0a883321740` (LF) | 432,177 | `acc84e37d1cf563fd4559d22b2b336949c39059c8b9aca6187318cc3599dc862` |
| MIPLIB LFS payload / Windows checkout (CRLF) | 450,862 | `c2b001e63a0e8a602a89c82907ccef0ee783e39cda72b8816c69e86aa70a7891` |

After replacing CRLF with LF, the two byte sequences are identical.  The
18,685-byte size difference is exactly one extra carriage-return byte for
each of 18,685 line endings.  Thus this is serialization, not a difference in
any variable value.

## 3. The submitted solve command intentionally loads the MST

The accompanying `solve.sh` was also part of the original submission.  Its
LFS payload has SHA-256
`f7efd6e3358bea71503a76a62ff475be3f1558e8b39409dee75156b86b6024a5`
and size 129 bytes.  The content retained in the revised official repository
is:

```sh
gurobi_cl Threads=14 MIPGap=1e-16 MIPFocus=3 Method=2 CutPasses=1 Presolve=2 LogFile=$1.log ResultFile=$1.sol InputFile=$1.mst $1
```

Official permalink:
[`Laurent_Sorber/models/solve.sh`](https://git.zib.de/miplib2017/revised-submissions-final/-/blob/0489c6fde5691138e639fb5ddf48260488411ea3/Laurent_Sorber/models/solve.sh)

`InputFile=$1.mst` is explicit evidence that the submitter intended Gurobi to
load the same-basename start when solving an LP instance.

## 4. Equivalence to the official MPS and strict feasibility

The local reproducibility audit compared the upstream LP with the current
official MIPLIB MPS coefficient by coefficient.  They have the same 18,684
variables, 219,368 rows, 718,146 nonzeros, names and order, bounds, objective,
row senses, right-hand sides, and coefficient matrix.  The only type-label
difference is that 378 `[0,1]` variables are written as binary in the LP and
as bounded general integers in the MPS; their feasible domains coincide.

See [`lp_mps_equivalence.json`](./lp_mps_equivalence.json).  Recorded hashes:

- submitted/upstream LP:
  `a8edb2756b526a177f28a74a0c10baa8535f79f0ac3c27ed1e7d197dc73e397e`;
- official compressed MPS:
  `210e76e09285ab346c1ae92155d5fc88efeeaafe96a4b5944b54011fa0103fba`;
- decompressed official MPS:
  `eefb351399b3b19bf9f972483f76c6539f444a8403621cdb0060aebfa40896c5`.

The strict audit in [`strict_2168_audit.json`](./strict_2168_audit.json)
checks every one of the 18,684 supplied values against the official MPS using
exact decimal and integer-matrix evaluation.  It reports:

- every variable supplied exactly once and every declared integer value
  integral;
- zero bound, row, and integrality violations;
- exact objective `2168`;
- semantic reconstruction error `E=2` and cyclic-core support `K=56`, hence
  `1000E + 3K = 2168`.

This establishes a strict feasible upper bound of 2168.  It does **not** prove
that 2168 is globally optimal.

## 5. What the public MIPLIB record says

The current official
[`fastxgemm-n3r21s3t6` instance page](https://miplib.zib.de/instance_details_fastxgemm-n3r21s3t6.html)
still labels the instance open and displays `4110.99800117485*`.  Its solution
history starts with objective 21084 on 2018-10-13 (problem selection) and does
not contain 2168.

The MIPLIB 2017 paper states that supplementary `misc` directories may include
MIP-start files, while its standardized performance study processed every
instance with eight solvers.  It also states that improving solutions sent for
the public page must use the solution-checker format and be accompanied by a
description.  See
[`MIPLIB 2017: Data-Driven Compilation of the 6th Mixed-Integer Programming Library`](https://doi.org/10.1007/s12532-020-00194-3),
Sections 3.1, 4.6--4.7, and 6.3.

### Established facts

1. The author generated the MST before submitting the instances.
2. The MST was included in the original official MIPLIB submission and was
   retained in later official repositories.
3. The submitter's own solve script tells Gurobi to load the MST.
4. The present public solution list does not include it.
5. The MST is strictly feasible for the official MPS with objective 2168.

### Inference, not documented fact

The observed record is consistent with MIPLIB's standardized performance and
solution-publication pipelines not automatically executing submitter-specific
scripts or converting every supplementary `.mst` into a checker-format
`.sol`.  In particular, had this exact start been loaded and accepted in the
reported Gurobi run, an incumbent of 21084 could not have remained the best
recorded solution.  However, no public issue, commit message, paper passage,
or page note found in this audit states the actual operational reason.

Accordingly, the defensible wording is:

> The objective-2168 MIP start was present in MIPLIB's official submission
> data, but it was never registered in the public solution archive.  The
> reason is undocumented; failure of the standardized pipeline to ingest the
> supplementary Gurobi `.mst` is a plausible explanation, not a verified
> historical fact.

It would be inappropriate to claim that MIPLIB rejected the start, that the
file was absent from the submission, or that a numerical-feasibility problem
caused the omission without further evidence from the maintainers.
