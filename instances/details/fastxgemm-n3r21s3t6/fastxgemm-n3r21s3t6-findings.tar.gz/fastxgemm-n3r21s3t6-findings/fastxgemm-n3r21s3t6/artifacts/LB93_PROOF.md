# A valid global lower-bound cut of 93 for `fastxgemm-n3r21s3t6`

This note strengthens the published project bound 90 for the **specific**
MIPLIB model `fastxgemm-n3r21s3t6`: ternary factors, rank 21, and the fixed
cyclic parametrization `S=3,T=6`.  It does not claim a rank lower bound for
unrestricted 3-by-3 matrix multiplication.

The earlier `LB90_PROOF.md` establishes all facts used below through the
exclusion of exact core support `K <= 29`.  They are recalled briefly so that
the new `K=30` exclusion can be checked on its own.

## 1. Notation and tight-slice facts

Write

```text
U = [A B C D],   V = [A D B C],   W = [A C D B],
```

where `A` has three columns and `B,C,D` each have six.  A row coordinate is
`(a,b) in {0,1,2}^2`.  Let `K` be the number of nonzero entries in the core
`[A B C D]`; the full factor support is `3K`.

For an exact decomposition every one of the nine core rows has degree at
least three.  A row of degree three is called *tight*.  Its three incident
rank columns are disjoint from the three incident columns of every other
tight row.  Indeed, the opposite factors of a rank-one term in the slice at
`(a,b)` must respectively lie in the coordinate row/column spaces selected
by `a,b`; two distinct tight slices sharing the term would force one opposite
factor to zero.  In particular, a core vector can contain at most one tight
row entry.

The earlier count already excludes `K <= 29`.  At `K=30`, the possible row
degree partitions are

```text
(6,3,3,3,3,3,3,3,3),
(5,4,3,3,3,3,3,3,3),
(4,4,4,3,3,3,3,3,3).
```

The first has eight tight rows, which would need `8*3=24>21` rank columns.
In the second, the seven tight rows use all 21 rank columns in each mode.
Thus every factor column meets one tight row in all three modes; the
row/column-space intersections make every factor column a singleton.  That
would give `K=21`, not 30.  Only the third partition remains.

Let `H` be its three degree-four rows.  The other six rows are tight.  Their
18 incidences occupy 18 distinct core vectors, so exactly three of the 21
core vectors contain no tight entry.  Call such a vector *deficient*.  Since
the total support is 30, the three rows in `H` must carry exactly 12
incidences, four on each row.

## 2. Coordinate-line restrictions inside one `BCD` orbit

Consider matching columns `B,C,D` in one of the six cyclic orbits.  The three
rank-one terms use `(B,D,C)`, `(C,B,D)`, and `(D,C,B)` in `(U,V,W)` order.
The tight-slice restriction gives the following implications:

```text
B tight at (a,b)  =>  C is supported in column a,
                        D is supported in row b;
C tight at (c,d)  =>  B is supported in row d,
                        D is supported in column c;
D tight at (e,f)  =>  B is supported in column e,
                        C is supported in row f.
```

Here a grid row is `{(x,0),(x,1),(x,2)}` and a grid column is
`{(0,x),(1,x),(2,x)}`.

If all three vectors are tight, the intersections above make all three
singletons, so this orbit has no incidence in `H`.

If exactly one vector is deficient, cyclically rename so that `D` is the
deficient one.  Write the tight locations as

```text
B: (a,b),   C: (c,a).
```

Then `B` is confined to row `a`, `C` to column `a`, and `D` to the singleton
`(b,c)`, which must belong to `H`.  Hence the number of possible `H`
incidences is at most

```text
|H intersect row(a)| + |H intersect column(a)| + 1.       (1)
```

Both tight locations are outside `H`, so each of the first two terms is at
most two.  A value five in (1) is impossible.  If `(a,a)` is not in `H`, two
row points plus two column points are four distinct points, while `|H|=3`.
If `(a,a)` is in `H`, value five would put all of `H` in the row/column
cross.  But `(b,c)` cannot lie in that cross: `b=a` would make the tight
location `(a,b)` equal the high center, and `c=a` would do the same to the
other tight location.  Thus a one-deficient orbit contributes at most four
high incidences.

If exactly two vectors are deficient, rename so only `B` is tight at `(a,b)`.
The deficient `C,D` are confined to column `a` and row `b`; `B` itself can
use at most all three high rows.  Since a three-point set meets a row and a
column with total multiplicity at most four, the orbit contributes at most
`3+4=7` high incidences.

If all three vectors are deficient, they are supported inside `H` and
contribute at most nine.  Summarizing, an orbit with `d=0,1,2,3` deficient
vectors contributes at most

```text
d             0   1   2   3
high bound    0   4   7   9.
```

For an `A` column, a tight entry `(a,b)` makes the same vector lie in grid
row `b` and grid column `a`.  Because the vector also contains `(a,b)`, this
is possible only for `a=b`, and the vector is that diagonal singleton.  A
nondeficient `A` column therefore has zero high incidences; a deficient one
has at most three.

## 3. Equality would require three incompatible doubled points

There are exactly three deficient core vectors.  The bounds above are
`3d`, except that a `BCD` orbit with `d=1` or `d=2` can gain one extra.
Therefore 12 high incidences can occur only if:

1. no `A` column is deficient;
2. three distinct `BCD` orbits each have exactly one deficient vector; and
3. every one of those orbits attains its bound four.

In an equality case of (1), the multiplicities contributed on the three
points of `H` are exactly `(2,1,1)`.  A multiplicity three would require the
singleton `(b,c)` to be the center `(a,a)`, contradicting that the two tight
locations are outside `H`.  If the center is absent, row `a` and column `a`
are disjoint on `H`, so only the singleton can create a doubled point.  If
the center is present, the singleton cannot lie in their cross: `b=a` or
`c=a` would make one tight location equal that high center.  Hence in this
case only the center can be doubled.  Thus two doubled points are impossible,
and each equality orbit has a unique *doubled point* of `H`.

Adding three `(2,1,1)` patterns and obtaining row degrees `(4,4,4)` requires
their doubled points to be the three distinct points of `H`.  But a
three-point set `H` has at most one point that can be doubled:

* If the doubled point is off diagonal, then the center `(a,a)` is absent.
  Equality forces all of `H` into the row/column cross at `a`.  The two tight
  exclusions leave exactly an all-off-diagonal wedge
  `{(a,c),(a,d),(d,a)}` or its transpose, with `{a,c,d}={0,1,2}`.  Its unique
  unpaired directed edge is the only possible doubled point.
* If the doubled point is the diagonal center `(a,a)`, equality forces `H`
  to contain the center, one other point in its cross, and the singleton
  outside that cross.  No off-diagonal point can also be doubled, because an
  off-diagonal equality set contains no diagonal point.  If the outside
  singleton is another diagonal `(d,d)`, the tight exclusions force the
  cross point to use the third symbol, so it lies outside the cross at `d`;
  consequently `(d,d)` cannot be a second doubled center.

This contradiction excludes exact `K=30`.  Together with the earlier cases,

```text
every exact cyclic R21 decomposition has K >= 31.          (2)
```

## 4. Finite audit of the last combinatorial step

`classify_k30_high_sets.py` independently enumerates all `C(9,3)=84` sets
`H`.  For every legal parameters `(a,b,c)` in the one-deficient case it
explicitly asserts the general incidence bound in (1) is at most four.  It
then compresses the 84 sets under simultaneous `S3` relabeling and grid
transpose into the following 12 classes:

| representative `H` | orbit size | max of (1) | possible doubled point |
|---|---:|---:|---|
| `00,01,02` | 6 | 2 | none |
| `00,01,10` | 6 | 1 | none |
| `00,01,11` | 6 | 1 | none |
| `00,01,12` | 12 | 3 | none |
| `00,01,20` | 6 | 2 | none |
| `00,01,21` | 12 | 4 | `00` |
| `00,01,22` | 12 | 4 | `00` |
| `00,11,22` | 1 | 3 | none |
| `00,12,21` | 3 | 3 | none |
| `01,02,10` | 12 | 4 | `02` |
| `01,02,12` | 6 | 3 | none |
| `01,12,20` | 2 | 3 | none |

The orbit sizes sum to 84, and no representative has more than one possible
doubled point.  This audit uses only finite Python sets and assertions; the
proof of (2) does not rely on a Gurobi status or an IIS.

## 5. The globally valid cut

At an integer factor assignment, the product gadgets make every reconstructed
tensor entry integral.

* If reconstruction is exact, (2) gives full factor support `3K >= 93`, so
  `sum(ABS_ALT) >= 93`.
* If reconstruction is inexact, at least one integral tensor discrepancy has
  magnitude at least one, so `sum(RESIDUAL) >= 1`.  The original official MPS
  already imposes `sum(ABS_ALT) >= 84`.

Therefore every integer-feasible point satisfies

```text
sum(ABS_ALT) + 9 sum(RESIDUAL) >= 93.                 (CUT-93)
```

This is an **integer-valid cut**; it is not asserted for arbitrary points of
the original continuous relaxation.  Since the original objective is

```text
1000 sum(RESIDUAL) + sum(ABS_ALT) + 0.001 sum(ABS_DIFF),
```

with all displayed auxiliary variables nonnegative, `CUT-93` proves the
global mathematical objective lower bound 93.
