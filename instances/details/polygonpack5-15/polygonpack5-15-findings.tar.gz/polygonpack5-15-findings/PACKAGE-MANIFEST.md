# Package manifest: polygonpack5-15

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 69
Excluded source files: 1

## Included files

- `README.md`
- `SHA256SUMS`
- `analysis/exact-geometry-structure.json`
- `analysis/gurobi-13.0.1-structure.json`
- `analysis/objective-layer-screen.json`
- `analysis/polygonpack5-15-public-1-exact-audit.json`
- `analysis/polygonpack5-15-public-2-exact-audit.json`
- `analysis/polygonpack5-15-public-3-exact-audit.json`
- `analysis/polygonpack5-15-public-4-exact-audit.json`
- `analysis/polygonpack5-15-public-5-exact-audit.json`
- `analysis/polygonpack5-15-public-6-exact-audit.json`
- `analysis/polygonpack5-15-public-7-exact-audit.json`
- `analysis/strict-candidate-literal-audit.json`
- `experiments/copt_fix_and_reoptimize30.py`
- `experiments/copt_object_neighborhood.py`
- `experiments/copt_orientation_local_branch.py`
- `experiments/fixed-pattern-summary.json`
- `experiments/object-neighborhoods/case-0.json`
- `experiments/object-neighborhoods/case-1.json`
- `experiments/object-neighborhoods/case-10-6.json`
- `experiments/object-neighborhoods/case-10-7.json`
- `experiments/object-neighborhoods/case-10-8.json`
- `experiments/object-neighborhoods/case-10-9.json`
- `experiments/object-neighborhoods/case-10.json`
- `experiments/object-neighborhoods/case-11-6.json`
- `experiments/object-neighborhoods/case-11-7.json`
- `experiments/object-neighborhoods/case-11-8.json`
- `experiments/object-neighborhoods/case-11-9.json`
- `experiments/object-neighborhoods/case-11.json`
- `experiments/object-neighborhoods/case-12-6.json`
- `experiments/object-neighborhoods/case-12-7.json`
- `experiments/object-neighborhoods/case-12-8.json`
- `experiments/object-neighborhoods/case-12-9.json`
- `experiments/object-neighborhoods/case-12.json`
- `experiments/object-neighborhoods/case-13-6.json`
- `experiments/object-neighborhoods/case-13-7.json`
- `experiments/object-neighborhoods/case-13-8.json`
- `experiments/object-neighborhoods/case-13-9.json`
- `experiments/object-neighborhoods/case-13.json`
- `experiments/object-neighborhoods/case-14-6.json`
- `experiments/object-neighborhoods/case-14-7.json`
- `experiments/object-neighborhoods/case-14-8.json`
- `experiments/object-neighborhoods/case-14-9.json`
- `experiments/object-neighborhoods/case-14.json`
- `experiments/object-neighborhoods/case-2.json`
- `experiments/object-neighborhoods/case-3.json`
- `experiments/object-neighborhoods/case-4.json`
- `experiments/object-neighborhoods/case-5-6.json`
- `experiments/object-neighborhoods/case-5-7.json`
- `experiments/object-neighborhoods/case-5-8.json`
- `experiments/object-neighborhoods/case-5.json`
- `experiments/object-neighborhoods/case-6.json`
- `experiments/object-neighborhoods/case-7.json`
- `experiments/object-neighborhoods/case-8.json`
- `experiments/object-neighborhoods/case-9.json`
- `experiments/radius2-summary.json`
- `experiments/radius3-summary.json`
- `experiments/recover_geometry_xml.py`
- `experiments/screen_object_subsets15.py`
- `input/polygonpack5-15-public-1.sol.gz`
- `input/polygonpack5-15-public-2.sol.gz`
- `input/polygonpack5-15-public-3.sol.gz`
- `input/polygonpack5-15-public-4.sol.gz`
- `input/polygonpack5-15-public-5.sol.gz`
- `input/polygonpack5-15-public-6.sol.gz`
- `input/polygonpack5-15-public-7.sol.gz`
- `logs/gurobi-13.0.1-structure.log`
- `solutions/polygonpack5-15-strict.sol`
- `solutions/strict-candidate.validation.log`

## Excluded files

- `input/polygonpack5-15.mps.gz (7762826 bytes; raw benchmark input; sha256 b17ab6bd54ec97a9f6d8ae89b22d6890a5a9ae4a6260ad5a8974974796156f12)`
