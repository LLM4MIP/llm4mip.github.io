# Package manifest: cvrpb-n45k5vrpi

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 57
Excluded source files: 1

## Included files

- `.gitattributes`
- `README.md`
- `SHA256SUMS`
- `analysis/compiled-mps-projection.json`
- `analysis/free-fleet-kge6-proof.json`
- `analysis/gurobi-structure.json`
- `analysis/optimality-proof.md`
- `analysis/source-equivalence.json`
- `artifacts/independent-original-mps-audit.json`
- `artifacts/structure.compact.json`
- `artifacts/target-751-report.json`
- `experiments/audit_compiled_mps_projection.py`
- `experiments/audit_source_equivalence.py`
- `experiments/check_indicator_mps_solution.py`
- `experiments/copt_original_cutoff.py`
- `experiments/copt_route_lift.py`
- `experiments/copt_standard_cvrp.py`
- `experiments/gurobi_original_optimize_probe.py`
- `experiments/gurobi_structure_export.py`
- `experiments/prove_standard_cvrp.py`
- `experiments/prove_standard_cvrp_route_interval.py`
- `input/B-n45-k5.sol`
- `input/B-n45-k5.vrp`
- `input/B-n45-k5.vrp.dzn`
- `input/cvrpb-n45k5vrpi-public-2.sol.gz`
- `logs/copt-original-cutoff-timelimit-summary.json`
- `logs/copt-original-cutoff-timelimit.log`
- `logs/exploratory-free-fleet-copt-interrupted.log`
- `logs/exploratory-free-fleet-gurobi-interrupted.log`
- `logs/gurobi-exact5-cutoff-timelimit-summary.json`
- `logs/gurobi-exact5-cutoff-timelimit.log`
- `logs/gurobi-free-fleet-kge6-proof.log`
- `logs/gurobi-kge5-cutoff-timelimit-summary.json`
- `logs/gurobi-kge5-cutoff-timelimit.log`
- `logs/gurobi-original-optimize-probe.json`
- `logs/gurobi-original-optimize-probe.log`
- `logs/gurobi-structure.log`
- `logs/gurobi-target-751.log`
- `scripts/audit_target_solution.py`
- `scripts/cvrpb_forensics.py`
- `scripts/cvrpb_giant_lift.py`
- `scripts/targeted_751_feasibility.py`
- `solutions/copt-route-lift-summary.json`
- `solutions/copt-route-lift.log`
- `solutions/cvrpb-751-full.sol`
- `solutions/cvrpb-751-full.sol.gz`
- `solutions/cvrpb-751-full.validation.json`
- `solutions/miplib-775.sol.gz`
- `solutions/miplib-775.validation.json`
- `solutions/semantic-witness.json`
- `solutions/target-751.sol`
- `sources/B-n45-k5.sol`
- `sources/B-n45-k5.vrp`
- `sources/B-n45-k5.vrp.dzn`
- `sources/B-n45-k5.vrp.metadata`
- `sources/PROVENANCE.md`
- `sources/cvrp.mzn`

## Excluded files

- `input/cvrpb-n45k5vrpi.mps.gz (2105506 bytes; raw benchmark input; sha256 368e6310ad1426214baab11beac8a6384315e7c98b8dcc56e2156b8bef187940)`
