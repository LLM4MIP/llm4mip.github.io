# Source provenance

All URLs were retrieved or checked on 2026-09-07.  Exact local bytes are
identified in the instance-level `SHA256SUMS` file.

- MIPLIB instance metadata, current incumbent 775, submitter, and compilation
  description:
  <https://miplib.zib.de/instance_details_cvrpb-n45k5vrpi.html>
- Original MIPLIB indicator MPS:
  <https://miplib.zib.de/WebData/instances/cvrpb-n45k5vrpi.mps.gz>
- MIPLIB incumbent revision 2:
  <https://miplib.zib.de/downloads/solutions/cvrpb-n45k5vrpi/2/cvrpb-n45k5vrpi.sol.gz>
- MiniZinc benchmark directory and model/data provenance:
  <https://github.com/MiniZinc/minizinc-benchmarks/tree/master/cvrp>
- MiniZinc model:
  <https://raw.githubusercontent.com/MiniZinc/minizinc-benchmarks/master/cvrp/cvrp.mzn>
- MiniZinc `B-n45-k5` data:
  <https://raw.githubusercontent.com/MiniZinc/minizinc-benchmarks/master/cvrp/B-n45-k5.vrp.dzn>
- MiniZinc metadata sidecar:
  <https://raw.githubusercontent.com/MiniZinc/minizinc-benchmarks/master/cvrp/B-n45-k5.vrp.metadata>
- CVRPLIB instance table (`B-n45-k5`: 44 customers, K=5, Q=100,
  UB=751, Opt=yes):
  <https://galgos.inf.puc-rio.br/cvrplib/en/instances/1>
- CVRPLIB original instance bytes:
  <https://galgos.inf.puc-rio.br/cvrplib/en/download/instance/39>
- CVRPLIB official route solution:
  <https://galgos.inf.puc-rio.br/cvrplib/en/download/bks/39>
- TSPLIB 95 format specification for `EUC_2D`:
  <https://comopt.ifi.uni-heidelberg.de/software/TSPLIB95/tsp95.pdf>
- Uchoa et al., *New benchmark instances for the Capacitated Vehicle Routing
  Problem*, documenting the exact-method convention of nearest-integer
  distances and a fixed number of routes:
  <https://doi.org/10.1016/j.ejor.2016.08.012>

`B-n45-k5.vrp` and `B-n45-k5.sol` are the downloaded CVRPLIB files.  The DZN,
metadata, and `cvrp.mzn` files are the downloaded MiniZinc benchmark sources;
they are retained so the identity and formulation checks do not depend on
future website contents.
