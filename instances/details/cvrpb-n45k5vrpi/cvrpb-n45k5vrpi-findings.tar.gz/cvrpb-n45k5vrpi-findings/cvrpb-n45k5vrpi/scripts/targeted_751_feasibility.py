"""Targeted auxiliary-completion run for the externally derived cost 751.

This is deliberately not a generic parameter sweep: the original CVRP route
construction provides the target.  Gurobi is used for at most 900 seconds to
complete the anonymized FlatZinc/MIP auxiliary encoding and return one feasible
point; it is not used to claim optimality.
"""
from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path
import re
import time

import gurobipy as gp
from gurobipy import GRB

from cvrpb_giant_lift import build_giant_tour, giant_distance, parse_dzn, parse_routes


def read_sparse_solution(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix.lower() == ".gz" else open
    values: dict[str, float] = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as source:
        for line in source:
            fields = line.split()
            if len(fields) == 2 and fields[0] != "=obj=":
                try:
                    values[fields[0]] = float(fields[1])
                except ValueError:
                    pass
    return values


def eliminated_source_value(offset: int, index: int, n: int) -> int | None:
    """Return values eliminated at export because cvrp.mzn fixes them."""
    if offset == 0 and 2 * n <= index < 3 * n:  # successor[end[k]]
        k = index - 2 * n + 1
        return n + (k % n) + 1
    if offset == 132 and n <= index < 2 * n:  # predecessor[start[k]]
        k = index - n + 1
        return 3 * n if k == 1 else 2 * n + k - 1
    if offset == 264 and n <= index < 3 * n:  # vehicle at depots
        node = index + 1
        return node - n if node <= 2 * n else node - 2 * n
    if offset in (396, 528) and n <= index < 2 * n:  # load/time at starts
        return 0
    return None


def source_arrays(model: gp.Model, sparse: dict[str, float], n: int) -> list[list[int]]:
    arrays: list[list[int]] = []
    for offset in (0, 132, 264, 396, 528):
        current = []
        for index in range(132):
            variable = model.getVarByName(f"X_INTRODUCED_{offset + index}_")
            if variable is None:
                value = eliminated_source_value(offset, index, n)
                if value is None:
                    raise RuntimeError(
                        f"unexplained missing source variable at suffix {offset + index}"
                    )
                current.append(value)
                continue
            value = sparse.get(variable.VarName)
            if value is None:
                if abs(variable.LB - variable.UB) <= 1e-12:
                    value = variable.LB
                else:
                    value = 0.0
            if abs(value - round(value)) > 1e-7:
                raise RuntimeError(f"nonintegral source value {variable.VarName}={value}")
            current.append(int(round(value)))
        arrays.append(current)
    return arrays


def audit_source_mapping(arrays: list[list[int]], data, expected_objective: int) -> dict:
    successor, predecessor, vehicle, load, arrival = ([0] + a for a in arrays)
    n = data.n
    nodes = 3 * n
    failures: list[str] = []
    if sorted(successor[1:]) != list(range(1, nodes + 1)):
        failures.append("successor is not a permutation")
    if sorted(predecessor[1:]) != list(range(1, nodes + 1)):
        failures.append("predecessor is not a permutation")
    for node in range(1, nodes + 1):
        if not 1 <= successor[node] <= nodes or not 1 <= predecessor[node] <= nodes:
            failures.append(f"node-domain failure at {node}")
            continue
        if predecessor[successor[node]] != node or successor[predecessor[node]] != node:
            failures.append(f"inverse failure at {node}")
    for k in range(1, n + 1):
        start, end = n + k, 2 * n + k
        if vehicle[start] != k or vehicle[end] != k:
            failures.append(f"vehicle depot identity failure at {k}")
        if arrival[start] != 0 or load[start] != 0:
            failures.append(f"start initialization failure at {k}")
    for customer in range(1, n + 1):
        if vehicle[successor[customer]] != vehicle[customer]:
            failures.append(f"successor vehicle failure at {customer}")
        if vehicle[predecessor[customer]] != vehicle[customer]:
            failures.append(f"predecessor vehicle failure at {customer}")
        if load[customer] + data.demand[customer - 1] != load[successor[customer]]:
            failures.append(f"load recurrence failure at {customer}")
        if arrival[customer] + giant_distance(data, customer, successor[customer]) > arrival[successor[customer]]:
            failures.append(f"time recurrence failure at {customer}")
    for k in range(1, n + 1):
        start = n + k
        if load[start] != load[successor[start]]:
            failures.append(f"start load transition failure at {k}")
        if arrival[start] + giant_distance(data, start, successor[start]) > arrival[successor[start]]:
            failures.append(f"start time transition failure at {k}")
    source_objective = sum(arrival[2 * n + k] for k in range(1, n + 1))
    if source_objective != expected_objective:
        failures.append(
            f"source objective {source_objective} != expected {expected_objective}"
        )
    return {
        "verified": not failures,
        "source_objective": source_objective,
        "failure_count": len(failures),
        "failures": failures[:100],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--incumbent", type=Path, required=True)
    parser.add_argument("--dzn", type=Path, required=True)
    parser.add_argument("--routes", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--time", type=float, default=900.0)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    model = gp.read(str(args.mps))
    model.read(str(args.incumbent))
    data = parse_dzn(args.dzn)
    routes = parse_routes(args.routes, data)
    giant = build_giant_tour(data, routes)
    if not routes.verified or giant.objective != 751:
        raise RuntimeError("canonical route/data audit did not establish cost 751")

    incumbent_sparse = read_sparse_solution(args.incumbent)
    incumbent_arrays = source_arrays(model, incumbent_sparse, data.n)
    mapping_audit = audit_source_mapping(incumbent_arrays, data, 775)
    if not mapping_audit["verified"]:
        raise RuntimeError(f"source-array mapping failed: {mapping_audit}")
    objective_vars = [v for v in model.getVars() if abs(v.Obj) > 1e-12]
    if len(objective_vars) != 1 or objective_vars[0].VarName != "objective":
        raise RuntimeError(
            f"fail closed: objective support is {[v.VarName for v in objective_vars]}"
        )
    objective = objective_vars[0]

    semantic_arrays = (
        giant.successor[1:],
        giant.predecessor[1:],
        giant.vehicle[1:],
        giant.load[1:],
        giant.arrival[1:],
    )
    fixed_source_variables = 0
    eliminated_fixed_source_values = 0
    for offset, values in zip((0, 132, 264, 396, 528), semantic_arrays):
        for index, value in enumerate(values):
            variable = model.getVarByName(f"X_INTRODUCED_{offset + index}_")
            if variable is None:
                expected = eliminated_source_value(offset, index, data.n)
                if expected is None or value != expected:
                    raise RuntimeError(
                        f"canonical value {value} conflicts with eliminated source "
                        f"suffix {offset + index} expected {expected}"
                    )
                eliminated_fixed_source_values += 1
                continue
            model.addConstr(
                variable == value,
                name=f"externally_derived_source_{offset + index}",
            )
            fixed_source_variables += 1
    model.addConstr(objective == 751, name="externally_derived_target_751")
    model.setObjective(0.0, GRB.MINIMIZE)
    model.Params.TimeLimit = args.time
    model.Params.Threads = 4
    model.Params.MIPFocus = 1
    model.Params.Heuristics = 0.5
    model.Params.SolutionLimit = 1
    model.Params.LogFile = str(args.out / "gurobi-target-751.log")
    started = time.monotonic()
    model.optimize()

    report = {
        "status": int(model.Status),
        "status_name": {
            GRB.OPTIMAL: "FEASIBLE_TARGET_FOUND",
            GRB.SOLUTION_LIMIT: "FEASIBLE_TARGET_FOUND_SOLUTION_LIMIT",
            GRB.INFEASIBLE: "TARGET_PROVED_INFEASIBLE_BY_SOLVER",
            GRB.TIME_LIMIT: "TIME_LIMIT",
        }.get(model.Status, f"GUROBI_STATUS_{model.Status}"),
        "elapsed_seconds": time.monotonic() - started,
        "solution_count": int(model.SolCount),
        "target": 751,
        "canonical_route_verified": routes.verified,
        "source_array_mapping_audit_on_incumbent_775": mapping_audit,
        "fixed_source_variables": fixed_source_variables,
        "eliminated_fixed_source_values": eliminated_fixed_source_values,
        "method_scope": (
            "The target and route came from the canonical CVRP source; Gurobi "
            "was used only to complete the anonymized auxiliary encoding."
        ),
        "optimality_claim": False,
    }
    if model.SolCount:
        report["objective_variable_value"] = float(objective.X)
        report["maximum_constraint_violation"] = float(model.ConstrVio)
        # The feasibility-completion model has a constant-zero optimization
        # objective. Write the original-model objective explicitly so an
        # independent re-reader does not inherit Gurobi's misleading
        # "Objective value = 0" comment from model.write().
        with (args.out / "target-751.sol").open("w", encoding="utf-8") as target:
            target.write("# Objective value = 751\n")
            for variable in model.getVars():
                target.write(f"{variable.VarName} {variable.X:.17g}\n")
    (args.out / "target-751-report.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(report))


if __name__ == "__main__":
    main()
