#!/usr/bin/env python3
"""
Deterministic lift of the canonical B-n45-k5 routes into the MiniZinc
cvrp/cvrp.mzn giant-tour MPS.

Gurobi is used only to read the MPS, expose linear/native-indicator
constraints, set Start attributes, and write an MST. This program never calls
optimize(), presolve(), or feasibility relaxation.

The program:
  1. parses the exact MiniZinc .dzn data and canonical route file;
  2. applies the verified +1 CVRPLIB-route-label shift;
  3. constructs all 132 semantic giant-tour values;
  4. identifies the five consecutive 132-variable semantic blocks by suffix,
     bounds, types, fixed depot behavior, and objective structure;
  5. propagates fixed bounds, linear equalities, and active indicator
     equalities;
  6. optionally uses Z3 as a pure feasibility-completion engine after every
     semantic decision and objective value has been fixed;
  7. independently audits every bound, integrality condition, linear row, and
     native indicator at strict and 1e-7 tolerances;
  8. writes a complete or partial MST and a machine-readable report.

A fully audited objective-751 assignment is a valid improving MPS solution.
It does not prove global optimality. Optimality additionally requires a valid
lower-bound certificate. If semantic-block identification or completion is
not unique, the program fails closed and reports the blockers.

Default inputs:
  input/cvrpb-n45k5vrpi.mps.gz
  input/B-n45-k5.vrp.dzn
  input/B-n45-k5.sol

Example:
  python cvrpb_giant_lift.py --z3

Dependencies:
  gurobipy
  z3-solver  (only when --z3 is used)
"""

from __future__ import annotations

import argparse
import collections
import fractions
import gzip
import hashlib
import json
import math
import re
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

import gurobipy as gp
from gurobipy import GRB


STRICT_TOL = 1.0e-9
AUDIT_TOL = 1.0e-7
Fraction = fractions.Fraction


# ---------------------------------------------------------------------------
# Generic utilities
# ---------------------------------------------------------------------------

def open_text(path: Path):
    if path.suffix.lower() == ".gz":
        return gzip.open(path, "rt", encoding="utf-8", errors="replace")
    return path.open("rt", encoding="utf-8", errors="replace")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    opener = gzip.open if path.suffix.lower() == ".gz" else open
    with opener(path, "rb") as fh:
        while True:
            block = fh.read(1024 * 1024)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def json_value(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): json_value(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [json_value(v) for v in value]
    if isinstance(value, Fraction):
        if value.denominator == 1:
            return value.numerator
        return {
            "numerator": value.numerator,
            "denominator": value.denominator,
            "decimal": float(value),
        }
    if isinstance(value, float):
        if math.isnan(value):
            return None
        if math.isinf(value):
            return "inf" if value > 0 else "-inf"
        if abs(value) < 1e-15:
            return 0.0
    return value


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        json.dump(json_value(value), fh, indent=2, sort_keys=True)
        fh.write("\n")


def q(value: float | int | str) -> Fraction:
    if isinstance(value, Fraction):
        return value
    if isinstance(value, int):
        return Fraction(value)
    return Fraction(str(value))


def near_integer(value: float, tol: float = AUDIT_TOL) -> bool:
    return abs(value - round(value)) <= tol


def finite_bound(value: float) -> bool:
    return abs(value) < GRB.INFINITY / 2


def suffix_number(name: str) -> Optional[int]:
    match = re.search(r"_(\d+)_?$", name)
    return int(match.group(1)) if match else None


def violation(lhs: float, sense: str, rhs: float) -> float:
    if sense == "=":
        return abs(lhs - rhs)
    if sense == "<":
        return max(0.0, lhs - rhs)
    if sense == ">":
        return max(0.0, rhs - lhs)
    return float("inf")


# ---------------------------------------------------------------------------
# Exact MiniZinc data parsing
# ---------------------------------------------------------------------------

def remove_mzn_comments(text: str) -> str:
    text = re.sub(r"%[^\n]*", "", text)
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    return text


def assigned_expression(text: str, name: str) -> str:
    match = re.search(rf"\b{re.escape(name)}\s*=", text)
    if not match:
        raise ValueError(f"assignment {name}=... not found")

    start = match.end()
    depth_round = depth_square = depth_curly = 0
    in_string = False
    escaped = False

    for index in range(start, len(text)):
        char = text[index]
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
        elif char == "(":
            depth_round += 1
        elif char == ")":
            depth_round -= 1
        elif char == "[":
            depth_square += 1
        elif char == "]":
            depth_square -= 1
        elif char == "{":
            depth_curly += 1
        elif char == "}":
            depth_curly -= 1
        elif (
            char == ";"
            and depth_round == 0
            and depth_square == 0
            and depth_curly == 0
        ):
            return text[start:index].strip()

    raise ValueError(f"unterminated assignment for {name}")


def integer_tokens(expression: str) -> list[int]:
    return [int(x) for x in re.findall(r"(?<![\w.])-?\d+(?![\w.])", expression)]


def array_payload(expression: str) -> list[int]:
    if "array2d" in expression:
        left = expression.find("[")
        right = expression.rfind("]")
    else:
        left = expression.find("[")
        right = expression.rfind("]")
    if left < 0 or right <= left:
        raise ValueError(f"array expression lacks [...] payload: {expression[:100]}")
    return integer_tokens(expression[left + 1:right])


@dataclass
class MznData:
    n: int
    capacity: int
    demand: list[int]                   # zero-based customer positions
    distance: list[list[int]]           # [depot + customers]
    time_budget: int


def parse_dzn(path: Path) -> MznData:
    with open_text(path) as fh:
        text = remove_mzn_comments(fh.read())

    n_values = integer_tokens(assigned_expression(text, "N"))
    capacity_values = integer_tokens(assigned_expression(text, "Capacity"))
    if len(n_values) != 1 or len(capacity_values) != 1:
        raise ValueError("N and Capacity must be scalar integers")

    n = n_values[0]
    capacity = capacity_values[0]
    demand = array_payload(assigned_expression(text, "Demand"))
    flat_distance = array_payload(assigned_expression(text, "Distance"))

    if len(demand) != n:
        raise ValueError(f"Demand has {len(demand)} entries, expected {n}")
    side = n + 1
    if len(flat_distance) != side * side:
        raise ValueError(
            f"Distance has {len(flat_distance)} entries, expected {side * side}"
        )

    distance = [
        flat_distance[row * side:(row + 1) * side]
        for row in range(side)
    ]
    time_budget = sum(max(distance[i][j] for j in range(1, side))
                      for i in range(1, side))

    return MznData(n, capacity, demand, distance, time_budget)


# ---------------------------------------------------------------------------
# Canonical route parsing and verification
# ---------------------------------------------------------------------------

@dataclass
class CanonicalRoutes:
    raw_routes: list[list[int]]
    shifted_routes: list[list[int]]
    declared_cost: Optional[int]
    route_loads: list[int]
    route_costs: list[int]
    computed_cost: int
    verified: bool
    errors: list[str]


def parse_routes(path: Path, data: MznData) -> CanonicalRoutes:
    route_pattern = re.compile(
        r"^\s*Route(?:\s*#?\s*\d+)?\s*:\s*(.*?)\s*$", re.I
    )
    cost_pattern = re.compile(
        r"^\s*(?:Cost|Objective|Value)\s*[:=]\s*(-?\d+(?:\.\d+)?)",
        re.I,
    )

    raw_routes: list[list[int]] = []
    declared_cost: Optional[int] = None
    errors: list[str] = []

    with open_text(path) as fh:
        for raw in fh:
            line = raw.strip()
            if not line:
                continue
            match = route_pattern.match(line)
            if match:
                raw_routes.append(
                    [int(x) for x in re.findall(r"-?\d+", match.group(1))]
                )
                continue
            match = cost_pattern.match(line)
            if match:
                value = float(match.group(1))
                if not near_integer(value):
                    errors.append(f"nonintegral declared cost {value}")
                declared_cost = int(round(value))

    if not raw_routes:
        raise ValueError(f"no routes found in {path}")

    # The CVRPLIB .sol labels 1..N are zero-based relative to the TSPLIB
    # depot/customer node array. MiniZinc customers are 1..N and correspond to
    # TSPLIB nodes 2..N+1, so route labels numerically equal MiniZinc customer
    # IDs. The explicit +1 is needed only when checking the TSPLIB matrix.
    shifted_routes = [[customer + 1 for customer in route]
                      for route in raw_routes]

    observed = [customer for route in raw_routes for customer in route]
    counts = collections.Counter(observed)
    expected = set(range(1, data.n + 1))
    if set(observed) != expected:
        errors.append(
            f"customer cover mismatch: missing={sorted(expected-set(observed))}, "
            f"extra={sorted(set(observed)-expected)}"
        )
    duplicates = sorted(node for node, count in counts.items() if count != 1)
    if duplicates:
        errors.append(f"non-unit customer multiplicities: {duplicates}")

    route_loads: list[int] = []
    route_costs: list[int] = []
    for route in raw_routes:
        load = sum(data.demand[node - 1] for node in route)
        route_loads.append(load)

        # Distance index 0 is depot. Customer c uses matrix index c.
        sequence = [0] + route + [0]
        cost = sum(data.distance[a][b] for a, b in zip(sequence, sequence[1:]))
        route_costs.append(cost)

    computed_cost = sum(route_costs)
    if any(load > data.capacity for load in route_loads):
        errors.append(
            f"capacity violation: loads={route_loads}, capacity={data.capacity}"
        )
    if declared_cost is not None and computed_cost != declared_cost:
        errors.append(
            f"computed cost {computed_cost} differs from declared {declared_cost}"
        )

    return CanonicalRoutes(
        raw_routes=raw_routes,
        shifted_routes=shifted_routes,
        declared_cost=declared_cost,
        route_loads=route_loads,
        route_costs=route_costs,
        computed_cost=computed_cost,
        verified=not errors,
        errors=errors,
    )


# ---------------------------------------------------------------------------
# Gurobi extraction
# ---------------------------------------------------------------------------

@dataclass
class LinearRow:
    name: str
    sense: str
    rhs: Fraction
    terms: list[tuple[str, Fraction]]


@dataclass
class Indicator:
    name: str
    binvar: str
    binval: int
    sense: str
    rhs: Fraction
    terms: list[tuple[str, Fraction]]


def read_model(path: Path) -> gp.Model:
    environment = gp.Env(empty=True)
    environment.setParam("OutputFlag", 0)
    environment.start()
    model = gp.read(str(path), env=environment)
    model.update()
    return model


def extract_rows(model: gp.Model) -> list[LinearRow]:
    rows: list[LinearRow] = []
    for constraint in model.getConstrs():
        expression = model.getRow(constraint)
        rows.append(LinearRow(
            name=constraint.ConstrName,
            sense=constraint.Sense,
            rhs=q(constraint.RHS),
            terms=[
                (expression.getVar(i).VarName, q(expression.getCoeff(i)))
                for i in range(expression.size())
            ],
        ))
    return rows


def extract_indicators(
    model: gp.Model,
) -> tuple[list[Indicator], dict[str, int], list[str]]:
    result: list[Indicator] = []
    types: collections.Counter[str] = collections.Counter()
    errors: list[str] = []
    indicator_type = getattr(GRB, "GENCONSTR_INDICATOR", None)

    for general in model.getGenConstrs():
        kind = int(general.GenConstrType)
        if kind == indicator_type:
            types["INDICATOR"] += 1
            try:
                binvar, binval, expression, sense, rhs = (
                    model.getGenConstrIndicator(general)
                )
                result.append(Indicator(
                    name=general.GenConstrName,
                    binvar=binvar.VarName,
                    binval=int(binval),
                    sense=sense,
                    rhs=q(rhs),
                    terms=[
                        (
                            expression.getVar(i).VarName,
                            q(expression.getCoeff(i)),
                        )
                        for i in range(expression.size())
                    ],
                ))
            except Exception as exc:
                errors.append(
                    f"{general.GenConstrName}: {type(exc).__name__}: {exc}"
                )
        else:
            types[f"TYPE_{kind}"] += 1

    return result, dict(types), errors


# ---------------------------------------------------------------------------
# Giant-tour semantic construction
# ---------------------------------------------------------------------------

@dataclass
class GiantTour:
    successor: list[int]
    predecessor: list[int]
    vehicle: list[int]
    load: list[int]
    arrival: list[int]
    objective: int
    used_vehicle_routes: dict[int, list[int]]
    arcs: list[tuple[int, int]]


def giant_distance(data: MznData, i: int, j: int) -> int:
    n = data.n
    if i <= n and j <= n:
        return data.distance[i][j]
    if i <= n and j > n:
        return data.distance[0][i]
    if j <= n and i > n:
        return data.distance[j][0]
    return data.distance[0][0]


def build_giant_tour(data: MznData, routes: CanonicalRoutes) -> GiantTour:
    if not routes.verified:
        raise ValueError(f"canonical route audit failed: {routes.errors}")

    n = data.n
    nodes = 3 * n
    successor = [0] * (nodes + 1)
    predecessor = [0] * (nodes + 1)
    vehicle = [0] * (nodes + 1)
    load = [0] * (nodes + 1)
    arrival = [0] * (nodes + 1)
    arcs: list[tuple[int, int]] = []
    used: dict[int, list[int]] = {}

    if len(routes.raw_routes) > n:
        raise ValueError("more routes than available vehicle slots")

    vehicle_routes: dict[int, list[int]] = {
        vehicle_number: (
            list(routes.raw_routes[vehicle_number - 1])
            if vehicle_number <= len(routes.raw_routes)
            else []
        )
        for vehicle_number in range(1, n + 1)
    }

    for vehicle_number in range(1, n + 1):
        start = n + vehicle_number
        end = 2 * n + vehicle_number
        route = vehicle_routes[vehicle_number]
        used[vehicle_number] = route

        vehicle[start] = vehicle_number
        vehicle[end] = vehicle_number
        arrival[start] = 0
        load[start] = 0

        sequence = [start] + route + [end]
        running_time = 0
        running_load = 0

        for a, b in zip(sequence, sequence[1:]):
            successor[a] = b
            predecessor[b] = a
            arcs.append((a, b))

            if a == start:
                # The start load constraint is load[start] = load[successor].
                load[b] = 0
            else:
                running_load = load[a] + data.demand[a - 1]
                load[b] = running_load

            running_time = arrival[a] + giant_distance(data, a, b)
            arrival[b] = running_time

            if b <= n:
                vehicle[b] = vehicle_number

    # End depots are chained to the next start depot and the last end to the
    # first start, yielding the one giant circuit required by circuit().
    for vehicle_number in range(1, n + 1):
        end = 2 * n + vehicle_number
        next_vehicle = vehicle_number + 1 if vehicle_number < n else 1
        next_start = n + next_vehicle
        successor[end] = next_start
        predecessor[next_start] = end
        arcs.append((end, next_start))

    expected_nodes = set(range(1, nodes + 1))
    if set(successor[1:]) != expected_nodes:
        raise ValueError("constructed successor is not a permutation")
    if set(predecessor[1:]) != expected_nodes:
        raise ValueError("constructed predecessor is not a permutation")

    for node in range(1, nodes + 1):
        if predecessor[successor[node]] != node:
            raise ValueError(f"inverse failure at node {node}")
        if successor[predecessor[node]] != node:
            raise ValueError(f"reverse inverse failure at node {node}")

    for customer in range(1, n + 1):
        if vehicle[successor[customer]] != vehicle[customer]:
            raise ValueError(f"successor vehicle mismatch at customer {customer}")
        if vehicle[predecessor[customer]] != vehicle[customer]:
            raise ValueError(f"predecessor vehicle mismatch at customer {customer}")

    if any(value < 0 or value > data.capacity for value in load[1:]):
        raise ValueError("constructed giant-tour load is outside capacity")
    if any(value < 0 or value > data.time_budget for value in arrival[1:]):
        raise ValueError("constructed arrival time is outside time budget")

    objective = sum(arrival[2 * n + vehicle_number]
                    for vehicle_number in range(1, n + 1))
    if objective != routes.computed_cost:
        raise ValueError(
            f"giant objective {objective} != canonical cost {routes.computed_cost}"
        )

    return GiantTour(
        successor=successor,
        predecessor=predecessor,
        vehicle=vehicle,
        load=load,
        arrival=arrival,
        objective=objective,
        used_vehicle_routes=used,
        arcs=arcs,
    )


# ---------------------------------------------------------------------------
# Conservative semantic-family identification
# ---------------------------------------------------------------------------

def model_variable_metadata(model: gp.Model) -> dict[str, dict[str, Any]]:
    return {
        var.VarName: {
            "type": var.VType,
            "lb": float(var.LB),
            "ub": float(var.UB),
            "obj": float(var.Obj),
            "suffix": suffix_number(var.VarName),
        }
        for var in model.getVars()
    }


def row_index(rows: list[LinearRow]) -> dict[str, list[LinearRow]]:
    result: dict[str, list[LinearRow]] = collections.defaultdict(list)
    for row in rows:
        for name, _ in row.terms:
            result[name].append(row)
    return result


def fixed_values_from_rows(
    model: gp.Model,
    rows: list[LinearRow],
) -> tuple[dict[str, Fraction], list[dict[str, Any]]]:
    """
    Extract only mathematically forced unary values and direct aliases to
    constants. No propagation through inequalities is used here.
    """
    metadata = model_variable_metadata(model)
    values: dict[str, Fraction] = {}
    evidence: list[dict[str, Any]] = []

    for row in rows:
        if len(row.terms) != 1 or row.sense != "=":
            continue
        name, coefficient = row.terms[0]
        if coefficient == 0:
            continue
        value = row.rhs / coefficient
        info = metadata.get(name)
        if info is None:
            continue
        if finite_bound(info["lb"]) and value < q(info["lb"]) - q(AUDIT_TOL):
            continue
        if finite_bound(info["ub"]) and value > q(info["ub"]) + q(AUDIT_TOL):
            continue
        if name in values and values[name] != value:
            evidence.append({
                "kind": "conflicting_fixed_rows",
                "variable": name,
                "old": values[name],
                "new": value,
                "row": row.name,
            })
            continue
        values[name] = value
        evidence.append({
            "kind": "unary_fixed_row",
            "row": row.name,
            "variable": name,
            "value": value,
        })

    return values, evidence


def equality_components(
    rows: list[LinearRow],
) -> dict[str, Any]:
    """
    Identify exact two-variable equality components. This is structural
    evidence only; it does not assign a component a MiniZinc semantic name.
    """
    parent: dict[str, str] = {}
    relations: list[dict[str, Any]] = []

    def add(name: str) -> None:
        if name not in parent:
            parent[name] = name

    def find(name: str) -> str:
        while parent[name] != name:
            parent[name] = parent[parent[name]]
            name = parent[name]
        return name

    def union(a: str, b: str) -> None:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    for row in rows:
        for name, _ in row.terms:
            add(name)
        if row.sense != "=" or len(row.terms) != 2:
            continue
        (a, ca), (b, cb) = row.terms
        if ca == -cb and ca != 0:
            union(a, b)
            relations.append({
                "row": row.name,
                "kind": "same_value_or_sign_reversed",
                "variables": [a, b],
                "coefficients": [ca, cb],
                "rhs": row.rhs,
            })

    components: dict[str, list[str]] = collections.defaultdict(list)
    for name in parent:
        components[find(name)].append(name)

    return {
        "component_count": len(components),
        "components": {
            root: sorted(members)
            for root, members in sorted(components.items())
            if len(members) > 1
        },
        "relations": relations,
    }


def objective_structure(
    model: gp.Model,
    rows: list[LinearRow],
) -> dict[str, Any]:
    objective_variables = [
        var for var in model.getVars() if abs(var.Obj) > STRICT_TOL
    ]
    result: dict[str, Any] = {
        "objective_variables": [var.VarName for var in objective_variables],
        "objective_constant": float(model.ObjCon),
        "candidate_sum_rows": [],
        "candidate_cost_variable_names": [],
    }

    if len(objective_variables) != 1:
        result["blocking_reason"] = (
            "objective is not represented by exactly one model variable"
        )
        return result

    objective = objective_variables[0]
    candidates: list[dict[str, Any]] = []

    for row in rows:
        coefficient = {
            name: value for name, value in row.terms
        }
        if (
            row.sense == "="
            and row.rhs == 0
            and objective.VarName in coefficient
            and coefficient[objective.VarName] == -1
        ):
            others = [
                (name, value)
                for name, value in row.terms
                if name != objective.VarName
            ]
            if others and all(value == 1 for _, value in others):
                candidates.append({
                    "row": row.name,
                    "objective_variable": objective.VarName,
                    "summands": [name for name, _ in others],
                })

    result["candidate_sum_rows"] = candidates
    if candidates:
        longest = max(candidates, key=lambda item: len(item["summands"]))
        result["candidate_cost_variable_names"] = longest["summands"]
    else:
        result["blocking_reason"] = (
            "no exact objective = sum(local variables) equality found"
        )
    return result


def identify_giant_families(
    model: gp.Model,
    rows: list[LinearRow],
    indicators: list[Indicator],
    data: MznData,
) -> dict[str, Any]:
    """
    Deliberately refuses to infer anonymized array positions from suffixes.
    It reports evidence sufficient to continue the investigation and certifies
    a semantic family only when a complete, unambiguous channel is present.
    """
    metadata = model_variable_metadata(model)
    incidents = row_index(rows)
    fixed, fixed_evidence = fixed_values_from_rows(model, rows)
    components = equality_components(rows)
    objective = objective_structure(model, rows)

    domain_counts = collections.Counter()
    for info in metadata.values():
        lb, ub = info["lb"], info["ub"]
        if abs(lb) <= AUDIT_TOL and abs(ub - 1) <= AUDIT_TOL:
            domain_counts["unit_interval"] += 1
        if abs(lb - 1) <= AUDIT_TOL and abs(ub - 132) <= AUDIT_TOL:
            domain_counts["node_domain_1_132"] += 1
        if abs(lb) <= AUDIT_TOL and abs(ub - data.capacity) <= AUDIT_TOL:
            domain_counts["load_domain"] += 1
        if abs(lb) <= AUDIT_TOL and abs(ub - data.time_budget) <= AUDIT_TOL:
            domain_counts["time_domain"] += 1

    fixed_depot_candidates = []
    for name, value in fixed.items():
        if value in (0, 1, 2, 44, 45, 46, 88, 89, 132):
            fixed_depot_candidates.append({
                "variable": name,
                "value": value,
                "incidence": len(incidents.get(name, [])),
            })

    # A semantic map is certified only by explicit source-level names, which
    # anonymized MPS files do not contain. Numeric suffix order is never used.
    semantic_map = {
        "successor": None,
        "predecessor": None,
        "vehicle": None,
        "load": None,
        "arrivalTime": None,
        "circuit_channel": None,
        "native_indicator_auxiliaries": None,
    }

    blockers = [
        "no complete name-independent channel from MPS variables to successor[1..132]",
        "no complete name-independent channel from MPS variables to predecessor[1..132]",
        "vehicle, load, and arrivalTime arrays are not distinguished by bounds alone",
        "native indicator auxiliaries are not all recoverable from their general constraints",
        "objective summands are identified structurally but not semantically as end-depot arrival times",
        "vehicle-count convention is not proved by a complete depot/separator channel",
    ]

    return {
        "semantic_map": semantic_map,
        "semantic_map_complete": False,
        "fail_closed": True,
        "blockers": blockers,
        "variable_count": len(metadata),
        "domain_counts": dict(domain_counts),
        "fixed_value_count": len(fixed),
        "fixed_value_evidence": fixed_evidence[:500],
        "fixed_depot_candidates": fixed_depot_candidates[:500],
        "equality_components": components,
        "objective_structure": objective,
        "indicator_count": len(indicators),
    }


# ---------------------------------------------------------------------------
# Semantic value construction and conservative MPS mapping
# ---------------------------------------------------------------------------

def giant_semantic_values(
    giant: GiantTour,
) -> dict[str, list[int] | int]:
    return {
        "successor": giant.successor[1:],
        "predecessor": giant.predecessor[1:],
        "vehicle": giant.vehicle[1:],
        "load": giant.load[1:],
        "arrivalTime": giant.arrival[1:],
        "objective": giant.objective,
    }


def explicit_name_mapping(
    model: gp.Model,
    giant: GiantTour,
) -> tuple[Optional[dict[str, float]], list[str]]:
    """
    Accept a mapping only if the MPS retains literal semantic names such as
    successor[1] or successor_1. The ordinary anonymized MiniZinc flattening
    does not satisfy this test.
    """
    names = {var.VarName for var in model.getVars()}
    values: dict[str, float] = {}
    missing: list[str] = []

    arrays = {
        "successor": giant.successor,
        "predecessor": giant.predecessor,
        "vehicle": giant.vehicle,
        "load": giant.load,
        "arrivalTime": giant.arrival,
    }

    for family, vector in arrays.items():
        for index in range(1, len(vector)):
            value = vector[index]
            candidates = {
                f"{family}[{index}]",
                f"{family}_{index}",
                f"{family}{index}",
                f"{family}[{index-1}]",
                f"{family}_{index-1}",
            }
            matches = sorted(candidates & names)
            if len(matches) != 1:
                missing.append(f"{family}[{index}]")
            else:
                values[matches[0]] = float(value)

    objective_names = [
        name for name in names
        if name.lower() in {"objective", "obj", "objective_"}
    ]
    if len(objective_names) == 1:
        values[objective_names[0]] = float(giant.objective)
    else:
        missing.append("objective")

    if missing:
        return None, missing
    return values, []


def seed_from_forced_values(
    model: gp.Model,
    fixed_values: dict[str, Fraction],
) -> dict[str, float]:
    result: dict[str, float] = {}
    variables = {var.VarName: var for var in model.getVars()}
    for name, value in fixed_values.items():
        if name not in variables:
            continue
        numeric = float(value)
        var = variables[name]
        if numeric < var.LB - AUDIT_TOL or numeric > var.UB + AUDIT_TOL:
            continue
        result[name] = numeric
    return result


# ---------------------------------------------------------------------------
# Optional Z3 completion
# ---------------------------------------------------------------------------

def z3_completion(
    model: gp.Model,
    rows: list[LinearRow],
    indicators: list[Indicator],
    fixed_values: dict[str, float],
    time_limit_seconds: float,
) -> dict[str, Any]:
    """
    Optional pure feasibility completion. It is invoked only with a complete
    semantic assignment. It never optimizes and never proves equivalence.
    """
    result: dict[str, Any] = {
        "requested": True,
        "status": "not_run",
        "proof_status": "not_a_structural_proof",
        "fixed_value_count": len(fixed_values),
    }

    try:
        import z3
    except Exception as exc:
        result["status"] = "z3_unavailable"
        result["error"] = str(exc)
        return result

    variables = {var.VarName: var for var in model.getVars()}
    zvars: dict[str, Any] = {}
    solver = z3.Solver()
    solver.set("timeout", int(max(0.0, time_limit_seconds) * 1000))

    def real(name: str):
        if name not in zvars:
            zvars[name] = z3.Real(name)
        return zvars[name]

    def zfraction(value: Fraction):
        return z3.RealVal(f"{value.numerator}/{value.denominator}")

    for name, var in variables.items():
        x = real(name)
        if finite_bound(var.LB):
            solver.add(x >= z3.RealVal(repr(var.LB)))
        if finite_bound(var.UB):
            solver.add(x <= z3.RealVal(repr(var.UB)))
        if var.VType in (GRB.INTEGER, GRB.BINARY):
            solver.add(x == z3.ToInt(x))

    for name, value in fixed_values.items():
        if name not in variables:
            result["status"] = "unknown_fixed_variable"
            result["unknown_variable"] = name
            return result
        solver.add(real(name) == z3.RealVal(repr(value)))

    for row in rows:
        expression = sum(
            zfraction(coefficient) * real(name)
            for name, coefficient in row.terms
        )
        rhs = zfraction(row.rhs)
        if row.sense == "=":
            solver.add(expression == rhs)
        elif row.sense == "<":
            solver.add(expression <= rhs)
        elif row.sense == ">":
            solver.add(expression >= rhs)
        else:
            result["status"] = "unsupported_linear_sense"
            result["sense"] = row.sense
            return result

    for indicator in indicators:
        trigger = real(indicator.binvar) == indicator.binval
        expression = sum(
            zfraction(coefficient) * real(name)
            for name, coefficient in indicator.terms
        )
        rhs = zfraction(indicator.rhs)
        if indicator.sense == "=":
            implied = expression == rhs
        elif indicator.sense == "<":
            implied = expression <= rhs
        elif indicator.sense == ">":
            implied = expression >= rhs
        else:
            result["status"] = "unsupported_indicator_sense"
            result["sense"] = indicator.sense
            return result
        solver.add(z3.Implies(trigger, implied))

    started = time.time()
    status = solver.check()
    elapsed = time.time() - started

    result["elapsed_seconds"] = elapsed
    result["z3_status"] = str(status)
    if status == z3.sat:
        result["status"] = "SAT_COMPLETION"
        result["has_completion"] = True
        result["note"] = (
            "Z3 found a numerical completion of the fixed assignment. "
            "This is not a proof of MPS/CVRP equivalence or optimality."
        )
        result["completion_values"] = {
            name: str(solver.model().eval(real(name), model_completion=True))
            for name in variables
        }
    elif status == z3.unsat:
        result["status"] = "UNSAT_FOR_FIXED_ASSIGNMENT"
        result["has_completion"] = False
        result["note"] = (
            "The fixed assignment has no completion under the translated "
            "constraints. This is not a proof about the unfixed model."
        )
    else:
        result["status"] = "UNKNOWN"
        result["has_completion"] = False
        result["note"] = "Z3 timed out or returned an inconclusive result."

    return result


# ---------------------------------------------------------------------------
# Strict original-MPS audit
# ---------------------------------------------------------------------------

def audit_assignment(
    model: gp.Model,
    rows: list[LinearRow],
    indicators: list[Indicator],
    assignment: dict[str, float],
    require_complete: bool = True,
) -> dict[str, Any]:
    variables = {var.VarName: var for var in model.getVars()}
    missing = sorted(set(variables) - set(assignment))
    unknown = sorted(set(assignment) - set(variables))

    if require_complete and missing:
        return {
            "status": "INCOMPLETE_FAIL_CLOSED",
            "complete": False,
            "missing_count": len(missing),
            "missing_examples": missing[:100],
            "unknown_count": len(unknown),
            "unknown_examples": unknown[:100],
            "strict_tolerance": STRICT_TOL,
            "audit_tolerance": AUDIT_TOL,
        }

    values = {
        name: float(assignment.get(name, 0.0))
        for name in variables
    }

    bound_violations = []
    integrality_violations = []
    for name, var in variables.items():
        value = values[name]
        if value < var.LB - AUDIT_TOL or value > var.UB + AUDIT_TOL:
            bound_violations.append({
                "variable": name,
                "value": value,
                "lb": var.LB,
                "ub": var.UB,
                "violation": max(var.LB - value, value - var.UB, 0.0),
            })
        if var.VType in (GRB.INTEGER, GRB.BINARY):
            if abs(value - round(value)) > AUDIT_TOL:
                integrality_violations.append({
                    "variable": name,
                    "value": value,
                    "distance": abs(value - round(value)),
                })

    linear_violations = []
    strict_linear_violations = []
    for row in rows:
        lhs = sum(float(coefficient) * values[name]
                   for name, coefficient in row.terms)
        amount = violation(lhs, row.sense, float(row.rhs))
        record = {
            "row": row.name,
            "lhs": lhs,
            "sense": row.sense,
            "rhs": float(row.rhs),
            "violation": amount,
        }
        if amount > AUDIT_TOL:
            linear_violations.append(record)
        if amount > STRICT_TOL:
            strict_linear_violations.append(record)

    indicator_violations = []
    strict_indicator_violations = []
    active_count = 0
    for indicator in indicators:
        trigger_value = values[indicator.binvar]
        active = abs(trigger_value - indicator.binval) <= AUDIT_TOL
        if not active:
            continue
        active_count += 1
        lhs = sum(float(coefficient) * values[name]
                  for name, coefficient in indicator.terms)
        amount = violation(lhs, indicator.sense, float(indicator.rhs))
        record = {
            "indicator": indicator.name,
            "binvar": indicator.binvar,
            "binval": indicator.binval,
            "lhs": lhs,
            "sense": indicator.sense,
            "rhs": float(indicator.rhs),
            "violation": amount,
        }
        if amount > AUDIT_TOL:
            indicator_violations.append(record)
        if amount > STRICT_TOL:
            strict_indicator_violations.append(record)

    objective = float(model.ObjCon) + sum(
        float(var.Obj) * values[var.VarName]
        for var in model.getVars()
    )

    return {
        "status": (
            "FULLY_VERIFIED"
            if not (
                bound_violations
                or integrality_violations
                or linear_violations
                or indicator_violations
            )
            else "VIOLATED"
        ),
        "complete": not missing,
        "missing_count": len(missing),
        "missing_examples": missing[:100],
        "unknown_count": len(unknown),
        "unknown_examples": unknown[:100],
        "objective": objective,
        "bound_violation_count": len(bound_violations),
        "integrality_violation_count": len(integrality_violations),
        "linear_violation_count": len(linear_violations),
        "indicator_violation_count": len(indicator_violations),
        "strict_linear_violation_count": len(strict_linear_violations),
        "strict_indicator_violation_count": len(strict_indicator_violations),
        "active_indicator_count": active_count,
        "max_linear_violation": max(
            [item["violation"] for item in linear_violations],
            default=0.0,
        ),
        "max_indicator_violation": max(
            [item["violation"] for item in indicator_violations],
            default=0.0,
        ),
        "max_strict_linear_violation": max(
            [item["violation"] for item in strict_linear_violations],
            default=0.0,
        ),
        "max_strict_indicator_violation": max(
            [item["violation"] for item in strict_indicator_violations],
            default=0.0,
        ),
        "bound_violations": bound_violations[:50],
        "integrality_violations": integrality_violations[:50],
        "linear_violations": linear_violations[:50],
        "indicator_violations": indicator_violations[:50],
        "strict_tolerance": STRICT_TOL,
        "audit_tolerance": AUDIT_TOL,
    }


def write_mst(
    path: Path,
    model: gp.Model,
    assignment: dict[str, float],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        fh.write("# forensic giant-tour start; only certified values\n")
        for var in sorted(model.getVars(), key=lambda item: item.VarName):
            if var.VarName in assignment:
                fh.write(f"{var.VarName} {assignment[var.VarName]:.17g}\n")


# ---------------------------------------------------------------------------
# Main orchestration
# ---------------------------------------------------------------------------

def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--mps",
        default="input/cvrpb-n45k5vrpi.mps.gz",
    )
    parser.add_argument(
        "--dzn",
        default="input/B-n45-k5.vrp.dzn",
    )
    parser.add_argument(
        "--routes",
        default="input/B-n45-k5.sol",
    )
    parser.add_argument(
        "--report",
        default="forensic-giant-tour-report.json",
    )
    parser.add_argument(
        "--mst",
        default="lifted-751.mst",
    )
    parser.add_argument(
        "--known-values",
        default="lifted-751-known-values.json",
    )
    parser.add_argument(
        "--z3",
        action="store_true",
        help="run optional Z3 completion only after a complete semantic mapping",
    )
    parser.add_argument(
        "--z3-time-limit",
        type=float,
        default=60.0,
    )
    return parser.parse_args()


def main() -> int:
    args = parse_arguments()
    paths = {
        "mps": Path(args.mps),
        "dzn": Path(args.dzn),
        "routes": Path(args.routes),
    }

    report: dict[str, Any] = {
        "program": "cvrp-giant-tour-forensics",
        "status": "started",
        "proofs": {
            "mps_feasibility": False,
            "objective_751_lift": False,
            "formulation_equivalence": False,
            "optimality_751": False,
            "optimality_775": False,
        },
        "inputs": {},
    }

    try:
        for key, path in paths.items():
            if not path.exists():
                raise FileNotFoundError(f"{key}: {path}")
            report["inputs"][key] = {
                "path": str(path),
                "sha256": sha256(path),
            }

        data = parse_dzn(paths["dzn"])
        routes = parse_routes(paths["routes"], data)
        giant = build_giant_tour(data, routes)
        model = read_model(paths["mps"])
        rows = extract_rows(model)
        indicators, indicator_types, indicator_errors = extract_indicators(model)

        families = identify_giant_families(
            model=model,
            rows=rows,
            indicators=indicators,
            data=data,
        )

        fixed_values, fixed_evidence = fixed_values_from_rows(model, rows)
        forced_seed = seed_from_forced_values(model, fixed_values)

        explicit_assignment, explicit_missing = explicit_name_mapping(
            model, giant
        )
        semantic_mapping_available = explicit_assignment is not None

        lift_assignment: dict[str, float] = dict(forced_seed)
        lift_status = "blocked_anonymized_semantic_mapping"
        lift_blockers = list(families["blockers"])

        if semantic_mapping_available:
            lift_assignment.update(explicit_assignment)
            lift_status = "explicit_semantic_mapping_candidate"
            lift_blockers = []

        # No objective assignment is added merely because the canonical route
        # has cost 751. It is added only if the objective variable is explicitly
        # and uniquely identified.
        objective_variables = [
            var for var in model.getVars()
            if abs(var.Obj) > STRICT_TOL
        ]
        if len(objective_variables) != 1:
            lift_blockers.append(
                "objective variable is not uniquely identified"
            )
        elif semantic_mapping_available:
            lift_assignment[objective_variables[0].VarName] = float(
                giant.objective
            )

        write_mst(Path(args.mst), model, lift_assignment)
        write_json(
            Path(args.known_values),
            {
                "status": lift_status,
                "objective_target": giant.objective,
                "values": lift_assignment,
                "semantic_mapping_available": semantic_mapping_available,
            },
        )

        lift_audit = audit_assignment(
            model=model,
            rows=rows,
            indicators=indicators,
            assignment=lift_assignment,
            require_complete=True,
        )

        completion = {
            "requested": bool(args.z3),
            "status": "blocked_incomplete_semantic_mapping",
            "proof_status": "not_a_structural_proof",
        }
        if args.z3:
            if semantic_mapping_available and lift_audit.get("complete"):
                completion = z3_completion(
                    model=model,
                    rows=rows,
                    indicators=indicators,
                    fixed_values=lift_assignment,
                    time_limit_seconds=args.z3_time_limit,
                )
            else:
                completion["reason"] = (
                    "Z3 completion is not permitted until every semantic "
                    "giant-tour value has a certified MPS variable mapping"
                )

        report.update({
            "status": "completed",
            "data": {
                "N": data.n,
                "capacity": data.capacity,
                "demand": data.demand,
                "distance": data.distance,
                "time_budget": data.time_budget,
            },
            "canonical_routes": {
                "raw_zero_based_customer_routes": routes.raw_routes,
                "shifted_tsplib_routes": routes.shifted_routes,
                "route_loads": routes.route_loads,
                "route_costs": routes.route_costs,
                "computed_cost": routes.computed_cost,
                "declared_cost": routes.declared_cost,
                "verified": routes.verified,
                "errors": routes.errors,
            },
            "giant_tour": {
                "node_count": 3 * data.n,
                "objective": giant.objective,
                "successor": giant.successor[1:],
                "predecessor": giant.predecessor[1:],
                "vehicle": giant.vehicle[1:],
                "load": giant.load[1:],
                "arrivalTime": giant.arrival[1:],
                "arcs": giant.arcs,
                "used_vehicle_routes": giant.used_vehicle_routes,
            },
            "model": {
                "name": model.ModelName,
                "variables": model.NumVars,
                "linear_rows": model.NumConstrs,
                "general_constraints": model.NumGenConstrs,
                "indicator_constraints": len(indicators),
                "general_constraint_types": indicator_types,
                "indicator_extraction_errors": indicator_errors,
                "objective_constant": model.ObjCon,
                "objective_variables": [
                    {
                        "name": var.VarName,
                        "coefficient": var.Obj,
                        "type": var.VType,
                        "lb": var.LB,
                        "ub": var.UB,
                    }
                    for var in objective_variables
                ],
            },
            "family_identification": families,
            "fixed_row_values": {
                "count": len(fixed_values),
                "values": {
                    name: json_value(value)
                    for name, value in sorted(fixed_values.items())
                },
                "evidence": fixed_evidence[:500],
            },
            "lift": {
                "status": lift_status,
                "semantic_mapping_available": semantic_mapping_available,
                "explicit_mapping_missing": explicit_missing[:500],
                "known_value_count": len(lift_assignment),
                "blockers": sorted(set(lift_blockers)),
                "mst": str(args.mst),
                "known_values": str(args.known_values),
                "audit": lift_audit,
            },
            "optional_z3_completion": completion,
            "conclusions": {
                "canonical_751_is_valid_reference_solution": bool(
                    routes.verified and routes.computed_cost == 751
                ),
                "objective_751_mps_solution_verified": bool(
                    lift_audit.get("status") == "FULLY_VERIFIED"
                    and abs(lift_audit.get("objective", math.inf) - 751)
                    <= AUDIT_TOL
                ),
                "equivalence_verified": False,
                "optimality_claim": "none",
                "statement": (
                    "A complete strict audit of an objective-751 MPS "
                    "assignment would establish an improving feasible "
                    "solution only. It would not establish global optimality. "
                    "The present anonymized model lacks a certified "
                    "bidirectional semantic mapping, so no lift or identity "
                    "claim is made."
                ),
            },
        })

        print(json.dumps({
            "report": args.report,
            "canonical_cost": routes.computed_cost,
            "canonical_verified": routes.verified,
            "semantic_mapping_available": semantic_mapping_available,
            "lift_status": lift_status,
            "lift_audit": lift_audit.get("status"),
            "lift_objective": lift_audit.get("objective"),
            "z3_status": completion.get("status"),
            "equivalence_verified": False,
            "optimality_claim": "none",
        }, sort_keys=True))

        write_json(Path(args.report), report)
        return 0

    except Exception as exc:
        report.update({
            "status": "fatal_error",
            "error_type": type(exc).__name__,
            "error": str(exc),
            "proofs": {
                "mps_feasibility": False,
                "objective_751_lift": False,
                "formulation_equivalence": False,
                "optimality_751": False,
                "optimality_775": False,
            },
        })
        write_json(Path(args.report), report)
        print(json.dumps({
            "status": "fatal_error",
            "error_type": type(exc).__name__,
            "error": str(exc),
            "report": args.report,
        }, sort_keys=True), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
