#!/usr/bin/env python3
"""Exact branch-and-cut reproduction for the semantic B-n45-k5 CVRP.

The formulation has one undirected edge variable for every node pair, degree
two at every customer, and a free depot degree (apart from the demand-derived
minimum).  Lazy cuts reject disconnected customer cycles and any depot route
whose demand exceeds capacity.  Fractional rounded-capacity cuts are also
separated as user cuts with exact cut sets and integer right-hand sides.

This 990-variable model fits the euler4 restricted Gurobi license.  It does not
fix the number of routes to five, so its optimum is valid for the MiniZinc
model, which permits any number from 5 through 44.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import time
from collections import deque
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


N_CUSTOMERS = 44
DEPOT = 0


def parse_dzn(path: Path):
    text = path.read_text(encoding="utf-8")
    n = int(re.search(r"\bN\s*=\s*(\d+)\s*;", text).group(1))
    demand_text = re.search(r"Demand\s*=\s*\[(.*?)\]\s*;", text, re.S).group(1)
    demands = [0] + [int(x) for x in re.findall(r"-?\d+", demand_text)]
    distance_text = re.search(r"Distance\s*=\s*\[\|(.*?)\|\]\s*;", text, re.S).group(1)
    distance = []
    for raw in distance_text.split("|"):
        values = [int(x) for x in re.findall(r"-?\d+", raw)]
        if values:
            distance.append(values)
    if n != N_CUSTOMERS or len(demands) != n + 1 or len(distance) != n + 1:
        raise ValueError("unexpected DZN dimensions")
    if any(len(row) != n + 1 for row in distance):
        raise ValueError("non-square distance matrix")
    if any(distance[i][j] != distance[j][i] for i in range(n + 1) for j in range(n + 1)):
        raise ValueError("distance matrix is not symmetric")
    return demands, distance


def parse_routes(path: Path):
    routes = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.startswith("Route #"):
            routes.append([int(x) for x in line.split(":", 1)[1].split()])
    return routes


def sha256(path: Path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class Dinic:
    def __init__(self, n: int):
        self.n = n
        self.graph = [[] for _ in range(n)]

    def add_directed(self, u: int, v: int, cap: float):
        a = [v, cap, None]
        b = [u, 0.0, a]
        a[2] = b
        self.graph[u].append(a)
        self.graph[v].append(b)

    def add_undirected_capacity(self, u: int, v: int, cap: float):
        # A symmetric edge contributes cap in either direction across a cut.
        self.add_directed(u, v, cap)
        self.add_directed(v, u, cap)

    def maxflow_cut(self, source: int, sink: int):
        total = 0.0
        eps = 1e-10
        while True:
            level = [-1] * self.n
            level[source] = 0
            q = deque([source])
            while q:
                u = q.popleft()
                for e in self.graph[u]:
                    if e[1] > eps and level[e[0]] < 0:
                        level[e[0]] = level[u] + 1
                        q.append(e[0])
            if level[sink] < 0:
                break
            ptr = [0] * self.n

            def dfs(u: int, flow: float):
                if u == sink:
                    return flow
                while ptr[u] < len(self.graph[u]):
                    e = self.graph[u][ptr[u]]
                    if e[1] > eps and level[e[0]] == level[u] + 1:
                        sent = dfs(e[0], min(flow, e[1]))
                        if sent > eps:
                            e[1] -= sent
                            e[2][1] += sent
                            return sent
                    ptr[u] += 1
                return 0.0

            while True:
                sent = dfs(source, float("inf"))
                if sent <= eps:
                    break
                total += sent
        reachable = set([source])
        q = deque([source])
        while q:
            u = q.popleft()
            for e in self.graph[u]:
                if e[1] > eps and e[0] not in reachable:
                    reachable.add(e[0])
                    q.append(e[0])
        return total, reachable


def components_from_integer(edge_values, customers):
    adjacency = {i: [] for i in customers}
    depot_degree = {i: 0 for i in customers}
    for (i, j), value in edge_values.items():
        multiplicity = int(round(value))
        if not multiplicity:
            continue
        if i == DEPOT:
            depot_degree[j] += multiplicity
        elif j == DEPOT:
            depot_degree[i] += multiplicity
        else:
            adjacency[i].extend([j] * multiplicity)
            adjacency[j].extend([i] * multiplicity)
    unseen = set(customers)
    result = []
    while unseen:
        seed = min(unseen)
        comp = set([seed])
        q = [seed]
        unseen.remove(seed)
        while q:
            u = q.pop()
            for v in adjacency[u]:
                if v in unseen:
                    unseen.remove(v)
                    comp.add(v)
                    q.append(v)
        result.append((comp, sum(depot_degree[i] for i in comp)))
    return result


def boundary_expr(model, subset):
    return gp.quicksum(
        var for (i, j), var in model._edge_vars.items() if (i in subset) != (j in subset)
    )


def callback(model, where):
    if where == GRB.Callback.MIPSOL:
        model._integer_solutions_checked += 1
        vals = {edge: model.cbGetSolution(var) for edge, var in model._edge_vars.items()}
        violations = 0
        for subset, depot_edges in components_from_integer(vals, model._customers):
            demand = sum(model._demands[i] for i in subset)
            required = 2 * math.ceil(demand / model._capacity)
            if depot_edges + 1e-6 < required:
                assert subset and DEPOT not in subset
                assert required >= 2 and required % 2 == 0
                model.cbLazy(boundary_expr(model, subset) >= required)
                model._lazy_cuts += 1
                model._lazy_sets.add(tuple(sorted(subset)))
                model._maximum_lazy_rhs = max(model._maximum_lazy_rhs, required)
                violations += 1
        if violations:
            model._invalid_integer_solutions_cut += 1
        else:
            model._valid_integer_solutions_seen += 1

    elif where == GRB.Callback.MIPNODE:
        if model.cbGet(GRB.Callback.MIPNODE_STATUS) != GRB.OPTIMAL:
            return
        # Separating on every callback is wasteful.  The cut pool persists, so
        # process at most the first 400 optimal node relaxations.
        if model._node_separation_calls >= 400:
            return
        model._node_separation_calls += 1
        vals = {edge: max(0.0, model.cbGetNodeRel(var)) for edge, var in model._edge_vars.items()}
        candidates = {}
        node_count = N_CUSTOMERS + 1
        for sink in model._customers:
            flow = Dinic(node_count)
            for (i, j), value in vals.items():
                if value > 1e-9:
                    flow.add_undirected_capacity(i, j, value)
            _, depot_side = flow.maxflow_cut(DEPOT, sink)
            subset = frozenset(set(range(node_count)) - depot_side)
            if not subset or DEPOT in subset:
                continue
            demand = sum(model._demands[i] for i in subset)
            required = 2 * math.ceil(demand / model._capacity)
            boundary = sum(value for (i, j), value in vals.items() if (i in subset) != (j in subset))
            if boundary < required - 1e-6:
                candidates[subset] = (boundary, required)
        for subset, (_, required) in sorted(candidates.items(), key=lambda kv: kv[1][0])[:20]:
            key = tuple(sorted(subset))
            if key not in model._user_sets:
                model.cbCut(boundary_expr(model, subset) >= required)
                model._user_sets.add(key)
                model._user_cuts += 1


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("dzn", type=Path)
    ap.add_argument("routes", type=Path)
    ap.add_argument("out", type=Path)
    ap.add_argument("--seconds", type=float, default=1200)
    ap.add_argument("--threads", type=int, default=32)
    ap.add_argument("--minimum-routes", type=int)
    ap.add_argument("--maximum-objective", type=int)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    demands, distance = parse_dzn(args.dzn)
    known_routes = parse_routes(args.routes)

    model = gp.Model("B-n45-k5-free-fleet")
    nodes = range(N_CUSTOMERS + 1)
    customers = range(1, N_CUSTOMERS + 1)
    edge_vars = {}
    for i in nodes:
        for j in range(i + 1, N_CUSTOMERS + 1):
            ub = 2 if i == DEPOT else 1
            vtype = GRB.INTEGER if i == DEPOT else GRB.BINARY
            edge_vars[i, j] = model.addVar(lb=0, ub=ub, vtype=vtype, obj=distance[i][j], name=f"e_{i}_{j}")
    model.update()
    for i in customers:
        model.addConstr(
            gp.quicksum(var for (u, v), var in edge_vars.items() if u == i or v == i) == 2,
            name=f"degree_{i}",
        )
    demand_min_routes = math.ceil(sum(demands) / 100)
    min_routes = args.minimum_routes or demand_min_routes
    if min_routes < demand_min_routes:
        raise ValueError("minimum-routes cannot weaken the demand lower bound")
    model.addConstr(gp.quicksum(edge_vars[0, j] for j in customers) >= 2 * min_routes, name="min_route_count")
    if args.maximum_objective is not None:
        model.addConstr(
            gp.quicksum(distance[i][j] * var for (i, j), var in edge_vars.items())
            <= args.maximum_objective,
            name="objective_ceiling",
        )

    route_edges = {}
    for route in known_routes:
        chain = [0, *route, 0]
        for a, b in zip(chain, chain[1:]):
            edge = tuple(sorted((a, b)))
            route_edges[edge] = route_edges.get(edge, 0) + 1
    if min_routes <= len(known_routes) and (args.maximum_objective is None or args.maximum_objective >= 751):
        for edge, var in edge_vars.items():
            var.Start = route_edges.get(edge, 0)

    model._edge_vars = edge_vars
    model._customers = list(customers)
    model._demands = demands
    model._capacity = 100
    model._lazy_cuts = 0
    model._user_cuts = 0
    model._lazy_sets = set()
    model._user_sets = set()
    model._node_separation_calls = 0
    model._integer_solutions_checked = 0
    model._invalid_integer_solutions_cut = 0
    model._valid_integer_solutions_seen = 0
    model._maximum_lazy_rhs = 0
    model.Params.Threads = args.threads
    model.Params.TimeLimit = args.seconds
    model.Params.MIPGap = 0
    model.Params.LazyConstraints = 1
    model.Params.PreCrush = 1
    model.Params.MIPFocus = 3
    model.Params.LogFile = str(args.out / "gurobi-standard-cvrp.log")
    started = time.time()
    model.optimize(callback)
    elapsed = time.time() - started

    result = {
        "gurobi_version": list(gp.gurobi.version()),
        "status": int(model.Status),
        "status_name": {
            GRB.OPTIMAL: "OPTIMAL",
            GRB.TIME_LIMIT: "TIME_LIMIT",
            GRB.INFEASIBLE: "INFEASIBLE",
            GRB.CUTOFF: "CUTOFF",
        }.get(model.Status, str(model.Status)),
        "variables": model.NumVars,
        "initial_constraints": model.NumConstrs,
        "customers": N_CUSTOMERS,
        "total_demand": sum(demands),
        "capacity": 100,
        "minimum_routes_by_total_demand": demand_min_routes,
        "minimum_routes_enforced": min_routes,
        "maximum_objective_enforced": args.maximum_objective,
        "route_count_not_fixed": True,
        "lazy_cuts_added": model._lazy_cuts,
        "distinct_lazy_sets": len(model._lazy_sets),
        "fractional_user_cuts_added": model._user_cuts,
        "node_separation_calls": model._node_separation_calls,
        "integer_solutions_checked_by_callback": model._integer_solutions_checked,
        "invalid_integer_solutions_cut": model._invalid_integer_solutions_cut,
        "valid_integer_solutions_seen": model._valid_integer_solutions_seen,
        "maximum_lazy_cut_rhs": model._maximum_lazy_rhs,
        "lazy_cut_formula": "x(delta(S)) >= 2*ceil(sum(demand[i] for i in S)/capacity)",
        "lazy_cut_scope": "Every customer component S of every integer callback solution; S excludes the depot.",
        "nodes_explored": float(model.NodeCount),
        "runtime_reported": float(model.Runtime),
        "runtime_wall": elapsed,
        "dzn_sha256": sha256(args.dzn),
        "known_routes_sha256": sha256(args.routes),
        "script_sha256": sha256(Path(__file__).resolve()),
        "cpu_only": True,
    }
    if model.SolCount:
        result["objective"] = float(model.ObjVal)
        vals = {edge: var.X for edge, var in edge_vars.items()}
        result["integer_components"] = [
            {"customers": sorted(subset), "demand": sum(demands[i] for i in subset), "depot_edges": dep}
            for subset, dep in components_from_integer(vals, customers)
        ]
        model.write(str(args.out / "standard-cvrp.sol"))
    try:
        best_bound = float(model.ObjBound)
        gap = float(model.MIPGap)
        if math.isfinite(best_bound):
            result["best_bound"] = best_bound
        if math.isfinite(gap):
            result["gap"] = gap
    except Exception:
        pass
    if model.Status == GRB.INFEASIBLE and args.minimum_routes is not None and args.maximum_objective is not None:
        result["proof_statement"] = (
            f"No capacity-feasible CVRP solution with at least {min_routes} routes "
            f"and objective at most {args.maximum_objective} exists."
        )
    (args.out / "gurobi-standard-cvrp-summary.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print("RESULT_JSON=" + json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
