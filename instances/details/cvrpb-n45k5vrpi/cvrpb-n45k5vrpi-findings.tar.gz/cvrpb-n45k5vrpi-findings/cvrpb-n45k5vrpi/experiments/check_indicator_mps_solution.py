#!/usr/bin/env python3
"""Exact Decimal checker for a free-MPS file with CPLEX INDICATORS.

Missing solution values are zero, matching MIPLIB solution semantics.  Unlike
the repository's generic linear-MPS checker, rows named in the INDICATORS
section are enforced only when their binary trigger has the stated value.
No optimization-library code is used.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from collections import defaultdict
from decimal import Decimal, getcontext
from pathlib import Path


getcontext().prec = 80
HEADERS = {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "INDICATORS", "ENDATA"}


def num(text: str) -> Decimal:
    return Decimal(text.replace("D", "E").replace("d", "e"))


def open_text(path: Path):
    if path.suffix == ".gz":
        return gzip.open(path, "rt", encoding="latin-1")
    return path.open(encoding="latin-1")


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while block := f.read(1 << 20):
            h.update(block)
    return h.hexdigest()


def read_solution(path: Path) -> dict[str, Decimal]:
    values = {}
    solution_open = gzip.open(path, "rt", encoding="utf-8") if path.suffix == ".gz" else path.open(encoding="utf-8")
    with solution_open as f:
        for raw in f:
            tok = raw.split()
            if len(tok) < 2 or tok[0].startswith(("#", "=obj=")):
                continue
            try:
                values[tok[0]] = num(tok[1])
            except Exception:
                pass
    return values


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("mps", type=Path)
    ap.add_argument("solution", type=Path)
    ap.add_argument("--json", type=Path, required=True)
    args = ap.parse_args()
    values = read_solution(args.solution)

    row_type = {}
    rhs = defaultdict(Decimal)
    ranges = defaultdict(Decimal)
    variables = set()
    integers = set()
    bounds = []
    indicators = {}
    section = ""
    integer_mode = False
    with open_text(args.mps) as f:
        for raw in f:
            tok = raw.split()
            if not tok or tok[0].startswith("*"):
                continue
            if not raw[0].isspace() and tok[0] in HEADERS:
                section = tok[0]
                continue
            if section == "ROWS":
                row_type[tok[1]] = tok[0]
            elif section == "COLUMNS":
                if "'MARKER'" in tok:
                    integer_mode = "'INTORG'" in tok
                    continue
                variables.add(tok[0])
                if integer_mode:
                    integers.add(tok[0])
            elif section == "RHS":
                for row, x in zip(tok[1::2], tok[2::2]):
                    rhs[row] += num(x)
            elif section == "RANGES":
                for row, x in zip(tok[1::2], tok[2::2]):
                    ranges[row] += num(x)
            elif section == "BOUNDS":
                bounds.append(tok)
            elif section == "INDICATORS":
                if tok[0] != "IF" or len(tok) != 4:
                    raise ValueError(f"unsupported indicator record: {tok}")
                indicators[tok[1]] = (tok[2], num(tok[3]))

    lower = {v: Decimal(0) for v in variables}
    upper = {v: None for v in variables}
    for tok in bounds:
        kind, var = tok[0], tok[2]
        x = num(tok[3]) if len(tok) > 3 else Decimal(0)
        if kind == "LO":
            lower[var] = x
        elif kind == "UP":
            upper[var] = x
        elif kind == "FX":
            lower[var] = upper[var] = x
        elif kind == "FR":
            lower[var], upper[var] = Decimal("-Infinity"), None
        elif kind == "MI":
            lower[var] = Decimal("-Infinity")
        elif kind == "PL":
            upper[var] = None
        elif kind == "BV":
            lower[var], upper[var] = Decimal(0), Decimal(1)
            integers.add(var)
        elif kind == "LI":
            lower[var] = x
            integers.add(var)
        elif kind == "UI":
            upper[var] = x
            integers.add(var)
        else:
            raise ValueError(f"unsupported bound {kind}")

    objective_rows = {r for r, typ in row_type.items() if typ == "N"}
    activity = defaultdict(Decimal)
    objective = Decimal(0)
    section = ""
    with open_text(args.mps) as f:
        for raw in f:
            tok = raw.split()
            if not tok or tok[0].startswith("*"):
                continue
            if not raw[0].isspace() and tok[0] in HEADERS:
                section = tok[0]
                continue
            if section != "COLUMNS" or "'MARKER'" in tok:
                continue
            x = values.get(tok[0], Decimal(0))
            for row, a in zip(tok[1::2], tok[2::2]):
                term = num(a) * x
                if row in objective_rows:
                    objective += term
                else:
                    activity[row] += term

    def row_violation(row: str) -> Decimal:
        lhs, b, typ = activity[row], rhs[row], row_type[row]
        width = ranges.get(row, Decimal(0))
        if width:
            width_abs = abs(width)
            if typ == "G":
                lo, hi = b, b + width_abs
            elif typ == "L":
                lo, hi = b - width_abs, b
            elif width > 0:
                lo, hi = b, b + width_abs
            else:
                lo, hi = b - width_abs, b
            return max(Decimal(0), lo - lhs, lhs - hi)
        if typ == "E":
            return abs(lhs - b)
        if typ == "L":
            return max(Decimal(0), lhs - b)
        if typ == "G":
            return max(Decimal(0), b - lhs)
        raise ValueError(f"bad row type {typ}")

    linear_violations = []
    indicator_violations = []
    active_indicators = 0
    inactive_indicators = 0
    malformed_triggers = []
    for row, typ in row_type.items():
        if typ == "N":
            continue
        if row in indicators:
            trigger, trigger_value = indicators[row]
            actual = values.get(trigger, Decimal(0))
            if actual not in (Decimal(0), Decimal(1)):
                malformed_triggers.append((abs(actual - actual.to_integral_value()), trigger, actual))
            if actual != trigger_value:
                inactive_indicators += 1
                continue
            active_indicators += 1
            v = row_violation(row)
            if v:
                indicator_violations.append((v, row, activity[row], rhs[row], typ, trigger, actual))
        else:
            v = row_violation(row)
            if v:
                linear_violations.append((v, row, activity[row], rhs[row], typ))

    bound_violations = []
    for var in variables:
        x = values.get(var, Decimal(0))
        v = max(Decimal(0), lower[var] - x)
        if upper[var] is not None:
            v = max(v, x - upper[var])
        if v:
            bound_violations.append((v, var, x, lower[var], upper[var]))
    int_violations = []
    for var in integers:
        x = values.get(var, Decimal(0))
        v = abs(x - x.to_integral_value())
        if v:
            int_violations.append((v, var, x))

    for seq in (linear_violations, indicator_violations, bound_violations, int_violations, malformed_triggers):
        seq.sort(reverse=True)
    report = {
        "mps": str(args.mps),
        "mps_sha256": digest(args.mps),
        "solution": str(args.solution),
        "solution_sha256": digest(args.solution),
        "objective_exact_decimal": str(objective),
        "variables_in_mps": len(variables),
        "solution_entries": len(values),
        "unknown_solution_entries": sorted(set(values) - variables),
        "integer_variables": len(integers),
        "ordinary_linear_rows": len(row_type) - len(objective_rows) - len(indicators),
        "indicator_rows": len(indicators),
        "active_indicators": active_indicators,
        "inactive_indicators": inactive_indicators,
        "exact_linear_violations": len(linear_violations),
        "exact_indicator_violations": len(indicator_violations),
        "exact_bound_violations": len(bound_violations),
        "exact_integrality_violations": len(int_violations),
        "malformed_indicator_triggers": len(malformed_triggers),
        "max_linear_violation": str(linear_violations[0][0] if linear_violations else 0),
        "max_indicator_violation": str(indicator_violations[0][0] if indicator_violations else 0),
        "max_bound_violation": str(bound_violations[0][0] if bound_violations else 0),
        "max_integrality_violation": str(int_violations[0][0] if int_violations else 0),
        "largest_linear_violations": [[str(x) for x in item] for item in linear_violations[:10]],
        "largest_indicator_violations": [[str(x) for x in item] for item in indicator_violations[:10]],
        "largest_bound_violations": [[str(x) for x in item] for item in bound_violations[:10]],
        "largest_integrality_violations": [[str(x) for x in item] for item in int_violations[:10]],
        "strictly_feasible": not (
            linear_violations or indicator_violations or bound_violations or int_violations or malformed_triggers
        ),
        "checker": "independent Python Decimal; no optimization library",
    }
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))
    if not report["strictly_feasible"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
