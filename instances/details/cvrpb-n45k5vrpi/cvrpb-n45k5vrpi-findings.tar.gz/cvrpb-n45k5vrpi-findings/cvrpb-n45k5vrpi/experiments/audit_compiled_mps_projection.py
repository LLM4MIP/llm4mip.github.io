#!/usr/bin/env python3
"""Audit the coefficient-level link from the anonymous MPS to CVRP semantics.

The MPS was emitted by the MiniZinc CPLEX backend with anonymous sequential
``X_INTRODUCED_i_`` names.  This checker parses the original compressed bytes
without a solver and verifies the semantic-array layout, domains, fixed depot
links, objective equation, and compiler constraint gadgets used in the route
projection.  Every numeric comparison uses exact ``Decimal`` arithmetic.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from decimal import Decimal, getcontext
from pathlib import Path


getcontext().prec = 80
HEADERS = {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "INDICATORS", "ENDATA"}
ARRAYS = ("successor", "predecessor", "vehicle", "load", "arrival_time")


def number(text: str) -> Decimal:
    return Decimal(text.replace("D", "E").replace("d", "e"))


def variable_name(index: int) -> str:
    return f"X_INTRODUCED_{index}_"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(1 << 20):
            h.update(block)
    return h.hexdigest()


def parse_dzn(path: Path) -> tuple[int, int, list[int], list[list[int]]]:
    text = path.read_text(encoding="utf-8")
    customer_count = int(re.search(r"\bN\s*=\s*(\d+)\s*;", text).group(1))
    capacity = int(re.search(r"\bCapacity\s*=\s*(\d+)\s*;", text).group(1))
    demand_text = re.search(r"Demand\s*=\s*\[(.*?)\]\s*;", text, re.S).group(1)
    demands = [int(value) for value in re.findall(r"-?\d+", demand_text)]
    distance_text = re.search(r"Distance\s*=\s*\[\|(.*?)\|\]\s*;", text, re.S).group(1)
    distances = []
    for raw_row in distance_text.split("|"):
        row = [int(value) for value in re.findall(r"-?\d+", raw_row)]
        if row:
            distances.append(row)
    matrix_order = customer_count + 1
    if (
        len(demands) != customer_count
        or len(distances) != matrix_order
        or any(len(row) != matrix_order for row in distances)
    ):
        raise AssertionError("unexpected DZN dimensions")
    return customer_count, capacity, demands, distances


@dataclass
class ParsedMps:
    row_sense: dict[str, str]
    rows: dict[str, dict[str, Decimal]]
    rhs: dict[str, Decimal]
    lower: dict[str, Decimal]
    upper: dict[str, Decimal | None]
    integers: set[str]
    variables: set[str]
    objective: dict[str, Decimal]
    indicators: dict[str, tuple[str, Decimal]]


def parse_mps(path: Path) -> ParsedMps:
    row_sense: dict[str, str] = {}
    rows: dict[str, dict[str, Decimal]] = defaultdict(dict)
    rhs: dict[str, Decimal] = defaultdict(Decimal)
    bounds: list[list[str]] = []
    indicators: dict[str, tuple[str, Decimal]] = {}
    variables: set[str] = set()
    integers: set[str] = set()
    objective: dict[str, Decimal] = defaultdict(Decimal)
    section = ""
    integer_mode = False
    with gzip.open(path, "rt", encoding="latin-1") as stream:
        for raw in stream:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if not raw[0].isspace() and tokens[0] in HEADERS:
                section = tokens[0]
                continue
            if section == "ROWS":
                row_sense[tokens[1]] = tokens[0]
            elif section == "COLUMNS":
                if "'MARKER'" in tokens:
                    integer_mode = "'INTORG'" in tokens
                    continue
                variable = tokens[0]
                variables.add(variable)
                if integer_mode:
                    integers.add(variable)
                for row, coefficient in zip(tokens[1::2], tokens[2::2]):
                    value = number(coefficient)
                    if row_sense[row] == "N":
                        objective[variable] += value
                    else:
                        rows[row][variable] = rows[row].get(variable, Decimal(0)) + value
            elif section == "RHS":
                for row, value in zip(tokens[1::2], tokens[2::2]):
                    rhs[row] += number(value)
            elif section == "RANGES":
                raise ValueError("RANGES records are not supported by this exact audit")
            elif section == "BOUNDS":
                bounds.append(tokens)
            elif section == "INDICATORS":
                if tokens[0] != "IF" or len(tokens) != 4:
                    raise ValueError(f"unsupported indicator record: {tokens}")
                indicators[tokens[1]] = (tokens[2], number(tokens[3]))

    lower = {variable: Decimal(0) for variable in variables}
    upper: dict[str, Decimal | None] = {variable: None for variable in variables}
    for tokens in bounds:
        kind, variable = tokens[0], tokens[2]
        value = number(tokens[3]) if len(tokens) > 3 else Decimal(0)
        if kind == "LO":
            lower[variable] = value
        elif kind == "UP":
            upper[variable] = value
        elif kind == "FX":
            lower[variable] = upper[variable] = value
        elif kind == "FR":
            lower[variable], upper[variable] = Decimal("-Infinity"), None
        elif kind == "MI":
            lower[variable] = Decimal("-Infinity")
        elif kind == "PL":
            upper[variable] = None
        elif kind == "BV":
            lower[variable], upper[variable] = Decimal(0), Decimal(1)
            integers.add(variable)
        elif kind == "LI":
            lower[variable] = value
            integers.add(variable)
        elif kind == "UI":
            upper[variable] = value
            integers.add(variable)
        else:
            raise ValueError(f"unsupported bound record: {tokens}")
    return ParsedMps(
        row_sense=row_sense,
        rows=dict(rows),
        rhs=dict(rhs),
        lower=lower,
        upper=upper,
        integers=integers,
        variables=variables,
        objective=dict(objective),
        indicators=indicators,
    )


def row_number(name: str) -> int:
    match = re.search(r"_(\d+)$", name)
    return int(match.group(1)) if match else -1


def build_alias_map(model: ParsedMps) -> tuple[dict[str, str], int]:
    """Collapse unconditional two-variable equations ``x-y=0``."""
    parent = {variable: variable for variable in model.variables}

    def find(variable: str) -> str:
        while parent[variable] != variable:
            parent[variable] = parent[parent[variable]]
            variable = parent[variable]
        return variable

    def union(left: str, right: str) -> None:
        left_root, right_root = find(left), find(right)
        if left_root != right_root:
            parent[max(left_root, right_root)] = min(left_root, right_root)

    alias_rows = 0
    for row, terms in model.rows.items():
        if row in model.indicators:
            continue
        if (
            model.row_sense[row] == "E"
            and model.rhs.get(row, 0) == 0
            and len(terms) == 2
            and sorted(terms.values()) == [Decimal(-1), Decimal(1)]
        ):
            union(*terms)
            alias_rows += 1
    aliases = {variable: find(variable) for variable in model.variables}
    return aliases, alias_rows


def recognize_element_groups(model: ParsedMps, aliases: dict[str, str]) -> list[dict]:
    """Recognize the backend's shared one-hot ``array[index]`` gadgets."""
    binaries = {
        variable for variable in model.integers
        if model.lower[variable] == 0 and model.upper[variable] == 1
    }
    ordinary_by_variable: dict[str, set[str]] = defaultdict(set)
    for row, terms in model.rows.items():
        if row not in model.indicators:
            for variable in terms:
                ordinary_by_variable[variable].add(row)
    indicators_by_trigger: dict[str, list[str]] = defaultdict(list)
    for row, (trigger, _) in model.indicators.items():
        indicators_by_trigger[trigger].append(row)

    groups = []
    for onehot_row, terms in model.rows.items():
        if onehot_row in model.indicators:
            continue
        if not (
            model.row_sense[onehot_row] == "E"
            and model.rhs.get(onehot_row, 0) == 1
            and len(terms) >= 2
            and all(coefficient == 1 and variable in binaries for variable, coefficient in terms.items())
        ):
            continue
        selectors = set(terms)
        selector_classes = {aliases[selector] for selector in selectors}
        if len(selector_classes) != len(selectors):
            raise AssertionError(f"{onehot_row}: selector aliases collide")
        common_rows = set.intersection(*(ordinary_by_variable[selector] for selector in selectors))
        weighted_rows = []
        for row in common_rows - {onehot_row}:
            row_terms = model.rows[row]
            extras = set(row_terms) - selectors
            if model.row_sense[row] == "E" and len(extras) == 1:
                weighted_rows.append((row, next(iter(extras))))
        if len(weighted_rows) != 1:
            raise AssertionError(f"{onehot_row}: expected one index row, got {weighted_rows}")
        index_row, index_variable = weighted_rows[0]
        index_terms = model.rows[index_row]
        index_coefficient = index_terms[index_variable]
        selector_value = {
            aliases[selector]: (model.rhs.get(index_row, 0) - index_terms[selector]) / index_coefficient
            for selector in selectors
        }
        feasible_selector_classes = {
            selector_class for selector_class, value in selector_value.items()
            if value >= model.lower[index_variable]
            and (model.upper[index_variable] is None or value <= model.upper[index_variable])
        }

        equality_pairs = []
        equivalent_triggers = [
            trigger for trigger in indicators_by_trigger
            if aliases[trigger] in selector_classes
        ]
        for selector in equivalent_triggers:
            for row in indicators_by_trigger[selector]:
                if model.indicators[row][1] != 1:
                    continue
                row_terms = model.rows[row]
                if not (
                    model.row_sense[row] == "E"
                    and model.rhs.get(row, 0) == 0
                    and len(row_terms) == 2
                    and sorted(row_terms.values()) == [Decimal(-1), Decimal(1)]
                ):
                    continue
                pair_classes = tuple(aliases[variable] for variable in row_terms)
                equality_pairs.append((aliases[selector], row, pair_classes))
        frequency: Counter[str] = Counter()
        for output_candidate in {variable for _, _, pair in equality_pairs for variable in pair}:
            frequency[output_candidate] = len({
                selector_class
                for selector_class, _, pair in equality_pairs
                if output_candidate in pair
            })
        outputs = []
        for output, count in frequency.items():
            if count < len(feasible_selector_classes):
                continue
            entries = []
            indicator_rows = []
            covered_selectors = set()
            entry_by_selector: dict[str, tuple[str, str]] = {}
            for selector_class, row, pair in equality_pairs:
                if output in pair:
                    other = pair[0] if pair[1] == output else pair[1]
                    entries.append(other)
                    indicator_rows.append(row)
                    covered_selectors.add(selector_class)
                    previous = entry_by_selector.get(selector_class)
                    if previous is not None and previous[0] != other:
                        raise AssertionError(
                            f"{onehot_row}: output {output} has conflicting entries for {selector_class}"
                        )
                    entry_by_selector[selector_class] = (other, row)
            if covered_selectors >= feasible_selector_classes:
                outputs.append({
                    "output": output,
                    "array_entries": sorted(set(entries)),
                    "array_entry_count": len(set(entries)),
                    "indicator_row_number_interval": [
                        min(row_number(row) for row in indicator_rows),
                        max(row_number(row) for row in indicator_rows),
                    ],
                    "selection_map": [
                        [str(selector_value[selector_class]), entry_by_selector[selector_class][0],
                         entry_by_selector[selector_class][1]]
                        for selector_class in sorted(
                            feasible_selector_classes,
                            key=lambda item: selector_value[item],
                        )
                    ],
                })
        groups.append({
            "onehot_row": onehot_row,
            "index_row": index_row,
            "index_variable": index_variable,
            "selector_count": len(selectors),
            "feasible_selector_count_from_index_domain": len(feasible_selector_classes),
            "selector_value_by_class": [
                [str(selector_value[selector_class]), selector_class]
                for selector_class in sorted(selector_classes, key=lambda item: selector_value[item])
            ],
            "outputs": outputs,
        })
    groups.sort(key=lambda group: row_number(group["onehot_row"]))
    return groups


def derive_fixed_values(
    model: ParsedMps, aliases: dict[str, str]
) -> tuple[dict[str, Decimal], dict[str, list[str]]]:
    fixed: dict[str, Decimal] = {}
    sources: dict[str, list[str]] = defaultdict(list)

    def record(variable: str, value: Decimal, source: str) -> None:
        root = aliases[variable]
        if root in fixed and fixed[root] != value:
            raise AssertionError(f"conflicting fixed values for {root}: {fixed[root]} and {value}")
        fixed[root] = value
        sources[root].append(source)

    for variable in model.variables:
        if model.upper[variable] is not None and model.lower[variable] == model.upper[variable]:
            record(variable, model.lower[variable], f"bound:{variable}")
    for row, terms in model.rows.items():
        if row in model.indicators or model.row_sense[row] != "E" or len(terms) != 1:
            continue
        variable, coefficient = next(iter(terms.items()))
        record(variable, model.rhs.get(row, 0) / coefficient, f"row:{row}")
    return fixed, dict(sources)


def canonical_terms(terms: dict[str, Decimal], aliases: dict[str, str]) -> dict[str, Decimal]:
    result: dict[str, Decimal] = defaultdict(Decimal)
    for variable, coefficient in terms.items():
        result[aliases[variable]] += coefficient
    return {variable: coefficient for variable, coefficient in result.items() if coefficient != 0}


def projection_audit(
    model: ParsedMps,
    aliases: dict[str, str],
    element_groups: list[dict],
    customer_count: int,
    capacity: int,
    demands: list[int],
    distances: list[list[int]],
) -> dict:
    node_count = 3 * customer_count
    first_start = customer_count + 1
    first_end = 2 * customer_count + 1
    fixed, fixed_sources = derive_fixed_values(model, aliases)
    group_by_index = {group["index_variable"]: group for group in element_groups}
    if len(group_by_index) != len(element_groups):
        raise AssertionError("duplicate element index variables")

    class_members: dict[str, list[str]] = defaultdict(list)
    for variable, root in aliases.items():
        class_members[root].append(variable)

    def class_is_integral(root: str) -> bool:
        return any(variable in model.integers for variable in class_members[root]) or (
            root in fixed and fixed[root] == fixed[root].to_integral_value()
        )

    def effective_bounds(root: str) -> tuple[Decimal, Decimal | None]:
        if root in fixed:
            return fixed[root], fixed[root]
        lower = max(model.lower[variable] for variable in class_members[root])
        finite_upper = [model.upper[variable] for variable in class_members[root] if model.upper[variable] is not None]
        return lower, min(finite_upper) if finite_upper else None

    successor_copy_base = 5 * node_count + 1
    successor_entries = {
        node: aliases[variable_name(successor_copy_base + node)]
        for node in range(1, node_count + 1)
    }
    for node, root in successor_entries.items():
        lower, upper = effective_bounds(root)
        if not class_is_integral(root) or lower < 1 or upper is None or upper > node_count:
            raise AssertionError(f"bad effective successor domain at node {node}: {lower}..{upper}")

    semantic_constants = {
        "load": {node: Decimal(0) for node in range(first_start, first_end)},
        "arrival": {node: Decimal(0) for node in range(first_start, first_end)},
    }
    semantic_bases = {"load": 3 * node_count, "arrival": 4 * node_count}

    def expected_semantic(array: str, node: int) -> tuple[str, str | Decimal]:
        variable = variable_name(semantic_bases[array] + node - 1)
        if variable in model.variables:
            return "class", aliases[variable]
        try:
            return "value", semantic_constants[array][node]
        except KeyError as exc:
            raise AssertionError(f"unexpected missing {array}[{node}] ({variable})") from exc

    def entry_matches(entry_class: str, expected: tuple[str, str | Decimal]) -> bool:
        kind, value = expected
        if kind == "class":
            return entry_class == value
        return fixed.get(entry_class) == value

    def output_matches_array(output: dict, array: str) -> bool:
        seen = set()
        for value_text, entry_class, _ in output["selection_map"]:
            value = Decimal(value_text)
            if value != value.to_integral_value() or not 1 <= value <= node_count:
                return False
            node = int(value)
            seen.add(node)
            if not entry_matches(entry_class, expected_semantic(array, node)):
                return False
        return len(seen) == len(output["selection_map"])

    def output_matches_successor(output: dict) -> bool:
        seen = set()
        for value_text, entry_class, _ in output["selection_map"]:
            value = Decimal(value_text)
            if value != value.to_integral_value() or not 1 <= value <= node_count:
                return False
            node = int(value)
            seen.add(node)
            if entry_class != successor_entries[node]:
                return False
        return len(seen) == len(output["selection_map"])

    # The customer- and end-node predecessor gadgets force those values to
    # occur in the effective successor vector.  Start-node values are supplied
    # by the fixed end->next-start connector arcs.
    surjectivity_targets = list(range(1, first_start)) + list(range(first_end, node_count + 1))
    predecessor_indices = (
        list(range(node_count, node_count + customer_count))
        + list(range(node_count + 2 * customer_count, node_count + 3 * customer_count))
    )
    surjectivity_records = []
    for target, introduced_id in zip(surjectivity_targets, predecessor_indices):
        index_variable = variable_name(introduced_id)
        group = group_by_index.get(index_variable)
        if group is None:
            raise AssertionError(f"missing predecessor-index element group for target {target}")
        matches = [
            output for output in group["outputs"]
            if fixed.get(output["output"]) == target and output_matches_successor(output)
        ]
        if len(matches) != 1:
            raise AssertionError(f"target {target}: expected one successor-array output, got {len(matches)}")
        output = matches[0]
        surjectivity_records.append({
            "target_value": target,
            "index_variable": index_variable,
            "onehot_row": group["onehot_row"],
            "index_row": group["index_row"],
            "selector_count": group["feasible_selector_count_from_index_domain"],
            "fixed_output_class": output["output"],
            "indicator_row_number_interval": output["indicator_row_number_interval"],
        })

    connector_records = []
    connector_values = list(range(first_start + 1, first_end)) + [first_start]
    for node, expected_value in zip(range(first_end, node_count + 1), connector_values):
        root = successor_entries[node]
        if fixed.get(root) != expected_value:
            raise AssertionError(f"connector successor[{node}] is {fixed.get(root)}, expected {expected_value}")
        connector_records.append({
            "node": node,
            "successor": expected_value,
            "class": root,
            "fixed_by": fixed_sources[root],
        })
    covered_values = {record["target_value"] for record in surjectivity_records} | set(connector_values)
    if covered_values != set(range(1, node_count + 1)):
        raise AssertionError("successor surjectivity coverage is incomplete")

    canonical_rows = {
        row: canonical_terms(terms, aliases)
        for row, terms in model.rows.items()
        if row not in model.indicators
    }

    def rows_equal_to(sense: str, rhs: Decimal, terms: dict[str, Decimal]) -> list[str]:
        return [
            row for row, row_terms in canonical_rows.items()
            if model.row_sense[row] == sense and model.rhs.get(row, 0) == rhs and row_terms == terms
        ]

    propagation_records = []
    all_successor_index_variables = {
        variable_name(node - 1) for node in range(1, first_end)
    }
    if not all_successor_index_variables <= set(group_by_index):
        raise AssertionError("missing successor-index element groups")
    for node in range(1, first_end):
        group = group_by_index[variable_name(node - 1)]
        feasible_values = {int(Decimal(value)) for value, _ in group["selector_value_by_class"] if (
            Decimal(value) >= model.lower[group["index_variable"]]
            and (model.upper[group["index_variable"]] is None or Decimal(value) <= model.upper[group["index_variable"]])
        )}
        if feasible_values != set(range(1, node_count + 1)) - {node}:
            raise AssertionError(f"successor[{node}] admissible values do not equal all nodes except itself")

        arrival_outputs = [output for output in group["outputs"] if output_matches_array(output, "arrival")]
        load_outputs = [output for output in group["outputs"] if output_matches_array(output, "load")]
        if len(arrival_outputs) != 1 or len(load_outputs) != 1:
            raise AssertionError(
                f"node {node}: arrival outputs={len(arrival_outputs)}, load outputs={len(load_outputs)}"
            )
        arrival_output = arrival_outputs[0]["output"]
        load_output = load_outputs[0]["output"]

        selector_values = {
            selector_class: int(Decimal(value))
            for value, selector_class in group["selector_value_by_class"]
            if int(Decimal(value)) in feasible_values
        }
        expected_selector_coefficients = {}
        from_index = node if node <= customer_count else 0
        for selector_class, successor_node in selector_values.items():
            to_index = successor_node if successor_node <= customer_count else 0
            coefficient = Decimal(distances[from_index][to_index])
            if coefficient:
                expected_selector_coefficients[selector_class] = coefficient

        distance_candidates = []
        selector_classes = set(selector_values)
        for row, row_terms in canonical_rows.items():
            if model.row_sense[row] != "E" or model.rhs.get(row, 0) != 0:
                continue
            if any(row_terms.get(selector, 0) != coefficient for selector, coefficient in expected_selector_coefficients.items()):
                continue
            if any(row_terms.get(selector, 0) != 0 for selector in selector_classes - set(expected_selector_coefficients)):
                continue
            extras = set(row_terms) - selector_classes
            if len(extras) == 1:
                output_class = next(iter(extras))
                if row_terms[output_class] == -1 and len(row_terms) == len(expected_selector_coefficients) + 1:
                    distance_candidates.append((row, output_class))
        if len(distance_candidates) != 1:
            raise AssertionError(f"node {node}: distance encoding candidates={distance_candidates}")
        distance_row, distance_output = distance_candidates[0]

        time_terms = {distance_output: Decimal(1), arrival_output: Decimal(-1)}
        arrival_kind, arrival_value = expected_semantic("arrival", node)
        if arrival_kind == "class":
            time_terms[arrival_value] = time_terms.get(arrival_value, Decimal(0)) + 1
        elif arrival_value != 0:
            raise AssertionError(f"unexpected nonzero fixed start arrival at node {node}")
        time_terms = {key: value for key, value in time_terms.items() if value}
        time_rows = rows_equal_to("L", Decimal(0), time_terms)
        if len(time_rows) != 1:
            raise AssertionError(f"node {node}: time propagation rows={time_rows}")

        if node <= customer_count:
            load_kind, load_value = expected_semantic("load", node)
            if load_kind != "class":
                raise AssertionError(f"customer load[{node}] unexpectedly fixed")
            load_terms = {load_value: Decimal(1), load_output: Decimal(-1)}
            load_rows = rows_equal_to("E", Decimal(-demands[node - 1]), load_terms)
            if len(load_rows) != 1:
                raise AssertionError(f"node {node}: load propagation rows={load_rows}")
            load_evidence = load_rows[0]
        else:
            if fixed.get(load_output) != 0:
                raise AssertionError(f"start node {node}: selected successor load is not fixed to zero")
            load_evidence = fixed_sources[load_output]

        propagation_records.append({
            "node": node,
            "kind": "customer" if node <= customer_count else "start_depot",
            "successor_onehot_row": group["onehot_row"],
            "successor_index_row": group["index_row"],
            "arrival_element_output": arrival_output,
            "load_element_output": load_output,
            "distance_linearization_row": distance_row,
            "time_propagation_row": time_rows[0],
            "load_propagation_evidence": load_evidence,
        })

    objective_terms = {aliases["objective"]: Decimal(1)}
    for node in range(first_end, node_count + 1):
        kind, value = expected_semantic("arrival", node)
        if kind != "class":
            raise AssertionError(f"end arrival[{node}] unexpectedly fixed")
        objective_terms[value] = objective_terms.get(value, Decimal(0)) - 1
    objective_rows = rows_equal_to("E", Decimal(0), objective_terms)
    if len(objective_rows) != 1:
        raise AssertionError(f"objective=sum(end arrival) rows={objective_rows}")

    load_domain_checks = []
    for node in range(1, node_count + 1):
        kind, value = expected_semantic("load", node)
        if kind == "value":
            lower = upper = value
            integral = value == value.to_integral_value()
        else:
            lower, upper = effective_bounds(value)
            integral = class_is_integral(value)
        if lower < 0 or upper is None or upper > capacity or not integral:
            raise AssertionError(f"bad load domain at node {node}: {lower}..{upper}, integral={integral}")
        load_domain_checks.append([node, str(lower), str(upper)])
    if any(demand <= 0 for demand in demands):
        raise AssertionError("demand positivity check failed")
    if any(
        distances[i][j] < 0
        for i in range(customer_count + 1)
        for j in range(customer_count + 1)
    ):
        raise AssertionError("a distance is negative")
    zero_distance_customer_pairs = [
        [i, j]
        for i in range(1, customer_count + 1)
        for j in range(i + 1, customer_count + 1)
        if distances[i][j] == 0
    ]

    return {
        "claim_scope": (
            "Sufficient coefficient-level projection only: every feasible MPS point projects to "
            "capacity-feasible depot routes whose integer CVRP cost is no greater than the MPS objective. "
            "This is not a complete reverse compilation of every auxiliary constraint."
        ),
        "successor_vector": {
            "effective_entries": node_count,
            "integral_domain": f"1..{node_count}",
            "surjectivity_element_gadgets": surjectivity_records,
            "fixed_end_to_next_start_connectors": connector_records,
            "deduction": (
                f"{node_count} integer entries in 1..{node_count} containing every value "
                "are a permutation"
            ),
        },
        "route_propagation": {
            "customer_and_start_nodes_checked": len(propagation_records),
            "records": propagation_records,
            "all_customer_demands_positive": True,
            "total_demand": sum(demands),
            "capacity_from_load_domains": capacity,
            "all_distances_nonnegative": True,
            "zero_distance_distinct_customer_pairs": zero_distance_customer_pairs,
        },
        "objective_equation": {
            "row": objective_rows[0],
            "equation": f"objective = sum(arrival_time[{first_end}..{node_count}])",
            "objective_coefficient": str(model.objective.get("objective", 0)),
        },
        "logical_projection": [
            "Surjectivity plus finite equal-size domain makes successor a permutation.",
            f"Deleting the {customer_count} fixed end->next-start arcs leaves start-to-end paths and possible customer-only cycles.",
            "Positive customer demand and load propagation exclude customer-only cycles, even when distinct coordinates have zero distance.",
            f"Load starts at zero, adds each positive customer demand, and always lies in 0..{capacity}, so every path is capacity-feasible.",
            "Arrival propagation and the objective equation make projected route cost no larger than the MPS objective.",
        ],
        "all_projection_checks_passed": True,
    }


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("mps", type=Path)
    ap.add_argument("dzn", type=Path)
    ap.add_argument("--json", type=Path, required=True)
    args = ap.parse_args()
    model = parse_mps(args.mps)
    customer_count, capacity, demands, distances = parse_dzn(args.dzn)
    node_count = 3 * customer_count

    ordinary_memberships: dict[str, list[str]] = defaultdict(list)
    indicator_term_memberships: dict[str, list[str]] = defaultdict(list)
    trigger_memberships: dict[str, list[str]] = defaultdict(list)
    for row, terms in model.rows.items():
        destination = indicator_term_memberships if row in model.indicators else ordinary_memberships
        for variable in terms:
            destination[variable].append(row)
    for row, (trigger, _) in model.indicators.items():
        trigger_memberships[trigger].append(row)

    semantic_arrays = {}
    for array_index, array_name in enumerate(ARRAYS):
        base = array_index * node_count
        names = [variable_name(base + offset) for offset in range(node_count)]
        present = [name for name in names if name in model.variables]
        missing = [name for name in names if name not in model.variables]
        semantic_arrays[array_name] = {
            "introduced_id_interval_zero_based": [base, base + node_count - 1],
            "present": len(present),
            "missing_as_compiler_substitutions": missing,
            "domain_histogram": sorted(
                ([str(key[0]), None if key[1] is None else str(key[1]), value]
                 for key, value in Counter((model.lower[name], model.upper[name]) for name in present).items()),
                key=lambda item: (-item[2], item[0]),
            ),
            "all_present_variables_integer": all(name in model.integers for name in present),
            "ordinary_row_membership_histogram": sorted(Counter(
                len(ordinary_memberships[name]) for name in present
            ).items()),
            "indicator_term_membership_histogram": sorted(Counter(
                len(indicator_term_memberships[name]) for name in present
            ).items()),
            "indicator_trigger_membership_histogram": sorted(Counter(
                len(trigger_memberships[name]) for name in present
            ).items()),
        }

    semantic_names = {variable_name(i) for i in range(len(ARRAYS) * node_count)} | {"objective"}
    touching_rows = []
    for row, terms in model.rows.items():
        touched = sorted(set(terms) & semantic_names)
        if touched:
            touching_rows.append({
                "row": row,
                "number": row_number(row),
                "sense": model.row_sense[row],
                "rhs": str(model.rhs.get(row, 0)),
                "indicator": (
                    None if row not in model.indicators else
                    [model.indicators[row][0], str(model.indicators[row][1])]
                ),
                "semantic_terms": [[name, str(terms[name])] for name in touched],
                "degree": len(terms),
            })
    touching_rows.sort(key=lambda item: (item["number"], item["row"]))

    aliases, alias_row_count = build_alias_map(model)
    element_groups = recognize_element_groups(model, aliases)
    projection = projection_audit(
        model, aliases, element_groups, customer_count, capacity, demands, distances
    )

    nonzero_objective = {
        name: value for name, value in model.objective.items() if value != 0
    }
    explicit_zero_objective_names = sorted(
        name for name, value in model.objective.items() if value == 0
    )
    checks = {
        "objective_is_single_named_variable_after_dropping_explicit_zeros": (
            nonzero_objective == {"objective": Decimal(1)}
        ),
        "recognized_element_group_count_is_4N": len(element_groups) == 4 * customer_count,
        "semantic_array_slot_count_is_15N": len(ARRAYS) * node_count == 15 * customer_count,
        "projection_checks_passed": projection["all_projection_checks_passed"] is True,
    }
    failed_checks = sorted(name for name, passed in checks.items() if not passed)
    if failed_checks:
        raise AssertionError(f"top-level audit checks failed: {failed_checks}")

    report = {
        "schema": "compiled-minizinc-cvrp-projection-audit-v2",
        "script_sha256": sha256(Path(__file__).resolve()),
        "mps_sha256": sha256(args.mps),
        "dzn_sha256": sha256(args.dzn),
        "model_counts": {
            "variables": len(model.variables),
            "integer_variables": len(model.integers),
            "ordinary_rows": len(model.row_sense) - 1 - len(model.indicators),
            "indicator_rows": len(model.indicators),
        },
        "objective_coefficients_nonzero": [
            [name, str(value)] for name, value in sorted(nonzero_objective.items())
        ],
        "explicit_zero_objective_coefficients": {
            "count": len(explicit_zero_objective_names),
            "variables": explicit_zero_objective_names,
        },
        "semantic_arrays": semantic_arrays,
        "semantic_touching_row_count": len(touching_rows),
        "recognized_element_gadgets": {
            "count": len(element_groups),
            "selector_count_histogram": sorted(Counter(
                group["selector_count"] for group in element_groups
            ).items()),
            "output_count_histogram": sorted(Counter(
                len(group["outputs"]) for group in element_groups
            ).items()),
            "template": (
                "sum(selectors)=1; weighted selector sum=index; "
                "selector=1 indicators equate each output with its indexed array entry"
            ),
        },
        "unconditional_two_variable_alias_rows": alias_row_count,
        "projection_certificate": projection,
        "checks": checks,
        "all_top_level_checks_passed": True,
    }
    args.json.parent.mkdir(parents=True, exist_ok=True)
    with args.json.open("w", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "model_counts": report["model_counts"],
        "projection_checks_passed": projection["all_projection_checks_passed"],
        "recognized_element_groups": len(element_groups),
        "semantic_touching_rows": len(touching_rows),
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
