# Layered optimality argument for cvrpb-n45k5vrpi

## Claim

The optimum of the downloaded MPS with SHA-256
`368e6310ad1426214baab11beac8a6384315e7c98b8dcc56e2156b8bef187940`
is 751.

## 1. Giant-tour model and CVRP routes

The recovered MiniZinc instance has 44 customers.  Its 132 circuit nodes are
the customer nodes `1..44`, start-depot copies `S_k=44+k`, and end-depot
copies `E_k=88+k`, for `k=1,...,44`.

The model fixes `E_k -> S_(k+1)` (cyclically) and fixes the corresponding
predecessors.  A single `circuit(successor)` therefore decomposes, after those
fixed connector arcs are removed, into start-to-end segments that jointly
visit every customer exactly once.  On every segment containing a customer,
the predecessor/successor vehicle-propagation constraints force the start and
end labels to be the same `k`.  Empty segments can only join depot copies and
carry no customer.

For a nonempty segment, `load[S_k]=0`, `load[S_k]=load[first]`, and
`load[c]+demand[c]=load[successor[c]]`.  Since every load variable lies in
`0..100`, the segment's total demand is at most 100.  Similarly,
`arrivalTime[S_k]=0` and the start/customer time inequalities imply that
`arrivalTime[E_k]` is at least the full depot-to-depot route length.  The MPS
objective is the sum of all end-depot arrival times, so projecting an MPS
solution to routes cannot increase its objective.

Conversely, any set of at most 44 capacity-feasible CVRP routes can be assigned
to start/end pairs; every unused pair takes the direct zero-distance
`S_k -> E_k` arc.  Cumulative loads and travel times satisfy the equations and
attain equality in the objective.  The fixed `E_k -> S_(k+1)` zero-distance
arcs merely join the route segments into the required giant circuit.  There is
no time or load propagation out of an end node, so these virtual arcs cannot
skip a customer arc, reduce a nonempty route cost, or create negative cost.

The finite time domain also causes no hidden restriction.  Every demand is
positive, and the 21 smallest demands are the largest number that fit within
capacity 100.  The largest matrix distance is 129, so any route has the safe
upper bound `(21+1)*129 = 2838`, below `timeBudget = 4320`.

The source audit checks all of these model fragments and every data entry; see
[`source-equivalence.json`](source-equivalence.json).  That source-level check
and the concrete route lift are not, by themselves, a proof that an arbitrary
feasible point of the anonymous compiled MPS has the same route semantics.  A
separate coefficient-level projection audit now closes that direction.

[`../experiments/audit_compiled_mps_projection.py`](../experiments/audit_compiled_mps_projection.py)
parses the compressed MPS bytes with exact `Decimal` arithmetic and recognizes
176 shared element-constraint gadgets.  Each recognized gadget contains an
exactly-one binary selector row, a selector-weighted index equation, and the
indicator equalities that select array entries.  Before matching these
gadgets, the checker takes the transitive closure of 12,232 unconditional
two-variable equations of the form `x-y=0`, because the compiler made several
aliases of the same source value.

The checker verifies the following sufficient subset of the compiled model:

- 88 predecessor-indexed element gadgets, together with 44 fixed connector
  arcs, force all values 1 through 132 to occur in the 132-entry integer
  successor vector.  Hence the successor vector is a permutation.
- For every customer and start-depot node (88 nodes total), the element gadget
  selected by the same successor index returns the correct arrival and load
  array entries.
- For each of those 88 nodes, a separate exact linear selector row contains
  the corresponding DZN distance coefficients, and the compiled time row is
  exactly `arrival[n] + distance[n,successor[n]] <= arrival[successor[n]]`
  after compiler-fixed zeros are removed.
- The 44 customer load rows use the exact DZN demands; the 44 start-node
  selected loads are fixed to zero; every effective load entry is integral in
  `0..100`.
- Row `p_lin_93991` is exactly
  `objective = sum(arrivalTime[89..132])`.

The machine-readable report
[`compiled-mps-projection.json`](compiled-mps-projection.json) records the row
names and auxiliary output classes for all 88 surjectivity gadgets and all 88
time/load propagation checks.  The audit is intentionally scoped as a
sufficient projection proof, not a claim to reverse-compile every auxiliary
constraint in the MPS.  Its verified subset is enough: deleting the fixed
end-to-next-start arcs from the permutation leaves start-to-end paths and
possibly customer-only cycles; positive customer distances and the time rows
exclude those cycles; the load rows make every remaining path capacity
feasible; and the objective row makes the projected route cost no larger than
the MPS objective.

## 2. At least five routes

All 44 customer demands sum to 486 and every vehicle has capacity 100.  Hence
every feasible solution uses at least

`ceil(486 / 100) = 5`

nonempty routes.  This is a direct arithmetic lower bound.

## 3. Exactly five routes cost at least 751

The coordinate, demand, capacity, and complete rounded distance matrix audit
identifies the instance as CVRPLIB `B-n45-k5`, not merely as a similarly named
problem.  CVRPLIB reports 44 customers, five routes, capacity 100, upper bound
751, and `Opt = yes`.  Its downloaded solution has five routes of loads
`[98,97,91,100,100]` and costs `[104,150,134,215,148]`.

Thus, accepting the authoritative CVRPLIB optimality status, every feasible
solution with exactly five routes costs at least 751.  The historical exact
CVRP benchmark convention fixes the displayed number of routes, which is why
the next layer separately handles larger fleets.

## 4. Six or more routes cannot cost at most 750

[`../experiments/prove_standard_cvrp.py`](../experiments/prove_standard_cvrp.py)
builds an undirected integer CVRP model on depot 0 and customers 1 through 44:

- one variable for each of 990 undirected node pairs;
- customer-customer edges are binary;
- depot-customer edges are integer in `0..2`, with value two representing a
  one-customer route;
- every customer has degree two;
- depot degree is at least 12, i.e. at least six routes;
- total integer edge cost is at most 750.

For every customer component `S` in every integer callback solution, the
solver enforces the rounded capacity/connectivity inequality

`x(delta(S)) >= 2*ceil(demand(S)/100)`.

This separation is complete for an integer degree-two solution.  A customer
cycle disconnected from the depot has boundary zero and is cut.  A
depot-to-depot route component has boundary two; if its demand exceeds 100,
the right-hand side is at least four and it is cut.  Therefore any integer
solution surviving all lazy cuts is exactly a collection of at least six
capacity-feasible depot routes.  Fractional min-cut separation adds the same
valid inequality at selected node relaxations but is not needed for logical
completeness.

On `euler4`, Gurobi 13.0.1 used 32 CPU threads and proved this model infeasible:

- 990 integer variables (946 binary), 46 initial rows, 2,970 nonzeros;
- 12,347 branch-and-bound nodes and 25.58 seconds;
- 632 integer callback solutions checked, all 632 invalid and cut;
- 1,064 distinct lazy inequalities proposed, maximum right-hand side 8;
- 186 fractional user cuts proposed in the callback;
- final status `INFEASIBLE`, solution count zero.

Gurobi's final cutting-plane table lists 438 lazy constraints and 17 user cuts;
those are solver-accepted/retained counts and need not equal the callback
proposal counts.  The machine-readable result is
[`free-fleet-kge6-proof.json`](free-fleet-kge6-proof.json), the complete solver
log is [`../logs/gurobi-free-fleet-kge6-proof.log`](../logs/gurobi-free-fleet-kge6-proof.log),
and the recorded proof-script SHA-256 is
`e40d49db7320763825f6b2dea797e3cf0feb57bfdb61684f3f08ed1fa5381b60`.

This is a solver-certified exhaustive branch-and-cut result for an exact
combinatorial formulation, not a heuristic search.  It is not a standalone
formal proof trace: replay requires trusting Gurobi's terminal status and
callback implementation.

## 5. Lower bound and matching incumbent

Assume an MPS solution had objective below 751.  Its projected routes have
integer distance at most 750.

- Fewer than five routes contradict total demand and capacity.
- Exactly five routes contradict the CVRPLIB optimum 751.
- At least six routes contradict the independent infeasibility run above.

Therefore every MPS solution has objective at least 751.  Unlike the earlier
source-identification argument alone, the coefficient-level audit above
establishes the required MPS-to-CVRP projection for every feasible MPS point.

The official five routes were lifted into all 37,568 MPS variables.  The
solver-independent `Decimal` checker reports exact objective 751 and zero
ordinary-row, active-indicator, bound, and integrality violations; see
[`../solutions/cvrpb-751-full.validation.json`](../solutions/cvrpb-751-full.validation.json).
This supplies the matching upper bound.  Consequently the MPS optimum is
exactly 751.
