#!/usr/bin/env python3
"""
Endpoint interval-order reduction for fhnw-binschedule2.

Gurobi reads the original MPS, but the original model is never optimized
or presolved.

The only optimization calls concern a derived model with 76 assignment
binaries.  Its mathematics is:

  choose endpoint y_i in {0,1};
  n_0 <= 39, n_5 <= 39;
  w_k = width of the interval order chosen for endpoint k;
  d_k >= w_k + n_k - 40;
  minimize sum_i c[i,k(i)] + 10(d_0+d_5).

For n_k items in a 39-position endpoint chain there are 39-n_k empty
positions, hence at most 40-n_k separate zero-cost interval-order chains.
"""

import sys
import gzip
import re
from collections import defaultdict, Counter
from fractions import Fraction

import gurobipy as gp
from gurobipy import GRB


def F(x):
    if isinstance(x, Fraction):
        return x
    if isinstance(x, int):
        return Fraction(x)
    return Fraction(str(float(x)))


def fs(x):
    x = F(x)
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"


def open_text(path):
    if path.endswith(".gz"):
        return gzip.open(path, "rt", encoding="utf-8", errors="replace")
    return open(path, "rt", encoding="utf-8", errors="replace")


def parse_solution(path, name_to_idx):
    vals = {}
    header = None

    with open_text(path) as f:
        text = f.read()

    m = re.search(r'objectiveValue\s*=\s*["\']([^"\']+)["\']', text, re.I)
    if m:
        header = Fraction(m.group(1))

    for m in re.finditer(
        r'<variable\b[^>]*\bname\s*=\s*["\']([^"\']+)["\']'
        r'[^>]*\bvalue\s*=\s*["\']([^"\']+)["\']',
        text, re.I
    ):
        name, value = m.group(1), m.group(2)
        if name in name_to_idx:
            vals[name_to_idx[name]] = Fraction(value)

    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or line.startswith("*"):
            continue

        mo = re.match(r"^=obj=\s+(\S+)", line, re.I)
        if mo:
            header = Fraction(mo.group(1))
            continue

        fields = line.split()
        if len(fields) >= 2 and fields[0] in name_to_idx:
            try:
                vals[name_to_idx[fields[0]]] = Fraction(fields[1])
            except Exception:
                pass

    return vals, header


def compact_counter(c, limit=20):
    z = sorted(c.items(), key=lambda p: (-p[1], str(p[0])))
    body = ", ".join(f"{a}:{b}" for a, b in z[:limit])
    if len(z) > limit:
        body += f", ... ({len(z)} distinct)"
    return "{" + body + "}"


def interval_width(selected, interval):
    """
    Width for the order [l_i,u_i] precedes [l_j,u_j] iff u_i <= l_j.

    Positive-length intervals form cliques at half-integral points.
    Equal degenerate intervals [h,h] are mutually comparable, so a clique
    contains at most one such point interval.  A point interval at h can
    join all positive intervals satisfying l < h < u.
    """
    selected = list(selected)
    best = 0
    witness = None

    # Open cells between consecutive integer endpoints.
    for h in range(20):
        t2 = 2 * h + 1
        active = [
            i for i in selected
            if 2 * interval[i][0] < t2 < 2 * interval[i][1]
        ]
        if len(active) > best:
            best = len(active)
            witness = ("half", Fraction(t2, 2), tuple(active))

    # A clique containing one degenerate interval [h,h].
    points = defaultdict(list)
    for i in selected:
        l, u = interval[i]
        if l == u:
            points[l].append(i)

    for h, point_items in points.items():
        positive = [
            i for i in selected
            if interval[i][0] < h < interval[i][1]
        ]
        if point_items and len(positive) + 1 > best:
            best = len(positive) + 1
            witness = ("point", h, tuple(positive + [point_items[0]]))

    # Nonempty sets consisting only of mutually comparable point intervals
    # still have width one.
    if selected and best == 0:
        best = 1
        witness = ("singleton", None, (selected[0],))

    return best, witness


def clique_family(interval):
    """All relevant interval-order antichain inequalities."""
    cliques = set()

    for h in range(20):
        t2 = 2 * h + 1
        q = frozenset(
            i for i, (l, u) in interval.items()
            if 2 * l < t2 < 2 * u
        )
        if q:
            cliques.add(q)

    points = defaultdict(list)
    for i, (l, u) in interval.items():
        if l == u:
            points[l].append(i)

    for h, point_items in points.items():
        positive = {
            i for i, (l, u) in interval.items()
            if l < h < u
        }
        for i in point_items:
            cliques.add(frozenset(positive | {i}))

    # Width must be at least one whenever an item is selected.
    for i in interval:
        cliques.add(frozenset({i}))

    return sorted(cliques, key=lambda q: (len(q), tuple(sorted(q))))


def main():
    if len(sys.argv) != 3:
        print(
            "usage: python endpoint_interval_order.py "
            "instance.mps.gz incumbent.sol.gz",
            file=sys.stderr
        )
        return 2

    model = gp.read(sys.argv[1])
    variables = model.getVars()
    constraints = model.getConstrs()
    nvar = len(variables)

    name_to_idx = {v.VarName: i for i, v in enumerate(variables)}

    rows = []
    incidence = [[] for _ in variables]

    for ri, con in enumerate(constraints):
        expr = model.getRow(con)
        terms = []
        for p in range(expr.size()):
            v = expr.getVar(p)
            j = v.index
            a = F(expr.getCoeff(p))
            terms.append((j, a))
            incidence[j].append(ri)
        rows.append((con.Sense, F(con.RHS), terms))

    # ---------------------------------------------------------------
    # Items and assignments
    # ---------------------------------------------------------------

    items = []
    item_of = {}

    for ri, (sense, rhs, terms) in enumerate(rows):
        if (
            sense == "=" and rhs == 1 and terms
            and all(
                a == 1 and variables[j].VType == GRB.BINARY
                for j, a in terms
            )
        ):
            item = len(items)
            opts = [j for j, _ in terms]
            items.append(opts)
            for j in opts:
                if j in item_of:
                    raise RuntimeError("Repeated assignment variable")
                item_of[j] = item

    assignment = set(item_of)

    mandatory_global = [i for i, opts in enumerate(items) if len(opts) == 78]
    flexible_global = [i for i, opts in enumerate(items) if len(opts) == 54]

    print("\nITEMS")
    print(" total:", len(items))
    print(" endpoint-only:", len(mandatory_global))
    print(" flexible:", len(flexible_global))

    if len(mandatory_global) != 76:
        raise RuntimeError("Expected 76 endpoint-only items")

    # ---------------------------------------------------------------
    # Normalize the six load epigraphs
    # ---------------------------------------------------------------

    objective_vars = [
        i for i, v in enumerate(variables) if F(v.Obj) != 0
    ]
    if len(objective_vars) != 1:
        raise RuntimeError("Expected one objective variable")

    objective_var = objective_vars[0]
    load_rows = list(incidence[objective_var])
    loads = []

    for ri in load_rows:
        sense, rhs, terms = rows[ri]
        coeff = dict(terms)
        ao = coeff[objective_var]

        sign = Fraction(1) if sense == ">" else Fraction(-1)
        A = sign * ao
        if A <= 0:
            raise RuntimeError("Malformed epigraph row")

        c = {}
        for j, a in terms:
            if j == objective_var:
                continue
            z = -sign * a / A
            if z:
                c[j] = z

        loads.append(c)

    if len(loads) != 6:
        raise RuntimeError("Expected six load rows")

    def owners(j):
        return tuple(k for k in range(6) if loads[k].get(j, 0) != 0)

    # ---------------------------------------------------------------
    # Capacity bins
    # ---------------------------------------------------------------

    capacity_rows = []
    bins = []
    bin_of = {}

    for ri, (sense, rhs, terms) in enumerate(rows):
        if terms and all(j in assignment for j, _ in terms):
            # Exclude partition equalities.
            if not (sense == "=" and rhs == 1):
                capacity_rows.append(ri)

    for b, ri in enumerate(capacity_rows):
        opts = [j for j, _ in rows[ri][2]]
        bins.append(opts)
        for j in opts:
            if j in bin_of:
                raise RuntimeError("Assignment occurs in two capacity bins")
            bin_of[j] = b

    bin_owner = {}
    for b, opts in enumerate(bins):
        os = {owners(j) for j in opts}
        if len(os) != 1 or len(next(iter(os))) != 1:
            raise RuntimeError("Inconsistent bin ownership")
        bin_owner[b] = next(iter(os))[0]

    print("\nENDPOINT BINS")
    print(" endpoint 0:", sum(bin_owner[b] == 0 for b in bin_owner))
    print(" endpoint 5:", sum(bin_owner[b] == 5 for b in bin_owner))

    # ---------------------------------------------------------------
    # OR supports
    # ---------------------------------------------------------------

    or_support = {}
    or_rows = {}

    for ri, (sense, rhs, terms) in enumerate(rows):
        if sense != ">" or rhs != 0:
            continue

        positive = [(j, a) for j, a in terms if a > 0]
        negative = [(j, a) for j, a in terms if a < 0]

        if len(positive) != 1 or not negative:
            continue

        q, aq = positive[0]
        if variables[q].VType != GRB.BINARY or q in assignment:
            continue
        if not all(j in assignment and a == -1 for j, a in negative):
            continue
        if aq != len(negative):
            continue

        support = tuple(j for j, _ in negative)
        support_bins = {bin_of[j] for j in support}

        if len(support_bins) != 1:
            raise RuntimeError("OR support crosses capacity bins")

        or_support[q] = support
        or_rows[q] = ri

    print("\nOR STRUCTURE")
    print(" OR variables:", len(or_support))
    print(
        " endpoint-owned OR variables:",
        sum(owners(q) in ((0,), (5,)) for q in or_support)
    )

    # ---------------------------------------------------------------
    # Window selectors
    # ---------------------------------------------------------------

    integer_vars = {
        i for i, v in enumerate(variables)
        if v.VType == GRB.INTEGER
    }

    windows = []

    for ri in range(len(rows) - 1):
        s1, r1, t1 = rows[ri]
        s2, r2, t2 = rows[ri + 1]

        if s1 != "<" or r1 != 20 or s2 != ">" or r2 != 0:
            continue

        ints1 = [(j, a) for j, a in t1 if j in integer_vars]
        ints2 = [(j, a) for j, a in t2 if j in integer_vars]
        oth1 = [(j, a) for j, a in t1 if j not in integer_vars]
        oth2 = [(j, a) for j, a in t2 if j not in integer_vars]

        if len(ints1) != 1 or ints1[0][1] != 1:
            continue
        if len(ints2) != 1 or ints2[0][1] != 1:
            continue
        if len(oth1) > 1 or len(oth2) > 1:
            continue

        if oth1:
            selector1, a1 = oth1[0]
            h1 = 20 - a1
        else:
            selector1 = None
            h1 = Fraction(20)

        if oth2:
            selector2, a2 = oth2[0]
            h2 = -a2
        else:
            selector2 = None
            h2 = Fraction(0)

        if h1 != h2:
            continue

        if selector1 is not None and selector2 is not None:
            if selector1 != selector2:
                continue
            selector = selector1
        elif selector1 is not None:
            selector = selector1
        elif selector2 is not None:
            selector = selector2
        else:
            continue

        if selector not in assignment and selector not in or_support:
            continue

        windows.append(
            (
                selector,
                h1,
                ints1[0][0],
                ints2[0][0],
                ri,
                ri + 1,
            )
        )

    print("\nWINDOWS")
    print(" selector windows:", len(windows))
    print(" OR selectors:", sum(s in or_support for s, *_ in windows))
    print(" singleton selectors:", sum(s in assignment for s, *_ in windows))

    # Assignment option -> all activated h values.
    option_h = defaultdict(list)

    # Also record the unique (left,right) timing pair of every bin.
    bin_window_pair = {}

    for selector, h, left, right, _, _ in windows:
        support = (
            or_support[selector]
            if selector in or_support
            else (selector,)
        )

        bs = {bin_of[j] for j in support}
        if len(bs) != 1:
            raise RuntimeError("Window support crosses bins")
        b = next(iter(bs))

        old = bin_window_pair.get(b)
        if old is not None and old != (left, right):
            raise RuntimeError("A bin has inconsistent timing endpoints")
        bin_window_pair[b] = (left, right)

        for j in support:
            option_h[j].append(h)

    # ---------------------------------------------------------------
    # Difference chain reconstruction
    # ---------------------------------------------------------------

    difference = []
    diff_groups = defaultdict(list)

    for ri, (sense, rhs, terms) in enumerate(rows):
        if rhs != 0 or len(terms) != 3:
            continue

        ints = [(j, a) for j, a in terms if j in integer_vars]
        binary = [
            (j, a) for j, a in terms
            if variables[j].VType == GRB.BINARY and j not in assignment
        ]

        if len(ints) != 2 or len(binary) != 1:
            continue
        if sorted(a for _, a in ints) != [Fraction(-1), Fraction(1)]:
            continue

        z, az = binary[0]
        if abs(az) != 20:
            continue

        key = (frozenset(j for j, _ in ints), z)
        diff_groups[key].append(ri)

    for (uv, z), rr in diff_groups.items():
        if len(rr) == 2:
            difference.append((tuple(uv), z, tuple(rr)))

    chain_edges = defaultdict(list)
    unmatched_diff = []

    for uv, z, rr in difference:
        own = owners(z)
        if len(own) != 1:
            unmatched_diff.append((z, "owner"))
            continue
        k = own[0]

        matches = []
        for b, (left_b, right_b) in bin_window_pair.items():
            if bin_owner[b] != k:
                continue
            for c, (left_c, right_c) in bin_window_pair.items():
                if bin_owner[c] != k or b == c:
                    continue
                if frozenset((right_b, left_c)) == frozenset(uv):
                    matches.append((b, c))

        if len(matches) == 1:
            chain_edges[k].append((matches[0][0], matches[0][1], z))
        else:
            unmatched_diff.append((z, len(matches)))

    print("\nCHAIN RECONSTRUCTION")
    print(" difference variables:", len(difference))
    print(" unmatched chain links:", len(unmatched_diff))

    endpoint_chain_ok = True
    chain_orders = {}

    for k in (0, 5):
        bs = {b for b in bin_owner if bin_owner[b] == k}
        edges = [(b, c) for b, c, z in chain_edges[k]]

        succ = {}
        pred = {}
        for b, c in edges:
            if b in succ or c in pred:
                endpoint_chain_ok = False
            succ[b] = c
            pred[c] = b

        starts = list(bs - set(pred))
        if len(bs) != 39 or len(edges) != 38 or len(starts) != 1:
            endpoint_chain_ok = False
            order = []
        else:
            order = []
            b = starts[0]
            while b not in order:
                order.append(b)
                if b not in succ:
                    break
                b = succ[b]
            if len(order) != 39:
                endpoint_chain_ok = False

        chain_orders[k] = order
        print(
            f" endpoint {k}: bins={len(bs)}, links={len(edges)}, "
            f"path length={len(order)}"
        )

    print(" endpoint chains verified:", endpoint_chain_ok)

    # ---------------------------------------------------------------
    # Additive option costs
    # ---------------------------------------------------------------

    option_cost = {}

    for j in assignment:
        own = owners(j)
        if len(own) != 1:
            raise RuntimeError("Assignment has nonunique load owner")

        k = own[0]
        c = loads[k][j]

        # Each selected assignment forces every OR whose support contains it.
        for q, support in or_support.items():
            if j in support:
                oq = owners(q)
                if oq == (k,):
                    c += loads[k].get(q, Fraction(0))

        option_cost[j] = c

    # Faster incidence version for diagnostics.
    or_membership_count = Counter()
    for q, support in or_support.items():
        for j in support:
            or_membership_count[j] += 1

    print("\nOPTION ACTIVATION")
    print(
        " endpoint option OR-membership histogram:",
        compact_counter(Counter(
            or_membership_count[j]
            for j in assignment
            if owners(j) in ((0,), (5,))
        ))
    )
    print(
        " endpoint option h-count histogram:",
        compact_counter(Counter(
            len(option_h[j])
            for j in assignment
            if owners(j) in ((0,), (5,))
        ))
    )

    missing_h = [
        j for j in assignment
        if owners(j) in ((0,), (5,)) and not option_h[j]
    ]
    print(" endpoint options with no h value:", len(missing_h))

    # ---------------------------------------------------------------
    # Position-invariance for the 76 mandatory items
    # ---------------------------------------------------------------

    reduced_index = {
        global_item: r
        for r, global_item in enumerate(mandatory_global)
    }

    cost = {0: {}, 5: {}}
    interval = {0: {}, 5: {}}

    bad_cost = []
    bad_interval = []
    bad_option_count = []

    for global_item in mandatory_global:
        r = reduced_index[global_item]
        opts = items[global_item]

        for k in (0, 5):
            kopts = [j for j in opts if owners(j) == (k,)]

            if len(kopts) != 39:
                bad_option_count.append((global_item, k, len(kopts)))
                continue

            costs = {option_cost[j] for j in kopts}
            intervals = {
                (min(option_h[j]), max(option_h[j]))
                for j in kopts if option_h[j]
            }

            if len(costs) != 1:
                bad_cost.append(
                    (global_item, k, tuple(sorted(costs)))
                )
            else:
                cost[k][r] = next(iter(costs))

            if len(intervals) != 1:
                bad_interval.append(
                    (global_item, k, tuple(sorted(intervals)))
                )
            else:
                interval[k][r] = next(iter(intervals))

    print("\nPOSITION-INVARIANCE")
    print(" bad endpoint option counts:", len(bad_option_count))
    print(" position-dependent combined costs:", len(bad_cost))
    print(" position-dependent intervals:", len(bad_interval))

    if bad_cost:
        print(" first bad costs:")
        for i, k, vals in bad_cost[:10]:
            print("  item", i, "endpoint", k, [fs(x) for x in vals])

    if bad_interval:
        print(" first bad intervals:")
        for i, k, vals in bad_interval[:10]:
            print(
                "  item", i, "endpoint", k,
                [(fs(a), fs(b)) for a, b in vals]
            )

    reduction_valid = (
        endpoint_chain_ok
        and not missing_h
        and not bad_option_count
        and not bad_cost
        and not bad_interval
        and len(cost[0]) == 76
        and len(cost[5]) == 76
        and len(interval[0]) == 76
        and len(interval[5]) == 76
    )

    print(" reduced interval-order model valid:", reduction_valid)

    if not reduction_valid:
        print("Stopping before reduced optimization.")
        return 0

    print("\nREDUCED DATA SUMMARY")
    print(
        " endpoint-0 cost histogram:",
        compact_counter(Counter(fs(x) for x in cost[0].values()))
    )
    print(
        " endpoint-5 cost histogram:",
        compact_counter(Counter(fs(x) for x in cost[5].values()))
    )
    print(
        " endpoint-0 interval histogram:",
        compact_counter(Counter(
            (fs(a), fs(b)) for a, b in interval[0].values()
        ))
    )
    print(
        " endpoint-5 interval histogram:",
        compact_counter(Counter(
            (fs(a), fs(b)) for a, b in interval[5].values()
        ))
    )
    print(
        " endpoint cost-difference histogram:",
        compact_counter(Counter(
            fs(cost[0][i] - cost[5][i]) for i in range(76)
        ))
    )

    # ---------------------------------------------------------------
    # Public solution in reduced coordinates
    # ---------------------------------------------------------------

    sol, objective_header = parse_solution(sys.argv[2], name_to_idx)
    xval = [sol.get(i, Fraction(0)) for i in range(nvar)]

    public_selected = {0: [], 5: []}
    public_reduced_endpoint = {}

    for global_item in mandatory_global:
        r = reduced_index[global_item]
        chosen = [j for j in items[global_item] if xval[j] == 1]

        if len(chosen) != 1:
            raise RuntimeError(
                f"Public solution does not select one option for item "
                f"{global_item}"
            )

        k = owners(chosen[0])[0]
        if k not in (0, 5):
            raise RuntimeError("Endpoint-only item assigned internally")

        public_selected[k].append(r)
        public_reduced_endpoint[r] = k

    public_additive = sum(
        cost[k][i]
        for k in (0, 5)
        for i in public_selected[k]
    )

    public_width = {}
    public_witness = {}
    public_reset_lb = {}

    for k in (0, 5):
        w, witness = interval_width(public_selected[k], interval[k])
        nk = len(public_selected[k])
        d = max(0, w + nk - 40)

        public_width[k] = w
        public_witness[k] = witness
        public_reset_lb[k] = d

    actual_endpoint_diff = {}
    actual_endpoint_or = {}
    actual_endpoint_base = {}

    diff_vars = {z for _, z, _ in difference}

    for k in (0, 5):
        actual_endpoint_diff[k] = sum(
            loads[k].get(z, 0) * xval[z]
            for z in diff_vars if owners(z) == (k,)
        )
        actual_endpoint_or[k] = sum(
            loads[k].get(q, 0) * xval[q]
            for q in or_support if owners(q) == (k,)
        )
        actual_endpoint_base[k] = sum(
            loads[k].get(j, 0) * xval[j]
            for j in assignment
        )

    print("\nPUBLIC ENDPOINT REDUCTION")
    for k in (0, 5):
        print(
            f" endpoint {k}: n={len(public_selected[k])}, "
            f"width={public_width[k]}, "
            f"minimum resets={public_reset_lb[k]}, "
            f"actual difference cost={fs(actual_endpoint_diff[k])}"
        )
        print(
            f"   original base={fs(actual_endpoint_base[k])}, "
            f"original OR={fs(actual_endpoint_or[k])}"
        )
        print("   width witness:", public_witness[k])

    public_reduced_value = (
        public_additive
        + 10 * (public_reset_lb[0] + public_reset_lb[5])
    )

    public_original_endpoint_value = sum(
        actual_endpoint_base[k]
        + actual_endpoint_or[k]
        + actual_endpoint_diff[k]
        for k in (0, 5)
    )

    print(" public additive endpoint cost:", fs(public_additive))
    print(" public reduced endpoint value:", fs(public_reduced_value))
    print(
        " public original endpoint value:",
        fs(public_original_endpoint_value)
    )
    print(
        " public reduction is exact:",
        public_reduced_value == public_original_endpoint_value
    )

    # ---------------------------------------------------------------
    # Build the 76-item interval-partition model
    # ---------------------------------------------------------------

    cliques = {
        0: clique_family(interval[0]),
        5: clique_family(interval[5]),
    }

    print("\nCLIQUE FAMILIES")
    for k in (0, 5):
        print(
            f" endpoint {k}: clique constraints={len(cliques[k])}, "
            f"size histogram="
            f"{compact_counter(Counter(len(q) for q in cliques[k]))}"
        )

    def build_reduced(binary):
        rm = gp.Model(
            "endpoint_interval_integer"
            if binary else
            "endpoint_interval_LP"
        )
        rm.Params.OutputFlag = 0

        vtype = GRB.BINARY if binary else GRB.CONTINUOUS
        y = {
            i: rm.addVar(lb=0, ub=1, vtype=vtype, name=f"y_{i}")
            for i in range(76)
        }

        W0 = rm.addVar(lb=0, ub=76, vtype=GRB.CONTINUOUS, name="W0")
        W5 = rm.addVar(lb=0, ub=76, vtype=GRB.CONTINUOUS, name="W5")
        D0 = rm.addVar(lb=0, ub=76, vtype=GRB.CONTINUOUS, name="D0")
        D5 = rm.addVar(lb=0, ub=76, vtype=GRB.CONTINUOUS, name="D5")

        n0 = gp.quicksum(y[i] for i in range(76))
        n5 = 76 - n0

        # Both 39-bin endpoints must accommodate their assigned items.
        rm.addConstr(n0 <= 39, name="endpoint0_capacity")
        rm.addConstr(n0 >= 37, name="endpoint5_capacity")

        # Endpoint 0 clique/width constraints.
        for qn, q in enumerate(cliques[0]):
            rm.addConstr(
                gp.quicksum(y[i] for i in q) <= W0,
                name=f"c0_{qn}"
            )

        # Endpoint 5: selected indicator is 1-y_i.
        for qn, q in enumerate(cliques[5]):
            rm.addConstr(
                gp.quicksum(1 - y[i] for i in q) <= W5,
                name=f"c5_{qn}"
            )

        # Available zero-cost segments are 40-n_k.
        rm.addConstr(D0 >= W0 + n0 - 40, name="reset0")
        rm.addConstr(D5 >= W5 + n5 - 40, name="reset5")

        objective = gp.LinExpr()
        for i in range(76):
            objective += float(cost[0][i]) * y[i]
            objective += float(cost[5][i]) * (1 - y[i])

        objective += 10 * D0 + 10 * D5

        rm.setObjective(objective, GRB.MINIMIZE)
        rm.update()

        return rm, y, W0, W5, D0, D5

    # ---------------------------------------------------------------
    # LP relaxation
    # ---------------------------------------------------------------

    lp, ly, lW0, lW5, lD0, lD5 = build_reduced(False)
    lp.optimize()

    print("\nREDUCED LP RELAXATION")
    print(" status:", lp.Status)

    if lp.Status == GRB.OPTIMAL:
        fractional = [
            (i, ly[i].X)
            for i in range(76)
            if 1e-8 < ly[i].X < 1 - 1e-8
        ]
        print(" objective:", f"{lp.ObjVal:.12g}")
        print(" W0, W5:", f"{lW0.X:.12g}", f"{lW5.X:.12g}")
        print(" D0, D5:", f"{lD0.X:.12g}", f"{lD5.X:.12g}")
        print(" fractional y variables:", len(fractional))
        if fractional:
            print(
                " first fractional values:",
                [(i, round(x, 8)) for i, x in fractional[:20]]
            )

        nonzero_duals = [
            (c.ConstrName, c.Pi, c.Slack)
            for c in lp.getConstrs()
            if abs(c.Pi) > 1e-8
        ]
        print(" nonzero dual multipliers:", len(nonzero_duals))
        print(" first nonzero duals:")
        for name, pi, slack in nonzero_duals[:30]:
            print(
                "  ",
                name,
                "pi=" + f"{pi:.12g}",
                "slack=" + f"{slack:.12g}"
            )

    # ---------------------------------------------------------------
    # Exact reduced oracle
    # ---------------------------------------------------------------

    mip, my, mW0, mW5, mD0, mD5 = build_reduced(True)
    mip.optimize()

    print("\nEXACT REDUCED ORACLE")
    print(" status:", mip.Status)

    if mip.Status == GRB.OPTIMAL:
        chosen0 = [i for i in range(76) if my[i].X > 0.5]
        chosen5 = [i for i in range(76) if my[i].X <= 0.5]

        w0, witness0 = interval_width(chosen0, interval[0])
        w5, witness5 = interval_width(chosen5, interval[5])

        n0 = len(chosen0)
        n5 = len(chosen5)
        d0 = max(0, w0 + n0 - 40)
        d5 = max(0, w5 + n5 - 40)

        additive0 = sum(cost[0][i] for i in chosen0)
        additive5 = sum(cost[5][i] for i in chosen5)
        exact_value = additive0 + additive5 + 10 * (d0 + d5)

        print(" solver objective:", f"{mip.ObjVal:.12g}")
        print(" exact recomputed objective:", fs(exact_value))
        print(" endpoint counts:", n0, n5)
        print(" widths:", w0, w5)
        print(" minimum resets:", d0, d5)
        print(" additive costs:", fs(additive0), fs(additive5))
        print(" endpoint-0 reduced item indices:", chosen0)
        print(" endpoint-5 reduced item indices:", chosen5)
        print(" endpoint-0 width witness:", witness0)
        print(" endpoint-5 width witness:", witness5)

        print("\nCERTIFICATE CONSEQUENCE")
        print(" endpoint lower bound:", fs(exact_value))

        if exact_value >= 4854:
            print(
                " Since both endpoint loads are even, objective < 2428 "
                "would imply endpoint sum <= 4852."
            )
            print(
                " The reduced endpoint bound excludes objective < 2428."
            )
            print(
                " Together with the exactly feasible public solution, "
                "this establishes optimum 2428, subject only to certifying "
                "the reduced oracle bound independently."
            )
        else:
            print(
                " Endpoint reduction alone does not exclude endpoint "
                "sum <= 4852."
            )

        if exact_value == 4856:
            print(
                " The endpoint reduction exactly matches the public "
                "endpoint sum 4856."
            )

        if lp.Status == GRB.OPTIMAL:
            if lp.ObjVal >= 4854 - 1e-7:
                print(
                    " The reduced LP relaxation itself closes the proof; "
                    "its dual can be rationalized into a short independently "
                    "checkable certificate."
                )
            else:
                print(
                    " Reduced LP gap to 4854:",
                    f"{4854 - lp.ObjVal:.12g}"
                )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
