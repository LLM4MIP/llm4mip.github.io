#!/usr/bin/env python3
"""
Structural and certificate analyzer for fhnw-binschedule2.

No optimize(), presolve(), relax(), or parameter tuning is performed.
Gurobi is used only as an MPS reader.

Main test:
  1. Recover all binary set-partition equations.
  2. Normalize the six objective epigraph rows as
         O >= beta_k + sum_j c[k,j] x_j.
  3. Sum those six inequalities.
  4. Test whether the summed coefficient is constant across every option
     of each partitioned item.
  5. Bound all remaining variables using only their declared bounds.
  6. Validate the public solution directly against every original row.

If the resulting lower bound and feasible incumbent coincide, this is an
instance-specific optimality certificate based only on original rows,
partition equations, and variable bounds.
"""

import sys
import os
import re
import gzip
import hashlib
import math
from collections import Counter, defaultdict
from fractions import Fraction

import gurobipy as gp
from gurobipy import GRB


def F(x):
    """Exact decimal-to-rational conversion of Gurobi/MPS numbers."""
    if isinstance(x, Fraction):
        return x
    if isinstance(x, int):
        return Fraction(x)
    return Fraction(str(float(x)))


def fs(q):
    q = F(q)
    if q.denominator == 1:
        return str(q.numerator)
    return f"{q.numerator}/{q.denominator}"


def ceil_fraction(q):
    q = F(q)
    return -((-q.numerator) // q.denominator)


def open_text(path):
    if path.endswith(".gz"):
        return gzip.open(path, "rt", encoding="utf-8", errors="replace")
    return open(path, "rt", encoding="utf-8", errors="replace")


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(1 << 20)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def compact_counter(cnt, limit=16):
    if not cnt:
        return "{}"
    items = sorted(cnt.items(), key=lambda z: (-z[1], str(z[0])))
    shown = items[:limit]
    body = ", ".join(f"{k}:{v}" for k, v in shown)
    if len(items) > limit:
        body += f", ... ({len(items)} distinct)"
    return "{" + body + "}"


def integer_runs(indices):
    a = sorted(set(indices))
    if not a:
        return []
    out = []
    start = prev = a[0]
    for x in a[1:]:
        if x == prev + 1:
            prev = x
        else:
            out.append((start, prev))
            start = prev = x
    out.append((start, prev))
    return out


def print_runs(label, indices, vars_):
    runs = integer_runs(indices)
    text = []
    for a, b in runs:
        if a == b:
            text.append(f"{vars_[a].VarName}[{a}]")
        else:
            text.append(
                f"{vars_[a].VarName}[{a}]..{vars_[b].VarName}[{b}]"
                f" ({b-a+1})"
            )
    print(label, "; ".join(text) if text else "(none)")


def parse_solution(path, name_to_idx):
    """
    Supports standard MIPLIB sparse text solutions and XML-style solutions.
    Unlisted variables are interpreted as zero.
    """
    vals = {}
    objective_header = None

    with open_text(path) as f:
        text = f.read()

    # XML objective header, if present.
    m = re.search(
        r'objectiveValue\s*=\s*["\']([^"\']+)["\']',
        text, flags=re.I
    )
    if m:
        objective_header = Fraction(m.group(1))

    # XML variables.
    for m in re.finditer(
        r'<variable\b[^>]*\bname\s*=\s*["\']([^"\']+)["\']'
        r'[^>]*\bvalue\s*=\s*["\']([^"\']+)["\']',
        text, flags=re.I
    ):
        name, value = m.group(1), m.group(2)
        if name in name_to_idx:
            vals[name_to_idx[name]] = Fraction(value)

    # Plain sparse solution.
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or line.startswith("*"):
            continue

        mo = re.match(r"^=obj=\s+(\S+)", line, flags=re.I)
        if mo:
            objective_header = Fraction(mo.group(1))
            continue

        fields = line.split()
        if len(fields) >= 2 and fields[0] in name_to_idx:
            try:
                vals[name_to_idx[fields[0]]] = Fraction(fields[1])
            except Exception:
                pass

    return vals, objective_header


def main():
    if len(sys.argv) != 3:
        print(
            "usage: python analyze_fhnw_binschedule2.py "
            "instance.mps.gz incumbent.sol.gz",
            file=sys.stderr,
        )
        return 2

    mps_path, sol_path = sys.argv[1], sys.argv[2]

    print("FILES")
    print(" mps:", os.path.basename(mps_path),
          "sha256=" + file_sha256(mps_path))
    print(" sol:", os.path.basename(sol_path),
          "sha256=" + file_sha256(sol_path))

    # Read only. Do not call optimize or presolve.
    m = gp.read(mps_path)
    vars_ = m.getVars()
    cons = m.getConstrs()
    n = len(vars_)

    name_to_idx = {v.VarName: i for i, v in enumerate(vars_)}

    # Cache the original matrix exactly as exposed by the MPS reader.
    rows = []
    incidence = [[] for _ in vars_]
    for ri, con in enumerate(cons):
        expr = m.getRow(con)
        terms = []
        for p in range(expr.size()):
            v = expr.getVar(p)
            j = v.index
            a = F(expr.getCoeff(p))
            terms.append((j, a))
            incidence[j].append(ri)
        rows.append((con.Sense, F(con.RHS), terms))

    print("\nVARIABLE BLOCKS")
    type_runs = []
    start = 0
    while start < n:
        typ = vars_[start].VType
        end = start
        while end + 1 < n and vars_[end + 1].VType == typ:
            end += 1
        type_runs.append((start, end, typ))
        start = end + 1

    for a, b, typ in type_runs:
        print(
            f" {vars_[a].VarName}[{a}]..{vars_[b].VarName}[{b}]: "
            f"type={typ}, count={b-a+1}"
        )

    for typ in sorted(set(v.VType for v in vars_)):
        hist = Counter()
        for v in vars_:
            if v.VType != typ:
                continue
            lb = "-inf" if v.LB <= -GRB.INFINITY / 2 else fs(F(v.LB))
            ub = "inf" if v.UB >= GRB.INFINITY / 2 else fs(F(v.UB))
            hist[(lb, ub)] += 1
        print(f" bounds type {typ}:", compact_counter(hist))

    # Recover pure binary partition equations.
    partition_rows = []
    groups = []
    part_of = {}
    duplicate_membership = []

    for ri, (sense, rhs, terms) in enumerate(rows):
        if sense != "=" or rhs != 1 or not terms:
            continue
        if all(
            a == 1 and vars_[j].VType == GRB.BINARY
            for j, a in terms
        ):
            partition_rows.append(ri)
            gid = len(groups)
            group = [j for j, _ in terms]
            groups.append(group)
            for j in group:
                if j in part_of:
                    duplicate_membership.append((j, part_of[j], gid))
                else:
                    part_of[j] = gid

    group_size = {gid: len(g) for gid, g in enumerate(groups)}
    part_size_of_var = {
        j: group_size[gid] for j, gid in part_of.items()
    }

    print("\nSET PARTITIONS")
    print(" rows:", len(partition_rows))
    print(" size histogram:", compact_counter(Counter(map(len, groups))))
    print(" covered variables:", len(part_of))
    print(" duplicate memberships:", len(duplicate_membership))
    print_runs(" covered-index runs:", part_of.keys(), vars_)

    # Locate the sole objective variable.
    obj_vars = [
        i for i, v in enumerate(vars_)
        if F(v.Obj) != 0
    ]
    if len(obj_vars) != 1:
        raise RuntimeError(
            f"Expected one objective variable, found {len(obj_vars)}"
        )
    oi = obj_vars[0]
    O = vars_[oi]

    # Find rows containing O and normalize lower epigraph inequalities.
    epi_rows = list(incidence[oi])
    epigraphs = []

    for ri in epi_rows:
        sense, rhs, terms = rows[ri]
        coeff = dict(terms)
        ao = coeff[oi]

        # Convert original row to s*(lhs-rhs) >= 0.
        if sense == ">":
            s = Fraction(1)
        elif sense == "<":
            s = Fraction(-1)
        else:
            raise RuntimeError(
                f"Objective variable appears in equality {cons[ri].ConstrName}"
            )

        A = s * ao
        if A <= 0:
            raise RuntimeError(
                f"Row {cons[ri].ConstrName} is not a lower epigraph row "
                f"after normalization: sense={sense}, objective coeff={fs(ao)}"
            )

        # A*O + s*sum(other a_j*x_j) - s*rhs >= 0
        # O >= s*rhs/A - sum(s*a_j/A)*x_j.
        beta = s * rhs / A
        c = {}
        for j, a in terms:
            if j == oi:
                continue
            value = -s * a / A
            if value:
                c[j] = value
        epigraphs.append((ri, beta, c, A))

    # Detect OR/linking rows M*q - sum x >= 0.
    or_defs = defaultdict(list)
    or_support = {}

    for ri, (sense, rhs, terms) in enumerate(rows):
        if sense != ">" or rhs != 0:
            continue

        positives = [(j, a) for j, a in terms if a > 0]
        negatives = [(j, a) for j, a in terms if a < 0]

        if len(positives) != 1 or not negatives:
            continue

        q, aq = positives[0]
        if q in part_of or vars_[q].VType != GRB.BINARY:
            continue
        if not all(j in part_of and a == -1 for j, a in negatives):
            continue
        if aq != len(negatives):
            continue

        support = tuple(j for j, _ in negatives)
        or_defs[q].append(ri)
        or_support[q] = support

    int_indices = {
        i for i, v in enumerate(vars_) if v.VType == GRB.INTEGER
    }
    timed_or = set()
    for q in or_defs:
        for ri in incidence[q]:
            if any(j in int_indices for j, _ in rows[ri][2]):
                timed_or.add(q)
                break

    untimed_or = set(or_defs) - timed_or

    print("\nDERIVED OR/BIN STRUCTURE")
    print(" OR-definition rows:", sum(len(x) for x in or_defs.values()))
    print(" OR variables:", len(or_defs))
    print_runs(" timed OR variables:", timed_or, vars_)
    print_runs(" untimed OR variables:", untimed_or, vars_)

    def support_profile(q):
        s = or_support[q]
        return (
            len(s),
            tuple(sorted(Counter(part_size_of_var[j] for j in s).items())),
            len(set(part_of[j] for j in s)),
        )

    print(
        " timed support profiles:",
        compact_counter(Counter(support_profile(q) for q in timed_or), 12),
    )
    print(
        " untimed support profiles:",
        compact_counter(Counter(support_profile(q) for q in untimed_or), 12),
    )

    # How often does each assignment option occur in each OR class?
    timed_occ = Counter()
    untimed_occ = Counter()
    for q in timed_or:
        timed_occ.update(or_support[q])
    for q in untimed_or:
        untimed_occ.update(or_support[q])

    for size in sorted(set(group_size.values())):
        members = [j for j in part_of if part_size_of_var[j] == size]
        print(
            f" partition-size {size}: timed-OR occurrence histogram",
            compact_counter(Counter(timed_occ[j] for j in members)),
        )
        print(
            f" partition-size {size}: untimed-OR occurrence histogram",
            compact_counter(Counter(untimed_occ[j] for j in members)),
        )

    # Detect pairs of timing variables connected through a +/-20 binary.
    pair_rows = defaultdict(list)
    for ri, (sense, rhs, terms) in enumerate(rows):
        if rhs != 0 or len(terms) != 3:
            continue
        ints = [(j, a) for j, a in terms if vars_[j].VType == GRB.INTEGER]
        bins = [
            (j, a) for j, a in terms
            if vars_[j].VType == GRB.BINARY and j not in part_of
        ]
        if len(ints) != 2 or len(bins) != 1:
            continue
        if sorted(a for _, a in ints) != [Fraction(-1), Fraction(1)]:
            continue
        q, aq = bins[0]
        if abs(aq) != 20:
            continue
        key = (tuple(sorted(j for j, _ in ints)), q)
        pair_rows[key].append((ri, sense, aq))

    complete_pairs = {
        key: rr for key, rr in pair_rows.items()
        if len(rr) == 2
    }

    offset_hist = Counter()
    residue_hist = Counter()
    switch_indices = set()
    for ((u, v), q), rr in complete_pairs.items():
        offset_hist[v - u] += 1
        residue_hist[(u % 6, v % 6)] += 1
        switch_indices.add(q)

    print("\nTIMING-DIFFERENCE INDICATORS")
    print(" paired integer-coordinate indicators:", len(complete_pairs))
    print_runs(" indicator variables:", switch_indices, vars_)
    print(" integer index-offset histogram:", compact_counter(offset_hist))
    print(" modulo-6 endpoint histogram:", compact_counter(residue_hist))

    def role(j):
        if j == oi:
            return "OBJ"
        if j in part_of:
            return f"P{part_size_of_var[j]}"
        if vars_[j].VType == GRB.INTEGER:
            return "TIME-I"
        if j in timed_or:
            return "TIME-OR"
        if j in untimed_or:
            return "BIN-OR"
        if j in switch_indices:
            return "DIFF-B"
        if vars_[j].VType == GRB.BINARY:
            return "OTHER-B"
        return vars_[j].VType

    # Parse and, if needed, infer the explicit objective variable from =obj=.
    sol, obj_header = parse_solution(sol_path, name_to_idx)
    inferred_obj = False

    if oi not in sol and obj_header is not None:
        obj_coeff = F(O.Obj)
        obj_const = F(m.ObjCon)
        if obj_coeff != 0:
            sol[oi] = (obj_header - obj_const) / obj_coeff
            inferred_obj = True

    xval = [sol.get(i, Fraction(0)) for i in range(n)]

    print("\nPUBLIC SOLUTION")
    print(" explicitly listed variables:", len(sol))
    print(" objective header:",
          "(absent)" if obj_header is None else fs(obj_header))
    print(" objective variable:", O.VarName,
          fs(xval[oi]),
          "(inferred from header)" if inferred_obj else "")

    # Validate bounds, integrality and every original constraint.
    bound_bad = []
    integer_bad = []

    for i, v in enumerate(vars_):
        z = xval[i]
        if v.LB > -GRB.INFINITY / 2 and z < F(v.LB):
            bound_bad.append((v.VarName, z, "LB", F(v.LB)))
        if v.UB < GRB.INFINITY / 2 and z > F(v.UB):
            bound_bad.append((v.VarName, z, "UB", F(v.UB)))
        if v.VType in (GRB.BINARY, GRB.INTEGER) and z.denominator != 1:
            integer_bad.append((v.VarName, z))

    row_bad = []
    max_violation = Fraction(0)
    for ri, (sense, rhs, terms) in enumerate(rows):
        lhs = sum((a * xval[j] for j, a in terms), Fraction(0))
        if sense == "=":
            viol = abs(lhs - rhs)
        elif sense == "<":
            viol = max(Fraction(0), lhs - rhs)
        else:
            viol = max(Fraction(0), rhs - lhs)
        if viol:
            row_bad.append((ri, cons[ri].ConstrName, lhs, sense, rhs, viol))
            max_violation = max(max_violation, viol)

    model_obj = F(m.ObjCon) + sum(
        (F(v.Obj) * xval[i] for i, v in enumerate(vars_)),
        Fraction(0),
    )

    print(" model objective:", fs(model_obj))
    print(" bound violations:", len(bound_bad))
    print(" nonintegral discrete variables:", len(integer_bad))
    print(" violated rows:", len(row_bad),
          "maximum exact violation:", fs(max_violation))

    if bound_bad:
        print(" first bound violations:",
              [(a, fs(b), c, fs(d)) for a, b, c, d in bound_bad[:8]])
    if integer_bad:
        print(" first integrality violations:",
              [(a, fs(b)) for a, b in integer_bad[:8]])
    if row_bad:
        print(" first row violations:")
        for ri, name, lhs, sense, rhs, viol in row_bad[:8]:
            print("  ", name, fs(lhs), sense, fs(rhs), "viol", fs(viol))

    print("\nOBJECTIVE EPIGRAPH")
    print(" objective-row count:", len(epigraphs))

    load_values = []
    for k, (ri, beta, c, A) in enumerate(epigraphs):
        load = beta + sum(
            (a * xval[j] for j, a in c.items()), Fraction(0)
        )
        load_values.append(load)

        role_counts = Counter(role(j) for j in c)
        coeff_hist = Counter(fs(a) for a in c.values())

        print(
            f" {k}: row={cons[ri].ConstrName}, "
            f"normalized-objective-coeff={fs(A)}, beta={fs(beta)}, "
            f"degree_without_O={len(c)}, incumbent_load={fs(load)}"
        )
        print("    roles:", compact_counter(role_counts))
        print("    coefficient histogram:", compact_counter(coeff_hist, 12))

    print(" incumbent load vector:", [fs(x) for x in load_values])
    if load_values:
        print(" incumbent maximum load:", fs(max(load_values)))
        print(" incumbent load sum:", fs(sum(load_values, Fraction(0))))

    # Sum all epigraph inequalities with unit multipliers.
    K = len(epigraphs)
    summed_beta = sum((beta for _, beta, _, _ in epigraphs), Fraction(0))
    summed_coeff = defaultdict(Fraction)
    for _, _, c, _ in epigraphs:
        for j, a in c.items():
            summed_coeff[j] += a

    print("\nUNIFORM-SUM CERTIFICATE")
    print(
        f" Summed inequality: {K}*{O.VarName} >= "
        f"{fs(summed_beta)} + sum_j d_j*x_j"
    )

    invariant_groups = 0
    noninvariant = []
    group_constant_hist = Counter()
    partition_min_sum = Fraction(0)

    for gid, group in enumerate(groups):
        vals = [summed_coeff[j] for j in group]
        lo, hi = min(vals), max(vals)
        partition_min_sum += lo
        if lo == hi:
            invariant_groups += 1
            group_constant_hist[fs(lo)] += 1
        else:
            noninvariant.append(
                (
                    gid,
                    len(group),
                    lo,
                    hi,
                    vars_[group[vals.index(lo)]].VarName,
                    vars_[group[vals.index(hi)]].VarName,
                )
            )

    print(" invariant partition groups:",
          invariant_groups, "/", len(groups))
    print(" invariant group-constant histogram:",
          compact_counter(group_constant_hist, 24))
    print(" sum of partition-wise minima:", fs(partition_min_sum))

    if noninvariant:
        print(" first noninvariant groups:")
        for gid, sz, lo, hi, vlo, vhi in noninvariant[:12]:
            print(
                f"  group={gid}, size={sz}, min={fs(lo)} at {vlo}, "
                f"max={fs(hi)} at {vhi}"
            )

    # Lower-bound nonpartition variables independently by declared bounds.
    nonpart_bound_sum = Fraction(0)
    unfavorable_infinite = []
    nonzero_nonpart = []
    nonpart_coeff_hist = Counter()

    for j in range(n):
        if j == oi or j in part_of:
            continue
        d = summed_coeff[j]
        if not d:
            continue

        v = vars_[j]
        nonzero_nonpart.append(j)
        nonpart_coeff_hist[(role(j), fs(d))] += 1

        if d > 0:
            if v.LB <= -GRB.INFINITY / 2:
                unfavorable_infinite.append((j, d, "LB"))
            else:
                nonpart_bound_sum += d * F(v.LB)
        else:
            if v.UB >= GRB.INFINITY / 2:
                unfavorable_infinite.append((j, d, "UB"))
            else:
                nonpart_bound_sum += d * F(v.UB)

    print(" nonzero summed coefficients outside partitions:",
          len(nonzero_nonpart))
    print(" nonpartition coefficient histogram:",
          compact_counter(nonpart_coeff_hist, 24))
    print(" nonpartition bound contribution:", fs(nonpart_bound_sum))
    print(" unfavorable infinite bounds:", len(unfavorable_infinite))

    certificate_valid = not unfavorable_infinite and K > 0
    if certificate_valid:
        total_rhs_lb = (
            summed_beta + partition_min_sum + nonpart_bound_sum
        )
        rational_lb = total_rhs_lb / K

        # Test whether every epigraph expression is integral on integral
        # feasible variables. Then max_k load_k is integer and the rational
        # lower bound may be rounded upward.
        integral_loads = True
        for _, beta, c, _ in epigraphs:
            if beta.denominator != 1:
                integral_loads = False
            for j, a in c.items():
                if a.denominator != 1:
                    integral_loads = False
                if vars_[j].VType not in (GRB.BINARY, GRB.INTEGER):
                    integral_loads = False

        rounded_lb = (
            Fraction(ceil_fraction(rational_lb))
            if integral_loads else rational_lb
        )

        print(" summed RHS lower bound:", fs(total_rhs_lb))
        print(f" raw objective lower bound ({fs(total_rhs_lb)}/{K}):",
              fs(rational_lb))
        print(" all epigraph loads integral on discrete assignments:",
              integral_loads)
        print(" certified objective lower bound:", fs(rounded_lb))
    else:
        rounded_lb = None
        print(" certificate unavailable because of an unfavorable "
              "unbounded nonpartition variable.")

    feasible = (
        not bound_bad
        and not integer_bad
        and not row_bad
    )

    print("\nVERDICT")
    if (
        feasible
        and rounded_lb is not None
        and model_obj == rounded_lb
    ):
        print(" PROVED: exact optimum =", fs(model_obj))
        print(
            " Certificate uses the original objective epigraph rows, "
            "the recovered set-partition equations, declared variable "
            "bounds, and the independently checked public feasible solution."
        )
    else:
        print(" No equality proof from this certificate test.")
        print(" public solution feasible:", feasible)
        print(" public objective:", fs(model_obj))
        print(
            " certificate lower bound:",
            "(none)" if rounded_lb is None else fs(rounded_lb)
        )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
