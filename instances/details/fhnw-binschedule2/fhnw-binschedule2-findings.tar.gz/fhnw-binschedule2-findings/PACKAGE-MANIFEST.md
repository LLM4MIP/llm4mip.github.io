# Package manifest: fhnw-binschedule2

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 8
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/structure.json`
- `logs/verify-fhnw-binschedule2.log`
- `scripts/analyze_fhnw_binschedule2.py`
- `scripts/endpoint_certificate.py`
- `scripts/endpoint_interval_order.py`
- `scripts/verify_fhnw_binschedule2.py`
- `solutions/fhnw-binschedule2-public.sol.gz`

## Excluded files

- `input/fhnw-binschedule2.mps.gz (611094 bytes; raw benchmark input; sha256 f3f816c31a5afcb288bd0aa84f9cce205d36890a5e46a6f2175c2fa35c8dac5f)`
