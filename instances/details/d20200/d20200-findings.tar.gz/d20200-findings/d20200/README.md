# `d20200`

## Result

The verified objective is **12237**. The best historical solver lower bound is
**12232**; the independently checked rational/Lagrangian lower bound is only
**12230**. Global optimality remains open.

The problem has 200 multiple-choice blocks and 1,302 coupled knapsack rows.
Custom whole-item branching uses exact reduced-cost filtering, with Gurobi
only as a continuous LP oracle. The final two-hour tree targeting `objective ≤12232`
is **incomplete**: 172,164 nodes, 122,299 checked exact leaves, 33 pending subtrees.
It cannot improve the lower bound or prove the 12237 witness optimal.

The final remote replay passed. At this publication snapshot the archive and
source/input hashes have passed locally; the local full-tree replay is still
running. No local completion is claimed. The full 206 MiB compressed partial
tree remains outside Git; see the [archive index](../../studies/ten-instance-2026-09-06/external-archives.json).

- [Latest report](../../docs/ten-instance-results-2026-09-06.zh.md#d20200)
- [Compact final evidence and frozen code](../../studies/ten-instance-2026-09-06/item-priority/runs/20260905-priority-d20200/)
- [Exact seed bound and initial structure-specific experiments](../../studies/ten-instance-2026-09-06/d20200/experiments/)
- [MIPLIB metadata](https://miplib.zib.de/instance_details_d20200.html)
- Input SHA-256: `478820f6ccbbcea7c0b5337f6eab3645714d80beff78b6ceeccafd4dfe4f5637`
