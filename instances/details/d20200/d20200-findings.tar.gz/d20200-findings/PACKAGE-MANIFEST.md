# Package manifest: d20200

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 3
Excluded source files: 1

## Included files

- `README.md`
- `solutions/official-best.sol.gz`
- `solutions/official-best.validation.json`

## Excluded files

- `input/d20200.mps.gz (651583 bytes; raw benchmark input; sha256 478820f6ccbbcea7c0b5337f6eab3645714d80beff78b6ceeccafd4dfe4f5637)`
