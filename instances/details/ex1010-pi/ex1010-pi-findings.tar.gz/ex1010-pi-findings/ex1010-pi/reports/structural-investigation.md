# ex1010-pi: exact set-cover audit and proof-route investigation

Initial date: 2026-09-04; proof-route update: 2026-09-07
Disposition: **still open; feasible value 233 is exact, but neither the full
proof logger nor the incumbent-private-row core produced lower bound 233 or an
independently checkable optimality proof.**

## 1. Exact interpretation of the MPS

`audit_pb_instances.py` parses the supplied MPS with `Decimal` arithmetic and rejects unsupported or ambiguous MPS features.  For SHA-256
`05e2a67ffff4e28912ce90ef60b9dd855257c1e36fca2a8b87981983d9edbdf8`, it verifies exactly

\[
  \min \sum_{j=1}^{25200} x_j,
  \qquad
  \sum_{j\in C_i}x_j\geq 1\quad(i=1,\ldots,1468),
  \qquad x_j\in\{0,1\}.
\]

There are 102,114 matrix nonzeros. Every matrix coefficient, right-hand side,
and objective coefficient is exactly one. There are no ranges, no nonbinary
variables, and no duplicate rows. Thus this is precisely unweighted minimum
set cover, or equivalently weighted partial MaxSAT with positive hard clauses
and unit soft clauses `not x_j`.

## 2. Incumbent 233: proved feasible, not proved optimal

The supplied solution has SHA-256
`e28e8d79d484418ea0ef821151855f13633907ed4e4b466ac6b71da1e923fdc6`.
Exact evaluation finds:

- 233 variables equal to one and all other variables zero;
- objective exactly 233, with no bound or integrality violation;
- all 1,468 cover rows satisfied, with minimum slack zero;
- row activities: 1,199 rows at 1, 232 at 2, 34 at 3, two at 4, and one at 5.

Therefore 233 is a rigorous upper bound. It is not, by itself, evidence that
233 is optimal.

## 3. Exact preprocessing to a fixed point

`preprocess_ex1010.py` applies only the following unit-cost set-cover rules.

1. Equal column supports are interchangeable, so retain one representative.
2. If `support(a)` is a strict subset of `support(b)`, replace `a` by `b` at
   the same cost and delete `a`.
3. If retained row support `R_p` is a subset of `R_q`, satisfying row `p`
   implies row `q`, so delete `q`.
4. Repeat after projection onto the retained rows and check singleton rows,
   duplicate/subsumed rows, and connected components.

The exact counts are:

| stage | columns | rows | nonzeros / event |
|---|---:|---:|---|
| original | 25,200 | 1,468 | 102,114 |
| merge identical supports | 21,736 support classes | 1,468 | 3,464 columns merged |
| first strict column dominance | 11,584 | 1,468 | 10,152 support classes removed |
| row subsumption | 11,584 | 1,466 | `c471` implied by `c470`; `c1183` implied by `c1181` |
| second strict column dominance | 11,568 | 1,466 | 16 additional columns removed |
| fixed point | **11,568** | **1,466** | **63,965** |

At the fixed point there are no duplicate columns, further strict column
dominances, duplicate rows, strict row subsumptions, or singleton rows. The
residual incidence graph is one connected component (1,466 rows and 11,568
columns), so component decomposition does not help. Retained column degrees
range from 2 to 17; retained row degrees range from 5 to 120.

The complete original-to-reduced map is saved as a TSV. Mapping the official
cover gives 233 *distinct* retained columns, and the chosen retained
representatives cover all 1,468 original rows as well as all 1,466 retained
rows. Conversely, each retained column is an original column. These two maps,
together with the dominance/subsumption arguments above, establish equality
of the original and reduced optima. An independently written reducer
(`reduce_ex1010.py`) reached the same fixed-point dimensions and nonzero count.

This is an exact program audit, not a VeriPB certificate for the preprocessing
steps. A fully proof-carrying workflow should either encode the original
25,200-variable decision instance or log these reductions in VeriPB.

## 4. Proof-oriented encodings

The artifact directory contains:

- `ex1010-pi-reduced.opb`: reduced optimization OPB;
- `ex1010-pi-reduced-lb233.opb`: the 1,466 cover constraints plus
  `sum x <= 232`; **UNSAT is exactly the missing lower-bound-233 obligation**;
- `ex1010-pi-reduced.wcnf`: 1,466 positive hard clauses and 11,568 unit soft
  clauses, where MaxSAT cost equals the number of selected columns;
- reduced binary and continuous LPs, the mapped 233 start, and both mapping
  tables.

No proof-producing PB/MaxSAT chain is installed locally. Gurobi 13.0.2 does
not export a portable integer optimality proof, and installed `pycosat` has no
PB/cardinality proof logging. RoundingSat, Exact, VeriPB, and the standard
MaxSAT proof solvers/checkers were absent. Consequently no local command could
turn an UNSAT answer into a checkable certificate in this investigation.

The concrete next closure attempt is a one-thread, 600-second refutation of
the `<=232` decision OPB with a proof-logging RoundingSat/Exact/HitPBO build,
followed by independent VeriPB checking. Acceptance must require both solver
UNSAT and verifier success; a timeout or an unverified UNSAT string is not a
certificate. For the strongest chain of custody, first emit the cutoff against
the original 25,200-variable OPB or add VeriPB-logged preprocessing.

## 5. Bounded solver evidence

The continuous relaxation of the exact reduced LP was solved with Gurobi
13.0.2, one thread, in 1.25 seconds: objective **220.6700870**. This leaves an
integer gap of 12.329913 to the incumbent.

A single permitted long run used the exact independently generated kernel,
the mapped 233 start, two threads, and 600 seconds:

```text
Threads=2 TimeLimit=600 Heuristics=0.02 MIPFocus=3 Cuts=2 Presolve=2
```

It retained incumbent 233, explored 3,339 nodes and 2,570,376 simplex
iterations, and ended with raw tree bound 223.28630. Because the objective is
integral, Gurobi reported best bound **224** and a 3.8627% gap. This is useful
numerical/search evidence, but the log is not an independently checkable PB
optimality certificate. In particular, values 225 through 232 remain open.

## 6. Proof-logging and incumbent-private-row investigation

The missing `sum x <= 232` refutation was run with the official RoundingSat
`pb24-log` source at commit `01be2c2`. Euler4 provides GCC 9 and Boost 1.71;
the proof branch uses two newer C++ library conveniences, so the archived patch
replaces `stringstream::view()` with `str()` and `std::ranges::sort` with
iterator-based `std::sort`. This changes only source compatibility, not solver
reasoning. A tiny contradictory OPB first produced a complete VeriPB 2.0 proof,
confirming that logging was active.

The reduced 11,568-variable decision file was normalized to the PB24 header
format and has SHA-256
`ba85fb1a2b6954139190693133c935f3515245200163393489e382e11c86740f`.
The 600-CPU-second proof run performed 97,308 conflicts, 35,369,230 decisions,
and 299,394,555 propagations. It returned `TIMELIMIT`, not `UNSAT`. The partial
6.6 GiB log correctly terminates with `conclusion NONE`; it remains at
`/data1/wyc/miplib-experiments/ex1010-pi/ex1010-lb233-rs-600s.pbp` on Euler4
and is intentionally excluded from Git. The compact transcript is archived as
`logs/roundingsat-lb233-600s.log`.

The 233 incumbent has 1,199 rows covered exactly once. Every incumbent column
owns between two and eleven of these private rows. If incumbent column `s` is
omitted, every row in its private bundle must be covered by newly added
columns. With binary `z_s` for omitted incumbent columns and `y_j` for added
outside columns, the private-core decision system is

```text
sum(j covers r) y_j >= z_s       for every private row r owned by s
sum(s) z_s - sum(j) y_j >= 1     positive-gain exchange
```

It contains 233 omit variables, 24,394 outside-column variables, and 1,200
constraints. UNSAT would by itself prove that no cover can improve 233. A
30-second one-thread search found no positive-gain exchange; its best feasible
gain was zero while its bound was 14. RoundingSat then performed 22,832
conflicts in 120 seconds and also returned `TIMELIMIT`. Therefore the private
core is a concrete, smaller proof target, but it has not been certified UNSAT.

An ordinary pairwise-disjoint-row certificate was also tested. Its packing LP
upper bound was 215.295 at the root, already below 233, and subsequent cuts
reduced the search bound to about 204.51. Consequently no certificate in this
row-packing family can prove 233; the route was stopped after 35 seconds. More
general owner-bundle rank inequalities could exceed the ordinary LP dual, but
they were not exhaustively separated in this run.

These attempts add proof-oriented evidence without changing the result:
upper bound 233, certified/solver lower bound 224, global optimum open.

## 7. Primary-source status check

The [official MIPLIB page](https://miplib.zib.de/instance_details_ex1010-pi.html)
still labels the instance **open** and marks 233 with an asterisk as best known;
it dates the exact feasible 233 submission to 2023-10-10.

The original benchmark is listed in the official
[PB06 results archive](https://www.cril.univ-artois.fr/PB06/results/benchinfo.php?idev=1)
under `manquiho/logic_synthesis/normalized-ex1010.pi.opb`; the competition
record gave a satisfiable result, not an optimality proof. It persisted in the
[PB24 benchmark pool](https://www.cril.univ-artois.fr/PB24/results/benchinfo.php?idev=108)
as an OPT-LIN instance with 25,200 variables, 1,468 clauses, and unit objective.
The official [PB24 Exact/VeriPB run record](https://www.cril.univ-artois.fr/PB24/results/solver.php?idev=108&idsolver=3081)
timed out rather than certifying the optimum; the best visible PB24 run found
235, also without closing the instance.

The 2026 competition again included the MIPLIB copy. Official traces show
[Exact_symlocal timing out with 242](https://www.cril.univ-artois.fr/PB26/results/trace.php?idev=123&idjob=4789428)
and the certificate-capable
[HitPBO-PL timing out without a solution/proof](https://www.cril.univ-artois.fr/PB26/results/trace.php?idev=123&idjob=4795814).
The [PB26 rules and solver list](https://www.cril.univ-artois.fr/PB26/) make
clear that certificate tracks use VeriPB, so the proposed route is supported
in principle; the official results do not show closure of this instance.
The [VeriPB proof-format overview](https://gitlab.com/MIAOresearch/software/VeriPB/blob/HEAD/proof_format_overview.md)
describes the necessary matching lower and upper objective bounds, and the
[CP 2025 proof-logging paper](https://drops.dagstuhl.de/storage/00lipics/lipics-vol340-cp2025/html/LIPIcs.CP.2025.21/LIPIcs.CP.2025.21.html)
documents practical PB-optimization proof logging.

No primary source examined reports a certified optimum of 233.

## 8. Reproduction and integrity

From the repository root:

```sh
python3 instances/ex1010-pi/scripts/preprocess.py \
  instances/ex1010-pi/input/ex1010-pi.mps.gz \
  instances/ex1010-pi/solutions/official-233.sol.gz \
  --out-dir instances/ex1010-pi/artifacts
gurobi_cl Threads=1 TimeLimit=60 \
  LogFile=instances/ex1010-pi/logs/ex1010-pi-reduced-relax.log \
  ResultFile=instances/ex1010-pi/artifacts/ex1010-pi-reduced-relax.sol \
  instances/ex1010-pi/artifacts/ex1010-pi-reduced-relax.lp
```

Key SHA-256 values:

```text
model                                      05e2a67ffff4e28912ce90ef60b9dd855257c1e36fca2a8b87981983d9edbdf8
official solution                          e28e8d79d484418ea0ef821151855f13633907ed4e4b466ac6b71da1e923fdc6
preprocess summary                         d942ad1101cdae7acc1e29f02b87a311b78b773ee3c178d544224d4527b26c4a
original-to-reduced map                    63bd61a96ab3e29fe215e308dc4ef08293c3afa2cc6e3293c30f483572ed9059
reduced-column table                       ada1d45ce3251d32f47333ac0d0869534843b28d07e2920750c2789d11e08905
reduced optimization OPB                   dd8b4183b12d71b3627e1846027786c66f760428da51571a19167b8c08c106ec
reduced <=232 decision OPB                 6eca8b058b78f6ceb488c6ceb15f6e7be5e8ca3beb2c786ffb62df5487b82ed1
reduced WCNF                               62540781a223583ff03b89306d92b4dbe9f7bc5fcce89e27259dc440e10bb511
independent reduced-kernel MPS             3cfd064ce16d37050a22b357e9f18e4946bb48577d47ed6a0b2d1d2a889ad4a3
600-second kernel log                      3ed7fa60117d7b4cfcde9297c6332ec00153b386342bbe7c7269751b0c71d647
continuous-relaxation log                  4f8c276ddeb21f65fa130d8ee902c9c5eb915acb8776392fe404bf07e132a005
private-exchange decision OPB              d0b6031f102d406460dd326e9b11beab5c970eeaccee54361df5eff154d5687c
RoundingSat <=232 600-second transcript    c613b3f28bcd81f16e5d1a7f9cd9a3a945b357c56b38fa0cb9264332a16f33ba
RoundingSat private-core transcript        886a1c875211af38063eeedb20eaa60a71ae045163a1fbab17533092934ada16
```

## Final assessment

The CSV hint is directionally correct: ex1010-pi is an unusually clean target
for proof-producing PB/MaxSAT technology, and exact structural preprocessing
removes 54.1% of its columns and 37.4% of its nonzeros. The easy reductions are
now exhausted, however: there are no essentials or independent components,
and a full bounded MIP run only raised the integer lower bound to 224. The
instance is **not solved here**. The full proof logger and the smaller
incumbent-private exchange core both reached their limits without an UNSAT
certificate. The next non-generic route is owner-bundle rank-inequality
separation or a first-omitted-incumbent proof tree; current competition and
local evidence both indicate that closure is a substantial computation rather
than a quick preprocessing win.
