#!/usr/bin/env python3
"""Exact structural preprocessing for MIPLIB ex1010-pi.

The model is an unweighted set cover.  This script performs only equivalence-
preserving rules with short, independently checkable witnesses:

* merge columns with identical row support;
* delete a column if its support is strictly contained in that of a retained
  equal-cost column;
* check duplicate/subsumed rows and essential columns;
* compute connected components of the residual incidence graph;
* map and verify the official incumbent in the reduced instance.

Optionally it writes a reduced optimization OPB, the decision OPB for the
putative lower bound 233 (that is, objective <= 232), a weighted partial
MaxSAT encoding, and complete original-to-reduced mapping tables.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from collections import Counter, defaultdict, deque
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "common"))
from audit_pb_instances import parse_mps, parse_solution, sha256


def variable_number(name: str) -> int:
    assert name.startswith("x") and name[1:].isdigit(), name
    return int(name[1:])


def set_bits(mask: int):
    while mask:
        low = mask & -mask
        yield low.bit_length() - 1
        mask -= low


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def build_reduction(model: Path, solution: Path):
    name, variables, senses, rows, objective, rhs, bounds = parse_mps(model)
    assert name == "ex1010-pi"
    assert len(variables) == 25200 and len(rows) == 1468
    assert all(senses[row] == "G" for row in rows)
    assert all(rhs.get(row, 0) == 1 for row in rows)
    assert all(value == 1 for value in objective.values())
    assert set(objective) == set(variables)
    assert all(value == 1 for row in rows.values() for value in row.values())

    row_names = list(rows)
    row_index = {row: index for index, row in enumerate(row_names)}
    support_by_variable = {variable: 0 for variable in variables}
    for row, coefficients in rows.items():
        bit = 1 << row_index[row]
        for variable in coefficients:
            support_by_variable[variable] |= bit
    assert all(support_by_variable.values())

    # Duplicate classes are ordered by their lowest-numbered original column.
    duplicate_classes: dict[int, list[str]] = defaultdict(list)
    for variable, support in support_by_variable.items():
        duplicate_classes[support].append(variable)
    for members in duplicate_classes.values():
        members.sort(key=variable_number)
    supports = sorted(duplicate_classes, key=lambda mask: variable_number(
        duplicate_classes[mask][0]
    ))
    class_index = {support: index for index, support in enumerate(supports)}

    classes_by_row: list[list[int]] = [[] for _ in row_names]
    for index, support in enumerate(supports):
        for row in set_bits(support):
            classes_by_row[row].append(index)

    # A unique-support class is kept iff no other class strictly covers it.
    dominated: set[int] = set()
    for index, support in enumerate(supports):
        incident_rows = list(set_bits(support))
        candidates = min((classes_by_row[row] for row in incident_rows), key=len)
        for other in candidates:
            if other != index and support & ~supports[other] == 0:
                dominated.add(index)
                break
    retained_classes = [
        index for index in range(len(supports)) if index not in dominated
    ]
    retained_set = set(retained_classes)
    retained_position = {
        class_id: position for position, class_id in enumerate(retained_classes)
    }

    # Give every removed class a direct inclusion witness that is itself kept.
    dominating_class: dict[int, int] = {}
    for index, support in enumerate(supports):
        if index in retained_set:
            dominating_class[index] = index
            continue
        incident_rows = list(set_bits(support))
        candidates = min((classes_by_row[row] for row in incident_rows), key=len)
        witnesses = [
            other for other in candidates
            if other in retained_set and support & ~supports[other] == 0
        ]
        assert witnesses, duplicate_classes[support][0]
        dominating_class[index] = min(
            witnesses,
            key=lambda other: variable_number(duplicate_classes[supports[other]][0]),
        )

    # First row pass after the initial column reductions.
    initial_retained_classes = list(retained_classes)
    initial_by_row: list[list[int]] = [[] for _ in row_names]
    for reduced_id, class_id in enumerate(initial_retained_classes):
        for row in set_bits(supports[class_id]):
            initial_by_row[row].append(reduced_id)
    assert all(initial_by_row)
    initial_row_masks = [
        sum(1 << column for column in members) for members in initial_by_row
    ]
    row_duplicate_groups: dict[int, list[int]] = defaultdict(list)
    for row, mask in enumerate(initial_row_masks):
        row_duplicate_groups[mask].append(row)
    duplicate_row_witness: dict[int, int] = {}
    for group in row_duplicate_groups.values():
        for row in group[1:]:
            duplicate_row_witness[row] = group[0]

    # Row q is redundant if a distinct row p has C(p) strictly contained in
    # C(q), since satisfying the harder p automatically satisfies q.
    redundant_row_witness: dict[int, int] = {}
    for q, qmask in enumerate(initial_row_masks):
        for p, pmask in enumerate(initial_row_masks):
            if p != q and pmask != qmask and pmask & ~qmask == 0:
                redundant_row_witness[q] = p
                break
    rows_removed = set(duplicate_row_witness) | set(redundant_row_witness)
    initial_essential_rows = [
        row for row, members in enumerate(initial_by_row) if len(members) == 1
    ]
    assert not initial_essential_rows

    # A second column pass is necessary after removing subsumed rows.  It is
    # deliberately restricted to columns retained by the first pass: removed
    # columns are never resurrected, making the sequence certificate direct.
    active_original_rows = [
        row for row in range(len(row_names)) if row not in rows_removed
    ]
    active_mask = sum(1 << row for row in active_original_rows)
    projected_groups: dict[int, list[int]] = defaultdict(list)
    for class_id in initial_retained_classes:
        projected = supports[class_id] & active_mask
        assert projected
        projected_groups[projected].append(class_id)
    projected_representatives = [
        min(group, key=lambda class_id: variable_number(
            duplicate_classes[supports[class_id]][0]
        ))
        for group in projected_groups.values()
    ]
    projected_representatives.sort(key=lambda class_id: variable_number(
        duplicate_classes[supports[class_id]][0]
    ))
    projected_support = {
        class_id: supports[class_id] & active_mask
        for class_id in projected_representatives
    }
    projected_by_row: dict[int, list[int]] = {
        row: [] for row in active_original_rows
    }
    for class_id in projected_representatives:
        for row in set_bits(projected_support[class_id]):
            projected_by_row[row].append(class_id)
    second_dominated: set[int] = set()
    for class_id in projected_representatives:
        support = projected_support[class_id]
        candidates = min(
            (projected_by_row[row] for row in set_bits(support)), key=len
        )
        if any(
            other != class_id and support & ~projected_support[other] == 0
            for other in candidates
        ):
            second_dominated.add(class_id)
    retained_classes = [
        class_id for class_id in projected_representatives
        if class_id not in second_dominated
    ]
    retained_set = set(retained_classes)
    retained_position = {
        class_id: position for position, class_id in enumerate(retained_classes)
    }

    # Map every first-pass retained class directly to a second-pass retained
    # class.  First merge projected duplicates, then use a retained strict
    # superset witness where necessary.
    projected_representative_of: dict[int, int] = {}
    for group in projected_groups.values():
        representative = min(group, key=lambda class_id: variable_number(
            duplicate_classes[supports[class_id]][0]
        ))
        for class_id in group:
            projected_representative_of[class_id] = representative
    second_target: dict[int, int] = {}
    for class_id in initial_retained_classes:
        representative = projected_representative_of[class_id]
        if representative in retained_set:
            second_target[class_id] = representative
            continue
        support = projected_support[representative]
        candidates = min(
            (projected_by_row[row] for row in set_bits(support)), key=len
        )
        witnesses = [
            other for other in candidates
            if other in retained_set and support & ~projected_support[other] == 0
        ]
        assert witnesses
        second_target[class_id] = min(
            witnesses,
            key=lambda other: variable_number(duplicate_classes[supports[other]][0]),
        )
    final_for_class = {
        class_id: second_target[dominating_class[class_id]]
        for class_id in range(len(supports))
    }

    # Reindex the final matrix densely and recheck all reduction rules.
    final_row_names = [row_names[row] for row in active_original_rows]
    local_row = {
        original: local for local, original in enumerate(active_original_rows)
    }
    final_supports: list[int] = []
    retained_by_row: list[list[int]] = [[] for _ in final_row_names]
    for reduced_id, class_id in enumerate(retained_classes):
        mask = 0
        for original_row in set_bits(supports[class_id] & active_mask):
            local = local_row[original_row]
            mask |= 1 << local
            retained_by_row[local].append(reduced_id)
        final_supports.append(mask)
    assert all(final_supports) and all(retained_by_row)

    final_row_masks = [
        sum(1 << column for column in members) for members in retained_by_row
    ]
    assert len(set(final_row_masks)) == len(final_row_masks)
    final_redundant_rows = []
    for q, qmask in enumerate(final_row_masks):
        if any(
            p != q and pmask != qmask and pmask & ~qmask == 0
            for p, pmask in enumerate(final_row_masks)
        ):
            final_redundant_rows.append(q)
    assert not final_redundant_rows
    final_essential_rows = [
        row for row, members in enumerate(retained_by_row) if len(members) == 1
    ]
    assert not final_essential_rows

    # Bipartite connected components of final columns and final rows.
    components = []
    seen_rows: set[int] = set()
    seen_columns: set[int] = set()
    for first_row in range(len(final_row_names)):
        if first_row in seen_rows:
            continue
        component_rows = {first_row}
        component_columns: set[int] = set()
        queue = deque([("r", first_row)])
        while queue:
            kind, node = queue.popleft()
            if kind == "r":
                if node in seen_rows:
                    continue
                seen_rows.add(node)
                for column in retained_by_row[node]:
                    if column not in component_columns:
                        component_columns.add(column)
                        queue.append(("c", column))
            else:
                if node in seen_columns:
                    continue
                seen_columns.add(node)
                for row in set_bits(final_supports[node]):
                    if row not in component_rows:
                        component_rows.add(row)
                        queue.append(("r", row))
        components.append({
            "rows": len(component_rows),
            "columns": len(component_columns),
        })

    # Canonically map the official incumbent through duplicate/dominance rules.
    claimed, sparse = parse_solution(solution)
    assert claimed == 233
    chosen_original = {variable for variable, value in sparse.items() if value == 1}
    assert len(chosen_original) == 233
    mapped_columns: set[int] = set()
    for variable in chosen_original:
        class_id = class_index[support_by_variable[variable]]
        kept_class = final_for_class[class_id]
        mapped_columns.add(retained_position[kept_class])
    covered_mask = 0
    covered_original_mask = 0
    for reduced_id in mapped_columns:
        covered_mask |= final_supports[reduced_id]
        covered_original_mask |= supports[retained_classes[reduced_id]]
    assert covered_mask == (1 << len(final_row_names)) - 1
    assert covered_original_mask == (1 << len(row_names)) - 1

    reduced_nonzeros = sum(
        len(retained_by_row[row]) for row in range(len(final_row_names))
    )
    result = {
        "instance": name,
        "model_sha256": sha256(model),
        "solution_sha256": sha256(solution),
        "original": {
            "rows": len(row_names),
            "columns": len(variables),
            "nonzeros": sum(len(coefficients) for coefficients in rows.values()),
        },
        "reduction_passes": [
            {
                "input_rows": len(row_names),
                "input_columns": len(variables),
                "duplicate_columns_removed": len(variables) - len(supports),
                "strictly_dominated_support_classes_removed": len(dominated),
                "retained_columns": len(initial_retained_classes),
                "duplicate_rows_removed": len(duplicate_row_witness),
                "strictly_subsumed_rows_removed": len(redundant_row_witness),
                "subsumed_row_witnesses": {
                    row_names[row]: row_names[witness]
                    for row, witness in redundant_row_witness.items()
                },
                "essential_rows": len(initial_essential_rows),
            },
            {
                "input_rows": len(final_row_names),
                "input_columns": len(initial_retained_classes),
                "projected_duplicate_columns_removed": (
                    len(initial_retained_classes) - len(projected_representatives)
                ),
                "strictly_dominated_columns_removed": len(second_dominated),
                "retained_columns": len(retained_classes),
                "duplicate_rows_removed": 0,
                "strictly_subsumed_rows_removed": 0,
                "essential_rows": len(final_essential_rows),
            },
        ],
        "retained_columns": len(retained_classes),
        "retained_rows": len(final_row_names),
        "retained_nonzeros": reduced_nonzeros,
        "retained_column_degree_histogram": dict(sorted(Counter(
            len(list(set_bits(support))) for support in final_supports
        ).items())),
        "retained_row_degree_histogram": dict(sorted(Counter(
            len(members) for members in retained_by_row
        ).items())),
        "fixed_point_duplicate_rows": 0,
        "fixed_point_strictly_subsumed_rows": 0,
        "fixed_point_essential_rows": 0,
        "components": components,
        "official_incumbent": {
            "objective": int(claimed),
            "chosen_original_columns": len(chosen_original),
            "chosen_reduced_columns": len(mapped_columns),
            "covered_reduced_rows": bin(covered_mask).count("1"),
            "covered_original_rows_by_retained_representatives": bin(
                covered_original_mask
            ).count("1"),
        },
    }
    certificates = {
        "row_names": final_row_names,
        "original_row_names": row_names,
        "supports": supports,
        "final_supports": final_supports,
        "duplicate_classes": duplicate_classes,
        "class_index": class_index,
        "retained_classes": retained_classes,
        "retained_position": retained_position,
        "final_for_class": final_for_class,
        "initial_dominating_class": dominating_class,
        "second_target": second_target,
        "active_mask": active_mask,
        "retained_by_row": retained_by_row,
        "support_by_variable": support_by_variable,
        "chosen_original": chosen_original,
        "mapped_columns": mapped_columns,
    }
    return result, certificates


def write_artifacts(out_dir: Path, result, cert) -> dict[str, str]:
    out_dir.mkdir(parents=True, exist_ok=True)
    supports = cert["supports"]
    final_supports = cert["final_supports"]
    duplicate_classes = cert["duplicate_classes"]
    class_index = cert["class_index"]
    retained_classes = cert["retained_classes"]
    retained_position = cert["retained_position"]
    final_for_class = cert["final_for_class"]
    initial_dominating_class = cert["initial_dominating_class"]
    second_target = cert["second_target"]
    active_mask = cert["active_mask"]
    retained_by_row = cert["retained_by_row"]

    mapped_original_count = Counter()
    for variable, support in cert["support_by_variable"].items():
        class_id = class_index[support]
        mapped_original_count[final_for_class[class_id]] += 1

    summary_path = out_dir / "ex1010-pi-preprocess-summary.json"
    summary_path.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")

    reduced_map_path = out_dir / "ex1010-pi-reduced-columns.tsv"
    with reduced_map_path.open("w", newline="", encoding="ascii") as stream:
        writer = csv.writer(stream, delimiter="\t", lineterminator="\n")
        writer.writerow([
            "reduced_variable", "original_representative",
            "row_support_size", "original_columns_mapped_here",
        ])
        for reduced_id, class_id in enumerate(retained_classes, start=1):
            members = duplicate_classes[supports[class_id]]
            writer.writerow([
                f"x{reduced_id}", members[0],
                len(list(set_bits(final_supports[reduced_id - 1]))),
                mapped_original_count[class_id],
            ])

    full_map_path = out_dir / "ex1010-pi-original-to-reduced.tsv"
    with full_map_path.open("w", newline="", encoding="ascii") as stream:
        writer = csv.writer(stream, delimiter="\t", lineterminator="\n")
        writer.writerow([
            "original_variable", "reduced_variable", "reason",
            "original_support_size", "retained_support_size",
        ])
        for variable in sorted(cert["support_by_variable"], key=variable_number):
            support = cert["support_by_variable"][variable]
            class_id = class_index[support]
            initial_class = initial_dominating_class[class_id]
            kept_class = final_for_class[class_id]
            reduced_id = retained_position[kept_class] + 1
            members = duplicate_classes[support]
            reasons = []
            if variable != members[0]:
                reasons.append("duplicate_support")
            if class_id != initial_class:
                reasons.append("strict_support_dominance")
            if initial_class != kept_class:
                if (supports[initial_class] & active_mask
                        == supports[kept_class] & active_mask):
                    reasons.append("projected_duplicate_after_row_subsumption")
                else:
                    reasons.append("second_pass_dominance")
            reason = ",".join(reasons) or "retained_representative"
            writer.writerow([
                variable, f"x{reduced_id}", reason,
                len(list(set_bits(support))),
                len(list(set_bits(final_supports[reduced_id - 1]))),
            ])

    def objective_line() -> str:
        return "min: " + " ".join(
            f"+1 x{column}" for column in range(1, len(retained_classes) + 1)
        ) + " ;\n"

    def cover_lines() -> str:
        return "".join(
            " ".join(f"+1 x{column + 1}" for column in members) + " >= 1 ;\n"
            for members in retained_by_row
        )

    optimization_path = out_dir / "ex1010-pi-reduced.opb"
    optimization_path.write_text(
        f"* #variable= {len(retained_classes)} #constraint= {len(retained_by_row)}\n"
        "* Equivalent to MIPLIB ex1010-pi after duplicate and equal-cost support dominance.\n"
        + objective_line() + cover_lines(),
        encoding="ascii",
    )

    decision_path = out_dir / "ex1010-pi-reduced-lb233.opb"
    bound = " ".join(
        f"-1 x{column}" for column in range(1, len(retained_classes) + 1)
    ) + " >= -232 ;\n"
    decision_path.write_text(
        f"* #variable= {len(retained_classes)} #constraint= {len(retained_by_row) + 1}\n"
        "* UNSAT proves lower bound 233 for MIPLIB ex1010-pi.\n"
        + cover_lines() + bound,
        encoding="ascii",
    )

    # Weighted partial MaxSAT: hard positive cover clauses and unit soft
    # clauses (-x), whose violated weight is exactly the selected-set size.
    wcnf_path = out_dir / "ex1010-pi-reduced.wcnf"
    top = len(retained_classes) + 1
    wcnf_lines = [
        f"p wcnf {len(retained_classes)} "
        f"{len(retained_by_row) + len(retained_classes)} {top}\n"
    ]
    wcnf_lines.extend(
        f"{top} " + " ".join(str(column + 1) for column in members) + " 0\n"
        for members in retained_by_row
    )
    wcnf_lines.extend(
        f"1 -{column} 0\n" for column in range(1, len(retained_classes) + 1)
    )
    wcnf_path.write_text("".join(wcnf_lines), encoding="ascii")

    incumbent_path = out_dir / "ex1010-pi-reduced-233.sol"
    incumbent_path.write_text(
        "=obj= 233\n" + "".join(
            f"x{column + 1} 1\n" for column in sorted(cert["mapped_columns"])
        ),
        encoding="ascii",
    )

    def wrapped_variables(prefix: str, columns, suffix: str = "") -> str:
        names = [f"x{column}" for column in columns]
        chunks = [names[start:start + 20] for start in range(0, len(names), 20)]
        # LP line breaks are whitespace, not implicit addition.  Prefix every
        # continuation chunk with an explicit plus sign so adjacent variable
        # names cannot be parsed as one malformed term.
        return prefix + ("\n  + ".join(" + ".join(chunk) for chunk in chunks)) + suffix

    def lp_text(binary: bool) -> str:
        lines = ["Minimize\n", wrapped_variables(
            " obj: ", range(1, len(retained_classes) + 1), "\n"
        ), "Subject To\n"]
        for row_name, members in zip(cert["row_names"], retained_by_row):
            lines.append(wrapped_variables(
                f" {row_name}: ", (column + 1 for column in members), " >= 1\n"
            ))
        lines.append("Bounds\n")
        lines.extend(
            f" 0 <= x{column} <= 1\n"
            for column in range(1, len(retained_classes) + 1)
        )
        if binary:
            lines.append("Binary\n")
            names = [f"x{column}" for column in range(1, len(retained_classes) + 1)]
            for start in range(0, len(names), 20):
                lines.append(" " + " ".join(names[start:start + 20]) + "\n")
        lines.append("End\n")
        return "".join(lines)

    mip_lp_path = out_dir / "ex1010-pi-reduced.lp"
    mip_lp_path.write_text(lp_text(binary=True), encoding="ascii")
    relax_lp_path = out_dir / "ex1010-pi-reduced-relax.lp"
    relax_lp_path.write_text(lp_text(binary=False), encoding="ascii")

    paths = [
        summary_path, reduced_map_path, full_map_path, optimization_path,
        decision_path, wcnf_path, incumbent_path, mip_lp_path, relax_lp_path,
    ]
    return {path.name: file_sha256(path) for path in paths}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--out-dir", type=Path)
    args = parser.parse_args()

    result, certificates = build_reduction(args.model, args.solution)
    if args.out_dir:
        result["generated_sha256"] = write_artifacts(
            args.out_dir, result, certificates
        )
        # Rewrite the summary so it also records all generated hashes. Its own
        # hash is intentionally excluded to avoid a recursive checksum.
        summary = args.out_dir / "ex1010-pi-preprocess-summary.json"
        result["generated_sha256"].pop(summary.name)
        summary.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
