#!/usr/bin/env python3
"""Find a certificate-style set-cover lower bound by disjoint row packing.

Selected cover rows must have pairwise disjoint column neighborhoods.  Hence
each selected row requires a distinct chosen set in every feasible cover.
The output row list is independently checkable against the MPS incidence
matrix; the optimizer is only used to search for the certificate.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mps", type=Path)
    ap.add_argument("certificate", type=Path)
    ap.add_argument("--time-limit", type=float, default=300)
    ap.add_argument("--log", type=Path)
    args = ap.parse_args()

    source = gp.read(str(args.mps))
    source.update()
    rows = source.getConstrs()
    columns = source.getVars()

    packing = gp.Model("ex1010_disjoint_row_packing")
    y = packing.addVars(len(rows), vtype=GRB.BINARY, name="row")
    for j, column in enumerate(columns):
        incidence = []
        col = source.getCol(column)
        for k in range(col.size()):
            if abs(col.getCoeff(k)) > 0:
                incidence.append(y[col.getConstr(k).index])
        if incidence:
            packing.addConstr(gp.quicksum(incidence) <= 1, name=f"column_{j}")
    packing.setObjective(y.sum(), GRB.MAXIMIZE)
    packing.Params.Threads = 2
    packing.Params.TimeLimit = args.time_limit
    packing.Params.MIPFocus = 1
    if args.log:
        args.log.parent.mkdir(parents=True, exist_ok=True)
        packing.Params.LogFile = str(args.log)
    packing.optimize()

    selected = [rows[i].ConstrName for i in range(len(rows)) if y[i].X > 0.5]
    # Independent pairwise-disjoint check using original column supports.
    selected_set = set(selected)
    collisions = []
    for column in columns:
        col = source.getCol(column)
        touched = [col.getConstr(k).ConstrName for k in range(col.size())
                   if col.getConstr(k).ConstrName in selected_set and abs(col.getCoeff(k)) > 0]
        if len(touched) > 1:
            collisions.append({"column": column.VarName, "rows": touched})
    payload = {
        "certificate_type": "pairwise-disjoint row neighborhoods",
        "selected_row_count": len(selected),
        "selected_rows": selected,
        "collision_count": len(collisions),
        "collisions": collisions[:10],
        "search_status": int(packing.Status),
        "search_incumbent": packing.ObjVal if packing.SolCount else None,
        "search_bound": packing.ObjBound,
        "runtime_seconds": packing.Runtime,
    }
    args.certificate.parent.mkdir(parents=True, exist_ok=True)
    args.certificate.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in payload.items() if k not in {"selected_rows", "collisions"}}, indent=2))


if __name__ == "__main__":
    main()
