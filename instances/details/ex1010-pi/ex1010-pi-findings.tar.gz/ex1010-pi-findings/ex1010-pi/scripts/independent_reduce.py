#!/usr/bin/env python3
"""Build an exactly equivalent duplicate/dominance kernel for ex1010-pi."""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "common"))
from audit_pb_instances import parse_mps, parse_solution


def numeric_key(name: str) -> int:
    return int(name[1:])


def column_reduction(active_rows, active_columns, original_supports, selected):
    signatures = defaultdict(list)
    for variable in active_columns:
        signatures[frozenset(original_supports[variable] & active_rows)].append(variable)
    assert all(signatures), "empty column signature"

    supports = list(signatures)
    row_to_supports = defaultdict(set)
    for index, support in enumerate(supports):
        for row in support:
            row_to_supports[row].add(index)

    representative = {}
    for support, variables in signatures.items():
        chosen = sorted(set(variables) & selected, key=numeric_key)
        representative[support] = chosen[0] if chosen else min(variables, key=numeric_key)

    dominating_index = {}
    for index, support in enumerate(supports):
        candidates = None
        for row in sorted(support, key=lambda item: len(row_to_supports[item])):
            candidates = (
                set(row_to_supports[row])
                if candidates is None
                else candidates & row_to_supports[row]
            )
            if len(candidates) == 1:
                break
        assert candidates is not None
        strict = [other for other in candidates if len(supports[other]) > len(support)]
        if strict:
            dominating_index[index] = max(
                strict,
                key=lambda other: (len(supports[other]), -numeric_key(representative[supports[other]])),
            )

    def terminal(index):
        while index in dominating_index:
            index = dominating_index[index]
        return index

    support_index = {support: index for index, support in enumerate(supports)}
    new_selected = {
        representative[supports[terminal(support_index[
            frozenset(original_supports[variable] & active_rows)
        ])]]
        for variable in selected
    }
    maximal = [index for index in range(len(supports)) if index not in dominating_index]
    new_columns = {representative[supports[index]] for index in maximal}
    assert new_selected <= new_columns
    stats = {
        "before": len(active_columns),
        "unique_supports": len(supports),
        "duplicates_removed": len(active_columns) - len(supports),
        "dominated_unique_supports_removed": len(supports) - len(maximal),
        "after": len(new_columns),
        "selected_after": len(new_selected),
    }
    return new_columns, new_selected, stats


def row_reduction(active_rows, active_columns, original_rows):
    supports = {
        row: frozenset(set(original_rows[row]) & active_columns)
        for row in active_rows
    }
    assert all(supports.values()), "uncoverable row after reduction"
    signatures = defaultdict(list)
    for row, support in supports.items():
        signatures[support].append(row)
    unique_supports = list(signatures)
    column_to_supports = defaultdict(set)
    for index, support in enumerate(unique_supports):
        for variable in support:
            column_to_supports[variable].add(index)

    # If A is a strict subset of B, satisfying A implies B, so B is redundant.
    superseded = set()
    for index, support in enumerate(unique_supports):
        candidates = None
        for variable in sorted(support, key=lambda item: len(column_to_supports[item])):
            candidates = (
                set(column_to_supports[variable])
                if candidates is None
                else candidates & column_to_supports[variable]
            )
            if len(candidates) == 1:
                break
        assert candidates is not None
        for other in candidates:
            if len(unique_supports[other]) > len(support):
                superseded.add(other)

    kept_rows = {
        min(signatures[support], key=lambda row: int(row[1:]))
        for index, support in enumerate(unique_supports)
        if index not in superseded
    }
    stats = {
        "before": len(active_rows),
        "duplicate_rows_removed": len(active_rows) - len(unique_supports),
        "dominated_rows_removed": len(superseded),
        "after": len(kept_rows),
    }
    return kept_rows, stats


def write_mps(path, active_rows, active_columns, original_rows):
    rows_by_column = defaultdict(list)
    for row in sorted(active_rows, key=lambda item: int(item[1:])):
        for variable in original_rows[row]:
            if variable in active_columns:
                rows_by_column[variable].append(row)

    with path.open("w", encoding="ascii") as output:
        output.write("NAME          ex1010-pi-kernel\nROWS\n")
        output.write(" N  Obj\n")
        for row in sorted(active_rows, key=lambda item: int(item[1:])):
            output.write(f" G  {row}\n")
        output.write("COLUMNS\n")
        output.write("    INTSTART  'MARKER'                 'INTORG'\n")
        for variable in sorted(active_columns, key=numeric_key):
            entries = [("Obj", 1)] + [(row, 1) for row in rows_by_column[variable]]
            for start in range(0, len(entries), 2):
                chunk = entries[start:start + 2]
                fields = f"    {variable:<12}"
                for row, value in chunk:
                    fields += f"  {row:<12}  {value:>12}"
                output.write(fields.rstrip() + "\n")
        output.write("    INTEND    'MARKER'                 'INTEND'\n")
        output.write("RHS\n")
        ordered_rows = sorted(active_rows, key=lambda item: int(item[1:]))
        for start in range(0, len(ordered_rows), 2):
            fields = "    RHS         "
            for row in ordered_rows[start:start + 2]:
                fields += f"  {row:<12}  {1:>12}"
            output.write(fields.rstrip() + "\n")
        output.write("BOUNDS\n")
        for variable in sorted(active_columns, key=numeric_key):
            output.write(f" BV Bound     {variable}\n")
        output.write("ENDATA\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("kernel", type=Path)
    parser.add_argument("kernel_solution", type=Path)
    parser.add_argument("report", type=Path)
    args = parser.parse_args()

    name, variables, senses, rows, objective, rhs, bounds = parse_mps(args.model)
    assert name == "ex1010-pi"
    assert all(senses[row] == "G" and rhs[row] == 1 for row in rows)
    assert all(value == 1 for value in objective.values())
    original_supports = {variable: set() for variable in variables}
    for row, coefficients in rows.items():
        for variable, coefficient in coefficients.items():
            assert coefficient == 1
            original_supports[variable].add(row)

    claimed, sparse = parse_solution(args.solution)
    selected = {variable for variable, value in sparse.items() if value != 0}
    assert claimed == len(selected) == 233
    active_rows = set(rows)
    active_columns = set(variables)
    iterations = []
    while True:
        new_columns, selected, column_stats = column_reduction(
            active_rows, active_columns, original_supports, selected
        )
        new_rows, row_stats = row_reduction(active_rows, new_columns, rows)
        iterations.append({"columns": column_stats, "rows": row_stats})
        if new_columns == active_columns and new_rows == active_rows:
            break
        active_columns, active_rows = new_columns, new_rows

    assert set().union(*(original_supports[variable] for variable in selected)) == set(rows)
    assert len(selected) <= 233
    write_mps(args.kernel, active_rows, active_columns, rows)
    args.kernel_solution.write_text(
        f"=obj= {len(selected)}\n" +
        "".join(f"{variable} 1\n" for variable in sorted(selected, key=numeric_key)),
        encoding="ascii",
    )
    summary = {
        "original_rows": len(rows),
        "original_columns": len(variables),
        "original_nonzeros": sum(map(len, rows.values())),
        "iterations": iterations,
        "kernel_rows": len(active_rows),
        "kernel_columns": len(active_columns),
        "kernel_nonzeros": sum(
            1 for row in active_rows for variable in rows[row] if variable in active_columns
        ),
        "mapped_incumbent_objective": len(selected),
        "selected_covers_every_original_row": True,
    }
    args.report.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="ascii")
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
