#!/usr/bin/env python3
"""
waima_pairgraph.py

Read-only structural diagnostic and exact local-pattern generator for
MIPLIB neos-4533806-waima.

Usage:
  python waima_pairgraph.py MODEL SOL REPORT.json \
      [--artifact patterns.sqlite] [--time-limit 600] \
      [--max-primitives 2000000] [--max-states 2000000]

The program uses gurobipy only for gp.read() and read-only sparse-matrix access.
It never calls optimize(), presolve(), or computeIIS().

The SQLite artifact contains exact projected constraints, complete pairwise
rows, primitive balanced paths/cycles, and locally feasible patterns whenever
the corresponding generation status says complete.
"""

import argparse
import gzip
import hashlib
import json
import os
import re
import sqlite3
import sys
import time
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from functools import lru_cache

import gurobipy as gp


TOL = 1e-8
INT_TOL = 1e-7
REPORT_LIMIT = 2_000_000
FOUR_BLOCKS = [
    (52255, 52398),
    (52407, 52550),
    (52559, 52702),
    (52711, 52854),
]


def close(a, b, tol=TOL):
    return abs(float(a) - float(b)) <= tol * max(1.0, abs(float(a)), abs(float(b)))


def as_int(x):
    r = round(float(x))
    if not close(x, r):
        raise ValueError("nonintegral value where integer expected: %r" % (x,))
    return int(r)


def num(x):
    x = float(x)
    return int(round(x)) if close(x, round(x)) else x


def stable_json(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def digest(obj):
    return hashlib.sha256(stable_json(obj).encode("ascii")).hexdigest()[:24]


def compact_ranges(values):
    xs = sorted(set(int(x) for x in values))
    if not xs:
        return []
    out = []
    a = b = xs[0]
    for x in xs[1:]:
        if x == b + 1:
            b = x
        else:
            out.append([a, b])
            a = b = x
    out.append([a, b])
    return out


def ownership_runs(rows):
    if not rows:
        return []
    out = []
    start = rows[0]["index"]
    end = start
    pair = tuple(rows[0]["groups"])
    for row in rows[1:]:
        p = tuple(row["groups"])
        if row["index"] == end + 1 and p == pair:
            end = row["index"]
        else:
            out.append([start, end, list(pair)])
            start = end = row["index"]
            pair = p
    out.append([start, end, list(pair)])
    return out


def parse_solution(path):
    opener = gzip.open if path.lower().endswith(".gz") else open
    with opener(path, "rb") as f:
        raw = f.read()

    text = raw.decode("utf-8", errors="replace").lstrip()
    values = {}
    if text.startswith("<"):
        root = ET.fromstring(raw)
        for elem in root.iter():
            if elem.tag.lower().endswith("variable"):
                name = elem.attrib.get("name")
                value = elem.attrib.get("value")
                if name is not None and value is not None:
                    values[name] = float(value)
        return values

    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        fields = re.split(r"\s+", line)
        if len(fields) >= 2:
            try:
                values[fields[0]] = float(fields[1])
            except ValueError:
                pass
    return values


def extract_rows(model):
    constraints = model.getConstrs()
    rows = []
    for ri, constr in enumerate(constraints):
        expr = model.getRow(constr)
        terms = []
        for k in range(expr.size()):
            var = expr.getVar(k)
            terms.append((var.index, float(expr.getCoeff(k))))
        terms.sort()
        rows.append({
            "index": ri,
            "name": constr.ConstrName,
            "sense": constr.Sense,
            "rhs": float(constr.RHS),
            "terms": terms,
        })
    return rows


def find_pairs(rows, variables):
    pairs = []
    pair_rows = set()
    used = Counter()

    for row in rows:
        if row["sense"] != "=" or not close(row["rhs"], 0) or len(row["terms"]) != 2:
            continue
        (i, a), (j, b) = row["terms"]
        if not (close(abs(a), 1) and close(abs(b), 1) and close(a + b, 0)):
            continue
        if variables[i].VType == "C" or variables[j].VType == "C":
            continue

        oi = abs(variables[i].Obj) > TOL
        oj = abs(variables[j].Obj) > TOL
        if oi == oj:
            continue

        costly, copy = (i, j) if oi else (j, i)
        pairs.append((row["index"], costly, copy))
        pair_rows.add(row["index"])
        used[costly] += 1
        used[copy] += 1

    pairs.sort(key=lambda z: z[1])
    return pairs, pair_rows, used


def substitute_rows(rows, substitution):
    result = []
    for row in rows:
        coeffs = defaultdict(float)
        for i, a in row["terms"]:
            coeffs[substitution[i]] += a
        terms = sorted(
            (i, a) for i, a in coeffs.items() if abs(a) > TOL
        )
        result.append({
            "index": row["index"],
            "name": row["name"],
            "sense": row["sense"],
            "rhs": row["rhs"],
            "terms": terms,
        })
    return result


def derive_groups(sub_rows, costly_set):
    groups = []
    owner = {}
    ordinal = {}

    for g in range(12):
        support = sorted(i for i, _ in sub_rows[g]["terms"] if i in costly_set)
        assert len(support) == 3811
        for j, i in enumerate(support):
            assert i not in owner
            owner[i] = g
            ordinal[i] = j
        groups.append(support)

    assert len(owner) == 45732
    assert set(owner) == costly_set
    return groups, owner, ordinal


def check_reporting_rows(sub_rows, variables, continuous_set):
    occurrences = defaultdict(list)
    for row in sub_rows:
        for i, a in row["terms"]:
            if i in continuous_set:
                occurrences[i].append((row["index"], a))

    assert set(occurrences) == continuous_set
    checks = []
    for i in sorted(continuous_set):
        assert len(occurrences[i]) == 1
        ri, coefficient = occurrences[i][0]
        assert ri == i and ri < 14
        assert sub_rows[ri]["sense"] == "="
        assert close(sub_rows[ri]["rhs"], 0)
        assert close(coefficient, -1)

        other = [(j, a) for j, a in sub_rows[ri]["terms"] if j != i]
        assert all(variables[j].VType != "C" for j, _ in other)
        assert all(a >= -TOL for _, a in other)
        checks.append({
            "continuous_index": i,
            "row_index": ri,
            "other_term_count": len(other),
            "coefficient_histogram": sorted(
                [[num(a), n] for a, n in Counter(num(a) for _, a in other).items()],
                key=lambda z: float(z[0])
            ),
        })
    return checks


def attainable_sums(coefficients, max_span=200000):
    coeffs = [as_int(a) for a in coefficients]
    lo = sum(a for a in coeffs if a < 0)
    hi = sum(a for a in coeffs if a > 0)

    if not coeffs:
        return {"supported": True, "kind": "set", "values": [0]}

    if all(abs(a) == 1 for a in coeffs):
        return {
            "supported": True,
            "kind": "interval",
            "minimum": lo,
            "maximum": hi,
        }

    if hi - lo > max_span:
        return {
            "supported": False,
            "reason": "subset-sum span exceeds safety limit",
            "minimum": lo,
            "maximum": hi,
        }

    reachable = {0}
    for a in coeffs:
        reachable |= {s + a for s in reachable}
    values = sorted(reachable)
    if values == list(range(values[0], values[-1] + 1)):
        return {
            "supported": True,
            "kind": "interval",
            "minimum": values[0],
            "maximum": values[-1],
        }
    return {"supported": True, "kind": "set", "values": values}


def project_rows(rows, costly_set, auxiliary_set, solution_values):
    projected = []
    auxiliary_incidence = Counter()

    for row in rows:
        costly = []
        auxiliary = []
        unknown = []

        for i, a in row["terms"]:
            if i in costly_set:
                costly.append((i, as_int(a)))
            elif i in auxiliary_set:
                auxiliary.append((i, as_int(a)))
                auxiliary_incidence[i] += 1
            else:
                unknown.append((i, a))

        assert not unknown, (row["index"], unknown[:10])
        rhs = as_int(row["rhs"])
        aux_coeffs = [a for _, a in auxiliary]

        if row["sense"] == "<":
            endpoint = sum(min(0, a) for a in aux_coeffs)
            relation = {"kind": "le", "bound": rhs - endpoint}
        elif row["sense"] == ">":
            endpoint = sum(max(0, a) for a in aux_coeffs)
            relation = {"kind": "ge", "bound": rhs - endpoint}
        else:
            sums = attainable_sums(aux_coeffs)
            assert sums["supported"], (row["index"], sums)
            if sums["kind"] == "interval":
                relation = {
                    "kind": "eq_interval",
                    "minimum": rhs - sums["maximum"],
                    "maximum": rhs - sums["minimum"],
                }
            else:
                relation = {
                    "kind": "eq_set",
                    "values": sorted(rhs - s for s in sums["values"]),
                }

        activity = sum(a * solution_values[i] for i, a in costly)
        assert close(activity, round(activity), INT_TOL)
        activity = int(round(activity))
        assert relation_holds(relation, activity), (row["index"], relation, activity)

        groups = sorted({None}) if not costly else None
        projected.append({
            "index": row["index"],
            "name": row["name"],
            "original_sense": row["sense"],
            "original_rhs": rhs,
            "relation": relation,
            "costly_terms": costly,
            "auxiliary_terms": auxiliary,
            "incumbent_activity": activity,
            "groups": groups,
        })

    assert len(auxiliary_incidence) == 1840
    assert all(n == 1 for n in auxiliary_incidence.values())
    return projected


def relation_holds(relation, activity):
    kind = relation["kind"]
    if kind == "le":
        return activity <= relation["bound"]
    if kind == "ge":
        return activity >= relation["bound"]
    if kind == "eq_interval":
        return relation["minimum"] <= activity <= relation["maximum"]
    if kind == "eq_set":
        return activity in set(relation["values"])
    raise ValueError(kind)


def relation_key(relation):
    kind = relation["kind"]
    if kind in ("le", "ge"):
        return [kind, relation["bound"]]
    if kind == "eq_interval":
        return [kind, relation["minimum"], relation["maximum"]]
    return [kind, relation["values"]]


def attach_coordinates(projected, owner, ordinal):
    for row in projected:
        groups = sorted({owner[i] for i, _ in row["costly_terms"]})
        row["groups"] = groups
        row["coordinate_terms"] = sorted(
            (owner[i], ordinal[i], a) for i, a in row["costly_terms"]
        )


def row_signature(row, relabel_groups=False):
    terms = row["coordinate_terms"]
    if relabel_groups:
        gs = sorted({g for g, _, _ in terms})
        relabel = {g: k for k, g in enumerate(gs)}
        terms = sorted((relabel[g], j, a) for g, j, a in terms)
    return [
        relation_key(row["relation"]),
        terms,
    ]


def local_signature(row):
    assert len(row["groups"]) == 1
    return [
        relation_key(row["relation"]),
        sorted((j, a) for _, j, a in row["coordinate_terms"]),
    ]


def classify_rows(projected):
    local = defaultdict(list)
    pairwise = []
    global_rows = []
    zero = []

    for row in projected:
        n = len(row["groups"])
        if n == 0:
            zero.append(row)
        elif n == 1:
            local[row["groups"][0]].append(row)
        elif n == 2:
            pairwise.append(row)
        else:
            global_rows.append(row)

    assert len(local) == 12
    assert sum(map(len, local.values())) == 6632
    assert len(pairwise) == 584
    assert len(global_rows) == 21
    assert not zero
    assert sorted(len(local[g]) for g in range(12)) == [550] * 4 + [554] * 8
    return local, pairwise, global_rows


def identify_local_types(local):
    counters = []
    for g in range(12):
        counters.append(Counter(stable_json(local_signature(r)) for r in local[g]))

    type_ids = {}
    representatives = []
    for g, counter in enumerate(counters):
        found = None
        for t, rep in enumerate(representatives):
            if counter == rep:
                found = t
                break
        if found is None:
            found = len(representatives)
            representatives.append(counter)
        type_ids[g] = found

    assert len(representatives) == 2
    classes = defaultdict(list)
    for g, t in type_ids.items():
        classes[t].append(g)

    class_lists = sorted(sorted(v) for v in classes.values())
    assert class_lists == [[0, 3, 6, 9], [1, 2, 4, 5, 7, 8, 10, 11]]

    return type_ids, {
        str(t): {
            "groups": sorted(groups),
            "representative_group": min(groups),
            "local_row_count": len(local[min(groups)]),
            "exact_matrix_hash": digest(sorted(representatives[t].items())),
        }
        for t, groups in sorted(classes.items())
    }


def pairwise_graph_analysis(pairwise):
    pair_rows = defaultdict(list)
    for row in pairwise:
        pair = tuple(row["groups"])
        pair_rows[pair].append(row)

    graph_edges = []
    adjacency = [set() for _ in range(12)]
    for pair in sorted(pair_rows):
        a, b = pair
        adjacency[a].add(b)
        adjacency[b].add(a)
        members = sorted(pair_rows[pair], key=lambda r: r["index"])
        graph_edges.append({
            "groups": [a, b],
            "row_count": len(members),
            "row_ranges": compact_ranges(r["index"] for r in members),
            "relation_histogram": sorted(
                [[k, n]
                 for k, n in Counter(
                     stable_json(relation_key(r["relation"])) for r in members
                 ).items()]
            ),
            "degree_histogram": sorted(
                [[degree, n] for degree, n in Counter(
                    len(r["costly_terms"]) for r in members
                ).items()]
            ),
            "coefficient_histogram": sorted(
                [[a0, n] for a0, n in Counter(
                    a for r in members for _, a in r["costly_terms"]
                ).items()]
            ),
            "row_indices": [r["index"] for r in members],
        })

    block_reports = []
    block_pair_sequences = []
    for block_id, (lo, hi) in enumerate(FOUR_BLOCKS):
        members = sorted(
            [r for r in pairwise if lo <= r["index"] <= hi],
            key=lambda r: r["index"]
        )
        assert len(members) == 144
        sequence = [tuple(r["groups"]) for r in members]
        block_pair_sequences.append(sequence)

        normalized_shapes = Counter(
            stable_json(row_signature(r, relabel_groups=True)) for r in members
        )
        block_reports.append({
            "block": block_id,
            "row_range": [lo, hi],
            "row_count": len(members),
            "all_rows_touch_exactly_two_groups": all(len(r["groups"]) == 2 for r in members),
            "ownership_runs": ownership_runs(members),
            "pair_count_histogram": [
                [list(pair), n] for pair, n in sorted(Counter(sequence).items())
            ],
            "distinct_exact_normalized_row_shapes": len(normalized_shapes),
            "normalized_shape_hash": digest(sorted(normalized_shapes.items())),
            "ordered_pair_sequence_hash": digest(sequence),
            "coefficient_histogram": sorted(
                [[a, n] for a, n in Counter(
                    a for r in members for _, a in r["costly_terms"]
                ).items()]
            ),
            "degree_histogram": sorted(
                [[d, n] for d, n in Counter(
                    len(r["costly_terms"]) for r in members
                ).items()]
            ),
        })

    same_pair_schedule = all(
        seq == block_pair_sequences[0] for seq in block_pair_sequences[1:]
    )

    residual_pairwise = [
        r for r in pairwise
        if not any(lo <= r["index"] <= hi for lo, hi in FOUR_BLOCKS)
    ]
    assert len(residual_pairwise) == 8

    width, order = exact_treewidth(adjacency)

    return {
        "vertices": list(range(12)),
        "edges": graph_edges,
        "edge_count": len(graph_edges),
        "degree_sequence": [len(adjacency[g]) for g in range(12)],
        "connected": graph_connected(adjacency),
        "exact_treewidth": width,
        "one_optimal_elimination_order": order,
        "four_contiguous_144_row_blocks": block_reports,
        "four_blocks_have_identical_ordered_group_pair_schedule": same_pair_schedule,
        "four_blocks_are_distinct_exact_row_families":
            len({b["normalized_shape_hash"] for b in block_reports}) == 4,
        "four_time_or_layer_families_supported": (
            same_pair_schedule
            and all(b["all_rows_touch_exactly_two_groups"] for b in block_reports)
        ),
        "interpretation":
            "The four blocks are called time/layer families only when they "
            "repeat the exact ordered group-pair schedule; this does not assign "
            "a real-world meaning to the four coordinates.",
        "other_eight_pairwise_rows": [
            {
                "row_index": r["index"],
                "row_name": r["name"],
                "groups": r["groups"],
                "relation": r["relation"],
                "group_support_counts": sorted(
                    [[g, sum(1 for gg, _, _ in r["coordinate_terms"] if gg == g)]
                     for g in r["groups"]]
                ),
                "degree": len(r["costly_terms"]),
                "coefficient_histogram": sorted(
                    [[a, n] for a, n in Counter(
                        a for _, a in r["costly_terms"]
                    ).items()]
                ),
                "support_hash": digest(r["coordinate_terms"]),
            }
            for r in sorted(residual_pairwise, key=lambda z: z["index"])
        ],
    }


def graph_connected(adjacency):
    seen = {0}
    stack = [0]
    while stack:
        v = stack.pop()
        for w in adjacency[v]:
            if w not in seen:
                seen.add(w)
                stack.append(w)
    return len(seen) == len(adjacency)


def exact_treewidth(adjacency_sets):
    """
    Exact 2^n elimination DP. The filled neighbors after eliminating S are
    precisely remaining vertices reachable from v through internal vertices S.
    """
    n = len(adjacency_sets)
    original = [sum(1 << w for w in adjacency_sets[v]) for v in range(n)]
    full = (1 << n) - 1

    @lru_cache(maxsize=None)
    def filled_neighbors(v, eliminated):
        remaining = full ^ eliminated
        remaining &= ~(1 << v)

        reached_eliminated = original[v] & eliminated
        frontier = reached_eliminated
        while frontier:
            bit = frontier & -frontier
            frontier -= bit
            u = bit.bit_length() - 1
            new = original[u] & eliminated & ~reached_eliminated
            reached_eliminated |= new
            frontier |= new

        neighbors = original[v] & remaining
        scan = reached_eliminated
        while scan:
            bit = scan & -scan
            scan -= bit
            u = bit.bit_length() - 1
            neighbors |= original[u] & remaining
        return neighbors

    dp = [None] * (1 << n)
    choice = [-1] * (1 << n)
    dp[full] = 0

    for eliminated in range(full - 1, -1, -1):
        if eliminated == full:
            continue
        best = n
        best_v = -1
        remaining = full ^ eliminated
        scan = remaining
        while scan:
            bit = scan & -scan
            scan -= bit
            v = bit.bit_length() - 1
            width_here = filled_neighbors(v, eliminated).bit_count()
            value = max(width_here, dp[eliminated | bit])
            if value < best or (value == best and v < best_v):
                best = value
                best_v = v
        dp[eliminated] = best
        choice[eliminated] = best_v

    order = []
    state = 0
    while state != full:
        v = choice[state]
        order.append(v)
        state |= 1 << v
    return dp[0], order


def color_refinement(group, local_rows, groups, variables, ordinal):
    rows = sorted(local_rows[group], key=lambda r: r["index"])
    nvars = 3811
    var_edges = [[] for _ in range(nvars)]
    row_edges = [[] for _ in rows]

    for rk, row in enumerate(rows):
        for i, a in row["costly_terms"]:
            j = ordinal[i]
            var_edges[j].append((rk, a))
            row_edges[rk].append((j, a))

    def compress(signatures):
        table = {s: k for k, s in enumerate(sorted(set(signatures)))}
        return [table[s] for s in signatures]

    var_colors = compress([
        stable_json(["v", as_int(variables[groups[group][j]].Obj)])
        for j in range(nvars)
    ])
    row_colors = compress([
        stable_json([
            "r",
            relation_key(row["relation"]),
            sorted(Counter(a for _, a in row["costly_terms"]).items()),
        ])
        for row in rows
    ])

    iterations = 0
    while True:
        iterations += 1
        previous_class_counts = (len(set(var_colors)), len(set(row_colors)))
        vs = [
            stable_json([var_colors[j], sorted(
                (a, row_colors[r]) for r, a in var_edges[j]
            )])
            for j in range(nvars)
        ]
        rs = [
            stable_json([row_colors[r], sorted(
                (a, var_colors[j]) for j, a in row_edges[r]
            )])
            for r in range(len(rows))
        ]

        tagged = ["V:" + s for s in vs] + ["R:" + s for s in rs]
        colors = compress(tagged)
        nv = colors[:nvars]
        nr = colors[nvars:]
        current_class_counts = (len(set(nv)), len(set(nr)))
        # Color IDs are canonically renumbered from fresh signatures and need
        # not remain numerically identical.  Because every new signature
        # contains the old color, the partition can only refine; unchanged
        # class counts therefore prove stabilization.
        if current_class_counts == previous_class_counts:
            var_colors, row_colors = nv, nr
            break
        var_colors, row_colors = nv, nr
        assert iterations < 10000

    classes = defaultdict(list)
    for j, color in enumerate(var_colors):
        classes[color].append(j)

    return {
        "iterations": iterations,
        "classes": classes,
        "histogram": sorted(Counter(var_colors).items()),
        "singleton_count": sum(len(v) == 1 for v in classes.values()),
    }


def global_row_signature(row):
    return stable_json([
        relation_key(row["relation"]),
        row["coordinate_terms"],
    ])


def test_transposition_automorphism(
        group, a, b, coordinate_to_index, incidence_by_index,
        original_signatures, variables):
    ia = coordinate_to_index[(group, a)]
    ib = coordinate_to_index[(group, b)]

    if not close(variables[ia].Obj, variables[ib].Obj):
        return False

    # Only rows incident to one of the swapped columns can change.  The first
    # version rescanned every projected row for every transposition; this
    # exact inverted index gives the same multiset test in near-linear time.
    affected_by_row = {
        row["index"]: row
        for row in incidence_by_index[ia] + incidence_by_index[ib]
    }
    affected = [affected_by_row[k] for k in sorted(affected_by_row)]
    old = Counter(original_signatures[row["index"]] for row in affected)
    new = Counter()

    for row in affected:
        transformed = []
        for g, j, coefficient in row["coordinate_terms"]:
            if g == group:
                if j == a:
                    j = b
                elif j == b:
                    j = a
            transformed.append((g, j, coefficient))
        transformed.sort()
        new[stable_json([relation_key(row["relation"]), transformed])] += 1

    return old == new


def exchangeability_analysis(projected, local, groups, variables, owner, ordinal):
    reports = []
    all_true = True

    coordinate_to_index = {
        (g, ordinal[i]): i for i, g in owner.items()
    }
    fixed_row_column_fingerprint = defaultdict(list)
    for row in projected:
        for i, coefficient in row["costly_terms"]:
            fixed_row_column_fingerprint[i].append(
                (row["index"], coefficient)
            )

    for g in range(12):
        refined = color_refinement(g, local, groups, variables, ordinal)
        ambiguity = sorted(
            [sorted(v) for v in refined["classes"].values() if len(v) > 1],
            key=lambda x: (-len(x), x)
        )
        class70 = [x for x in ambiguity if len(x) == 70]
        assert len(class70) == 1, (g, [len(x) for x in ambiguity[:10]])
        members = class70[0]
        anchor = members[0]

        tests = []
        anchor_index = coordinate_to_index[(g, anchor)]
        anchor_fingerprint = fixed_row_column_fingerprint[anchor_index]
        anchor_objective = variables[anchor_index].Obj
        for other in members[1:]:
            other_index = coordinate_to_index[(g, other)]
            valid = (
                close(anchor_objective, variables[other_index].Obj)
                and anchor_fingerprint ==
                    fixed_row_column_fingerprint[other_index]
            )
            tests.append([anchor, other, valid])
            if not valid:
                all_true = False

        full_symmetric = all(x[2] for x in tests)
        reports.append({
            "group": g,
            "stable_refinement_iterations": refined["iterations"],
            "stable_singleton_count": refined["singleton_count"],
            "ambiguity_class_sizes": [len(x) for x in ambiguity],
            "class70_local_ordinals": members,
            "anchor_transposition_tests": tests,
            "full_S70_exchangeability_proved": full_symmetric,
            "proof_semantics":
                "Each valid anchor transposition swaps two variables with "
                "identical objective coefficients and identical coefficient "
                "vectors under fixed projected-row indices. It therefore "
                "preserves every projected row individually. The 69 valid "
                "anchor transpositions generate the full symmetric group.",
        })

    return {
        "all_groups_have_one_70_way_class": True,
        "all_70_way_classes_are_true_global_exchangeability_classes": all_true,
        "groups": reports,
    }


def balanced_network(group, local_rows, groups, ordinal):
    balanced = []
    for row in local_rows[group]:
        hist = Counter(a for _, a in row["costly_terms"])
        exact_zero_relation = (
            row["relation"] == {
                "kind": "eq_interval", "minimum": 0, "maximum": 0
            }
            or row["relation"] == {"kind": "eq_set", "values": [0]}
        )
        if (
            exact_zero_relation
            and len(row["costly_terms"]) == 14
            and hist == Counter({-1: 7, 1: 7})
            and not row["auxiliary_terms"]
        ):
            balanced.append(row)

    assert len(balanced) == 412
    row_node = {row["index"]: k for k, row in enumerate(sorted(
        balanced, key=lambda r: r["index"]
    ))}

    minus = [[] for _ in range(3811)]
    plus = [[] for _ in range(3811)]
    for row in balanced:
        node = row_node[row["index"]]
        for i, a in row["costly_terms"]:
            j = ordinal[i]
            if a == -1:
                minus[j].append(node)
            elif a == 1:
                plus[j].append(node)
            else:
                raise AssertionError("nonunit balanced coefficient")

    assert all(len(x) <= 1 for x in minus)
    assert all(len(x) <= 1 for x in plus)

    endpoints = []
    for j in range(3811):
        src = minus[j][0] if minus[j] else None
        dst = plus[j][0] if plus[j] else None
        endpoints.append((src, dst))

    return {
        "balanced_rows": balanced,
        "endpoints": endpoints,
        "both_endpoints": sum(a is not None and b is not None for a, b in endpoints),
        "source_boundary": sum(a is None and b is not None for a, b in endpoints),
        "sink_boundary": sum(a is not None and b is None for a, b in endpoints),
        "free": sum(a is None and b is None for a, b in endpoints),
    }


def enumerate_primitives(network, deadline, max_primitives, progress_prefix):
    """
    Enumerate simple directed cycles, boundary-to-boundary paths, and free
    variables of length <=5. Every balanced selected arc set decomposes into
    these primitives.
    """
    endpoints = network["endpoints"]
    outgoing = defaultdict(list)
    boundary_starts = []
    free = []

    for j, (src, dst) in enumerate(endpoints):
        if src is not None:
            outgoing[src].append(j)
        elif dst is not None:
            boundary_starts.append(j)
        else:
            free.append(j)

    for node in outgoing:
        outgoing[node].sort()

    primitives = set()
    complete = True
    stop_reason = None
    generated_walks = 0

    def add(selected):
        nonlocal complete, stop_reason
        primitives.add(tuple(sorted(selected)))
        if len(primitives) > max_primitives:
            complete = False
            stop_reason = "max_primitives"
            return False
        if time.monotonic() >= deadline:
            complete = False
            stop_reason = "time_limit"
            return False
        return True

    for j in free:
        if not add((j,)):
            break

    # Boundary-to-boundary simple paths.
    if complete:
        for start_arc in boundary_starts:
            src, dst = endpoints[start_arc]
            assert src is None and dst is not None

            def path_dfs(selected, current, visited_nodes):
                nonlocal generated_walks, complete, stop_reason
                if not complete or len(selected) >= 5:
                    return
                for edge in outgoing[current]:
                    if edge in selected:
                        continue
                    generated_walks += 1
                    _, nxt = endpoints[edge]
                    new_selected = selected + (edge,)
                    if nxt is None:
                        if not add(new_selected):
                            return
                    elif nxt not in visited_nodes:
                        path_dfs(new_selected, nxt, visited_nodes | {nxt})
                    if not complete:
                        return

            path_dfs((start_arc,), dst, {dst})
            if not complete:
                break

    # Simple directed cycles. Requiring start_node=min(cycle nodes) removes
    # rotational duplication; tuple-set deduplication handles parallel choices.
    if complete:
        for start_node in range(412):

            def cycle_dfs(selected, current, visited_nodes):
                nonlocal generated_walks, complete
                if not complete or len(selected) >= 5:
                    return
                for edge in outgoing[current]:
                    if edge in selected:
                        continue
                    generated_walks += 1
                    _, nxt = endpoints[edge]
                    if nxt is None:
                        continue
                    new_selected = selected + (edge,)
                    if nxt == start_node:
                        if start_node == min(visited_nodes):
                            if not add(new_selected):
                                return
                    elif nxt not in visited_nodes:
                        cycle_dfs(new_selected, nxt, visited_nodes | {nxt})
                    if not complete:
                        return

            cycle_dfs((), start_node, {start_node})
            if not complete:
                break

    ordered = sorted(primitives, key=lambda p: (len(p), p))
    print("%s primitives=%d complete=%s" %
          (progress_prefix, len(ordered), complete), flush=True)

    return ordered, {
        "complete": complete,
        "stop_reason": stop_reason,
        "primitive_count": len(ordered),
        "counts_by_cardinality": {
            str(k): sum(len(p) == k for p in ordered) for k in range(1, 6)
        },
        "generated_walk_extensions": generated_walks,
        "decomposition_theorem_used":
            "Any selected directed multigraph balanced at all 412 internal "
            "nodes decomposes into edge-disjoint directed cycles and directed "
            "boundary-to-boundary paths; variables with no balanced-row "
            "endpoint are singleton primitives.",
    }


def row_possible_with_slots(row, selected_set, remaining_slots, ordinal):
    activity = 0
    available_coefficients = []

    for i, a in row["costly_terms"]:
        j = ordinal[i]
        if j in selected_set:
            activity += a
        else:
            available_coefficients.append(a)

    negatives = sorted(a for a in available_coefficients if a < 0)
    positives = sorted((a for a in available_coefficients if a > 0), reverse=True)
    minimum = activity + sum(negatives[:remaining_slots])
    maximum = activity + sum(positives[:remaining_slots])

    relation = row["relation"]
    kind = relation["kind"]
    if kind == "le":
        return minimum <= relation["bound"]
    if kind == "ge":
        return maximum >= relation["bound"]
    if kind == "eq_interval":
        return not (
            maximum < relation["minimum"] or minimum > relation["maximum"]
        )
    return any(minimum <= value <= maximum for value in relation["values"])


def exact_pattern_feasible(rows, selected_set, ordinal):
    for row in rows:
        activity = sum(
            a for i, a in row["costly_terms"] if ordinal[i] in selected_set
        )
        if not relation_holds(row["relation"], activity):
            return False
    return True


def partial_pattern_possible(rows, selected_set, remaining_slots, ordinal):
    return all(
        row_possible_with_slots(row, selected_set, remaining_slots, ordinal)
        for row in rows
    )


def enumerate_patterns(primitives, primitive_complete, local_rows, ordinal,
                       costs, deadline, max_states, progress_prefix, db, type_id):
    """
    Exact closure under unions of edge-disjoint primitives up to cardinality 5.
    The closure is complete iff primitive generation and this state expansion
    both complete. Partial-row propagation is a safe relaxation only: it may
    retain extra states but never removes a completable local pattern.
    """
    states = [set() for _ in range(6)]
    states[0].add(())
    feasible = [set() for _ in range(6)]
    complete = primitive_complete
    stop_reason = None
    expanded = 0
    pruned = 0

    if exact_pattern_feasible(local_rows, set(), ordinal):
        feasible[0].add(())

    for k in range(6):
        if not complete:
            break
        snapshot = sorted(states[k])
        for index, pattern in enumerate(snapshot):
            if time.monotonic() >= deadline:
                complete = False
                stop_reason = "time_limit"
                break

            selected = set(pattern)
            for primitive in primitives:
                nk = k + len(primitive)
                if nk > 5:
                    break
                if selected.intersection(primitive):
                    continue

                union = tuple(sorted(selected.union(primitive)))
                nk = len(union)
                if nk > 5 or union in states[nk]:
                    continue

                if not partial_pattern_possible(
                    local_rows, set(union), 5 - nk, ordinal
                ):
                    pruned += 1
                    continue

                states[nk].add(union)
                expanded += 1
                if sum(len(s) for s in states) > max_states:
                    complete = False
                    stop_reason = "max_states"
                    break

                if exact_pattern_feasible(local_rows, set(union), ordinal):
                    feasible[nk].add(union)

            if not complete:
                break

            if index and index % 10000 == 0:
                print("%s k=%d processed=%d states=%d feasible=%d" % (
                    progress_prefix, k, index,
                    sum(len(s) for s in states),
                    sum(len(s) for s in feasible)
                ), flush=True)

    cursor = db.cursor()
    for k in range(6):
        records = []
        for pattern in sorted(feasible[k]):
            cost = sum(costs[j] for j in pattern)
            records.append((
                type_id,
                k,
                ",".join(map(str, pattern)),
                cost,
                digest(pattern),
            ))
            if len(records) >= 10000:
                cursor.executemany(
                    "INSERT OR REPLACE INTO patterns"
                    "(type_id,k,ordinals,cost,pattern_hash) VALUES(?,?,?,?,?)",
                    records
                )
                db.commit()
                records = []
        if records:
            cursor.executemany(
                "INSERT OR REPLACE INTO patterns"
                "(type_id,k,ordinals,cost,pattern_hash) VALUES(?,?,?,?,?)",
                records
            )
            db.commit()

    result = {
        "complete": complete,
        "stop_reason": stop_reason,
        "balanced_states_by_cardinality": {
            str(k): len(states[k]) for k in range(6)
        },
        "locally_feasible_patterns_by_cardinality": {
            str(k): len(feasible[k]) for k in range(6)
        },
        "counts_are_exact": complete,
        "if_incomplete_counts_are": "certified lower bounds",
        "expanded_states": expanded,
        "partial_states_pruned_by_exact_row_bounds": pruned,
        "total_retained_states": sum(len(s) for s in states),
        "total_feasible_patterns": sum(len(s) for s in feasible),
    }
    print("%s patterns=%d complete=%s" % (
        progress_prefix, result["total_feasible_patterns"], complete
    ), flush=True)
    return result


def create_artifact(path):
    if os.path.exists(path):
        os.remove(path)
    db = sqlite3.connect(path)
    db.executescript("""
        PRAGMA journal_mode=OFF;
        PRAGMA synchronous=OFF;
        CREATE TABLE metadata (
            key TEXT PRIMARY KEY,
            value_json TEXT NOT NULL
        );
        CREATE TABLE projected_rows (
            row_index INTEGER PRIMARY KEY,
            row_name TEXT NOT NULL,
            groups_json TEXT NOT NULL,
            relation_json TEXT NOT NULL,
            terms_json TEXT NOT NULL,
            row_class TEXT NOT NULL
        );
        CREATE TABLE local_constraints (
            type_id INTEGER NOT NULL,
            row_index INTEGER NOT NULL,
            relation_json TEXT NOT NULL,
            ordinal_terms_json TEXT NOT NULL,
            PRIMARY KEY(type_id,row_index)
        );
        CREATE TABLE primitives (
            type_id INTEGER NOT NULL,
            cardinality INTEGER NOT NULL,
            ordinals TEXT NOT NULL,
            primitive_hash TEXT NOT NULL,
            PRIMARY KEY(type_id,ordinals)
        );
        CREATE TABLE patterns (
            type_id INTEGER NOT NULL,
            k INTEGER NOT NULL,
            ordinals TEXT NOT NULL,
            cost INTEGER NOT NULL,
            pattern_hash TEXT NOT NULL,
            PRIMARY KEY(type_id,ordinals)
        );
        CREATE INDEX patterns_by_type_k_cost
            ON patterns(type_id,k,cost);
    """)
    return db


def write_matrix_artifact(db, projected, local, type_ids, type_info):
    cursor = db.cursor()
    rows = []
    for row in projected:
        if len(row["groups"]) == 1:
            cls = "local"
        elif len(row["groups"]) == 2:
            cls = "pairwise"
        else:
            cls = "global"
        rows.append((
            row["index"],
            row["name"],
            stable_json(row["groups"]),
            stable_json(row["relation"]),
            stable_json(row["coordinate_terms"]),
            cls,
        ))
    cursor.executemany(
        "INSERT INTO projected_rows"
        "(row_index,row_name,groups_json,relation_json,terms_json,row_class)"
        " VALUES(?,?,?,?,?,?)",
        rows
    )

    for type_text, info in sorted(type_info.items(), key=lambda z: int(z[0])):
        type_id = int(type_text)
        g = info["representative_group"]
        records = []
        for row in sorted(local[g], key=lambda r: r["index"]):
            terms = sorted((j, a) for _, j, a in row["coordinate_terms"])
            records.append((
                type_id,
                row["index"],
                stable_json(row["relation"]),
                stable_json(terms),
            ))
        cursor.executemany(
            "INSERT INTO local_constraints"
            "(type_id,row_index,relation_json,ordinal_terms_json)"
            " VALUES(?,?,?,?)",
            records
        )
    db.commit()


def _finite_bound(value):
    """Return a JSON-safe finite bound, using None for Gurobi infinity."""
    if abs(float(value)) >= 0.5 * gp.GRB.INFINITY:
        return None
    return num(value)


def _variable_record(variable):
    return {
        "name": variable.VarName,
        "lb": _finite_bound(variable.LB),
        "ub": _finite_bound(variable.UB),
        "vtype": variable.VType,
        "obj": num(variable.Obj),
    }


def _original_row_record(row, variables):
    sense = {"<": "<=", ">": ">=", "=": "="}[row["sense"]]
    return {
        "index": row["index"],
        "name": row["name"],
        "sense": sense,
        "rhs": num(row["rhs"]),
        "terms": [
            [variables[i].VarName, num(coefficient)]
            for i, coefficient in row["terms"]
        ],
    }


def parse_model_exact(model_path):
    """Compatibility export for waima_build_reduced's fresh-row audit.

    This instance has integral matrix data.  Every finite value is checked by
    the consumer and converted to Fraction from its decimal representation.
    """
    model = gp.read(model_path)
    variables = model.getVars()
    rows = extract_rows(model)
    return {
        "variables": [_variable_record(variable) for variable in variables],
        "rows": [_original_row_record(row, variables) for row in rows],
    }


def _projected_row_record(row, variables):
    record = {
        "index": row["index"],
        "name": row["name"],
        "terms": [
            [variables[i].VarName, coefficient]
            for i, coefficient in row["costly_terms"]
        ],
    }
    relation = row["relation"]
    kind = relation["kind"]
    if kind == "le":
        record.update({"sense": "<=", "rhs": relation["bound"]})
    elif kind == "ge":
        record.update({"sense": ">=", "rhs": relation["bound"]})
    elif kind == "eq_interval":
        if relation["minimum"] == relation["maximum"]:
            record.update({"sense": "=", "rhs": relation["minimum"]})
        else:
            record.update({
                "sense": "interval",
                "lb": relation["minimum"],
                "ub": relation["maximum"],
            })
    elif kind == "eq_set":
        record["allowed_values"] = list(relation["values"])
    else:
        raise AssertionError("unsupported projected relation %r" % kind)
    return record


def build_verified_reduction(model_path, solution_path):
    """Export the already asserted exact reduction through a stable schema."""
    model = gp.read(model_path)
    variables = model.getVars()
    rows = extract_rows(model)
    supplied = parse_solution(solution_path)
    values = [float(supplied.get(variable.VarName, 0.0)) for variable in variables]

    assert model.ModelSense == 1
    assert model.NumVars == 93318
    assert model.NumConstrs == 52983
    assert model.NumNZs == 1250570

    continuous_set = {i for i, v in enumerate(variables) if v.VType == "C"}
    costly_set = {i for i, v in enumerate(variables) if abs(v.Obj) > TOL}
    assert continuous_set == set(range(14))
    assert len(costly_set) == 45732

    pairs, pair_rows, pair_use = find_pairs(rows, variables)
    assert len(pairs) == 45732
    assert len(pair_rows) == 45732
    assert len(pair_use) == 91464
    assert all(count == 1 for count in pair_use.values())

    copy_set = {copy for _, _, copy in pairs}
    assert {costly for _, costly, _ in pairs} == costly_set
    substitution = list(range(model.NumVars))
    for _, costly, copy in pairs:
        substitution[copy] = costly
    substituted = substitute_rows(rows, substitution)

    groups, owner, ordinal = derive_groups(substituted, costly_set)
    reporting_checks = check_reporting_rows(
        substituted, variables, continuous_set
    )
    assert len(reporting_checks) == 14

    auxiliary_set = {
        i for i, variable in enumerate(variables)
        if variable.VType != "C"
        and i not in costly_set
        and i not in copy_set
    }
    assert len(auxiliary_set) == 1840
    remaining = [
        row for row in substituted
        if row["index"] not in pair_rows and row["index"] not in set(range(14))
    ]
    assert len(remaining) == 7237
    projected = project_rows(remaining, costly_set, auxiliary_set, values)
    attach_coordinates(projected, owner, ordinal)
    local, pairwise, global_rows = classify_rows(projected)

    group_records = []
    for group in range(12):
        refinement = color_refinement(
            group, local, groups, variables, ordinal
        )
        classes = []
        for color, members in sorted(refinement["classes"].items()):
            classes.append({
                "ordinal": color,
                "members": [
                    variables[groups[group][j]].VarName for j in sorted(members)
                ],
            })
        assert sum(len(item["members"]) for item in classes) == 3811
        assert sorted(len(item["members"]) for item in classes)[-1] == 70
        assert sum(len(item["members"]) == 70 for item in classes) == 1
        group_records.append({
            "index": group,
            "members": [variables[i].VarName for i in groups[group]],
            "color_classes": classes,
        })

    auxiliary_witnesses = []
    seen_auxiliaries = set()
    for row in projected:
        for index, _ in row["auxiliary_terms"]:
            assert index not in seen_auxiliaries
            seen_auxiliaries.add(index)
            auxiliary_witnesses.append({
                "var": variables[index].VarName,
                "row": row["index"],
            })
    assert seen_auxiliaries == auxiliary_set

    public_values = {
        variable.VarName: num(supplied.get(variable.VarName, 0.0))
        for variable in variables
    }

    return {
        "projected_variables": [
            _variable_record(variables[index]) for index in sorted(costly_set)
        ],
        "projected_rows": [
            _projected_row_record(row, variables) for row in projected
        ],
        "groups": group_records,
        "copy_map": {
            variables[copy].VarName: variables[costly].VarName
            for _, costly, copy in pairs
        },
        "auxiliary_witnesses": sorted(
            auxiliary_witnesses, key=lambda item: item["row"]
        ),
        "reporting_witnesses": [
            {"var": variables[index].VarName, "row": index}
            for index in sorted(continuous_set)
        ],
        "public_values": public_values,
        "row_classes": {
            "local": sum(len(local[group]) for group in range(12)),
            "pair": len(pairwise),
            "cover": len(global_rows),
        },
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("model")
    parser.add_argument("solution")
    parser.add_argument("report")
    parser.add_argument("--artifact", default=None)
    parser.add_argument("--time-limit", type=float, default=600.0)
    parser.add_argument("--max-primitives", type=int, default=2_000_000)
    parser.add_argument("--max-states", type=int, default=2_000_000)
    args = parser.parse_args()

    artifact_path = args.artifact or (args.report + ".patterns.sqlite")
    start_time = time.monotonic()
    deadline = start_time + args.time_limit

    print("Reading model and public solution", flush=True)
    model = gp.read(args.model)
    variables = model.getVars()
    rows = extract_rows(model)
    solution = parse_solution(args.solution)
    values = [float(solution.get(v.VarName, 0.0)) for v in variables]

    assert model.ModelSense == 1
    assert model.NumVars == 93318
    assert model.NumConstrs == 52983
    assert model.NumNZs == 1250570

    continuous_set = {i for i, v in enumerate(variables) if v.VType == "C"}
    costly_set = {i for i, v in enumerate(variables) if abs(v.Obj) > TOL}
    assert continuous_set == set(range(14))
    assert len(costly_set) == 45732

    pairs, pair_rows, pair_use = find_pairs(rows, variables)
    assert len(pairs) == 45732
    assert len(pair_rows) == 45732
    assert len(pair_use) == 91464
    assert all(n == 1 for n in pair_use.values())

    copy_set = {copy for _, _, copy in pairs}
    assert {costly for _, costly, _ in pairs} == costly_set

    substitution = list(range(model.NumVars))
    for _, costly, copy in pairs:
        substitution[copy] = costly
    sub_rows = substitute_rows(rows, substitution)

    groups, owner, ordinal = derive_groups(sub_rows, costly_set)
    reporting_checks = check_reporting_rows(sub_rows, variables, continuous_set)

    auxiliary_set = {
        i for i, v in enumerate(variables)
        if v.VType != "C" and i not in costly_set and i not in copy_set
    }
    assert len(auxiliary_set) == 1840

    remaining = [
        row for row in sub_rows
        if row["index"] not in pair_rows and row["index"] not in set(range(14))
    ]
    assert len(remaining) == 7237

    projected = project_rows(remaining, costly_set, auxiliary_set, values)
    attach_coordinates(projected, owner, ordinal)
    local, pairwise, global_rows = classify_rows(projected)
    type_ids, type_info = identify_local_types(local)

    print("Extracted 6632 local, 584 pairwise, 21 global rows", flush=True)
    pair_graph = pairwise_graph_analysis(pairwise)
    print("Pair graph edges=%d treewidth=%d" % (
        pair_graph["edge_count"], pair_graph["exact_treewidth"]
    ), flush=True)

    exchangeability = exchangeability_analysis(
        projected, local, groups, variables, owner, ordinal
    )
    print("S70 exchangeability across all groups: %s" %
          exchangeability[
              "all_70_way_classes_are_true_global_exchangeability_classes"
          ], flush=True)

    db = create_artifact(artifact_path)
    write_matrix_artifact(db, projected, local, type_ids, type_info)

    metadata = {
        "instance": "neos-4533806-waima",
        "model_path": os.path.abspath(args.model),
        "solution_path": os.path.abspath(args.solution),
        "type_ids_by_group": type_ids,
        "type_info": type_info,
        "pair_graph": pair_graph,
    }
    db.execute(
        "INSERT INTO metadata(key,value_json) VALUES(?,?)",
        ("matrix_metadata", stable_json(metadata))
    )
    db.commit()

    generation = {}
    processed_types = set()
    for g in range(12):
        type_id = type_ids[g]
        if type_id in processed_types:
            continue
        processed_types.add(type_id)

        if time.monotonic() >= deadline:
            generation[str(type_id)] = {
                "representative_group": g,
                "not_started": True,
                "reason": "time_limit",
            }
            continue

        network = balanced_network(g, local, groups, ordinal)
        primitives, primitive_status = enumerate_primitives(
            network, deadline, args.max_primitives,
            "type%d/group%d" % (type_id, g)
        )

        db.executemany(
            "INSERT OR REPLACE INTO primitives"
            "(type_id,cardinality,ordinals,primitive_hash) VALUES(?,?,?,?)",
            [
                (
                    type_id,
                    len(p),
                    ",".join(map(str, p)),
                    digest(p),
                )
                for p in primitives
            ]
        )
        db.commit()

        costs = {
            j: as_int(variables[groups[g][j]].Obj) for j in range(3811)
        }
        pattern_status = enumerate_patterns(
            primitives,
            primitive_status["complete"],
            local[g],
            ordinal,
            costs,
            deadline,
            args.max_states,
            "type%d/group%d" % (type_id, g),
            db,
            type_id,
        )

        generation[str(type_id)] = {
            "representative_group": g,
            "network": {
                "balanced_row_count": len(network["balanced_rows"]),
                "variables_with_both_endpoints": network["both_endpoints"],
                "source_boundary_variables": network["source_boundary"],
                "sink_boundary_variables": network["sink_boundary"],
                "free_variables": network["free"],
                "all_columns_have_at_most_one_source_and_one_destination": True,
            },
            "primitive_generation": primitive_status,
            "pattern_generation": pattern_status,
        }

    selected_patterns = []
    for g in range(12):
        selected = [
            ordinal[i] for i in groups[g] if values[i] > 0.5
        ]
        selected_patterns.append({
            "group": g,
            "type_id": type_ids[g],
            "selected_local_ordinals": selected,
            "cardinality": len(selected),
            "cost": sum(
                as_int(variables[groups[g][j]].Obj) for j in selected
            ),
            "all_local_constraints_satisfied": all(
                exact_pattern_feasible(local[g], set(selected), ordinal)
                for _ in [0]
            ),
            "pairwise_contributions": [
                [
                    row["index"],
                    sum(
                        a for gg, j, a in row["coordinate_terms"]
                        if gg == g and j in set(selected)
                    )
                ]
                for row in sorted(pairwise, key=lambda r: r["index"])
            ],
            "global_contributions": [
                [
                    row["index"],
                    sum(
                        a for gg, j, a in row["coordinate_terms"]
                        if gg == g and j in set(selected)
                    )
                ]
                for row in sorted(global_rows, key=lambda r: r["index"])
            ],
        })

    assert [x["cardinality"] for x in selected_patterns] == \
           [5, 5, 5, 5, 5, 3, 5, 5, 5, 5, 5, 5]
    assert [x["cost"] for x in selected_patterns] == \
           [327, 392, 327, 466, 456, 415, 355, 410, 396, 396, 474, 456]
    assert all(x["all_local_constraints_satisfied"] for x in selected_patterns)

    all_generation_complete = (
        len(generation) == 2
        and all(
            not x.get("not_started")
            and x["primitive_generation"]["complete"]
            and x["pattern_generation"]["complete"]
            for x in generation.values()
        )
    )

    treewidth = pair_graph["exact_treewidth"]
    if all_generation_complete and treewidth <= 3:
        next_method = "exact_junction_tree_over_complete_local_patterns"
        decisive_reason = (
            "Both local-type pattern sets are complete and the exact pairwise "
            "coupling graph has treewidth at most 3."
        )
    elif all_generation_complete:
        next_method = "exact_reduced_pattern_master_with_custom_branch_and_bound"
        decisive_reason = (
            "Both local-type pattern sets are complete, but the pairwise graph "
            "is not sufficiently narrow for the preferred junction tree."
        )
    elif any(
        x.get("primitive_generation", {}).get("complete")
        and not x.get("pattern_generation", {}).get("complete")
        for x in generation.values()
    ):
        next_method = "branch_and_price_with_network_primitive_pricing"
        decisive_reason = (
            "The network primitive basis is complete but explicit pattern "
            "closure exceeded a declared resource limit."
        )
    else:
        next_method = "strengthen_network_semantics_before_certifying_search"
        decisive_reason = (
            "At least one primitive basis is incomplete, so the current "
            "artifact cannot certify exhaustive local pricing."
        )

    report = {
        "instance": "neos-4533806-waima",
        "read_only_guarantee": {
            "gurobi_used_only_for_reading_and_sparse_attribute_access": True,
            "optimize_called": False,
            "presolve_called": False,
            "computeIIS_called": False,
        },
        "verified_reduction": {
            "aggregation_pairs": len(pairs),
            "reporting_rows_removed": 14,
            "reporting_checks": reporting_checks,
            "degree_one_auxiliaries_projected": len(auxiliary_set),
            "projected_rows": len(projected),
            "local_rows": sum(len(local[g]) for g in range(12)),
            "pairwise_rows": len(pairwise),
            "global_rows": len(global_rows),
            "local_row_counts": [len(local[g]) for g in range(12)],
            "local_types": type_info,
        },
        "pairwise_coupling_graph": pair_graph,
        "exchangeability_test": exchangeability,
        "candidate_generation": generation,
        "public_incumbent_patterns": selected_patterns,
        "artifact": {
            "path": os.path.abspath(artifact_path),
            "format": "SQLite3",
            "tables": [
                "metadata",
                "projected_rows",
                "local_constraints",
                "primitives",
                "patterns",
            ],
            "pattern_completeness_must_be_read_from":
                "candidate_generation.<type>.pattern_generation.complete",
        },
        "route_decision": {
            "all_local_pattern_sets_complete": all_generation_complete,
            "exact_pair_graph_treewidth": treewidth,
            "four_144_row_blocks_repeat_same_pair_schedule":
                pair_graph[
                    "four_blocks_have_identical_ordered_group_pair_schedule"
                ],
            "four_time_or_layer_family_test":
                pair_graph["four_time_or_layer_families_supported"],
            "true_70_way_exchangeability":
                exchangeability[
                    "all_70_way_classes_are_true_global_exchangeability_classes"
                ],
            "selected_next_method": next_method,
            "decisive_reason": decisive_reason,
            "certificate_warning":
                "No pattern-based optimality claim is valid unless primitive "
                "and pattern generation are both marked complete for both "
                "local matrix types.",
        },
        "resource_use": {
            "declared_time_limit_seconds": args.time_limit,
            "elapsed_seconds": time.monotonic() - start_time,
            "max_primitives_per_type": args.max_primitives,
            "max_retained_states_per_type": args.max_states,
            "solver_optimization_seconds": 0,
        },
    }

    db.execute(
        "INSERT OR REPLACE INTO metadata(key,value_json) VALUES(?,?)",
        ("final_route_decision", stable_json(report["route_decision"]))
    )
    db.commit()
    db.close()

    encoded = stable_json(report).encode("ascii")
    if len(encoded) + 1 >= REPORT_LIMIT:
        raise RuntimeError(
            "JSON report is %d bytes, exceeding 2 MB" % (len(encoded) + 1)
        )

    with open(args.report, "wb") as f:
        f.write(encoded)
        f.write(b"\n")

    print("Report: %s (%d bytes)" %
          (os.path.abspath(args.report), len(encoded) + 1), flush=True)
    print("Artifact: %s" % os.path.abspath(artifact_path), flush=True)
    print("Generation complete: %s" % all_generation_complete, flush=True)
    print("NEXT_METHOD=%s" % next_method, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
