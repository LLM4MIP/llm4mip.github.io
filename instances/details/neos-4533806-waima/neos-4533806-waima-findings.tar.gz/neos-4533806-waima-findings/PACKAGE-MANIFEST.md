# Package manifest: neos-4533806-waima

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 33
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/baseline-result.json`
- `artifacts/decomposition-report.json`
- `artifacts/inspect-report.json`
- `artifacts/pairgraph-diagnostic.json`
- `artifacts/path-lns-run/best-original.sol.gz`
- `artifacts/path-lns-run/neighborhood-01-groups-0-1-2.log`
- `artifacts/path-lns-run/neighborhood-02-groups-3-4-5.log`
- `artifacts/path-lns-run/neighborhood-03-groups-6-7-8.log`
- `artifacts/path-lns-run/neighborhood-04-groups-9-10-11.log`
- `artifacts/path-lns-run/neighborhood-05-groups-0-1-2-3-4-5.log`
- `artifacts/path-lns-run/neighborhood-06-groups-0-1-2-6-7-8.log`
- `artifacts/path-lns-run/neighborhood-07-groups-0-1-2-9-10-11.log`
- `artifacts/path-lns-run/neighborhood-08-groups-3-4-5-6-7-8.log`
- `artifacts/path-lns-run/neighborhood-09-groups-3-4-5-9-10-11.log`
- `artifacts/path-lns-run/neighborhood-10-groups-6-7-8-9-10-11.log`
- `artifacts/path-lns-run/result.json`
- `artifacts/reduced-build/aggregated.mps.gz`
- `artifacts/reduced-build/aggregation-map.json`
- `artifacts/reduced-build/build-report.json`
- `artifacts/reduced-build/public-start.mst`
- `artifacts/reduced-build/reconstructed-public.sol.gz`
- `artifacts/semantics-report.json`
- `artifacts/structure.json`
- `logs/baseline-solver.log`
- `logs/lns-899-driver.log`
- `logs/solve-900-driver.log`
- `scripts/waima_build_reduced.py`
- `scripts/waima_pairgraph.py`
- `scripts/waima_path_lns.py`
- `scripts/waima_solve_reduced.py`
- `solutions/neos-4533806-waima-4870-audited.sol.gz`
- `solutions/neos-4533806-waima-public-1.sol.gz`

## Excluded files

- `input/neos-4533806-waima.mps.gz (4469920 bytes; raw benchmark input; sha256 d5dfd8c8edb4ea12626e11277eccea8cca593d6b74c34d5e7403adc6dddc9bdb)`
