# Package manifest: gmut-76-40

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 9
Excluded source files: 0

## Included files

- `README.md`
- `artifacts/result.json`
- `artifacts/strict-repair-audit.txt`
- `input/README.md`
- `input/SHA256SUMS`
- `logs/baseline-numerical.log`
- `scripts/repair_official_id3.py`
- `solutions/official-id3.sol.gz`
- `solutions/strict-repaired.sol`

## Excluded files

- None
