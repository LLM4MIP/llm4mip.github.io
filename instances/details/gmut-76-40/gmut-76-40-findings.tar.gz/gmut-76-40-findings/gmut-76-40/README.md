# `gmut-76-40` — strict incumbent repair; global optimum open

Official MIPLIB page: <https://miplib.zib.de/instance_details_gmut-76-40.html>

## Result

The instance remains **globally open**.  The imported material supplies a
solver-free strict repair of MIPLIB solution ID 3, but no optimality
certificate.

| quantity | value | evidence |
|---|---:|---|
| strict feasible upper bound | **`-14169477.7859`** | exact-decimal replay: zero row, bound and integrality violation |
| local numerical lower bound | `-14171086.31587` | Gurobi 13.0.2 log; floating-point branch-and-bound evidence only |
| numerical gap | `0.0114%` | solver-reported |
| global optimum | unknown | no portable dual certificate |

MIPLIB's displayed point `-14169477.79550346` is slightly better
numerically, but the downloaded ID 3 vector contains 14 fractional binary
entries.  Its largest integrality violation is about `7.95e-7`; it is a
tolerance-feasible point, not the strict vector claimed above.

## Repair and structure

The original timber-harvest model has 24,338 variables, including 24,332
binary-valued integer columns and six continuous harvest-age variables, and
2,586 rows.  Rounding the 14 near-integral binary values and rebuilding the
six `H_t` variables from their defining equalities yields
[`strict-repaired.sol`](solutions/strict-repaired.sol).  Exact arithmetic on
the finite-decimal MPS then reports:

```text
objective=-14169477.7859
row violations=0
bound violations=0
integrality violations=0
```

The repair can be regenerated with
[`repair_official_id3.py`](scripts/repair_official_id3.py) after downloading
the original MPS to `input/gmut-76-40.mps.gz`.

The sanitized [baseline log](logs/baseline-numerical.log) is retained only as
numerical lower-bound evidence.  Its source run was configured with a
30-second solver limit but reports 64.62 elapsed seconds, so it is not used for
runtime comparison.

## Evidence boundary

The strict vector is a portable primal certificate.  The lower bound is a
solver number under floating-point tolerances, and the run stopped with a
nonzero gap.  Therefore this package does **not** prove optimality.
