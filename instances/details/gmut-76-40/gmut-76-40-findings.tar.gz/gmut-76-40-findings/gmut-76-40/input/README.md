# Input provenance

The original MPS is intentionally not stored in this repository.

- MIPLIB page: <https://miplib.zib.de/instance_details_gmut-76-40.html>
- Official MPS: <https://miplib.zib.de/WebData/instances/gmut-76-40.mps.gz>
- Expected SHA-256: `0d610ec885bf1dfe36804451c6f449a233fef16ff02a791cf536f9eaa8c252e4`

Download it as `input/gmut-76-40.mps.gz` before replaying the repair.
