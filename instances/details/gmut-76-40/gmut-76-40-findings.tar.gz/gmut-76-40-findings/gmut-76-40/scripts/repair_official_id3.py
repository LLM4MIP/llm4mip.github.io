#!/usr/bin/env python3
"""Make a strict finite-decimal incumbent by rounding ID3 and rebuilding H.

The official ID3 vector contains 14 binary entries within 8e-7 of 0 or 1.
All x variables are rounded to the nearest integer.  Each continuous H_t is
then reconstructed exactly from its defining Sawti_Ht equality using Decimal
arithmetic.  The script verifies every row, bound, and integrality condition
before writing a sparse solution.
"""

from decimal import Decimal, getcontext
from pathlib import Path
import gzip
import importlib.util

getcontext().prec = 60
ZERO = Decimal(0)
ONE = Decimal(1)
ROOT = Path(__file__).resolve().parents[1]
GENERIC = ROOT.parent / "ger50-17-ptp-pop-3t" / "structural" / "audit_solution.py"

spec = importlib.util.spec_from_file_location("decimal_mps_audit", GENERIC)
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)

row_sense, matrix, rhs, objective_row, variables, integers, lower, upper = audit.parse_mps(
    ROOT / "input" / "gmut-76-40.mps.gz"
)
values, _ = audit.parse_solution(ROOT / "solutions" / "official-id3.sol.gz")

fractional_before = []
for variable in integers:
    value = values[variable]
    rounded = value.to_integral_value()
    if value != rounded:
        fractional_before.append((variable, value, rounded))
    values[variable] = rounded

for period in range(1, 7):
    row = f"Sawti_H{period}"
    variable = f"H_{period}"
    coefficient = matrix[row][variable]
    assert coefficient == Decimal(-1)
    other_activity = sum(
        (value * values[name] for name, value in matrix[row].items() if name != variable),
        ZERO,
    )
    values[variable] = (rhs[row] - other_activity) / coefficient

row_violations = []
for row, sense in row_sense.items():
    if sense == "N":
        continue
    activity = sum((coefficient * values[variable] for variable, coefficient in matrix[row].items()), ZERO)
    residual = activity - rhs[row]
    if sense == "E":
        violation = abs(residual)
    elif sense == "L":
        violation = max(residual, ZERO)
    else:
        violation = max(-residual, ZERO)
    row_violations.append((violation, row, residual))

bound_violations = []
for variable in variables:
    violation = ZERO
    if variable in lower:
        violation = max(violation, lower[variable] - values[variable])
    if variable in upper:
        violation = max(violation, values[variable] - upper[variable])
    bound_violations.append((violation, variable, values[variable]))

integer_violations = [
    (abs(values[variable] - values[variable].to_integral_value()), variable, values[variable])
    for variable in integers
]
row_violations.sort(reverse=True)
bound_violations.sort(reverse=True)
integer_violations.sort(reverse=True)
assert row_violations[0][0] == 0
assert bound_violations[0][0] == 0
assert integer_violations[0][0] == 0

objective = sum(
    (coefficient * values[variable] for variable, coefficient in matrix[objective_row].items()),
    ZERO,
)
target = ROOT / "solutions" / "strict-repaired.sol"
with target.open("w", encoding="utf-8") as handle:
    print(f"# Objective value = {objective}", file=handle)
    for variable in sorted(variables):
        if values[variable] != 0:
            print(f"{variable} {values[variable]}", file=handle)

report = ROOT / "artifacts" / "strict-repair-audit.txt"
with report.open("w", encoding="utf-8") as handle:
    print(f"fractional_binary_entries_before={len(fractional_before)}", file=handle)
    for variable, value, rounded in sorted(fractional_before):
        print(f"  {variable}: {value} -> {rounded}", file=handle)
    print(f"strict_repaired_objective={objective}", file=handle)
    print(f"max_row_violation={row_violations[0][0]}", file=handle)
    print(f"max_bound_violation={bound_violations[0][0]}", file=handle)
    print(f"max_integrality_violation={integer_violations[0][0]}", file=handle)
    for period in range(1, 7):
        print(f"H_{period}={values[f'H_{period}']}", file=handle)

print(report.read_text(encoding="utf-8"), end="")
