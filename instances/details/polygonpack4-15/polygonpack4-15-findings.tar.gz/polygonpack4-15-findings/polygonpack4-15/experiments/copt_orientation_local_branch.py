#!/usr/bin/env python3
"""COPT local branching on polygon presence/orientation bits.

The slice-disjunction and coordinate variables remain free.  A radius-two
ball therefore includes one presence add/drop, one orientation replacement,
or one selected/unselected object exchange.  Solver bounds are numerical.
"""

from __future__ import annotations

import argparse
import gzip
import json
import xml.etree.ElementTree as ET
from pathlib import Path

import coptpy as cp
from coptpy import COPT


def read_solution(path: Path) -> dict[str, float]:
    raw = path.read_bytes()
    if raw[:2] == b"\x1f\x8b" or path.suffix == ".gz":
        raw = gzip.decompress(raw)
    text = raw.decode("utf-8", errors="replace")
    values: dict[str, float] = {}
    try:
        root = ET.fromstring(text)
        for node in root.iter():
            if "name" in node.attrib and "value" in node.attrib:
                values[node.attrib["name"]] = float(node.attrib["value"])
        if values:
            return values
    except ET.ParseError:
        pass
    for line in text.splitlines():
        fields = line.split()
        if len(fields) >= 2 and not fields[0].startswith(("#", "=")):
            try:
                values[fields[0]] = float(fields[1])
            except ValueError:
                pass
    return values


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("start", type=Path)
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--radius", type=int, required=True)
    parser.add_argument("--seconds", type=float, default=300.0)
    parser.add_argument("--threads", type=int, default=8)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    supplied = read_solution(args.start)
    model = cp.Envr().createModel(f"polygonpack-orientation-radius-{args.radius}")
    model.read(str(args.mps))
    variables = model.getVars().getAll()
    if len(variables) < 90:
        raise RuntimeError("expected 30 coordinates followed by 60 orientation bits")
    orientations = variables[30:90]
    rounded = {v.name: int(round(supplied.get(v.name, 0.0))) for v in orientations}
    distance_terms = [1 - v if rounded[v.name] else v for v in orientations]
    model.addConstr(cp.quicksum(distance_terms) <= args.radius, name="orientation_local_branch")

    model.setMipStart(variables, [supplied.get(v.name, 0.0) for v in variables])
    model.loadMipStart()
    model.setParam(COPT.Param.Logging, 1)
    model.setLogFile(str(args.outdir / "copt.log"))
    model.setParam(COPT.Param.Threads, args.threads)
    model.setParam(COPT.Param.TimeLimit, args.seconds)
    model.setParam(COPT.Param.RelGap, 0.0)
    try:
        model.setParam(COPT.Param.FeasTol, 1e-9)
    except Exception:
        pass
    try:
        model.setParam(COPT.Param.HeurLevel, 3)
    except Exception:
        pass
    model.solve()

    result = {
        "copt_version": [COPT.VERSION_MAJOR, COPT.VERSION_MINOR, COPT.VERSION_TECHNICAL],
        "cpu_only": True,
        "threads": args.threads,
        "time_limit_seconds": args.seconds,
        "radius_on_60_presence_orientation_bits": args.radius,
        "start": str(args.start),
        "status": int(model.status),
        "has_solution": int(model.hasmipsol),
        "scope": "coordinates and all slice-disjunction variables free",
        "interpretation": (
            "radius 2 includes a one-bit add/drop, a two-bit orientation change, "
            "and a selected/unselected one-for-one exchange"
        ),
    }
    for key, attr in (
        ("objective", "objval"),
        ("best_bound", "bestbnd"),
        ("relative_gap", "mipgap"),
        ("node_count", "nodecnt"),
        ("runtime", "solvingtime"),
    ):
        try:
            result[key] = float(getattr(model, attr))
        except Exception:
            pass
    if model.hasmipsol:
        model.writeSol(str(args.outdir / "incumbent.sol"))
    (args.outdir / "summary.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print("RESULT_JSON=" + json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
