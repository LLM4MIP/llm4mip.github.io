#!/usr/bin/env python3
"""Certify the implied-integrality relaxation used for tokyometro.

This is a structural certificate, not an optimizer run. It checks the exact
row/column patterns used by the argument in ``../structural/README.md``.
"""

from __future__ import annotations

import collections
import gzip
import math
import sys


def read_mps(path: str):
    rows: dict[str, str] = {}
    rhs: dict[str, float] = collections.defaultdict(float)
    cols: dict[str, dict[str, float]] = collections.defaultdict(dict)
    obj: dict[str, float] = collections.defaultdict(float)
    section = ""
    with gzip.open(path, "rt", encoding="iso-8859-1") as stream:
        for raw in stream:
            fields = raw.split()
            if not fields or fields[0] == "*":
                continue
            if fields[0] == "NAME":
                continue
            if fields[0] in {"ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"} and len(fields) == 1:
                section = fields[0]
                continue
            if section == "ROWS":
                rows[fields[1]] = fields[0]
            elif section == "COLUMNS":
                if len(fields) >= 3 and fields[1] == "'MARKER'":
                    continue
                var = fields[0]
                for pos in range(1, len(fields), 2):
                    row, value = fields[pos], float(fields[pos + 1])
                    if rows.get(row) == "N":
                        obj[var] = value
                    else:
                        cols[var][row] = value
            elif section == "RHS":
                for pos in range(1, len(fields), 2):
                    rhs[fields[pos]] = float(fields[pos + 1])
    return rows, rhs, cols, obj


def family(var: str) -> str:
    for prefix in ("dirF-", "dirB-", "bend-", "RPos-", "lambda-", "diff_"):
        if var.startswith(prefix):
            return prefix.rstrip("-").rstrip("_")
    return "retained"


def row_family(row: str) -> str:
    return row.split("-")[0].split("_")[0]


def is_integer(value: float) -> bool:
    return abs(value - round(value)) <= 1e-12


def main(path: str) -> None:
    rows, rhs, cols, obj = read_mps(path)
    row_cols: dict[str, dict[str, float]] = collections.defaultdict(dict)
    for var, incidences in cols.items():
        for row, value in incidences.items():
            row_cols[row][var] = value
    by_family: dict[str, list[str]] = collections.defaultdict(list)
    for var in cols:
        by_family[family(var)].append(var)

    # dirF/dirB are each fixed by one Eq02 equality using only retained alpha
    # variables and integer data.  Their other appearances do not affect this.
    for fam in ("dirF", "dirB"):
        variables = by_family[fam]
        for var in variables:
            defining = [r for r in cols[var] if row_family(r) == "Eq02"]
            assert len(defining) == 1
            row = defining[0]
            assert rows[row] == "E" and is_integer(rhs[row])
            assert is_integer(cols[var][row]) and abs(cols[var][row]) == 1
            assert all(other == var or other.startswith("alpha-") for other in row_cols[row])
        print(f"{fam}: {len(variables)} unit-coefficient integer equalities")

    # Each bend/RPos variable occurs only in its positive-cost objective and an
    # opposed row pair.  Once direction/delta variables are integral, its lower
    # envelope has an integer breakpoint.
    for fam, expected_rows, expected_obj in (("bend", "Eq10", 1.0), ("RPos", "Eq12", 100.0)):
        variables = by_family[fam]
        for var in variables:
            incidences = cols[var]
            assert len(incidences) == 2
            assert {row_family(r) for r in incidences} == {expected_rows}
            assert sorted(incidences.values()) == [-1.0, 1.0]
            assert all(is_integer(rhs[r]) for r in incidences)
            assert obj[var] == expected_obj
            lower = next(r for r, value in incidences.items() if value == 1.0)
            upper = next(r for r, value in incidences.items() if value == -1.0)
            assert rows[lower] == "G" and rows[upper] == "L"
            assert rhs[lower] == rhs[upper]
            lower_rest = {v: a for v, a in row_cols[lower].items() if v != var}
            upper_rest = {v: a for v, a in row_cols[upper].items() if v != var}
            assert lower_rest == upper_rest
            allowed = ("dirF-", "dirB-", "delta") if fam == "bend" else ("dirF-", "dirB-")
            assert all(other.startswith(allowed) for other in lower_rest)
        print(f"{fam}: {len(variables)} opposed integer-breakpoint epigraph pairs")

    # lambda lower bounds are integer because x/y remain integer.  On the
    # EqEqual graph, reducing lambda_i toward its lower bound can increase TV
    # by at most degree(i) per unit.  Since 10 > 0.1*max_degree, every optimal
    # lambda is exactly at its integer lower bound; every optimal diff then is
    # an integer absolute difference.
    lambda_vars = by_family["lambda"]
    diff_vars = by_family["diff"]
    degrees = {}
    for var in lambda_vars:
        eq14 = [r for r in cols[var] if row_family(r) == "Eq14"]
        eqequal = [r for r in cols[var] if row_family(r) == "EqEqual"]
        assert len(eq14) == 4
        assert all(rows[r] == "L" and cols[var][r] == -1 and is_integer(rhs[r]) for r in eq14)
        assert all(
            other == var or other.startswith(("x-", "y-"))
            for row in eq14
            for other in row_cols[row]
        )
        assert len(eqequal) % 2 == 0
        degrees[var] = len(eqequal) // 2
        assert obj[var] == 10.0
    for var in diff_vars:
        incidences = cols[var]
        assert len(incidences) == 2
        assert {row_family(r) for r in incidences} == {"EqEqual"}
        assert all(rows[r] == "L" and value == -1 and is_integer(rhs[r]) for r, value in incidences.items())
        pair = list(incidences)
        assert rhs[pair[0]] == rhs[pair[1]] == 0
        rest0 = {v: a for v, a in row_cols[pair[0]].items() if v != var}
        rest1 = {v: a for v, a in row_cols[pair[1]].items() if v != var}
        assert len(rest0) == len(rest1) == 2
        assert all(other.startswith("lambda-") for other in rest0)
        assert rest1 == {other: -value for other, value in rest0.items()}
        assert obj[var] == 0.1
    max_degree = max(degrees.values())
    assert 10.0 > 0.1 * max_degree
    print(
        f"lambda/diff: {len(lambda_vars)} nodes, {len(diff_vars)} TV edges, "
        f"max_degree={max_degree}, 10 > 0.1*{max_degree}"
    )

    relaxed_count = sum(len(by_family[name]) for name in ("dirF", "dirB", "bend", "RPos", "lambda", "diff"))
    assert relaxed_count == 1874
    assert all(is_integer(value) for value in rhs.values())
    assert all(is_integer(value) for var in cols for value in cols[var].values())
    print(f"certificate=PASS relaxed_variables={relaxed_count}")


if __name__ == "__main__":
    main(sys.argv[1])
