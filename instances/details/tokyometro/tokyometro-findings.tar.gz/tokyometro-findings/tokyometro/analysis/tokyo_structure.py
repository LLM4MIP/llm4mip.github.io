#!/usr/bin/env python3
"""Structural audit of the Tokyo Metro layout MIP."""

from __future__ import annotations

import collections
import gzip
import math
import re
import sys


def opener(path: str):
    return gzip.open(path, "rt", encoding="iso-8859-1") if path.endswith(".gz") else open(path, encoding="iso-8859-1")


def stem(name: str) -> str:
    match = re.match(r"^(.*?)-?\d+(?:-|$)", name)
    return match.group(1).rstrip("-") if match else name


def main(mps_path: str, solution_path: str) -> None:
    rows: dict[str, str] = {}
    rhs: dict[str, float] = {}
    columns: dict[str, dict[str, float]] = collections.defaultdict(dict)
    lower: dict[str, float] = collections.defaultdict(float)
    upper: dict[str, float] = collections.defaultdict(lambda: math.inf)
    integer_vars: set[str] = set()
    section = ""
    in_integer = False
    with opener(mps_path) as stream:
        for raw in stream:
            fields = raw.split()
            if not fields or fields[0] == "*":
                continue
            if fields[0] == "NAME":
                section = "NAME"
                continue
            if fields[0] in {"ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"} and len(fields) == 1:
                section = fields[0]
                continue
            if section == "ROWS":
                rows[fields[1]] = fields[0]
            elif section == "COLUMNS":
                if len(fields) >= 3 and fields[1] == "'MARKER'":
                    in_integer = fields[2] == "'INTORG'"
                    continue
                var = fields[0]
                if in_integer:
                    integer_vars.add(var)
                for pos in range(1, len(fields), 2):
                    columns[var][fields[pos]] = float(fields[pos + 1])
            elif section == "RHS":
                for pos in range(1, len(fields), 2):
                    rhs[fields[pos]] = float(fields[pos + 1])
            elif section == "BOUNDS":
                kind, _, var = fields[:3]
                value = float(fields[3]) if len(fields) > 3 else 0.0
                if kind == "UP":
                    upper[var] = value
                elif kind == "LO":
                    lower[var] = value
                elif kind == "FX":
                    lower[var] = upper[var] = value
                elif kind == "FR":
                    lower[var], upper[var] = -math.inf, math.inf
                elif kind == "MI":
                    lower[var] = -math.inf
                elif kind == "PL":
                    upper[var] = math.inf
                elif kind == "LI":
                    integer_vars.add(var)
                    lower[var] = value
                elif kind == "UI":
                    integer_vars.add(var)
                    upper[var] = value
                elif kind == "BV":
                    integer_vars.add(var)
                    lower[var], upper[var] = 0.0, 1.0

    incumbent: dict[str, float] = {}
    with opener(solution_path) as stream:
        for line in stream:
            fields = line.split()
            if len(fields) == 2 and not fields[0].startswith(("#", "=obj=")):
                incumbent[fields[0]] = float(fields[1])

    constraint_rows = set(rows) - {"obj"}
    row_to_cols = {row: [] for row in constraint_rows}
    for var, entries in columns.items():
        for row, coefficient in entries.items():
            if row != "obj":
                row_to_cols[row].append((var, coefficient))

    binary = {v for v in integer_vars if lower[v] >= 0 and upper[v] == 1}
    general = integer_vars - binary
    print(f"constraints={len(constraint_rows)} variables={len(columns)} integer={len(integer_vars)} binary={len(binary)} general_integer={len(general)}")
    print(f"constraint_nonzeros={sum(len(e) - ('obj' in e) for e in columns.values())}")
    print(f"row_senses={sorted(collections.Counter(rows[r] for r in constraint_rows).items())}")
    print(f"column_degree_histogram={sorted(collections.Counter(len(e) - ('obj' in e) for e in columns.values()).items())}")
    print(f"objective_histogram={sorted(collections.Counter(columns[v].get('obj', 0.0) for v in columns).items())}")

    print("variable_families:")
    families = collections.defaultdict(list)
    for var in columns:
        families[stem(var)].append(var)
    for family, members in sorted(families.items(), key=lambda item: (-len(item[1]), item[0])):
        selected = [incumbent.get(v, 0.0) for v in members if incumbent.get(v, 0.0)]
        obj_values = collections.Counter(columns[v].get("obj", 0.0) for v in members)
        bounds = collections.Counter((lower[v], upper[v]) for v in members)
        print(
            f"  {family}: n={len(members)} bin={sum(v in binary for v in members)} gen={sum(v in general for v in members)} "
            f"selected_nz={len(selected)} selected_sum={sum(selected):.10g} obj={sorted(obj_values.items())} "
            f"bounds={sorted(bounds.items(), key=lambda x: repr(x[0]))}"
        )

    print("row_families:")
    row_families = collections.defaultdict(list)
    for row in constraint_rows:
        match = re.match(r"^(Eq(?:\d+|Equal))", row)
        prefix = match.group(1) if match else row.split("-")[0]
        row_families[prefix].append(row)
    for family, members in sorted(row_families.items()):
        print(
            f"  {family}: n={len(members)} senses={sorted(collections.Counter(rows[r] for r in members).items())} "
            f"nnz={sorted(collections.Counter(len(row_to_cols[r]) for r in members).items())}"
        )

    objective = sum(columns[v].get("obj", 0.0) * value for v, value in incumbent.items())
    violations = []
    binding = collections.Counter()
    for row in constraint_rows:
        lhs = sum(coefficient * incumbent.get(var, 0.0) for var, coefficient in row_to_cols[row])
        rr = rhs.get(row, 0.0)
        sense = rows[row]
        violated = (sense == "E" and abs(lhs - rr) > 1e-6) or (sense == "G" and lhs < rr - 1e-6) or (sense == "L" and lhs > rr + 1e-6)
        if violated:
            violations.append((row, sense, lhs, rr))
        tight = abs(lhs - rr) <= 1e-6
        if tight:
            binding[row.split("-")[0]] += 1
    integral_violations = [v for v, value in incumbent.items() if v in integer_vars and abs(value - round(value)) > 1e-6]
    print(f"incumbent_nonzeros={len(incumbent)} objective={objective:.15g} row_violations={len(violations)} integral_violations={len(integral_violations)}")
    print(f"incumbent_binding_by_family={sorted(binding.items())}")

    signatures = collections.defaultdict(list)
    for var, entries in columns.items():
        signatures[(tuple(sorted(entries.items())), lower[var], upper[var])].append(var)
    duplicates = sorted((group for group in signatures.values() if len(group) > 1), key=len, reverse=True)
    print(f"identical_column_classes={len(duplicates)} vars_in_classes={sum(map(len, duplicates))}")
    print(f"identical_column_size_hist={sorted(collections.Counter(map(len, duplicates)).items())}")
    print(f"largest_identical_columns={duplicates[:10]}")

    unseen_rows = set(constraint_rows)
    components = []
    while unseen_rows:
        seed = unseen_rows.pop()
        component_rows = {seed}
        component_vars = set()
        frontier = [seed]
        while frontier:
            row = frontier.pop()
            for var, _ in row_to_cols[row]:
                if var in component_vars:
                    continue
                component_vars.add(var)
                for other in columns[var]:
                    if other != "obj" and other in unseen_rows:
                        unseen_rows.remove(other)
                        component_rows.add(other)
                        frontier.append(other)
        components.append((component_rows, component_vars))
    components.sort(key=lambda pair: len(pair[1]), reverse=True)
    print(f"connected_components={len(components)} sizes={[(len(r), len(v)) for r, v in components[:30]]}")
    for component_rows, component_vars in components:
        if len(component_vars) <= 3:
            print(f"  tiny_component rows={sorted(component_rows)} vars={sorted(component_vars)}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
