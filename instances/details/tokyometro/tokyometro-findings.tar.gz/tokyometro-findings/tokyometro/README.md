# `tokyometro` — strict incumbent and exact reductions; optimum open

Official MIPLIB page: <https://miplib.zib.de/instance_details_tokyometro.html>

## Result

The instance remains **globally open**. The imported investigation validates
the incumbent and recovers substantial exact structure, but it neither finds
a better feasible layout nor proves the incumbent optimal.

| quantity | value | evidence |
|---|---:|---|
| strict feasible upper bound | **`8263.1`** | exact replay of the original integer model; zero row, bound and integrality violation |
| local numerical lower bound | **`7117.5`** | Gurobi 13.0.2 on the original model, 600 s, two threads |
| numerical gap | `13.8640%` | time-limit result |
| global optimum | unknown | no portable lower-bound or infeasibility certificate |

The validated vector is
[`strict-8263.1.sol`](solutions/strict-8263.1.sol). The original MPS is not
stored here; see [`input/README.md`](input/README.md) for its official MIPLIB
link and hash. The sanitized [600-second log](logs/original-proof-600s.log)
is retained only as floating-point branch-and-bound evidence.

## Recovered structure

This is a connected octilinear metro-map layout model with 239 station
vertices and 311 links, not a set-covering or route-column master. Its 4,537
integer variables include grid coordinates, three direction choices per link,
cyclic-order variables, and epigraph variables for bends, link lengths and
adjacent-length differences. The objective is

```text
100 sum(RPos) + sum(bend) + 10 sum(lambda) + 0.1 sum(diff).
```

The [structural audit](structural/README.md) verifies, among other things:

- 14 isolated leaf gadgets can be fixed and removed exactly;
- 110 wraparound direction choices are provably impossible;
- one station may be anchored to remove two-dimensional translation symmetry;
- bend-wrap symmetry can be removed, and 622 defined direction variables can
  be substituted;
- each local nine-row geometry disjunction has an exact multiple-choice
  convex-hull representation; and
- 13 duplicated bend/difference cost factors can be aggregated while
  preserving the optimum and an explicit lift.

The audit deliberately stops short of claiming these reductions solve the
remaining connected layout core. A reduced MPS was not generated or committed.

## Exact target for a future proof

All objective values lie on a `0.1` lattice. After multiplying the objective
by ten, the incumbent is `82631`; proving the following cutoff infeasible
would establish its optimality:

```text
1000 sum(RPos) + 10 sum(bend) + 100 sum(lambda) + sum(diff) <= 82630.
```

The present `7117.5` lower bound is a numerical solver result, not an
independently checkable certificate, so this package does **not** close the
instance.
