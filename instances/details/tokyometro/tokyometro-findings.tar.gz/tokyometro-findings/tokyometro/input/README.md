# Input provenance

The original MPS is intentionally not stored in this repository.

- MIPLIB page: <https://miplib.zib.de/instance_details_tokyometro.html>
- Official MPS: <https://miplib.zib.de/WebData/instances/tokyometro.mps.gz>
- Expected SHA-256: `18ac2912e6f03494a044463b17296d70d2cb97e094f3def29cba2faa764a17cc`

Download it as `input/tokyometro.mps.gz` before running the structural
verifiers.
