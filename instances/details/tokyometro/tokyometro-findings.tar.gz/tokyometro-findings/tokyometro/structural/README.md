# `tokyometro` structural audit

This is a structural audit, not a proof of optimality and not a new reduced
MPS. The original model is intentionally not stored in this repository; its
download location and expected hash are recorded in
[`../input/README.md`](../input/README.md). The expected replay paths are:

- `../input/tokyometro.mps.gz`
  (`sha256 18ac2912e6f03494a044463b17296d70d2cb97e094f3def29cba2faa764a17cc`)
- `../solutions/strict-8263.1.sol`
  (`sha256 91c6f098926cb99b1a345744b3dcd7edf889252116b2cf0187a75c7ba80cd029`)

The official MIPLIB description calls this a layout model for the Tokyo Metro
map.  Its names recover a compact octilinear graph-layout formulation.  It is
not a set-covering or route-column master, so the CSV suggestion of branch and
price does not match the actual matrix.

## Recovered model

The network has 239 station vertices and 311 distinct links.  It is connected,
has station-degree histogram

```
degree:       1    2   3   4   5  6
stations:    14  150   8  55   8  4
```

and cycle rank `311 - 239 + 1 = 73`.  The variable blocks are:

| block | count | role |
|---|---:|---|
| `x,y` | 239+239 general integer | station grid coordinates |
| `alpha` | 933 binary | one of three allowed directions per link |
| `dirF,dirB` | 311+311 general integer in `[0,7]` | forward/backward direction codes |
| `V` | 622 binary | one cyclic-order break per station incidence list |
| `RPos` | 311 binary | penalty for moving a link off its target direction |
| `bend` | 315 integer in `[0,3]` | circular bend magnitude along a line |
| `delta1,delta2` | 315+315 binary | `-8/0/+8` wrap encoding for a bend |
| `lambda` | 311 nonnegative integer | Chebyshev link length |
| `diff` | 315 nonnegative integer | adjacent-link length difference |

The objective is

```
100 sum(RPos) + sum(bend) + 10 sum(lambda) + 0.1 sum(diff).
```

The 7,719 named constraints partition exactly as follows.

| family | rows | interpretation |
|---|---:|---|
| `Eq01` | 311 | choose exactly one of three directions |
| `Eq02` | 622 | define `dirF` and `dirB` from `alpha` |
| `Eq03` | 2,799 | three-way bounded octilinear geometry disjunction |
| `Eq04` | 239 | choose one cyclic-order break at each station |
| `Eq05` | 622 | strict cyclic ordering of incident directions |
| `Eq10` | 630 | two-sided epigraph of circular bend |
| `Eq12` | 622 | `RPos >= abs(dirF - target_direction)` |
| `Eq14` | 1,244 | `lambda >= abs(dx), abs(dy)` |
| `EqEqual` | 630 | `diff >= abs(lambda_i-lambda_j)` |

There are no identical full columns, identical matrix columns, or identical
raw rows.

## Incumbent validation

The retained strict solution assigns all 4,537 variables, of which 2,277 are
nonzero. Direct evaluation of the original MPS gives:

- no row, bound, or integrality violation (checked exactly for the integer
  constraint data);
- objective `82631/10 = 8263.1`;
- objective split `3200 + 192 + 4850 + 21.1` across
  `RPos`, `bend`, `lambda`, and `diff`;
- every positive-cost epigraph is at its lower envelope:
  `RPos=alpha[off-center]`, `lambda=max(abs(dx),abs(dy))`,
  `bend=abs(direction_difference+8k)`, and
  `diff=abs(lambda_i-lambda_j)`.

Run the independent check from this directory with:

```sh
python3 verify_structure.py
```

The checked output begins with `"status": "PASS"` and reports objective
`"82631/10"`, 110 impossible direction variables, 14 isolated leaf fixings,
24 exact local direction polyhedra, 13 repeated bend/difference groups, and
maximum length-smoothing incidence 6.  `structural_audit.py` produces the full
matrix census and independently recomputes the incumbent.

## Exact feasible-set reductions

### Fourteen isolated leaf gadgets

The bipartite row/column graph has 15 components: one component with 7,691
rows and 4,523 variables, plus fourteen components containing two rows and one
variable each.  Each small component is a degree-one station gadget

```
V = 1
8 V >= 1
V binary.
```

Thus its `V` variable is fixed to one and both rows can be deleted.  This
removes 14 binaries and 28 rows with zero objective offset.  There is no other
exact matrix decomposition.

### 110 impossible direction choices

For link `i`, `Eq02-F` maps its three `alpha` choices to target direction
minus one, target direction, and target direction plus one, using numerical
codes 0 through 7.  `Eq12` and `RPos <= 1` imply

```
abs(dirF[i] - target[i]) <= 1.
```

Consequently the numeric wrap choice 7 at target 0 is infeasible on 70 links,
and the numeric wrap choice 0 at target 7 is infeasible on 40 links.  The
corresponding 110 `alpha` binaries can be fixed to zero.  The verifier prints
their exact names.

### Translation symmetry

In every row the coefficients on all `x` variables sum to zero, and separately
the coefficients on all `y` variables sum to zero.  Neither block occurs in
the objective.  Hence `(x,y) -> (x+c,y+d)` is an exact two-dimensional integer
translation symmetry.  Fixing any one station, for example
`x-000 = y-000 = 0`, preserves feasibility and objective after translation.

### Bend wrap symmetry

In each `Eq10` pair, `delta1` and `delta2` occur nowhere else and only through

```
k = delta2 - delta1.
```

Both `(0,0)` and `(1,1)` encode `k=0`.  Adding
`delta1 + delta2 <= 1` is valid symmetry breaking.  More compactly, replace
the two binaries by one general integer `k in [-1,1]`; every value of `k` has
an original lift, so this is exact after projection.  The official incumbent
uses the redundant `(1,1)` representation in 18 blocks and can normalize all
of them to `(0,0)` without changing any other variable or the objective.

### Defined directions

All 622 `dirF/dirB` variables are defined by the 622 `Eq02` equalities as
integer linear combinations of one-hot `alpha` variables.  Direct substitution
removes those variables and equations exactly.  It modestly increases the
support of station-order and bend rows.

## Objective-equivalent reductions

The following preserve the optimum and have an explicit lift, but remove
positive-cost slack points; they are not claimed to preserve the entire
original feasible set one-to-one.

### Eliminate `RPos`

After the 110 infeasible wrap choices are removed, `alpha-*-1` is the target
choice and each remaining off-center choice differs by exactly one.  Positive
objective coefficient 100 forces

```
RPos[i] = alpha[i,0] + alpha[i,2]
```

at every optimum.  Put coefficient 100 on the two off-center choices, delete
all 311 `RPos` variables and 622 `Eq12` rows, and lift by the displayed
identity.

### Aggregate 13 duplicated cost factors

Exactly 13 physical adjacent-link pairs occur twice (shared line segments).
For each pair, two bend blocks have the same absolute direction expression and
two `diff` blocks have the same absolute length expression.  Replace each pair
of copies by one epigraph block with doubled objective coefficient.  This
removes 13 bend variables, 26 bend-wrap binaries, 13 difference variables, and
52 rows.  A solution lifts by copying the retained epigraph value and wrap
choice into the deleted copy.  The exact index pairs are printed by
`verify_structure.py`.

### Relax positive-cost epigraph integrality

With integral directions and integer `k`, the lower bound on every `bend` is
integer, so a continuous bend variable attains the same optimum.

For every link, `Eq14` has integer lower envelope

```
L[i] = max(abs(dx[i]), abs(dy[i])).
```

A `lambda[i]` participates in at most six smoothing terms.  Lowering it toward
`L[i]` saves 10 per unit and can increase the total smoothing penalty by at
most `6 * 0.1` per unit.  Therefore every optimum has `lambda[i]=L[i]`, even if
`lambda` is relaxed to continuous.  It is consequently integer at an optimum;
positive cost then forces each continuous `diff` to an integer absolute
difference.  Thus all 315 `bend`, 311 `lambda`, and 315 `diff` variables may be
declared continuous without changing the optimal value or losing an optimal
lift.

## Strong exact local reformulation

Fixing one `alpha[i,k]=1`, the nine `Eq03` inequalities form exactly the line
segment

```
(dx,dy) = t * direction_vector[d(i,k)],    1 <= t <= U(i,k).
```

The verifier enumerates the vertices and recession rays with rational
arithmetic for all 24 distinct direction/choice polyhedra.  Twenty have
`U=128`; the four central axial cases have `U=256`.  There are no other points
or rays.  This proves an exact multiple-choice convex-hull formulation:

```
alpha[i,0] + alpha[i,1] + alpha[i,2] = 1
alpha[i,k] <= t[i,k] <= U[i,k] alpha[i,k]
(dx,dy) = sum_k t[i,k] direction_vector[d(i,k)].
```

The `t` variables can be continuous while integer coordinates remain in the
model.  This replaces weak 128/256 big-M rows by the convex hull of each local
three-segment union.  Do not simply convert `Eq03` to indicators and drop the
inactive rows: those rows supply the finite segment upper bounds, so that
naive change is not feasible-set equivalent.

An alternative graph formulation can eliminate anchored node coordinates.
Use integer edge lengths and enforce zero x/y displacement on a 73-cycle
basis, giving 146 cycle equations; integral coordinates then reconstruct by
path integration.  This is exact but may trade sparse node-potential rows for
denser fundamental-cycle rows, so it should be benchmarked rather than assumed
superior.

## Structural conclusion

The hard core is one connected direction/layout problem, not 311 independent
links and not a natural pricing model.  The most promising exact route is a
strong local multiple-choice formulation combined with the explicit direction
fixings, wrap symmetry removal, translation anchoring, and aggregation of
shared-line cost factors.  A reduced MPS was deliberately not generated in
this audit; the reformulation should be implemented and regression-checked
against the original incumbent before using it for a proof run.
