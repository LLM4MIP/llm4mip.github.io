# Package manifest: tokyometro

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 12
Excluded source files: 0

## Included files

- `README.md`
- `analysis/audit_aux_relaxation.py`
- `analysis/relax_implied_integer_aux.py`
- `analysis/tokyo_structure.py`
- `artifacts/result.json`
- `input/README.md`
- `input/SHA256SUMS`
- `logs/original-proof-600s.log`
- `solutions/strict-8263.1.sol`
- `structural/README.md`
- `structural/structural_audit.py`
- `structural/verify_structure.py`

## Excluded files

- None
