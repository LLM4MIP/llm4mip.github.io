# Package manifest: pb-grow22

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 27
Excluded source files: 2

## Included files

- `README.md`
- `artifacts/audit_public_10.json`
- `artifacts/audit_public_11.json`
- `artifacts/audit_public_9.json`
- `artifacts/encoding_inventory.json`
- `artifacts/encoding_mapping.json`
- `artifacts/feasible_move_search.json`
- `artifacts/gurobi_300s.json`
- `artifacts/gurobi_strict_300s.json`
- `artifacts/quotient_audit.json`
- `artifacts/variable_numbering.json`
- `input/pb-grow22-public-10.sol.gz`
- `input/pb-grow22-public-11.sol.gz`
- `input/pb-grow22-public-9.sol.gz`
- `logs/gurobi_300s.log`
- `logs/gurobi_strict_300s.log`
- `reports/effort_ledger.md`
- `reports/final_report.md`
- `scripts/analyze_grow22.py`
- `scripts/analyze_grow22_mapping.py`
- `scripts/inspect_variable_numbering.py`
- `scripts/pb_grow22_moves.py`
- `scripts/pb_grow22_quotient.py`
- `sources/official_background.md`
- `structure/compact_structure.json`
- `structure/gurobi_structure.json`
- `structure/netlib_grow22_structure.json`

## Excluded files

- `input/netlib-grow22.mps.gz (36782 bytes; raw benchmark input; sha256 799529d386a93f8ca063c6b6d2c15f0bbb80908472906f53ccec7c80c10cf83e)`
- `input/pb-grow22.mps.gz (712644 bytes; raw benchmark input; sha256 6407df50ac88f9130f810d7285bd06a41f1894404d82950b86f0e9e1c26ee2bc)`
