# Official and authoritative background: pb-grow22

## MIPLIB record

- Official page: <https://miplib.zib.de/instance_details_pb-grow22.html>
- Official MPS: <https://miplib.zib.de/WebData/instances/pb-grow22.mps.gz>
- Status observed on 2026-09-09: open.
- MIPLIB objective convention: minimization; displayed best value `-449536`.
- Size: 25,124 binary variables, 1,320 rows, 154,694 nonzeros.
- Row classification after trivial presolve: 440 equation-knapsack rows and
  880 knapsack rows.

The page includes a MiniZinc Challenge 2016 `zephyrus` command as an example of
how the submitter's collection was compiled.  It is not evidence that this
particular instance is Zephyrus; treating that generic command as instance
provenance would be an error.
The public incumbent history shows major gains from weighting local search,
CP-SAT local branching, and OptVerse local/neural search.  The current strict
public solution 11 has objective `-449536` and is downloaded for independent
audit, together with solutions 9 (`-449302`) and 10 (`-449467`).

## Source problem identity

The name and exact dimensions identify the underlying source as the classical
Netlib LP `grow22`.  The authoritative Netlib copy has 946 continuous
variables, 440 equality rows, and 8,252 nonzeros.  The submitted `pb-grow22`
has 25,124 binary variables and exactly 1,320 rows: 440 encoded source
equations plus 880 encoding-cap inequalities.  The initial conjecture that all
three rows came from each source equality was falsified by inspecting the first
880 disjoint row supports.

The historical MIPLIB 2010 submission directory preserves the full benchmark
name `normalized-reduced-mps-v2-20-10-grow22.mps.gz`:
<https://miplib2010.zib.de/contrib/submission2010/PB/>.

Section 5.2 of Manquinho and Roussel, *The First Evaluation of
Pseudo-Boolean Solvers* (JSAT, 2006), defines the `mps-v2-b-a` conversion:
<https://www.cril.univ-artois.fr/PB05/resultb/report/report-PB05-JSAT-submission.pdf>.
It decomposes each real MPS variable into a fixed-point binary expansion.  The
`20-10` family uses the documented 20/10 digit parameters (30 total bits).
Finite bounds shorten the encoding, finite lower bounds are shifted, and each
constraint is scaled to integral coefficients.  The subsequent PB reduction
and normalization explain why the final MPS no longer has a direct raw
power-of-two or row-order correspondence with the Netlib matrix.

## Authoritative sources

- COIN-OR Netlib data mirror:
  <https://github.com/coin-or-tools/Data-Netlib/blob/master/grow22.mps.gz>.
- SuiteSparse description of `LPnetlib/lp_grow22`:
  <https://www.cise.ufl.edu/research/sparse/matrices/LPnetlib/lp_grow22.html>.
- Umetani, *Exploiting variable associations to configure efficient local
  search algorithms in large-scale binary integer programs*, EJOR 263(1),
  2017: <https://arxiv.org/abs/1604.08448>.  It develops lazy overlap-based
  neighbor lists and 2-/4-flip local search; MIPLIB credits this method for
  several historical incumbent improvements.
- The MIPLIB symmetry census reports factors `(S4)^22`, `(S5)^44`,
  `(S6)^110`, `(S7)^198`, `(S8)^154`, `(S9)^88`, `(S10)^88`,
  `(S11)^88`, `(S12)^67`, and `(S13)^87`:
  <https://wwwopt.mathematik.tu-darmstadt.de/~pfetsch/symmetries/miplib2017-init-symmetries.pdf>.
