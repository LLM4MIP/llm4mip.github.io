#!/usr/bin/env python3
"""Inspect whether reduced PB column names retain 30-bit source groups."""

import argparse
import collections
import gzip
import json
import re

import gurobipy as gp


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mps")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    model = gp.read(args.mps)
    model.update()
    parsed = []
    unparsed = []
    for var in model.getVars():
        match = re.fullmatch(r"x(\d+)", var.VarName)
        if match:
            parsed.append((var.index, var.VarName, int(match.group(1))))
        else:
            unparsed.append(var.VarName)

    numbers = [item[2] for item in parsed]
    model_order_runs = []
    current = []
    for item in parsed:
        if current and item[2] != current[-1][2] + 1:
            model_order_runs.append(current)
            current = []
        current.append(item)
    if current:
        model_order_runs.append(current)
    base_candidates = {}
    for base in (0, 1):
        group_counts = collections.Counter((n - base) // 30 for n in numbers)
        bit_counts = collections.Counter((n - base) % 30 for n in numbers)
        base_candidates[str(base)] = {
            "group_count": len(group_counts),
            "group_id_min": min(group_counts) if group_counts else None,
            "group_id_max": max(group_counts) if group_counts else None,
            "group_size_histogram": dict(sorted(collections.Counter(group_counts.values()).items())),
            "bit_position_histogram": dict(sorted(bit_counts.items())),
            "complete_groups": sum(value == 30 for value in group_counts.values()),
            "groups_sample": [
                {"group": key, "surviving_bits": value}
                for key, value in sorted(group_counts.items())[:20]
            ],
        }

    gaps = []
    if numbers:
        present = set(numbers)
        gaps = [n for n in range(min(numbers), max(numbers) + 1) if n not in present]

    result = {
        "variables": model.NumVars,
        "parsed_x_number": len(parsed),
        "unparsed": unparsed[:20],
        "numeric_min": min(numbers) if numbers else None,
        "numeric_max": max(numbers) if numbers else None,
        "distinct_numbers": len(set(numbers)),
        "missing_inside_numeric_range": len(gaps),
        "missing_sample": gaps[:100],
        "model_order_sample": [
            {"index": i, "name": name, "number": n}
            for i, name, n in parsed[:50]
        ],
        "model_order_consecutive_runs": {
            "count": len(model_order_runs),
            "size_histogram": dict(sorted(collections.Counter(len(run) for run in model_order_runs).items())),
            "sample": [
                {
                    "start_model_index": run[0][0],
                    "end_model_index": run[-1][0],
                    "start_name": run[0][1],
                    "end_name": run[-1][1],
                    "size": len(run),
                }
                for run in model_order_runs[:50]
            ],
        },
        "base_candidates": base_candidates,
    }
    with open(args.output, "w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2, sort_keys=True)
        handle.write("\n")


if __name__ == "__main__":
    main()
