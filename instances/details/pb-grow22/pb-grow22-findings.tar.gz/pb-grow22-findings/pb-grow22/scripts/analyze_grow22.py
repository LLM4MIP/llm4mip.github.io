#!/usr/bin/env python3
"""
Structural analysis of a binary MPS against the Netlib grow22 source MPS.

No optimize() and no presolve() are called.

Example:
  python analyze_grow22.py binary.mps grow22.mps \
      --solutions sol449302.sol sol449467.sol sol449536.sol \
      --json-out analysis.json
"""

import argparse
import collections
import gzip
import json
import math
import os
import re
import sys
from typing import Dict, List, Tuple

import gurobipy as gp
from gurobipy import GRB


def row_vector(model, constr):
    """Read one sparse row in O(nnz(row)), not O(number of variables)."""
    expr = model.getRow(constr)
    return {
        expr.getVar(i).index: float(expr.getCoeff(i))
        for i in range(expr.size())
    }


def constraint_vectors(model):
    model.update()
    return [row_vector(model, c) for c in model.getConstrs()]


def objective_columns(model):
    return {
        v.index: float(v.Obj)
        for v in model.getVars()
        if abs(v.Obj) > 1e-12
    }


def rounded_signature(items, scale=1e-9, limit=10000):
    pairs = sorted((int(k), round(float(v) / scale) * scale)
                   for k, v in items.items())
    if len(pairs) > limit:
        pairs = pairs[:limit]
    return tuple(pairs)


def coefficient_signature(values, decimals=9):
    vals = sorted(round(abs(float(x)), decimals) for x in values if abs(x) > 1e-12)
    return tuple(vals)


def row_family_stats(model, rows):
    counts = collections.Counter()
    for r in rows:
        counts[coefficient_signature(r.values())] += 1

    sizes = collections.Counter(len(r) for r in rows)
    senses = collections.Counter(c.Sense for c in model.getConstrs())
    rhs = collections.Counter(round(c.RHS, 9) for c in model.getConstrs())

    return {
        "number_of_families": len(counts),
        "largest_families": [
            {"nnz_signature_size": len(sig), "count": n}
            for sig, n in counts.most_common(20)
        ],
        "row_nnz_histogram": dict(sorted(sizes.items())),
        "senses": dict(senses),
        "distinct_rhs": len(rhs),
    }


def variable_family_stats(model):
    model.update()
    sigs = collections.defaultdict(list)
    for v in model.getVars():
        col = model.getCol(v)
        nz = [float(col.getCoeff(i)) for i in range(col.size())]
        sig = (
            round(v.Obj, 9),
            round(v.LB, 9),
            round(v.UB, 9) if v.UB < GRB.INFINITY else "inf",
            coefficient_signature(nz),
        )
        sigs[sig].append(v.index)

    return {
        "number_of_families": len(sigs),
        "largest_families": [
            {
                "count": len(ix),
                "objective": key[0],
                "lb": key[1],
                "ub": key[2],
                "coefficient_magnitude_count": len(key[3]),
            }
            for key, ix in sorted(sigs.items(), key=lambda kv: -len(kv[1]))[:40]
        ],
    }


def numeric_factors(numbers, max_factor=100):
    """Report repeated divisors useful for detecting binary/radix blocks."""
    ints = []
    for x in numbers:
        if abs(x - round(x)) < 1e-9 and x:
            ints.append(abs(int(round(x))))
    counts = {}
    for d in range(2, max_factor + 1):
        counts[d] = sum(1 for x in ints if x % d == 0)
    return sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))[:15]


def load_solution(path, model):
    """
    Supports common Gurobi .sol files and simple whitespace-separated
    'variable value' files. Unknown variables are ignored.
    """
    by_name = {v.VarName: v for v in model.getVars()}
    result = {}
    if not os.path.exists(path):
        return result, ["missing solution file"]

    opener = gzip.open if path.lower().endswith(".gz") else open
    with opener(path, "rt", errors="replace") as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith("#") or s.startswith("<"):
                continue
            parts = s.replace("=", " ").split()
            if len(parts) < 2:
                continue
            name = parts[0]
            try:
                val = float(parts[1])
            except ValueError:
                continue
            if name in by_name:
                result[by_name[name].index] = val

    return result, []


def solution_row_residuals(model, rows, values):
    residuals = []
    for c, r in zip(model.getConstrs(), rows):
        lhs = sum(a * values.get(j, 0.0) for j, a in r.items())
        residuals.append((c.Sense, lhs - c.RHS))
    return residuals


def infer_row_triples(binary_model, source_model):
    """
    Candidate matching based on row signatures only. This intentionally does
    not assume row order or names. Exact coefficient matching is attempted
    after normalization by gcd and sign.
    """
    br = constraint_vectors(binary_model)
    sr = constraint_vectors(source_model)

    def norm(r):
        vals = [abs(x) for x in r.values() if abs(x) > 1e-12]
        if not vals:
            return ()
        g = vals[0]
        for x in vals[1:]:
            g = math.gcd(int(round(g)), int(round(x))) if (
                abs(g - round(g)) < 1e-9 and abs(x - round(x)) < 1e-9
            ) else g
        if not g:
            g = 1
        return coefficient_signature([x / g for x in vals])

    bmap = collections.defaultdict(list)
    smap = collections.defaultdict(list)
    for i, r in enumerate(br):
        bmap[norm(r)].append(i)
    for i, r in enumerate(sr):
        smap[norm(r)].append(i)

    matches = []
    for sig, six in smap.items():
        bix = bmap.get(sig, [])
        if bix:
            matches.append({
                "source_rows": six[:10],
                "binary_rows": bix[:30],
                "source_count": len(six),
                "binary_count": len(bix),
            })

    return matches


def objective_summary(binary_model, source_model):
    bobj = objective_columns(binary_model)
    sobj = objective_columns(source_model)
    return {
        "binary_nonzero_objective_columns": len(bobj),
        "source_nonzero_objective_columns": len(sobj),
        "two_times_source_plus_source_objective": 2 * source_model.NumVars
        + len(sobj),
        "claimed_binary_count": 2 * source_model.NumVars + len(sobj),
        "matches_claimed_count": len(bobj) == 2 * source_model.NumVars + len(sobj),
        "binary_objective_min": min(bobj.values()) if bobj else None,
        "binary_objective_max": max(bobj.values()) if bobj else None,
        "source_objective_min": min(sobj.values()) if sobj else None,
        "source_objective_max": max(sobj.values()) if sobj else None,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("binary_mps")
    ap.add_argument("source_mps")
    ap.add_argument("--solutions", nargs="*", default=[])
    ap.add_argument("--json-out")
    args = ap.parse_args()

    b = gp.read(args.binary_mps)
    s = gp.read(args.source_mps)
    b.update()
    s.update()

    brows = constraint_vectors(b)
    srows = constraint_vectors(s)

    negative_ladder = []
    for r in brows:
        for x in r.values():
            if x < 0:
                negative_ladder.append(abs(x))

    result = {
        "files": {
            "binary": os.path.abspath(args.binary_mps),
            "source": os.path.abspath(args.source_mps),
        },
        "binary_dimensions": {
            "variables": b.NumVars,
            "constraints": b.NumConstrs,
            "nonzeros": b.NumNZs,
            "binary_variables": sum(v.VType == GRB.BINARY for v in b.getVars()),
        },
        "source_dimensions": {
            "variables": s.NumVars,
            "constraints": s.NumConstrs,
            "nonzeros": s.NumNZs,
        },
        "binary_rows": row_family_stats(b, brows),
        "source_rows": row_family_stats(s, srows),
        "binary_variables": variable_family_stats(b),
        "objective": objective_summary(b, s),
        "row_triple_candidates": infer_row_triples(b, s)[:100],
        "negative_coefficient_factor_statistics": numeric_factors(negative_ladder),
        "hypotheses": [
            {
                "name": "one equality plus two inequalities per source row",
                "prediction": "binary has 3 times source row count",
                "observed": b.NumConstrs == 3 * s.NumConstrs,
            },
            {
                "name": "22-fold replicated block structure",
                "prediction": "dominant variable or row families have counts divisible by 22",
                "observed": "inspect largest_families and row_nnz_histogram",
            },
            {
                "name": "44-fold signed pairing",
                "prediction": "dominant families have counts divisible by 44",
                "observed": "inspect largest_families",
            },
        ],
        "solution_checks": [],
        "recommendations": [],
    }

    for path in args.solutions:
        vals, errors = load_solution(path, b)
        residuals = solution_row_residuals(b, brows, vals)
        violations = 0
        max_violation = 0.0
        for c, (sense, residual) in zip(b.getConstrs(), residuals):
            if sense == GRB.EQUAL:
                bad = abs(residual)
            elif sense == GRB.GREATER_EQUAL:
                bad = max(0.0, -residual)
            else:
                bad = max(0.0, residual)
            if bad > 1e-7:
                violations += 1
                max_violation = max(max_violation, bad)

        objective = sum(v.Obj * vals.get(v.index, 0.0) for v in b.getVars())
        result["solution_checks"].append({
            "file": os.path.abspath(path),
            "parsed_values": len(vals),
            "parse_exceptions": errors,
            "row_violations": violations,
            "max_row_violation": max_violation,
            "computed_binary_objective": objective,
            "note": "Objective comparison is meaningful only when all relevant columns parsed.",
        })

    obj = result["objective"]
    if obj["matches_claimed_count"]:
        result["recommendations"].append(
            "The 1,958 objective-column count exactly matches 2*946+66; "
            "next test should correlate objective-bearing columns with two "
            "candidate representatives per source variable."
        )
    else:
        result["recommendations"].append(
            "The objective-column count does not match 2*source_variables+source_nonzero_objective; "
            "test whether auxiliary objective terms were generated or source MPS differs."
        )

    if b.NumConstrs == 3 * s.NumConstrs:
        result["recommendations"].append(
            "Prioritize row-triple matching by coefficient ratios and RHS affine relations; "
            "do not assume row order."
        )

    result["recommendations"].append(
        "Cluster columns by exact normalized row-incidence signatures, then search "
        "within clusters for mixed-radix weight ladders and 22/44-sized orbits."
    )
    result["recommendations"].append(
        "Use the three public solutions to estimate affine objective constants only "
        "after recovering a common source-variable decoding; reject mappings whose "
        "constant differs across incumbents."
    )

    text = json.dumps(result, indent=2, sort_keys=True)
    if args.json_out:
        with open(args.json_out, "w") as f:
            f.write(text + "\n")
    else:
        print(text)


if __name__ == "__main__":
    main()
