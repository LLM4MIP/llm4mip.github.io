# pb-grow22: one-hour direct-API research report

## Outcome

`pb-grow22` was **not proved optimal**, and no incumbent better than the
strictly feasible public value **-449536** was found. The strongest strict
solver observation is a valid integer lower bound of **-449546**, leaving an
exact 10-unit interval. Proving the cutoff `objective <= -449537` infeasible
would certify the public incumbent.

The main result is an exact structural reduction rather than solver tuning.
The instance was traced to the PB-evaluation fixed-point conversion of Netlib
`grow22`; all 25,124 binary columns were recovered into 946 source-variable
mother groups, and all published permutation symmetries were independently
reproduced. The exact orbit quotient has 17,909 bounded integer count variables
and 109,891 nonzeros, versus 25,124 variables and 154,694 nonzeros originally.

## Reproducibility and strict validation

- Official MPS SHA-256:
  `6407df50ac88f9130f810d7285bd06a41f1894404d82950b86f0e9e1c26ee2bc`.
- Public solutions 9, 10, and 11 SHA-256:
  `b084cec48a156815b4e5817ce72e00dc25b8d21a93f519f4162e6bc429a93179`,
  `83552fad48d8d5fdb68c2a86c3bb7e66a378f8414aab1f497d416f0675921372`,
  and `d8254ff0b6b32fe0c7a361aa2871584301c5bda6f99dec0a0f1048e578375573`.
- Netlib `grow22` SHA-256:
  `086f6d9289c69178ff6f2042777d9eb10bf73a794b8657b0e2309df1b1ba622c`.
- Exact audits reproduce objectives -449302, -449467, and -449536 with zero
  row, bound, or integrality violations.
- Research wall-clock: **68 minutes**, 02:31--03:39 UTC+08:00.
- Five successful stateful `gpt-5.6-sol` segments used **106,744 recorded
  tokens**. Failed timeout or empty gateway responses were atomically discarded.
- Generic solver optimization time: **302.06 seconds**, below the 30-minute cap.

## Authoritative provenance and recovered encoding

The historical MIPLIB 2010 archive contains the full name
`normalized-reduced-mps-v2-20-10-grow22`. Section 5.2 of Manquinho and
Roussel's PB evaluation paper defines this family as a fixed-point binary
conversion of real MPS variables using 20/10 digit parameters (30 total bits),
with bound shortening, lower-bound shifting, and integer row scaling. The
source Netlib model has 946 continuous variables, 440 equality rows, and 8,252
nonzeros. Subsequent PB reduction explains why naive raw power-of-two and
row-order matching failed.

Direct inspection establishes:

- `c0..c879` are 880 disjoint encoding-cap inequalities;
- `c880..c1319` are 440 reduced encoded equalities;
- cap supports cover 23,144 columns without overlap;
- MPS column order reveals 880 mother groups of sizes 22--31;
- the remaining 1,980 columns partition exactly into 66 groups of 30;
- all 946 groups cover every binary column exactly once.

The cap-group size histogram is:

```text
22:22, 23:44, 24:110, 25:198, 26:154,
27:88, 28:88, 29:88, 30:66, 31:22
```

This falsifies two early API hypotheses: the 880 inequalities are not two
copies of each source row, and `1958 = 2*946 + 66` does not establish the
objective encoding.

## Exact symmetry quotient

Columns were grouped only when their complete signatures were identical:
type, bounds, objective, and every indexed row coefficient. Arbitrary
permutations inside such a group preserve the complete model.

The audit found 17,909 exact orbits: 16,963 singleton and 946 nontrivial. No
orbit crosses a mother-group boundary, and all 25,124 signatures rechecked
without mismatch. The nontrivial multiplicity histogram is exactly:

```text
4:22, 5:44, 6:110, 7:198, 8:154,
9:88, 10:88, 11:88, 12:67, 13:87
```

This reproduces every published factor `(S4)^22` through `(S13)^87`.
Replacing each orbit by an integer count `0 <= y_o <= |o|` is exact. The
public incumbent's orbit counts reproduce its objective and all 1,320 row
left-hand sides exactly. This is a checkable transformation, not an optimality
proof.

## Non-solver search experiments

### Exact 2-flips

Every equality-preserving exchange of one selected and one unselected bit was
enumerated: 5,898 tested, 5,878 cap-feasible, and zero objective improvements.
This excludes only the specified 2-flip neighborhood.

### Mother-group meet-in-the-middle

An exact subset meet-in-the-middle search held the full equality contribution
fixed while allowing cap-feasible replacements. Two of 66 objective-bearing
groups completed before the custom-search limit:

- group 374: 30 bits, current and best contribution -1595;
- group 375: 29 bits, current and best contribution -1164.

The other 64 groups are untested, so no broad local-optimality claim is made.

### Rejected 4-flip attempt

The proposed bounded 4-flip code truncated one pair side before equality-sum
matching and consequently tested zero matching moves. It is recorded as an
implementation failure and supplies no negative evidence.

## Solver baseline and tolerance trap

With Gurobi's default `MIPGap=1e-4`, the solver returned status `OPTIMAL` after
1.98 seconds at objective -449536 and bound -449566. The 30-unit difference
was below the relative tolerance; this is not a strict mathematical
certificate.

The required `MIPGap=0` rerun ended `TIME_LIMIT` after 300 seconds, 5,900
nodes, and 3,879,051 simplex iterations:

```text
best feasible objective  -449536
best valid integer bound -449546
exact remaining gap            10
```

No improved solution was found. A strict optimum remains somewhere in the
integer interval [-449546, -449536].

## Why no optimality claim is possible

The valid lower bound does not match the witness. The 2-flip and two completed
mother-group searches are local; the 4-flip phase was invalid. No checkable
PB/SAT UNSAT certificate or complete branch tree excludes objectives -449546
through -449537.

## Recommended next work

1. Emit and independently verify the 17,909-variable orbit quotient, then test
   `objective <= -449537` with a proof-producing PB/SAT or bit-vector backend.
2. Correct the exact 4-flip/count-move search by hashing both pair-sum sides
   before pruning and reporting the fully exhausted association domain.
3. Use the repeated 22-block templates for an exact residual-state dynamic
   program or symmetry-aware branch tree against the same cutoff.

## Artifact index

- `structure/gurobi_structure.json` and `netlib_grow22_structure.json`:
  complete binary and source structure extractions.
- `research/official_background.md`: authoritative provenance and sources.
- `research/api_01.json` through `api_05.json`: successful API transcripts.
- `artifacts/audit_public_9.json` through `audit_public_11.json`: exact audits.
- `artifacts/encoding_inventory.json` and `encoding_mapping.json`: encoding
  hypotheses, including the falsified row-order mapping.
- `artifacts/variable_numbering.json`: mother-group recovery.
- `artifacts/quotient_audit.json`: exact quotient and incumbent reproduction.
- `artifacts/feasible_move_search.json`: local-search experiment ledger.
- `artifacts/gurobi_300s.json`: default-tolerance run, not a strict proof.
- `artifacts/gurobi_strict_300s.json`: strict 300-second baseline.
- `logs/`: full solver logs; `scripts/`: generated and repaired scripts.
