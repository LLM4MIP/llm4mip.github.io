# Effort ledger: pb-grow22

All timestamps use Asia/Shanghai (UTC+08:00).  The one-hour minimum is measured
from the first instance-specific action until the final report is completed.
Generic solver optimization is capped at 30 minutes.  Read-only Gurobi parsing,
solution auditing, and custom algorithms do not consume that cap.

| Start | End | Activity | API/compute | Solver optimization |
|---|---|---|---|---|
| 2026-09-09 02:31 | 2026-09-09 02:33 | Official MPS and three best public solutions downloaded and hashed; read-only Gurobi structure extraction | Research/setup | 0 min |
| 2026-09-09 02:33 | 2026-09-09 02:42 | Exact audits of solutions 9--11; downloaded and extracted the Netlib `grow22` source model | Research/validation | 0 min |
| 2026-09-09 02:42 | 2026-09-09 02:54 | Official-page, PB-evaluation, Netlib, symmetry, and local-search background investigation; corrected the initial MiniZinc provenance error | Research/background | 0 min |
| 2026-09-09 02:54 | 2026-09-09 03:05 | Stateful API segments 1--2; executed and repaired encoding inventory and mapping scripts; falsified naive row-order mapping | API/experiment | 0 min |
| 2026-09-09 03:05 | 2026-09-09 03:18 | Recovered the 946 mother groups from cap supports and MPS column order; documented authoritative 30-bit fixed-point conversion | Research/experiment | 0 min |
| 2026-09-09 03:18 | 2026-09-09 03:24 | Stateful API segment 3; exact full-column orbit audit and quotient/incumbent reproduction | API/experiment | 0 min |
| 2026-09-09 03:24 | 2026-09-09 03:29 | Stateful API segment 4; exact 2-flip, partial mother-group MITM, and rejected 4-flip implementation | API/experiment | 0 min |
| 2026-09-09 03:29 | 2026-09-09 03:30 | Default-tolerance Gurobi baseline exposed a false-strict-OPTIMAL trap | Solver baseline | 1.98 sec |
| 2026-09-09 03:30 | 2026-09-09 03:35 | Strict `MIPGap=0` Gurobi baseline; TIME_LIMIT with incumbent -449536 and bound -449546 | Solver baseline | 300.08 sec |
| 2026-09-09 03:35 | 2026-09-09 03:41 | Stateful API final assessment, report consolidation, and artifact audit | API/reporting | 0 min |

Status: complete without an optimality claim. Research wall-clock exceeded 60
minutes. Five successful API segments used 106,744 recorded tokens. Generic
solver runtime was 302.06 seconds, below the 30-minute cap.
