# Package manifest: neos-3355323-arnon

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 15
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/order_csp_60s.json`
- `artifacts/order_sat_result.json`
- `logs/effort_ledger.md`
- `logs/research_log.md`
- `reports/final_report.md`
- `scripts/audit_original.py`
- `scripts/inspect_arnon.py`
- `scripts/solve_order_csp.py`
- `scripts/solve_order_sat.py`
- `solutions/README.md`
- `sources/sources.md`
- `structure/deep_structure.json`
- `structure/structure.compact.json`
- `structure/structure.json`

## Excluded files

- `input/neos-3355323-arnon.mps.gz (405587 bytes; raw benchmark input; sha256 79c32f6dfc7a1784ece68d4024eae739784b9c69adfc94ef7222a35cdacda5d7)`
