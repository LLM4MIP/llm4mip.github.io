# Effort ledger

All times are Asia/Shanghai on 2026-09-09.

| Time | Activity | Artifact / observation |
|---|---|---|
| 03:29:31 | Research started | Required wall-clock clock began |
| 03:29:56 | Official MPS acquired | SHA-256 `79c32f...da5d7` |
| 03:30:09 | Read-only Gurobi structure extraction | `structure/structure.json`; no optimization |
| 03:35:51 | Deep row-template and incidence extraction | `structure/deep_structure.json` |
| 03:37-03:42 | API round 1 | Structural classification and exact-order reduction proposal; 8,651 tokens |
| 03:42-03:51 | Exact custom order-CSP implementation and run | 60-second DPLL(T), 12,024 nodes, no result |
| 03:52-03:57 | API round 2 | Observation feedback and SAT/CDCL redesign; 13,703 tokens |
| 03:57-04:42 | Truth-table normalization and exact CSP export | `artifacts/order_csp_normalized.json` |
| 04:42-04:47 | Exact threshold-CNF implementation and construction | 11,544 variables, 210,720 clauses |
| 04:47:57-05:07:41.843 | Bounded structural CDCL attempt | CaDiCaL 1.9.5: `UNKNOWN`, 1,184.843 seconds; no model or proof |
| 05:07:41.843 | Research closed | Wall time 1 h 38 min 10.843 s (5,890.843 s); result reported conservatively |

## Solver budget

- Generic MIP optimization: 0 seconds out of the allowed 1,800 seconds.
- Gurobi was used only to parse the original MPS and expose rows/columns.
- Custom structural search: 60 seconds.
- SAT/CDCL structural search: 1,184.843 seconds.

## API budget

| Round | Input tokens | Output tokens | Reasoning tokens | Total tokens |
|---|---:|---:|---:|---:|
| Structure decode | 997 | 7,654 | 1,552 | 8,651 |
| CSP feedback | 7,738 | 5,965 | 1,034 | 13,703 |
| **Total** | **8,735** | **13,619** | **2,586** | **22,354** |
