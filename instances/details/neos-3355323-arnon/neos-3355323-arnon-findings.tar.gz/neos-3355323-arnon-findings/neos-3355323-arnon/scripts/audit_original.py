#!/usr/bin/env python3
"""Independently audit a complete integer assignment against the original MPS."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import time
from pathlib import Path

import gurobipy as gp


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("assignment", type=Path)
    parser.add_argument("result", type=Path)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    started = time.time()
    model = gp.read(str(args.mps))
    values = json.loads(args.assignment.read_text(encoding="utf-8"))
    variables = model.getVars()
    expected = {v.VarName for v in variables}
    supplied = set(values)

    missing = sorted(expected - supplied)
    extra = sorted(supplied - expected)
    bound_violations = []
    integrality_violations = []
    max_bound_violation = 0.0
    max_integrality_violation = 0.0

    for var in variables:
        if var.VarName not in values:
            continue
        value = float(values[var.VarName])
        violation = max(var.LB - value, value - var.UB, 0.0)
        max_bound_violation = max(max_bound_violation, violation)
        if violation > 1e-9:
            bound_violations.append([var.VarName, value, var.LB, var.UB, violation])
        if var.VType in (gp.GRB.BINARY, gp.GRB.INTEGER, gp.GRB.SEMIINT):
            violation = abs(value - round(value))
            max_integrality_violation = max(max_integrality_violation, violation)
            if violation > 1e-9:
                integrality_violations.append([var.VarName, value, violation])

    row_violations = []
    max_row_violation = 0.0
    nonintegral_coefficients = 0
    nonintegral_rhs = 0
    for constraint in model.getConstrs():
        row = model.getRow(constraint)
        activity = 0.0
        for j in range(row.size()):
            coefficient = row.getCoeff(j)
            if abs(coefficient - round(coefficient)) > 1e-12:
                nonintegral_coefficients += 1
            activity += coefficient * float(values.get(row.getVar(j).VarName, math.nan))
        rhs = constraint.RHS
        if abs(rhs - round(rhs)) > 1e-12:
            nonintegral_rhs += 1
        if constraint.Sense == gp.GRB.LESS_EQUAL:
            violation = max(activity - rhs, 0.0)
        elif constraint.Sense == gp.GRB.GREATER_EQUAL:
            violation = max(rhs - activity, 0.0)
        elif constraint.Sense == gp.GRB.EQUAL:
            violation = abs(activity - rhs)
        else:
            raise ValueError(f"unknown row sense {constraint.Sense}")
        max_row_violation = max(max_row_violation, violation)
        if violation > 1e-9:
            row_violations.append(
                [constraint.ConstrName, constraint.Sense, activity, rhs, violation]
            )

    objective = sum(
        var.Obj * float(values.get(var.VarName, math.nan)) for var in variables
    )
    feasible = not (
        missing
        or extra
        or bound_violations
        or integrality_violations
        or row_violations
    )
    result = {
        "mps_sha256": hashlib.sha256(args.mps.read_bytes()).hexdigest(),
        "assignment_sha256": hashlib.sha256(args.assignment.read_bytes()).hexdigest(),
        "variables_in_mps": len(variables),
        "variables_in_assignment": len(values),
        "constraints_checked": model.NumConstrs,
        "missing_variables": missing,
        "extra_variables": extra,
        "bound_violation_count": len(bound_violations),
        "integrality_violation_count": len(integrality_violations),
        "row_violation_count": len(row_violations),
        "max_bound_violation": max_bound_violation,
        "max_integrality_violation": max_integrality_violation,
        "max_row_violation": max_row_violation,
        "first_bound_violations": bound_violations[:20],
        "first_integrality_violations": integrality_violations[:20],
        "first_row_violations": row_violations[:20],
        "nonintegral_coefficients": nonintegral_coefficients,
        "nonintegral_rhs_values": nonintegral_rhs,
        "objective": objective,
        "feasible": feasible,
        "audit_seconds": time.time() - started,
    }
    args.result.parent.mkdir(parents=True, exist_ok=True)
    args.result.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0 if feasible else 1


if __name__ == "__main__":
    raise SystemExit(main())
