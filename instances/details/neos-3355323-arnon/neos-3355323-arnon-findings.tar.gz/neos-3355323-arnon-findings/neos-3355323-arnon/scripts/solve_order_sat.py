#!/usr/bin/env python3
"""Exact SAT encoding of the normalized neos-3355323-arnon order CSP.

This script deliberately has no MIP dependency.  It uses unary threshold variables
for the 144 rank variables and Boolean atoms for the comparison, pattern, and gap
variables.  A satisfying assignment is written as a complete assignment for all
original variables; a separate script must audit it against the original MPS.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import threading
import time
from pathlib import Path

from pysat.formula import CNF, IDPool
from pysat.solvers import Solver


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("normalized", type=Path)
    parser.add_argument("--solver", default="cadical195")
    parser.add_argument("--time-limit", type=float, default=600.0)
    parser.add_argument("--cnf", type=Path, required=True)
    parser.add_argument("--mapping", type=Path, required=True)
    parser.add_argument("--result", type=Path, required=True)
    parser.add_argument("--assignment", type=Path, required=True)
    parser.add_argument("--solution", type=Path, required=True)
    return parser.parse_args()


def signed_atom(atom: int, bit: int) -> int:
    return atom if bit else -atom


def main() -> int:
    args = parse_args()
    started = time.time()
    normalized_bytes = args.normalized.read_bytes()
    data = json.loads(normalized_bytes)

    ranks = data["integer_names"]
    comparisons = list(data["comparison_bit_edges"])
    patterns = list(data["allowed_patterns"])
    gaps = data["gap_names"]

    pool = IDPool()
    cnf = CNF()
    threshold = {
        (i, k): pool.id(("threshold", i, k))
        for i in range(len(ranks))
        for k in range(2, 12)
    }
    comparison = {name: pool.id(("comparison", name)) for name in comparisons}
    pattern = {name: pool.id(("pattern", name)) for name in patterns}
    gap = {name: pool.id(("gap", name)) for name in gaps}

    clause_groups: dict[str, int] = {}

    def add(clause: list[int], group: str) -> None:
        cnf.append(clause)
        clause_groups[group] = clause_groups.get(group, 0) + 1

    # Threshold semantics: x >= k+1 implies x >= k.
    for i in range(len(ranks)):
        for k in range(2, 11):
            add([-threshold[i, k + 1], threshold[i, k]], "rank_monotonicity")

    def add_edge(edge: list[int], condition: int | None, group: str) -> None:
        """Encode condition => x[v] >= x[u] + w for x in {1,...,11}."""
        u, v, w = map(int, edge)
        prefix = [] if condition is None else [-condition]
        if w == 0:
            for k in range(2, 12):
                add(prefix + [-threshold[u, k], threshold[v, k]], group)
        elif w == 1:
            # x[u] >= 1 is implicit, hence x[v] >= 2.
            add(prefix + [threshold[v, 2]], group)
            for k in range(2, 11):
                add(prefix + [-threshold[u, k], threshold[v, k + 1]], group)
            # x[u] = 11 is incompatible with a strict successor in the domain.
            add(prefix + [-threshold[u, 11]], group)
        else:
            raise ValueError(f"unsupported edge weight {w}")

    for edge in data["base_edges"]:
        add_edge(edge, None, "base_order_edges")

    # Each comparison Boolean selects one of two complementary integer relations.
    for name, bit_edges in data["comparison_bit_edges"].items():
        atom = comparison[name]
        add_edge(bit_edges["1"], atom, "comparison_true")
        add_edge(bit_edges["0"], -atom, "comparison_false")

    # The twelve gap decisions select exact alternative order equalities.
    for name, bit_edges in data["gap_options"].items():
        atom = gap[name]
        for edge in bit_edges["1"]:
            add_edge(edge, atom, "gap_true")
        for edge in bit_edges["0"]:
            add_edge(edge, -atom, "gap_false")

    # Pattern indicators are Tseitin atoms exactly equivalent to six signed bits.
    for name, assignments in data["allowed_patterns"].items():
        z = pattern[name]
        literals = [signed_atom(comparison[b], int(bit)) for b, bit in assignments]
        for literal in literals:
            add([-z, literal], "pattern_forward")
        add([z] + [-literal for literal in literals], "pattern_reverse")

    # Explicitly forbidden six-bit assignments.
    for assignment in data["nogoods"]:
        add(
            [-signed_atom(comparison[b], int(bit)) for b, bit in assignment],
            "six_bit_nogoods",
        )

    # Each original final row requires at least one of its 13 exact patterns.
    for family in data["families"]:
        add([pattern[name] for name in family], "pattern_families")

    args.cnf.parent.mkdir(parents=True, exist_ok=True)
    args.mapping.parent.mkdir(parents=True, exist_ok=True)
    args.result.parent.mkdir(parents=True, exist_ok=True)
    args.assignment.parent.mkdir(parents=True, exist_ok=True)
    args.solution.parent.mkdir(parents=True, exist_ok=True)
    cnf.to_file(str(args.cnf))

    mapping = {
        "normalized_sha256": hashlib.sha256(normalized_bytes).hexdigest(),
        "rank_thresholds": {
            ranks[i]: {str(k): threshold[i, k] for k in range(2, 12)}
            for i in range(len(ranks))
        },
        "comparison_atoms": comparison,
        "pattern_atoms": pattern,
        "gap_atoms": gap,
        "variables": pool.top,
        "clauses": len(cnf.clauses),
        "clause_groups": clause_groups,
    }
    args.mapping.write_text(json.dumps(mapping, indent=2), encoding="utf-8")

    build_finished = time.time()
    solver = Solver(name=args.solver, bootstrap_with=cnf.clauses)
    interrupted = False

    def interrupt() -> None:
        nonlocal interrupted
        interrupted = True
        solver.interrupt()

    timer = threading.Timer(args.time_limit, interrupt)
    timer.start()
    solve_started = time.time()
    try:
        status = solver.solve_limited(expect_interrupt=True)
    finally:
        timer.cancel()
    solve_finished = time.time()
    stats = solver.accum_stats()

    result: dict[str, object] = {
        "solver": args.solver,
        "status": "SAT" if status is True else "UNSAT" if status is False else "UNKNOWN",
        "timer_interrupt_requested": interrupted,
        "time_limit_seconds": args.time_limit,
        "build_seconds": build_finished - started,
        "solve_seconds": solve_finished - solve_started,
        "total_seconds": solve_finished - started,
        "variables": pool.top,
        "clauses": len(cnf.clauses),
        "clause_groups": clause_groups,
        "solver_stats": stats,
    }

    if status is True:
        model = set(solver.get_model())
        values: dict[str, int] = {}
        for i, name in enumerate(ranks):
            values[name] = 1 + sum(threshold[i, k] in model for k in range(2, 12))
        for name, atom in comparison.items():
            values[name] = int(atom in model)
        for name, atom in pattern.items():
            values[name] = int(atom in model)
        for name, atom in gap.items():
            values[name] = int(atom in model)

        expected = set(ranks) | set(comparisons) | set(patterns) | set(gaps)
        if set(values) != expected:
            raise RuntimeError(
                f"assignment coverage mismatch: got {len(values)}, expected {len(expected)}"
            )
        args.assignment.write_text(json.dumps(values, indent=2), encoding="utf-8")
        with gzip.open(args.solution, "wt", encoding="utf-8", newline="\n") as out:
            out.write("# Objective value = 0\n")
            for name in sorted(values, key=lambda x: int(x[1:])):
                out.write(f"{name} {values[name]}\n")
        result["assignment_variables"] = len(values)
        result["assignment_sha256"] = hashlib.sha256(args.assignment.read_bytes()).hexdigest()
        result["solution_sha256"] = hashlib.sha256(args.solution.read_bytes()).hexdigest()

    solver.delete()
    args.result.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0 if status is not None else 2


if __name__ == "__main__":
    raise SystemExit(main())
