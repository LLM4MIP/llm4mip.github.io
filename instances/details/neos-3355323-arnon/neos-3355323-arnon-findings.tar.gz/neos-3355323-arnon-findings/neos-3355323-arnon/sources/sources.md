# Sources

## Primary instance source

- Zuse Institute Berlin, MIPLIB 2017 instance page: [neos-3355323-arnon](https://miplib.zib.de/instance_details_neos-3355323-arnon.html). Accessed 2026-09-09. The page identifies the submitter (Jeff Linderoth), group (`neos-pseudoapplication-38`), open feasibility status, model dimensions, structural tags, lack of a public solution, and lack of bibliographic information.
- Original compressed MPS downloaded from the MIPLIB link on that page. Local SHA-256: `79c32f6dfc7a1784ece68d4024eae739784b9c69adfc94ef7222a35cdacda5d7`.

## Same-group context

- Zuse Institute Berlin, MIPLIB 2017 instance page: [neos-3211096-shag](https://miplib.zib.de/instance_details_neos-3211096-shag.html). Accessed 2026-09-09. This same-group instance is recorded as infeasible, solved by ParaSCIP in 42,484 seconds and confirmed by ParaXpress.
- Zuse Institute Berlin, MIPLIB 2017 instance page: [neos-3603137-hoteo](https://miplib.zib.de/instance_details_neos-3603137-hoteo.html). Accessed 2026-09-09. This smaller same-group feasibility instance remains open and has no public solution.

No primary publication or domain description was found. Accordingly, the application interpretation in the report is explicitly labeled as structural inference rather than sourced fact.
