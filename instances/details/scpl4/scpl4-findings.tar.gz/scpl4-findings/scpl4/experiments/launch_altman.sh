#!/usr/bin/env bash
set -euo pipefail

root=${1:-/home/huangyicheng/miplib-scpl4-20260908-altman}
cd "$root"
export PYTHONPATH=/home/huangyicheng/copt80/lib/python/310${PYTHONPATH:+:$PYTHONPATH}
export LD_LIBRARY_PATH=/home/huangyicheng/copt80/lib/python/deps:/home/huangyicheng/copt80/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}
name=copt-reduced-1200s
if [[ -s "runs/${name}/pid" ]] && kill -0 "$(<"runs/${name}/pid")" 2>/dev/null; then
    echo "$name already running as $(<"runs/${name}/pid")"
elif [[ -s "runs/${name}/result.json" ]]; then
    echo "$name already has a result"
else
    mkdir -p "runs/${name}"
    nohup python3 scripts/run_copt_reduced.py \
        --model input/scpl4-dominance-reduced.mps \
        --start input/scpl4-public-reduced.sol \
        --outdir "runs/${name}" \
        --time-limit 1200 --threads 16 \
        > "runs/${name}/stdout.log" 2>&1 < /dev/null &
    echo $! > "runs/${name}/pid"
    echo "launched $name as $!"
fi

name=copt-aggressive-600s
if ! { [[ -s "runs/${name}/pid" ]] && kill -0 "$(<"runs/${name}/pid")" 2>/dev/null; } \
    && [[ ! -s "runs/${name}/result.json" ]]; then
    mkdir -p "runs/${name}"
    nohup python3 scripts/run_copt_reduced.py \
        --model input/scpl4-dominance-reduced.mps \
        --start input/scpl4-public-reduced.sol \
        --outdir "runs/${name}" \
        --time-limit 600 --threads 16 --aggressive-heuristics \
        > "runs/${name}/stdout.log" 2>&1 < /dev/null &
    echo $! > "runs/${name}/pid"
    echo "launched $name as $!"
fi
