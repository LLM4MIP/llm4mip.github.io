#!/usr/bin/env python3
"""Small dependency-free free-MPS reader used by the scpl4 experiments."""

from __future__ import annotations

import gzip
from collections import defaultdict
from decimal import Decimal
from pathlib import Path


def open_text(path: Path, mode: str = "rt"):
    if path.suffix == ".gz":
        return gzip.open(path, mode, encoding="latin-1" if "t" in mode else None)
    return path.open(mode, encoding="latin-1" if "t" in mode else None)


def parse_mps(path: Path):
    section = ""
    objective_row = None
    senses: dict[str, str] = {}
    rhs: defaultdict[str, Decimal] = defaultdict(Decimal)
    costs: defaultdict[str, Decimal] = defaultdict(Decimal)
    columns: defaultdict[str, dict[str, Decimal]] = defaultdict(dict)
    with open_text(path) as stream:
        for raw in stream:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if not raw[0].isspace() and tokens[0] in {
                "NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"
            }:
                section = tokens[0]
                continue
            if section == "ROWS":
                sense, name = tokens[:2]
                if sense == "N":
                    objective_row = name
                else:
                    senses[name] = sense
            elif section == "COLUMNS":
                if "'MARKER'" in tokens:
                    continue
                variable = tokens[0]
                for row, value_text in zip(tokens[1::2], tokens[2::2]):
                    value = Decimal(value_text)
                    if row == objective_row:
                        costs[variable] += value
                    else:
                        columns[variable][row] = columns[variable].get(row, Decimal(0)) + value
            elif section == "RHS":
                for row, value_text in zip(tokens[1::2], tokens[2::2]):
                    rhs[row] += Decimal(value_text)
    return senses, rhs, costs, columns


def parse_solution(path: Path):
    declared = None
    values: dict[str, Decimal] = {}
    with open_text(path) as stream:
        for raw in stream:
            tokens = raw.split()
            if len(tokens) < 2 or tokens[0].startswith("#"):
                continue
            if tokens[0] == "=obj=":
                declared = Decimal(tokens[-1])
            else:
                values[tokens[0]] = Decimal(tokens[1])
    return declared, values
