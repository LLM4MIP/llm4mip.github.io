#!/usr/bin/env python3
"""Delete scpl4 columns dominated by explicit collections of cost-one columns."""

from __future__ import annotations

import argparse
import gzip
import json
from collections import defaultdict
from pathlib import Path

from setcover_io import parse_mps, parse_solution


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--model-output", type=Path, required=True)
    parser.add_argument("--start-output", type=Path, required=True)
    parser.add_argument("--certificate", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    args = parser.parse_args()

    senses, rhs, costs, columns = parse_mps(args.model)
    declared, solution = parse_solution(args.solution)
    variables = list(columns)
    supports = {variable: frozenset(columns[variable]) for variable in variables}
    cost_one = [variable for variable in variables if costs[variable] == 1]
    row_candidates: defaultdict[str, list[str]] = defaultdict(list)
    for variable in cost_one:
        for row in supports[variable]:
            row_candidates[row].append(variable)

    dominated: dict[str, list[str]] = {}
    for target in variables:
        budget = int(costs[target])
        if costs[target] != budget or budget <= 1:
            continue
        remaining = set(supports[target])
        candidate_pool: set[str] = set()
        for row in remaining:
            candidate_pool.update(row_candidates[row])
        chosen: list[str] = []
        while remaining and len(chosen) < budget:
            best = max(
                candidate_pool,
                key=lambda variable: (len(supports[variable] & remaining), variable),
                default=None,
            )
            if best is None or not (supports[best] & remaining):
                break
            chosen.append(best)
            remaining -= supports[best]
            candidate_pool.remove(best)
        if not remaining and len(chosen) <= budget:
            dominated[target] = chosen

    retained = [variable for variable in variables if variable not in dominated]
    selected = [variable for variable in variables if solution.get(variable, 0) != 0]
    if not all(variable in retained for variable in selected):
        raise RuntimeError("a selected incumbent column was unexpectedly dominated")

    args.model_output.parent.mkdir(parents=True, exist_ok=True)
    with args.model_output.open("wt", encoding="ascii", newline="\n") as stream:
        stream.write("NAME scpl4_dominance_reduced\nROWS\n N OBJ\n")
        for row, sense in senses.items():
            stream.write(f" {sense} {row}\n")
        stream.write("COLUMNS\n MARK0000 'MARKER' 'INTORG'\n")
        for variable in retained:
            entries = [("OBJ", costs[variable]), *columns[variable].items()]
            for offset in range(0, len(entries), 2):
                stream.write(" " + variable)
                for row, value in entries[offset:offset + 2]:
                    stream.write(f" {row} {value}")
                stream.write("\n")
        stream.write(" MARK0001 'MARKER' 'INTEND'\nRHS\n")
        rows = list(senses)
        for offset in range(0, len(rows), 2):
            stream.write(" RHS1")
            for row in rows[offset:offset + 2]:
                stream.write(f" {row} {rhs[row]}")
            stream.write("\n")
        stream.write("BOUNDS\n")
        for variable in retained:
            stream.write(f" BV BND1 {variable}\n")
        stream.write("ENDATA\n")

    args.start_output.parent.mkdir(parents=True, exist_ok=True)
    with args.start_output.open("wt", encoding="ascii", newline="\n") as stream:
        stream.write(f"=obj= {declared}\n")
        for variable in retained:
            stream.write(f"{variable} {solution.get(variable, 0)}\n")

    certificate = {
        "instance": "scpl4",
        "method": "explicit domination by a union of cost-one columns",
        "original_columns": len(variables),
        "retained_columns": len(retained),
        "dominated_columns": len(dominated),
        "cost_one_columns": len(cost_one),
        "selected_public_columns_retained": True,
        "dominated": dominated,
    }
    args.certificate.parent.mkdir(parents=True, exist_ok=True)
    if args.certificate.suffix == ".gz":
        with gzip.open(args.certificate, "wt", encoding="utf-8") as stream:
            json.dump(certificate, stream, separators=(",", ":"), sort_keys=True)
            stream.write("\n")
    else:
        args.certificate.write_text(json.dumps(certificate, separators=(",", ":"), sort_keys=True) + "\n")

    summary = {key: value for key, value in certificate.items() if key != "dominated"}
    args.summary.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
