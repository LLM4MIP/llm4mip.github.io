#!/usr/bin/env python3
"""Run COPT on the independently verified scpl4 dominance reduction."""

from __future__ import annotations

import argparse
import json
import platform
from pathlib import Path

from coptpy import COPT, Envr


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--start", type=Path, required=True)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--mode", choices=("optimize", "exclude"), default="optimize")
    parser.add_argument("--target", type=float, default=213.0)
    parser.add_argument("--time-limit", type=float, default=900.0)
    parser.add_argument("--threads", type=int, default=16)
    parser.add_argument("--aggressive-heuristics", action="store_true")
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    environment = Envr()
    model = environment.createModel("scpl4_dominance_reduced")
    model.readMps(str(args.model))
    if args.mode == "optimize":
        model.readSol(str(args.start))
    variables = model.getVars().getAll()
    objective_coefficients = [variable.obj for variable in variables]
    original_objective = sum(
        coefficient * variable
        for coefficient, variable in zip(objective_coefficients, variables)
        if coefficient
    )
    if args.mode == "exclude":
        model.addConstr(original_objective <= args.target, "EXCLUDE_BUDGET")
        model.setObjective(0.0, COPT.MINIMIZE)
    model.setLogFile(str(args.outdir / "solver.log"))
    model.setParam(COPT.Param.Threads, args.threads)
    model.setParam(COPT.Param.TimeLimit, args.time_limit)
    model.setParam(COPT.Param.GPUMode, 0)
    if args.aggressive_heuristics:
        for parameter, value in (
            (COPT.Param.HeurLevel, 3),
            (COPT.Param.PreRootHeurLevel, 3),
            (COPT.Param.RoundingHeurLevel, 3),
            (COPT.Param.DivingHeurLevel, 3),
            (COPT.Param.FAPHeurLevel, 4),
            (COPT.Param.SubMipHeurLevel, 3),
            (COPT.Param.MipRepair, 3),
        ):
            model.setParam(parameter, value)
    model.solve()

    get = model.getAttr
    report = {
        "instance": "scpl4",
        "host": platform.node(),
        "solver": "COPT",
        "solver_version": "recorded in solver.log",
        "model": str(args.model),
        "method": (
            "objective-cutoff feasibility on independently verified dominance reduction"
            if args.mode == "exclude"
            else "branch-and-cut on independently verified dominance reduction"
        ),
        "mode": args.mode,
        "excluded_target": args.target if args.mode == "exclude" else None,
        "parameters": {
            "time_limit": args.time_limit,
            "threads": args.threads,
            "gpu_mode": 0,
            "aggressive_heuristics": args.aggressive_heuristics,
        },
        "mip_status": int(get(COPT.Attr.MipStatus)),
        "runtime_seconds": float(get(COPT.Attr.SolvingTime)),
        "nodes": float(get(COPT.Attr.NodeCnt)),
        "has_mip_solution": bool(get(COPT.Attr.HasMipSol)),
        "best_bound_numerical": (
            float(get(COPT.Attr.BestBnd)) if args.mode == "optimize" else None
        ),
    }
    if report["has_mip_solution"]:
        if args.mode == "exclude":
            values = model.getInfo(COPT.Info.Value, model.getVars())
            report["objective"] = sum(
                coefficient * value
                for coefficient, value in zip(objective_coefficients, values)
            )
        else:
            report["objective"] = float(get(COPT.Attr.BestObj))
        model.writeSol(str(args.outdir / "best.sol"))
    if args.mode == "exclude" and int(report["mip_status"]) == int(COPT.INFEASIBLE):
        report["strict_claim"] = (
            "solver_terminal_infeasibility_for_reduced_objective_at_most_target"
        )
    (args.outdir / "result.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
