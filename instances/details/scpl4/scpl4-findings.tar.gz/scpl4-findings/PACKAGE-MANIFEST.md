# Package manifest: scpl4

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 51
Excluded source files: 1

## Included files

- `README.md`
- `analysis/copt-aggressive-600s-solution-verification.json`
- `analysis/copt-aggressive-600s.json`
- `analysis/copt-exclude213-3600-archive.json`
- `analysis/copt-reduced-1200s-solution-verification.json`
- `analysis/copt-reduced-1200s.json`
- `analysis/copt-root-dual-verification.json`
- `analysis/copt-root-dual.json`
- `analysis/dominance-certificate.json.gz`
- `analysis/dominance-summary.json`
- `analysis/dominance-verification.json`
- `analysis/exact-target213-12h-archive.json`
- `analysis/experiment-status.json`
- `analysis/gurobi-structure.json`
- `analysis/proof-target212.json`
- `analysis/proof-target213-incomplete.json`
- `analysis/proof-target213.json`
- `analysis/public-solution-verification.json`
- `analysis/reduced-structure-lp.json`
- `analysis/replay-target212.json`
- `analysis/replay-target213.json`
- `analysis/scpl4-dominance-reduced.mps.gz`
- `background.md`
- `experiments/launch_altman.sh`
- `experiments/launch_euler4.sh`
- `input/SHA256SUMS`
- `logs/copt-aggressive-600s.log`
- `logs/copt-exclude213-3600/result.json`
- `logs/copt-exclude213-3600/solver.log`
- `logs/copt-exclude213-3600/stdout.log`
- `logs/copt-reduced-1200s.log`
- `logs/gurobi-read-euler4.log`
- `logs/proof-target212.log`
- `logs/proof-target213-incomplete.log`
- `logs/proof-target213.log`
- `logs/reduced-structure-lp.log`
- `scripts/copt_lp_dual.py`
- `scripts/dominance_reduce.py`
- `scripts/exact_setcover_bnb.py`
- `scripts/gurobi_read_structure.py`
- `scripts/run_copt_reduced.py`
- `scripts/run_gurobi_reduced.py`
- `scripts/setcover_io.py`
- `scripts/verify_dominance.py`
- `scripts/verify_lp_dual.py`
- `scripts/verify_setcover_bnb.py`
- `scripts/verify_setcover_solution.py`
- `solutions/copt-aggressive-600s.sol`
- `solutions/copt-reduced-1200s.sol`
- `solutions/scpl4-public-4.sol.gz`
- `solutions/scpl4-public-reduced.sol`

## Excluded files

- `input/scpl4.mps.gz (10112134 bytes; raw benchmark input; sha256 5ee51ae9acd1e9f23490a7aee4fb9103e95253a9d41b98097a70a1fe4aa388a8)`
