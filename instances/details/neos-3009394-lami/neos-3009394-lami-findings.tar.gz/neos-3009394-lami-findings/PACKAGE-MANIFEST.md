# Package manifest: neos-3009394-lami

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 14
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/bottleneck-matching-certificate.json`
- `artifacts/exact-solution-audit.json`
- `artifacts/experiment-summary.json`
- `artifacts/official-info.yaml`
- `artifacts/structure-and-solution-audit.json`
- `logs/copt-global-300s.log`
- `logs/gurobi-global-300s.log`
- `reports/neos-3009394-lami-study-zh.md`
- `scripts/analyze_structure.py`
- `scripts/solve_bottleneck_matching.py`
- `solutions/matching-optimal.sol`
- `solutions/official-5.5.sol`
- `solutions/official-5.5.sol.gz`

## Excluded files

- `input/neos-3009394-lami.mps.gz (47877 bytes; raw benchmark input; sha256 e394f664a010d3aeddbbd8494a85a66b673a57e6bfd8f5c0af8849168d3e0e0b)`
