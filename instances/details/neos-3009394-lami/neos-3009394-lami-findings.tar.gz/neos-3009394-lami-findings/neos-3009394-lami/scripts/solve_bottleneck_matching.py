#!/usr/bin/env python3
"""Solve neos-3009394-lami exactly as a bottleneck bipartite matching.

The MPS assigns 26 labelled points to distinct cells of a 5-by-6 grid.  Four
one-hot binaries for each unordered point pair merely select a strict row or
column order.  Once that extended formulation is removed, feasibility at a
candidate objective is a 26-by-30 bipartite matching problem.
"""

from __future__ import annotations

import argparse
import collections
import gzip
import json
from decimal import Decimal, getcontext
from pathlib import Path


getcontext().prec = 80
SECTIONS = {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}


def number(text: str) -> Decimal:
    return Decimal(text.replace("D", "E").replace("d", "e"))


def open_text(path: Path):
    return gzip.open(path, "rt", encoding="latin-1") if path.suffix == ".gz" else path.open("rt", encoding="latin-1")


def parse_mps(path: Path):
    row_type: dict[str, str] = {}
    rhs: dict[str, Decimal] = collections.defaultdict(Decimal)
    rows: dict[str, dict[str, Decimal]] = collections.defaultdict(dict)
    objective: dict[str, Decimal] = collections.defaultdict(Decimal)
    lower: dict[str, Decimal] = collections.defaultdict(Decimal)
    upper: dict[str, Decimal] = {}
    objective_row = None
    section = None
    with open_text(path) as handle:
        for raw in handle:
            fields = raw.split()
            if not fields or fields[0].startswith("*"):
                continue
            if not raw[0].isspace() and fields[0] in SECTIONS:
                section = fields[0]
                continue
            if section == "ROWS":
                row_type[fields[1]] = fields[0]
                if fields[0] == "N":
                    objective_row = fields[1]
            elif section == "COLUMNS":
                if "'MARKER'" in fields:
                    continue
                variable = fields[0]
                for offset in range(1, len(fields), 2):
                    row, value = fields[offset], number(fields[offset + 1])
                    if row == objective_row:
                        objective[variable] += value
                    else:
                        rows[row][variable] = rows[row].get(variable, Decimal(0)) + value
            elif section == "RHS":
                for offset in range(1, len(fields), 2):
                    rhs[fields[offset]] += number(fields[offset + 1])
            elif section == "BOUNDS":
                kind, variable = fields[0], fields[2]
                value = number(fields[3]) if len(fields) > 3 else Decimal(0)
                if kind == "LO":
                    lower[variable] = value
                elif kind == "UP":
                    upper[variable] = value
                elif kind == "FX":
                    lower[variable] = upper[variable] = value
                elif kind == "BV":
                    lower[variable], upper[variable] = Decimal(0), Decimal(1)
                elif kind == "FR":
                    lower[variable], upper[variable] = Decimal("-Infinity"), Decimal("Infinity")
                else:
                    raise ValueError(f"unexpected bound type {kind}")
    return row_type, rhs, rows, objective, lower, upper


def read_solution(path: Path) -> dict[str, Decimal]:
    values = {}
    with path.open("rt", encoding="utf-8") as handle:
        for raw in handle:
            fields = raw.split()
            if len(fields) != 2 or fields[0].startswith(("#", "=")):
                continue
            values[fields[0]] = number(fields[1])
    return values


def maximum_matching(adjacency: list[list[int]], cell_count: int):
    """Return a maximum matching and the alternating Hall witness."""

    match_cell = [-1] * cell_count

    def augment(item: int, seen: list[bool]) -> bool:
        for cell in adjacency[item]:
            if seen[cell]:
                continue
            seen[cell] = True
            if match_cell[cell] == -1 or augment(match_cell[cell], seen):
                match_cell[cell] = item
                return True
        return False

    cardinality = 0
    for item in range(len(adjacency)):
        if augment(item, [False] * cell_count):
            cardinality += 1
    match_item = [-1] * len(adjacency)
    for cell, item in enumerate(match_cell):
        if item >= 0:
            match_item[item] = cell

    # Alternating reachability from unmatched left vertices.  For a maximum
    # matching, S=reachable_items and N(S)=reachable_cells form a Hall witness.
    reachable_items = {item for item, cell in enumerate(match_item) if cell < 0}
    reachable_cells: set[int] = set()
    queue = collections.deque(reachable_items)
    while queue:
        item = queue.popleft()
        for cell in adjacency[item]:
            if match_item[item] == cell or cell in reachable_cells:
                continue
            reachable_cells.add(cell)
            matched_item = match_cell[cell]
            if matched_item >= 0 and matched_item not in reachable_items:
                reachable_items.add(matched_item)
                queue.append(matched_item)
    return cardinality, match_item, sorted(reachable_items), sorted(reachable_cells)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("--official-solution", type=Path)
    parser.add_argument("--certificate", type=Path)
    parser.add_argument("--solution-output", type=Path)
    args = parser.parse_args()

    row_type, rhs, rows, objective, lower, upper = parse_mps(args.mps)
    official = read_solution(args.official_solution) if args.official_solution else {}

    point_count, first_coordinate_count, second_coordinate_count = 26, 5, 6
    cells = [
        (first_coordinate, second_coordinate)
        for second_coordinate in range(second_coordinate_count)
        for first_coordinate in range(first_coordinate_count)
    ]
    a_names = [f"C{2706 + item:04d}" for item in range(point_count)]
    b_names = [f"C{2732 + item:04d}" for item in range(point_count)]
    t_name = "C0001"
    if objective != {t_name: Decimal(1)}:
        raise RuntimeError("unexpected objective")
    if any((lower[name], upper[name]) != (Decimal(0), Decimal(4)) for name in a_names):
        raise RuntimeError("unexpected first-coordinate bounds")
    if any((lower[name], upper[name]) != (Decimal(0), Decimal(5)) for name in b_names):
        raise RuntimeError("unexpected second-coordinate bounds")

    for cell_index in range(point_count * point_count):
        option = [
            f"C{2 + cell_index:04d}",
            f"C{678 + cell_index:04d}",
            f"C{1354 + cell_index:04d}",
            f"C{2030 + cell_index:04d}",
        ]
        row = f"R{1 + cell_index:04d}"
        if row_type[row] != "E" or rhs[row] != 1 or rows[row] != {variable: Decimal(1) for variable in option}:
            raise RuntimeError(f"unexpected set-partitioning row {row}")

    minus_rhs = [rhs[f"R{1977 + item:04d}"] for item in range(point_count)]
    plus_rhs = [rhs[f"R{2003 + item:04d}"] for item in range(point_count)]
    for item in range(point_count):
        expected_minus = {t_name: Decimal(1), a_names[item]: Decimal(-1), b_names[item]: Decimal(-1)}
        expected_plus = {t_name: Decimal(1), a_names[item]: Decimal(1), b_names[item]: Decimal(-1)}
        if rows[f"R{1977 + item:04d}"] != expected_minus or rows[f"R{2003 + item:04d}"] != expected_plus:
            raise RuntimeError(f"unexpected objective-envelope rows for item {item}")

    # Verify all 325 active four-way disjunctions.  The other diagonal/lower
    # triangular partition rows contain dummy binaries and do not affect the model.
    pair_rows = []
    for first in range(point_count):
        for second in range(first + 1, point_count):
            pair_rows.append((first, second))
    if len(pair_rows) != 325:
        raise RuntimeError("unexpected pair count")
    for pair_index, (first, second) in enumerate(pair_rows):
        cell_index = first * point_count + second
        option = [
            f"C{2 + cell_index:04d}",
            f"C{678 + cell_index:04d}",
            f"C{1354 + cell_index:04d}",
            f"C{2030 + cell_index:04d}",
        ]
        expected = [
            {option[1]: Decimal(5), a_names[first]: Decimal(1), a_names[second]: Decimal(-1)},
            {option[0]: Decimal(5), a_names[first]: Decimal(-1), a_names[second]: Decimal(1)},
            {option[3]: Decimal(6), b_names[first]: Decimal(1), b_names[second]: Decimal(-1)},
            {option[2]: Decimal(6), b_names[first]: Decimal(-1), b_names[second]: Decimal(1)},
        ]
        row_names = [
            f"R{677 + pair_index:04d}",
            f"R{1002 + pair_index:04d}",
            f"R{1327 + pair_index:04d}",
            f"R{1652 + pair_index:04d}",
        ]
        for row, expected_coefficients, expected_rhs in zip(row_names, expected, (4, 4, 5, 5)):
            if row_type[row] != "L" or rhs[row] != expected_rhs or rows[row] != expected_coefficients:
                raise RuntimeError(f"unexpected pair-order row {row}")

    costs: list[list[Decimal]] = []
    for item in range(point_count):
        costs.append(
            [
                max(Decimal(column + row) + minus_rhs[item], Decimal(row - column) + plus_rhs[item])
                for column, row in cells
            ]
        )
    thresholds = sorted({cost for item_costs in costs for cost in item_costs})

    optimum = None
    optimum_matching = None
    predecessor = None
    predecessor_result = None
    for threshold_index, threshold in enumerate(thresholds):
        adjacency = [[cell for cell, cost in enumerate(item_costs) if cost <= threshold] for item_costs in costs]
        result = maximum_matching(adjacency, len(cells))
        if result[0] == point_count:
            optimum = threshold
            optimum_matching = result[1]
            if threshold_index:
                predecessor = thresholds[threshold_index - 1]
                predecessor_adjacency = [
                    [cell for cell, cost in enumerate(item_costs) if cost <= predecessor] for item_costs in costs
                ]
                predecessor_result = maximum_matching(predecessor_adjacency, len(cells))
            break
    if optimum is None or optimum_matching is None or predecessor is None or predecessor_result is None:
        raise RuntimeError("failed to solve bottleneck matching")

    predecessor_cardinality, _, hall_items, hall_cells = predecessor_result
    if len(hall_items) <= len(hall_cells):
        raise RuntimeError("failed to extract a deficient Hall set")
    assignment = [cells[cell] for cell in optimum_matching]
    official_assignment = [
        (int(official.get(a_names[item], 0)), int(official.get(b_names[item], 0))) for item in range(point_count)
    ] if official else []
    official_cost = max(
        max(Decimal(column + row) + minus_rhs[item], Decimal(row - column) + plus_rhs[item])
        for item, (column, row) in enumerate(official_assignment)
    ) if official else None
    sixth_row_cost = min(
        costs[item][cell]
        for item in range(point_count)
        for cell, (_, second_coordinate) in enumerate(cells)
        if second_coordinate == 5
    )

    certificate = {
        "instance": "neos-3009394-lami",
        "reduction": "26 labelled points assigned injectively to a 5-by-6 integer grid",
        "items": point_count,
        "grid_cells": len(cells),
        "cost_formula": "cost(i,a,b)=max(a+b+minus_rhs[i], -a+b+plus_rhs[i])",
        "optimal_objective": str(optimum),
        "predecessor_threshold": str(predecessor),
        "predecessor_maximum_matching": predecessor_cardinality,
        "minimum_cost_on_sixth_grid_row": str(sixth_row_cost),
        "pigeonhole_proof": (
            "For any objective below 5.5 the sixth grid row is forbidden, leaving only "
            "5*5=25 cells for 26 distinct labelled points."
        ),
        "active_pair_order_binaries": 4 * len(pair_rows),
        "dummy_partition_binaries": 4 * (point_count * point_count - len(pair_rows)),
        "hall_witness": {
            "items": hall_items,
            "item_count": len(hall_items),
            "neighbor_cells": [list(cells[cell]) for cell in hall_cells],
            "neighbor_count": len(hall_cells),
            "deficiency": len(hall_items) - len(hall_cells),
        },
        "optimal_assignment": [list(cell) for cell in assignment],
        "official_assignment": [list(cell) for cell in official_assignment],
        "official_objective_recomputed": str(official_cost) if official_cost is not None else None,
        "checks": {
            "all_pair_disjunctions_match": True,
            "sixth_grid_row_starts_at_optimum": sixth_row_cost == optimum,
            "optimal_assignment_is_injective": len(set(assignment)) == point_count,
            "matching_reaches_all_items_at_optimum": len(optimum_matching) == point_count and min(optimum_matching) >= 0,
            "predecessor_matching_is_deficient": predecessor_cardinality < point_count,
            "hall_witness_is_deficient": len(hall_items) > len(hall_cells),
            "official_assignment_is_injective": not official_assignment or len(set(official_assignment)) == point_count,
            "official_objective_matches_its_coordinates": (
                official_cost is None or official_cost == official.get(t_name)
            ),
        },
    }
    if not all(certificate["checks"].values()):
        failed = [name for name, passed in certificate["checks"].items() if not passed]
        raise SystemExit(f"certificate checks failed: {failed}; optimum={optimum}; official_cost={official_cost}")

    if args.solution_output:
        args.solution_output.parent.mkdir(parents=True, exist_ok=True)
        with args.solution_output.open("wt", encoding="utf-8", newline="\n") as handle:
            handle.write(f"=obj= {optimum}\n")
            handle.write(f"{t_name} {optimum}\n")
            for item, (column, row) in enumerate(assignment):
                if column:
                    handle.write(f"{a_names[item]} {column}\n")
                if row:
                    handle.write(f"{b_names[item]} {row}\n")
            for first in range(point_count):
                for second in range(point_count):
                    cell_index = first * point_count + second
                    if first >= second:
                        option = 0
                    else:
                        a_first, b_first = assignment[first]
                        a_second, b_second = assignment[second]
                        if a_first > a_second:
                            option = 0
                        elif a_first < a_second:
                            option = 1
                        elif b_first > b_second:
                            option = 2
                        else:
                            option = 3
                    variable_number = (2, 678, 1354, 2030)[option] + cell_index
                    handle.write(f"C{variable_number:04d} 1\n")

    rendered = json.dumps(certificate, indent=2, ensure_ascii=False)
    print(rendered)
    if args.certificate:
        args.certificate.parent.mkdir(parents=True, exist_ok=True)
        args.certificate.write_text(rendered + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
