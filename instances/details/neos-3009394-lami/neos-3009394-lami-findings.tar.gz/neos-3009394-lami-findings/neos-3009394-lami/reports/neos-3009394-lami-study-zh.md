#  `neos-3009394-lami` Structural analysis with exact optimality proof

## Conclusion

The official feasible value of 5.5 is globally optimal:

```text
OPT = 5.5。
```

proof does not depend on the floating-point MIP gap. The original model can be reduced to an exact 26 integer with a 5 × 6 tag point.
Under any objective less strict than 5.5, the sixth row grid cannot be used.
Placing 26 pairwise distinct points in 25 cells gives an immediate contradiction. The 5.5 solution produced by the matching script is translated back
After returning the original 2,757 variable, line through the entire 2,028 with tolerance 0.

##  Models recovered from MPS

The variable is structured as:

-  `C0001`: the only continuous variables, but also objective `t`;
-  `C0002` `C2705`: 2,704 is a binary variable;
-  `C2706` `C2731`: 26 is an integer of the coordinate `a_i in {0,...,4}`;
-  `C2732` `C2757`: 26 is an integer of the coordinates `b_i in {0,...,5}`.

The first 676 rows are one-of-four selection equalities, forming 26-by-26 cells with four options per cell.
Only the `C(26,2)=325` cells in the strict upper triangle participate in subsequent constraints. For each pair `i<j`, the four
Activate the options separately

```text
a_i > a_j，a_i < a_j，b_i > b_j，b_i < b_j。
```

So this 1,300 is a valid binary variable that's just two points `(a_i,b_i)` and `(a_j,b_j)` in the proof.
are different. The 351 four-choice cells on the diagonal and below it, totaling 1,404 binary variables, have no other
Gurobi presolve also removes the 1,404 column.

Finally, the 52 line is given for each point.

```text
t >=  a_i + b_i + c_i
t >= -a_i + b_i + d_i，
```

where `c_i,d_i` is the finite decimal constant in MPS.
Complete, the original problem is equivalent to matching 26 one by one to a grid unit 30, making the maximum cost
The smallest one.

## strict lower bound

The script evaluates all 26×30 item-cell edges with `Decimal`. For the cells with second coordinate `b=5`,
Across all 130 combinations of item and first coordinate, the minimum cost is exactly 5.5. Thus if `t<5.5`, any
No point can be placed on the sixth line, only used

```text
{0,...,4} × {0,...,4}
```

the 25 cells within it. However, the 325 four-direction inequalities require the 26 points to be pairwise distinct; the pigeonhole principle immediately
It's not impossible.

The same proof can be expressed with a Hall set: at the last discrete threshold below 5.5,
`5.428571429`, the neighbouring set of all 26 items is correct for the above 25 units, the defect is 1.
Maximum matching is only 25.

## strict primal bound

In the 5.5 threshold, the standard binary map width-increasing algorithm finds the matching of the size of 26.
The size relation selects the original four-direction variable and selects the first option for all functionless cells, generating
`matching-optimal.sol`. The original MPS exact test result was:

```text
objective=5.5
rows=2028, exact_row_violations=0
bound_violations=0
integrality_violations=0
```

Therefore, the lower bound and the primal bound in the 5.5 closure are globally optimal proof, rather than local certificate or solver timeout boundaries.

##  General solver baseline

|  Method | CPU threads |  Time | The best solution | Finally lower bound | Number of nodes |
|---|---:|---:|---:|---:|---:|
| Gurobi 13.0.1, formerly MPS + official start |  64  |  300 s  |  5.5  |  1.7142857143  |  3,737,930  |
| COPT 8.0.4, originally MPS + official start |  64  |  300 s  |  5.5  |  1.642857143  |  2,289,531  |
| Exact bottle of wine matching / Hall certificate |  1  | It's about 0.15 s |  5.5  |  **5.5**  |  —  |

The gap between the two sets of general-purpose MIPs at 300 seconds is still greater than the 68 %.
GPU0 is not used.

##  Why is the original MIP difficult?

The original model introduced the 1,300 as a valid pair-order binary variable for simple binary position differentials, and
Keep 1,404 a complete redundant one-hot variable. This extended LP relaxation is weak and the same.
The coordinate layout can accommodate a large number of directional choices. General branch-and-bound will repeat enumeration.
Synchronousness; after directly restoring grid matching, the standard library script can solve and output Hall certificate in about 0.15 seconds.

## material

-  [MIPLIB `neos-3009394-lami` page ](https://miplib.zib.de/instance_details_neos-3009394-lami.html)]
-  [MIPLIB download with solution archive ](https://miplib.zib.de/download.html)]
