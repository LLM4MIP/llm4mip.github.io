# bab3

Official MIPLIB status: open. The public objective `-656214.95420` was audited
against every original constraint, bound, and integer domain. No new bound was
found.

## Structure and method

The model has 393,800 binary-domain variables, 23,069 rows, and 3,301,838
nonzeros. Structural analysis identified 224 exact categorical blocks with 271
alternatives each and 28 eight-block components. Exact filtering and
identical-row-effect dominance were used before enumeration.

All 224 one-block scans, 562 relevant pair scans, and all 28 surviving full
component products were completed. The component closure tested 752,334 tuples;
only 28 were feasible, one per component, and all best objective deltas were
zero.

## Evidence boundary

The incumbent is optimal in the fixed-unassigned 224-block categorical
neighborhood. Variables outside those blocks can still couple components, so
this is not a global decomposition or a global-optimality proof.

Sources: [MIPLIB instance page](https://miplib.zib.de/instance_details_bab3.html),
[original benchmark description](https://mic.optimatorlab.org/models/bab.html).

