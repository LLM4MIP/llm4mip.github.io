# Package manifest: fhnw-schedule-paira400

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 12
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/independent-cross-audit.json`
- `artifacts/invalid-old-cut-counterexample.json`
- `artifacts/paira400-safe-suffix-master.mps.gz`
- `artifacts/safe-suffix-master-proof.json`
- `artifacts/summary.json`
- `experiments/paira400-safe-suffix-master-first.log`
- `experiments/paira400-safe-suffix-master-rerun.log`
- `input/SHA256SUMS`
- `input/fhnw-schedule-paira400-public.sol.gz`
- `reports/deep-study-2026-09-08.zh.md`
- `solutions/global-optimal.sol`

## Excluded files

- `input/fhnw-schedule-paira400.mps.gz (3017847 bytes; raw benchmark input; sha256 6c6d547a5bceae81f2fc0d03ba38c9479eebc97015e1a40e0ba971813266f4a2)`
