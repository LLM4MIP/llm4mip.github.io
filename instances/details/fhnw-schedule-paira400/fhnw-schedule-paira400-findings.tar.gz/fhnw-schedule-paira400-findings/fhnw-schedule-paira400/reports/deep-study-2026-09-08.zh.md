# Independent optimality verification for `fhnw-schedule-paira400` (2026-09-08)

## Conclusion

This round was obtained and independently verified by a **solver-verified global optimum**:

```text
Optimal objective value -36.27696674236886
Select the number of jobs 60
master primal     -36.27696674236886
master dual       -36.27696674236886
gap                0
```

In comparison, the middle strict feasible value of the original MPS audit has already been passed.
`-36.276622209826776`, improved with `0.000344532542084`.
The Pair-A tolerance solution objective `-35.54680465280395` was published.
`0.73016208956491`; the public solution itself contains a tolerance integer whose direct input option has been proven.
It cannot be excluded, so it should be clearly distinguished between public tolerance objective and strict feasible benchmarks when reporting externally.
Another numerical `-35.45840605462827` is the recalculation value of the public variables Pair-B400.
It is not a strict benchmark for Pair-A400.

This is not a DRAT/LRAT certification.
Global effective 0 -1 relaxation is independently sought by Gurobi to be primal=dual, while the same objective solution is sought by Gurobi.
It reconstructed two official formulations and audited the entire line through high-precision original MPS.

##  1 . original model Structural audit

### Pair A

-  80,600 variable: 400 is an optional binary variable; 400 is a continuous start time variable;
`C(400,2)=79,800` is a binary variable of the preceding order;
-  160,000 article constraint, 479,504 nonzero entries;
-  159,600 two or two non-overlapping constraint all row by row verification;
-  The 96 single variable equation selects the corresponding variable fixed as 0;
-  The rest of the 304 operational constraints give the latest start time when the pump is selected.

### Pair B

-  160,400 variable, 399,096 bar constraint, 1,197,096 nonzero entries;
-  Each unordered operation has two auxiliary binary variables and five constraints;
-  399,000 column pairs line all row by row verification;
-  fixed for the 0 96 operation consistent with Pair A complete.

304 has the objective coefficients of release time, processing time, and
The maximum processing recovery time is equal to `2.84e-14`, from the floating-point of the large M coefficient.
Delete. Complete the deadline calculation as follows:

```text
d_i = latest_start_i + processing_time_i.
```

304 with an optional function `d_i` is 1 (Pair A's MPS floating-point recovery range is:
`[0.999999999999994, 1.0000000000000568]`）。

##  2. After-sales capacity relaxation

Common security deadlines

```text
D_safe = 1.000000000001057,
```

It is larger than the maximum recovery deadline of at least `1.00009e-12` in Pair A, thus avoiding
MPS's approximate `1e-14` equals the error error as a mathematical reinforcement.

For each release threshold `t`, any feasible solution to the original problem must meet:

```text
sum_{i: r_i >= t} p_i z_i <= D_safe - t.
```

The reason for this is that these tasks cannot be completed before `t` and must be completed no later than `D_safe`.
The total capacity of the `[t,D_safe]` is only `D_safe-t`. These constraints are therefore global valid for the original problem.
The preferred model to use them is the relaxation of the original MIP.
The optimal value is the legal global lower bound.

Independent constructed masters include:

-  400 is a binary choice variable;
-  96 original fixed zero constraint;
-  304 full release-suffix capacity constraint;
-  The objective function is the same as the original Pair A complete.

400 variable of the master, 400 bar constraint, 46,456 nonzero entries were checked; no entries were found.
variable mapping, coefficient, support set, direction or right end error.

##  3. two independent master solve

2 threads, Seed 29, NumericFocus 2:

```text
status   OPTIMAL
primal   -36.27696674236886
dual     -36.27696674236886
gap      0
nodes    61
runtime  0.130 s
```

Save proof MPS and read it again and change it to 1 thread, Seed 73, NumericFocus 3,
MIPFocus 3 is obtained by:

```text
status   OPTIMAL
primal   -36.27696674236886
dual     -36.27696674236886
gap      0
nodes    35
runtime  0.154 s
```

Additionally, the suffix master is generated directly from Pair B and loosens the security common deadline.
`1e-12`, step-by-step verification Its 400 clause constraint; using Seed 101 / 149, different threads are also re-run.
The same zero gap optimum value. The previous Pair B numerical override for `D=1` was recovered by Decimal.
The boundary value of `1.0000000000000002` is reserved for numerical cross-checks only and is no longer used as proof.

##  4. Create a strict sequence from the selected set

The master selects the 60 tasks. These tasks are sorted by release time and not in descending order.
The earliest feasible start time:

```text
s_k = max(r_k, s_{k-1}+p_{k-1}).
```

The last selected task was completed at `0.9993391698566962`, strictly ahead of all completion deadlines.

###  Replacing Pair A

Keep this 60 job sequence, and then add the unselected job sequence, and then complete the 400 -job.
The sequence has makespan `99.21017075197013 < 400`. The complete order determines 79,800
Pair-A order binaries. Use the 60 bit decimal plus to re-check the original 160,000 line:

```text
objective value -36.27696674236886495400
Maximum variable bound violation 0
Maximum integrality violation of the 0
Maximum row violation 3.406e-14
row violation greater than 1e-9 0
```

###  Replacing Pair B

Re-construct joint-selection and direction binary variables for each task and no task will be selected
Start times are set to the respective original release times. Recheck all 399,096 original rows:

```text
objective value -36.27696674236886495400
Maximum variable bound violation 0
Maximum integrality violation of the 0
Maximum row violation 3.0e-16
row violation greater than 1e-9 0
```

Because the master's global lower bound is equal to the objective of the original model strictly feasible solution, Pair A's globally optimal performance is the same.
This closure; the independent suffix master of Pair B and the original MPS iteration also yield the same conclusion.

##  5. Correction of the old 750 article cuts

Early `method02` experiments mistakenly called the primal bound of the start variable the completion deadline.
The processing time was omitted:

```text
Incorrect: d_i = UB(start_i)
Correct: d_i = UB(start_i) + p_i
```

Therefore, the 750 energetic cuts from the file transfer cannot be used for proof optimal.
Verifiable counterexample: The old `energy_lp_44` is given to the working `{108,335}`

```text
Error cut LHS 0.9950234323134086
RHS            0.9948513622720969
Surface violation of the 0.0001720700413117
```

However, both tasks are strictly feasible in both original MPS according to the `108 -> 335` layout.
The deadline is recalculated and the necessary processing for the same interval is only `0.9880390761480027 <= RHS`.
The dual, zero gap and `OPTIMAL` labels of the proof model were all revoked; it generated
`-36.276622209826776` solution can still be kept as intermediate primal as independent of the original MPS check.

Finally, the proof complete of `-36.27696674236886` does not depend on the 750 error cuts.

##  6. Key evidence

-  `../artifacts/independent-cross-audit.json` ](../artifacts/independent-cross-audit.json): complete structure, mapping, original MPS and proof chain audit;
-  `../artifacts/safe-suffix-master-proof.json` ](../artifacts/safe-suffix-master-proof.json):Pair A security suffix master to solve twice;
-  [`../../fhnw-schedule-pairb400/artifacts/` ](../../fhnw-schedule-pairb400/artifacts/): with `1e-12`
the deadline for Pair B master, logs and step-by-step semantic audit;
-  [`../artifacts/paira400-safe-suffix-master.mps.gz` ](../artifacts/paira400-safe-suffix-master.mps.gz): Pair A relaxation model that can be run over;
- [ `../solutions/global-optimal.sol` ](../solutions/global-optimal.sol) : Pair A strict optimal solution ; 
-  `../../fhnw-schedule-pairb400/solutions/global-optimal.sol` ](../../fhnw-schedule-pairb400/solutions/global-optimal.sol): Pair B cross verification solution;
-  `../artifacts/invalid-old-cut-counterexample.json` ](../artifacts/invalid-old-cut-counterexample.json): original model feasible counterexample of old energetic cut.
