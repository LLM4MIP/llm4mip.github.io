# fhnw-schedule-paira400 — solver-verified OPT = -36.27696674236886

2026-09-14 independent dual-bound review: [adopted bound, proof chain, checks, and limitations](../../docs/dual-bound-audit-2026-09-14/cases/fhnw-schedule-paira400.zh.md). Reviewed lower bound: **-36.276966742368865136**. Use this exact certified decimal; superseded floating-point headline digits below are historical. This review distinguishes exact, literature, and numerical evidence; historical statements below remain dated records.

Official MIPLIB page: <https://miplib.zib.de/instance_details_fhnw-schedule-paira400.html>

## Result

```text
MIPLIB headline     -35.54680465280395
new strict optimum  -36.27696674236886
improvement           0.73016208956491
selected jobs        60
```

This is a **solver-verified global conclusion**, not a portable formal MIP
certificate. A conservative 400-binary relaxation constructed from the
official Pair-A rows is solved to zero gap twice, and its optimum is matched by
a complete solution that passes all 160,000 rows of the untouched Pair-A MPS.
The same selection is independently reconstructed and audited in Pair B.

## Safe release-suffix master

The original model has 80,600 variables, including 79,800 pair-order binaries,
and a weak pairwise big-M relaxation. Of the 400 jobs, 96 are fixed to zero and
304 eligible jobs share completion deadline 1, up to MPS decimal roundoff.

For every release threshold `t`, any feasible single-machine schedule must
satisfy

```text
sum_{i: r_i >= t} p_i z_i <= D_safe - t,
```

where `D_safe = 1.000000000001057` is strictly no smaller than every completion
deadline recovered from Pair A. The model consisting of the original objective,
96 fixed-zero rows and all 304 suffix-capacity rows is therefore a relaxation;
its minimum is a valid global lower bound.

The first run (2 threads, Seed 29) closes in 0.130 seconds and 61 nodes. The
frozen master is then reread with one thread, Seed 73 and different settings;
it closes in 0.154 seconds and 35 nodes at the same objective and bound. The
selected jobs, ordered by release time, finish at `0.9993391698566962`.
Decimal substitution gives maximum Pair-A row violation `3.406e-14`, with zero
bound/integrality violations and no row violation above `1e-9`.

## Correction of an earlier invalid attempt

An earlier local experiment incorrectly used `UB(start_i)` as a completion
deadline instead of `UB(start_i) + p_i`. Its 750 energetic cuts and every dual,
zero-gap or `OPTIMAL` claim derived from them are rejected. Jobs `{108,335}`
give an explicit original-MPS-feasible counterexample to one such cut. The final
result above is independent of all rejected cuts. See
[`invalid-old-cut-counterexample.json`](artifacts/invalid-old-cut-counterexample.json)
and the detailed report for the audit trail.

## Evidence

- [`summary.json`](artifacts/summary.json) gives the compact conclusion.
- [`paira400-safe-suffix-master.mps.gz`](artifacts/paira400-safe-suffix-master.mps.gz)
  is the frozen relaxation.
- [`safe-suffix-master-proof.json`](artifacts/safe-suffix-master-proof.json)
  records both runs and the mathematical validity statement.
- [`independent-cross-audit.json`](artifacts/independent-cross-audit.json)
  records the Pair-A/Pair-B structure, mappings and original-MPS audits.
- [`global-optimal.sol`](solutions/global-optimal.sol) is the final Pair-A witness.
- [`deep-study-2026-09-08.zh.md`](reports/deep-study-2026-09-08.zh.md) is the
  detailed Chinese report.

The independent Pair-B safe-master build and portable generation/audit scripts
are archived under [`../fhnw-schedule-pairb400/`](../fhnw-schedule-pairb400/).
Hashes are in [`input/SHA256SUMS`](input/SHA256SUMS).
