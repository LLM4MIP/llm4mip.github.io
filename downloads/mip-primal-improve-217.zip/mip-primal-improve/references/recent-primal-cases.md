# Primal Decisions from the September-October Research

These are selected transferable lessons from repository commit `8779d862b692348321c3607642f63e6c443cae09`, whose latest research publication is dated 2026-10-06. The review read published reports and summaries; it did not rerun their optimizers or all witness checkers. Follow the linked evidence and model hash when reproducing a case. Historical machine paths, CPU assignments, and deadlines are not live execution settings. Overall inventory and baseline definitions are maintained in [repository-refresh-20261012.md](repository-refresh-20261012.md).

## 1. Search Semantic States, Then Release Sufficient Recourse

**Threshold chains.** In `supportcase38`, 167 implication chains of 15 binary variables each encode only 16 threshold states. Recover the chain directions and admissible states from rows, then release one or several whole thresholds. A bit Hamming ball needlessly encodes these states and can prohibit the effective move. Fix the remaining integers and release continuous recourse broadly enough to evaluate the change.

The reported trajectory was `32565.75628454652 -> 32564.91155530251 -> 32564.554326849717 -> 32564.500162611843`. The first improving neighborhood released several groups, but only group 4 changed integers: this does not establish that joint-group changes were necessary. Reoptimizing all continuous variables improved that pattern again; one additional group-4 bit change with full recourse gave the final point. All 16 group-4 states were later closed only with the other binaries fixed. Public-vector crossover and LP-guided group pairs yielded no further material gain.

For a large neighborhood, form each residual RHS directly from the fixed-variable contribution, `b_N = b - A_fixed * x_fixed`, using sufficient accumulation accuracy. Do not subtract two large nearly equal full activities when a direct sum is available. Keep explicit mappings for every original variable and objective constant. Here, a cancellation-sensitive builder and a serializer that renamed `ONE_VAR_CONSTANT` to `x0` produced rejected candidates; neither was an improvement. An empty MIP basis export was also rejected before an explicit LP supplied a usable basis. The final witness passed `1e-9` checks with nonzero residuals, so it is tolerance-feasible despite rational checking.

Source: [supportcase38 methods, trajectory, and rejected attempts](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/supportcase38/README.md).

**Permutation moves.** `neos-4535459-waipa` exposes an 800-job, 200-machine flowshop. Source-audited single-job insertion descent reduced `26040609` to `23331046`. When a permutation determines many order bits, move the job in that representation, recompute schedule completion, then reconstruct and check the complete original vector. This success supports testing inexpensive domain moves before spending the entire budget on a huge binary neighborhood; it does not prove all order encodings reduce to a permutation.

Source: [waipa construction and original-model validation](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/neos-4535459-waipa/README.md).

## 2. Preserve Balances While Changing Operational Choices

Fixed-charge transportation requires changing arc activations together with the flows that make them useful. Use demand/supply-balanced components, cyclic exchanges, or joint origin-destination regions, then repair all affected flows under original capacities. Closing a one-arc neighborhood says little about this coupled move.

- `n3705`: joint fixed-charge transportation neighborhoods improved `1212657 -> 1208356`.
- `n3707`: component rewiring plus flow repair improved `1186691 -> 1185209`.
- `n370b`: balanced blocks and joint activation/flow moves improved `1216766 -> 1212433`.

Sources: [n3705](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/n3705/README.md), [n3707](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/n3707/README.md), [n370b](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/n370b/README.md).

Extend the same principle to time: a production change can require procurement changes earlier and inventory or service changes later. Choose windows through the actual inventory/constraint graph; release coupled decisions and retain boundary balances. `snp-04-052-052` improved its repaired baseline by `17997.815490` through joint procurement/production/inventory neighborhoods. Its final residual `6.44e-12` passed `1e-9` but was not exact zero. `snp-10-052-052` used count/inventory graph neighborhoods followed by original integer-recourse repair and an exact final witness. These are instance-specific encodings, not a rule that every count admits a particular parity representation.

Sources: [SNP04 neighborhood and acceptance grade](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/snp-04-052-052/README.md), [SNP10 count/inventory route](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/studies/primal-dual-r29-r30-20260926/instances/snp-10-052-052/README.md).

`lr1dr12vc10v70b-t360` combined time windows, route neighborhoods, terminal-service decisions, DP-guided moves, and continuous inventory repair, improving by `1361.654777402921` to an exact-zero witness. `rwth-timetable` used missing-course/relationship groups, enrollment exchanges, shared periods, and public-timetable recombination, improving `772347 -> 772258`. Both continued through their two-hour search windows. Preserve the boundary and resource constraints during proposal generation; projected schedules are hints until original-model repair succeeds.

Sources: [lr1 route/inventory research](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/lr1dr12vc10v70b-t360/README.md), [rwth timetable research](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/rwth-timetable/README.md).

## 3. Pattern Pools Are Candidate Generators with a Physical Lift

In set partitioning, keep an incumbent-feasible pool of duties/patterns, replace related columns, and enlarge the pool around uncovered or expensive relationships. Advisory reduced costs can rank proposals even without a certified dual; they cannot justify removing all other original possibilities. A restricted-pool integer solution may give a valid primal after lifting, while the pool bound and pool infeasibility remain restricted conclusions.

`ivu06-big` selected a 111-duty original binary partition at `140.412332083`, improving `140.74366634`. `ivu59` used validated partition exchanges to improve `912.70015745 -> 911.94105059`; its advisory primal reduced costs were explicitly not asserted dual-feasible.

Sources: [ivu06-big original partition](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/ivu06-big/README.md), [ivu59 partition and advisory scores](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/ivu59/README.md).

When patterns aggregate physical stock, distinguish type availability from individual-item assignment. `supportcase31` progressed from one-to-four-stack original-matrix neighborhoods to type-pool selection and explicit wafer assignment. The first all-double pattern timed out; a different pattern lifted to the original model. A cardinality-constrained bitset subset-sum also constructed a pattern. The final gain was `0.701`, with exact original feasibility; a separate later dual certificate proved optimality. The lift must preserve title exclusivity and never reuse a physical wafer. A small aggregate optimum is not itself a primal vector.

Sources: [supportcase31 primal methods and failed pattern](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/supportcase31/reports/primal_summary.json), [completed original-model result](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/supportcase31/README.md).

## 4. Combine Genuine Blocks Only When Their Shared Decisions Agree

In `perth`, removing eight shared columns leaves 20 private blocks. Each original row belongs to one block; shared objective terms are allocated once across the copies. The independently solved blocks all selected the same shared values, so their private solutions could be assembled and checked on the original model, improving the public point by about `9.5045514634`.

For primal construction, feasible private solutions with agreement suffice; proving each block optimal is unnecessary. If copies disagree, solve a consensus or common-decision repair with all coupling constraints. Do not concatenate incompatible blocks or double-count shared costs. If disagreement persists, use the block pool as hints for an original-model solve. Check actual private variables and row ownership rather than trusting DEC labels. The reported perth closure is solver numerical evidence with tolerance-feasible primal residuals, not an exact rational optimum certificate.

Source: [perth source map, shared-copy agreement, and limitations](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/neos-4290317-perth/README.md).

## 5. Alternate Topology and Continuous Geometry

`ns1904248` alternated discrete geometric connectivity with continuous-coordinate repair, using tree/path search and original-model solver neighborhoods. It improved the strict repaired baseline `37.017633016848471` to exact-zero `35.26253512665094`. A weakened connectivity or coordinate projection can suggest a topology; its raw objective is not an original-model primal result. Restore all original connectivity, domain, and geometric rows before accepting the candidate.

Source: [ns1904248 original lift and baseline distinction](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/ns1904248/README.md).

## 6. Candidate Generators Can Fail Without Invalidating the Method

`neos-848198` used elastic continuous recourse to reduce unmet demand, then released capacities incident to remaining deficits. Some auxiliary searches added a small objective-cost regularizer, so acceptance used actual unweighted deficits and the complete original checker. No material gain was found. Repeated unchanged RINS neighborhoods remained repeated attempts in the ledger; an interrupted worker with a segmentation-fault message was not declared closed. Treat these as failure evidence when choosing the next pilot, not as additional distinct methods or infeasibility proofs.

`hgms30` has 20 maintenance-start choices, four plants, 30 periods, and 30 hydraulic scenarios with different RHS values. Basis-reused recourse, date moves, whole-plant replacement, family-calendar crossover, finite whole-calendar pools, and LP-price guidance were tested. A top-K calendar ranking or surrogate gradient is a proposal heuristic; evaluate a candidate against the complete target-scenario recourse. The accepted result changed no original maintenance Y/Z variables and was classified as continuous numerical polishing. Neither the compact calendar representation nor sibling hints demonstrated a new maintenance design in this run.

Sources: [neos-848198 elastic-repair failures and scope](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/neos-848198/reports/research_notes/primal/proof.md), [hgms30 full-scenario recourse and polishing](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/hgms30/reports/research_notes/primal/proof.md).

## 7. Numerical and Baseline Lessons That Change Decisions

- **Repair is preparation.** Latest `neos-1420546` and `snp-10-004-052` reports count gains of `11.81936` and about `5.62429455118` only after strict baseline repair. Retain both the unmodified public vector and repaired baseline hashes. Small magnitude alone does not decide whether a discrete improvement is material.
- **A large strict-baseline gain need not beat the public record.** `navua` improved an exact-feasible repaired baseline near `2108583.4752` to `166345.7472`, but the official tolerance headline was about `157909.0678`. Report these as different references. Its separate `1e-9` point is also distinct from its exact-zero witness.
- **Exact arithmetic and exact feasibility are different.** Checking rational residuals against a nonzero tolerance establishes tolerance feasibility. `perth`, `supportcase38`, `ns1690781`, and SNP04 retain this qualification. Do not compare their numerical vectors directly with an exact-zero track without saying so.
- **Contradictions trigger audit.** The 20-instance comparison retained a primal `ns1456591` point below the independently exact optimum; its roughly `1e-6` violation explains why it is not a valid win. `vouga` rejected a much lower big-M tolerance point. `sutlej` keeps exact optimum `-5243654/5 = -1048730.8` separate from the lower-looking tolerance vector `-1048730.9379120774`, even where a summary header conflates them.
- **Literal coefficients may reveal unboundedness.** In `supportcase35`, five nonnegative continuous columns cancel in every row but have exact negative slope `-35762787/50000000000000`. A feasible base and checked ray establish unboundedness. The finite example is not optimal, and the solver sentinel `-1e30` is not a finite objective. Preserve the original coefficients rather than rounding away the ray.

Sources: [neos-1420546](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/neos-1420546/README.md), [SNP10-004](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/snp-10-004-052/README.md), [navua two feasibility tracks](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/neos-3754224-navua/README.md), [20-instance comparison and anomalies](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/skills-research/comparisons/SKILL_COMPARISON_REPORT_ZH.md), [vouga rejected tolerance point](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/studies/primal-dual10-r41-50-20260927/instances/neos-4531126-vouga/README.md), [sutlej strict and tolerance distinction](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/studies/primal-dual10-r41-50-20260927/instances/neos-3615091-sutlej/README.md), [supportcase35 ray](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/supportcase35/README.md).

## 8. Keep Comparisons and Deadlines Honest

The historical 20-instance comparison supports local primal-skill wins on `graphdraw-grafo2` and `r4l4` and a general-skill advantage on `oparau`; mixed feasibility grades prevent treating all raw objective rankings as valid wins. The later adaptive campaigns used different baselines and more time than their short original-model controls. Neither set proves universal acceleration or a causal effect of this revision.

Record end-to-end time, including baseline repair, model construction, lifting, serialization, and validation. `supportcase38` needed several minutes for its full check. `dlr2` completed research within its clock but missed evidence delivery; later artifact-only repair did not reset the deadline. In concurrent work, helper threads and validation consume the allocation; thread count times wall time is not measured CPU utilization. Reuse historical methods only where the task permits it, and do not present an authorized reuse campaign as blind.

Sources: [20-instance comparison](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/skills-research/comparisons/SKILL_COMPARISON_REPORT_ZH.md), [dlr2 late-delivery qualification](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/dlr2/README.md), [fresh campaign resource and baseline scope](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/studies/primal-dual10-fresh-r01-r10-20261006/README.md).
