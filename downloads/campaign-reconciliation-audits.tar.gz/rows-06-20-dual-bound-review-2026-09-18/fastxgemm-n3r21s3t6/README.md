# fastxgemm-n3r21s3t6 lower-bound audit — 2026-09-18

**Confirmed: global LB 93 for the stated cyclic ternary R21 formulation.**

Fresh checks:

- `classification.json` / `.log`: all 84 three-point high-row sets checked directly;
  12 symmetry classes; no set permits the three distinct doubled points needed
  for exact core support K=30.
- `original-mapping.json`: new standard-library raw-MPS audit verifies 218,116
  sufficient original rows using integer arithmetic and Decimal objective
  coefficients. This includes all 378 binary sign variables, the cyclic
  U=ABCD/V=ADBC/W=ACDB order, 15,309 product gadgets, their complete 27-input
  ternary truth table, 729 tensor-error pairs, factor absolute-value domination,
  nonzero factor columns, the support floor 84, and the objective coefficients.
- Input SHA-256: `210e76e09285ab346c1ae92155d5fc88efeeaafe96a4b5944b54011fa0103fba`.

The analytic LB90 and LB93 notes were reviewed. Rank-three slices require three
factor incidences; distinct tight slices cannot share a rank column. The lower
support partitions are excluded by this count. In the sole K=30 partition, the
three deficient vectors can supply 12 high-row incidences only via three
one-deficient BCD orbits, each contributing (2,1,1). The freshly replayed
84-case classification excludes their required three distinct doubled points.
Thus exact reconstruction requires 3K>=93. Inexact reconstruction has integral
error at least one, and the original support floor is 84, proving
`sum(ABS_ALT)+9 sum(RESIDUAL)>=93`; the original objective dominates this cut.

The slower alternate bitmask DP was source-reviewed and its archived result
inspected, but was **not rerun**. The fresh 84-case direct classification covers
the final finite case independently. No LP, MIP, or fixed-pattern optimization
was run; an LP optimum after inserting an unproved cut would not itself certify
that cut. The universal MPS mapping and mathematical proof provide that link.
No claim of unrestricted matrix-multiplication rank lower bounds is made.

Reproduce the new original-model check from the repository root:

```sh
python3 docs/rows-06-20-dual-bound-review-2026-09-18/fastxgemm-n3r21s3t6/verify_lb93_mapping.py
```
