#!/usr/bin/env python3
"""Exact raw-MPS check of every semantic implication used by LB93.

Checks a sufficient subset of rows; additional constraints only strengthen the
lower bound. Standard library only, no solver and no incumbent is assumed.
"""
from collections import defaultdict
from decimal import Decimal
import gzip
import hashlib
import itertools
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
MPS = ROOT / 'instances/fastxgemm-n3r21s3t6/input/fastxgemm-n3r21s3t6.mps.gz'
types, matrix, rhs, lower, upper = {}, defaultdict(dict), {}, {}, {}
variables, integer = set(), set()
section = None
integer_mode = False
objective = None
objective_coefficients = {}
rhs_sets, bound_sets, headers = set(), set(), []


def exact_int(token):
    x = Decimal(token.replace('D', 'E'))
    assert x == x.to_integral_value()
    return int(x)


with gzip.open(MPS, 'rt') as f:
    for raw in f:
        t = raw.split()
        if not t or t[0].startswith('*'):
            continue
        if not raw[0].isspace():
            section = t[0]
            assert section in {'NAME','ROWS','COLUMNS','RHS','BOUNDS','ENDATA'}, section
            headers.append(section)
            continue
        if section == 'ROWS':
            assert len(t) == 2 and t[1] not in types
            types[t[1]] = t[0]
            if t[0] == 'N':
                assert objective is None
                objective = t[1]
        elif section == 'COLUMNS':
            if t[1] == "'MARKER'":
                assert t[2] in {"'INTORG'", "'INTEND'"}
                integer_mode = t[2] == "'INTORG'"
                continue
            assert len(t) in (3,5)
            v = t[0]
            variables.add(v)
            if integer_mode:
                integer.add(v)
            for r,a in zip(t[1::2],t[2::2]):
                assert r in types
                if r == objective:
                    objective_coefficients[v] = objective_coefficients.get(v,Decimal(0))+Decimal(a)
                else:
                    matrix[r][v] = matrix[r].get(v,0)+exact_int(a)
        elif section == 'RHS':
            rhs_sets.add(t[0])
            for r,a in zip(t[1::2],t[2::2]):
                assert r not in rhs
                rhs[r] = exact_int(a)
        elif section == 'BOUNDS':
            kind,bs,v = t[:3]
            bound_sets.add(bs)
            assert v in variables
            if kind == 'LO':
                lower[v] = exact_int(t[3])
            elif kind == 'UP':
                upper[v] = exact_int(t[3])
            else:
                raise AssertionError((kind,v))
        else:
            raise AssertionError(section)
assert headers == ['NAME','ROWS','COLUMNS','RHS','BOUNDS','ENDATA']
assert len(rhs_sets) == len(bound_sets) == 1 and rhs.get(objective,0) == 0
assert len(variables) == 18684 and len(types)-1 == 219368
for v in variables:
    lower.setdefault(v,0)
    upper.setdefault(v,None)

sign_names = {f'{sign}_{block}_{i}_{r}' for sign in ('POS','NEG')
              for block,width in [('A',3),('B',6),('C',6),('D',6)]
              for i in range(9) for r in range(width)}
assert integer == sign_names and len(integer) == 378
assert all(lower[v] == 0 and upper[v] == 1 for v in sign_names)
alt = {f'ABS_ALT_{f}_{i}_{r}' for f in 'UVW' for i in range(9) for r in range(21)}
diff = {f'ABS_DIFF_{f}_{i}_{r}' for f in 'UVW' for i in range(9) for r in range(21)}
residual = {f'RESIDUAL_{i}_{j}_{k}' for i,j,k in itertools.product(range(9),repeat=3)}
expected_obj = {**{v:Decimal(1) for v in alt}, **{v:Decimal('0.001') for v in diff},
                **{v:Decimal(1000) for v in residual}}
assert {v:a for v,a in objective_coefficients.items() if a} == expected_obj
assert all(lower[v] >= 0 for v in expected_obj)


def key(sense,target,co):
    return sense,target,tuple(sorted((v,a) for v,a in co.items() if a))


available = {key(types[r],rhs.get(r,0),co) for r,co in matrix.items()}
checked = set()


def require(sense,target,co):
    k = key(sense,target,co)
    assert k in available, k
    checked.add(k)


# Binary sign variables and ABS<=1 forbid simultaneous POS=NEG=1.
# Thus these equalities force ternary factors and ABS=actual absolute value.
for f,blocks in [('U','ABCD'),('V','ADBC'),('W','ACDB')]:
    block_columns = [(b,r) for b in blocks for r in range(3 if b == 'A' else 6)]
    assert len(block_columns) == 21
    for i in range(9):
        for col,(block,r) in enumerate(block_columns):
            v = f'{f}_{i}_{col}'
            av = f'ABS_{v}'
            pos,neg = f'POS_{block}_{i}_{r}',f'NEG_{block}_{i}_{r}'
            assert lower[v] == -1 and upper[v] == 1
            assert lower[av] == 0 and upper[av] == 1
            require('E',0,{v:1,pos:-1,neg:1})
            require('E',0,{av:1,pos:-1,neg:-1})
            for sign in (-1,1):
                require('L',0,{f'ABS_ALT_{v}':-1,v:sign})
    # The archived alternate DP omits empty factor vectors. These original
    # constraints establish that omission is legitimate for this instance.
    for col in range(21):
        require('G',1,{f'ABS_{f}_{i}_{col}':1 for i in range(9)})

# Four sign patterns, each with lower and upper inequalities, and six zero
# factor inequalities occur for all 15,309 ternary product gadgets.
patterns = [(1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1)]
for i,j,k in itertools.product(range(9),repeat=3):
    for r in range(21):
        names = (f'U_{i}_{r}',f'V_{j}_{r}',f'W_{k}_{r}')
        z = f'VALUE_{i}_{j}_{k}_{r}'
        assert lower[z] == -1 and upper[z] == 1
        for signs in patterns:
            co = {z:-1,**dict(zip(names,signs))}
            require('L',2,co)
            require('G',-2,co)
        for v in names:
            for sign in (-1,1):
                require('L',0,{z:sign,f'ABS_{v}':-1})
    target = int(i//3 == k%3 and i%3 == j//3 and j%3 == k//3)
    for sign in (-1,1):
        require('L',sign*target,{f'RESIDUAL_{i}_{j}_{k}':-1,
                               **{f'VALUE_{i}_{j}_{k}_{r}':sign for r in range(21)}})
require('G',84,{v:1 for v in alt})

# The local inequalities force exactly z=u*v*w for all 27 ternary inputs.
for triple in itertools.product((-1,0,1),repeat=3):
    signed = [sum(a*b for a,b in zip(s,triple)) for s in patterns]
    lower_z = max([-1]+[x-2 for x in signed]+[-abs(x) for x in triple])
    upper_z = min([1]+[x+2 for x in signed]+[abs(x) for x in triple])
    assert lower_z == upper_z == triple[0]*triple[1]*triple[2]

result = {
    'instance':'fastxgemm-n3r21s3t6','result':'PASS',
    'arithmetic':'Exact integer MPS constraints/bounds and Decimal objective coefficients',
    'original_mps_sha256':hashlib.sha256(MPS.read_bytes()).hexdigest(),
    'variables':len(variables),'constraints':len(types)-1,
    'sufficient_distinct_original_rows_verified':len(checked),
    'binary_sign_variables':len(sign_names),'verified_product_gadgets':9**3*21,
    'product_truth_table_cases':27,'tensor_residual_coordinates':9**3,
    'cyclic_factor_order_verified':{'U':'ABCD','V':'ADBC','W':'ACDB'},
    'each_factor_column_nonzero_verified':True,
    'sum_abs_alt_ge_84_verified':True,
    'objective_verified':'1000 sum RESIDUAL + sum ABS_ALT + 0.001 sum ABS_DIFF',
    'implication':'Each integer feasible point yields ternary cyclic factors; VALUE equals exact products; RESIDUAL dominates tensor error; ABS_ALT dominates factor support.',
    'remaining_mathematical_input':'LB90/LB93 tight-slice and support counting proof; 84-case classification replay saved separately.',
    'optimization_calls':0,
}
print(json.dumps(result,indent=2))
