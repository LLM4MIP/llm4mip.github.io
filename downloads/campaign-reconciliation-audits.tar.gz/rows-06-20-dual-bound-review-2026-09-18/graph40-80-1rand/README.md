# Row 9: graph40-80-1rand

**Confirmed: original-model lower bound and optimum are -7.**

Fresh full-chain replay checked all 1,050,112 original rows and 283,648 variables; reconstructed the eight-cut CNF (4,696 variables, 32,388 clauses); and checked every one of the 2,050 LRAT RUP lemmas, including the empty clause (63,715 exact propagation steps). The feasible -7 original witness has zero bound, row, and integrality violations. The study and instance copies of the compressed MPS were compared byte-for-byte and match the documented hash.

The reduction is sound: active blocks each define a nonempty cut by XOR; capacities prohibit repeated use of any original oriented edge record. Root fixing uses complement symmetry and strict shore sorting uses permutation symmetry. Eight distinct edge-disjoint nonempty cuts can always be sorted, so the symmetry constraints preserve satisfiability. The 512 oriented records represent 431 undirected pairs; their multiplicities are retained in this encoding.

The supplementary audit explicitly confirms the entire variable-name set, bounds, minimization objective with no offset, one distinct nonempty-cut link per active block, valid endpoints, and canonical edge hash. These tighten small generic completeness omissions in the archived auditor without changing the result.

Evidence: `full-chain-replay.json`, `original-mps-audit.json`, `supplemental-linkage.json`; wrappers `replay.py` and `check_graph_linkage.py`. The wrapper redirects writes that the original full-chain command would otherwise make inside the archived proof directory. Gurobi is used only to read the MPS; no optimization call was made. Python-SAT only constructs/loads the CNF. LRAT propagation itself uses Python's standard library.
