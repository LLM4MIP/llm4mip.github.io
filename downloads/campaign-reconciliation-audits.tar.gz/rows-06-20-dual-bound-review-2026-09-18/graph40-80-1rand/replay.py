"""Run original graph80 full chain while redirecting all outputs to this audit."""
import hashlib,json,sys
from pathlib import Path
OUT=Path(__file__).resolve().parent
REPO=OUT.parents[2]
SOURCE=REPO/'studies/ten-instance-2026-09-06/hour-pass'
sys.path.insert(0,str(SOURCE))
import common
import graph_mps_audit as audit
from graph_sat_proof import encode,read_edges
from check_lrat_rup import check
from pysat.formula import CNF
captured={}
def redirect(path,result):
    captured[Path(path).name]=result
    common.dump(OUT/Path(path).name,result)
audit.dump=redirect
audit.main()
mps,sol=common.paths('graph40-80-1rand')
assert hashlib.sha256(mps.read_bytes()).hexdigest()=='4a1243b6d5b81367c9d6ae6512be8dc79974a1115e2aa40d5e5393928a67ee33'
assert mps.read_bytes()==(REPO/'instances/graph40-80-1rand/input/graph40-80-1rand.mps.gz').read_bytes()
cnf,_,_=encode(8,read_edges(mps))
disk=CNF(from_file=str(SOURCE/'graph-proof/eight-cuts.cnf'))
assert cnf.clauses==disk.clauses
proof=check(SOURCE/'graph-proof/eight-cuts.cnf',SOURCE/'graph-proof/eight-cuts.lrat')
feasible=common.verify(mps,sol,0)
assert feasible['valid_at_tolerance'] and feasible['computed_objective']==-7
result={'certified_optimum':-7,'original_audit':captured['original-mps-audit.json'],
'cnf_rebuilt_same_clauses':True,'variables':cnf.nv,'clauses':len(cnf.clauses),
'lrat_replay':proof,'original_primal':feasible,'optimization_solver_calls':0,
'sha256':{str(p.relative_to(REPO)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [mps,sol,SOURCE/'graph-proof/eight-cuts.cnf',SOURCE/'graph-proof/eight-cuts.lrat']}}
common.dump(OUT/'full-chain-replay.json',result)
print(json.dumps(result,indent=2))
