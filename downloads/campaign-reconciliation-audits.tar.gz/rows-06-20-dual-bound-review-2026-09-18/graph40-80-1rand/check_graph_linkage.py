"""Supplement archived graph audits with explicit full variable-set/linkage checks."""
from pathlib import Path
import gurobipy as gp
import hashlib,json
OUT=Path(__file__).resolve().parent
REPO=OUT.parents[2]
for name,blocks,records in [('graph40-80-1rand',512,512),('graph40-40-1rand',300,300)]:
 mps=REPO/f'instances/{name}/input/{name}.mps.gz'
 m=gp.read(str(mps));vs=m.getVars();cs=m.getConstrs();A=m.getA().tocsr()
 edges=set()
 for v in vs:
  if v.VarName.startswith('slack#'):edges.add(tuple(map(int,v.VarName.split('#')[1:])))
 assert len(edges)==records and all(0<=a<40 and 0<=b<40 and a!=b for a,b in edges)
 expected={f'x#{c}' for c in range(blocks)}|{f'u#{c}#{v}' for c in range(blocks) for v in range(40)}|{f'y#{c}#{a}#{b}' for c in range(blocks) for a,b in edges}|{f'slack#{a}#{b}' for a,b in edges}
 assert {v.VarName for v in vs}==expected and len(vs)==len(expected)
 assert m.ModelSense==1 and m.ObjCon==0
 assert all(v.LB==0 and v.UB==1 and v.VType in 'BI' and v.Obj==(-1 if v.VarName.startswith('x#') else 0) for v in vs)
 active=[]
 for i,row in enumerate(cs):
  lo,hi=A.indptr[i:i+2]
  xs=[vs[j].VarName for j in A.indices[lo:hi] if vs[j].VarName.startswith('x#')]
  if xs:
   assert len(xs)==1;active+=xs
 assert len(active)==blocks and set(active)=={f'x#{c}' for c in range(blocks)}
 canonical=sorted({tuple(sorted(e)) for e in edges})
 h=hashlib.sha256(''.join(f'{a}\t{b}\n' for a,b in canonical).encode()).hexdigest()
 if blocks==300:
  tsv=REPO/'instances/graph40-40-1rand/artifacts/graph40-40-1rand_edges.tsv'
  actual=[tuple(map(int,line.split())) for line in tsv.read_text().splitlines()[1:]]
  assert actual==canonical
  assert h=='bedbdab73007779c9212578fc4e3ad0091a8c21f1226f0afffcd1d733eefdabb'
 result={'verified':True,'all_variable_names_bounds_objective_checked':len(vs),'all_active_block_links_distinct':blocks,'oriented_edge_records':records,'canonical_undirected_edges':len(canonical),'canonical_edges_sha256':h,'mps_sha256':hashlib.sha256(mps.read_bytes()).hexdigest(),'solver_calls':0}
 p=OUT.parent/name/'supplemental-linkage.json';p.write_text(json.dumps(result,indent=2)+'\n')
 print(name,result)
