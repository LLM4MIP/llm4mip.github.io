# genus-sym-g31-8 lower-bound audit — 2026-09-18

**Confirmed: original-MPS global LB -23, with fresh exhaustive-computation
support (evidence X). Native orientable genus is exactly 3.**

The literal exact-decimal original-MPS optimum equality is not established by
the archived -23 witness: it violates 7 original rows, each by 1e-15.

Fresh checks:

- `original-mps-reduction-audit.json`: all 32,073 rows and 3,484 variables
  checked against the rotation/face-slot necessity patterns, including odd
  parity. Gurobi was used only for reading; no optimization was run.
- `fresh-exhaustive.json`: serial `multi_genus w` reports genus 3 and produces a
  directly checked 23-face rotation. A separate bounded `multi_genus l2 F`
  invocation excludes genus<=2. Both runs finished normally under 20-second
  limits. Recovered multicode matches the archived input.
- The newly fetched source from
  [SanderGi/Genus](https://github.com/SanderGi/Genus/tree/main/MultiGenus) has
  SHA-256 `a3758cb7fc2d02ca4b3b81a519a7d3957c0b7ce8708a4af2c6fb36cd2d4538de`,
  exactly matching the archived source fingerprint. It was compiled using
  `clang -O3 -DLONG` in `/tmp`. This program emits no portable lower-bound proof
  trace: the evidence remains exhaustive computation, not a replayable formal
  certificate.
- `exact-primal.log` and `exact-primal-details.json`: the archived objective -23
  point is exactly integral and within all bounds, but has 7 active
  three-dart faces. For each, the original decimal row evaluates to
  `1 - 3*0.333333333333333 = 1e-15 > 0`. The maximum violation is 1e-15.

The graph has 31 vertices and 58 edges, so genus>=3 implies native F<=23. The
verified original-model implication is active slots<=native F, which gives
original objective>=-23 even with the decimal coefficients as written.
The reverse direction is not justified: a triangular native face cannot fill
one active original slot at zero tolerance. The README's unqualified exact
original-MPS optimum claim therefore needs this numerical caveat. These checks
do not prove that a different strict -23 witness is impossible; no such search
was launched. The two formulations share the graph and exhaustive result.

The shared adapted mapping checker is
`../genus-g31-8/verify_g31_mapping.py`; its only model-specific change from the
archived larger-genus reduction audit is the odd parity RHS.
