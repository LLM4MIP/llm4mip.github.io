#!/usr/bin/env python3
"""Validate the geometric area bound and even-lattice map from every MPS row."""
import hashlib
import importlib.util
import itertools
import math
import sys
from decimal import Decimal
from pathlib import Path

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'instances/liu'


def main():
    path=BASE/'input/liu.mps.gz'
    assert hashlib.sha256(path.read_bytes()).hexdigest() == '50599cbd1c0ea27d88e97fb3a53f1aae3d240a095c8c7baaa1f1408290c8f85f'
    spec=importlib.util.spec_from_file_location('reader',BASE/'scripts/analyze_structure.py')
    reader=importlib.util.module_from_spec(spec); spec.loader.exec_module(reader)
    m=reader.parse_mps(path); s=reader.recover(m)
    rows=m['rows']; rhs=m['rhs']; integers=m['integer_variables']
    continuous=set(m['variables'])-integers
    assert len(continuous)==67 and len(integers)==1089
    assert rows[m['objective_row']]=={s['side']:Decimal(1)}
    assert rhs.get(m['objective_row'],0)==0
    assert all(m['lower'][v]==0 and m['upper'][v]==1 for v in integers)
    assert all(m['lower'][v]==0 and m['upper'][v] is None for v in continuous)
    for r,kind in m['row_types'].items():
        if kind=='N': continue
        assert kind in ('L','G')
        terms=rows[r]
        assert sorted(a for v,a in terms.items() if v in continuous)==[-1,1]
        assert all(a%2==0 for v,a in terms.items() if v in integers)
        assert rhs.get(r,0)%2==0
    modules=s['modules']; assert len(modules)==33
    assert all(a>0 and a%2==0 for item in modules for a in (item['width'],item['height']))
    # Each boundary row is exactly x_i + width_i(rotation) <= side (likewise y).
    boundary=[r for r in m['row_order'] if rows[r].get(s['side'])==-1]
    for item,pair in zip(modules,itertools.batched(boundary,2)):
        for r,axis,dim,delta in zip(pair,('x','y'),('width','height'),('width_delta','height_delta')):
            expected={item[axis]:Decimal(1),s['side']:Decimal(-1)}
            if item['rotation'] and item[delta]: expected[item['rotation']]=item[delta]
            assert m['row_types'][r]=='L' and rows[r]==expected and rhs[r]==-item[dim]
    # For each pair and every two-bit code, exactly one row is the unrelaxed
    # separation inequality. Enumerate both orientations too, rather than
    # trusting a coefficient pattern extracted from only boundary rows.
    pair_rows=s['nonoverlap_rows']; checked=0
    for (i,j),rp in zip(itertools.combinations(range(33),2),itertools.batched(pair_rows,4)):
        a,b=modules[i],modules[j]
        codes=set().union(*(set(rows[r])&s['pair_binary_variables'] for r in rp))
        assert len(codes)==2
        assert set().union(*(set(rows[r]) for r in rp)) <= {
            a['x'],a['y'],b['x'],b['y'],a['rotation'],b['rotation']} | codes
        for bits in itertools.product((0,1),repeat=2):
            for rotations in itertools.product((0,1),repeat=2):
                vals=dict(zip(sorted(codes),bits))
                for item,v in zip((a,b),rotations):
                    if item['rotation']: vals[item['rotation']]=v
                wi=a['width']+a['width_delta']*rotations[0]
                hi=a['height']+a['height_delta']*rotations[0]
                wj=b['width']+b['width_delta']*rotations[1]
                hj=b['height']+b['height_delta']*rotations[1]
                wanted=[({a['x']:1,b['x']:-1},-wi),({a['x']:-1,b['x']:1},-wj),
                        ({a['y']:1,b['y']:-1},-hi),({a['y']:-1,b['y']:1},-hj)]
                active=[]
                for r in rp:
                    sign=1 if m['row_types'][r]=='L' else -1
                    coeff={v:sign*c for v,c in rows[r].items() if v in continuous}
                    target=sign*(rhs.get(r,0)-sum(c*vals[v] for v,c in rows[r].items() if v in integers))
                    if (coeff,target) in wanted: active.append((coeff,target))
                assert len(active)==1,(i,j,bits,rotations,active)
                checked+=1
    assert checked==528*16
    area=sum(int(a['width']*a['height']) for a in modules)
    assert area==1149192 and 1072**2 < area <= 1073**2
    # Flooring every continuous variable divided by 2 preserves all normalized
    # difference inequalities with integral RHS. Thus any solution below 1074
    # would yield an even-side solution at most 1072, contradicting the area.
    print(f'Original-MPS geometry PASSED: {checked} pair-code/orientation cases; 66 boundary rows')
    print('All 2178 rows are differences of two continuous variables, with even binary coefficients and RHS')
    print('All continuous bounds are [0,infinity); scaling by 2 and componentwise flooring preserves feasibility')
    print(f'Area = {area}; 1072^2 = {1072**2}; 1073^2 = {1073**2}; certified lower bound = 1074')
    print('The optimum can be chosen even; larger non-even feasible objective values remain possible')


if __name__=='__main__': main()
