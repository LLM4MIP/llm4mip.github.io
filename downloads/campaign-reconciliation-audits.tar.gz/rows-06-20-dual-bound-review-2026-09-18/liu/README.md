# Row 12 audit: liu

**Confirmed: rigorous global lower bound 1,074; exact feasible upper bound 1,082. Global optimality remains open.** No optimization solver or neighborhood search was run.

The original structural analyzer and original-MPS solution checker were rerun. The 1,082 witness satisfies all 2,178 rows, bounds, and integrality requirements at tolerance zero; all printed violation counts and maxima are zero.

The original structural analyzer recovers dimensions and checks a witness, but it does not fully mechanically verify the lower-bound reduction. This audit adds [verify_area_lattice.py](verify_area_lattice.py). It checks all 66 rectangle boundary rows and, for each of 528 rectangle pairs, every pair-code and rotation combination: 8,448 combinations total. Each pair code activates a genuine separating inequality, so any original feasible point is a packing of the 33 recovered rectangles in the objective-sized square. Their total area is exactly 1,149,192.

The same supplement checks that all 2,178 original constraints have precisely one `+1` and one `-1` continuous coefficient and even integer coefficients/RHS. All continuous variables have bounds `[0,infinity)` and every discrete variable is binary. Therefore, fixing the binaries, scaling the continuous variables by two gives difference inequalities with integer right sides. Componentwise flooring preserves every such inequality and every bound. A feasible side strictly below 1,074 would consequently yield an even feasible side at most 1,072. But `1072^2 = 1149184 < 1149192`, an area contradiction. This proves the claimed lower bound directly without numerical square-root rounding or an extreme-point assumption.

**Documentation precision:** the instance README says there are no possible exact objectives strictly between adjacent even targets. That sentence is too strong for feasible values: from the feasible 1,082 packing, raising only the side variable gives, for example, a feasible objective 1,083. The correct statement is that an optimal side can be chosen even, and any strict improvement over 1,082 can be compacted to side at most 1,080. This distinction does not affect the lower bound or the improvement-target argument.

**Hash normalization:** the README's 1,082-solution SHA-256 `06461cc352fb5267a9b01dcd1fd281dfa56324fa890dca4d2c0993aee2503af3` matches the CRLF text recovered from the archived `.sol.gz`. The working-tree plain `.sol` uses LF and has SHA-256 `e90882a2bcc6632397180e9d0d5055aa346e764748a8844ef8fc42bf8961443e`. Normalizing CRLF to LF makes the files byte-for-byte identical. The numerical solution is unchanged. Other checked provenance hashes match. See [normalization evidence](solution-normalization.json).

Evidence: [structural replay](structure-replay.log), [area/lattice/geometry replay](supplement-replay.log), [original primal replay](primal-replay.log), [file hashes](provenance.json).

From the repository root (the supplement uses `itertools.batched`, available in Python 3.12+; this audit used Python 3.14):

```sh
python -B docs/rows-06-20-dual-bound-review-2026-09-18/liu/verify_area_lattice.py
python -B common/exact_mps_solution_check.py instances/liu/input/liu.mps.gz instances/liu/solutions/cpsat-sequence-pair-1082.sol --tolerance 0
```

The restricted-neighborhood failures and historical time-limited solver runs are not used as global lower-bound evidence. Original files were preserved.
