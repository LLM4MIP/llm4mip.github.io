# Row 10: graph40-40-1rand

**Confirmed: original-model lower bound and optimum are -9.**

Fresh archived full-chain replay checks 360,900 rows, 102,600 variables, and 1,260,900 nonzeros; reconstructs the ten-cut CNF byte-for-byte (3,510 variables, 25,519 clauses); checks the known nine-cut fixture; and verifies all 5,752 LRAT lemmas through the empty clause (106,117 exact propagation steps). The original -9 witness has exactly zero bound, row, and integrality violations.

The reduction from original XOR/capacity/nonempty rows to cut packing is valid. Collapsing the 300 oriented edge records to 275 unique undirected edges is exact because reversed duplicates impose identical crossing/capacity restrictions. Complement fixing and strict lexicographic shore ordering preserve every possible collection of edge-disjoint nonempty cuts.

The archived full-chain checker compares metadata's edge hash with the MPS audit but does not itself hash the edge TSV used by the encoder. A supplementary audit directly compares that TSV to the unique edges recovered from the MPS. It also verifies full variable sets, objective/bounds, and distinct active-block link coverage. All pass; canonical SHA-256 is `bedbdab73007779c9212578fc4e3ad0091a8c21f1226f0afffcd1d733eefdabb`.

Evidence: `full-chain-replay.json`, `supplemental-linkage.json`; the supplemental script is in the adjacent graph40-80-1rand audit directory. Full replay used the original `instances/graph40-40-1rand/scripts/verify_graph40_40_optimality.py` with output redirected here. No optimization solver calls were made; Gurobi only reads the matrix. LRAT rechecking establishes UNSAT directly, so rerunning historical DRAT-to-LRAT conversion is unnecessary.
