# Independent code and proof cross-review

A second audit agent read `reproduce.py`, the audit README, and the original
`instances/mining/experiments/check_lagrangian_from_mps.py`. This was a bounded
logical review; the already completed numeric replay was not repeated.

No remaining gap was found in the universal lower-bound argument for the
archived model after the supplemental checks are included.

- The checked binary bounds and vertical `x_t - x_(t+1) <= 0` rows imply exactly
  the 21 suffix states. The wrapper checks the required zero right sides.
- On those suffix states the horizontal gadget is equivalent to
  `threshold(u) <= threshold(v)`: when block v first turns on, block u must
  already be on. State 20 (never) is included. The wrapper checks all 441 state
  pairs, while the original checker verifies the actual coefficients in every
  gadget.
- The graph checks exclude duplicate predecessors/successors, self loops,
  cycles, and missing blocks. Therefore the retained domain factors into the
  967 directed paths, including isolated nodes.
- In reverse path order, `DP(node,s) = min_{t>=s}(adjusted(node,t) +
  DP(successor,t))` includes every feasible nondecreasing state sequence. The
  terminal value zero and initial lower state zero are correct.
- For minimization with capacity rows `Ax <= b` and nonnegative multipliers,
  `c(x) + lambda(Ax-b) <= c(x)` at every original feasible point. Minimizing
  over the retained domain is consequently a universal lower bound. No
  positivity assumption on resource weights is needed for this step.
- The mixed-row reconstruction accounts for every capacity contribution in
  every suffix state. The other 38 mixed rows have nonpositive state
  contributions and zero right sides, establishing their claimed redundancy.
- The extra continuous variable is fixed to one and its objective contribution
  is retained. The wrapper rules out a separate objective offset, unexpected
  objective sense, extra bound records, or unrecognized RHS vectors.
- The original module resets Decimal precision to 80 but does not disable the
  wrapper's `Inexact` and `Rounded` traps. A completed trap-enabled replay with
  clear flags therefore certifies that none of the Decimal additions,
  multiplications, or comparisons relied on rounded arithmetic.

The witness equality provides a useful independent attainment check for the
Lagrangian inner minimum. It is not an original-feasibility or global-optimality
certificate, and the audit README correctly keeps those distinctions.
