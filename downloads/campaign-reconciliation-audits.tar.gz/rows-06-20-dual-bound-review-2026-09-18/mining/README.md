# Row 11: mining

**Confirmed exact global lower bound:**
`-835361895.5863052144840282387439`. The instance remains unresolved.

The unmodified original-MPS Lagrangian checker was run through
[reproduce.py](reproduce.py), using the archived MPS and final multiplier
certificate only. All 21 checks passed. The replay independently reconstructs
17,446 binary suffix blocks, 16,479 precedence edges, and 967 disjoint paths.
It recomputes the minimum over all 21 threshold states per block; the certificate
witness attains that minimum and its two resource-usage vectors match.
See [original-mps-replay.json](original-mps-replay.json) and [replay.log](replay.log).

The wrapper adds original-file checks that are not explicit in the old checker:
the default minimization sense, sole objective row, zero objective offset,
**zero right-hand sides on all retained vertical and horizontal implication
rows**, and one ordinary upper-bound record per variable. It also checks all
441 pairs of threshold states against the horizontal-gadget inequalities.
All these assumptions hold in the actual archived model.

The original code uses Decimal arithmetic at precision 80. The fresh replay
enables traps for both `Inexact` and `Rounded`: neither occurred. Thus the
recomputed bound is exact for the finite decimal MPS coefficients and stored
nonnegative multipliers, rather than just an 80-digit numerical approximation.
See [supplemental-replay.json](supplemental-replay.json).

## Why the bound is global

Each 20-variable block is a binary suffix. On those suffix states the exact
horizontal gadget is equivalent to `threshold[u] <= threshold[v]`. The 38
mixed difference rows are redundant, as their contribution from every state
of every block is nonpositive with zero RHS. The remaining 40 capacity rows
have the reconstructed resource usage, and are the only rows relaxed.

For the original minimization problem and `lambda >= 0`, every feasible point
satisfies `c(x) + lambda*(A*x-b) <= c(x)`. Minimizing this expression over the
retained suffix-path constraints therefore gives a global lower bound.
The backward path DP enumerates every allowed nondecreasing state sequence:
at a node with lower allowed state `s`, it minimizes the current adjusted cost
plus the successor DP over all states `t >= s`. Paths are independent after
the capacity relaxation. This justifies the exact DP minimum used by the checker.

The original-MPS public witness was also checked with tolerance zero across all
661,133 rows, bounds, and integrality. Its objective is exactly
`-833589149.2736538586882046`, with zero violations. See
[primal-replay.log](primal-replay.log). It does not attain the lower bound and
does not establish optimality.

## Comparison and reproduction

The historical COPT PDF displays `-933493233`. Exact subtraction from those
displayed inputs gives `98131337.4136947855159717612561`. The root README prints
`98131337.41369478551597176126`, differing by only `3.9e-21` because of rounding.
The README explicitly calls its differences approximate; this is harmless
display rounding, not a lower-bound error.

Run from the repository root with Python 3.10 or newer:

```sh
python docs/rows-06-20-dual-bound-review-2026-09-18/mining/reproduce.py
python common/exact_mps_solution_check.py instances/mining/input/mining.mps.gz instances/mining/solutions/official-best.sol.gz --tolerance 0
```

No optimization solver, multiplier search, or new feasible-solution search was
run. The MPS is present, with SHA-256
`b460c0f02b2bd0262d2a53c677705cdceffca77db61623730c5260e703b76a57`.
The source and archived evidence were not modified.
