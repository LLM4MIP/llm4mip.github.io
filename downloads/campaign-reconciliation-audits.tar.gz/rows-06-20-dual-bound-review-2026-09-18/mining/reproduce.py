#!/usr/bin/env python3
"""Supplement and replay the original mining proof, trapping decimal rounding.

No original source is changed. Additional parsing checks cover objective sense,
objective offset, zero RHS on all retained implication rows, and actual bound
records. The original verifier reconstructs the full reduction and path DP.
"""
import gzip
import hashlib
import importlib.util
import json
import sys
from collections import Counter
from decimal import Decimal, Inexact, Rounded, getcontext
from pathlib import Path

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
BASE = ROOT / 'instances/mining'


def supplemental_checks(mps):
    section = ''
    rhs = {}
    bound_columns = set()
    rhs_vectors, bound_vectors = set(), set()
    objectives, headers = [], []
    counts = Counter()
    with gzip.open(mps, 'rt') as handle:
        for raw in handle:
            p = raw.split()
            if not p or raw.startswith('*'):
                continue
            if not raw[0].isspace():
                section = p[0]
                assert section in {'NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA'}, p
                headers.append(section)
                continue
            if section == 'ROWS':
                if p[0] == 'N':
                    objectives.append(p[1])
            elif section == 'RHS':
                assert len(p) % 2 == 1
                rhs_vectors.add(p[0])
                for row, value in zip(p[1::2],p[2::2]):
                    assert row not in rhs
                    rhs[row] = Decimal(value)
            elif section == 'RANGES':
                raise AssertionError('Unexpected range data')
            elif section == 'BOUNDS':
                assert len(p) == 4 and p[0] == 'UP'
                bound_vectors.add(p[1])
                assert p[2] not in bound_columns
                bound_columns.add(p[2])
                i = int(p[2][1:])
                assert p[2] == 'x'+str(i) and 1 <= i <= 348921
                assert Decimal(p[3]) == (2 if i == 348921 else 1)
                counts['upper_bounds'] += 1
    assert objectives == ['obj'] and rhs.get('obj',0) == 0
    assert len(rhs_vectors) == len(bound_vectors) == 1
    assert counts['upper_bounds'] == 348921
    # No OBJSENSE/OBJNAME: standard MPS minimization and sole N row.
    assert headers == ['NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA']
    capacities = set(range(331494,331514)) | set(range(331533,331553))
    allowed = capacities | {661133}
    assert all(row.startswith('c') and int(row[1:]) in allowed for row in rhs)
    assert rhs['c661133'] == 1
    assert all(rhs.get('c'+str(i),Decimal(0)) == 0
               for i in range(1,661133) if i not in capacities)
    truth_count = 0
    for u in range(21):
        for v in range(21):
            xu, xv = [int(t>=u) for t in range(20)], [int(t>=v) for t in range(20)]
            feasible = xv[0] <= xu[0] and all(xv[t] <= xv[t-1]+xu[t] for t in range(1,20))
            assert feasible == (u<=v)
            truth_count += 1
    result = {'default_minimization_and_single_objective':True,
              'zero_objective_offset':True,
              'all_vertical_horizontal_and_difference_RHS_zero':True,
              'single_rhs_and_bound_vectors':True,
              'only_one_UP_record_per_variable':True,
              'horizontal_gadget_truth_table_cases':truth_count,
              'source_sha256':hashlib.sha256(mps.read_bytes()).hexdigest()}
    assert result['source_sha256'] == 'b460c0f02b2bd0262d2a53c677705cdceffca77db61623730c5260e703b76a57'
    return result


def main():
    mps = BASE / 'input/mining.mps.gz'
    cert = BASE / 'experiments/lagrangian-refine2-6000.json'
    result = supplemental_checks(mps)
    context = getcontext()
    context.prec = 80
    context.traps[Inexact] = True
    context.traps[Rounded] = True
    context.clear_flags()
    script = BASE / 'experiments/check_lagrangian_from_mps.py'
    spec = importlib.util.spec_from_file_location('mining_original_verifier',script)
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    sys.argv = [str(script),str(mps),str(cert),str(OUT/'original-mps-replay.json')]
    assert verifier.main() == 0
    assert not context.flags[Inexact] and not context.flags[Rounded]
    report = json.loads((OUT/'original-mps-replay.json').read_text())
    assert report['all_checks_passed']
    assert report['recomputed_exact_decimal_lower_bound'] == '-835361895.5863052144840282387439'
    result.update({'all_21_original_checks_passed':True,
                   'decimal_precision':80,'inexact_and_rounded_traps_enabled':True,
                   'no_decimal_rounding_occurred':True,
                   'exact_lower_bound':report['recomputed_exact_decimal_lower_bound']})
    (OUT/'supplemental-replay.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__ == '__main__':
    main()
