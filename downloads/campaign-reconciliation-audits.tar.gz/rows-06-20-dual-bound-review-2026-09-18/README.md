# Rows 6–20: independent dual-bound review

Audit date: 2026-09-18 UTC (2026-09-17 America/Los_Angeles).
Scope: rows 6 through 20, inclusive, in the root README's **Dual-bound
improvements over COPT 10h** table. This continues the
[first-five audit](../first-five-dual-bound-review-2026-09-18/README.md).

**All fifteen claimed lower-bound values are supported by fresh checks.**
All COPT baseline values match the archived source PDF, and all displayed
differences are correct at their stated precision. This does not mean all
fifteen instances are solved, or that all fifteen have portable proof traces.

Two qualifications matter most. The original `sangro` summary skips necessary
active-layer cases; this audit reruns all three relevant exclusions. The two
`g31` lower bounds are confirmed, but their saved objective −23 witnesses fail
literal exact-decimal MPS feasibility by `1e-15`. Their native graph genus is
confirmed; exact MPS optimality is not established by those witnesses.

| Row | Instance / detailed audit | COPT displayed LB | Rechecked global LB | Displayed improvement | Fresh evidence |
|---:|---|---:|---:|---:|---|
| 6 | [fhnw-binschedule1](fhnw-binschedule1/README.md) | 52153 | 55158 | 3005 | exact MPS mapping, matching/cover, exact witness |
| 7 | [neos-3009394-lami](neos-3009394-lami/README.md) | 1.92857143 | 5.5 | 3.57142857 | exact Hall bound, domains/envelopes, exact witness |
| 8 | [neos-2629914-sudost](neos-2629914-sudost/README.md) | 42387.0653 | 48180 | 5792.9347 | exact reduction and full finite enumeration |
| 9 | [graph40-80-1rand](graph40-80-1rand/README.md) | -495.450445 | -7 | 488.450445 | original mapping, rebuilt CNF, full LRAT replay |
| 10 | [graph40-40-1rand](graph40-40-1rand/README.md) | -68.9559386 | -9 | 59.9559386 | original mapping, rebuilt CNF, full LRAT replay |
| 11 | [mining](mining/README.md) | -933493233 | -835361895.5863052144840282387439 | 98131337.41369478551597176126 | exact original-MPS Lagrangian/path DP |
| 12 | [liu](liu/README.md) | 560 | 1074 | 514 | all-row geometry, area and even-optimum reduction |
| 13 | [fastxgemm-n3r21s3t6](fastxgemm-n3r21s3t6/README.md) | 84 | 93 | 9 | analytic support proof, all 84 cases, exact MPS mapping |
| 14 | [genus-g61-25](genus-g61-25/README.md) | -58 | -42 | 16 | catalogue, complete 3,803-node tree, 1,902 exact leaves |
| 15 | [genus-sym-g62-2](genus-sym-g62-2/README.md) | -54 | -40 | 14 | complete short-walk catalogue and rational dual |
| 16 | [bppc6-06](bppc6-06/README.md) | 201 | 208 | 7 | exact reduction, hash-matched CNF, fresh SAT UNSAT |
| 17 | [neos-4360552-sangro](neos-4360552-sangro/README.md) | -12.0644768 | -8 | 4.0644768 | exact MPS reduction; fresh A=9,10,11 exclusions |
| 18 | [ns1631475](ns1631475/README.md) | 1659 | 11100 | 9441 | original mapping and complete cyclic-order enumeration |
| 19 | [genus-sym-g31-8](genus-sym-g31-8/README.md) | -27 | -23 | 4 | original mapping and fresh exhaustive native genus run |
| 20 | [genus-g31-8](genus-g31-8/README.md) | -27 | -23 | 4 | original mapping and fresh exhaustive native genus run |

## Findings that qualify the original documentation

### 1. Sangro: exactly nine layers does not cover every improvement

The short instance README argues that infeasibility at exactly nine active
layers proves at most eight. That implication is not supplied by the model:
the compressed model fixes the final endpoints, so simply taking a nine-layer
prefix does not preserve feasibility. The full historical report contains
additional cases, but the short reproduction command does not replay them.

The exact original-row audit verifies the total-overlap identity
`overlap = 12*A - 72` and at most `6*(A-1)` overlap. Hence `A <= 11`. This audit
reran the repeated-partition relaxations for **A=9, 10, and 11**; all returned
`INFEASIBLE`. Together with the exact original-MPS witness at −8, this confirms
the optimum at the repository's stated exhaustive-computation evidence level.
These CP-SAT runs do not emit a standalone formal proof trace.

### 2. Both g31 models: lower bound passes; exact original-MPS witness does not

The upstream `multi_genus` source was obtained and its SHA-256 matches the
archived source fingerprint. Fresh runs report genus 3, exclude genus at most
2, and produce directly checked 23-face rotations. Both original-MPS-to-rotation
implications were checked. Therefore both global lower bounds **−23** are
supported, with the same exhaustive-computation limitation recorded by code `X`.

However, the MPS uses the decimal `0.333333333333333` in its nonempty-face
constraints. A three-dart face incurs an exact residual of `1e-15` there.
Exact checks of the saved objective −23 solutions find:

| Original model | Violated rows | Maximum exact violation |
|---|---:|---:|
| genus-sym-g31-8 | 7 | 1e-15 |
| genus-g31-8 | 6 | 1e-15 |

Bounds and integrality pass. These are tolerance-feasible witnesses, not
zero-tolerance rational witnesses for the literal decimal MPS. The current
evidence establishes the native graph optimum and the original-MPS lower
bound, but **does not establish exact-decimal original-MPS OPT = −23**.
It also does not establish that the exact MPS optimum is different; that would
require a further argument or an exact feasible witness. The `g61`/`g62` READMEs
already disclose the corresponding rounded-third qualification for their
upper-bound witnesses.

### 3. BPPC: fresh exclusion succeeds; old large trace remains unreplayed

The original MPS mapping, exact 208 witness, and all `2^20` subset checks pass.
The target-207 CNF was regenerated with the published SHA-256
`85cd2537ef615b878f0a57d1cb5198bbc6cd3835261306c6dfcc7086d25ecc6b`.
A new CaDiCaL195 run on this CNF returned **UNSAT in 175.71 seconds**, confirming
the lower bound by a fresh Boolean solver computation.

The historical multi-gigabyte DRAT/LRAT files are not in this checkout. Their
logs and hash manifest were inspected, but the old LRAT trace was **not**
replayed, and the new run did **not** generate a proof trace. This is fresh
computational confirmation, not a claim to have independently replayed the
missing formal certificate. The distinction is consistent with the row's `X`
evidence label.

### 4. Several certificate checkers needed additional original-model guards

The supplements in this audit check assumptions that hold in the actual input
but were not fully asserted by the old entry points:

- **Binschedule1:** connect the detached interval JSON to every required
  original MPS interval, cost, capacity, and path edge with exact fractions.
- **Lami:** check binary selectors, integer coordinates, objective, and the
  directions of the final envelope inequalities.
- **Sudost:** verify that every numeric token cast to integer by its reader
  really is integral; then replay all 14,078,016 assignments.
- **Mining:** verify the objective convention, zero RHS on all retained
  implication rows, and actual bound records. Decimal `Inexact` and `Rounded`
  traps confirm that no rounding occurred in the complete 21-check replay.
- **Liu:** check all 2,178 rows and all 8,448 pair-code/orientation cases,
  establishing both packing geometry and the even-optimum reduction.
- **Fastxgemm:** verify the raw MPS's cyclic factors, signs, products, residuals,
  objective, and support floor, connecting the combinatorial proof to the model.
- **Sangro and NS1631475:** explicitly audit the original coefficient templates
  and the missing objective/domain/row-sense assumptions used by the reductions.

The two graph cut-packing instances have full fresh CNF/LRAT proof chains.
The g61 catalogue, complete exclusion tree, branch coverage, and all exact
leaves were replayed. The g62 catalogue and every rational-dual column were
rechecked. For fastxgemm, the full direct 84-case classification was rerun;
the redundant slower symmetry-DP was reviewed rather than rerun.

### 5. Liu and display precision

Liu's proof establishes that an optimum can be chosen even. It does not say
that every feasible objective is even: increasing the square side of a
feasible packing preserves feasibility. The correct even-optimum statement
suffices for the lower bound **1,074** and for reducing any improvement over
1,082 to a target at most 1,080.

Liu's saved 1,082-solution SHA in its README matches the archived CRLF text;
the checked-out plain solution has LF line endings. Normalization makes their
contents identical, and exact feasibility passes.

For mining, exact subtraction from the displayed COPT input gives
`98131337.4136947855159717612561`. The README's displayed difference rounds this
by `3.9e-21`. Its stated approximate-comparison convention already covers this;
there is no numerical bound error.

## Source, reproducibility, and scope

The [frozen COPT PDF](../dual-bound-audit-2026-09-14/sources/frozen-copt-table.pdf)
has SHA-256 `d34798161c0535ba22595ffc1cc8c1dfb40a86d5b21963a542297330db65589f`.
Fresh extraction agrees with all fifteen README baselines and the archived
94-instance comparison JSON. Every selected PDF row reports 36,000 seconds;
the footer records 8 threads and `RelGap=0`. See
[comparison-recheck.json](comparison-recheck.json) and
[verify_comparison.py](verify_comparison.py). These are historical scalar-bound
comparisons, not new COPT runs or controlled equal-budget experiments.

Each instance directory linked above contains check descriptions, fresh logs,
scope qualifications, and any supplemental script. Reproduction commands and
original entry points are recorded in the individual reports. The common primal checker
prints violations without failing its process, so its printed counts were
inspected. Assertions must remain enabled. Python requirements vary by script;
the new Liu supplement requires Python 3.12+.

Exact integer/Boolean solver searches were run where required (Sangro, BPPC,
and the g31 exhaustive genus programs). Gurobi was used only for matrix reading
in selected original verifiers, not for optimization. Existing environment
packages were not changed; additional replay dependencies were installed in an
isolated temporary environment. No original README, instance input, certificate,
solution, proof script, or archived evidence was edited. New audit outputs are
confined to this directory; temporary runtimes and regenerated large intermediates
are outside the repository. This audit does not establish current official
MIPLIB acceptance or novelty.
