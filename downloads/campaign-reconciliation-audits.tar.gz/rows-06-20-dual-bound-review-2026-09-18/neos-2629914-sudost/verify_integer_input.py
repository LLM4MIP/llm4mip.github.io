#!/usr/bin/env python3
"""Ensure the archived certificate's int(Decimal(...)) cannot truncate data."""
import gzip
import hashlib
from decimal import Decimal
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3]
path=ROOT/'instances/neos-2629914-sudost/input/neos-2629914-sudost.mps.gz'
assert hashlib.sha256(path.read_bytes()).hexdigest() == 'd13e000b9cbff6ebc6c6426cdfaea2e44501714a5be294c669e9e8e9d57d60e5'
section=''; count=0; rhs_names=set(); bound_names=set()
with gzip.open(path,'rt') as stream:
    for raw in stream:
        t=raw.split()
        if not t or raw.startswith('*'): continue
        if not raw[0].isspace():
            assert t[0] in {'NAME','ROWS','COLUMNS','RHS','BOUNDS','ENDATA'}, t
            section=t[0]; continue
        if section=='COLUMNS' and "'MARKER'" not in t:
            numbers=t[2::2]
        elif section=='RHS':
            rhs_names.add(t[0]); numbers=t[2::2]
        elif section=='BOUNDS':
            bound_names.add(t[1]); numbers=t[3:]
        else: continue
        for token in numbers:
            value=Decimal(token.replace('D','E').replace('d','e'))
            assert value.is_finite() and value == value.to_integral_value(), (section,token)
            count+=1
assert len(rhs_names)==len(bound_names)==1
assert hashlib.sha256(gzip.decompress(path.read_bytes())).hexdigest() == '9ecc76582a0fd3e28bd5c0064ec91edc9daa00ae13b3a92130cfeaa1575cf8d9'
print(f'Integral input guard PASSED: all {count} MPS numeric tokens are exact integers')
print('Single RHS vector, single bound vector; no ranges or nonstandard objective sense')
print('Both archived compressed and uncompressed MPS SHA-256 values match')
