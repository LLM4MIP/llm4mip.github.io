# Row 8 audit: neos-2629914-sudost

**Confirmed: lower bound = optimum = 48,180.** The complete archived computational proof reran successfully, including all 14,078,016 grid-compatible assignments. No optimization solver was run. Compressed and uncompressed MPS hashes and the saved solution hash match the instance README.

The verifier checks 32 permutation equations, all 48,000 necessary product lower-bound rows, positive objective flow coefficients, binary assignment variables, and auxiliary lower bounds 11. Thus every original feasible solution dominates the extracted QAP objective. The exact distance embedding is `10 + Manhattan distance`; flow symmetry and positivity are checked. Decomposing into coordinate cuts gives `36020 + 2*(Cx+Cy)`.

The two independent nested-cut dynamic programs return `min Cx=2254` and `min Cy=3793`. A strict improvement would have `Cx+Cy <= 6079`, and therefore `Cx <= 2286`, `Cy <= 3825`. Enumeration gives 32,367 X chains and 8,147 Y chains. All 1,728 within-row bijections for each Y chain were checked: 14,078,016 assignments, 118,161 matches with a capped X chain, minimum matched sum 6,080. Therefore no strict improvement exists. The saved assignment has `Cx=2273`, `Cy=3807`, and attains 48,180.

The exhaustive checker also validates the original witness against all 51,872 MPS rows. A separate common MPS checker reran at tolerance zero and independently reports objective 48,180 with zero row, bound, and integrality violations.

**Input-parser guard added:** two archived reader routines use `int(Decimal(token))`, which could silently truncate a noninteger coefficient on another input. [verify_integer_input.py](verify_integer_input.py) confirms that all 258,560 numeric tokens in this actual MPS are exact integers, that only one RHS and bound vector occur, and that no unsupported objective-sense/range feature is present. Thus there is no truncation in this proof. This is an independently rerunnable finite integer computation, not a proof-assistant formalization.

Evidence: [complete certificate replay](certificate-replay.log), [input guard](supplement-replay.log), [independent primal replay](primal-replay.log), [file hashes](provenance.json).

From the repository root, with Python 3.10 or newer:

```sh
python -B docs/rows-06-20-dual-bound-review-2026-09-18/neos-2629914-sudost/verify_integer_input.py
python -B instances/neos-2629914-sudost/scripts/sudost_optimality_certificate.py instances/neos-2629914-sudost/input/neos-2629914-sudost.mps.gz --solution instances/neos-2629914-sudost/solutions/sudost_48180.sol
python -B common/exact_mps_solution_check.py instances/neos-2629914-sudost/input/neos-2629914-sudost.mps.gz instances/neos-2629914-sudost/solutions/sudost_48180.sol --tolerance 0
```

The complete proof took 4.13 seconds on this machine. Original files were preserved.
