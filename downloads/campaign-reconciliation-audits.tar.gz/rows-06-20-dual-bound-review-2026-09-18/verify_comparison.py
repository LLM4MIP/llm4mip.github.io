#!/usr/bin/env python3
"""Check the README rows 6 through 20 against the preserved COPT PDF extraction."""
import hashlib
import json
import re
from decimal import Decimal, getcontext
getcontext().prec = 80
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PDF = ROOT / 'docs/dual-bound-audit-2026-09-14/sources/frozen-copt-table.pdf'
PDF_SHA = 'd34798161c0535ba22595ffc1cc8c1dfb40a86d5b21963a542297330db65589f'
EXPECTED = [('fhnw-binschedule1','55158'), ('neos-3009394-lami','5.5'),
            ('neos-2629914-sudost','48180'), ('graph40-80-1rand','-7'),
            ('graph40-40-1rand','-9'), ('mining','-835361895.5863052144840282387439'),
            ('liu','1074'), ('fastxgemm-n3r21s3t6','93'), ('genus-g61-25','-42'),
            ('genus-sym-g62-2','-40'), ('bppc6-06','208'),
            ('neos-4360552-sangro','-8'), ('ns1631475','11100'),
            ('genus-sym-g31-8','-23'), ('genus-g31-8','-23')]


def main():
    assert hashlib.sha256(PDF.read_bytes()).hexdigest() == PDF_SHA
    extracted = (HERE / 'evidence/copt-table.txt').read_text()
    baseline = {}
    for line in extracted.splitlines():
        cells = line.split('|')
        if len(cells) != 4 or not cells[0].strip().isdigit():
            continue
        metadata, values = cells[1].split(), cells[2].split()
        baseline[cells[3].strip()] = (metadata[0], values[1])
    assert len(baseline) == 217
    assert 'Threads=8' in extracted and 'RelGap=0' in extracted
    table = (ROOT / 'README.md').read_text().split('### Dual-bound improvements over COPT 10h',1)[1]
    rows = [line for line in table.splitlines() if line.startswith('| [`')][5:20]
    snapshot = json.loads((ROOT / 'docs/comparisons/copt-10h-vs-github-20260907/copt-10h-github-tracked-94.json').read_text())
    archived = {row['name']: row for row in snapshot['rows']}
    result = []
    for row,(name,bound) in zip(rows,EXPECTED):
        cells = [c.strip().replace('**','') for c in row.split('|')[1:-1]]
        assert re.search(r'\[`([^`]+)`\]',cells[0]).group(1) == name
        runtime, dual = baseline[name]
        assert Decimal(runtime) == 36000
        assert cells[1] == dual == archived[name]['dual_bound']
        assert Decimal(cells[2]) == Decimal(bound)
        delta = Decimal(bound)-Decimal(dual)
        display_delta = Decimal(cells[3])
        rounding_error = display_delta - delta
        assert abs(rounding_error) <= Decimal('1e-20') and delta > 0
        assert cells[4] in ('E','X')
        result.append({'instance':name, 'copt_displayed_dual':dual,
                       'readme_claimed_lower_bound':bound, 'exact_delta_from_displayed_inputs':str(delta),
                       'readme_displayed_delta':cells[3], 'rounding_error':str(rounding_error),
                       'evidence_code':cells[4],
                       'copt_runtime_seconds':runtime, 'comparison_consistent_to_displayed_precision':True})
    assert len(result) == 15
    output = {'source_pdf':str(PDF.relative_to(ROOT)), 'source_pdf_sha256':PDF_SHA,
              'extraction_method':'Fresh Ghostscript txtwrite; same source PDF as first-five audit',
              'scope':'Historical displayed COPT bounds; no new COPT benchmark run',
              'rows':result}
    (HERE / 'comparison-recheck.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(output,indent=2))


if __name__ == '__main__':
    main()
