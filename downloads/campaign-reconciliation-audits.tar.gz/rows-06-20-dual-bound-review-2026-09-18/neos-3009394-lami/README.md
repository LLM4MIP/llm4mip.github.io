# Row 7 audit: neos-3009394-lami

**Confirmed: lower bound = optimum = 5.5.** All checked archived hashes match the instance README. No optimization solver was run.

The original matching script was rerun. The regenerated certificate is identical to the archived certificate. It checks all 676 one-hot equations, all 325 four-way pair disjunctions, and the exact objective-envelope coefficients; its maximum matching at 5.5 covers all 26 points. At the predecessor edge-cost threshold 5.428571429, all 26 points have only the 25 cells with second coordinate at most 4 as neighbors. More directly, every sixth-row cell has cost at least exactly 5.5, so a solution strictly below 5.5 would inject 26 distinct points into 25 cells.

**Checker completeness gap closed in this audit:** the archived matching reader discards integer markers and does not verify the senses of the final 52 objective-envelope rows. Both are essential for the lower-bound reduction. [verify_original_assumptions.py](verify_original_assumptions.py) checks against the MPS that all 2,704 selectors are binary, all 52 coordinates are integer, their bounds give precisely the 5-by-6 grid, all 52 envelope rows have sense `G`, and the objective is the unit-coefficient side variable without an offset. It also recomputes the sixth-row minimum cost exactly. All checks pass.

Both the archived matching witness and the newly regenerated matching witness pass all 2,028 original rows, all variable bounds, and all integer conditions at tolerance zero with objective 5.5. Their printed violation counts and maxima are all zero.

Evidence: [certificate replay](certificate-replay.log), [supplement replay](supplement-replay.log), [archived primal replay](primal-replay.log), [regenerated primal replay](regenerated-primal-replay.log), [regenerated certificate](regenerated-certificate.json), [file hashes](provenance.json).

From the repository root, with Python 3.10 or newer:

```sh
python -B instances/neos-3009394-lami/scripts/solve_bottleneck_matching.py instances/neos-3009394-lami/input/neos-3009394-lami.mps.gz --official-solution instances/neos-3009394-lami/solutions/official-5.5.sol --certificate docs/rows-06-20-dual-bound-review-2026-09-18/neos-3009394-lami/regenerated-certificate.json --solution-output docs/rows-06-20-dual-bound-review-2026-09-18/neos-3009394-lami/regenerated-matching.sol
python -B docs/rows-06-20-dual-bound-review-2026-09-18/neos-3009394-lami/verify_original_assumptions.py
python -B common/exact_mps_solution_check.py instances/neos-3009394-lami/input/neos-3009394-lami.mps.gz instances/neos-3009394-lami/solutions/matching-optimal.sol --tolerance 0
```

The current external MIPLIB status was not part of this local certificate audit. Original files were preserved.
