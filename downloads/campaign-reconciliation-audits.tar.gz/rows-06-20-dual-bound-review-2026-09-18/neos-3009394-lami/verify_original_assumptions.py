#!/usr/bin/env python3
"""Check assumptions omitted by the archived bottleneck-matching reader."""
import hashlib
import importlib.util
import json
import sys
from decimal import Decimal
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'instances/neos-3009394-lami'


def main():
    path = BASE / 'input/neos-3009394-lami.mps.gz'
    assert hashlib.sha256(path.read_bytes()).hexdigest() == 'e394f664a010d3aeddbbd8494a85a66b673a57e6bfd8f5c0af8849168d3e0e0b'
    spec = importlib.util.spec_from_file_location('reader', ROOT / 'instances/liu/scripts/analyze_structure.py')
    reader = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(reader)
    m = reader.parse_mps(path)
    assert set(m['variables']) == {f'C{k:04d}' for k in range(1,2758)}
    assert m['integer_variables'] == {f'C{k:04d}' for k in range(2,2758)}
    assert m['rows'][m['objective_row']] == {'C0001': Decimal(1)}
    assert m['rhs'].get(m['objective_row'],0) == 0
    assert set(m['row_types']) == {m['objective_row']} | {f'R{k:04d}' for k in range(1,2029)}
    for k in range(2,2706):
        name = f'C{k:04d}'
        assert m['lower'][name] == 0 and m['upper'][name] == 1
    for k in range(2706,2758):
        name = f'C{k:04d}'
        assert m['lower'][name] == 0 and m['upper'][name] == (4 if k < 2732 else 5)
    for k in range(1977,2029):
        assert m['row_types'][f'R{k:04d}'] == 'G'
    # The 26-by-5 sixth-row edge costs give a direct exact pigeonhole proof.
    minimum = min(max(Decimal(a+5)+m['rhs'][f'R{1977+i:04d}'],
                      Decimal(5-a)+m['rhs'][f'R{2003+i:04d}'])
                  for i in range(26) for a in range(5))
    assert minimum == Decimal('5.5')
    archive=json.loads((BASE/'artifacts/bottleneck-matching-certificate.json').read_text())
    replay=json.loads((Path(__file__).parent/'regenerated-certificate.json').read_text())
    assert archive == replay
    print('Original MPS assumptions PASSED: all 2704 selectors binary; all 52 coordinates integer')
    print('All 52 objective-envelope rows are >=; objective is C0001 with no offset')
    print('Bounds give a 5-by-6 grid; minimum exact sixth-row cost = 5.5')
    print('For t < 5.5, 26 distinct points would occupy only 25 cells: impossible')
    print('Regenerated matching certificate equals the archived certificate')


if __name__ == '__main__':
    main()
