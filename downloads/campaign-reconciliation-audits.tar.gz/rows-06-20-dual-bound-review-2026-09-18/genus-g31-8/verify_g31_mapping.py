# Adapted for odd parity from archived genus_mps_reduction_audit.py.
"""Audit every MPS row proving active face slots <= rotation-system face cycles.

No optimization calls. Only this necessity implication is claimed: the native
rotation model is a relaxation for bounding the original face-slot objective.
"""
import argparse,collections,hashlib,itertools,re,time
from pathlib import Path
import json
ROOT = Path(__file__).resolve().parents[3]
def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2)+'\n')
def paths(name):
    folder=ROOT/'instances'/name
    return folder/'input'/(name+'.mps.gz'), folder/'solutions'/'official-23.sol.gz'
def gp_read(name):
    import gurobipy as gp
    gp.setParam('OutputFlag',0)
    return gp.read(str(paths(name)[0]))

def audit(name,out):
    started=time.monotonic();m=gp_read(name);vs=m.getVars();rows=m.getConstrs();A=m.getA().tocsr()
    assert m.ModelSense==1 and m.ObjCon==0
    darts=sorted({tuple(map(int,v.VarName.split('_')[1:])) for v in vs if v.VarName.startswith('c0_')})
    adj=collections.defaultdict(set)
    for a,b in darts:assert (b,a) in darts;assert a!=b;adj[a].add(b)
    assert min(map(len,adj.values()))>=3
    connected={min(adj)}
    while True:
        nxt=set().union(*(adj[v] for v in connected))|connected
        if nxt==connected:break
        connected=nxt
    assert connected==set(adj)
    slots=sorted(int(v.VarName[1:]) for v in vs if re.fullmatch(r'x\d+',v.VarName) and v.Obj==-1 and v.UB==1)
    assert slots==list(range(len(slots)))
    expected_names={f'c{s}_{a}_{b}' for s in slots for a,b in darts}|{f'x{s}' for s in slots}
    triple={}
    for v in vs:
        if v.VarName.startswith('p'):
            center,*nb=map(int,v.VarName[1:].split('_'))
            if len(nb)==3:
                assert len(adj[center])==3 and set(nb)==adj[center] and center not in triple
                triple[center]=(v.VarName,nb);expected_names.add(v.VarName)
    for v,nb in adj.items():
        if len(nb)==3:assert v in triple
        else:expected_names.update(f'p{v}_{a}_{b}' for a in nb for b in nb if a!=b)
    extra=[v for v in vs if v.VarName not in expected_names]
    assert len(extra)==2
    fixed=[v for v in extra if v.LB==v.UB==0 and v.Obj==-1]
    parity=[v for v in extra if v.LB==0 and v.UB==len(slots)//2 and v.Obj==0 and v.VType in 'BI']
    assert len(fixed)==len(parity)==1
    for v in vs:
        if v.VarName in expected_names:
            assert v.LB==0 and v.UB==1 and v.VType in 'BI'
            assert v.Obj==(-1 if v.VarName.startswith('x') else 0)
    def key(sense,rhs,terms):return sense,rhs,tuple(sorted(terms.items()))
    actual=collections.Counter()
    for r,c in enumerate(rows):
        lo,hi=A.indptr[r:r+2]
        actual[key(c.Sense,c.RHS,{vs[j].VarName:float(a) for j,a in zip(A.indices[lo:hi],A.data[lo:hi])})]+=1
    counts=collections.Counter();used=0
    def require(kind,sense,rhs,terms):
        nonlocal used
        k=key(sense,rhs,terms)
        assert actual[k]>0,('Missing original row',name,kind,k)
        actual[k]-=1;counts[kind]+=1;used+=1
    # Every dart belongs to exactly one original face slot.
    for a,b in darts:require('dart_partition','=',1,{f'c{s}_{a}_{b}':1 for s in slots})
    # Local rotation is a single directed neighbor circuit, including every cut.
    for v,nb in sorted(adj.items()):
        nb=sorted(nb)
        if len(nb)==3:continue
        for a in nb:
            require('rotation_outdegree','=',1,{f'p{v}_{a}_{b}':1 for b in nb if b!=a})
            require('rotation_indegree','=',1,{f'p{v}_{b}_{a}':1 for b in nb if b!=a})
        for size in range(1,len(nb)):
            for selected in itertools.combinations(nb,size):
                subset=set(selected)
                require('rotation_subtour_cut','>',1,{f'p{v}_{a}_{b}':1 for a in subset for b in set(nb)-subset})
    for s in slots:
        for v,nb in sorted(adj.items()):
            flow={**{f'c{s}_{v}_{a}':1 for a in nb},**{f'c{s}_{a}_{v}':-1 for a in nb}}
            require('face_flow_balance','=',0,flow)
            if len(nb)==3:
                pn,cycle=triple[v]
                for active in [0,1]:
                    order=cycle if active else list(reversed(cycle))
                    for a,b in zip(order,order[1:]+order[:1]):
                        cin=f'c{s}_{a}_{v}';cout=f'c{s}_{v}_{b}'
                        for sign in [-1,1]:
                            require('degree3_rotation_face_consistency','>',-active,{cin:sign,cout:-sign,pn:-1 if active else 1})
            else:
                for a in nb:
                    for b in nb:
                        if a==b:continue
                        pn=f'p{v}_{a}_{b}';cin=f'c{s}_{a}_{v}';cout=f'c{s}_{v}_{b}'
                        for sign in [-1,1]:
                            require('general_rotation_face_consistency','<',1,{cin:sign,cout:-sign,pn:1})
        # The only implication needed is x_s=1 => at least one assigned dart.
        require('active_slot_nonempty','<',0,{f'x{s}':1,**{f'c{s}_{a}_{b}':-0.333333333333333 for a,b in darts}})
    require('active_face_parity','=',(len(darts)//2-len(adj))%2,{**{f'x{s}':1 for s in slots},parity[0].VarName:-2})
    if name.startswith('genus-sym'):
        for s in slots[:-1]:require('slot_order_symmetry','>',0,{f'x{s}':1,f'x{s+1}':-1})
    remaining=[(k,n) for k,n in actual.items() if n]
    assert not remaining,('Unclassified original rows',remaining[:3])
    assert used==len(rows)
    result={'instance':name,'original_mps_sha256':hashlib.sha256(paths(name)[0].read_bytes()).hexdigest(),
        'all_original_rows_checked':len(rows),'all_original_variables_checked':len(vs),'row_classes':dict(counts),
        'vertices':len(adj),'edges':len(darts)//2,'darts':len(darts),'face_slots':len(slots),'connected':True,
        'minimum_degree':min(map(len,adj.values())),'elapsed_seconds':time.monotonic()-started,
        'claimed_direction':'Any original integer-feasible point induces a one-cycle local rotation at every vertex; each successor face cycle belongs to one original face slot; hence number of active original slots <= native face cycles.',
        'native_encoding_completion':'Give each successor cycle its minimum dart label, root exactly at that dart, and rank equal to distance after the root. Reversing all local rotations, if needed, preserves cycle count and satisfies the single mirror constraint.',
        'native_parity':'A connected orientable rotation system has F congruent to E-V modulo 2. Both audited g31 graphs have odd E-V, so F is odd.',
        'bound_transfer':'If the native improving model has certified face upper bound U, the original minimum objective is at least -U. A native INFEASIBLE result excludes all strict original improvements.',
        'limitations':'This is an exact row-pattern and logical-reduction audit, not an independently checked CP-SAT search proof. The reverse direction and arbitrary native-candidate original-MPS reconstruction are not claimed.'}
    dump(out/name/'original-mps-reduction-audit.json',result);print(result,flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    for name in ['genus-g31-8','genus-sym-g31-8']:audit(name,a.output)
