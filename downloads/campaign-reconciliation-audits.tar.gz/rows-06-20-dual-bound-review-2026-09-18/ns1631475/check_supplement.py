"""Check objective, commodity layer uniqueness and normalized flow orientation."""
from pathlib import Path
import gurobipy as gp
import hashlib,json
OUT=Path(__file__).resolve().parent;REPO=OUT.parents[2]
p=REPO/'instances/ns1631475/input/ns1631475.mps.gz'
s=json.loads((REPO/'instances/ns1631475/artifacts/recovered-tsp-layers.json').read_text())
m=gp.read(str(p));vs=m.getVars();cs=m.getConstrs()
assert m.ModelSense==1 and m.ObjCon==0
A=m.getA().tocsr()
assert all(float(c).is_integer() for c in A[1:31].data)
assert all(float(c).is_integer() for c in A[241:24496].data)
assert {v.VarName:v.Obj for v in vs if v.Obj}=={'C22486':1}
bins=[v for v in vs if v.VType!='C' and v.LB==0 and v.UB==1]
assert len(bins)==107*210
layers=[bins[i:i+210] for i in range(0,len(bins),210)]
arcs={v:tuple(e) for v,e in s['base_arc_by_variable'].items()}
assert set(arcs.values())=={(i,j) for i in range(15) for j in range(15) if i!=j}
base=[v.VarName for v in layers[0]]
arc_of={v.VarName:arcs[base[q]] for layer in layers for q,v in enumerate(layer)}
layer_of={v.VarName:k for k,layer in enumerate(layers) for v in layer}
normalized={k:{} for k in range(2,107)}
for row in cs[451:2026]:
 assert row.Sense=='=' and row.RHS in (-1,0,1)
 e=m.getRow(row);terms={e.getVar(q).VarName:e.getCoeff(q) for q in range(e.size())}
 layer=layer_of[next(iter(terms))]
 common=set(range(15))
 for v in terms:common.intersection_update(arc_of[v])
 assert len(common)==1;node=common.pop()
 sign=next(c for v,c in terms.items() if arc_of[v][0]==node)
 assert all(c==sign*(1 if arc_of[v][0]==node else -1) for v,c in terms.items())
 assert node not in normalized[layer];normalized[layer][node]=int(row.RHS*sign)
commod=s['flow_commodities']
assert {c['binary_layer'] for c in commod}==set(range(2,107))
for c in commod:
 assert type(c['demand']) in (int,float) and c['demand']>=0 and int(c['demand'])==c['demand'] and c['demand']%150==0
 r=normalized[c['binary_layer']]
 assert len(r)==15 and sorted(r.values())==[-1]+[0]*13+[1]
 assert {n for n,b in r.items() if b}==set(c['endpoints_zero_based'])
result={'verified':True,'objective_minimize_C22486_no_constant':True,'all_210_arcs_verified':True,'105_commodity_layers_distinct':True,'all_1575_conservation_rows_have_consistent_normalized_balance':True,'all_demands_nonnegative_multiples_of_150':True,'mps_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'solver_calls':0}
(OUT/'supplemental-mapping.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
