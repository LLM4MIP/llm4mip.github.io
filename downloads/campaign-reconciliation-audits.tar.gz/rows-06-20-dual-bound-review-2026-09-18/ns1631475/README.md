# Row 18: ns1631475

**Confirmed: original-model lower bound and optimum are 11,100.**

Both the archived original-model verifier and separate exact cyclic-cutwidth DFS replay successfully. The search checks 218,831 prefixes and prunes 1,262,956 extensions; it finds no cyclic order with every interval cut<=21,900. All demands are multiples of150, so every cyclic order has an interval demand cut>=22,050. That interval has two ring boundaries; their loads cannot both be<=10,950. Since each load is a multiple of150, objective>=11,100.

The audited assignment/tour-link/flow rows force a connected degree-two ring: all-pairs commodity flow feasibility connects the cycle cover, even for pairs with zero demand. Any unnecessary circulation in a binary flow only increases load and does not invalidate the cut argument.

The archived verifier omits explicit assertions for minimization/other objective coefficients, equality senses of balance rows, lossless integer conversion, distinct commodity layers, and globally normalized flow orientation. `check_supplement.py` checks those actual-file assumptions, full210-arc coverage, and integer coefficients of every original row used in the lower-bound argument. All pass. Fractional coefficients occur only in omitted MTZ constraints, which may safely be dropped for the lower bound.

**Original witness is exactly feasible.** The archived floating-point check has tiny accumulation residuals (fresh replay maximum4.09e-12), but evaluating the original public solution with Decimal gives objective11,100 and zero violations in all24,496 rows, bounds and integrality. No repair was needed. A separately saved copy after rounding integer entries also passes; the integer values were already exact. The result is supported by the original witness itself, not by tolerance acceptance.

Evidence: `full-chain-replay.json`, `cutwidth-replay.json`, `supplemental-mapping.json`, `official-decimal-audit.log`, and `rounded-witness-audit.log`. Gurobi was used only as an MPS reader; enumeration and Decimal checking use no optimizer.
