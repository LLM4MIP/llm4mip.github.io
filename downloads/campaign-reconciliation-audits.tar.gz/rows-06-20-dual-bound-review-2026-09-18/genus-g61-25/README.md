# genus-g61-25 lower-bound audit — 2026-09-18

**Confirmed: original-MPS global LB -42.**

Fresh complete replays:

- `catalogue.json`: independently enumerated all 14,492 admissible facial walks
  up to length 10 from the original MPS graph.
- `branch.json` / `.log`: checked all 3,803 branch nodes and 1,902 exact rational
  leaf certificates; zero pending nodes; every rotation with at least 44 faces
  is excluded. Replay took about 13 seconds, with no optimization/search call.
- `archive-hash-check.json`: compressed complete tree and all 1,904 members match
  the frozen publication manifest. The expanded 205 MB scratch copy was moved to
  `/tmp/miplib-rows06-20-g61-complete-proof-20260918`; archived evidence is intact.
- `original-mps-reduction-audit.json`: reran the full original-model necessity
  audit using Gurobi only to read the model; all 94,735 rows and 14,380 variables
  match the required patterns. The study input is byte-identical to the canonical
  instance MPS, SHA-256
  `f601e791f656d3cd6769180cfcbbce22aedbfb411b439d012be90031ff5277b0`.

The reduction supplies a one-cycle local rotation at every vertex. Original face
slots partition darts and are closed under successor; every active slot is
nonempty. Therefore active slots cannot exceed native face cycles. The
60-vertex, 118-edge graph has even face parity. Excluding 44 or more faces hence
implies F<=42 and original objective >=-42.

The catalogue permits repeated vertices/opposite darts and excludes only
repeated directed darts, reversals, and impossible local subtours. The leaf
checker reconstructs every inequality and nonnegative integer dual weight; the
branch checker verifies both 0/1 children and full coverage. No reliance on the
older external genus-8 result or incomplete 42-face search is needed.

The -40 primal was not revalidated in this audit; the instance README already
limits it to tolerance 1e-6 because of rounded thirds. This does not affect the
lower bound. The full reduction reader uses Gurobi's numeric matrix API; its
noninteger one-third coefficient is used only for the sign implication that an
active slot is nonempty, so exact-decimal rounding does not weaken this direction.
