"""Bounded fresh UNSAT computation; deliberately not a proof-trace replay."""
from pathlib import Path
import hashlib,json,subprocess,sys,time
OUT=Path(__file__).resolve().parent
CNF=Path('/private/tmp/miplib-bppc207-rebuilt/model.cnf')
EXPECTED='85cd2537ef615b878f0a57d1cb5198bbc6cd3835261306c6dfcc7086d25ecc6b'
if '--child' in sys.argv:
 from pysat.formula import CNF as Formula
 from pysat.solvers import Solver
 assert hashlib.sha256(CNF.read_bytes()).hexdigest()==EXPECTED
 f=Formula(from_file=str(CNF)); t=time.monotonic()
 print('CNF loaded',f.nv,len(f.clauses),flush=True)
 with Solver(name='cadical195',bootstrap_with=f.clauses) as s:
  sat=s.solve()
  result={'status':'SAT' if sat else 'UNSAT','solver':'PySAT CaDiCaL195','seconds':time.monotonic()-t,'cnf_sha256':EXPECTED,'statistics':s.accum_stats(),'proof_trace_generated':False,'evidence':'fresh exact Boolean solver computation, not independently checked proof trace'}
  (OUT/'fresh-sat-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
else:
 start=time.monotonic()
 try:
  with (OUT/'fresh-sat.log').open('w') as log:
   done=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--child'],stdout=log,stderr=subprocess.STDOUT,timeout=600)
  outcome={'process_returncode':done.returncode,'wall_seconds':time.monotonic()-start,'limit_seconds':600}
 except subprocess.TimeoutExpired:
  outcome={'status':'TIMEOUT','wall_seconds':time.monotonic()-start,'limit_seconds':600}
 (OUT/'fresh-sat-supervisor.json').write_text(json.dumps(outcome,indent=2)+'\n');print(outcome)
