"""Exact full-row template audit supporting the compressed-chain necessity map."""
from pathlib import Path
from collections import Counter
import hashlib,json,sys
OUT=Path(__file__).resolve().parent
REPO=OUT.parents[2]
sys.path.insert(0,str(REPO/'instances/neos-4360552-sangro/scripts'))
from independent_audit import read_mps,family
p=REPO/'instances/neos-4360552-sangro/input/neos-4360552-sangro.mps.gz'
sense,rows,order,mat,rhs,obj,bounds,integer,variables=read_mps(p)
assert sense=='min' and len(variables)==10272 and integer==variables
I=range(1,7);J=range(1,13);N=range(1,49);K=range(1,59)
def v(f,*a):return f+'('+','.join(map(str,a))+')'
expected_vars={v('w',n,k) for n in N for k in K}|{v('x',i,j,n) for i in I for j in J for n in N}|{v('y',i,n,j) for i in I for j in J for n in N}|{v(f,i,n) for f in ['s','e'] for i in I for n in N}
assert variables==expected_vars
assert all(bounds[x]==(0,12 if x.startswith(('s(','e(')) else 1) for x in variables)
assert {x:c for x,c in obj.items() if c}=={v('w',n,k):-1 for n in N for k in K}
checked=set()
def check(name,s,r,terms):
 terms={k:c for k,c in terms.items() if c}
 assert name not in checked
 assert rows[name]==s and rhs[name]==r and mat[name]==terms,(name,rows[name],rhs[name],mat[name],terms)
 checked.add(name)
labels={}
for n in N:
 for ell in range(12):
  name=f'aggri_{n}_{ell}'
  xs=[x for x in mat[name] if x.startswith('x(')]
  assert len(xs)==6
  local={}
  for x in xs:
   i,j,n1=map(int,x[2:-1].split(',')); assert n1==n and i not in local;local[i]=j
  assert set(local)==set(I)
  labels[n,ell]=local
  check(name,'E',0,{**{v('w',n,k):-1 for k in K},**{x:1 for x in xs}})
for n in N:
 for i in I:assert {labels[n,ell][i] for ell in range(12)}==set(J)
for n in N:
 for ell in range(12):assert labels[n,ell]==labels[1,ell]
profiles={k:tuple(mat[f'wS_{k}_1_{j}'].get(v('w',1,k),0) for j in J) for k in K}
assert len(set(profiles.values()))==58
assert all(sum(c)==12 and 6>=c[0] and all(c[j]>=c[j+1]>=0 for j in range(11)) for c in profiles.values())
for k in K:
 check(f'w_difk_{k}','L',1,{v('w',n,k):1 for n in N})
for n in N:
 check(f'w_difn_{n}','L',1,{v('w',n,k):1 for k in K})
 check(f'twtone_{n}','E',0,{**{v('w',n,k):-12 for k in K},**{v('x',i,j,n):1 for i in I for j in J}})
for i in I:
 check(f'stfix_{i}_1','E',0,{v('s',i,1):1})
 check(f'edfix_{i}_48','E',12,{v('e',i,48):1})
 for n in N:
  check(f'Nless_{i}_{n}','L',12,{v('x',i,j,n):1 for j in J})
  check(f'x_es_{i}_{n}','E',0,{**{v('x',i,j,n):1 for j in J},v('s',i,n):1,v('e',i,n):-1})
  check(f'y_{i}_{n}','E',0,{v('s',i,n):-1,v('e',i,n):1,**{v('y',i,n,j):-1 for j in J}})
  if n>1:
   check(f'e_e_{i}_{n}','G',0,{v('e',i,n-1):-1,v('e',i,n):1})
   check(f'e_s_{i}_{n}','G',-1,{v('s',i,n):1,v('e',i,n-1):-1})
   check(f'ord_s_e_{i}_{n}','G',0,{v('s',i,n):-1,v('e',i,n-1):1})
  for j in J:
   check(f'jx_s_{i}_{j}_{n}','L',12,{v('x',i,j,n):13-j,v('s',i,n):1})
   check(f'jx_e_{i}_{j}_{n}','G',0,{v('x',i,j,n):-j,v('e',i,n):1})
   if j>1:check(f'y2y_{i}_{n}_{j}','G',0,{v('y',i,n,j-1):1,v('y',i,n,j):-1})
 for j in J:check(f'cover_{i}_{j}','G',1,{v('x',i,j,n):1 for n in N})
for k in K:
 for n in N:
  for j in J:check(f'wS_{k}_{n}_{j}','L',0,{v('w',n,k):profiles[k][j-1],**{v('y',i,n,j):-1 for i in I}})
assert checked==set(rows) and len(checked)==46012
result={'verified':True,'mps_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'all_original_rows_checked':len(checked),'all_original_variables_checked':len(variables),'row_families':dict(Counter(family(r) for r in checked)),'identical_layer_label_matrices':48,'partition_profiles':58,'analytic_global_active_layer_bound':11,'justification':'Each active layer has total duration12. Endpoints start0/end12 on six tracks; adjacent overlap is0 or1. Inactive layers are identity transitions. After deleting them, sum(overlap)=12A-72<=6(A-1), hence A<=11. Active layers require one of the original profiles; dropping profile uniqueness relaxes original feasibility. Fresh infeasibility for each A in9,10,11 therefore proves A<=8.','solver_calls':0}
(OUT/'original-reduction-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
