# Row 17: neos-4360552-sangro

**Confirmed computationally: original-model lower bound and optimum are -8.**

The exact Decimal witness audit passes all 46,012 original rows, bounds and integrality, with objective -8. The added `check_original_reduction.py` matches every original row against its complete interval/label/partition template and checks all 10,272 variables, integer types, bounds and objective. It confirms all 48 label matrices coincide and the 58 partition profiles are independent of layer.

**Reproduction gap in the README:** infeasibility for exactly A=9 does not alone prove A<=8. The compressed model fixes final endpoints to 12, so deleting active layers is not a justified monotonicity argument. The complete older Chinese report also contains separate exclusions of A=10 and A>=11; these are necessary in that argument. This audit freshly runs the weaker repeated-partition relaxation for each A=9,10,11, and all three return INFEASIBLE.

The complete global implication is now explicit. Every active layer contributes total duration 12. Six tracks go from 0 to 12, and each consecutive overlap is 0 or 1. Inactive layers have zero duration and, using nondecreasing end coordinates, are identity transitions; deleting them preserves the chain. Consequently 12A-72 equals the sum of overlaps in the active chain, at most 6(A-1). Hence A<=11. The three fresh infeasibility computations exclude every remaining A>8. Dropping partition uniqueness is a valid relaxation. The extra inequality overlap<=number of positive intervals minus6 is also implied: on each track the first positive interval starts at0 and has no incoming overlap.

Fresh OR-Tools 9.15.6755, four-worker times: A9 2.8193s, A10 0.7666s, A11 0.0131s. Each had a120s cap and completed as INFEASIBLE. This is integer exhaustive computation using a trusted CP-SAT engine, **not** an independently replayable LRAT/DRAT certificate. No such trace is supplied by the archived workflow.

Evidence: `original-reduction-audit.json`, `primal-replay.json`, all `A*-repeat-replay.json` and `.log` files. The original compressed model script was executed unmodified, only its output path and bounded run parameters changed. Original assets remain unchanged.
