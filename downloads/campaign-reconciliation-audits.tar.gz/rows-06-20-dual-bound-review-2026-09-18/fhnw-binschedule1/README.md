# Row 6 audit: fhnw-binschedule1

**Confirmed: lower bound = optimum = 55,158.** All archived input/solution/certificate SHA-256 values match the instance README. No optimization solver was run.

The archived compact verifier passes: 738 contracted interval groups, 19,089 compatibility arcs, matching and vertex cover of size 134, 604 paths, at most 3 occupied segments, and at least 601 incompatible transitions. Hence the two endpoint loads sum to at least `104306 + 10*601 = 110316`, giving makespan at least 55,158.

The compact checker only accepts certificate data; it does not connect those data to the MPS. The separate derivation script uses a Gurobi parser and floating-to-rational conversion. This audit adds [verify_original_mapping.py](verify_original_mapping.py), adapted from the first-five binschedule0 audit, to check the complete required bridge directly with exact Fraction MPS parsing. It verifies the objective, nonnegative load contributions, 2,152 item partitions, binary selectors, unit-capacity endpoint slots, all options of all 773 forced items, OR support containment and owner consistency, every timing window, the invariant fixed cost 104,306, two 387-slot directed paths, and 772 distinct cost-10 transition indicators. It also confirms that endpoint loads lie on the even lattice (the half-sum bound alone already suffices here).

The accounting is valid because the OR supports being charged are contained in unit-capacity endpoint slots: no two chosen assignments can cause the same OR cost to be charged twice. Forced-item assignment costs, OR costs, and transition costs are distinct nonnegative contributions. There is only one slot outside the 773 forced occupancies, so those items form at most three contiguous segments across two chains. Identical zero-duration items can be consolidated into one path without increasing the required number of good paths; the remaining interval-order graph is acyclic. The matching/cover equality therefore certifies the path-cover bound used above.

The original sparse witness at 55,158 was independently evaluated against all 772,872 constraints, bounds, and integrality conditions with tolerance zero. Every printed violation count and maximum is zero. Thus this is a full exact optimum check, not a replay of a solver gap.

Evidence: [compact certificate replay](certificate-replay.log), [original mapping replay](original-mapping-replay.log), [original primal replay](primal-replay.log), [file hashes](provenance.json).

From the repository root, with Python 3.10 or newer:

```sh
python -B instances/fhnw-binschedule1/scripts/verify_interval_certificate.py instances/fhnw-binschedule1/certificates/interval-order-certificate.json
python -B docs/rows-06-20-dual-bound-review-2026-09-18/fhnw-binschedule1/verify_original_mapping.py
python -B common/exact_mps_solution_check.py instances/fhnw-binschedule1/input/fhnw-binschedule1.mps.gz instances/fhnw-binschedule1/solutions/optimal-55158.sol --tolerance 0
```

The original mapping is memory-intensive because it reads the 8.6-million-nonzero MPS exactly. Original files were preserved.
