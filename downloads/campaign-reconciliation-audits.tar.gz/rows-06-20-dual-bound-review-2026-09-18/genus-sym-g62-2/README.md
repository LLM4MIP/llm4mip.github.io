# genus-sym-g62-2 lower-bound audit — 2026-09-18

**Confirmed: original-MPS global LB -40.**

Fresh complete replays:

- `catalogue.json` / `.log`: independent enumeration of all 54,952 admissible
  facial walks of length at most 12.
- `dual.json` / `.log`: all 55,636 dual columns and 757 nonzero dual rows checked
  with arbitrary-precision integers, yielding
  `F <= 5316188672/130000000 < 41`, hence F<=40.
- `original-mps-reduction-audit.json`: original-model necessity audit rerun for
  all 78,472 rows and 12,912 variables. Gurobi reads the model only; no optimizer
  is called. Study and canonical input copies are byte-identical, SHA-256
  `fa5e5a27ac21e571f6561fc9a26b6148f0c88276e656baf1cd51633cd3168d2e`.

The native bound follows from `(k+1)F <= 2E + sum_short((k+1-length)*indicator)`.
Complete short-face enumeration and the exact rational dual bound its right
side. Every original integer-feasible point induces local cyclic rotations;
its active, nonempty face slots are disjoint unions of native face cycles.
Thus original active slots <=F, transferring the certificate to LB -40.

The incomplete subsequent 40-face tree is not used. Global optimum remains
open; the -38 witness was not freshly revalidated here. As its README states,
that witness is tolerance-feasible, not an exact-decimal rational primal proof.
The original-model audit's numerical one-third coefficient is needed only for
its positive sign in the nonempty-slot implication; no reverse equivalence is
asserted.
