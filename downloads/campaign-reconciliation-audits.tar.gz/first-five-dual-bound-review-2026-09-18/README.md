# First five dual-bound improvements: independent recheck

Audit date: 2026-09-18 UTC (2026-09-17 America/Los_Angeles).
Scope: the first five rows of the root README's **Dual-bound improvements over
COPT 10h** table, in their existing order.

**All five numerical lower bounds and displayed improvements are confirmed.**
Each also has a checked feasible solution attaining its lower bound, so all five
optima are confirmed for the archived original MPS files. However, the original
CVRPP proof only considers eight routes; the actual MPS permits up to fifteen.
This audit supplies the missing free-fleet check. It also adds explicit checks
for assumptions not enforced by the original assignment and binschedule0
certificate checkers. Thus this is not an assertion that every original checker
was already sufficient on its own.

| Instance | COPT displayed dual bound | Exact rechecked LB = OPT | Difference | Outcome |
|---|---:|---:|---:|---|
| assign1-10-4 | 377.444386 | 422 | 44.555614 | confirmed; original checker assumptions supplemented |
| cvrpp-n16k8vrpi | 282.375839 | 450 | 167.624161 | confirmed after checking every permitted route count |
| dfn-bwin-DBE | 56406.0914 | 73623.79 | 17217.6986 | original exact proof replayed |
| fhnw-binschedule2 | 2273.5 | 2428 | 154.5 | original exact proof and primal replayed |
| fhnw-binschedule0 | 15642 | 15958 | 316 | certificate replayed; exact original-MPS mapping supplemented |

## COPT source and comparison scope

The five baseline values were extracted directly from the
[preserved COPT PDF](../dual-bound-audit-2026-09-14/sources/frozen-copt-table.pdf),
and its table was also visually inspected. Its SHA-256 is
`d34798161c0535ba22595ffc1cc8c1dfb40a86d5b21963a542297330db65589f`, matching the
original comparison provenance. All five rows report 36,000 seconds; the footer
states `Threads=8; RelGap=0`. The values also match the archived 94-instance JSON.
All five differences were recomputed using exact decimal arithmetic on the
displayed strings. See [comparison-recheck.json](comparison-recheck.json) and
[the extracted table](evidence/copt-table.txt).

These are comparisons against a historical displayed scalar dual bound, not
independent certification of COPT's internal search, a new COPT run, or a
same-budget performance experiment. Differences inherit the PDF's limited
precision. The older comparison `SOURCE.md` says the PDF was not committed;
the later 2026-09-14 audit does contain the hash-matching PDF used here.

## 1. assign1-10-4

The categorical counting lower bound is `76 + 192 + 64 + 90 = 422`. Both
archived feasible solutions pass the original checker. A separate parser checks
all 582 original rows, the binary assignment domains, the objective `min sum y`
with no constant, and both witnesses exactly. A separate integer dynamic program
over the ten groups reproduces the four counting minima.

The original checker omits explicit universal checks of the objective and
assignment binary domains, although its proof report claims broader coverage.
The actual MPS satisfies those assumptions, so this is a checker/documentation
gap rather than a false bound. See [the detailed audit](assign1-10-4/README.md)
and [independent results](assign1-10-4/independent_check.json).

## 2. cvrpp-n16k8vrpi

The original README and DP fix eight routes. The MPS instead has 15 vehicle
slots, allowing unused vehicles. The name `k8` is not an eight-route constraint
in this model. Proving a minimum over exactly eight routes is insufficient to
prove the original MPS lower bound.

The new independent integer-distance Held--Karp and subset-partition calculation
covers every nonempty route count. Counts 1--7 are infeasible; the minima for
8--15 routes are **450, 472, 513, 557, 604, 652, 706, 760**. An exact coefficient
audit of the original MPS establishes the necessary projection to those routes,
and the indicator-aware original-MPS primal check has zero violations at 450.
This closes the gap and confirms the original numerical claim. See
[the detailed audit and reproducible check](cvrpp/README.md).

## 3. dfn-bwin-DBE

Positive demands force a connected support on ten nodes. A support with nine
physical edges is a tree; the exact subset DP gives **7,362,379 cents** for every
root. A support with at least ten edges costs at least **8,122,240 cents**, just
from the ten cheapest opening costs. The exact original-MPS witness attains
73,623.79 with zero violations over its 235 rows, bounds, and integrality.
The structure audit and recurrence were reviewed, not merely their final output.
See [the full proof audit and replay logs](dfn/REVIEW.md).

The unmodified verifier needs **Python 3.10 or newer**, because it calls
`int.bit_count()`; Python 3.9 fails. The slightly smaller objective in the public
solution does not refute the result: that solution has six fractional binary
values and tiny row violations. The archived exact DP-tree witness is feasible.

## 4. fhnw-binschedule2

The unmodified solver-free verifier checks the original compressed MPS and
solution hashes, all structural assumptions, all 6,503 primal rows, bounds, and
integrality with exact fractions. It reproduces 76 mandatory endpoint items,
fixed cost 4,546, and a common interval antichain of size 35. The two 39-slot
endpoint paths require at least `35 + 76 - 80 = 31` active difference indicators,
so their loads sum to at least `4546 + 10*31 = 4856`. Their maximum is therefore
at least 2,428. The exact witness attains 2,428 at both endpoints.
See [the fresh complete replay](evidence/binschedule2-replay.log).

## 5. fhnw-binschedule0

The original compact JSON checker passes: 128 interval groups, 3,350 compatibility
arcs, a matching and vertex cover both of size 62, hence 66 minimum paths.
But that checker does not read the MPS. It trusts the supplied intervals, fixed
base cost, segment cap, difference cost, and even-load property. The original
extraction uses Gurobi floating-point coefficients and rational reconstruction.

The new [exact original-MPS mapping check](binschedule0/verify_original_mapping.py)
uses a direct Fraction parser and verifies all necessary lower-bound assumptions:
507 forced items, unit capacities in 508 endpoint slots, every option's interval
and fixed cost, two complete 254-slot paths, 506 distinct transition indicators
costing 10, and even integral endpoint loads. Transition indicators are disjoint
from OR variables already charged in the base. Every certificate group is checked
against the corresponding original items. Its [fresh output](binschedule0/original-mapping-replay.log)
passes, as does the separate [zero-tolerance primal check](binschedule0/primal-replay.log)
over all 58,085 original constraints.

For completeness, contraction of equal point intervals is valid: from any cover
by compatible paths, keep one representative of each duplicate point group and
delete the others. Shortcutting remains compatible because interval compatibility
is transitive. Deletion cannot increase the number of paths. Thus the original
items require at least 66 good runs. Removing the single non-forced endpoint
position leaves at most three occupied segments; cutting these segments at bad
transitions gives at most `3+B` good runs. Consequently `B >= 63`, endpoint load
sum is at least `31284 + 10*63 = 31914`, and evenness strengthens the maximum
endpoint load from 15,957 to **15,958**. The exact witness attains that value.

## Replay and preservation

No optimization solver was run. Original instance inputs, scripts, certificates,
solutions, README claims, and old evidence remain unchanged. New scripts and
results are confined to this directory. Inputs are actual model files, not Git
LFS pointer placeholders. This audit checked the archived input provenance; it
did not download new MIPLIB copies or establish current official acceptance.

Use Python 3.10 or newer from the repository root:

```sh
python docs/first-five-dual-bound-review-2026-09-18/verify_comparison.py
python docs/first-five-dual-bound-review-2026-09-18/assign1-10-4/independent_check.py
python docs/first-five-dual-bound-review-2026-09-18/cvrpp/reproduce.py
python instances/dfn-bwin-DBE/scripts/verify_dfn_exact.py instances/dfn-bwin-DBE/input/dfn-bwin-DBE.mps.gz
python common/exact_mps_solution_check.py instances/dfn-bwin-DBE/input/dfn-bwin-DBE.mps.gz instances/dfn-bwin-DBE/solutions/dfn-bwin-DBE.dp-tree.sol --tolerance 0
python instances/fhnw-binschedule2/scripts/verify_fhnw_binschedule2.py instances/fhnw-binschedule2/input/fhnw-binschedule2.mps.gz instances/fhnw-binschedule2/solutions/fhnw-binschedule2-public.sol.gz
python docs/first-five-dual-bound-review-2026-09-18/binschedule0/verify_original_mapping.py
python instances/fhnw-binschedule0/scripts/verify_interval_certificate.py instances/fhnw-binschedule0/certificates/interval-order-certificate.json
python common/exact_mps_solution_check.py instances/fhnw-binschedule0/input/fhnw-binschedule0.mps.gz instances/fhnw-binschedule0/solutions/optimal-15958.sol --tolerance 0
```

The common primal checker reports violations without failing the process; inspect
its actual counts. All counts in the saved successful primal checks are zero.
Assertions must remain enabled in certificate scripts (do not use `-O` or `-OO`).
