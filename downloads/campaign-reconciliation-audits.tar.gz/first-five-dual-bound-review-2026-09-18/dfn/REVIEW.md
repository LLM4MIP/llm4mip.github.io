# dfn-bwin-DBE: independent audit, 2026-09-18

**Verdict: the exact global optimum 73,623.79 is reproduced.** The README
dual-bound improvement over the displayed COPT 10-hour bound is arithmetically
correct: `73623.79 - 56406.0914 = 17217.6986`.

## Replayed evidence

- The original compressed MPS and both solution files are present, not Git LFS
  pointer files. All three SHA-256 values agree with the instance README; see
  `input-checks.json`.
- The unmodified standard-library verifier passes under Python 3.10.19. Every
  one of its ten root choices returns 7,362,379 cents. The lower bound for
  supports with at least ten physical edges is 8,122,240 cents. See
  `verify-dfn-exact-python310.log`.
- The independent original-MPS solution checker was run with `--tolerance 0`.
  The archived DP-tree witness has objective exactly 73,623.79, with zero row,
  variable-bound, and integrality violations. See `exact-witness-check.log`.
- The public solution has exact objective
  `73623.78788664004417240155686310590032`, but six nonintegral binary values
  (maximum deviation `2.57907583956E-7`) and 96 tiny row violations (maximum
  `3.28E-11`). It does not contradict the exact optimum. See
  `public-solution-check.log`.
- Additional parsing checks confirm one objective row, a zero objective offset,
  and no undeclared column/RHS rows. Each commodity has exactly all 81 directed
  arcs other than self-arcs and arcs entering its own source. Thus every simple
  source-to-destination tree route is expressible in the original model; see
  `tree-routing-sufficiency.json`.

## Proof audit

The original model has 2,475 binary design variables, 810 nonnegative flow
variables, and 235 constraints. The verifier checks the whole variable/row
partition, bounds, positive directed demands, flow conservation, the at-most-one
capacity choice per physical edge, and both directional capacity rows. In
particular, it checks that every flow arc is linked to its actual physical
endpoints. Relevant source: `scripts/verify_dfn_exact.py:275-495` within the
instance directory.

Every feasible support is connected, because every ordered pair has positive
demand. Therefore it has at least nine physical edges. A nine-edge support on
ten nodes is a tree. For any edge of that tree, flow conservation and
nonnegativity force at least the total crossing demand in each direction. The
required installed capacity is consequently at least the maximum of the two
directional totals. Sending each demand along its unique tree path attains those
totals; optional cyclic flow cannot lower the required capacity.

The subset recurrence enumerates the child components of a rooted tree,
attaches each component through one of its vertices, and uses the global cut of
that component to price the joining edge. Requiring the first component to
contain the least remaining vertex removes duplicate partition orders without
losing any tree. Increasing subset cardinality ensures all referenced tree
values are already final, including values used by the cached partition
recursion (`scripts/verify_dfn_exact.py:508-605`).

For any support with ten or more edges, each selected edge pays its own cheapest
positive opening cost. Summing the ten smallest such costs is a valid bound even
after dropping connectivity and capacity requirements. This gives 81,222.40,
strictly above the tree optimum (`scripts/verify_dfn_exact.py:607-628`). The
matching exact original-model witness completes the optimum proof.

## Reproduction caveats

The current system `python3` is Python 3.9.6. The documented verifier command
fails there at `mask.bit_count()` on line 592; the method requires Python 3.10 or
newer. The README says only “Python standard library” and should mention that
minimum version. The failed run is retained as `verify-dfn-exact.log`, followed
by the successful unmodified run in `verify-dfn-exact-python310.log`. This is a
reproduction issue, not a bound error.

The shared exact solution checker prints violations without returning a failing
process status. This audit inspected the numerical output, rather than treating
exit status alone as proof of feasibility.

## Commands

Run from the repository root with Python 3.10 or newer:

```sh
python3.10 instances/dfn-bwin-DBE/scripts/verify_dfn_exact.py \
  instances/dfn-bwin-DBE/input/dfn-bwin-DBE.mps.gz
python3.10 common/exact_mps_solution_check.py \
  instances/dfn-bwin-DBE/input/dfn-bwin-DBE.mps.gz \
  instances/dfn-bwin-DBE/solutions/dfn-bwin-DBE.dp-tree.sol --tolerance 0
```

No original instance, proof script, solution, or archived log was modified.
No optimization solver was run. The original Gurobi-dependent DP was reviewed
but not rerun; the complete solver-free lower-bound verifier and the separate
exact feasible-witness checker were rerun.
