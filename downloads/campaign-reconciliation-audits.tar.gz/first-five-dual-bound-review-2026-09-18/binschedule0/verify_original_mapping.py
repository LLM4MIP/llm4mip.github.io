#!/usr/bin/env python3
"""Connect the archived interval certificate to the original MPS, exactly.

No solver. Reuse the binschedule2 exact MPS reader, with a set-backed column
list and cached immutable Fraction tokens solely to speed up parsing.
"""
import functools
import hashlib
import importlib.util
import json
import sys
from collections import defaultdict
from fractions import Fraction
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'instances/fhnw-binschedule0'
spec = importlib.util.spec_from_file_location(
    'reader', ROOT / 'instances/fhnw-binschedule2/scripts/verify_fhnw_binschedule2.py')
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)


class IndexedList(list):
    def __init__(self):
        super().__init__()
        self.index = set()

    def append(self, value):
        super().append(value)
        self.index.add(value)

    def __contains__(self, value):
        return value in self.index


class Model:
    def __setattr__(self, key, value):
        if key == 'col_order':
            assert value == []
            value = IndexedList()
        object.__setattr__(self, key, value)


def main():
    reader.MPS = Model
    reader.number = functools.lru_cache(maxsize=None)(reader.number)
    mps = BASE / 'input/fhnw-binschedule0.mps.gz'
    assert hashlib.sha256(mps.read_bytes()).hexdigest() == (
        '5604233f73f5ff3b6d09e4e72f5763edef7c2c09eebf3610a674198b9709e0f2')
    m = reader.parse_mps(str(mps))
    assert len(m.col_order) == 319319
    assert len(m.row_order) == 58086
    print('Exact original MPS parsed: 319319 variables, 58085 constraints', flush=True)
    nz = {r: {c: a for c, a in m.coeff[r].items() if a} for r in m.row_order}
    assert len(nz[m.objective_row]) == 1 and m.rhs[m.objective_row] == 0
    objective, coefficient = next(iter(nz[m.objective_row].items()))
    assert coefficient == 1
    loads = []
    for r in m.row_order:
        if r == m.objective_row or objective not in nz[r]:
            continue
        assert m.row_type[r] in ('L', 'G')
        sign = 1 if m.row_type[r] == 'G' else -1
        scale = sign * nz[r][objective]
        assert scale > 0 and m.rhs[r] == 0
        load = {c: -sign * a / scale for c, a in nz[r].items() if c != objective}
        assert all(a >= 0 and m.lower[c] is not None and m.lower[c] >= 0
                   for c, a in load.items())
        loads.append(load)
    assert len(loads) == 6
    owners = defaultdict(list)
    for k, load in enumerate(loads):
        for c in load:
            owners[c].append(k)
    binary = {c for c in m.col_order if reader.is_binary(m, c)}
    items, item_of, partition_rows = [], {}, set()
    for r in m.row_order:
        terms = nz[r]
        if m.row_type[r] == 'E' and m.rhs[r] == 1 and terms and all(
                a == 1 and c in binary for c, a in terms.items()):
            partition_rows.add(r)
            for c in terms:
                assert c not in item_of
                item_of[c] = len(items)
            items.append(tuple(terms))
    assert len(items) == 939
    assignment = set(item_of)
    assert all(len(owners[c]) == 1 for c in assignment)
    bins, bin_of, bin_owner = [], {}, {}
    for r in m.row_order:
        terms = nz[r]
        if r in partition_rows or not terms or not set(terms) <= assignment:
            continue
        b = len(bins)
        bins.append(tuple(terms))
        ks = {tuple(owners[c]) for c in terms}
        assert len(ks) == 1
        k, = next(iter(ks))
        bin_owner[b] = k
        if k in (0, 5):
            assert m.row_type[r] == 'L' and m.rhs[r] == 1
            assert set(terms.values()) == {Fraction(1)}
        for c in terms:
            assert c not in bin_of
            bin_of[c] = b
    assert set(bin_of) == assignment and len(bins) == 572
    assert [sum(k == j for k in bin_owner.values()) for j in range(6)] == [254,16,16,16,16,254]
    forced = [i for i, options in enumerate(items) if all(owners[c][0] in (0, 5) for c in options)]
    assert len(forced) == 507
    for i in forced:
        assert len(items[i]) == 508
        assert {bin_of[c] for c in items[i]} == {b for b in bin_owner if bin_owner[b] in (0,5)}

    supports, memberships = {}, defaultdict(list)
    for r, terms in nz.items():
        if m.row_type[r] != 'G' or m.rhs[r] != 0:
            continue
        pos = [(c,a) for c,a in terms.items() if a > 0]
        neg = [(c,a) for c,a in terms.items() if a < 0]
        if len(pos) != 1 or not neg:
            continue
        q, a = pos[0]
        if q in assignment or q not in binary or a != len(neg) or not all(
                c in assignment and v == -1 for c,v in neg):
            continue
        assert q not in supports
        support = tuple(c for c,v in neg)
        assert len({bin_of[c] for c in support}) == 1
        supports[q] = support
        for c in support:
            memberships[c].append(q)
            if owners[c][0] in (0,5):
                assert owners[q] == owners[c]

    # x=1 (or a forced OR=1) implies left<=h<=right in paired rows.
    integer_times = m.integer - binary
    windows, timing = defaultdict(list), {}
    for ru, rl in zip(m.row_order, m.row_order[1:]):
        if (m.row_type[ru], m.row_type[rl], m.rhs[rl]) != ('L','G',0):
            continue
        ut, lt = nz[ru], nz[rl]
        ui = [(c,a) for c,a in ut.items() if c in integer_times]
        li = [(c,a) for c,a in lt.items() if c in integer_times]
        ub = [(c,a) for c,a in ut.items() if c not in integer_times]
        lb = [(c,a) for c,a in lt.items() if c not in integer_times]
        if len(ui) != 1 or len(li) != 1 or ui[0][1] != 1 or li[0][1] != 1 or len(ub)>1 or len(lb)>1:
            continue
        selectors = {c for c,a in ub+lb}
        if len(selectors) != 1:
            continue
        s, = selectors
        if s not in assignment and s not in supports:
            continue
        h = m.rhs[ru] - (ub[0][1] if ub else 0)
        if h != -(lb[0][1] if lb else 0):
            continue
        support = supports[s] if s in supports else (s,)
        bset = {bin_of[c] for c in support}
        assert len(bset) == 1
        b, = bset
        pair = (ui[0][0], li[0][0])
        assert b not in timing or timing[b] == pair
        timing[b] = pair
        for c in support:
            windows[c].append(h)
    intervals, fixed_cost = {}, Fraction(0)
    for i in forced:
        signatures = set()
        for c in items[i]:
            k = owners[c][0]
            assert windows[c]
            cost = loads[k][c] + sum(loads[k][q] for q in memberships[c])
            signatures.add((min(windows[c]), max(windows[c]), cost))
        assert len(signatures) == 1
        u,l,cost = next(iter(signatures))
        intervals[i] = (u,l)
        fixed_cost += cost
    assert fixed_cost == 31284

    # With d=0, a single original row already forces right(prev)<=left(next).
    timing_right = {pair[1]: b for b,pair in timing.items() if bin_owner[b] in (0,5)}
    timing_left = {pair[0]: b for b,pair in timing.items() if bin_owner[b] in (0,5)}
    assert len(timing_right) == len(timing_left) == 508
    edges = {0: {}, 5: {}}
    used_d = set()
    for r,terms in nz.items():
        if m.rhs[r] != 0 or len(terms) != 3 or m.row_type[r] not in ('L','G'):
            continue
        sign = 1 if m.row_type[r] == 'L' else -1
        plus = [c for c,a in terms.items() if sign*a == 1 and c in timing_right]
        minus = [c for c,a in terms.items() if sign*a == -1 and c in timing_left]
        ds = [c for c,a in terms.items() if c in binary and c not in assignment and sign*a < 0]
        if len(plus) != 1 or len(minus) != 1 or len(ds) != 1:
            continue
        a,b,d = timing_right[plus[0]],timing_left[minus[0]],ds[0]
        k = bin_owner[a]
        assert bin_owner[b] == k and a != b and owners[d] == [k] and loads[k][d] == 10
        assert a not in edges[k] and d not in used_d
        edges[k][a] = (b,d)
        used_d.add(d)
    assert used_d.isdisjoint(supports), 'Do not charge an OR again as a transition'
    for k in (0,5):
        assert len(edges[k]) == 253
        bs = {b for b in bin_owner if bin_owner[b] == k}
        targets = {b for b,d in edges[k].values()}
        assert len(targets) == 253 and len(bs-targets) == 1
        b, = bs-targets
        seen = {b}
        while b in edges[k]:
            b,d = edges[k][b]
            assert b not in seen
            seen.add(b)
        assert seen == bs
        assert all(c in m.integer and a.denominator == 1 and a.numerator % 2 == 0 for c,a in loads[k].items())

    cert = json.loads((BASE / 'certificates/interval-order-certificate.json').read_text())
    represented = set()
    for g in cert['groups']:
        for i in g['members']:
            assert i not in represented
            represented.add(i)
            assert intervals[i] == (Fraction(g['U']),Fraction(g['L']))
    assert represented == set(forced)
    assert Fraction(cert['fixed_base_cost']) == fixed_cost
    assert cert['occupied_segment_cap'] == 2 + (508-507) == 3
    assert Fraction(cert['difference_cost']) == 10
    print('Original-MPS mapping PASSED: 507 forced items; 508 slots; two 254-slot paths')
    print('All certificate intervals match every original option; fixed cost = 31284')
    print('506 distinct transition indicators cost 10; endpoint loads are even')
    print('With separately checked 128-group/62-cover certificate: LB = 15958')


if __name__ == '__main__':
    main()
