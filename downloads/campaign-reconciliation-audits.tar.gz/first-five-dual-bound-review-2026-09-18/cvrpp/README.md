# cvrpp-n16k8vrpi: first-five dual-bound review

**Conclusion: the original MPS has exact optimum 450.** The table's improvement
over the archived displayed COPT bound is correctly `450 - 282.375839 = 167.624161`.
The existing eight-route certificate reproduces identically, but it does not by
itself cover the original MPS's fleet size. This supplemental audit closes that gap.

## Proof-scope issue in the existing package

The instance README, line 7, describes partitioning customers into exactly eight
routes. Its script hard-codes `VEHICLES = 8` at line 21 and calls the partition DP
with that value at line 148. However, the compiled original MPS has **15 vehicle
slots**, including unused vehicles: 15 customers, 15 start-depot nodes, and 15
end-depot nodes. Thus the original claim needs to cover every possible nonempty
route count up to 15. The `k8` in the instance name does not impose an eight-route
restriction in this compiled model. The related archived family source also sets
`nbVehicles = N` (`instances/cvrpb-n45k5vrpi/sources/cvrp.mzn`, line 15).

This is a gap in the scope of the existing proof, not a counterexample to 450.

## Fresh checks

- The original compressed MPS is fully present; its SHA-256 matches the instance
  README: `d07ca11a223231562842334a053ea4d891c33d74c7245cccb4fcc0fab3216b86`.
- The archived script produces the same JSON certificate, including 164 feasible
  subsets, 996 partition states, and objective 450.
- A separate Held--Karp implementation computes every feasible route cost using
  exact integer rounding of Euclidean distances, then solves the subset partition
  problem for **every route count 1 through 15**. It does not import the archived
  DP or use its hard-coded coordinates.
- The existing family coefficient checker is applied directly to this original
  MPS and the distance/demand data derived from its paired VRP file. It verifies
  all 60 element gadgets, successor permutation, fixed depot connectors, demand
  and capacity propagation, distance coefficients, time propagation, and the
  equation `objective = sum(arrival_time[31..45])` (`p_lin_11167`). An extra guard
  verifies the 30 customer/start successor-copy aliases and the sole objective
  coefficient.
- The stored `verified450.sol` passes the exact Decimal indicator-aware checker:
  4,972 variables, 4,971 ordinary constraints, 6,719 indicators, objective exactly
  450, and zero row, indicator, bound, or integrality violations.

| Nonempty routes | Exact optimum |
|---:|---:|
| 1 through 7 | infeasible |
| 8 | 450 |
| 9 | 472 |
| 10 | 513 |
| 11 | 557 |
| 12 | 604 |
| 13 | 652 |
| 14 | 706 |
| 15 | 760 |

The coefficient checks establish the implication needed for a lower bound: every
feasible original-MPS point projects to capacity-feasible depot routes whose total
cost is no greater than its MPS objective. Positive demands exclude customer-only
cycles. The free-fleet route optimum is 450, so the MPS objective is at least 450.
The exact feasible MPS solution establishes the matching upper bound.

## Reproduce

Run from the repository root with Python 3.10 or later:

```sh
python docs/first-five-dual-bound-review-2026-09-18/cvrpp/reproduce.py
```

This writes only into this review directory. The successful audit used Python
3.14.6 and no optimization solver. The system `python3` here is Python 3.9, which
cannot run the existing certificate because it calls `int.bit_count()`.

`summary.json` contains the verdict and source hashes. `independent-free-fleet.json`
contains the independent DP results and integer distance matrix.
`mps-projection.json` contains coefficient-level evidence, and `exact-primal.json`
contains primal verification. Raw stdout/stderr from the three archived tools is
preserved alongside these files. The COPT value is checked against the archived
comparison JSON; this runner does not inspect the original COPT PDF.
