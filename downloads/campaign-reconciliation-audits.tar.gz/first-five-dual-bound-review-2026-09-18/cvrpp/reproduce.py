#!/usr/bin/env python3
"""Recheck the cvrpp claim against its original MPS, including every fleet size.

Requires Python >= 3.10 because the archived eight-route script uses int.bit_count.
All generated files stay alongside this script; archived inputs are read-only.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import math
import subprocess
import sys
from decimal import Decimal
from functools import lru_cache
from pathlib import Path


sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
INSTANCE = ROOT / "instances/cvrpp-n16k8vrpi"
FAMILY = ROOT / "instances/cvrpb-n45k5vrpi/experiments"


def dump(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def run(script, *args, stem):
    command = [sys.executable, str(script), *map(str, args)]
    result = subprocess.run(command, capture_output=True, text=True, cwd=ROOT)
    (OUT / f"{stem}.stdout.txt").write_text(result.stdout)
    (OUT / f"{stem}.stderr.txt").write_text(result.stderr)
    result.check_returncode()


def read_vrp():
    metadata, coordinates, demands = {}, {}, {}
    section = None
    depots = []
    for raw in (INSTANCE / "artifacts/P-n16-k8.vrp").read_text().splitlines():
        line = raw.strip()
        if not line or line == "EOF":
            continue
        if line.endswith("_SECTION"):
            section = line
        elif section is None:
            key, value = line.split(":", 1)
            metadata[key.strip()] = value.strip()
        elif section == "NODE_COORD_SECTION":
            i, x, y = map(int, line.split())
            coordinates[i] = (x, y)
        elif section == "DEMAND_SECTION":
            i, demand = map(int, line.split())
            demands[i] = demand
        else:
            depots.extend(int(x) for x in line.split() if x != "-1")
    n = int(metadata["DIMENSION"]) - 1
    assert metadata["EDGE_WEIGHT_TYPE"] == "EUC_2D" and depots == [1]
    assert set(coordinates) == set(demands) == set(range(1, n + 2))
    assert demands[1] == 0 and all(demands[i] > 0 for i in range(2, n + 2))
    distance = []
    for i in range(1, n + 2):
        row = []
        for j in range(1, n + 2):
            q = sum((x - y) ** 2 for x, y in zip(coordinates[i], coordinates[j]))
            floor = math.isqrt(q)
            # Exact nearest-integer Euclidean distance, without floating arithmetic.
            row.append(floor + int(4 * q >= (2 * floor + 1) ** 2))
        distance.append(row)
    return n, int(metadata["CAPACITY"]), [demands[i] for i in range(2, n + 2)], distance


def independent_dp(n, capacity, demand, distance):
    full = (1 << n) - 1
    subset_demand = [0] * (full + 1)
    for mask in range(1, full + 1):
        bit = mask & -mask
        subset_demand[mask] = subset_demand[mask ^ bit] + demand[bit.bit_length() - 1]

    @lru_cache(None)
    def path(mask, last):
        """Held--Karp: least depot-to-last path visiting exactly mask."""
        rest = mask ^ (1 << last)
        if rest == 0:
            return distance[0][last + 1]
        return min(path(rest, j) + distance[j + 1][last + 1]
                   for j in range(n) if rest & (1 << j))

    costs = {}
    for mask in range(1, full + 1):
        if subset_demand[mask] <= capacity:
            costs[mask] = min(path(mask, last) + distance[last + 1][0]
                              for last in range(n) if mask & (1 << last))
    by_customer = [[mask for mask in costs if mask & (1 << i)] for i in range(n)]

    @lru_cache(None)
    def partition(mask, routes):
        if mask == 0:
            return 0 if routes == 0 else math.inf
        if routes <= 0:
            return math.inf
        first = (mask & -mask).bit_length() - 1
        return min((costs[sub] + partition(mask ^ sub, routes - 1)
                    for sub in by_customer[first] if sub & mask == sub), default=math.inf)

    by_count = {k: partition(full, k) for k in range(1, n + 1)}
    result = {
        "method": "integer-distance Held-Karp route costs, exact subset partition for all fleet sizes",
        "customers": n,
        "maximum_nonempty_routes": n,
        "capacity": capacity,
        "total_demand": sum(demand),
        "minimum_routes_from_capacity": (sum(demand) + capacity - 1) // capacity,
        "feasible_route_subsets": len(costs),
        "exact_route_count_optima": {str(k): v if math.isfinite(v) else "infeasible"
                                     for k, v in by_count.items()},
        "free_fleet_optimum": min(by_count.values()),
        "integer_distance_matrix": distance,
    }
    dump("independent-free-fleet.json", result)
    return result


def main():
    assert sys.version_info >= (3, 10), "The archived DP requires Python >= 3.10"
    n, capacity, demands, distance = read_vrp()
    independent = independent_dp(n, capacity, demands, distance)
    assert independent["free_fleet_optimum"] == 450
    dzn = OUT / "data-derived-from-vrp.dzn"
    dzn.write_text(f"N={n};\nCapacity={capacity};\nDemand=[" + ",".join(map(str, demands))
                   + "];\nDistance=[|" + "|".join(",".join(map(str, row)) for row in distance) + "|];\n")
    mps = INSTANCE / "input/cvrpp-n16k8vrpi.mps.gz"
    solution = INSTANCE / "solutions/cvrpp-n16k8vrpi-verified450.sol"
    run(INSTANCE / "scripts/cvrpp_n16k8_exact_dp.py", "--vrp",
        INSTANCE / "artifacts/P-n16-k8.vrp", "--json", OUT / "archived-dp-replay.json", stem="archived-dp")
    archived_matches = json.loads((OUT / "archived-dp-replay.json").read_text()) == json.loads(
        (INSTANCE / "artifacts/cvrpp-n16k8-exact-certificate.json").read_text())
    assert archived_matches
    projection_script = FAMILY / "audit_compiled_mps_projection.py"
    run(projection_script, mps, dzn, "--json", OUT / "mps-projection.json", stem="mps-projection")
    run(FAMILY / "check_indicator_mps_solution.py", mps, solution,
        "--json", OUT / "exact-primal.json", stem="exact-primal")
    # Extra guard: successor copies used in the projection really equal the
    # corresponding original index variables for every customer/start node.
    spec = importlib.util.spec_from_file_location("cvrpp_projection", projection_script)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    model = module.parse_mps(mps)
    aliases, _ = module.build_alias_map(model)
    for node in range(1, 2 * n + 1):
        assert aliases[module.variable_name(node - 1)] == aliases[module.variable_name(15 * n + 1 + node)]
    assert {v: c for v, c in model.objective.items() if c} == {"objective": Decimal(1)}
    primal = json.loads((OUT / "exact-primal.json").read_text())
    assert primal["strictly_feasible"] and primal["objective_exact_decimal"] == "450"
    projection = json.loads((OUT / "mps-projection.json").read_text())
    assert projection["all_top_level_checks_passed"]
    baseline_path = ROOT / "docs/comparisons/copt-10h-vs-github-20260907/copt-10h-github-tracked-94.json"
    baseline = next(row for row in json.loads(baseline_path.read_text())["rows"]
                    if row["name"] == "cvrpp-n16k8vrpi")
    assert baseline["dual_bound"] == "282.375839" and baseline["time_seconds"] == "36000.0"
    files = [mps, solution, INSTANCE / "artifacts/P-n16-k8.vrp", projection_script,
             FAMILY / "check_indicator_mps_solution.py", INSTANCE / "scripts/cvrpp_n16k8_exact_dp.py",
             baseline_path]
    result = {
        "instance": "cvrpp-n16k8vrpi",
        "python": sys.version,
        "archived_certificate_reproduced_identically": archived_matches,
        "all_30_successor_copy_aliases_verified": True,
        "coefficient_level_mps_projection_passed": True,
        "exact_primal_passed": True,
        "global_lower_bound": 450,
        "global_upper_bound": 450,
        "copt_displayed_dual_bound": baseline["dual_bound"],
        "copt_baseline_verification_scope": "archived comparison JSON; original PDF not checked by this script",
        "delta_from_displayed_bound": str(Decimal(450) - Decimal(baseline["dual_bound"])),
        "proof_scope_issue": "Archived DP fixes 8 routes; original MPS has 15 vehicle slots. This replay checks every possible nonempty route count, 1..15.",
        "sha256": {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
    }
    dump("summary.json", result)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
