# assign1-10-4 audit, 2026-09-18

**Confirmed: exact global lower bound and optimum 422.** The table delta at its
displayed COPT precision is exactly `422 - 377.444386 = 44.555614`.

Both archived 422 witnesses passed the original certificate. The new independent
standard-library checker also parsed the complete archived MPS, checked all 582
constraints and all bounds/integrality exactly for both witnesses, and checked
all model assumptions supporting the counting lower bound. It reconstructs every
constraint from the supplied categories. An independent integer dynamic program
over ten groups reproduces the category lower bounds `76 + 192 + 64 + 90 = 422`.
No optimizer was run.

The independent check confirms that the objective is `min sum y` with no
constant, all 520 assignment variables are binary, and each of the 52 continuous
overlap variables has bounds `[0,20]`. The proof uses nonnegativity; the upper
bounds only strengthen the model. Assignment and group-size equalities hold as
claimed, and every load row equals the stated categorical formula.

The MPS is a real gzip file, not a Git LFS pointer. Its SHA-256 is
`d85ac9d663bb7f6a26d98d52988b5de59bf8038c8c89789b7a3bedf546160422`,
matching both the frozen publication manifest and the frozen input copy.
This audit did not retrieve another model copy from the MIPLIB server.

One checker-hardening issue is present: the original certificate's
`extract_weights` verifies the load, assignment, and quota rows but does not
assert the objective coefficients/constant or binary domains used in the global
proof. Its primal check is not a substitute for these universal assumptions.
The proof report's statement that the verifier directly checks all these facts
is consequently too broad. The independent audit explicitly checks them and
they do hold in the archived input, so this does not invalidate the 422 claim.

Evidence:

- `replay-gurobi.log` and `replay-copt.log`: successful original certificate runs.
- `independent_check.py`: independent parser, exact original-model checks, and
  integer-DP lower bound.
- `independent_check.json`: recorded successful independent result and hashes.

Reproduce from the repository root:

```sh
python3 docs/first-five-dual-bound-review-2026-09-18/assign1-10-4/independent_check.py
```
