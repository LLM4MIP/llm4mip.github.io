#!/usr/bin/env python3
"""Read-only exact audit, independently parsed from the archived MPS.

Run from any directory; stdout is JSON. Does not call an optimizer or import the
original certificate implementation. Only the Python standard library is used.
"""
from collections import Counter, defaultdict
from decimal import Decimal
from fractions import Fraction
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
INSTANCE = ROOT / "instances/assign1-10-4"
MPS = INSTANCE / "input/assign1-10-4.mps.gz"
raw = MPS.read_bytes()
source = gzip.decompress(raw).decode("latin1")
rows, matrix, rhs = {}, defaultdict(dict), {}
variables, integers = set(), set()
lower, upper = {}, {}
section, integer_mode = None, False
rhs_names, bound_names = set(), set()
headers = []
for line in source.splitlines():
    tokens = line.split()
    if not tokens or tokens[0].startswith("*"):
        continue
    if not line[0].isspace():
        section = tokens[0]
        assert section in {"NAME", "ROWS", "COLUMNS", "RHS", "BOUNDS", "ENDATA"}, line
        headers.append(section)
        continue
    if section == "ROWS":
        kind, name = tokens
        assert name not in rows and kind in {"N", "E", "G", "L"}
        rows[name] = kind
    elif section == "COLUMNS":
        if tokens[1] == "'MARKER'":
            assert tokens[2] in {"'INTORG'", "'INTEND'"}
            integer_mode = tokens[2] == "'INTORG'"
            continue
        variable = tokens[0]
        assert len(tokens) in {3, 5}
        variables.add(variable)
        if integer_mode:
            integers.add(variable)
        for row, coefficient in zip(tokens[1::2], tokens[2::2]):
            assert row in rows
            value = Fraction(coefficient)
            assert value.denominator == 1
            matrix[row][variable] = matrix[row].get(variable, 0) + int(value)
    elif section == "RHS":
        assert len(tokens) in {3, 5}
        rhs_names.add(tokens[0])
        for row, value in zip(tokens[1::2], tokens[2::2]):
            assert row in rows and row not in rhs
            rhs[row] = Fraction(value)
    elif section == "BOUNDS":
        kind, bound_set, variable = tokens[:3]
        assert variable in variables
        bound_names.add(bound_set)
        value = Fraction(tokens[3]) if len(tokens) == 4 else 0
        if kind == "UP":
            assert variable not in upper
            upper[variable] = value
        elif kind == "LO":
            assert variable not in lower
            lower[variable] = value
        else:
            raise AssertionError((kind, line))
    else:
        raise AssertionError((section, line))

assert headers == ["NAME", "ROWS", "COLUMNS", "RHS", "BOUNDS", "ENDATA"]
assert len(rhs_names) == len(bound_names) == 1
y = [f"C{i+1:04d}" for i in range(52)]
x = [[f"C{53+10*i+g:04d}" for g in range(10)] for i in range(52)]
xs = {v for row in x for v in row}
assert variables == set(y) | xs
assert integers == xs
assert all(lower.get(v, 0) == 0 for v in variables)
assert all(upper.get(v) == 1 for v in xs)
assert all(upper.get(v) == 20 for v in y)
objectives = [r for r, kind in rows.items() if kind == "N"]
assert len(objectives) == 1
objective = objectives[0]
assert matrix[objective] == {v: 1 for v in y}
assert rhs.get(objective, 0) == 0
assert {r for r, kind in rows.items() if kind != "N"} == {f"R{i:04d}" for i in range(1, 583)}

categories = json.loads((INSTANCE / "artifacts/assign1-10-4_categories.json").read_text())["item_categories"]
assert len(categories) == 52 and all(len(c) == 4 for c in categories)
weights = [[int(i == j) + sum(a == b for a, b in zip(categories[i], categories[j])) for j in range(52)] for i in range(52)]
for i in range(52):
    for g in range(10):
        row = f"R{1+10*i+g:04d}"
        expected = {y[i]: 1, **{x[j][g]: -weights[i][j] for j in range(52) if weights[i][j]}}
        assert rows[row] == "G" and rhs[row] == -5
        assert {v: c for v, c in matrix[row].items() if c} == expected
    row = f"R{521+i:04d}"
    assert rows[row] == "E" and rhs[row] == 1 and matrix[row] == {v: 1 for v in x[i]}
for g, quota in enumerate([5]*8 + [6]*2):
    row = f"R{573+g:04d}"
    assert rows[row] == "E" and rhs[row] == quota and matrix[row] == {x[i][g]: 1 for i in range(52)}

# Exact integer DP over ten groups independently verifies each type minimum.
dp = [0] + [None]*52
for _ in range(10):
    dp = [min(dp[n-k] + k*(k-1) for k in range(n+1) if dp[n-k] is not None) for n in range(53)]
frequencies = [sorted(Counter(c[k] for c in categories).values(), reverse=True) for k in range(4)]
bounds = [sum(dp[n] for n in counts) for counts in frequencies]
assert bounds == [76, 192, 64, 90]
solutions = {}
for filename in ["assign1-10-4_gurobi_422.sol", "assign1-10-4_copt_422.sol"]:
    path = INSTANCE / "solutions" / filename
    values = {}
    for line in path.read_text().splitlines():
        fields = line.split()
        if not fields or fields[0].startswith("#"):
            continue
        assert len(fields) == 2 and fields[0] not in values
        values[fields[0]] = Fraction(fields[1])
    assert set(values) == variables
    for v, value in values.items():
        assert value >= lower.get(v, 0)
        assert v not in upper or value <= upper[v]
        assert v not in integers or value.denominator == 1
    for row, kind in rows.items():
        if kind == "N":
            continue
        activity = sum(c*values[v] for v, c in matrix[row].items())
        target = rhs.get(row, 0)
        assert {"E": activity == target, "G": activity >= target, "L": activity <= target}[kind], row
    obj = sum(c*values[v] for v, c in matrix[objective].items())
    assert obj == sum(bounds) == 422
    solutions[filename] = {"objective": str(obj), "all_582_rows_exactly_feasible": True, "all_bounds_and_integrality_exact": True, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}

relative = str(MPS.relative_to(ROOT))
record = json.loads((ROOT / "studies/ten-instance-2026-09-06/publication-manifest.json").read_text())["files"][relative]
sha = hashlib.sha256(raw).hexdigest()
assert record["bytes"] == len(raw) and record["sha256"] == sha
snapshot = ROOT / "studies/ten-instance-2026-09-06/assign1-10-4/input/assign1-10-4.mps.gz"
assert snapshot.read_bytes() == raw
print(json.dumps({
    "instance": "assign1-10-4", "result": "PASS", "exact_global_lower_bound": sum(bounds),
    "objective_verified": "min sum of 52 nonnegative continuous y variables; no objective constant",
    "all_520_assignment_variables_binary": True,
    "full_model_matches_categorical_reconstruction": True,
    "variables": len(variables), "constraints": len(rows)-1,
    "category_frequencies": frequencies, "category_lower_bounds_by_independent_integer_dp": bounds,
    "primal_solutions": solutions, "input_sha256": sha,
    "input_is_real_gzip_not_lfs_pointer": True,
    "input_matches_publication_manifest_and_frozen_snapshot": True,
    "copt_10h_dual_as_recorded_in_readme": "377.444386",
    "delta_exact_at_display_precision": str(Decimal(sum(bounds))-Decimal("377.444386")),
    "external_miplib_server_not_retrieved": True,
}, indent=2))
