#!/usr/bin/env python3
"""Check the first five README rows against the preserved COPT PDF extraction."""
import hashlib
import json
import re
from decimal import Decimal
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PDF = ROOT / 'docs/dual-bound-audit-2026-09-14/sources/frozen-copt-table.pdf'
PDF_SHA = 'd34798161c0535ba22595ffc1cc8c1dfb40a86d5b21963a542297330db65589f'
EXPECTED = [('assign1-10-4','422'), ('cvrpp-n16k8vrpi','450'),
            ('dfn-bwin-DBE','73623.79'), ('fhnw-binschedule2','2428'),
            ('fhnw-binschedule0','15958')]


def main():
    assert hashlib.sha256(PDF.read_bytes()).hexdigest() == PDF_SHA
    extracted = (HERE / 'evidence/copt-table.txt').read_text()
    baseline = {}
    for line in extracted.splitlines():
        cells = line.split('|')
        if len(cells) != 4 or not cells[0].strip().isdigit():
            continue
        metadata, values = cells[1].split(), cells[2].split()
        baseline[cells[3].strip()] = (metadata[0], values[1])
    assert len(baseline) == 217
    assert 'Threads=8' in extracted and 'RelGap=0' in extracted
    table = (ROOT / 'README.md').read_text().split('### Dual-bound improvements over COPT 10h',1)[1]
    rows = [line for line in table.splitlines() if line.startswith('| [`')][:5]
    snapshot = json.loads((ROOT / 'docs/comparisons/copt-10h-vs-github-20260907/copt-10h-github-tracked-94.json').read_text())
    archived = {row['name']: row for row in snapshot['rows']}
    result = []
    for row,(name,bound) in zip(rows,EXPECTED):
        cells = [c.strip() for c in row.split('|')[1:-1]]
        assert re.search(r'\[`([^`]+)`\]',cells[0]).group(1) == name
        runtime, dual = baseline[name]
        assert Decimal(runtime) == 36000
        assert cells[1] == dual == archived[name]['dual_bound']
        assert Decimal(cells[2]) == Decimal(bound)
        delta = Decimal(bound)-Decimal(dual)
        assert Decimal(cells[3]) == delta and delta > 0 and cells[4] == 'E'
        result.append({'instance':name, 'copt_displayed_dual':dual,
                       'rechecked_exact_lower_bound':bound, 'delta':str(delta),
                       'copt_runtime_seconds':runtime, 'readme_matches':True})
    assert len(result) == 5
    output = {'source_pdf':str(PDF.relative_to(ROOT)), 'source_pdf_sha256':PDF_SHA,
              'extraction_method':'Ghostscript txtwrite; table also visually inspected',
              'scope':'Historical displayed COPT bounds; no new COPT benchmark run',
              'rows':result}
    (HERE / 'comparison-recheck.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(output,indent=2))


if __name__ == '__main__':
    main()
