#  20 is a controllable, auditable structural research experiment of a MIPLIB Open instance

**Experiment ID:** `controlled_miplib20_20260911_1451`
**Public baseline and model freeze date:** 2026 -09 -11
**Final draft organizing time:** 2026 -09 -12
**local evidence root directory:** `D:\sufe\code\AI+MIP\controlled_miplib20_20260911_1451`
**Distant evidence root directory:** `/data1/wyc/controlled_miplib20_20260911_1451`

##  1. Execute the summary

The experiment was conducted in five batches of pre-fixed batches, with the exact name given to 20 [MIPLIB ](https://miplib.zib.de/) open instance completes structural analysis, public background retrieval, original model baseline, structural drive tests, open-space solution verification, global environment transfer audit and evidence storage].

Completion of the hypothesis hypothesis hypothesis is that the instance has reached a time threshold, stops additional experiments and completes proof closeout; it is not the same as if the MIP had been solved globally.

-  The 20 / 20 instance completes the experiment and audit closed loop;
-  The 20 / 20 instance keeps the global lower bound evidence that is valid for the original problem;
-  The 4 instance obtained a better public record of the MIPLIB than the MIPLIB that was frozen in this experiment.
-  An instance of 2 receives an exact globally optimal certificate that is portable;
-  The remainder of the 18 instance still maintains a positive global gap, not claiming optimal;
-  Finally, `summary.csv` was approved for the fixed sequence 20 line, 16 column, JSON→CSV decimal word form for zero loss audit;
-  The instance process for the entire experimental root directory on euler4 is ultimately 0, with the core delivering the local/remote file SHA-256 consistent.

The four new strict incumbents are:

| Instance | Freezing public baselines | New strict original - MPS primal | Improvements (minimized) |
|---|---:|---:|---:|
| `graphdraw-grafo2` | 68613.5 | 68595.5 | 18 |
| `r4l4-02-tree-bounds-50` | 499132179 | 499097063 | 35,116 |
| `ns1856153` | 34.16346179965939 | 34.01697312588408 | 0.14648867377531 |
| `neos-5221106-oparau` | 52.66999999999962 | 52.07 | 0.59999999999962 |

"New" refers only to the public records retrieved and frozen for this experiment on 2026-09-11. The experiment does not claim official MIPLIB acceptance or that these are the first historical discoveries.

Two exact closure instances are:

| Instance |  exact primal |  exact global dual | Form of proof |
|---|---:|---:|---|
|  `ns1456591`  |  988.14128344  |  988.14128344  | Complete route, business, Held Carp/ group division DP, Complete main problem with dual, original MPS lift |
|  `neos-3682128-sandon`  |  34666770  |  34666770  | Complete machine configuration enumeration  exact rational dual  strict original MPS lift  cross host standard library verification |

##  2. Scope and control of experiments

###  2.1 fixed batch

1. `graphdraw-grafo2`、`polygonpack4-10`、`scpm1`、`ger50-17-trans-dfn-3t`
2. `eva1aprime6x6opt`、`cmflsp60-36-2-6`、`r4l4-02-tree-bounds-50`、`sct1`
3. `shipsched`、`rocII-8-11`、`ns1856153`、`dc1l`
4. `neos-5221106-oparau`、`zeil`、`cdma`、`ns1456591`
5. `seqsolve1`、`stockholm`、`supportcase22`、`neos-3682128-sandon`

Strict Batch Barrier: The last batch of the first four instances all stops, save the evidence and start after passing the block. Each batch of up to four instances goes in parallel, without transferring unused time to other instances.

###  2.2 time rule

- Batch 1 followed the initial rule of 40–120 minutes of effective research per instance.
-  After further revision by the user, Batch 2 5 uses the minute valid study rules for each instance 90 150.
-  `elapsed_minutes` represents the exclusion of the active research time after pure waiting; it includes structural analysis, source research, model construction, solve, supervision, result explanation, verification and reporting work.
-  `solver_minutes` is a verifiable solver/search workflow in a retained log that can overlap with active research and cannot be combined with `elapsed_minutes` as explanation for wall clock time.

The cumulative instance effective study is **1729.5301 minutes (28.8255 hours)**; the recorded solver work is **1010.2245 minutes (16.8371 hours)**.

| Batch | Accumulated active minutes | Active scope | Accumulated Solver Minutes |  Acceptance gate |
|---:|---:|---:|---:|---|
| 1 | 195.7145 | 42.071–58.033 | 104.9060 | 40–120，PASS |
| 2 | 406.3483 | 91.343–117.861 | 280.3282 | 90–150，PASS |
| 3 | 403.9161 | 90.036–106.696 | 304.0170 | 90–150，PASS |
| 4 | 362.7722 | 90.097–92.239 | 190.0737 | 90–150，PASS |
| 5 | 360.7789 | 90.114–90.260 | 130.8996 | 90–150，PASS |

###  2.3 computing environment

|  Project | Freezing value |
|---|---|
| Manifest mainly solve host | euler4 , user `wyc` , data drive `/data1` |
| Operating system |  Ubuntu 20.04.6 LTS, Linux 5.4.0-216-generic, x86_64  |
|  CPU  | 2 × 32 physical core, 128 logic CPU, Intel Xeon Platinum 8358 @ 2.60 GHz |
|  Memory |  540,659,212,288 bytes  |
|  Gurobi  | 13.0.1, NODE file license |
| Python | `/home/wyc/miniconda3/envs/gen-milp-instance/bin/python` |
| Each instance thread |  `Threads=8`  |
| Each instance has soft memory limitations |  `SoftMemLimit=32` GiB  |
| Random seeds |  `Seed=20260911`  |
| numerical baseline | `FeasibilityTol=IntFeasTol=OptimalityTol=1e-6`, more strict verification by instance |
| Codex | `gpt-5.6-sol`，reasoning=`ultra` |

Most instances ran in the euler4/Gurobi 13.0.1 environment above. Two documented exceptions are `zeil` and `cdma`: their final experiments ran locally on host `huangyicheng`, with Windows 11 build 26200, Python 3.13.5 and Gurobi 13.0.2 build `v13.0.2rc1`. Both retained `Threads=8`, `SoftMemLimit=32` GiB as recorded, and `Seed=20260911`, with version evidence in their environment/ledger files. These differences are not silently merged into euler4 results.

The original `.mps.gz` was derived from MIPLIB WebData, which calculated SHA-256 by instance and set it to read-only; any derivative model used a new file that did not cover the original. Optimized evidence for this experiment was used by Gurobi; the COPT output was not incorporated into the final boundary or proof chain of the 20 instance.

##  3. Evidence and numerical range

###  3.1 results field

-  `official_primal`: Freeze the value recorded in a page, solution table or public solution file; save the conflict text if the source conflict is present.
- `best_verified_primal` (denoted `P*` below) is the original-space candidate selected in `summary.csv` and rechecked at that instance's stated tolerance. It does not mean a uniform zero-tolerance strict primal across all 20 instances.
-  `best_valid_dual` (abbreviated `D`): Global lower bound valid for an unchanged original problem. It may be the original model solver boundary, the computational boundary for equivalent/relaxing directional audit, or the portable exact certificate.
-  `final_gap = |P* - D| / max(|P*|, 1e-10)`. The negative objective instance of a gap greater than 1 is normal.
-  `official_dual` in the frozen 20 line is `null`/CSV blank, indicating that the authority page has no official global dual value available, and does not represent 0.

###  3.2 certified rating

From weak to strong:

1.  public element data or solver observation;
2.  Restricted neighborhood, fixed mode, or local search results;
3.  A global computational framework that is effective for the original problem;
4.  The original - MPS primal or exact rational boundary of independent verification;
5.  Complete proof, equivalent exact primal/dual, globally optimal certificate composed of original space mapping and independent replay.

The `OPTIMAL`, infeasible or cutoff of the restricted model is valid only within its declared domain; it is not elevated to global conclusions unless mapped, loosened or equivalent through separate audits.

##  4. The final result of twenty instances

In the table, a dagger indicates that `P*` uses an instance-specific tolerance tier and must not be interpreted as a uniformly strict zero-tolerance value. Refer to `summary.csv` for the exact decimal representations.

|  B  | Instance |  `P*`  |  `D`  | Relative gap | Mathematical conclusions |
|---:|---|---:|---:|---:|---|
|  1  |  `graphdraw-grafo2`  |  68595.5  |  36159.784210526326  |  47.2855%  | New strict incumbent, open |
|  1  |  `polygonpack4-10`  |  -53594508.70758325†  |  -93676450.23559369  |  74.7874%  | tolerance layer P, open |
|  1  |  `scpm1`  |  537  |  414  |  22.9050%  | Exact rational lower bound, open |
|  1  |  `ger50-17-trans-dfn-3t`  |  3969.433399999999  |  3929.073502371996  |  1.0168%  |  Open |
|  2  |  `eva1aprime6x6opt`  |  -18.101002981361386†  |  -495.3702539490355  |  2636.7006%  | tolerance layer P, open |
|  2  |  `cmflsp60-36-2-6`  |  73891244.22159792†  |  71322258.264677  |  3.4767%  | No Strict Improvement, Open |
|  2  |  `r4l4-02-tree-bounds-50`  |  499097063  |  479452299.6156765  |  3.9361%  | New strict incumbent, open |
|  2  |  `sct1`  |  -187.52765083903063†  |  -201.483830038592  |  7.4422%  | tolerance layer P, open |
|  3  |  `shipsched`  |  111919.8337342348†  |  79152.37747691161  |  29.2776%  | tolerance layer P, open |
|  3  |  `rocII-8-11`  |  -8.739845027008393†  |  -11.854388559168083  |  35.6361%  | tolerance layer P, open |
|  3  |  `ns1856153`  |  34.01697312588408  |  28.900000000000006  |  15.0424%  | New strict incumbent, open |
|  3  |  `dc1l`  |  1758647.6801  |  1748341.9142596035  |  0.5860%  |  Open |
|  4  |  `neos-5221106-oparau`  |  52.07  |  42.54  |  18.3023%  | New strict incumbent, open |
|  4  |  `zeil`  |  1081.3585  |  833.8312541332446  |  22.8904%  |  Open |
|  4  |  `cdma`  |  -24778478399999989.93240  |  -63828901980830619.66410742284140406012091284602512785  |  157.5982%  |  Open |
|  4  |  `ns1456591`  |  988.14128344  |  988.14128344  |  0  |  **exact globally optimal** |
|  5  |  `seqsolve1`  |  4277  |  4269  |  0.1870%  |  Open |
|  5  |  `stockholm`  |  122  |  104  |  14.7541%  |  Open |
|  5  |  `supportcase22`  |  110  |  6.0  |  94.5455%  |  Open |
|  5  |  `neos-3682128-sandon`  |  34666770  |  34666770  |  0  |  **exact globally optimal** |

##  5. By instance conclusions, methods and fail route

### Batch 1

#### `graphdraw-grafo2`

The dimensional structure of objective graphs and the separation of fractions support the fractional design of LNS. The experiment generated and independently verified the 68595.5 on the original MPS, relatively freezing the public incumbent to improve the 18; the unmodified original model gives the global lower bound 36159.784210526326. The broader fractional neighborhood did not continue to improve over time, so the results remain open. See `instances/graphdraw-grafo2/instance_report.md`.

#### `polygonpack4-10`

The main approach uses projection-equivalent canonical-slice linking and core local branching. Public primal -53594508.70758325 is retained; it passes `1e-6` but fails `1e-7`, with maximum original-row violation 9.569714620738523e-7, so it is not called a strict zero-tolerance point. The equivalent model yields transferable computational global lower bound -93676450.23559369. Pairwise conflict search found no valid conflicts; radius-2 search timed out without primal progress. See `instances/polygonpack4-10/instance_report.md`.

#### `scpm1`

Public sources conflict between 540 and solution-table ID8 at 537; the experiment retains this discrepancy and strictly replays 537. An exact rational dual certificate for the original LP gives 413.781670848; safe rounding on the integer objective lattice yields global lower bound 414. Deterministic cost-1 RWLS did not improve 537. See `instances/scpm1/instance_report.md`.

#### `ger50-17-trans-dfn-3t`

The rounded logical cutset of 12 articles independently derived and audited was used for the same budget reinforcement; ultimately primal basically kept the public 3969.4334, the global computing community upgraded to 3929.073502371996. The cutting experiment was positive, but the gap remained at 1.0168 %, continuing to do unstructured base see sweeping was stopped. Details `instances/ger50-17-trans-dfn-3t/final_report.md`.

### Batch 2

#### `eva1aprime6x6opt`

Recovered material-choice, redundant-indicator, conflict-clique and symmetry structures guided fixed-pattern recourse, symmetric exact/local neighborhoods and cardinality shells. Page/solution ID6 at -18.10146978964996 fails the frozen original-MPS audit at `1e-6`; ID5 at -18.100995280293 is the strict reference. CSV `P*=-18.101002981361386` is a tolerance-indexed `1e-6` candidate; other results are a `1e-9` candidate -18.100995282203325 and a more robust `1e-10` fixed-pattern value -18.10099528029322. No new strict integer topology was found. The computational bound from the audited equivalent indicator model is -495.3702539490355. See `instances/eva1aprime6x6opt/final_report.md`.

#### `cmflsp60-36-2-6`

Testing the exact fixed mode LP recourse, Y/Z neighborhood and confirmation running of the original model without modification. CSV candidate 73891244.22159792 freezes the `1e-6` threshold but fails under `1e-7`; strict fixed mode recourse is 73891245.64760002 and therefore does not claim strict primal improvement. The original model running gives the global lower bound 71322258.264677; the entire family 1 is still undecided. See `instances/cmflsp60-36-2-6/final_report.md`.

#### `r4l4-02-tree-bounds-50`

The graph/tree structure yields five independently verified BFS fundamental-cycle inequalities. Structured solving produced the strictly verified original-MPS primal value 499097063, improving on the frozen public value by 35,116; the valid global lower bound is 479452299.6156765. The strengthened experiment still stopped at TIME_LIMIT and did not prove optimality. See `instances/r4l4-02-tree-bounds-50/final_report.md`.

#### `sct1`

Tested exact neighborhoods with external variables fixed, local branching, exact rational LP certificates and a final global original-model control. The CSV retains the public tolerance-level `P*=-187.52765083903063`; the strict repaired value -187.52764944960396 is slightly worse, so there is no primal improvement. The computational original-MPS lower bound is -201.483830038592; a weaker portable exact LP certificate gives -218.139003128115. See `instances/sct1/final_report.md`.

### Batch 3

#### `shipsched`

The precedence/scheduling structure guided fixed-pattern recourse, literature-inspired neighborhoods and 3,892 independently verified directed-cycle inequalities. The CSV value 111919.8337342348 is a transferred candidate at `1e-6` tolerance; the stricter original-MPS witness is 111920. A 2400-second cutting run raised the transferable global lower bound to 79152.37747691161, without a strict primal improvement. See `instances/shipsched/final_report.md`.

#### `rocII-8-11`

The main route is public integer mode repair, time structure limitation and ultimately unmodified original model control. CSV's `1e-6` candidate is -8.739845027008393; fixed mode recourse is obtained by `1e-9` witness -8.739844934961763. All structural searches do not change the integer topology; the original model global lower bound is -11.854388559168083. See `instances/rocII-8-11/final_report.md`.

#### `ns1856153`

An exact connectivity projection and transpose/tree optimal-value equivalence were established, and 1,568 big-M rows were tightened under an incumbent cutoff. The strict primal 34.01697312588408 improves on the frozen public record by 0.14648867377531; the computational global lower bound is 28.900000000000006. The final strengthening route did not exceed the earlier structural route, and the instance remains open. See `instances/ns1856153/final_report.md`.

#### `dc1l`

Complete the structurer, exact mapping and valid certificate chains, and audit multiple restricted neighborhoods and matched original controls. Public primal 1758647.6801 is retained; the strongest calculation of the lower bound of the original model without modification is 1748341.9142596035, with a weaker but portable exact lower bound 1744591.69295. The quotient model acceleration hypothesis has not been established and the restricted neighborhood boundary has not been upgraded to the global boundary. See `instances/dc1l/final_report.md`.

### Batch 4

#### `neos-5221106-oparau`

Routing/mode-4 structure yielded an incumbent-capped exact projection and route-exchange, two-for-one and assignment-radius neighborhoods. Strict primal 52.07 improves the public 52.67 by 0.60. The mapping-audited computational global lower bound is 42.54, with a portable exact Lagrangian lower bound of 36.24. The initial unconditional MTZ route was falsified by strict checks; its 29.84 value was quarantined and never used as a final bound. See `instances/neos-5221106-oparau/final_report.md`.

#### `zeil`

Exact continuous recourse for the timetable pattern was combined with a `w` projection and support cuts. The strict primal value is 1081.3585; the audited projection gives a computational global lower bound of 833.8312541332446, alongside an exact rational projected-LP certificate of 771.534476759. The eight-prefix cutoff closed only a restricted domain and was not incorrectly promoted to a global conclusion. See `instances/zeil/final_report.md`.

#### `cdma`

The public near-integer point failed the strict policy. Fixed-pattern recourse in original space gives the strict primal -24778478399999989.93240. Adding 3,600 independently verified OR-hull inequalities to the original LP yields a finite Decimal bounded-box Lagrangian certificate with global lower bound -63828901980830619.66410742284140406012091284602512785. This bound is portable but the gap remains large; local structural contradictions did not close the problem. See `instances/cdma/final_report.md`.

#### `ns1456591`

The numerically better public ID3 failed the strict `1e-9` policy; the strict primal is 988.14128344. The complete route quotient yields 387 complete route columns. Held-Karp/set-partitioning DP, an exact rational dual of the complete master and a full-coefficient crosswalk give the same lower bound. The original witness passes strict checks on 8,399 variables and 1,997 rows, establishing the exact original-problem optimum 988.14128344. See `instances/ns1456591/final_report.md`.

### Batch 5

#### `seqsolve1`

The original MPS has 207,665 variables, 242,243 rows and 1,027,681 nonzeros. Its structural core comprises person/site/day blocks, site coupling and shortage/excess objectives. The public witness 4277 passes zero-tolerance checks over all 1,027,681 integer matrix entries. A single 300-second baseline on the untouched original model gives global lower bound 4269. Independently audited activation-hull, half-rounding and Hall-projection strengthenings do not exceed 4269; the final gap is 8/4277. See `instances/seqsolve1/final_report.md`.

#### `stockholm`

The recovered minimum-toll-design structure has 416 nodes, 962 arcs and 45 OD pairs. Public solution 4, corresponding to the displayed 120.9999950202855, violates binarity at `1e-6`; public solution 3 and two independently constructed points pass the original MPS at strict primal 122. The original-model baseline lower bound is 104. Two-stage monotone combinatorial Benders generated 815 valid cuts, each replayed on the original model, but did not improve 104 or exclude objective 121. See `instances/stockholm/final_report.md`.

#### `supportcase22`

All 7,129 variables are binary. The 640 equalities define exactly substitutable variable aliases; 145 support-indicator groups require retaining five essential capacity rows. The strict public primal 110 passes zero-tolerance replay. Starting from all DEC master rows and adding 96 violated original rows over 20 rounds yields a 27,657-row subset relaxation with raw bound 5.999999999998181. Safely rounding down to 5.999 and applying the `(1/5)Z` objective lattice established by a complete objective audit gives the original-problem global lower bound 6.0. This relaxation point violates five original rows and was never treated as a primal solution. See `instances/supportcase22/final_report.md`.

#### `neos-3682128-sandon`

The original MPS has 7,880 integer variables, 14,920 constraints and 50,438 constraint nonzeros. Its semantic core consists of five ordered jobs, four machines, three operations and 120 time slots. The point corresponding to the displayed 34666767.4743958 fails strict integrality/row checks; the strict reference is 34666770. The experiment enumerates all admissible type sequences and 82,794 machine-configuration columns, checks an exact rational dual column by column, and lifts the configuration solution to every original variable. Standard-library checkers on Windows Python 3.13.5 and euler4 Python 3.8.10 both return primal=dual=34666770; a single-bit negative control correctly rejects a corrupted witness. The global optimum is therefore 34666770. See `instances/neos-3682128-sandon/final_report.md`.

##  6. Tolerance Differences from Public Sources

The following situation explains why `P*` cannot be called a strict primal string in all instances:

| Instance | CSV `P*` and related public values | More strict verification or conclusions |
|---|---|---|
|  `polygonpack4-10`  | Public `1e-6` Candidate -53594508.70758325 | Failed in `1e-7`; no new strict primal |
|  `eva1aprime6x6opt`  | `1e-6` Candidate -18.101002981361386 | `1e-9` is -18.100995282203325; stable `1e-10` is -18.10099528029322; no new strict topology |
|  `cmflsp60-36-2-6`  | `1e-6` Candidate 73891244.22159792 | Failure of `1e-7`; strict recourse 73891245.64760002; not including strict improvement |
|  `sct1`  | Public tolerance level -187.52765083903063 | strict Repair -187.52764944960396, numerical slightly poor |
|  `shipsched`  | Public `1e-6` Candidate 111919.8337342348 |  strict witness 111920 |
|  `rocII-8-11`  | `1e-6` Candidate -8.739845027008393 |  `1e-9` witness -8.739844934961763  |
|  `ns1456591`  | Page ID3 numerical Optimized | ID3 strict Failure; Primal/dual certificate closure of 988.14128344 |
|  `stockholm`  | Page 120.9999950202855 | The corresponding points in `1e-6` violate the duality; strict primal 122 |
|  `neos-3682128-sandon`  | Page 34666767.4743958 | Conversation point strict failed; 34666770 obtained exact proof |

This distinction avoids mistakes in the display, default solver tolerance, or unverified solution header as mathematical proof.

##  7. Discovering the cross-instance method

1.  **finite architects can close the original problem, but the completeness must be proven separately.** `ns1456591` and Sandon's successes come not only from a small model set, but also from a complete set of columns, exact primal/dual, original model crosswalk and independent replay.
2.  Whether **computation type reinforcement is useful depends on the proof trajectory rather than just looking at the root LP. The activation hull of** `seqsolve1` increases the LP, but with the budget MIP bound rather than without modifying the baseline; the `stockholm` 815 benders cut is valid and does not exceed the original model lower bound 104.
3.  **security relaxation combined with objective lattice can turn the numerical boundary into a strict global boundary.** `supportcase22`'s 5.999 → 6.0 is the result of the removal of the constraint direction, row by row identity audit and `(1/5)Z` objective lattice.
4.  **strict raw space verification is often more important than new integer searches.** Multiple pages/solver points appear to be better under the default tolerance, but disappear in more strict replay; therefore, all contributions must state both tolerance and provenance.
5.  **limited neighborhood negative results are still valuable, but cannot be globalized.** multiple radius, fixed-pattern, prefix and union-core test verification shows no improvement in specific domains to help stop low-value routes, but no proof globally optimal.
6.  The **failed route must remain.** Oparau's unconditional MTZ; Sandon's wrong time direction DP; Supportcase22's first name parse errors are retained; explanation and exclusion beyond the final conclusion.

##  8. audit, restoration and completeness

Key Delivery:

-  `summary.csv`: 20 × 16 Final result table; SHA- 256 `7b1df6d2b6a9441cf16f2a82d2b7b77e782cb7ab73ea73b72c556718dd7934e7`
-  `summary_rows_batch5.audit.json`: fixed sequence, fields, model hash, proof path, time gate and gap audit; PASS
-  `summary_csv_batch5_exact.audit.json`: JSON→CSV Decimal word process verification; 20 / 20, zero failure
-  `batch5_root_review.json`: Batch 5 Mathematical claims, manifests, permissions, processes and root manifests synchronous audit; PASS
-  `final_delivery_manifest.json`: core delivery list; sidewalk `final_delivery_manifest.sha256` records and validates its SHA- 256
-  `protocol_events.md`: All known protocol events and effects determined

Batch 5 also underwent two independent read-only reviews, which found no mathematical overclaim concerning bound direction, gap arithmetic, strict/official primal separation or promotion of restricted conclusions. This independent claim review explicitly covers Batch 5. Batch 1-2 summary-row audits are in `summary_rows_batch1.audit.json` and `summary_rows_batch2.audit.json`, with mathematical evidence in the instance directories; Batch 3-4 have `batch3_root_review.json` and `batch4_root_review.json`. This report does not present the Batch 5 review as a fresh review of every mathematical argument for the first 16 instances.

Final remote state: summary/time/report files exist for all four Batch-5 instances, and the original archive has mode `0444`. All 135/135 Sandon files match by SHA-256 across the full tree; 0 processes match exact instance paths under the experiment root. The root `manifest.md` revision to 90-150 minutes is synchronized, with local and remote SHA-256 both `1fdde8d8ea9937ec3c7f0af68128806956cc4b60550f900626d820bd0d32d3c4`.

##  9. Protocol events and effects

`protocol_events.md` Full disclosure:

-  Two times the over-width of the read-only process name filter sees the command line outside the experimental root; no external files are opened, copied, modified or used;
-  The absolute root of the `supportcase22` closeout `rg` exclusion glob fails, with the return showing `cdma` matching; no further reading or conclusion after the stop;
-  Remote root manifest Once still the old time rule, Batch 5 actually uses user-defined new rules; eventually it has been synchronized and hashed consistent;
-  Sandon's increase synchronized with the remote source `0444` refused coverage, a temporary misplaced audit copy and an automatically generated pycache; both were cleared on the exact path, and ultimately the entire tree parity was passed.

These events were read-only or administrative close-out events, without providing evidence for any primal, dual, gap or optimality conclusions.

##  10. Limitations and follow-up priorities

-  Except for two exact closure instances, one instance of 18 remains open; a smaller gap cannot replace proof.
-  The majority of `best_valid_dual`s are reproducible computational global domains rather than portable exact rational certificates; their evidence levels are marked instance-by-instance.
-  public pages and incumbent may change after the freezing date; this report only compares 2026 -09 -11 freezing snapshots.
-  Solver time is the amount of work that has been recorded, and does not guarantee coverage of each extremely short, not individually timed diagnostic phase.
-  The cumulative active/solver time is the sum of the workloads of the instance; four parallel instances cannot explain the time spent on a single wall clock for the entire experiment.

The recommendation is to continue:

1.  `seqsolve1`: gap is only an integer objective unit of 8, prioritized for proof-based site-coupling decomposition or 4269 exclusion of 4277 interval;
2.  `dc1l`: 0.5860 % gap, priority reinforcement has an exact quotient/certificate chain, rather than repeated parameter sweep;
3.  `ger50-17-trans-dfn-3t`: Extended family of independent cutsets that have shown positive action;
4.  `cmflsp60-36-2-6`: First establish a unified strict primal gateway and then explore whole-family structures that have not yet been closed;
5.  `r4l4-02-tree-bounds-50`: branch/decomposition of proof orientations around the new incumbent with fundamental-cycle cuts;
6.  `stockholm`: Research can improve the stronger toll-design projection of the master lower bound, rather than continuing to accumulate the same class of IIS cuts.

The next recommendation for the rest of the open instance is to keep the route, exact commands and failure boundaries in their final report and chronological ledger.

##  11 . instance Evidence indexing

| Instance | Main report |
|---|---|
| `graphdraw-grafo2` | `instances/graphdraw-grafo2/instance_report.md` |
| `polygonpack4-10` | `instances/polygonpack4-10/instance_report.md` |
| `scpm1` | `instances/scpm1/instance_report.md` |
| `ger50-17-trans-dfn-3t` | `instances/ger50-17-trans-dfn-3t/final_report.md` |
| `eva1aprime6x6opt` | `instances/eva1aprime6x6opt/final_report.md` |
| `cmflsp60-36-2-6` | `instances/cmflsp60-36-2-6/final_report.md` |
| `r4l4-02-tree-bounds-50` | `instances/r4l4-02-tree-bounds-50/final_report.md` |
| `sct1` | `instances/sct1/final_report.md` |
| `shipsched` | `instances/shipsched/final_report.md` |
| `rocII-8-11` | `instances/rocII-8-11/final_report.md` |
| `ns1856153` | `instances/ns1856153/final_report.md` |
| `dc1l` | `instances/dc1l/final_report.md` |
| `neos-5221106-oparau` | `instances/neos-5221106-oparau/final_report.md` |
| `zeil` | `instances/zeil/final_report.md` |
| `cdma` | `instances/cdma/final_report.md` |
| `ns1456591` | `instances/ns1456591/final_report.md` |
| `seqsolve1` | `instances/seqsolve1/final_report.md` |
| `stockholm` | `instances/stockholm/final_report.md` |
| `supportcase22` | `instances/supportcase22/final_report.md` |
| `neos-3682128-sandon` | `instances/neos-3682128-sandon/final_report.md` |

##  12 . Authorized original archive SHA- 256

The following hash corresponds to the authority `.mps.gz` archive for each exact instance name, rather than the derivative model:

| Instance |  SHA-256  |
|---|---|
| `graphdraw-grafo2` | `a5528a5b80f4405206449e26933e69eb5c2465bceff303a5086a572b80bdbfed` |
| `polygonpack4-10` | `c77946405fd9fc1a53aa56dec82a1dcdef9932248c15ecc17e1ea05d49ab0969` |
| `scpm1` | `fef145329bf9dd25fd9ff59a51816c044adf41ae627a23ab8c93eeb31cffed41` |
| `ger50-17-trans-dfn-3t` | `fd05921bf1e954a9123a8d686f1610c00f03f700235910962220b1f3b8d20704` |
| `eva1aprime6x6opt` | `32ac7ea0015a16edc5058a6c6c2c9e8d79262b170888fc806304aaa2a51e0161` |
| `cmflsp60-36-2-6` | `ce7f3600260baaf5e8cea531d616e212723875003366014af17d8802d2909da4` |
| `r4l4-02-tree-bounds-50` | `f6dedac412b6d9e9c6ee4ad0a91c92c27027d031efcd25a62dc4a26eb39d33f3` |
| `sct1` | `49423b96c7a5f3c64590ec8f283d0111e4a7730348693e5c1f53df09542fb7a2` |
| `shipsched` | `152d733821a90eae633bef181fe0e0907dc23e6a8afa8413bc98c22cc115b9f1` |
| `rocII-8-11` | `8d0f3e5aacd9ceec0e0c2618d96ba00ad87803b457adaac4542b4393af5155b1` |
| `ns1856153` | `f52ae202906c0df1bcc804b679c647cff2e62607c2b78301dff8b5d9f51a13b4` |
| `dc1l` | `49d40810273a4948b8b56be538b46575b566afa2f133094a4a687f05ab7604f5` |
| `neos-5221106-oparau` | `788ac2b03e5a11b39b58e616663ed598cc9523e64ff195c7c8d038e3b4459d2d` |
| `zeil` | `0a841d40523d10b0b66ebd2b3ad2a24baba5a351148b6bdf77685669a513bebe` |
| `cdma` | `84775da3b8e919cd5363bbe3f2a170a126b379f1f2d9cdf4b7ac70bbb93384fb` |
| `ns1456591` | `acc4972ca3c3f59ab052d7b39ca1ded34d5a685f82e0a64a95dc317839594ccf` |
| `seqsolve1` | `4aa946b2d01a7f6d700cbd35194b8938961b6e872f0deca4ac16b7268f43b1aa` |
| `stockholm` | `42f1fa8ba37eaf11999579b09562be30d6b26df151b06dcbaa710dab0eb82498` |
| `supportcase22` | `69b86a13d312e6531d03cd93f31d13e4b8db01dd4093761b72acdefeb38bd8a3` |
| `neos-3682128-sandon` | `8f2b0f9f2ca63ed893a5524279d98a983b967276f9bcbb278301fb146ca2f71c` |

##  13. This experiment actually reads SKILL.md

-  The path is absolute: `C:\Users\huangyicheng\.agents\skills\milp-structure-research\SKILL.md`
- SHA-256：`f8a09b104f0af3786b2e702f60dde3de7fd54a1aac581dff9bdd8a3325c84b4f`

Before each instance starts, the access to the skill is re-executed and recorded; the corresponding timestamp, the number of file bytes, the reference file hash and `read_before_instance_access=true` are kept in the instance evidence directory. For a list of supported materials see `shared/skills_read.md`.
