# Repository refresh: October 12, 2026

Read this reference when interpreting current cases or comparing results. It does not authorize prior-target evidence in a blind experiment. Keep any frozen experimental skill separate from this updated operational version.

## Pinned sources and scope

- [Main research snapshot](https://github.com/Huangyc98/MIPLIB_openproblem/tree/8779d862b692348321c3607642f63e6c443cae09): `8779d862b692348321c3607642f63e6c443cae09`, committed October 6, 2026; remote `main` was checked October 12.
- [Complete catalogue snapshot](https://github.com/Huangyc98/MIPLIB_openproblem/blob/933fcc1120a7084b3b67726b0e9a959045b5f3d1/results/ALL_RESULTS.md): `933fcc1120a7084b3b67726b0e9a959045b5f3d1`, on `organize/complete-results-20260921`, also committed October 6. The main README links to this separate branch.
- Main has 198 instance directories; the complete catalogue has 217 distinct entries, including results organized under study/experiment paths. Directory counting is not catalogue coverage.
- The bundled `latest-results.json` indexes the 217 catalogue entries with pinned sources, reported values, separate exact/numerical values, baseline-specific comparisons, and qualifications. The old 112-instance files remain dated historical evidence. The lookup helpers default to the refreshed index; `--snapshot historical` explicitly selects the historical index.

This refresh reviews campaign overviews, selected detailed method/proof reports and source records. It does not rerun the 217 optimizations or independently replay all archived certificates. Catalogue claims are attributed repository evidence; lookup is not mathematical verification or an automatic reason to stop a new task.

## Baselines and totals are not interchangeable

| Reported quantity | Actual scope |
|---|---|
| 217 catalogue entries | Combined published coverage at the pinned complete-results commit |
| 49 optimal conclusions | Qualified total: exact, computational, numerical/tolerance and model-specific caveats remain attached |
| 2 infeasible, 1 unbounded | Distinct conclusion types; unboundedness is not a finite optimum or a finite dual improvement |
| 51 primal updates | Previously assessed attribution against frozen MIPLIB v36 in the preceding 187-entry catalogue |
| 112 dual improvements | Previously assessed comparisons with historical COPT 10-hour results in that preceding catalogue |
| 10 material primal gains in the recent 30 | Three fresh campaigns with 3 + 4 + 3 gains against their strict validated/repaired starting points |
| 10 best-global-bound gains in the newest 10 | Gains over fresh 300-second original-model probes; later research used more time |

Do not add fresh campaign gains to the historical 51/112 and call the result a common-baseline total. Fresh cases are unassessed against those old baselines, not zero-improvement cases. Do not call the 300-second-versus-longer comparison an equal-budget skill speedup. Keep a repaired baseline, a website's tolerance headline, a generated candidate and a strictly verified final point as separate objects.

The latest fresh cohort has three material primal improvements (`neos-1420546`, `snp-10-004-052`, `neos-3754224-navua`) and three polish-only changes (`hgms30`, `hgms62`, `snp-06-004-052`). Materiality is not a universal percentage threshold: a small relative gain can reflect a changed discrete decision, while a larger apparent gain may only repair an invalid starting vector.

## Qualifications that must survive lookup and reporting

- **Sutlej:** a displayed historical P/D of `-1048730.9379120774` is tolerance-based. The strict literal-model optimum is `-1048730.8`. Use the detailed proof/strict field rather than promoting a generic table heading to an exact claim.
- **Tagus:** `32225.700099` is an exact conclusion for a particular hashed MPS. It conflicts with a public headline of `4206.140099965`; the cause remains unresolved. It is not an unqualified public-record improvement or a bound transferable by instance name alone.
- **Navua:** the strict final `166345.74718740067` improves a repaired baseline near `2108583.4751875894`. It does not beat the public tolerance headline `157909.0677610051`. A separate `1e-9`-tolerance point is not the zero-residual witness.
- **RFDS:** the strongest recorded numerical bound `-1146278.6542107703` comes from a run whose incumbent violates original rows by over one million. Reject that candidate and retain the bound's explicit numerical qualification; seek corroborating global runs or certification before using it for strict exclusions. An invalid incumbent alone neither proves that the bound is false nor establishes it as safe.
- **SHS1014:** the exact feasible value is `22671.197441887947`, distinct from its numerical display. Keep the audited numerical bound `22555.8775122676`; quarantine inconsistent larger continuation bounds and do not import a historical COPT number above a validated feasible objective.
- **CDMA:** a historical numerical witness was not uniformly revalidated. Treat it as a candidate until it passes the actual task's original-model policy. Best-of separate experiments is not a paired full-run comparison.
- **Genus g31 variants:** catalogue entries explicitly use a `1e-10` policy for a roughly `1e-15` literal-MPS primal residual. This is tolerance-qualified closure, not zero-residual feasibility.
- **Supportcase35:** exact decimal columns yield a feasible recession ray with negative objective slope. There is no finite minimum or finite minimization lower bound. Finite ray examples and solver infinity sentinels do not enter ordinary improvement/gap tables.

## Evidence acquisition and practical use

Use repository case records to propose a route, then reconstruct its assumptions on the new target. Audit original model hashes, domains, objective constants and decimal coefficients before transferring a transformation or proof. When a detailed source corrects an older summary, retain both records and state which claim supersedes which.

For a fresh/blind benchmark, check the allowed evidence policy before querying an instance. An expanded index increases prior-target overlap. Freeze skill bytes and log references actually read; do not silently use newly learned target results in an old controlled arm. New operational skills can benefit from these results without retroactively changing what historical experiments knew.

Keep artifact-only checks distinct from original-model feasibility checks, exact bound checks and optimizer reruns. A `verify.py --artifacts-only` success verifies packaging, not a mathematical result. In core publications, full failed-trial archives may remain outside the repository; missing logs limit causal or failure-frequency claims even when the final mathematical certificate is complete.
