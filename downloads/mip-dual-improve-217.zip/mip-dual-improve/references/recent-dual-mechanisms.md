# Dual mechanisms from the September 26 - October 6 studies

This is a selective transfer guide, not a prescribed checklist. Sources are pinned to repository commit `8779d862b692348321c3607642f63e6c443cae09` (October 6, 2026). Read the matching mechanism and its limitations. The refresh inspected reports and derivations; it did not rerun the solver campaigns or independently replay all proof bundles. The repository's recorded replay outcomes are attributed evidence.

The strongest numerical bound and the strongest exact bound are both useful. In the October 6 ten-instance study, nine best reported bounds are numerical and one is independently exact; certification is not a requirement for making useful dual progress. That study compares with its own fresh 300-second baselines after longer adaptive research, not with equal-budget runs or the historical COPT 10-hour table. See [repository-refresh-20261012.md](repository-refresh-20261012.md) for catalogue accounting.

## Choose a representation that exposes the bottleneck

| Observable structure | Useful next experiment | Main validity obligation |
|---|---|---|
| Identical groups with means, absolute deviations and coverage penalties | Canonical hinge cost; cardinality-type aggregation; pair-distance, triangle, subset-count and moment cuts | Derive the literal source identity; cover every size and preserve soft penalties |
| One-hot states with shared continuous physics | State-disaggregated perspective copies and physical boxes | An original integer point activates one state and has an equal-cost lift |
| Binary activations in a continuous network | Per-path hulls, rounded capacity cuts; measured Benders trial | Source-valid flow bounds and globally valid recourse cuts |
| Almost low-rank kernel or nearly trigonometric coefficients | Residual-bounded outer projection | Account for literal coefficient error with the correct inequality direction |
| Small label space hidden by millions of table-selection columns | Pairwise energy and exact cost reparameterization | Audit every one-hot table and linking equality; no missing labels |
| Ordered routes with resource limits | Complete resource-state pricing and a corrected master dual | Every original path is priced, including terminal resources |
| Integer rewards with voucher/stock/scheduling semantics | Prefix, counting, small DP, assignment-potential bounds | Prove the semantic implication from active source rows and domains |
| Dense objective but few useful integer decisions | Threshold-safe bound propagation and compact Lagrangian projection | Retain interval minima for eliminated variables; apply the threshold cap once |

## 1. Grouping: combine local geometry with global counts

`neos-1420546` and `neos-1420790` have interchangeable groups, one-hot item assignments, attribute means, absolute deviations and soft cardinality/coverage costs. Eliminate free deviation slack only through its minimum-cost lift. For the audited source, rewrite the objective as a constant plus nonnegative group hinge costs.

Start with the cheapest bound-producing representation:

- Solve or bound a complete single-group oracle. With membership prices `u`, combine its **global lower bound** as `C + sum(u) + G * oracle_LB` for `G` identical groups. A pool master proposes multipliers; its optimum is not a global bound.
- Bound one attribute at a time for each possible group size using the proved sorted-window minimum, then combine sizes through an exhaustive cardinality DP. When literal mean coefficients differ from the ideal proportional formula, add a rigorous perturbation correction; do not import the ideal identity unchanged.
- Introduce group counts, item masses and same-group pairs by size. Degree, endpoint and transitivity inequalities strengthen the projection. Pair-distance lower bounds expose geometry absent from independent features.
- Separate subset-count inequalities from `(s-k)(s-k-1) >= 0` for integer `s`, and moment inequalities from the positive semidefinite sum of outer products `[1; membership][1; membership]^T`. Numerical eigenvectors choose candidate cuts; recompute the recorded integer-vector coefficients exactly.
- Strengthen the weak cost representation with selected-item hinges or universal group-affine cuts obtained from dual prices and residual correction. Check which missing feature limits the bound before adding more transitivity rows.

All-size coverage matters: a good fixed-size oracle replaces only that size's bound; take a minimum over every size, retaining inherited bounds for unfinished sizes. A restriction such as zero missing categories or sizes in a short interval may be valid only below a threshold. Preserve that scope.

The October 6 reports record numerical/exact bounds of `3067.067291069953` / approximately `3066.7434033326062` for 790, and approximately `22618.025646072001` / `22629.32917678247` for 546. These are source-specific results, not transferable constants. Full group pricing stalled; a larger pair model improved roots but made node LPs expensive. Retaining an incremental LP basis enabled useful higher-order separation after cold starts failed. An unfinished LP's displayed primal objective was rejected; its row prices were usable only after independent residual correction.

Sources: [546 derivation](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/neos-1420546/reports/research_notes/dual/proof.md), [790 decision ledger](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/neos-1420790/reports/research_notes/dual/research_ledger.md).

## 2. Perspective states: improve the hull without losing the physics

For `hgms62`, generator-count states couple shared maintenance calendars to continuous water recourse. For a one-hot state `z`, disaggregate each relevant continuous variable `x` into copies with `L*z <= x_copy <= H*z` and `sum(x_copy)=x`. Derive finite physical boxes from original rows first. Perspective production rows must retain the state's RHS contribution. An original integer point lifts by assigning its continuous values to the unique active state.

Exact polygon clipping on the physical box identified production planes that never define the envelope. Removing them reduced the formulation, but further redundant-row deletion was not uniformly faster. Restoring valid redundant planes or exact unit scaling sometimes improved numerical root behavior. Complete calendar formulations, Benders, RLT and transported sibling prices were tested and could be weaker or unstable. Use short pilots before committing the remaining budget.

`supportcase41` transfers the same idea to all admissible activity masks per time period, disaggregating four work channels and shared resources. Its objective is continuous: do not round the bound to an integer. Complete complementary branches can improve the exact series; unfinished leaves inherit their parent.

Sibling row prices are proposals only. For HGMS, a balanced scenario-transport matrix generated prices, but only the target model's residual check gave a bound. Conditional calendar elimination transfers through `min(T,D)`, even if a filtered model later solves easily.

Sources: [HGMS62 proof and negative routes](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/hgms62/reports/research_notes/dual/proof.md), [supportcase41 evidence](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/supportcase41/reports/research_notes/dual/README.md).

## 3. Network hulls and useful stopping rules for weak relaxations

`neos-848198` exposes 22 nodes and direct/two-hop routing options. Necessary capacity cutsets helped, then path on/off hulls using finite demand bounds strengthened the root substantially. Separating additional rounded cutsets and keeping productive full-model trees ultimately beat several elaborate alternatives.

Its Benders cuts were algebraically valid, but large unscaled coefficients caused numerical acceptance of points violating intended lazy cuts. Exact power-of-two row scaling restored rejection behavior, yet hundreds of further cuts still plateaued. Validity and effectiveness are separate questions. Keep the accepted original-global solver bound while testing a stronger route; never claim a callback relaxation incumbent is original-feasible.

An undirected projection had a feasible relaxation point with cost below the best original-global lower bound. Since that point upper-bounds the relaxation optimum, solving that relaxation harder could not improve the best bound. Stop or strengthen it. This is a cheap impossibility test for a proposed dual route and needs no original primal solution.

Source: [network decision ledger](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/neos-848198/reports/research_notes/dual/research_ledger.md).

## 4. Literal coefficient errors can support safe outer reductions

In `gsvm2rl12`, the numerical kernel is rank ten but the literal decimal matrix need not have exact rank ten. Write `K=AB+E` exactly and bound `|E_i u|` using an outward residual norm and the source norm variable. Replacing a margin expression with its safe upper surrogate yields an outer relaxation. Balanced sample multipliers cancel the intercept and generate disjunctive loss cuts. If an objective threshold gives finite boxes, certified margin lower bounds can tighten Big-M; tighten only successful queries and retain the original coefficient for timeouts. A Big-M certified for the reduced expression cannot be copied directly into the original expression.

`neos-3754224-navua` contains thousands of zero-cost continuous fold blocks. Back-substitution generates supporting planes only while every inequality multiplier has the required nonnegative sign. Keep literal, slightly unequal trigonometric-looking coefficients. Exact affine equality substitutions and objective normalization can improve conditioning without changing the feasible objective values. A necessary conic relaxation was valid but numerically unproductive; the accepted evidence used linear projections and residual-corrected prices instead.

Sources: [GSVM derivation](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/gsvm2rl12/reports/research_notes/dual/proof.md), [Navua projection](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/neos-3754224-navua/reports/research_notes/dual/proof.md).

## 5. Threshold-safe contraction and compact Lagrangian models

For SNP network models, an objective split at `T` made bound propagation and integer lattice deductions useful. In the `f <= T` region, derive finite boxes, tighten integer bounds with correct rounding, price dropped rows, and retain an interval minimum for each omitted variable. The result is `min(T, constant + compact_global_LB)`. Dropping the dense threshold row later is a relaxation, but does not make threshold-derived bounds unconditional.

Rational GMI cuts require a correctly identified integer basic variable and exact translations; use integer formulas only for integral shifts. Correct decimal row exports against proven boxes. Decompose into independent components only after substitution and checking **every** retained row. Add component bounds and the Lagrangian constant once, then apply the outer threshold cap. A source NAME label such as `SNP10_EXT` does not establish identity; hashes and full coefficient/domain comparisons do.

Useful multipliers may survive an interrupted or suboptimal LP. Correct row signs and evaluate every residual. For an unbounded variable, a residual in an unfavorable direction cannot be repaired with an invented finite box. A failed denominator compression, partial MPS export or intermediate objective does not become accepted evidence.

Sources: [SNP10 proof](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/snp-10-004-052/reports/research_notes/dual/proof.md), [SNP06 evidence](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/snp-06-004-052/reports/research_notes/dual/README_evidence.md).

## 6. Complete pricing and overlapping local structures

`sutlej` projects an acyclic routing model onto resource-constrained paths. Pricing enumerates complete states `(visited count, last customer, resource)`, with safe dominance and terminal resource checks. Beam truncation would invalidate the oracle. A master dual plus the minimum reduced cost over **all** paths gives a bound even when the route pool is incomplete. Complementary branch predicates and inherited bounds cover the full original improving region.

`ns930473` similarly uses source-implied ordered pickup/delivery paths and complete integer pricing. `xmas10` strengthens local patterns to width-five forest strips. A restricted original path can be disconnected inside a strip, so requiring strip connectivity would cut out valid original projections. Strips overlap: sum their minima only together with the remaining node residuals, which correct double-counting. Its exact unrounded bound `-508.126058199` rounds to `-507` on the proved odd objective lattice.

In the newer wards study, complete block pricing gave a base bound. An objective identity and the remaining cutoff budget forced certain covering slacks to zero. A finite class/count model strengthened the result only after independent exclusion established that all relevant private block classes were covered; a discovered pattern pool would not suffice. The closure retains numerical solver evidence for those finite exclusions rather than claiming a standalone exact trace.

Sources: [Sutlej proof](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/studies/primal-dual10-r41-50-20260927/SUTLEJ_PROOF.md), [ns930473](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/ns930473/README.md), [Xmas10](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/xmas10/README.md), [Wards complete classes](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/studies/primal-dual10-r31-40-20260927/WARDS_NOTES.md).

## 7. Small semantic cores can replace enormous formulations

- **Pairwise table energy:** `proteindesign121hz512p19` has about 2.59 million integer columns but only 12 shared label choices. Audited unary/pair tables give an energy relaxation. Reparameterization messages cancel exactly; sums of table minima give a bound. Remaining nonnegative residual costs support safe label deletion and a complete label-partition tree. The recorded 63-node tree proves 3382; the 300-second original COPT baseline was only about 3216.35. Transfer the table audit and energy identity, not the specific messages.
- **Heterogeneous vouchers:** `pizza27i` derives a sorted-prefix bound. For `k` free items, enumerate voucher subsets with enough free capacity and minimize their required paid count `B(k)`. The kth free item cannot appear before rank `k+B(k)`, with paid-before-free tie handling. Positive prices turn this into a savings upper bound and cost lower bound. Verify indicator activation, counts and price-order implications; pizza78i supplies a mechanism, not a certificate for pizza27i.
- **Cutoff-induced stock core:** `supportcase31` reduces every improving solution to 38 assigned orders, then uses rational stock prices, a 41-item integer DP and complete enumeration of the remaining cases. Aggregated supply must not count the same physical wafer twice.
- **Tree and scheduling cores:** `reiu` uses a source-derived rooted binary tree, a Huffman lower bound and tail correction. `waipa` uses job head/tail inequalities and nested-prefix assignment potentials. These are useful routes when the matrix, not just the application name, supports their hypotheses.

Sources: [protein proof](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/proteindesign121hz512p19/reports/proof.md), [pizza proof](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/pizza27i/reports/proof.md), [stock core](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/supportcase31/README.md), [Reiu](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/neos-3208254-reiu/README.md), [Waipa](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/neos-4535459-waipa/README.md).

## Evidence barriers demonstrated by the new results

| Case | What the source supports | Transfer rule |
|---|---|---|
| `supportcase35` | Exact literal-decimal feasible ray with negative objective slope; infimum is negative infinity | A near-cancellation can change boundedness. Check the actual decimals; infinity sentinels are not finite dual values |
| `neos-4358725-tagus` | Exact result for a hashed model, unresolved conflicting public headline | Scope the conclusion to that model; do not assert a public-record gain or invent a discrepancy explanation |
| `rfds-4-days` | Strongest raw numerical bound comes from a run whose incumbent has a huge original-row violation | Preserve the qualification and independent alternative bounds; do not promote that run to clean certified evidence |
| `shs1014` | Accepted projection bound is separated from conflicting larger continuation values | Quarantine contradictory candidates instead of taking an unconditional maximum |
| `sutlej` | Strict exact optimum `-1048730.8`; public tolerance witness `-1048730.9379120774` is distinct | Detailed source proof overrides a stale cohort table; do not merge tolerance and strict closure |
| `scpn2`, `seqsolve*`, `tpl-tub-ws1617` | Numerical bounds may use audited objective lattices or an optimum-preserving integer projection | Integer rounding does not upgrade numerical solver evidence into an exact certificate |

Sources: [unbounded ray](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/supportcase35/README.md), [Tagus qualification](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/neos-4358725-tagus/README.md), [RFDS](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/rfds-4-days/README.md), [SHS](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/shs1014/README.md), [integer projection](https://github.com/Huangyc98/MIPLIB_openproblem/blob/8779d862b692348321c3607642f63e6c443cae09/instances/tpl-tub-ws1617/README.md).
