#!/usr/bin/env python3
"""Print matching dual case records without loading the whole corpus into context."""
import argparse
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('query', nargs='?', help='Exact instance name, name fragment, or family')
    parser.add_argument('--snapshot', choices=('latest', 'historical'), default='latest',
                        help='Default: 217-entry refresh; historical: original 112-entry index')
    parser.add_argument('--limit', type=int, default=8)
    args = parser.parse_args()
    if args.limit < 1:
        parser.error('--limit must be positive')
    filename = 'latest-results.json' if args.snapshot == 'latest' else 'corpus-index.json'
    data = json.loads((Path(__file__).resolve().parents[1]/'references'/filename).read_text(encoding='utf-8'))
    if args.query is None:
        print(json.dumps({k:v for k,v in data.items() if k != 'instances'}, ensure_ascii=False, indent=2))
        return 0
    query = args.query.casefold()
    exact = [r for r in data['instances'] if r['name'].casefold() == query]
    rows = exact or [r for r in data['instances'] if query in r['name'].casefold() or query == (r.get('family') or '').casefold()]
    if args.snapshot == 'historical':
        print(json.dumps(rows[:args.limit], ensure_ascii=False, indent=2))
    else:
        print(json.dumps({'snapshot_commit': data['latest_main_commit'],
                          'catalogue_commit': data['catalogue_commit'],
                          'usage': data['usage'], 'value_semantics': data['value_semantics'],
                          'family_scope': 'Family filtering uses historical 112-instance classifications only.',
                          'matches': len(rows), 'cases': rows[:args.limit]}, ensure_ascii=False, indent=2))
    return 0 if rows else 1


if __name__ == '__main__':
    raise SystemExit(main())
