# neos-4545615-waita

Result snapshot: 2026-10-06.

## Current result

- Conclusion: Open
- Primal bound: 6311
- Dual bound: 6021
- Normalized gap: 0.0459515132308667406116304864522262715892885438
- Primal improvement vs MIPLIB v36: False
- MIPLIB v36 primal: 6311.0
- Primal difference (baseline minus result): 0
- Dual improvement vs historical COPT 10h: True
- Historical COPT 10h dual: 3753.09803
- Dual difference (result minus baseline): 2267.90197

## Verification and qualifications

Exact original witness and independent DP lower certificate; unequal bounds leave the problem open



- Primal validation: Exact rational original-MPS feasibility, zero residual
- Dual validation: See separately reported numerical and independent exact bounds
- Primal comparison: No difference above 1e-7
- Dual comparison: Improved

## Files and provenance

[Result data](result.json) · [Source research record](https://github.com/Huangyc98/MIPLIB_openproblem/blob/organize/complete-results-20260921/instances/neos-4545615-waita/README.md)

The result bundle contains this summary, the current result data, and the project license.
Source research records may require repository access. Solver logs and full proof archives
are not embedded in this compact result bundle. Numerical and tolerance-based conclusions
retain their stated qualifications; the source-model qualification for tagus is recorded
in its own result. These are project results against fixed baselines, not a live leaderboard.
